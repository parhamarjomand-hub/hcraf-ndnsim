#!/usr/bin/env python3
"""Verify P12R fair-comparator preregistration. NO ndnSIM, AP, or training."""
import argparse,csv,hashlib,io,json,pathlib,sys
from collections import Counter
ROOT=pathlib.Path(__file__).resolve().parents[3]
DOC=ROOT/'hcraf/episode/docs/1AM/F3_P12R_FAIR_COMPARATOR_PREREG_v0.52.37'
PLAN=DOC/'P12R_FAIR_COMPARATOR_PROSPECTIVE_PLAN_v05237.json'
MATRIX=DOC/'P12R_LOCKED_MATRIX_504_v05237.csv'
COMMIT=DOC/'P12R_FROZEN_SCHEDULE_COMMITMENTS_252_v05237.json'
SCIENCE={'Congestion':None,'FutureCongestion':None,'F3_ready':False,'GO_FREEZE':False,'training_ready':False,'heldout_release_authorized':False,'Stage1AO_or_NSGAIII_authorized':False}
def demand(v,c):
 if not v:raise AssertionError('P12R_'+c)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def audit():
 p=json.loads(PLAN.read_bytes());c=json.loads(COMMIT.read_bytes())
 demand(all(p[k] is v for k,v in SCIENCE.items()),'SCIENCE_LOCK')
 demand(not p['current_step_only']['independent_study_execution_authorized'],'NO_NEW_SIM')
 demand(all(p['current_step_only'][key]==0 for key in ['new_AP','new_bootstrap','new_simulations','new_model_fits']),'ZERO_NEW_COMPUTATION')
 demand(p['seed_partitions']['development']==list(range(24901,24907)),'DEV_SEEDS')
 demand(p['seed_partitions']['independent_confirmation']==list(range(25001,25037)),'CONFIRM_SEEDS')
 excluded=set(p['seed_partitions']['consumed_P12K']+p['seed_partitions']['legacy_validation']+p['seed_partitions']['permanently_sealed_Heldout']+p['seed_partitions']['legacy_development'])
 demand(not excluded.intersection(p['seed_partitions']['development']+p['seed_partitions']['independent_confirmation']),'SEED_OVERLAP')
 demand(sha(MATRIX.read_bytes())==c['matrix_sha256']==p['prospective_design']['matrix_sha256'],'MATRIX_SHA')
 demand(sha(COMMIT.read_bytes())==p['prospective_design']['schedule_commitments_sha256'],'COMMIT_SHA')
 rows=list(csv.DictReader(io.StringIO(MATRIX.read_text())));demand(len(rows)==504,'ROW_COUNT')
 seen=set();arms=Counter();plans=set()
 for r in rows:
  seed=int(r['seed']);key=(seed,r['site'],r['load'],r['telemetry'])
  demand(key not in seen,'DUPLICATE');seen.add(key)
  demand(r['site'] in ('producer_egress','transit_middle','consumer_ingress') and r['load'] in ('low_control','high_pressure') and r['telemetry'] in ('off','on_20ms'),'UNKNOWN_CELL')
  expected_partition='FAIR_LOCAL_DEV' if seed in range(24901,24907) else 'FAIR_COMPARATOR_CONFIRM'
  demand(seed in list(range(24901,24907))+list(range(25001,25037)) and r['partition']==expected_partition,'PARTITION')
  demand(r['execution_authorized_now']=='false' and r['validation_or_heldout_released']=='false','AUTHORIZATION')
  f=r['schedule_filename'];plans.add(f)
  demand(c['schedule_hashes'][f]==r['schedule_sha256'],'SCHEDULE_MATRIX')
  demand(sha((DOC/'plans'/f).read_bytes())==r['schedule_sha256'],'SCHEDULE_SHA')
  arms[(r['partition'],r['telemetry'])]+=1
 demand(len(plans)==252 and len(c['schedule_hashes'])==252,'PLAN_COUNTS')
 demand(arms==Counter({('FAIR_LOCAL_DEV','off'):36,('FAIR_LOCAL_DEV','on_20ms'):36,('FAIR_COMPARATOR_CONFIRM','off'):216,('FAIR_COMPARATOR_CONFIRM','on_20ms'):216}),'BALANCE')
 b1=p['feature_sets']['strengthened_local_B1_primary_control'];r=p['feature_sets']['remote_plus_B1_R_primary_treatment']
 demand(r[:len(b1)]==b1 and len(r)>len(b1),'NESTED_TREATMENT')
 demand(p['analysis_rules']['bootstrap_replicates']==10000 and p['analysis_rules']['bootstrap_rng_seed']==525250,'BOOTSTRAP_LOCK')
 demand(p['model_training_locked']['development_rows_only']==4608 and p['model_training_locked']['confirmation_seed_blocks']==36,'TRAIN_SPLIT')
 return {'stage':'P12R_v0.52.37','status':'PASS_P12R_NEW_FAIR_COMPARATOR_STUDY_PROSPECTIVELY_PREREGISTERED_ONLY','matrix_sha256':sha(MATRIX.read_bytes()),'plan_sha256':sha(PLAN.read_bytes()),'commitments_sha256':sha(COMMIT.read_bytes()),'development_seeds':list(range(24901,24907)),'confirmatory_seeds':list(range(25001,25037)),'case_count':504,'schedule_count':252,'physical_cases_run':0,'new_models_fit':0,'new_AP_computed':False,'heldout_read':False,'future_execution_authorized':False,'P12Q_parent_run':45830572992,**SCIENCE}
def main():
 a=argparse.ArgumentParser();a.add_argument('--output',required=True);args=a.parse_args()
 out=audit();pathlib.Path(args.output).write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(out['status'])
if __name__=='__main__':main()
