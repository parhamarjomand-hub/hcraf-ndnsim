import unittest,importlib.util,pathlib,tempfile,json,copy,csv,io
ROOT=pathlib.Path(__file__).resolve().parents[3]
DOC=ROOT/'hcraf/episode/docs/1AM/F3_P12R_FAIR_COMPARATOR_PREREG_v0.52.37'
p=ROOT/'hcraf/episode/scripts/audit_stage1am_f3_p12r_prereg_v05237.py'
spec=importlib.util.spec_from_file_location('audited_p12r',p);a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
class P12R(unittest.TestCase):
 def test_complete_prereg_audit(self):self.assertTrue(a.audit()['status'].startswith('PASS_P12R'))
 def test_correct_partition(self):
  p=json.loads((DOC/'P12R_FAIR_COMPARATOR_PROSPECTIVE_PLAN_v05237.json').read_bytes())
  self.assertEqual(len(p['seed_partitions']['development']),6);self.assertEqual(len(p['seed_partitions']['independent_confirmation']),36)
 def test_holdout_sealed(self):
  x=a.audit();self.assertFalse(x['heldout_read']);self.assertFalse(x['F3_ready']);self.assertFalse(x['GO_FREEZE'])
 def test_model_fits_zero(self):self.assertEqual(a.audit()['new_models_fit'],0)
 def test_no_new_ap(self):self.assertFalse(a.audit()['new_AP_computed'])
 def test_no_execution_authority(self):self.assertFalse(a.audit()['future_execution_authorized'])
 def test_disjoint_old_seeds(self):
  p=json.loads((DOC/'P12R_FAIR_COMPARATOR_PROSPECTIVE_PLAN_v05237.json').read_bytes());self.assertFalse(set(p['seed_partitions']['independent_confirmation'])&set(range(24801,24837)))
 def test_nested_features(self):
  p=json.loads((DOC/'P12R_FAIR_COMPARATOR_PROSPECTIVE_PLAN_v05237.json').read_bytes());self.assertEqual(p['feature_sets']['remote_plus_B1_R_primary_treatment'][:12],p['feature_sets']['strengthened_local_B1_primary_control'])
 def test_same_primary_endpoint(self):
  p=json.loads((DOC/'P12R_FAIR_COMPARATOR_PROSPECTIVE_PLAN_v05237.json').read_bytes());self.assertEqual(p['endpoint']['horizon_ns'],75000000)
 def test_bootstrap_whole_seeds(self):
  p=json.loads((DOC/'P12R_FAIR_COMPARATOR_PROSPECTIVE_PLAN_v05237.json').read_bytes());self.assertEqual(p['analysis_rules']['bootstrap_unit'],'whole-seed paired resampling 36 blocks')
 def test_no_auto_go_anywhere(self):
  p=json.loads((DOC/'P12R_FAIR_COMPARATOR_PROSPECTIVE_PLAN_v05237.json').read_bytes());self.assertFalse(p['F3_ready']);self.assertFalse(p['Stage1AO_or_NSGAIII_authorized'])
 def test_mutated_science_lock_rejected(self):
  old=a.PLAN;tmp=tempfile.TemporaryDirectory();q=pathlib.Path(tmp.name)/'plan.json';v=json.loads(old.read_bytes());v['F3_ready']=True;q.write_text(json.dumps(v));a.PLAN=q
  try:self.assertRaises(AssertionError,a.audit)
  finally:a.PLAN=old;tmp.cleanup()
 def test_mutated_matrix_rejected(self):
  old=a.MATRIX;tmp=tempfile.TemporaryDirectory();q=pathlib.Path(tmp.name)/'matrix.csv';q.write_bytes(old.read_bytes()+b'corrupted');a.MATRIX=q
  try:self.assertRaises(AssertionError,a.audit)
  finally:a.MATRIX=old;tmp.cleanup()
 def test_matrix_all_504_cells(self):
  with (DOC/'P12R_LOCKED_MATRIX_504_v05237.csv').open() as f:self.assertEqual(sum(1 for _ in csv.DictReader(f)),504)
