#!/usr/bin/env python3
"""v0.52.10/P7: post-hoc DEV-only reconstruction of immutable v0.52.9 evidence.

The v0.52.9 pre-registered physical gate remains NO_GO. These are forensic,
exploratory, separate candidate streams, NEVER official F3 labels or models.
No simulation, model fitting, PR-AUC, validation, or held-out release occurs.
"""
import argparse
from bisect import bisect_right
from collections import Counter
import hashlib
import json
from pathlib import Path
import zipfile


PARENT_RUN = 44541671109
PARENT_ARTIFACT = 14543216459
PARENT_COMMIT = "8cda6ffe225e48ed584d448a7708fe0c685af078"
PARENT_SHA256 = "ae7ce3870016be927f06e4c1d6ffc058f251f9075386b0a508bbd585e1b02f9a"
SOURCE_SHA256 = "6689c538befd0d74cdc305c5d12bcca6f2e594559d54e44a0c247e9c87f95ece"
ROOT = "stage1am_f3_p4_revised_dev_v0529/"
SEEDS = (23201, 23202, 23203, 23204)
SITES = ("producer_egress", "transit_middle", "consumer_ingress")
ROLES = {"producer_egress": "producer", "transit_middle": "mid", "consumer_ingress": "relay"}
LOADS = ("low_control", "high_pressure")
TELEMETRIES = ("off", "on_20ms")
SCIENCE = dict(Congestion=None, FutureCongestion=None, F3_ready=False,
               GO_FREEZE=False, training_ready=False, heldout_release_authorized=False)
WINDOW_NS = 75_000_000
FRESHNESS_NS = 100_000_000


def require(yes, message):
    if not yes:
        raise RuntimeError("P4P7_" + message)


def sha256_file(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_json(archive, member):
    return json.loads(archive.read(member))


def iter_jsonl(archive, member):
    with archive.open(member) as handle:
        for line in handle:
            if line.strip():
                yield json.loads(line)


def expected_keys():
    return [(seed, site, load, telemetry)
            for seed in SEEDS for site in SITES
            for load in LOADS for telemetry in TELEMETRIES]


def assert_locks(record, context):
    for name, value in SCIENCE.items():
        require(name in record and record[name] is value, context + "_SCIENCE_LOCK_" + name)
    require(record["official_F3_labels_constructed"] == 0, context + "_OFFICIAL_LABELS")


def retrospective_label(drops, decision_ns, horizon_ns=WINDOW_NS):
    """Strictly after decision; right endpoint included, no proxy loss events."""
    return bisect_right(drops, decision_ns + horizon_ns) - bisect_right(drops, decision_ns)


def validated_receipt(receipt, decision_ns):
    require(0 <= receipt["sample_ns"] <= receipt["receipt_ns"] <= decision_ns,
            "FUTURE_OR_UNRECEIVED_TELEMETRY")
    require(decision_ns - receipt["sample_ns"] <= FRESHNESS_NS,
            "EXPIRED_TELEMETRY")
    return receipt


def audited_queue_drop_times(archive, prefix, scenario, audit):
    """Scan real QUEUE_DROP records; audit path role AND all-device totals."""
    role_node = {role: int(scenario["selected_" + role + "_node_id"])
                 for role in ("relay", "mid", "producer")}
    require(len(set(role_node.values())) == 3, "SELECTED_PATH_ROLE_NODES_NOT_UNIQUE")
    device = int(audit["physical"]["selected_device_index"])
    counts = Counter()
    all_count = 0
    times = []
    with archive.open(prefix + "pathwide_witness_b.jsonl") as stream:
        for line in stream:
            if b'"event_type":"QUEUE_DROP"' not in line:
                continue
            event = json.loads(line)
            require(event["event_type"] == "QUEUE_DROP", "INVALID_PHYSICAL_EVENT")
            all_count += 1
            if int(event["device_index"]) != device:
                continue
            for role, node in role_node.items():
                if int(event["node_id"]) == node:
                    counts[role] += 1
                    times.append(int(event["timestamp_ns"]))
                    break
    reference = audit["physical"]
    require(all_count == reference["all_devices_physical_queue_drops"],
            "ALL_DEVICE_REAL_QUEUE_DROP_AUDIT_DISAGREES")
    require(all(counts[role] == reference["physical_drops_by_role"][role]
                for role in role_node), "SELECTED_ROLE_REAL_QUEUE_DROP_AUDIT_DISAGREES")
    require(reference["nonqueue_receive_failures_excluded"] is True,
            "NON_QUEUE_LOSS_AMBIGUOUS")
    return sorted(times)


def process_condition(archive, row, feature_stream, label_stream, seen):
    key = (row["seed"], row["site"], row["load"], row["telemetry"])
    seed, site, load, telemetry = key
    prefix = ROOT + "/".join(map(str, key)) + "/"
    require(row["role"] == ROLES[site], "ROLE_MISMATCH")
    scenario = read_json(archive, prefix + "scenario.json")
    audit = read_json(archive, prefix + "P4P6_REVISED_DEV_PHYSICAL_AUDIT.json")
    case = read_json(archive, prefix + "P4P5_LOCKED_CASE.json")
    require(all(audit[x] == row[x] == case[x] for x in ("seed", "site", "load", "telemetry")),
            "LOCKED_CASE_AUDIT_PROVENANCE_DISAGREES")
    require(scenario["holdout_partition"] == "DEVELOPMENT" and
            scenario["independent_rng_block"] == seed and
            scenario["selected_face_slot"] == row["selected_slot"] and
            scenario["selected_face_id"] == 258 + row["selected_slot"] and
            scenario["technical_queue_max_packets"] == 12 and
            scenario["telemetry_enabled"] == (telemetry == "on_20ms"),
            "PROSPECTIVE_SCENARIO_PROVENANCE_CHANGED")
    assert_locks(audit, "AUDIT")
    assert_locks(scenario, "SCENARIO")
    decisions = list(iter_jsonl(archive, prefix + "events.jsonl.decisions.jsonl"))
    require(len(decisions) == audit["decisions"] == 108, "DECISION_COUNT_CHANGED")
    local = {}
    for item in iter_jsonl(archive, prefix + "nfd_local_queue_at_decision.jsonl"):
        if item["candidate_face_id"] == scenario["selected_face_id"]:
            require(item["decision_id"] not in local, "DUPLICATE_LOCAL_DECISION")
            require(item["observed_before_forwarding"] is True and
                    item["remote_node_queue_accessed"] is False and
                    item["future_pressure_label"] is None,
                    "LOCAL_QUEUE_NOT_DECISION_TIME_SAFE")
            local[item["decision_id"]] = item
    require(len(local) == 108, "INCOMPLETE_SELECTED_FACE_LOCAL_QUEUE")
    on = telemetry == "on_20ms"
    receipts = {}
    telemetry_decisions = {}
    names = set(archive.namelist())
    if on:
        for item in iter_jsonl(archive, prefix + "queue_telemetry_receipts.jsonl"):
            ref = (item["source_node_id"], item["report_id"])
            require(ref not in receipts, "DUPLICATE_RECEIVED_REPORT")
            receipts[ref] = item
        for item in iter_jsonl(archive, prefix + "queue_telemetry_decisions.jsonl"):
            require(item["decision_id"] not in telemetry_decisions,
                    "DUPLICATE_ONLINE_TELEMETRY_DECISION")
            telemetry_decisions[item["decision_id"]] = item
        require(len(telemetry_decisions) == 108, "INCOMPLETE_ONLINE_TELEMETRY")
        require(len(receipts) == audit["telemetry_transport"]["real_received"],
                "TELEMETRY_TRANSPORT_AUDIT_DISAGREES")
    else:
        require(prefix + "queue_telemetry_receipts.jsonl" not in names and
                prefix + "queue_telemetry_decisions.jsonl" not in names,
                "TELEMETRY_OFF_HAS_RECEIPTS")
    drops = audited_queue_drop_times(archive, prefix, scenario, audit)
    role_node = {role: int(scenario["selected_" + role + "_node_id"])
                 for role in ("relay", "mid", "producer")}
    positive = 0
    observed = 0
    missing = 0
    for decision in decisions:
        t = int(decision["time_ns"])
        id_ = decision["decision_id"]
        nearest = [candidate for candidate in decision["candidates"]
                   if candidate["routing_cost"] == 1]
        require(len(nearest) == 1 and nearest[0]["face_id"] == scenario["selected_face_id"],
                "SELECTED_FACE_NOT_REAL_FIB_NEXT_HOP")
        q = local[id_]
        require(q["sim_time_ns"] == t, "LOCAL_QUEUE_SAMPLE_NOT_AT_DECISION")
        evidence = {}
        missed = set()
        if on:
            td = telemetry_decisions[id_]
            require(td["decision_ns"] == t, "ONLINE_TELEMETRY_TIME_NOT_DECISION")
            for pointer in td["feature_evidence"]:
                src = int(pointer["source_node_id"])
                require(src not in evidence, "DUPLICATE_ROLE_REPORT")
                report = receipts.get((src, pointer["report_id"]))
                require(report is not None, "TELEMETRY_EVIDENCE_NOT_ACTUALLY_RECEIVED")
                evidence[src] = validated_receipt(report, t)
            missed = {int(entry["source_node_id"]) for entry in td["feature_missing_sources"]}
            require(set(evidence) | missed == set(role_node.values()) and
                    not (set(evidence) & missed), "TELEMETRY_ROLE_PARTITION_INCOMPLETE")
        predictors = {"fib_route_cost": 1,
                      "local_selected_queue_packets": q["queue_packets"],
                      "local_selected_queue_fraction": q["local_queue_occupancy_fraction"],
                      "local_selected_link_up": q["link_up"]}
        for role, source in role_node.items():
            rr = evidence.get(source)
            predictors[role + "_queue_packets"] = None if rr is None else rr["queue_packets_now"]
            predictors[role + "_queue_drops_observed_total"] = None if rr is None else rr["queue_drop_packets_total"]
            predictors[role + "_telemetry_age_ms"] = None if rr is None else (t - rr["sample_ns"]) / 1e6
            predictors[role + "_telemetry_missing"] = rr is None
            observed += int(rr is not None)
            missing += int(rr is None)
        row_key = ":".join(map(str, (*key, id_)))
        require(row_key not in seen, "DUPLICATE_EPISODE_KEY")
        seen.add(row_key)
        metadata = dict(row_key=row_key, seed=seed, site=site, load=load,
                        telemetry=telemetry, decision_id=id_, decision_ns=t,
                        pit_instance_id=decision["pit_instance_id"],
                        selected_face_id=scenario["selected_face_id"],
                        traffic_type=("target" if decision["name"].startswith("/hcraf/pilot/")
                                      else "competitor"))
        feature_stream.write(json.dumps({"metadata_NOT_A_PREDICTOR": metadata,
                                         "allowed_decision_time_features": predictors},
                                        sort_keys=True) + "\n")
        count = retrospective_label(drops, t)
        positive += int(count > 0)
        label_stream.write(json.dumps({"row_key": row_key,
                                       "DIAGNOSTIC_ONLY_not_official_F3": True,
                                       "retrospective_future_selected_path_QUEUE_DROP_75ms": int(count > 0),
                                       "retrospective_future_drop_event_count": count},
                                      sort_keys=True) + "\n")
    if on:
        require(observed == audit["telemetry_transport"]["observed_features"] and
                missing == audit["telemetry_transport"]["unavailable_features"],
                "CAUSAL_TELEMETRY_REFERENCE_AUDIT_MISMATCH")
    else:
        require(observed == 0 and missing == 324, "OFF_ARM_UNEXPECTED_REMOTE_FEATURE")
    return dict(seed=seed, site=site, load=load, telemetry=telemetry,
                physical_total_queue_drops=audited_queue_drop_times_count(audit),
                physical_selected_path_queue_drops=len(drops),
                physical_target_queue_drops=audit["physical"]["physical_drops_by_role"][ROLES[site]],
                physical_off_target_drops=len(drops) - audit["physical"]["physical_drops_by_role"][ROLES[site]],
                decisions=108, positive_75ms=positive, negative_75ms=108 - positive,
                causal_remote_features=observed, explicit_missing_remote_features=missing)


def audited_queue_drop_times_count(audit):
    return audit["physical"]["all_devices_physical_queue_drops"]


def run(parent_zip, destination):
    require(sha256_file(parent_zip) == PARENT_SHA256,
            "GITHUB_PARENT_ARTIFACT_SHA256_CHANGED")
    require(not destination.exists(), "REFUSE_TO_OVERWRITE_EXISTING_OUTPUT")
    destination.mkdir(parents=True, exist_ok=False)
    with zipfile.ZipFile(parent_zip) as archive:
        names = archive.namelist()
        require(len(names) == len(set(names)), "DUPLICATE_PARENT_ARTIFACT_MEMBERS")
        require(all(not n.startswith("/") and ".." not in Path(n).parts for n in names),
                "PARENT_ZIP_PATH_TRAVERSAL")
        summary = read_json(archive, ROOT + "P4P6_REVISED_DEVELOPMENT_SUMMARY.json")
        require(summary["status"] == "NO_GO_REVISED_DEV_FOUR_SEEDS_PHYSICAL_OR_CONTROL_FAILURE",
                "ORIGINAL_NO_GO_MUST_BE_PRESERVED")
        require(summary["high_target_drop_positive"] is True and
                summary["low_controls_have_zero_queue_drop"] is False and
                summary["causal_telemetry_pass"] is True,
                "V0529_REASON_FOR_NO_GO_HAS_CHANGED")
        require(summary["seeds"] == list(SEEDS) and summary["num_simulations"] == 48 and
                summary["previously_consumed_seed_23101_excluded"] is True and
                summary["validation_test_executable"] is False,
                "DEVELOPMENT_PARTITION_LOCK_CHANGED")
        assert_locks(summary, "ORIGINAL_SUMMARY")
        rows = summary["results"]
        require([tuple(row[name] for name in ("seed", "site", "load", "telemetry"))
                 for row in rows] == expected_keys(),
                "ORIGINAL_FORTY_EIGHT_EXHAUSTIVE_MATRIX_CHANGED")
        reports = []
        seen = set()
        with (destination / "DEV_FEATURES_ONLY_POSTHOC_v05210.jsonl").open("w") as feature_stream, \
             (destination / "DEV_DIAGNOSTIC_FUTURE_EVENTS_ONLY_POSTHOC_v05210.jsonl").open("w") as label_stream:
            for index, row in enumerate(rows, 1):
                report = process_condition(archive, row, feature_stream, label_stream, seen)
                reports.append(report)
                print("P4P7_RECONSTRUCTED", index, "/48", report["seed"],
                      report["site"], report["load"], report["telemetry"],
                      report["positive_75ms"], report["negative_75ms"], flush=True)
    high = [r for r in reports if r["load"] == "high_pressure"]
    low = [r for r in reports if r["load"] == "low_control"]
    require(len(seen) == 48 * 108 and len(high) == len(low) == 24,
            "EPISODE_OR_STRATUM_COUNT_CHANGED")
    require(sum(r["positive_75ms"] + r["negative_75ms"] for r in reports) == len(seen),
            "DIAGNOSTIC_LABEL_COVERAGE_CHANGED")
    require(all(0 < r["positive_75ms"] < 108 for r in high),
            "HIGH_PRESSURE_ONE_CLASS_REQUIRES_EXPLICIT_NO_GO")
    # This is a post-hoc, not a reversal of the v0.52.9 preregistered NO_GO.
    report = dict(status="PASS_POSTHOC_DEV_FORENSIC_RECONSTRUCTION_ONLY",
                  v0529_original_preregistered_status=summary["status"],
                  v0529_original_low_zero_control_gate_pass=False,
                  posthoc_amendment_after_parent_result_observed=True,
                  must_not_relabel_as_preregistered_success=True,
                  parent_run_id=PARENT_RUN, parent_artifact_id=PARENT_ARTIFACT,
                  parent_commit=PARENT_COMMIT, parent_artifact_sha256=PARENT_SHA256,
                  parent_v0529_source_sha256=SOURCE_SHA256,
                  num_simulations_reused=48, num_new_simulations=0,
                  independent_seed_blocks=4, seeds=list(SEEDS),
                  development_episodes_selected_face=len(seen),
                  total_diagnostic_positive_75ms=sum(r["positive_75ms"] for r in reports),
                  total_diagnostic_negative_75ms=sum(r["negative_75ms"] for r in reports),
                  high_pressure_positive_75ms=sum(r["positive_75ms"] for r in high),
                  high_pressure_negative_75ms=sum(r["negative_75ms"] for r in high),
                  low_control_positive_75ms=sum(r["positive_75ms"] for r in low),
                  low_control_negative_75ms=sum(r["negative_75ms"] for r in low),
                  high_pressure_strata_with_both_classes=sum(0 < r["positive_75ms"] < 108 for r in high),
                  low_load_conditions_with_unexpected_physical_drops=sum(r["physical_total_queue_drops"] > 0 for r in low),
                  high_load_conditions_with_off_target_physical_drops=sum(r["physical_off_target_drops"] > 0 for r in high),
                  per_condition_retains_all_48=True,
                  missingness_explicit_and_never_imputed_zero=True,
                  no_future_event_in_decision_features=True,
                  diagnostic_outcome_separate_file=True,
                  decision_overlap_makes_episodes_dependent=True,
                  design_and_load_metadata_not_predictors=True,
                  excluded_prior_pilot_seed_23101=True,
                  validation_seeds_consumed=0, heldout_seeds_consumed=0,
                  validation_test_executable=False,
                  official_F3_labels_constructed=0, F3_PR_AUC_computed=False,
                  training_executed=False, entering_stage1ao_authorized=False,
                  results=reports, **SCIENCE)
    (destination / "P4P7_POSTHOC_DEV_FORENSIC_AUDIT.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
    outputs = sorted(x for x in destination.iterdir() if x.is_file())
    (destination / "P4P7_OUTPUT_SHA256SUMS.txt").write_text(
        "".join(sha256_file(x) + "  " + x.name + "\n" for x in outputs))
    print("P4P7_DONE", json.dumps({k: v for k, v in report.items() if k != "results"},
                                   sort_keys=True), flush=True)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--parent-zip", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    run(arguments.parent_zip, arguments.output)


if __name__ == "__main__":
    main()
