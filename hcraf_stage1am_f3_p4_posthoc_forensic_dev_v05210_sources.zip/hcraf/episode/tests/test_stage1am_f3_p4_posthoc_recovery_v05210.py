#!/usr/bin/env python3
"""No simulator needed; verify strict causal and documentary fences."""
import unittest

from recover_stage1am_f3_p4_dev_evidence_v05210 import (
    SEEDS, SCIENCE, PARENT_RUN, PARENT_ARTIFACT, PARENT_COMMIT,
    PARENT_SHA256, expected_keys, retrospective_label,
    validated_receipt, assert_locks,
)


class TestPosthocRecovery(unittest.TestCase):
    def test_scope_is_exactly_four_development_seeds(self):
        self.assertEqual(SEEDS, (23201, 23202, 23203, 23204))
        self.assertEqual(len(expected_keys()), 48)
        self.assertEqual(len(set(expected_keys())), 48)
        self.assertNotIn(23101, SEEDS)
        self.assertFalse(set(SEEDS).intersection({24101, 24102, 24103, 24104,
                                                   25101, 25102, 25103, 25104}))

    def test_parent_is_immutable(self):
        self.assertEqual(PARENT_RUN, 44541671109)
        self.assertEqual(PARENT_ARTIFACT, 14543216459)
        self.assertEqual(PARENT_COMMIT, "8cda6ffe225e48ed584d448a7708fe0c685af078")
        self.assertEqual(PARENT_SHA256,
                         "ae7ce3870016be927f06e4c1d6ffc058f251f9075386b0a508bbd585e1b02f9a")

    def test_future_window_left_open_right_closed(self):
        t = 1_000_000_000
        self.assertEqual(retrospective_label([t, t + 1, t + 75_000_000,
                                               t + 75_000_001], t), 2)
        self.assertEqual(retrospective_label([t - 1, t, t + 75_000_001], t), 0)

    def test_received_before_decision_and_fresh(self):
        e = {"sample_ns": 900_000_000, "receipt_ns": 950_000_000}
        self.assertIs(validated_receipt(e, 1_000_000_000), e)
        with self.assertRaisesRegex(RuntimeError, "P4P7_FUTURE"):
            validated_receipt({"sample_ns": 999, "receipt_ns": 1001}, 1000)
        with self.assertRaisesRegex(RuntimeError, "P4P7_FUTURE"):
            validated_receipt({"sample_ns": 1001, "receipt_ns": 999}, 1000)
        with self.assertRaisesRegex(RuntimeError, "P4P7_EXPIRED"):
            validated_receipt({"sample_ns": 899_999_999, "receipt_ns": 900_000_000},
                              1_000_000_000)

    def test_science_locks_are_unbreakable(self):
        d = dict(SCIENCE, official_F3_labels_constructed=0)
        assert_locks(d, "TEST")
        for key in SCIENCE:
            broken = dict(d)
            broken[key] = "true"
            with self.assertRaises(RuntimeError):
                assert_locks(broken, "TEST")
        with self.assertRaises(RuntimeError):
            assert_locks(dict(d, official_F3_labels_constructed=1), "TEST")


if __name__ == "__main__":
    unittest.main()
