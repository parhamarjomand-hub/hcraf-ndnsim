import unittest,copy,tempfile
from pathlib import Path
import audit_stage1am_f3_p12r_construct_v05253 as a

def sample():
 rr=[(0,'INITIAL',None,0,0,None),(1,'QUEUE_ENQUEUE',1,1,10,None),(3,'QUEUE_DEQUEUE',1,0,0,2),(5,'FINAL',None,0,0,None)]
 def trace(m):
  return [{('timestamp_ns' if m else 'time_ns'):t,'event_type':e,'packet_uid':u,'queue_packets':q,'queue_bytes':b,'queue_wait_ns':w,('drop_packets_cumulative' if m else 'queue_drop_packets_total'):0} for t,e,u,q,b,w in rr]
 return trace(False),trace(True)
class Test(unittest.TestCase):
 def test_area(self):
  x,y=sample();m=a.metrics(x,y,5,2);self.assertEqual(m['mean_occupancy_fraction'],.2);self.assertEqual(m['mean_dequeue_wait_ms'],.000002)
 def test_mismatched_witness(self):
  x,y=sample();y[1]['packet_uid']=9
  with self.assertRaisesRegex(RuntimeError,'WITNESS_EVENT_MISMATCH'):a.metrics(x,y,5,2)
 def test_invalid_transition(self):
  x,y=sample();x[1]['queue_packets']=y[1]['queue_packets']=2
  with self.assertRaisesRegex(RuntimeError,'QUEUE_TRANSITION'):a.metrics(x,y,5,2)
 def test_bad_wait(self):
  x,y=sample();x[2]['queue_wait_ns']=y[2]['queue_wait_ns']=None
  with self.assertRaisesRegex(RuntimeError,'WAIT_MISSING'):a.metrics(x,y,5,2)
 def test_counter(self):
  x,y=sample();y[-1]['drop_packets_cumulative']=1
  with self.assertRaisesRegex(RuntimeError,'DROP_COUNTER'):a.metrics(x,y,5,2)
 def test_capacity(self):
  x,y=sample()
  with self.assertRaisesRegex(RuntimeError,'CAPACITY'):a.metrics(x,y,5,0)
 def test_overwrite(self):
  with tempfile.TemporaryDirectory() as d:
   with self.assertRaisesRegex(RuntimeError,'REFUSE_OVERWRITE'):a.audit(None,None,None,Path(d))
 def test_lock(self):
  self.assertTrue(all(v is False or v is None for v in a.LOCKS.values()));self.assertIn('NOT_VALIDATED',a.STATUS)
if __name__=='__main__':unittest.main()
