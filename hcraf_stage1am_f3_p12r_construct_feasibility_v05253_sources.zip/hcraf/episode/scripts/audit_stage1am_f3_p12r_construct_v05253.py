#!/usr/bin/env python3
"""DEV physical feasibility audit, not a new label, fit or statistical test."""
import argparse,csv,hashlib,io,json,zipfile
from pathlib import Path
DEV_SHA='c5e63aa1de79774088adeba73b914e0e45574694974e55d81fb0363ec1375577'
DIAG_SHA='916a2f346b042052225bf433f83a87a7a5e2a27099984d54416ab8e2b1e45fa1'
PREREG_SHA='dbb12863ca83c26b687b243211aaf698986b8d6f2f7b8656cffb06278751ae30'
NO_GO='NO_GO_P12R_CONFIRMATORY_STATISTICAL_GATES_NOT_MET'
STATUS='PASS_P12R_CONSTRUCT_FEASIBILITY_AUDIT_ONLY_CONSTRUCT_NOT_VALIDATED'
LOCKS=dict(F3_ready=False,GO_FREEZE=False,training_ready=False,Congestion=None,FutureCongestion=None,heldout_release_authorized=False,Stage1AO_or_NSGAIII_authorized=False)
EVENTS={'QUEUE_ENQUEUE','QUEUE_DEQUEUE','QUEUE_DROP'}
def need(ok,msg):
 if not ok:raise RuntimeError('P12R53_'+msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def digest(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def checked_zip(p,h):
 need(digest(p)==h,'ARCHIVE_SHA');z=zipfile.ZipFile(p);need(len(z.namelist())==len(set(z.namelist())),'DUPLICATE_MEMBER');return z
def trace(b,nodes,monitor):
 out={n:[] for n in nodes};snap={};markers=[('"node_id":%d,"device_index":0'%n).encode() for n in nodes];ev=[('"event_type":"%s"'%e).encode() for e in EVENTS|{'INITIAL','FINAL','DECISION_SNAPSHOT'}]
 for l in b.splitlines():
  if not any(m in l for m in markers) or not any(e in l for e in ev):continue
  r=json.loads(l);n=r['node_id'];need(n in out and r['device_index']==0,'TRACE_SCOPE');e=r['event_type']
  if e=='DECISION_SNAPSHOT':
   need(not monitor and (r['decision_id'],n) not in snap,'SNAP_DUPLICATE');snap[r['decision_id'],n]=(r['time_ns'],r['queue_packets']);continue
  out[n].append(r)
 return out,snap
def metrics(a,b,stop,cap):
 def key(r,m):return (r['timestamp_ns' if m else 'time_ns'],r['event_type'],r['packet_uid'],r['queue_packets'],r['queue_bytes'],r['queue_wait_ns'] if r['event_type']=='QUEUE_DEQUEUE' else None)
 for stream,m in [(a,False),(b,True)]:
  need(stream and stream[0]['event_type']=='INITIAL' and stream[-1]['event_type']=='FINAL','TRACE_BOUNDS');ts=[key(r,m)[0] for r in stream];need(ts[0]==0 and ts[-1]==stop and all(x<=y for x,y in zip(ts,ts[1:])),'TRACE_TIMES');need(all(type(r['queue_packets']) is int and 0<=r['queue_packets']<=cap for r in stream),'CAPACITY')
 ae=[key(r,False) for r in a if r['event_type'] in EVENTS];be=[key(r,True) for r in b if r['event_type'] in EVENTS];need(ae==be,'WITNESS_EVENT_MISMATCH')
 q=last=area=peak=drops=0;wait=[]
 for t,e,uid,n,bytes_,w in ae:
  area+=q*(t-last);last=t;need(n==q+{'QUEUE_ENQUEUE':1,'QUEUE_DEQUEUE':-1,'QUEUE_DROP':0}[e],'QUEUE_TRANSITION')
  if e=='QUEUE_DEQUEUE':need(type(w) is int and w>=0,'WAIT_MISSING');wait.append(w)
  if e=='QUEUE_DROP':need(q==cap,'DROP_WITHOUT_FULL_QUEUE');drops+=1
  peak=max(peak,n);q=n
 area+=q*(stop-last);need(q==a[-1]['queue_packets']==b[-1]['queue_packets']==0,'UNDRAINED_QUEUE');need(drops==a[-1]['queue_drop_packets_total']==b[-1]['drop_packets_cumulative'],'DROP_COUNTER')
 return dict(queue_events=len(ae),mean_occupancy_fraction=area/(stop*cap),peak_packets=peak,mean_dequeue_wait_ms=sum(wait)/len(wait)/1e6 if wait else 0.,dequeued=len(wait),drops=drops)
def write_csv(p,rr):
 with p.open('w',newline='',encoding='utf8') as f:
  w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
def audit(dev,diag,prereg,out):
 need(not out.exists(),'REFUSE_OVERWRITE')
 with checked_zip(prereg,PREREG_SHA) as pz,checked_zip(diag,DIAG_SHA) as dz,checked_zip(dev,DEV_SHA) as z:
  p='p12r_exploratory/';sums=dz.read(p+'P12R_OUTPUT_SHA256SUMS.txt').decode().splitlines();need(len(sums)==6,'PARENT_SUMS')
  for line in sums:
   h,n=line.split('  ',1);need('/' not in n and sha(dz.read(p+n))==h,'DIAG_MEMBER_SHA')
  d=json.loads(dz.read(p+'P12R_EXPLORATORY_REPORT_v05252.json'));need(d['status']=='PASS_P12R_POSTCONFIRM_EXPLORATORY_DIAGNOSTICS_ONLY_NO_F3_RELEASE' and d['parent_scientific_status']==NO_GO and all(d[k] is v for k,v in LOCKS.items()),'PRIOR_STATUS')
  n=next(n for n in pz.namelist() if n.endswith('/P12R_LOCKED_MATRIX_504_v05237.csv'));rr=list(csv.DictReader(io.StringIO(pz.read(n).decode())));m=[r for r in rr if r['partition']=='FAIR_LOCAL_DEV'];need(len(rr)==504 and len(m)==72 and {int(r['seed']) for r in m}==set(range(24901,24907)),'DEV_MATRIX');base='stage1am_f3_p12r_v05246/'
  def prefix(r):return base+r['seed']+'/'+r['site']+'_'+r['load']+'_'+r['telemetry']+'/'
  need({n for n in z.namelist() if n.endswith('/case_receipt.json')}=={prefix(r)+'case_receipt.json' for r in m},'CASE_SET');result=[]
  for r in m:
   pr=prefix(r);rc=json.loads(z.read(pr+'case_receipt.json'));need(rc['case']==r and rc['decisions']==128,'CASE_RECEIPT')
   def get(n):
    b=z.read(pr+n);need(sha(b)==rc['raw_file_sha256'][n],'RAW_SHA:'+n);return b
   sc=json.loads(get('scenario.json'));need(sc['research_partition']=='FAIR_LOCAL_DEV' and sc['independent_rng_block']==int(r['seed']) and sc['loss_probability']==0 and sc['loss_kind']=='NONE' and sc['actual_assignment_probability']==1 and sc['queue_capacity_packets']==12 and sc['stop_ns']==20000000000,'SCENARIO_CONTRACT');need(not get('fault_events.jsonl').strip(),'FAULT_PRESENT');nodes=sc['path_nodes'][1:];need(len(nodes)==4 and nodes[0]==1 and len(set(nodes))==4,'PATH')
   target={'producer_egress':sc['selected_producer_node_id'],'transit_middle':sc['selected_mid_node_id'],'consumer_ingress':sc['selected_relay_node_id']}[r['site']];need(target in nodes,'TARGET');a,snap=trace(get('link_events.jsonl'),nodes,False);b,_=trace(get('pathwide_witness_b.jsonl'),nodes,True);met={n:metrics(a[n],b[n],sc['stop_ns'],12) for n in nodes};need({x['data_rate_bps'] for x in a[target]}=={12000000},'INTERVENTION_RATE')
   v=[json.loads(l) for l in get('p12v_native_local_12_at_decision.jsonl').splitlines() if l.strip()];need(len(v)==128 and len(snap)==512 and len({x['decision_id'] for x in v})==128,'DECISION_COUNT');pn=ln=both=0
   for x in v:
    i=x['decision_id'];need(x['node_id']==1 and x['selected_face_id']==sc['selected_face_id'] and len(x['b1_all_twelve_native'])==12,'LOCAL_SCOPE');ss=[snap[i,n] for n in nodes];need(all(t==x['time_ns'] and 0<=q<=12 for t,q in ss),'SNAP_TIME');p0=max(q for t,q in ss)>0;l0=x['b1_all_twelve_native'][1]>0;pn+=p0;ln+=l0;both+=p0 and not l0
   result.append(dict(seed=int(r['seed']),site=r['site'],load=r['load'],telemetry=r['telemetry'],selected_slot=int(r['selected_slot']),intervention_node=target,**met[target],path_queue_events=sum(x['queue_events'] for x in met.values()),path_drops=sum(x['drops'] for x in met.values()),decisions=128,path_nonzero_at_decision=pn,local_selected_nonzero_at_decision=ln,path_nonzero_local_empty_at_decision=both));print('PASS_DEV_CONSTRUCT_CASE',r['seed'],r['site'],r['load'],r['telemetry'],flush=True)
 groups={}
 for r in result:groups.setdefault((r['seed'],r['site'],r['telemetry']),{})[r['load']]=r
 need(len(groups)==36 and all(set(g)=={'low_control','high_pressure'} for g in groups.values()),'PAIR_SET');pairs=[];keys=('mean_occupancy_fraction','mean_dequeue_wait_ms','drops','peak_packets')
 for (seed,site,telemetry),g in sorted(groups.items()):
  hi,lo=g['high_pressure'],g['low_control'];need(hi['selected_slot']==lo['selected_slot'] and hi['intervention_node']==lo['intervention_node'],'PAIR_SCOPE');pairs.append(dict(seed=seed,site=site,telemetry=telemetry,**{k:hi[k]-lo[k] for k in keys}))
 summary={}
 for arm in ('off','on_20ms'):
  q=[r for r in pairs if r['telemetry']==arm];need(len(q)==18,'ARM_PAIR_COUNT');summary[arm]={k:{'positive':sum(r[k]>0 for r in q),'equal':sum(r[k]==0 for r in q),'negative':sum(r[k]<0 for r in q),'mean_difference':sum(r[k] for r in q)/len(q)} for k in keys}
 report=dict(status=STATUS,parent_scientific_status=NO_GO,**LOCKS,development_cases=72,decisions_audited=9216,raw_members_checked=360,matched_path_queue_events=sum(r['path_queue_events'] for r in result),matched_path_drops=sum(r['path_drops'] for r in result),paired_load_contrasts=36,load_contrasts=summary,path_nonzero_at_decision=sum(r['path_nonzero_at_decision'] for r in result),local_selected_nonzero_at_decision=sum(r['local_selected_nonzero_at_decision'] for r in result),path_nonzero_local_empty_at_decision=sum(r['path_nonzero_local_empty_at_decision'] for r in result),construct_validated=False,discriminant_validity_established=False,selected_face_counterfactual_available=False,physical_loss_control_available=False,new_candidate_defined=False,new_candidate_scores=0,model_fits=0,confirmation_rows_read=0,heldout_rows_read=0,diagnostic_injection_rows_used=0,new_simulations=0,new_AP_computed=False,new_bootstrap_computed=False,official_F3_labels_constructed=0,independent_new_validation_required=True,scope='DEV only, device0 return path; prior exploratory aggregate receipt only',limitations=['Two software witnesses share the same simulation.','Wait measures dequeued link packets, not NDN Data RTT; excludes dropped packets.','Occupancy averages the full fixed 20 s including idle time.','High and low schedules differ; contrasts descriptive, not isolated causal load effects.','No random loss or delay-only control, no counterfactual unselected face, no validated episode label.','New preregistered independent study required.'])
 out.mkdir(parents=True);write_csv(out/'dev_physical_cases.csv',result);write_csv(out/'paired_load_contrasts.csv',pairs);(out/'P12R_CONSTRUCT_FEASIBILITY_RECEIPT_v05253.json').write_text(json.dumps(report,sort_keys=True,indent=2,allow_nan=False)+'\n');(out/'SHA256SUMS.txt').write_text(''.join(f'{digest(x)}  {x.name}\n' for x in sorted(out.iterdir())));print(STATUS,flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();[p.add_argument('--'+x,required=True,type=Path) for x in ('dev','diag','prereg','output')];a=p.parse_args();audit(a.dev,a.diag,a.prereg,a.output)
