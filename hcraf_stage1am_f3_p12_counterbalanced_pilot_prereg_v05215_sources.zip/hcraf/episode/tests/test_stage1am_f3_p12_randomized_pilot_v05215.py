#!/usr/bin/env python3
"""Pure preregistration tests: 0 simulations, no heldout, full SHA replay."""
import csv
from hashlib import sha256
import io
import json
import unittest

from generate_stage1am_f3_p12_randomized_pilot_v05215 import (
    VERSION,PARTITION,SEEDS,SITES,LOADS,TELEMETRIES,CSV_HEADER,
    DOC,PLANS,MATRIX,COMMITMENTS,allocation,cells,events,filename,
    rows,render_schedule,render_matrix,commitments,
)

LOCKS={'Congestion':None,'FutureCongestion':None,'F3_ready':False,
       'GO_FREEZE':False,'training_ready':False,
       'heldout_release_authorized':False}


class P12ACounterbalancedTimePilotTests(unittest.TestCase):
    def test_parent_p11_local_artifact_is_original_no_go(self):
        evidence=DOC/'P4P11_DEV_TIME_CONDITIONED_DIAGNOSTIC_REPORT_v05214.json'
        self.assertEqual(sha256(evidence.read_bytes()).hexdigest(),
                         'a984085bfae01a69d673908f635d86d41e25cb7b1b9e80a837cdda1d090b71aa')
        p=json.loads(evidence.read_text())
        self.assertEqual(p['parent_github_run'],44591102013)
        self.assertEqual(p['parent_artifact_id'],14565749815)
        self.assertEqual(p['status'],'NO_GO_INDEPENDENT_PREDICTIVE_VALUE_NOT_DEMONSTRATED')
        self.assertLess(p['mean_seed_block_AP_difference_vs_time_envelope']['observed_mean'],0)
        self.assertEqual(p['validation_seeds_consumed'],0)
        self.assertEqual(p['heldout_seeds_consumed'],0)
        for k,v in LOCKS.items():self.assertIs(p[k],v)

    def test_only_six_pilot_cells_and_latin_phase_times(self):
        self.assertEqual(SEEDS,(23401,23402))
        self.assertEqual(len(cells()),6)
        a=allocation();self.assertEqual(set(a),set(cells()))
        self.assertEqual(len(set(v['phase_A_anchor_ns']//100_000_000 for v in a.values())),6)
        self.assertEqual(len(set(v['phase_B_anchor_ns']//100_000_000 for v in a.values())),6)
        self.assertEqual({(seed,site,a[(seed,site)]['selected_slot']) for seed,site in cells()},
                         {(23401,'producer_egress',0),(23401,'transit_middle',1),
                          (23401,'consumer_ingress',2),(23402,'producer_egress',1),
                          (23402,'transit_middle',2),(23402,'consumer_ingress',0)})
        self.assertEqual(set(SEEDS)&(set(range(23301,23309))|
                         set(range(24301,24309))|set(range(25301,25309))),set())

    def test_frozen_only_twelve_pilot_csvs_all_sha(self):
        expected=set()
        for seed,site in cells():
            low=events(seed,site,'low_control')
            high=events(seed,site,'high_pressure')
            self.assertEqual(len(low),len(high))
            self.assertEqual({r['sequence']:r['time_ns'] for r in low
                              if r['traffic_class']=='TARGET'},
                             {r['sequence']:r['time_ns'] for r in high
                              if r['traffic_class']=='TARGET'})
            for load,ev in [('low_control',low),('high_pressure',high)]:
                name=filename(seed,site,load)
                expected.add(name)
                self.assertEqual((PLANS/name).read_bytes(),render_schedule(seed,site,load))
                with io.StringIO((PLANS/name).read_text()) as f:
                    lines=list(csv.DictReader(f))
                self.assertEqual(len(lines),108)
                self.assertEqual(set(lines[0]),set(CSV_HEADER))
                self.assertEqual({r['split'] for r in lines},{PARTITION})
                self.assertEqual(sum(r['traffic_class']=='INDEPENDENT_COMPETITOR'
                                     for r in lines),96)
                self.assertEqual(sum(r['traffic_class']=='TARGET' for r in lines),12)
                self.assertFalse(any('QUEUE_DROP' in r or 'future' in r for r in lines[0]))
                if load=='high_pressure':
                    c=[r for r in ev if r['traffic_class']=='INDEPENDENT_COMPETITOR']
                    self.assertEqual(len([r for r in c if r['sequence']<48]),48)
                    self.assertEqual(len([r for r in c if r['sequence']>=48]),48)
        self.assertEqual({p.name for p in PLANS.glob('*.csv')},expected)

    def test_matrix_and_commitments_are_immutable(self):
        self.assertEqual(MATRIX.read_bytes(),render_matrix())
        p=json.loads(COMMITMENTS.read_text())
        self.assertEqual(p,commitments())
        self.assertEqual(sha256(MATRIX.read_bytes()).hexdigest(),p['matrix_SHA256'])
        self.assertEqual(len(p['per_schedule_SHA256']),12)
        for name,digest in p['per_schedule_SHA256'].items():
            self.assertEqual(sha256((PLANS/name).read_bytes()).hexdigest(),digest)
        r=rows()
        self.assertEqual(len(r),24)
        self.assertEqual(len({(x['seed'],x['site'],x['load'],x['telemetry']) for x in r}),24)
        self.assertEqual({x['eligible_to_execute_in_P12A'] for x in r},{'false'})
        self.assertEqual({x['validation_or_heldout'] for x in r},{'false'})
        self.assertEqual({x['candidate_queue_capacity_packets'] for x in r},{12})
        self.assertEqual(p['executed_simulations'],0)
        self.assertFalse(p['pilot_exec_authorized_now'])
        self.assertEqual(p['validation_or_heldout_schedules_emitted'],0)
        for k,v in LOCKS.items():self.assertIs(p[k],v)


if __name__=='__main__':unittest.main()
