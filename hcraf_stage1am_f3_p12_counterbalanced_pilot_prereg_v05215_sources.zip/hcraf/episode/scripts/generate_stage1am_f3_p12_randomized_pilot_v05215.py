#!/usr/bin/env python3
"""P12-A: deterministic, time-counterbalanced PILOT-ONLY schedule commitments.

No simulator execution. All seeds are consumed only by the *future* P12-B
technical pilot and will be excluded from every official data partition.
"""
import csv
from hashlib import sha256
import io
import json
from pathlib import Path
import random


VERSION='HCRAF-STAGE1AM-F3-P12-v0.52.15-RANDOMIZED-PILOT-ONLY'
SCHEMA='HCRAF_F3_P12_TIME_COUNTERBALANCED_PILOT_V05215'
FAMILY='P12_RANDOMIZED_PRESSURE_PILOT_ONLY'
PARTITION='PILOT_EXCLUDED'
SEEDS=(23401,23402)
SITES=('producer_egress','transit_middle','consumer_ingress')
SITE_ARMS={
    'producer_egress':('PRODUCER_RETURN_12M','PRODUCER_RETURN','producer'),
    'transit_middle':('MID_RETURN_12M','MID_RETURN','mid'),
    'consumer_ingress':('RELAY_RETURN_12M','RELAY_RETURN','relay'),
}
LOADS=('low_control','high_pressure')
TELEMETRIES=('off','on_20ms')
CSV_HEADER=('traffic_class','sequence','time_ns','family','rng_block',
            'split','phase_label','phase_nominal_ns','phase_jitter_ns',
            'selected_slot','load_level','schedule_schema')
MATRIX_HEADER=('seed','site','selected_slot','temporal_anchor_A_ns',
               'temporal_anchor_B_ns','arm','location','target_role','load',
               'telemetry','schedule_filename','schedule_sha256',
               'candidate_queue_capacity_packets','scientific_partition',
               'eligible_to_execute_in_P12A','validation_or_heldout')

ROOT=Path(__file__).resolve().parents[3]
DOC=ROOT/'hcraf/episode/docs/1AM/F3_P12_TIME_COUNTERBALANCED_PILOT_v0.52.15'
PLANS=DOC/'plans'
MATRIX=DOC/'P12A_PILOT_LOCKED_MATRIX_24_v05215.csv'
COMMITMENTS=DOC/'P12A_PILOT_SCHEDULE_COMMITMENTS_12_v05215.json'


def check(ok,why):
    if not ok:raise AssertionError('P12A_'+why)


def stream_seed(label):
    number=int.from_bytes(sha256((VERSION+':'+label).encode()).digest()[:8],'big')
    return number or 1


def cells():
    return tuple((seed,site) for seed in SEEDS for site in SITES)


def allocation():
    """Blocked Latin allocation of 6 distinct A/B pressure-onset anchors."""
    keys=cells()
    phase_a=[2_180_000_000+200_000_000*i for i in range(6)]
    phase_b=[4_350_000_000+240_000_000*i for i in range(6)]
    random.Random(stream_seed('PHASE_A_LATIN_SHUFFLE')).shuffle(phase_a)
    random.Random(stream_seed('PHASE_B_INDEPENDENT_LATIN_SHUFFLE')).shuffle(phase_b)
    out={}
    for i,(seed,site) in enumerate(keys):
        site_index=SITES.index(site)
        slot=(site_index+SEEDS.index(seed))%3
        seed_site=f'{seed}:{site}'
        jitter_a=random.Random(stream_seed(seed_site+':anchor_A_jitter')).randint(-9_000_000,9_000_000)
        jitter_b=random.Random(stream_seed(seed_site+':anchor_B_jitter')).randint(-9_000_000,9_000_000)
        out[(seed,site)]={'selected_slot':slot,
                         'phase_A_anchor_ns':phase_a[i]+jitter_a,
                         'phase_B_anchor_ns':phase_b[i]+jitter_b,
                         'traffic_stream_seed':stream_seed(seed_site+':traffic')&0x7fffffff,
                         'routing_stream_seed':stream_seed(seed_site+':routing')&0x7fffffff,
                         'telemetry_stream_seed':stream_seed(seed_site+':telemetry')&0x7fffffff}
    check(len(out)==6,'SIX_INDEPENDENT_PILOT_CELLS')
    check(len({v['phase_A_anchor_ns']//100_000_000 for v in out.values()})==6,
          'PHASE_A_TIME_COUNTERBALANCE_CHANGED')
    check(len({v['phase_B_anchor_ns']//100_000_000 for v in out.values()})==6,
          'PHASE_B_TIME_COUNTERBALANCE_CHANGED')
    check(all(v['phase_B_anchor_ns']>v['phase_A_anchor_ns']+1_000_000_000
              for v in out.values()),'PULSES_NOT_DISTINCT')
    return out


def filename(seed,site,load):
    a=allocation()[(seed,site)]
    return f'p12-v05215-pilot-seed-{seed}-{site}-slot-{a["selected_slot"]}-{load}.csv'


def events(seed,site,load):
    check(seed in SEEDS and site in SITES and load in LOADS,'INVALID_PILOT_ONLY_CASE')
    a=allocation()[(seed,site)]
    seed_site=f'{seed}:{site}'
    target_rng=random.Random(stream_seed(seed_site+':TARGET_JITTER_SHARED_ACROSS_LOADS'))
    comp_rng=random.Random(stream_seed(seed_site+':COMP_JITTER:'+load))
    out=[]
    for sequence in range(12):
        nominal=2_260_000_000+sequence*330_000_000
        jitter=target_rng.randint(-280_000,280_000)
        out.append(dict(traffic_class='TARGET',sequence=sequence,
                        time_ns=nominal+jitter,family=FAMILY,rng_block=seed,
                        split=PARTITION,phase_label='P'+str(sequence//3),
                        phase_nominal_ns=nominal,phase_jitter_ns=jitter,
                        selected_slot=a['selected_slot'],load_level=load,
                        schedule_schema=SCHEMA))
    for sequence in range(96):
        if load=='low_control':
            nominal=2_170_000_000+sequence*163_000_000
        else:
            anchor=a['phase_A_anchor_ns'] if sequence<48 else a['phase_B_anchor_ns']
            nominal=anchor+(sequence%48)*3_600_000
        jitter=comp_rng.randint(-180_000,180_000)
        out.append(dict(traffic_class='INDEPENDENT_COMPETITOR',sequence=sequence,
                        time_ns=nominal+jitter,family=FAMILY,rng_block=seed,
                        split=PARTITION,phase_label='P'+str(sequence//24),
                        phase_nominal_ns=nominal,phase_jitter_ns=jitter,
                        selected_slot=a['selected_slot'],load_level=load,
                        schedule_schema=SCHEMA))
    out.sort(key=lambda r:(r['time_ns'],r['traffic_class'],r['sequence']))
    check(len(out)==108 and len({(r['traffic_class'],r['sequence']) for r in out})==108,
          'MISSING_OR_DUPLICATED_INTEREST')
    check(all(2_000_000_000<r['time_ns']<19_000_000_000 for r in out),
          'INTEREST_OUTSIDE_FROZEN_20S_SIMULATION')
    return out


def render_schedule(seed,site,load):
    buf=io.StringIO(newline='')
    writer=csv.DictWriter(buf,fieldnames=CSV_HEADER,lineterminator='\n')
    writer.writeheader();writer.writerows(events(seed,site,load))
    return buf.getvalue().encode()


def rows():
    alloc=allocation()
    out=[]
    for seed,site in cells():
        a=alloc[(seed,site)]
        arm,location,role=SITE_ARMS[site]
        for load in LOADS:
            name=filename(seed,site,load)
            digest=sha256(render_schedule(seed,site,load)).hexdigest()
            for telemetry in TELEMETRIES:
                out.append(dict(seed=seed,site=site,selected_slot=a['selected_slot'],
                  temporal_anchor_A_ns=a['phase_A_anchor_ns'],
                  temporal_anchor_B_ns=a['phase_B_anchor_ns'],arm=arm,
                  location=location,target_role=role,load=load,telemetry=telemetry,
                  schedule_filename=name,schedule_sha256=digest,
                  candidate_queue_capacity_packets=12,
                  scientific_partition=PARTITION,
                  eligible_to_execute_in_P12A='false',validation_or_heldout='false'))
    check(len(out)==24 and len({(x['seed'],x['site'],x['load'],x['telemetry'])
                                 for x in out})==24,'NOT_EXACTLY_24_FUTURE_PILOT_CASES')
    return out


def render_matrix():
    b=io.StringIO(newline='')
    w=csv.DictWriter(b,fieldnames=MATRIX_HEADER,lineterminator='\n')
    w.writeheader();w.writerows(rows())
    return b.getvalue().encode()


def commitments():
    s={filename(seed,site,load):sha256(render_schedule(seed,site,load)).hexdigest()
       for seed,site in cells() for load in LOADS}
    check(len(s)==12,'TWELVE_SHA_LOCKS_REQUIRED')
    return dict(stage='v0.52.15_P12_A_COUNTERBALANCED_PRESSURE_PILOT_PREREG_ONLY',
                parent_p10_run=44591102013,
                parent_p10_commit='6bddc98b89cf47d7fca0eccc877916efe0e351a5',
                parent_p10_artifact_id=14565749815,
                parent_p10_artifact_sha256='45bfb6c2e65277d8aa00c480f2b5be789445c7d1c68670740cb049db935aa45c',
                p11_local_development_diagnostic_no_go=True,
                p11_report_sha256='a984085bfae01a69d673908f635d86d41e25cb7b1b9e80a837cdda1d090b71aa',
                p11_report_origin='LOCAL_RECALCULATION_OF_SHA_VERIFIED_P10_GITHUB_ARTIFACT',
                pilot_only_seed_blocks=list(SEEDS),pilot_cells=6,pilot_conditions_planned=24,
                emitted_pilot_csvs=12,proposed_simulations=24,executed_simulations=0,
                pilot_exec_authorized_now=False,
                all_pilot_seeds_excluded_from_formal_F3_sets=True,
                validation_or_heldout_schedules_emitted=0,
                official_F3_labels_constructed=0,F3_PR_AUC_computed=False,
                original_v0520_v0524_v0529_v05212_v05213_unchanged=True,
                temporal_start_assignment='BLOCKED_6_CELL_LATIN_TWO_INDEPENDENT_PERMUTATIONS',
                matrix_SHA256=sha256(render_matrix()).hexdigest(),
                per_schedule_SHA256=s,
                Congestion=None,FutureCongestion=None,F3_ready=False,GO_FREEZE=False,
                training_ready=False,heldout_release_authorized=False)


def main():
    DOC.mkdir(parents=True,exist_ok=True)
    PLANS.mkdir(parents=True,exist_ok=True)
    for seed,site in cells():
        for load in LOADS:
            path=PLANS/filename(seed,site,load)
            blob=render_schedule(seed,site,load)
            if path.exists():check(path.read_bytes()==blob,'REFUSE_REPLACE_EXISTING_PILOT_SCHEDULE')
            else:path.write_bytes(blob)
    m=render_matrix()
    if MATRIX.exists():check(MATRIX.read_bytes()==m,'REFUSE_REPLACE_PILOT_MATRIX')
    else:MATRIX.write_bytes(m)
    c=(json.dumps(commitments(),sort_keys=True,indent=2)+'\n').encode()
    if COMMITMENTS.exists():check(COMMITMENTS.read_bytes()==c,'REFUSE_REPLACE_PILOT_COMMITMENTS')
    else:COMMITMENTS.write_bytes(c)
    print('PASS_P12A_TWELVE_IMMUTABLE_PILOT_SCHEDULES_AND_24_LOCKED_MATRIX_ROWS')


if __name__=='__main__':main()
