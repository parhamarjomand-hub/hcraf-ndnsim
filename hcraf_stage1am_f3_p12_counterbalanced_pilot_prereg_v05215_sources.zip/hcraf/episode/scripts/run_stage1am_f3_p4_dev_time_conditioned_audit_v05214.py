#!/usr/bin/env python3
"""P11: frozen development-only, no-fit temporal-confounding diagnostic.

Read only the authenticated P10 GitHub artifact. This is NOT a trained model,
official F3 PR-AUC, validation, heldout access, or proof of prediction.
"""
import argparse
from collections import defaultdict
from hashlib import sha256
import json
from pathlib import Path
import random
import zipfile


P10_RUN=44591102013
P10_ARTIFACT_ID=14565749815
P10_SHA='45bfb6c2e65277d8aa00c480f2b5be789445c7d1c68670740cb049db935aa45c'
P10_COMMIT='6bddc98b89cf47d7fca0eccc877916efe0e351a5'
PREFIX='stage1am_f3_p4_temporal_dev_v05213/'
SEEDS=tuple(range(23301,23309))
SITES=('producer_egress','transit_middle','consumer_ingress')
REGIME={23308:'EARLY',23307:'EARLY',23303:'LATE',23305:'LATE',
        23302:'DOUBLE',23306:'DOUBLE',23304:'THREE_PULSE',23301:'THREE_PULSE'}
LOCKS={'Congestion':None,'FutureCongestion':None,'F3_ready':False,
       'GO_FREEZE':False,'training_ready':False,
       'heldout_release_authorized':False}
TIME_CENTERS_NS=(2_320_000_000,2_520_000_000,2_750_000_000)
TIME_BIN_NS=100_000_000
BOOTSTRAP=5000


def require(ok,reason):
    if not ok:raise RuntimeError('P4P11_'+reason)


def file_sha256(path):
    h=sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(1<<20),b''):h.update(chunk)
    return h.hexdigest()


def read_records(z,name):
    return [json.loads(line) for line in z.read(PREFIX+name).splitlines() if line.strip()]


def ap_with_ties(records):
    """Non-interpolated average precision grouped by EXACT tied score."""
    positives=sum(int(y) for _,y in records)
    require(0<positives<len(records),'NO_BOTH_LABEL_CLASSES_IN_CASE')
    groups=defaultdict(lambda:[0,0])
    for score,label in records:
        require(isinstance(score,(int,float)) and label in (0,1),
                'INVALID_SCORE_OR_LABEL')
        # In each group slot 0 is positive, slot 1 is negative.
        groups[score][0 if label==1 else 1]+=1
    num_pos=total=0
    weighted=0.0
    for score in sorted(groups,reverse=True):
        positive,negative=groups[score]
        num_pos+=positive;total+=positive+negative
        weighted+=(positive/positives)*(num_pos/total)
    require(num_pos==positives,'AP_POSITIVE_TOTAL_INCONSISTENT')
    return weighted


def time_scores(ns):
    return {'ascending':float(ns),'descending':float(-ns),
            'center_2320':float(-abs(ns-TIME_CENTERS_NS[0])),
            'center_2520':float(-abs(ns-TIME_CENTERS_NS[1])),
            'center_2750':float(-abs(ns-TIME_CENTERS_NS[2]))}


def matched_same_time_bin(rows):
    """Within-one-case concordance; no future information in score."""
    bins=defaultdict(lambda:{0:[],1:[]})
    for ns,q,label in rows:bins[ns//TIME_BIN_NS][label].append(q)
    wins=ties=pairs=0
    for group in bins.values():
        for pos in group[1]:
            for neg in group[0]:
                pairs+=1
                wins+=int(pos>neg)
                ties+=int(pos==neg)
    return {'pairs':pairs,'wins':wins,'ties':ties,
            'concordance':(wins+ties/2)/pairs if pairs else None}


def bootstrap_ci(per_seed,allow_incomplete=False):
    require(set(per_seed).issubset(set(SEEDS)) and
            (allow_incomplete or set(per_seed)==set(SEEDS)) and len(per_seed)>=2,
            'BOOTSTRAP_INVALID_WHOLE_SEED_BLOCK_COVERAGE')
    values=[per_seed[x] for x in SEEDS if x in per_seed]
    n=len(values)
    rng=random.Random(52014)
    means=sorted(sum(values[rng.randrange(n)] for _ in range(n))/n
                 for _ in range(BOOTSTRAP))
    return {'observed_mean':sum(values)/n,
            'percentile_95':[means[int(.025*BOOTSTRAP)],
                             means[int(.975*BOOTSTRAP)-1]],
            'unit':'independent_DEVELOPMENT_seed_block',
            'eligible_seed_blocks':n,'full_eight_seed_coverage':n==8,
            'replicates':BOOTSTRAP,'seed':52014,
            'inferential_status':'descriptive_only_no_claim_of_independence'}


def load_and_verify(path):
    require(file_sha256(path)==P10_SHA,'WRONG_P10_GITHUB_ARTIFACT_SHA256')
    with zipfile.ZipFile(path) as z:
        require(z.testzip() is None,'OUTER_ARTIFACT_BAD_CRC')
        manifest={}
        for line in z.read(PREFIX+'P4P10_OUTPUT_SHA256SUMS.txt').decode().splitlines():
            digest,name=line.split('  ',1)
            require(sha256(z.read(PREFIX+name)).hexdigest()==digest,
                    'P10_DERIVED_SHA256_MISMATCH_'+name)
            manifest[name]=digest
        report=json.loads(z.read(PREFIX+'P4P10_TEMPORAL_DEVELOPMENT_SUMMARY.json'))
        require(report['status']=='PASS_P4P10_DEV_PHYSICAL_AND_ALL_HIGH_STRATA_CLASS_VARIATION'
                and report['num_development_simulations']==96
                and report['num_forwarding_episodes_selected_face']==10368
                and report['high_strata_with_both_classes']==48,
                'P10_PARENT_SCIENTIFIC_STAGE_NOT_PASSED')
        require(all(report[k] is v for k,v in LOCKS.items()),'P10_PARENT_SCIENCE_LOCK_BROKEN')
        archives=report['archived_raw_by_seed']
        require({r['seed'] for r in archives}==set(SEEDS) and len(archives)==8,
                'P10_RAW_SEED_ARCHIVES_MISSING')
        for row in archives:
            require(sha256(z.read(PREFIX+row['raw_archive_name'])).hexdigest()==
                    row['raw_archive_sha256'],'P10_RAW_SEED_DIGEST_MISMATCH')
        f=read_records(z,'DEV_FEATURES_ONLY_TEMPORAL_v05213.jsonl')
        l=read_records(z,'DEV_DIAGNOSTIC_FUTURE_EVENTS_ONLY_TEMPORAL_v05213.jsonl')
    require(len(f)==len(l)==10368,'P10_DIAGNOSTIC_STREAM_SIZE_CHANGED')
    labels={x['row_key']:x for x in l}
    require(len(labels)==len(l),'DUPLICATE_DIAGNOSTIC_LABEL_ROW_KEY')
    require(sum(x['retrospective_future_selected_path_QUEUE_DROP_75ms'] for x in l)==2692,
            'P10_DIAGNOSTIC_CLASS_COUNT_CHANGED')
    require(all(x['DIAGNOSTIC_ONLY_not_official_F3'] is True for x in l),
            'OFFICIAL_F3_LABEL_SNEAKED_IN')
    require(len({x['metadata_NOT_A_PREDICTOR']['row_key'] for x in f})==10368,
            'DUPLICATE_FEATURE_KEY')
    return report,f,labels


def analyze(archive_path):
    summary,features,labels=load_and_verify(archive_path)
    per_case=defaultdict(list)
    total_partial=0
    partial_keys=[]
    for record in features:
        metadata=record['metadata_NOT_A_PREDICTOR']
        predictors=record['allowed_decision_time_features']
        key=metadata['row_key']
        require(key in labels,'P10_FEATURE_WITHOUT_SEPARATE_DIAGNOSTIC')
        seed=metadata['seed'];site=metadata['site'];load=metadata['load'];arm=metadata['telemetry']
        require(seed in SEEDS and site in SITES and load in ('high_pressure','low_control') and
                arm in ('off','on_20ms'),'UNAUTHORIZED_STRATUM')
        require(not any('future' in k or 'retrospective' in k or 'label' in k
                        for k in predictors),'FUTURE_LABEL_IN_PREDICTORS')
        if load!='high_pressure' or arm!='on_20ms':continue
        values=[predictors[role+'_queue_packets'] for role in ('relay','mid','producer')]
        # A missing remote source is NOT imputed to an observed zero.
        available=[v for v in values if v is not None]
        require(available,'ALL_THREE_REMOTE_SOURCES_MISSING')
        complete=len(available)==3
        if not complete:
            total_partial+=1;partial_keys.append(key)
        require(all(isinstance(v,int) and v>=0 for v in available),
                'INVALID_REMOTE_QUEUE_PACKETS')
        require(all(predictors[role+'_telemetry_missing'] is (predictors[role+'_queue_packets'] is None)
                    for role in ('relay','mid','producer')),'INVALID_MISSINGNESS_ENCODING')
        decision_ns=metadata['decision_ns']
        require(isinstance(decision_ns,int) and 2_000_000_000<=decision_ns<20_000_000_000,
                'INVALID_DECISION_TIME')
        label=labels[key]['retrospective_future_selected_path_QUEUE_DROP_75ms']
        require(label in (0,1),'BAD_DIAGNOSTIC_LABEL')
        per_case[(seed,site)].append((decision_ns,max(available),label,complete))
    require(len(per_case)==24 and total_partial==1,
            'P10_MISSINGNESS_EXCEEDS_TRANSPARENT_P11_A_AMENDMENT')
    rows=[]
    complete_case_differences={}
    for (seed,site),case in sorted(per_case.items()):
        require(len(case)==108,'P11_REQUIRES_108_EPISODES_PER_PAIRED_CASE')
        label_counts={0:sum(1 for x in case if x[2]==0),
                      1:sum(1 for x in case if x[2]==1)}
        ap_queue=ap_with_ties([(q,y) for _,q,y,_ in case])
        times={name:ap_with_ties([(time_scores(t)[name],y) for t,_,y,_ in case])
               for name in ('ascending','descending','center_2320',
                            'center_2520','center_2750')}
        envelope=max(times.values())
        within=matched_same_time_bin([(t,q,y) for t,q,y,_ in case])
        complete_case=[(t,q,y) for t,q,y,complete in case if complete]
        cc_queue=ap_with_ties([(q,y) for _,q,y in complete_case])
        cc_time=max(ap_with_ties([(time_scores(t)[name],y) for t,_,y in complete_case])
                    for name in times)
        complete_case_differences[(seed,site)]=cc_queue-cc_time
        rows.append({'seed':seed,'site':site,'temporal_regime':REGIME[seed],
                     'observations':108,'complete_telemetry_observations':len(complete_case),
                     'positives':label_counts[1],
                     'negatives':label_counts[0],
                     'diagnostic_AP_queue_max':ap_queue,
                     'diagnostic_AP_time_fixed_scores':times,
                     'diagnostic_AP_time_conservative_envelope':envelope,
                     'diagnostic_AP_queue_minus_time_envelope':ap_queue-envelope,
                     'within_100ms_queue_concordance':within})
    per_seed_diff={seed:sum(x['diagnostic_AP_queue_minus_time_envelope']
                            for x in rows if x['seed']==seed)/3 for seed in SEEDS}
    per_seed_cc={seed:sum(complete_case_differences[(seed,site)] for site in SITES)/3
                 for seed in SEEDS}
    per_seed_conc={}
    not_estimable=[]
    for seed in SEEDS:
        cases=[x['within_100ms_queue_concordance'] for x in rows if x['seed']==seed]
        pairs=sum(x['pairs'] for x in cases)
        if not pairs:
            not_estimable.append(seed)
            continue
        per_seed_conc[seed]=sum(x['wins']+x['ties']/2 for x in cases)/pairs
    ci_diff=bootstrap_ci(per_seed_diff)
    ci_conc=bootstrap_ci(per_seed_conc,allow_incomplete=True)
    promising=(not not_estimable and ci_diff['observed_mean']>0 and ci_diff['percentile_95'][0]>0 and
               ci_conc['percentile_95'][0]>0.5)
    status=('PROMISING_DEV_ASSOCIATION_NOT_CONFIRMED' if promising else
            'NO_GO_INDEPENDENT_PREDICTIVE_VALUE_NOT_DEMONSTRATED')
    site_breakdown={site:{'mean_queue_AP':sum(r['diagnostic_AP_queue_max'] for r in rows
                                                   if r['site']==site)/8,
                          'mean_time_envelope_AP':sum(r['diagnostic_AP_time_conservative_envelope']
                                                      for r in rows if r['site']==site)/8,
                          'mean_AP_difference':sum(r['diagnostic_AP_queue_minus_time_envelope']
                                                   for r in rows if r['site']==site)/8}
                    for site in SITES}
    regime_breakdown={regime:{'case_count':len([r for r in rows if r['temporal_regime']==regime]),
                              'mean_AP_difference':sum(r['diagnostic_AP_queue_minus_time_envelope']
                                                       for r in rows if r['temporal_regime']==regime)/6}
                      for regime in ('EARLY','LATE','DOUBLE','THREE_PULSE')}
    report=dict(stage='v0.52.14_P4_P11_DEV_NO_FIT_TIME_CONDITIONED_EXPLORATORY',
                status=status,scientific_status='DEVELOPMENT_ONLY_NOT_CONFIRMATORY',
                parent_github_run=P10_RUN,parent_commit=P10_COMMIT,
                parent_artifact_id=P10_ARTIFACT_ID,parent_artifact_sha256=P10_SHA,
                observed_p10_simulations=96,new_simulations_executed=0,
                used_high_pressure_telemetry_on_cases=24,observed_episodes_in_comparison=2592,
                partial_remote_telemetry_observations=total_partial,
                partial_remote_telemetry_row_keys=partial_keys,
                sensitivity_complete_case_mean_AP_difference=sum(per_seed_cc.values())/8,
                sensitivity_complete_case_minus_main_mean_AP_difference=
                    (sum(per_seed_cc.values())-sum(per_seed_diff.values()))/8,
                time_bin_ns=TIME_BIN_NS,bootstrap_by_whole_independent_seed=True,
                mean_seed_block_AP_difference_vs_time_envelope=ci_diff,
                mean_seed_block_within_time_bin_concordance=ci_conc,
                within_bin_nonestimable_seed_blocks=not_estimable,
                within_bin_full_eight_seed_coverage=not not_estimable,
                per_seed_AP_difference={str(k):v for k,v in per_seed_diff.items()},
                per_seed_within_time_bin_concordance={str(k):v for k,v in per_seed_conc.items()},
                per_site=site_breakdown,per_temporal_regime=regime_breakdown,
                case_results=rows,official_F3_PR_AUC_computed=False,
                official_F3_labels_constructed=0,models_trained=0,
                validation_seeds_consumed=0,heldout_seeds_consumed=0,
                heldout_release_authorized=False,**{k:v for k,v in LOCKS.items()
                                                  if k!='heldout_release_authorized'})
    return report


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--p10-artifact',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    result=analyze(args.p10_artifact)
    require(not args.output.exists(),'REFUSE_OVERWRITE_P11_REPORT')
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({k:result[k] for k in ('status','used_high_pressure_telemetry_on_cases',
          'mean_seed_block_AP_difference_vs_time_envelope',
          'mean_seed_block_within_time_bin_concordance')},indent=2))


if __name__=='__main__':main()
