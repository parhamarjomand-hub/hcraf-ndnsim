import csv,json,zipfile,hashlib,collections,math,sys,pathlib
PINS=['746889957c3d91523fa937e7a888cef4e50d847c8596760f6b833ccdafe28ab2','f9fd01d7a22f03675033495b834d449d98ea35b8b4cafddb717eeadac7401992','86aed069623b04b3c3786e0afc7fc97f7e1953313e836883b7b0265d034739e8']
LOCKS=dict(F3_ready=False,GO_FREEZE=False,training_ready=False,Congestion=None,FutureCongestion=None,Stage1AO_or_NSGAIII_authorized=False,heldout_release_authorized=False)
COLS='rank packets fraction up pit interest_rx data_rx nack_rx interest_tx interest_drop rtt missing'.split()
def need(ok,msg):
 if not ok:raise ValueError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def rows(b):return csv.DictReader(b.decode().splitlines())
def j(z,n):return json.loads(z.read(n))
def locks(r):need(all(k in r and r[k]==v for k,v in LOCKS.items()),'LOCKS')
def equivalent(m):
 a,b=m['B0'],m['B1'];idx=[b['names'].index(k) for k in a['names']];extra=set(range(12))-set(idx)
 need(len(set(idx))==7 and len(extra)==5,'FEATURE_SET')
 return a['intercept']==b['intercept'] and all(a[k]==[b[k][i] for i in idx] for k in ['weights','means','sds']) and all(b['weights'][i]==0 for i in extra)
def stat(c):
 n=sum(c.values());mean=sum(x*k for x,k in c.items())/n
 return dict(n=n,unique=len(c),minimum=min(c),maximum=max(c),mean=mean,sd=math.sqrt(sum(k*(x-mean)**2 for x,k in c.items())/n),nonzero=n-c.get(0,0))
def audit(prereg,raw,freeze,out):
 for path,h in zip((prereg,raw,freeze),PINS):
  with open(path,'rb') as file:need(hashlib.file_digest(file,'sha256').hexdigest()==h,'ZIP_SHA')
 with zipfile.ZipFile(prereg) as p,zipfile.ZipFile(raw) as z,zipfile.ZipFile(freeze) as f:
  for a in (p,z,f):need(len(a.namelist())==len(set(a.namelist())),'ZIP_DUP')
  pr=j(p,'p12r_prereg/PREREG_RECEIPT.json');locks(pr)
  for n,h in pr['files'].items():need(sha(p.read('p12r_prereg/'+n))==h,'PREREG_SHA')
  plan=j(p,'p12r_prereg/PLAN.json');need(plan['horizon_ns']==75000000,'HORIZON')
  fr=j(f,'FREEZE_RECEIPT.json');locks(fr);need(fr['confirmation_rows_read']==0 and not fr['confirmation_execution_authorized'],'FREEZE')
  for n,h in fr['files'].items():need(sha(f.read(n))==h,'FREEZE_SHA')
  m=j(f,'FROZEN_MODELS.json');locks(m);need(m['B0']['names']==plan['feature_order_baseline'] and m['B1']['names']==plan['feature_order_full'] and equivalent(m),'MODEL_EQUIVALENCE')
  root='p12r57_dev/';dr=j(z,root+'DEV_RECEIPT.json');locks(dr);need(dr['confirmation_cases']==0 and sha(z.read(root+'DEV_RECEIPT.json'))==fr['source_dev_receipt_sha256'],'DEV_SHA')
  matrix=[r for r in rows(p.read('p12r_prereg/LOCKED_MATRIX.csv')) if r['partition']=='development'];need(len(matrix)==180,'MATRIX')
  expected={f'{r["seed"]}/{r["site"]}/{r["arm"]}/case_receipt.json' for r in matrix};need(expected==set(dr['case_receipt_hashes'])=={n[len(root):] for n in z.namelist() if n.startswith(root) and n.endswith('/case_receipt.json')},'CASES')
  schedules=collections.defaultdict(list)
  for r in rows(p.read('p12r_prereg/LOCKED_PROBE_SCHEDULE.csv')):
   if r['partition']=='development':schedules[(r['seed'],r['site'])].append(tuple(int(r[k]) for k in ('decision_index','decision_ns','selected_slot')))
  sel=[collections.Counter() for _ in COLS];allf=[collections.Counter() for _ in COLS];events=collections.Counter();queues=collections.Counter();gaps=[];rawcount=pos=0
  for c in matrix:
   need(620101<=int(c['seed'])<=620112,'SEED');prefix=f'{c["seed"]}/{c["site"]}/{c["arm"]}/';n=prefix+'case_receipt.json';need(sha(z.read(root+n))==dr['case_receipt_hashes'][n],'CASE_SHA');rc=j(z,root+n);locks(rc);need(rc['case']==c and rc['status']=='PASS_DEV_CASE_ENGINEERING_ONLY','CASE')
   need(set(rc['files'])=={n[len(root+prefix):] for n in z.namelist() if n.startswith(root+prefix) and n!=root+prefix+'case_receipt.json'},'RAW_SET')
   data={}
   for n,h in rc['files'].items():
    b=z.read(root+prefix+n);need(sha(b)==h,'RAW_SHA');rawcount+=1
    if n in ('features.csv','local_events.csv','queue_a.csv','dev_candidate_reference.json'):data[n]=b
   fs=list(rows(data['features.csv']));ys=json.loads(data['dev_candidate_reference.json']);ss=schedules[c['seed'],c['site']];need(len(fs)==378 and len(ys)==len(ss)==126,'ROWS');gaps.extend(b[1]-a[1] for a,b in zip(ss,ss[1:]))
   for i,t,k in ss:
    q=ys[i];need((q['decision_id'],q['time_ns'],q['slot'])==(i+1,t,k),'LABEL_KEY');pos+=q['candidate_future_class']
    for s in range(3):
     v=fs[i*3+s];need(tuple(int(v[n]) for n in ('decision_id','time_ns','slot'))==(i+1,t,s),'FEATURE_KEY');vals=[float(v[n]) for n in COLS];need(all(math.isfinite(x) for x in vals),'NONFINITE')
     for a,x in enumerate(vals):
      allf[a][x]+=1
      if s==k:sel[a][x]+=1
   for e in rows(data['local_events.csv']):events[e['kind']]+=1
   for e in rows(data['queue_a.csv']):queues[('local' if int(e['queue'])>=9 else 'return')+'_'+e['event']]+=1
  need(rawcount==3240 and pos==fr['training_positives']==1618 and all(sum(c.values())==22680 for c in sel) and all(sum(c.values())==68040 for c in allf),'TOTALS')
  features={n:dict(selected=stat(s),all_candidates=stat(a),frozen_weight=w) for n,s,a,w in zip(m['B1']['names'],sel,allf,m['B1']['weights'])}
  for n,info in features.items():need(abs(info['selected']['mean']-m['B1']['means'][m['B1']['names'].index(n)])<1e-8,'MEAN')
  r=dict(status='PASS_DEV_DEGENERACY_AUDIT_CONFIRMATION_BLOCKED',cases=180,raw_files_verified=rawcount,selected_rows=22680,all_candidate_rows=68040,positives=pos,features=features,local_native_events=dict(events),queue_events=dict(queues),min_interdecision_gap_ns=min(gaps),max_interdecision_gap_ns=max(gaps),gaps_le_75ms=sum(x<=75000000 for x in gaps),gap_count=len(gaps),identical_frozen_functions=True,strict_superiority_possible=False,confirmation_execution_authorized=False,confirmation_rows_read=0,model_fits=0,new_AP_computed=False,new_bootstrap_computed=False,prior_NO_GO_preserved=True,physical_dev_contrasts=j(f,'DEV_PHYSICAL_DESCRIPTIVE.json')['contrasts'],**LOCKS)
  out=pathlib.Path(out);out.mkdir(parents=True,exist_ok=False);(out/'AUDIT_RECEIPT.json').write_text(json.dumps(r,sort_keys=True,indent=2)+'\n');print(r['status'])
if __name__=='__main__':audit(*sys.argv[1:])
