import unittest,copy,collections
from audit import equivalent,locks,LOCKS,stat,need
class Tests(unittest.TestCase):
 def setUp(self):
  a=dict(names=list('abcdefg'),means=[0]*7,sds=[1]*7,weights=[1]*7,intercept=0)
  self.m={'B0':a,'B1':dict(names=list('abcdefghijkl'),means=[0]*12,sds=[1]*12,weights=[1]*7+[0]*5,intercept=0)}
 def test_equivalence(self):self.assertTrue(equivalent(self.m))
 def test_extra_weight(self):self.m['B1']['weights'][11]=1;self.assertFalse(equivalent(self.m))
 def test_scale(self):self.m['B1']['sds'][2]=2;self.assertFalse(equivalent(self.m))
 def test_intercept(self):self.m['B1']['intercept']=1;self.assertFalse(equivalent(self.m))
 def test_locks(self):locks(LOCKS);r=dict(LOCKS,F3_ready=True);self.assertRaises(ValueError,locks,r)
 def test_missing_lock(self):r=dict(LOCKS);del r['Congestion'];self.assertRaises(ValueError,locks,r)
 def test_constant(self):self.assertEqual(stat(collections.Counter({1:10}))['sd'],0)
 def test_need(self):self.assertRaises(ValueError,need,False,'X')
if __name__=='__main__':unittest.main()
