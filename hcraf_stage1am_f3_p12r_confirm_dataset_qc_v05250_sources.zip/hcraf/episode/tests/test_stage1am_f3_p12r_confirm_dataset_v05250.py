import unittest,sys,pathlib
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent.parent/'scripts'))
from audit_stage1am_f3_p12r_confirm_dataset_v05250 import y_at,replay,remote,prefix,H,BLOCKS,SEEDS,locked,LOCK,unique
class TestQC(unittest.TestCase):
 def test_endpoint_boundaries(self):
  t=100000000
  self.assertEqual(y_at([t],t),0);self.assertEqual(y_at([t+1],t),1);self.assertEqual(y_at([t+H],t),1);self.assertEqual(y_at([t+H+1],t),0)
 def test_event_causal_window(self):
  t=100000000;ev=[dict(time_ns=t-H,event='interest_rx',face_id=1),dict(time_ns=t-H+1,event='interest_rx',face_id=1),dict(time_ns=t,event='interest_tx',face_id=2),dict(time_ns=t,event='interest_tx',face_id=3),dict(time_ns=t,event='interest_rx',face_id=1)]
  self.assertEqual(replay(ev,t,4,2),[1,0,0,1,0,0.,1])
 def test_rtt(self):
  ev=[dict(time_ns=1,event='rtt',face_id=2,rtt_ms=10),dict(time_ns=2,event='rtt',face_id=2,rtt_ms=18)]
  self.assertEqual(replay(ev,3,2,2)[5:],[11.,0])
 def test_future_rejected(self):
  with self.assertRaises(RuntimeError):prefix([{'time_ns':10}],9,1,'time_ns')
 def test_omitted_past_rejected(self):
  with self.assertRaises(RuntimeError):prefix([{'time_ns':10}],11,0,'time_ns')
 def test_remote_order_and_missing(self):
  t=200000000;rr=[dict(source_node_id=2,source_device_index=0,report_id='relay-1',sample_ns=t-10000000,receipt_ns=t-5000000,queue_packets_now=4)]
  ev=dict(selected_sender_sources=[dict(node_id=n,device_index=0) for n in (2,7,8)],feature_evidence=[dict(source_node_id=2,source_device_index=0,report_id='relay-1')],feature_missing_sources=[dict(source_node_id=n,source_device_index=0) for n in (7,8)])
  self.assertEqual(remote(t,1,rr,[2,7,8],ev),[4,0,10.,0,1,0,0,1,0])
  ev['feature_evidence'][0]['report_id']='bad'
  with self.assertRaises(RuntimeError):remote(t,1,rr,[2,7,8],ev)
 def test_stale_receipt(self):
  t=200000000;rr=[dict(source_node_id=2,source_device_index=0,report_id='relay-1',sample_ns=t-100000001,receipt_ns=t-5000000,queue_packets_now=4)]
  ev=dict(selected_sender_sources=[dict(node_id=n,device_index=0) for n in (2,7,8)],feature_evidence=[],feature_missing_sources=[dict(source_node_id=n,source_device_index=0) for n in (2,7,8)])
  self.assertEqual(remote(t,1,rr,[2,7,8],ev),[0,1,0]*3)
 def test_exact_blocks(self):
  self.assertEqual(len(BLOCKS),6);self.assertEqual([s for b in BLOCKS for s in b['seeds']],sorted(SEEDS));self.assertEqual(len({b['artifact_id'] for b in BLOCKS}),6)
 def test_lock_guard(self):
  self.assertTrue(locked(LOCK));self.assertFalse(locked(dict(LOCK,F3_ready=True)));self.assertFalse(locked(dict(LOCK,Congestion=0)))
 def test_duplicate_rejected(self):
  with self.assertRaises(RuntimeError):unique([{'id':1},{'id':1}],lambda x:x['id'])
if __name__=='__main__':unittest.main()
