#!/usr/bin/env python3
"""P4/P10: new 8-seed, 96-condition DEVELOPMENT-only physical executor.

Every 12-case seed is audited, zipped with per-file SHA256, CRC verified,
then the temporary raw directory is removed only after recoverable ZIP save.
No old development fixture, Validation, Heldout, training, or official F3.
"""
import argparse
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

from generate_stage1am_f3_p4_temporal_schedule_v05212 import (
    PARTITIONS, PLANS, MATRIX, COMMITMENTS, FAMILY, SCHEMA,
    assignments, events, render, locked_filename, commitments,
)
from generate_stage1am_f3_p4_temporal_matrix_v05212 import rows as matrix_rows, render as matrix_render
from run_stage1am_f3_p4_route_diversity_dev_v0527 import physical_witness, check_decisions
from run_stage1am_f3_p4_revised_dev_v0529 import verify_telemetry
from build_stage1am_f3_p4_temporal_dev_tables_v05213 import process_one


ROOT=Path(__file__).resolve().parents[3]
DEST=ROOT/"episode_output/stage1am_f3_p4_temporal_dev_v05213"
WORK=ROOT/"episode_output/v05213_temporary_raw_seed_work"
BIN="hcraf-stage1am-f3-p4-temporal-dev-v05213"
SEEDS=PARTITIONS["DEVELOPMENT"]
ARMS=(("producer_egress","PRODUCER_RETURN_12M","PRODUCER_RETURN","producer"),
      ("transit_middle","MID_RETURN_12M","MID_RETURN","mid"),
      ("consumer_ingress","RELAY_RETURN_12M","RELAY_RETURN","relay"))
LOADS=("low_control","high_pressure")
TELEMETRIES=(("off",False),("on_20ms",True))
SCIENCE=dict(Congestion=None,FutureCongestion=None,F3_ready=False,
             GO_FREEZE=False,training_ready=False,
             heldout_release_authorized=False)


def check(ok,why):
    if not ok:raise RuntimeError("P4P10_"+why)


def sha256_file(path):
    hasher=hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda:f.read(1 << 20),b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def plan():
    check(len(SEEDS)==8 and all(23301<=seed<=23308 for seed in SEEDS),
          "ONLY_EIGHT_NEW_DEVELOPMENT_SEEDS")
    a=assignments("DEVELOPMENT")
    rows=[]
    for seed in SEEDS:
        for site,arm,location,role in ARMS:
            for load in LOADS:
                for telemetry,enabled in TELEMETRIES:
                    rows.append(dict(seed=seed,site=site,arm=arm,location=location,
                         role=role,load=load,telemetry=telemetry,enabled=enabled,
                         selected_slot=a[seed]["selected_slot"],
                         temporal_regime=a[seed]["temporal_regime"]))
    check(len(rows)==96,"EXPECTED_96_DEV_CONDITIONS")
    locked={(r["seed"],r["topology_profile"],r["load_profile"],r["telemetry_profile"])
            for r in matrix_rows() if r["eligible_after_separate_frozen_executor"]=="true"}
    check({(r["seed"],r["site"],r["load"],r["telemetry"]) for r in rows}==locked and
          len(locked)==96,"P10_AUTHORIZED_DEV_MATRIX_NOT_P9_COMMITMENT")
    check(all(r["partition"]=="DEVELOPMENT" for r in matrix_rows()
              if r["eligible_after_separate_frozen_executor"]=="true"),
          "VALIDATION_OR_TEST_MADE_ELIGIBLE")
    return rows


def check_locked():
    check(MATRIX.read_bytes()==matrix_render(),"P9_288_MATRIX_MODIFIED")
    m=json.loads(COMMITMENTS.read_text())
    check(m==commitments(),"P9_48_SCHEDULE_HASH_COMMITMENTS_CHANGED")
    check(m["validation_and_heldout_schedules_emitted"]==0 and
          m["all_288_simulations_executable_now"] is False,
          "P9_PROTECTED_SEEDS_UNSEALED")
    for seed in SEEDS:
        for load in LOADS:
            path=PLANS/locked_filename("DEVELOPMENT",seed,load)
            check(path.is_file() and path.read_bytes()==render("DEVELOPMENT",seed,load),
                  "DEV_CSV_NOT_IDENTICAL_TO_P9_COMMITTED_BYTES")
            check(hashlib.sha256(path.read_bytes()).hexdigest()==m["SHA256_by_filename"][path.name],
                  "DEV_CSV_SHA256_NOT_P9_FROZEN")
        low={r["sequence"]:r["time_ns"] for r in events("DEVELOPMENT",seed,"low_control")
             if r["traffic_class"]=="TARGET"}
        high={r["sequence"]:r["time_ns"] for r in events("DEVELOPMENT",seed,"high_pressure")
              if r["traffic_class"]=="TARGET"}
        check(low==high and len(low)==12,"PAIRED_TARGET_SCHEDULE_CHANGED")


def command(row,dest):
    a=assignments("DEVELOPMENT")[row["seed"]]
    values=[f"--pathArm={row['arm']}",f"--interventionLocation={row['location']}",
            "--interventionReturnBps=12000000","--lossProbability=0",
            "--lossStream=79","--lossReceiverNodeId=-1","--lossReceiverDeviceIndex=-1",
            f"--scheduleFamily={FAMILY}",
            f"--scheduleCsv={PLANS/locked_filename('DEVELOPMENT',row['seed'],row['load'])}",
            f"--prospectiveLoad={row['load']}",
            f"--prospectiveTrafficStreamSeed={a['traffic_stream_seed']}",
            f"--prospectiveRoutingStreamSeed={a['routing_stream_seed']}",
            f"--prospectiveTelemetryStreamSeed={a['telemetry_stream_seed']}",
            f"--selectedSlot={row['selected_slot']}",f"--run={row['seed']}",
            f"--output={dest}","--instrument=1","--topology=DEV_CHAIN_L",
            "--mode=LP_INDEPENDENT_COMPETITOR_NO_DROP","--seed=17",
            "--lifetimeMs=2600","--requestCount=12","--intervalNs=30000000",
            "--competitorCount=96","--competitorIntervalNs=2000000",
            "--competitorOffsetNs=0","--targetOffsetNs=30000000",
            "--forwardBps=50000000","--returnBps=50000000",
            "--technicalQueueMaxPackets=12",
            f"--telemetryEnabled={int(row['enabled'])}","--telemetryPeriodMs=20"]
    return BIN+" "+" ".join(values)


def load_lines(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line]


def verify_sends(dest,seed,load):
    reference=events("DEVELOPMENT",seed,load)
    for kind,base in (("TARGET","consumer_events.jsonl"),
                      ("INDEPENDENT_COMPETITOR","competitor_events.jsonl")):
        expected={r["sequence"]:r["time_ns"] for r in reference if r["traffic_class"]==kind}
        sent={int(e["name"].rsplit("/",1)[-1]):e["time_ns"]
              for e in load_lines(dest/base) if e["event"]=="SEND"}
        arrivals=load_lines(dest/(base+".arrivals.jsonl"))
        arrived={r["sequence"]:r["time_ns"] for r in arrivals}
        check(expected==sent==arrived,"ACTUAL_SEND_NOT_MATCH_P9_LOCKED_CSV")
        check({r["schedule"] for r in arrivals}==
              {"F3_P4_V05212_TEMPORAL_DEVELOPMENT_LOCKED_CSV"},
              "P10_ACTUAL_ARRIVAL_CONTRACT_MISMATCH")


def simulate_one(row,seed_work,features,labels):
    dest=seed_work/row["site"]/row["load"]/row["telemetry"]
    dest.mkdir(parents=True,exist_ok=False)
    cmd=command(row,dest)
    (dest/"command.txt").write_text(cmd+"\n")
    (dest/"P4P10_LOCKED_CASE.json").write_text(json.dumps({**row,**SCIENCE},indent=2)+"\n")
    with (dest/"simulator.log").open("w") as logfile:
        subprocess.run(["/usr/bin/time","-f","wall_seconds=%e\nmax_rss_kib=%M",
                        "-o",str(dest/"resource_usage.txt"),"python3","./waf",
                        "--run-no-build",cmd],cwd=ROOT/"episode_sources/ns-3",
                       stdout=logfile,stderr=subprocess.STDOUT,check=True)
    scenario=json.loads((dest/"scenario.json").read_text())
    expect=assignments("DEVELOPMENT")[row["seed"]]
    check(scenario["holdout_partition"]=="DEVELOPMENT" and
          scenario["independent_rng_block"]==row["seed"] and
          scenario["selected_face_slot"]==row["selected_slot"] and
          scenario["selected_face_id"]==258+row["selected_slot"] and
          scenario["schedule_family"]==FAMILY and
          scenario["schedule_contract"]=="P4_V05212_INDEPENDENT_TEMPORAL_DEVELOPMENT_LOCKED_CSV" and
          scenario["schedule_csv_filename"]==locked_filename("DEVELOPMENT",row["seed"],row["load"]) and
          scenario["p4_locked_traffic_stream_seed"]==expect["traffic_stream_seed"] and
          scenario["p4_locked_routing_stream_seed"]==expect["routing_stream_seed"] and
          scenario["p4_locked_telemetry_stream_seed"]==expect["telemetry_stream_seed"] and
          scenario["p4_prospective_load"]==row["load"] and
          scenario["phase_arm"]==row["arm"] and
          scenario["intervention_location"]==row["location"] and
          scenario["technical_queue_max_packets"]==12 and
          scenario["telemetry_enabled"]==row["enabled"] and
          scenario["official_F3_labels_constructed"]==0 and
          all(scenario[k] is value for k,value in SCIENCE.items()),
          "PHYSICAL_SCENARIO_OR_SCIENCE_FENCE_CHANGED")
    verify_sends(dest,row["seed"],row["load"])
    physical=physical_witness(dest,scenario,row["role"])
    decisions=check_decisions(dest,scenario)
    transport=verify_telemetry(dest,scenario,row["enabled"])
    audit={**row,"physical":physical,"decisions":decisions,
           "telemetry_transport":transport,
           "off_target_queue_drops_not_silently_deleted":True,
           "low_control_queue_drops_not_silently_deleted":True,
           "official_F3_labels_constructed":0,
           "F3_PR_AUC_computed":False,**SCIENCE}
    (dest/"P4P10_TEMPORAL_DEV_PHYSICAL_AUDIT.json").write_text(json.dumps(audit,indent=2)+"\n")
    diagnostic=process_one(row,dest,features,labels)
    result={**audit,"diagnostic":diagnostic}
    return result


def archive_seed(seed,seed_work):
    """Make one recoverable seed ZIP, verify CRC and all SHA, only then clear scratch."""
    target=DEST/("P4P10_RAW_SEED_"+str(seed)+".zip")
    check(not target.exists(),"REFUSE_OVERWRITE_SEED_ARCHIVE")
    files=sorted(p for p in seed_work.rglob("*") if p.is_file())
    check(len(files)>100,"INSUFFICIENT_RAW_PHYSICAL_FILES_BEFORE_ARCHIVE")
    digests={str(p.relative_to(seed_work)):sha256_file(p) for p in files}
    with zipfile.ZipFile(target,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for path in files:
            z.write(path,str(path.relative_to(seed_work)))
        z.writestr("P4P10_ORIGINAL_RAW_FILE_SHA256.json",
                   json.dumps(digests,indent=2,sort_keys=True)+"\n")
    with zipfile.ZipFile(target) as z:
        check(z.testzip() is None and
              set(z.namelist())==set(digests)|{"P4P10_ORIGINAL_RAW_FILE_SHA256.json"},
              "COMPRESSED_SEED_ZIP_BAD_CRC_OR_MEMBERS")
        for name in digests:
            check(hashlib.sha256(z.read(name)).hexdigest()==digests[name],
                  "COMPRESSED_SEED_FILE_SHA_CHANGED:"+name)
    sha=sha256_file(target)
    size=target.stat().st_size
    # Only generated transient work is removed after a complete, verified,
    # recoverable seed ZIP was written into the final artifact directory.
    shutil.rmtree(seed_work)
    return {"seed":seed,"raw_archive_name":target.name,"raw_archive_sha256":sha,
            "raw_archive_bytes":size,"raw_members":len(digests),
            "temporary_raw_removed_after_verified_recoverable_archive":True}


def preflight():
    rows=plan();check_locked()
    return dict(status="P4P10_96_DEV_PREFLIGHT_ONLY",conditions=96,
                seeds=list(SEEDS),regime_allocation={str(seed):assignments("DEVELOPMENT")[seed]
                                                  for seed in SEEDS},
                validation_or_test_authorized=False,
                no_simulations_in_preflight=True,**SCIENCE)


def run():
    check_locked();rows=plan()
    check((ROOT/"episode_sources/ns-3/build/scratch"/BIN).is_file(),"BINARY_NOT_BUILT")
    check(not DEST.exists() and not WORK.exists(),"REFUSE_OVERWRITE_EXISTING_P10_OUTPUT")
    DEST.mkdir(parents=True,exist_ok=False)
    WORK.mkdir(parents=True,exist_ok=False)
    audit_rows=[];diagnostic_rows=[];archived=[]
    features=DEST/"DEV_FEATURES_ONLY_TEMPORAL_v05213.jsonl"
    labels=DEST/"DEV_DIAGNOSTIC_FUTURE_EVENTS_ONLY_TEMPORAL_v05213.jsonl"
    with features.open("w") as f,labels.open("w") as l:
        for seed in SEEDS:
            seed_work=WORK/str(seed)
            seed_work.mkdir(parents=True,exist_ok=False)
            batch=[]
            for row in rows:
                if row["seed"]!=seed:continue
                result=simulate_one(row,seed_work,f,l)
                audit_rows.append(result)
                diagnostic_rows.append(result["diagnostic"])
                batch.append(result)
                print("P4P10_DEV_PHYSICAL",len(audit_rows),"/96",seed,row["site"],
                      row["load"],row["telemetry"],
                      result["physical"]["physical_drops_by_role"],
                      result["diagnostic"]["positive_75ms"],flush=True)
            f.flush();l.flush()
            check(len(batch)==12,"ONE_SEED_NOT_ALL_12_PAIRED_SCENARIOS")
            (seed_work/"P4P10_SEED_AUDIT.json").write_text(json.dumps(batch,indent=2)+"\n")
            package=archive_seed(seed,seed_work)
            archived.append(package)
            (DEST/"P4P10_ARCHIVED_SEED_INDEX.json").write_text(
                json.dumps(archived,indent=2)+"\n")
            # Fail fast after securely retaining the full failed seed. Do not
            # substitute another seed or silently remove an unfavorable case.
            high=[x for x in batch if x["load"]=="high_pressure"]
            if not all(x["physical"]["physical_drops_by_role"][x["role"]]>0 for x in high):
                (DEST/"P4P10_FAIL_FAST_SCIENCE_GATE.json").write_text(json.dumps({
                    "status":"NO_GO_HIGH_PRESSURE_REAL_TARGET_QUEUE_DROP_ABSENT",
                    "seed":seed,"completed_simulations":len(audit_rows),
                    "archived_raw_recoverable":True,"results":batch,**SCIENCE},indent=2)+"\n")
                print("P4P10_NO_GO_PHYSICAL_ABORT_AFTER_ARCHIVED_SEED",seed,flush=True)
                raise RuntimeError("P4P10_REAL_TARGET_QUEUE_DROP_ABSENT")
    check(len(audit_rows)==96 and len(diagnostic_rows)==96,"INCOMPLETE_96_CONDITIONS")
    check(sum(row["diagnostic"]["decisions"] for row in audit_rows)==10368,
          "INCOMPLETE_SELECTED_FACE_EPISODES")
    positives=sum(x["positive_75ms"] for x in diagnostic_rows)
    both_high=[x for x in diagnostic_rows if x["load"]=="high_pressure" and
               0<x["positive_75ms"]<108]
    all_high=[x for x in diagnostic_rows if x["load"]=="high_pressure"]
    labels_status="PASS_P4P10_DEV_PHYSICAL_AND_ALL_HIGH_STRATA_CLASS_VARIATION" if len(both_high)==48 else \
                  "NO_GO_P4P10_CLASS_VARIATION_SOME_HIGH_ONE_CLASS"
    report={"status":labels_status,"num_development_simulations":96,
            "num_seed_blocks":8,"num_forwarding_episodes_selected_face":10368,
            "positive_75ms_diagnostic":positives,
            "negative_75ms_diagnostic":10368-positives,
            "high_strata_with_both_classes":len(both_high),
            "high_strata_total":len(all_high),"low_controls_retained_even_if_queue_drop":True,
            "no_future_information_in_online_features":True,
            "training_executed":False,"official_F3_labels_constructed":0,
            "F3_PR_AUC_computed":False,"validation_seeds_consumed":0,
            "heldout_seeds_consumed":0,
            "archived_raw_by_seed":archived,"results":diagnostic_rows,
            **SCIENCE}
    (DEST/"P4P10_TEMPORAL_DEVELOPMENT_SUMMARY.json").write_text(
        json.dumps(report,indent=2,sort_keys=True)+"\n")
    # Every derived table and summary also carries a separate SHA manifest;
    # archived raw seed ZIPs already have individual SHA values in summary.
    (DEST/"P4P10_OUTPUT_SHA256SUMS.txt").write_text(
        "".join(sha256_file(path)+"  "+path.name+"\n" for path in sorted(DEST.iterdir())
                if path.is_file() and path.name!="P4P10_OUTPUT_SHA256SUMS.txt"))
    print("P4P10_DONE",json.dumps({k:v for k,v in report.items()
                              if k not in ("results","archived_raw_by_seed")},sort_keys=True),flush=True)


def main():
    p=argparse.ArgumentParser();p.add_argument("--preflight-only",action="store_true")
    args=p.parse_args()
    if args.preflight_only:
        print(json.dumps(preflight(),indent=2))
    else:
        run()


if __name__=="__main__":main()
