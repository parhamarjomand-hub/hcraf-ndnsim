#!/usr/bin/env python3
"""P10 independent preregistered temporal-development safety/lineage tests."""
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import run_stage1am_f3_p4_temporal_dev_v05213 as p10
from generate_stage1am_f3_p4_temporal_schedule_v05212 import (
    PARTITIONS, assignments, events, FAMILY, locked_filename,
)
from build_stage1am_f3_p4_temporal_dev_tables_v05213 import audited_drops


class TemporalDevelopmentP10Tests(unittest.TestCase):
    def test_p9_parent_commitments_and_plan_are_immutable(self):
        p10.check_locked()
        matrix = p10.plan()
        self.assertEqual(len(matrix), 96)
        self.assertEqual(set(x['seed'] for x in matrix), set(range(23301,23309)))
        self.assertTrue(all(x['seed'] not in PARTITIONS['VALIDATION'] +
                            PARTITIONS['HELDOUT'] for x in matrix))
        self.assertEqual(len(set((x['seed'],x['site'],x['load'],x['telemetry'])
                                 for x in matrix)),96)
        for seed in PARTITIONS['DEVELOPMENT']:
            self.assertEqual(len([r for r in matrix if r['seed']==seed]),12)
        self.assertEqual({r['temporal_regime'] for r in matrix},
                         {'EARLY','LATE','DOUBLE','THREE_PULSE'})

    def test_frozen_paired_target_traffic_and_distinct_low_high(self):
        for seed in PARTITIONS['DEVELOPMENT']:
            low=events('DEVELOPMENT',seed,'low_control')
            high=events('DEVELOPMENT',seed,'high_pressure')
            self.assertEqual({r['time_ns'] for r in low if r['traffic_class']=='TARGET'},
                             {r['time_ns'] for r in high if r['traffic_class']=='TARGET'})
            self.assertNotEqual({r['time_ns'] for r in low if r['traffic_class']=='INDEPENDENT_COMPETITOR'},
                                {r['time_ns'] for r in high if r['traffic_class']=='INDEPENDENT_COMPETITOR'})

    def test_each_run_executes_only_development_12_packet_temporal_case(self):
        for row in p10.plan():
            c=p10.command(row,Path('/tmp/P10-fixed-probe'))
            self.assertIn('--scheduleFamily='+FAMILY,c)
            self.assertIn(locked_filename('DEVELOPMENT',row['seed'],row['load']),c)
            self.assertIn('--technicalQueueMaxPackets=12',c)
            self.assertIn('--telemetryPeriodMs=20',c)
            self.assertIn('--prospectiveTrafficStreamSeed='+str(
                assignments('DEVELOPMENT')[row['seed']]['traffic_stream_seed']),c)
            self.assertNotIn('2430',c)
            self.assertNotIn('2530',c)

    def test_cpp_source_rejects_protected_seeds_and_holds_science_fence(self):
        source=Path(__file__).resolve().parents[1]/'src/hcraf-stage1am-f3-p4-temporal-dev-v05213.cpp'
        content=source.read_text()
        for seed in PARTITIONS['DEVELOPMENT']:
            a=assignments('DEVELOPMENT')[seed]
            self.assertIn(f'{{{seed}u,{{{a["traffic_stream_seed"]}u,'+
                          f'{a["routing_stream_seed"]}u,{a["telemetry_stream_seed"]}u,'+
                          f'{a["selected_slot"]}u}}',content)
        self.assertNotIn('{24301u,',content)
        self.assertNotIn('{25301u,',content)
        self.assertIn('P4_V05212_INDEPENDENT_TEMPORAL_DEVELOPMENT_LOCKED_CSV',content)
        self.assertIn('P4P10_WRONG_TEMPORAL_DEVELOPMENT_SEED_STREAM_OR_ROUTE',content)
        for k,v in p10.SCIENCE.items():
            self.assertIsNone(v) if k in ('Congestion','FutureCongestion') else self.assertFalse(v)

    def test_raw_seed_zip_sha_and_crc_reconstruction_before_removal(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            temp=root/'working_seed'
            temp.mkdir()
            for i in range(101):
                p=temp/f'device_{i:03d}.jsonl'
                p.write_text('QUEUE_DROP '+str(i)+'\n')
            destination=root/'saved';destination.mkdir()
            with patch.object(p10,'DEST',destination):
                report=p10.archive_seed(23301,temp)
            self.assertFalse(temp.exists())
            zpath=destination/'P4P10_RAW_SEED_23301.zip'
            self.assertEqual(hashlib.sha256(zpath.read_bytes()).hexdigest(),
                             report['raw_archive_sha256'])
            with zipfile.ZipFile(zpath) as z:
                self.assertIsNone(z.testzip())
                hashes=json.loads(z.read('P4P10_ORIGINAL_RAW_FILE_SHA256.json'))
                self.assertEqual(len(hashes),101)
                for name,digest in hashes.items():
                    self.assertEqual(hashlib.sha256(z.read(name)).hexdigest(),digest)

    def test_zip_fails_without_erasing_nonrecoverable_raw(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);temp=root/'working_seed';temp.mkdir()
            (temp/'sole_raw.jsonl').write_text('{}\n')
            destination=root/'saved';destination.mkdir()
            with patch.object(p10,'DEST',destination):
                with self.assertRaisesRegex(RuntimeError,'INSUFFICIENT_RAW'):
                    p10.archive_seed(23301,temp)
            self.assertTrue((temp/'sole_raw.jsonl').exists())

    def test_physically_observed_queue_drop_not_arbitrary_receiver_failure(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            witness=root/'pathwide_witness_b.jsonl'
            witness.write_text('\n'.join(json.dumps({'event_type':kind,
                   'node_id':node,'device_index':dev,'timestamp_ns':t})
                   for kind,node,dev,t in [('QUEUE_DROP',2,0,100),
                                            ('RX_DROP',2,0,200),
                                            ('QUEUE_DROP',10,1,300)])+'\n')
            scenario={'selected_relay_node_id':2,'selected_mid_node_id':5,
                      'selected_producer_node_id':8}
            physical={'all_devices_physical_queue_drops':2,
                      'physical_drops_by_role':{'relay':1,'mid':0,'producer':0}}
            self.assertEqual(audited_drops(root,scenario,{'physical':physical}),[100])


if __name__=='__main__':unittest.main()
