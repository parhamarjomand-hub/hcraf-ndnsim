#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
# Compile and verify original pinned P12T first, unmodified, as performed in Run 45844118722.
bash "$TASK/scripts/build_stage1am_f3_p12t_native_v05239.sh"
NFD="$ROOT/episode_sources/ns-3/src/ndnSIM/NFD"
python3 "$TASK/scripts/patch_stage1am_f3_p12v_nfd_native_hooks_v05241.py" \
  --root "$NFD" --receipt "$ROOT/episode_output/p12v_native_preflight/NFD_PINNED_HOOK_PATCH_RECEIPT.json"
cd "$ROOT/episode_sources/ns-3"
cp "$TASK/src/hcraf-stage1am-f3-p12v-native-development-v05241.cpp" scratch/hcraf-stage1am-f3-p12v-native-development-v05241.cc
cp "$TASK/src/hcraf-stage1am-f3-p12u-local-nfd-hook-adapter-v05240.hpp" scratch/hcraf-stage1am-f3-p12u-local-nfd-hook-adapter-v05240.hpp
cmp -s "$TASK/src/hcraf-stage1am-f3-p12v-native-development-v05241.cpp" scratch/hcraf-stage1am-f3-p12v-native-development-v05241.cc
cmp -s "$TASK/src/hcraf-stage1am-f3-p12u-local-nfd-hook-adapter-v05240.hpp" scratch/hcraf-stage1am-f3-p12u-local-nfd-hook-adapter-v05240.hpp
python3 ./waf -j 2
test -x build/scratch/hcraf-stage1am-f3-p12v-native-development-v05241
echo PASS_P12V_REAL_PINNED_NDNSIM_NATIVE_FIVE_HOOK_SIGNALS_COMPILED
