#!/usr/bin/env python3
"""P12-V additive, fail-closed patch to the REAL PINNED NFD Forwarder.
Only the approved NFD commit 361b381b9b55... can be used. All other modifications
remain the historically authenticated instrumented Forwarder; never overwrite.
"""
import argparse, hashlib, json, pathlib, subprocess
PIN='361b381b9b552ff3341aa160858bea1d470d2122'
CPP='daemon/fw/forwarder.cpp'
HPP='daemon/fw/forwarder.hpp'

def need(x,msg):
    if not x: raise RuntimeError('P12V_'+msg)

def sha(raw):return hashlib.sha256(raw).hexdigest()

def replace_one(text,old,new,label):
    need(text.count(old)==1,'PATCH_ANCHOR_'+label+'_'+str(text.count(old)))
    return text.replace(old,new,1)

def patch(hpp,cpp):
    # Signal declared in public API next to the existing NFD PIT satisfaction signal.
    anchor='signal::Signal<Forwarder, pit::Entry, Face, Data> beforeSatisfyInterest;'
    addition="""

  // P12V DEVELOPMENT-ONLY local causality signals: all fired inside live NFD
  // pipelines. Do not compute labels or new scores from these hooks.
  signal::Signal<Forwarder, Interest, Face> hcrafP12VInterestIn;
  signal::Signal<Forwarder, Data, Face> hcrafP12VDataIn;
  signal::Signal<Forwarder, lp::Nack, Face> hcrafP12VNackIn;
  signal::Signal<Forwarder, Interest, Face> hcrafP12VInterestTx;
  signal::Signal<Forwarder, Interest, Face> hcrafP12VInterestDrop;"""
    hpp=replace_one(hpp,anchor,anchor+addition,'PUBLIC_SIGNALS')
    anchors=[
      ('++m_counters.nInInterests;', '++m_counters.nInInterests;\n  hcrafP12VInterestIn(interest, ingress.face);','INTEREST_IN'),
      ('++m_counters.nInData;', '++m_counters.nInData;\n  hcrafP12VDataIn(data, ingress.face);','DATA_IN'),
      ('++m_counters.nInNacks;', '++m_counters.nInNacks;\n  hcrafP12VNackIn(nack, ingress.face);','NACK_IN'),
      ('++m_counters.nOutInterests;', '++m_counters.nOutInterests;\n  hcrafP12VInterestTx(interest, egress);','SELECTED_TX'),
      ('m_strategyChoice.findEffectiveStrategy(interest.getName()).onDroppedInterest(interest, egress);',
       'hcrafP12VInterestDrop(interest, egress);\n  m_strategyChoice.findEffectiveStrategy(interest.getName()).onDroppedInterest(interest, egress);', 'NFD_DROP')
    ]
    for old,new,label in anchors:
        cpp=replace_one(cpp,old,new,label)
    return hpp,cpp

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--receipt',required=True);args=p.parse_args()
    root=pathlib.Path(args.root).resolve(); receipt=pathlib.Path(args.receipt)
    need(subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()==PIN,'PINNED_NFD_REV')
    hpp=root/HPP;cpp=root/CPP
    need(hpp.is_file() and cpp.is_file(),'MISSING_REAL_FORWARDER')
    actual_hpp=hpp.read_bytes();actual_cpp=cpp.read_bytes()
    # Existing instrumented Forwarder includes historically locked HCRAF API.
    need(b'hcrafSetDecisionObserver' in actual_hpp,'P12T_DECISION_OBSERVER_MISSING')
    need(b'hcrafEnable' in actual_hpp,'HISTORIC_RECORDER_MISSING')
    orig_hpp=subprocess.check_output(['git','-C',str(root),'show',PIN+':'+HPP])
    orig_cpp=subprocess.check_output(['git','-C',str(root),'show',PIN+':'+CPP])
    # Commit-level upstream fingerprint established from the actual P12T build log.
    need(len(orig_hpp)>6500 and b'beforeSatisfyInterest' in orig_hpp,'BAD_HISTORIC_HEADER')
    need(len(orig_cpp)>21000 and b'onIncomingInterest' in orig_cpp,'BAD_HISTORIC_CPP')
    new_hpp,new_cpp=patch(actual_hpp.decode(),actual_cpp.decode())
    # Locally ensure we only add one named signal declaration / call per event.
    for item in ('hcrafP12VInterestIn','hcrafP12VDataIn','hcrafP12VNackIn','hcrafP12VInterestTx','hcrafP12VInterestDrop'):
        need(new_hpp.count(item)==1 and new_cpp.count(item)==1,'DUPLICATE_SIGNAL_'+item)
    hpp.write_text(new_hpp);cpp.write_text(new_cpp)
    rec={'status':'P12V_NFD_PINNED_SOURCE_HOOK_PATCH_PREBUILD_ONLY','NFD_commit':PIN,
      'git_original_forwarder_hpp_sha256':sha(orig_hpp),'git_original_forwarder_cpp_sha256':sha(orig_cpp),
      'prepatch_instrumented_hpp_sha256':sha(actual_hpp),'prepatch_instrumented_cpp_sha256':sha(actual_cpp),
      'patched_hpp_sha256':sha(hpp.read_bytes()),'patched_cpp_sha256':sha(cpp.read_bytes()),
      'signals':list(('hcrafP12VInterestIn','hcrafP12VDataIn','hcrafP12VNackIn','hcrafP12VInterestTx','hcrafP12VInterestDrop')),
      'new_Ap':False,'heldout_reads':0,'F3_ready':False,'GO_FREEZE':False,'training_ready':False}
    receipt.parent.mkdir(parents=True,exist_ok=True);receipt.write_text(json.dumps(rec,indent=2)+'\n')
    print('PASS_P12V_PINNED_NFD_FIVE_EVENT_SIGNALS_PATCHED_DEVELOPMENT_ONLY')
if __name__=='__main__':main()
