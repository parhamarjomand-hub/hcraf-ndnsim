#!/usr/bin/env python3
"""P12V: ONE P12R development 24901 exploratory native 12-slot smoke; no AP/fit/heldout."""
import argparse, importlib.util, sys, json, subprocess, math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
MOD=ROOT/'hcraf/episode/scripts/run_stage1am_f3_p12t_smoke_v05239.py'
spec=importlib.util.spec_from_file_location('p12t_frozen_runner',MOD)
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
old.OUT=ROOT/'episode_output/stage1am_f3_p12v_v05241/dev_seed_24901_native12'
old.BIN='hcraf-stage1am-f3-p12v-native-development-v05241'

def need(c,x):
 if not c:raise RuntimeError('P12V_'+x)

def jsonl(p):
 return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]

def audit(r):
 old.audit_output(r)
 out=old.OUT
 native=jsonl(out/'p12v_native_local_12_at_decision.jsonl')
 original=jsonl(out/'p12t_native_local_at_decision.jsonl')
 need(len(native)==len(original)==128,'DECISION_COUNT')
 missing=[]
 for i,(x,p) in enumerate(zip(native,original),1):
  need(x['decision_id']==p['decision_id']==i and x['time_ns']==p['time_ns'],'TEMPORAL_SYNC')
  need(x['node_id']==1 and x['selected_face_id']==p['selected_face_id'],'FACE_LOCALITY')
  v=x['b1_all_twelve_native'];need(len(v)==12 and all(isinstance(a,(float,int)) and math.isfinite(a) for a in v),'NATIVE_12_FINITE')
  need(all(abs(v[j]-p['b1_first_five_native'][j])<1e-9 for j in range(5)),'FROZEN_FIRST_FIVE_MISMATCH')
  need(all(a>=0 for a in v[5:11]) and v[11] in (0,1),'NONNEGATIVE_FEATURES')
  need(x['hook_wiring_development_only'] and x['all_B1_features_validated'] is False,'NO_FALSE_READINESS')
  need(not x['F3_ready'] and not x['GO_FREEZE'] and not x['model_training_authorized'],'NO_GO')
  if i>1:
   before=native[i-2];need(all(x[k]>=before[k] for k in ('live_NFD_interest_rx_total','live_NFD_data_rx_total','live_NFD_nack_rx_total','live_NFD_interest_tx_total','live_NFD_interest_drop_total','locally_completed_RTT_total')),'NONMONOTONE_NATIVE_COUNTS')
 need(native[-1]['live_NFD_interest_rx_total']>=128,'NFD_INTEREST_RX_DISCONNECTED')
 need(native[-1]['live_NFD_interest_tx_total']>0,'NFD_TX_DISCONNECTED')
 # Nack and drop may correctly be zero in this one development condition;
 # these hooks are source-wired, but negative path exercise remains required.
 event_counts={k:native[-1][k] for k in ('live_NFD_interest_rx_total','live_NFD_data_rx_total','live_NFD_nack_rx_total','live_NFD_interest_tx_total','live_NFD_interest_drop_total','locally_completed_RTT_total')}
 status='PASS_P12V_ONE_DEV_PINNED_LIVE_NFD_TWELVE_SLOTS_ONLY_NOT_FULL_FEATURE_VALIDATION'
 result={'status':status,'run_partition':'P12R_FAIR_LOCAL_DEV','seed':24901,'cases':1,'native_decisions':128,'twelve_feature_slots_observed':True,
  'live_hook_totals_at_final_decision':event_counts,'rtt_hook_exercised':event_counts['locally_completed_RTT_total']>0,
  'nack_hook_exercised':event_counts['live_NFD_nack_rx_total']>0,'drop_hook_exercised':event_counts['live_NFD_interest_drop_total']>0,
  'fully_validated_12_feature_construct':False,'new_AP_computed':False,'model_fits':0,'confirmation_seed_reads':0,
  'heldout_reads':0,'F3_ready':False,'GO_FREEZE':False,'training_ready':False,'Congestion':None,'FutureCongestion':None,
  'Stage1AO_or_NSGAIII_authorized':False}
 (out/'P12V_NATIVE_12_HOOK_DEVELOPMENT_SMOKE_RECEIPT_v05241.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
 print(status);print(json.dumps(event_counts,sort_keys=True))
 return result

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--preflight-only',action='store_true');a=ap.parse_args()
 r,p=old.plan();need(r['seed']=='24901' and r['partition']=='FAIR_LOCAL_DEV','FROZEN_DEV_PARTITION')
 print('PASS_P12V_FROZEN_P12R_DEV_PLAN',r['schedule_sha256'])
 if a.preflight_only:return
 need(not old.OUT.exists(),'REFUSE_REPEAT_OR_OVERWRITE')
 need((ROOT/'episode_sources/ns-3/build/scratch'/old.BIN).is_file(),'NO_REAL_PINNED_NDNSIM_BINARY')
 old.OUT.mkdir(parents=True)
 command=old.cmd(r,p);(old.OUT/'command.txt').write_text(command+'\n')
 with (old.OUT/'simulator.log').open('w') as f:
  subprocess.run(['python3','./waf','--run-no-build',command],cwd=ROOT/'episode_sources/ns-3',stdout=f,stderr=subprocess.STDOUT,check=True)
 audit(r)
if __name__=='__main__':main()
