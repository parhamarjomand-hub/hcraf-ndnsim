import importlib.util, pathlib, sys, unittest
BASE=pathlib.Path(__file__).resolve().parents[1]
SRC=BASE/'src/hcraf-stage1am-f3-p12v-native-development-v05241.cpp'
PATCH=BASE/'scripts/patch_stage1am_f3_p12v_nfd_native_hooks_v05241.py'
RUN=BASE/'scripts/run_stage1am_f3_p12v_dev_v05241.py'
class P12V(unittest.TestCase):
  def test_parent_source_identical_prefix(self):
    s=SRC.read_text();self.assertIn('HcrafP12TNativeWiring',s)
    self.assertIn('p12t_native_local_at_decision.jsonl',s)
  def test_all_native_hook_slots_in_cpp(self):
    s=SRC.read_text()
    for x in ['hcrafP12VInterestIn','hcrafP12VDataIn','hcrafP12VNackIn','hcrafP12VInterestTx','hcrafP12VInterestDrop','beforeSatisfyInterest','nativeV->BeforeDecision(id)','b1_all_twelve_native']:
      self.assertIn(x,s)
  def test_no_false_release(self):
    s=RUN.read_text();self.assertIn("'F3_ready':False",s);self.assertIn("'GO_FREEZE':False",s);self.assertIn("'training_ready':False",s)
    self.assertNotIn('average_precision_score',s)
  def test_pinned_nfd_rev(self):
    self.assertIn('361b381b9b552ff3341aa160858bea1d470d2122',PATCH.read_text())
  def test_fail_closed_event_anchors(self):
    s=PATCH.read_text()
    for n in ['nInInterests','nInData','nInNacks','nOutInterests','onDroppedInterest']:
      self.assertIn(n,s)
  def test_one_development_case_only(self):
    s=RUN.read_text();self.assertIn('24901',s);self.assertIn('REFUSE_REPEAT_OR_OVERWRITE',s);self.assertNotIn('25001',s)
if __name__=='__main__':unittest.main()
