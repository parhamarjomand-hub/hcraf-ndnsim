import unittest

from analyze_stage1am_f3_p4_dev_ap_v05211 import (
    SEEDS, PARENT_RUN, PARENT_ARTIFACT, PARENT_SHA256,
    average_precision, scores_from_feature_row,
)


class TestDevExploratoryAP(unittest.TestCase):
    def test_average_precision_uses_tie_groups(self):
        self.assertAlmostEqual(average_precision([1, 0, 1], [3, 2, 1]), 5/6)
        self.assertAlmostEqual(average_precision([1, 0], [1, 1]), 0.5)
        self.assertAlmostEqual(average_precision([0, 1], [1, 1]), 0.5)

    def test_single_class_must_not_be_reported_as_AP(self):
        self.assertIsNone(average_precision([0, 0, 0], [3, 2, 1]))
        self.assertIsNone(average_precision([1, 1, 1], [3, 2, 1]))
        self.assertRaises(RuntimeError, average_precision, [1], [0, 1])

    def test_real_parent_pinning(self):
        self.assertEqual(PARENT_RUN, 44579295748)
        self.assertEqual(PARENT_ARTIFACT, 14557443309)
        self.assertEqual(PARENT_SHA256,
                         '4c8e7d1b065d0d7dcbaadc098c3c21b47b2d3a836ecba7276b8e2ed827e02d0e')
        self.assertEqual(SEEDS, (23201, 23202, 23203, 23204))

    def test_no_future_field_can_be_scored(self):
        values={'local_selected_queue_fraction':0.2}
        for role in ('relay','mid','producer'):
            values[role+'_telemetry_missing']=True
            values[role+'_queue_packets']=None
            values[role+'_queue_drops_observed_total']=None
            values[role+'_telemetry_age_ms']=None
        row={'metadata_NOT_A_PREDICTOR':{'load':'high_pressure'},
             'allowed_decision_time_features':values}
        self.assertEqual(scores_from_feature_row(row,False)['LOCAL_QUEUE_FRACTION'],0.2)
        with self.assertRaisesRegex(RuntimeError,'P4P8_REMOTE_REPORT_MISSING'):
            scores_from_feature_row(row,True)
        values['future_pressure_label']=1
        with self.assertRaisesRegex(RuntimeError,'P4P8_FUTURE_COLUMN'):
            scores_from_feature_row(row,False)

    def test_remote_metrics_are_fixed_and_only_observed(self):
        values={'local_selected_queue_fraction':0.2}
        for role,q in (('relay',1),('mid',3),('producer',2)):
            values[role+'_telemetry_missing']=False
            values[role+'_queue_packets']=q
            values[role+'_queue_drops_observed_total']=0
            values[role+'_telemetry_age_ms']=12.5
        row={'metadata_NOT_A_PREDICTOR':{}, 'allowed_decision_time_features':values}
        scores=scores_from_feature_row(row,True)
        self.assertEqual(scores['REMOTE_MAX_QUEUE_PACKETS'],3)
        self.assertEqual(scores['REMOTE_SUM_QUEUE_PACKETS'],6)
        self.assertEqual(scores['REMOTE_NONEMPTY_SITES'],3)


if __name__=='__main__':
    unittest.main()
