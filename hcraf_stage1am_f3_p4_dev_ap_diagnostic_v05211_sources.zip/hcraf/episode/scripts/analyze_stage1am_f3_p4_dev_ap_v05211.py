#!/usr/bin/env python3
"""P4/P8: no-training, post-hoc exploratory AP on v0.52.10 DEV only.

Average Precision follows registered v0.52.0 convention. Four independent
seed clusters; all metadata excluded from main predictive scores. No model
fitting, threshold selection, official F3 result, Validation or Test release.
"""
import argparse
from collections import defaultdict
import csv
import hashlib
import json
import math
from pathlib import Path
import zipfile


PARENT_RUN = 44579295748
PARENT_ARTIFACT = 14557443309
PARENT_COMMIT = "3bde9e58753982d0cfcd57c5f5b38c2b60ed3622"
PARENT_SHA256 = "4c8e7d1b065d0d7dcbaadc098c3c21b47b2d3a836ecba7276b8e2ed827e02d0e"
PARENT_NAME = "hcraf-f3-p4-posthoc-dev-forensic-v05210-run-44579295748"
ROOT = "stage1am_f3_p4_posthoc_dev_v05210/"
SEEDS = (23201, 23202, 23203, 23204)
SITES = ("producer_egress", "transit_middle", "consumer_ingress")
TELEMETRIES = ("off", "on_20ms")
LOADS = ("low_control", "high_pressure")
SCIENTIFIC_LOCKS = dict(Congestion=None, FutureCongestion=None, F3_ready=False,
                        GO_FREEZE=False, training_ready=False,
                        heldout_release_authorized=False)


def require(condition, reason):
    if not condition:
        raise RuntimeError("P4P8_" + reason)


def sha256_file(path):
    sha = hashlib.sha256()
    with open(path, "rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            sha.update(chunk)
    return sha.hexdigest()


def average_precision(y, scores):
    """Noninterpolated AP: sum over distinct descending score ties of Δrecall×precision.

    All one-class strata return None, including all positive. Under fixed
    score ties, treating a tie group jointly avoids arbitrary row ordering.
    """
    require(len(y) == len(scores) and len(y) > 0, "AP_LENGTH_MISMATCH")
    require(all(label in (0, 1) for label in y), "AP_NON_BINARY_LABEL")
    require(all(math.isfinite(float(s)) for s in scores), "AP_INVALID_SCORE")
    positives = sum(y)
    if positives == 0 or positives == len(y):
        return None
    indexed = sorted(zip(scores, y), key=lambda item: item[0], reverse=True)
    tp = seen = 0
    ap = 0.0
    i = 0
    while i < len(indexed):
        same = indexed[i][0]
        group_tp = 0
        j = i
        while j < len(indexed) and indexed[j][0] == same:
            group_tp += indexed[j][1]
            j += 1
        tp += group_tp
        seen += j - i
        ap += group_tp / positives * (tp / seen)
        i = j
    require(0 <= ap <= 1, "AP_OUT_OF_RANGE")
    return ap


def scores_from_feature_row(feature, allow_remote):
    """Registered *fixed* formulas; no labels, metadata, or training used here."""
    p = feature["allowed_decision_time_features"]
    require(set(feature) == {"metadata_NOT_A_PREDICTOR", "allowed_decision_time_features"},
            "FEATURE_SCHEMA_OR_FUTURE_COLUMN_CHANGED")
    require(not any("future" in k.lower() for k in p), "FUTURE_COLUMN_IN_PREDICTORS")
    local = float(p["local_selected_queue_fraction"])
    require(math.isfinite(local) and 0 <= local <= 1, "INVALID_LOCAL_QUEUE_FRACTION")
    scores = {"CONSTANT_PREVALENCE": 0.0,
              "LOCAL_QUEUE_FRACTION": local}
    if allow_remote:
        roles = ("relay", "mid", "producer")
        require(all(p[role + "_telemetry_missing"] is False for role in roles),
                "P4P8_REMOTE_REPORT_MISSING_MUST_NOT_BE_SILENTLY_IMPUTED")
        queues = [float(p[role + "_queue_packets"]) for role in roles]
        historical_drops = [float(p[role + "_queue_drops_observed_total"]) for role in roles]
        require(all(math.isfinite(q) and q >= 0 for q in queues + historical_drops),
                "INVALID_ONLINE_REMOTE_QUEUE_DATA")
        for role in roles:
            age = p[role + "_telemetry_age_ms"]
            require(age is not None and 0 <= age <= 100, "REMOTE_TELEMETRY_STALE")
        scores.update({"REMOTE_MAX_QUEUE_PACKETS": max(queues),
                       "REMOTE_SUM_QUEUE_PACKETS": sum(queues),
                       "REMOTE_NONEMPTY_SITES": sum(q > 0 for q in queues),
                       "PAST_CUMULATIVE_QUEUE_DROPS": sum(historical_drops)})
    else:
        require(all(p[role + "_telemetry_missing"] is True and
                    p[role + "_queue_packets"] is None and
                    p[role + "_queue_drops_observed_total"] is None and
                    p[role + "_telemetry_age_ms"] is None
                    for role in ("relay", "mid", "producer")),
                "OFF_ARM_HAS_REMOTE_OBSERVATIONS")
    return scores


def analysis(archive_zip, output_dir):
    require(sha256_file(archive_zip) == PARENT_SHA256, "WRONG_V05210_GITHUB_ARTIFACT_SHA")
    require(not output_dir.exists(), "REFUSE_OVERWRITE_PREVIOUS_P4P8_ANALYSIS")
    with zipfile.ZipFile(archive_zip) as z:
        require(z.testzip() is None, "BAD_PARENT_ZIP_CRC")
        require(len(z.namelist()) == len(set(z.namelist())), "PARENT_ZIP_DUPLICATE_ENTRY")
        for record in z.read(ROOT + "P4P7_OUTPUT_SHA256SUMS.txt").decode().splitlines():
            sha, name = record.split(None, 1)
            require(hashlib.sha256(z.read(ROOT + name.strip())).hexdigest() == sha,
                    "P7_INNER_DERIVED_OUTPUT_SHA_CHANGED")
        parent = json.loads(z.read(ROOT + "P4P7_POSTHOC_DEV_FORENSIC_AUDIT.json"))
        require(parent["status"] == "PASS_POSTHOC_DEV_FORENSIC_RECONSTRUCTION_ONLY" and
                parent["v0529_original_preregistered_status"] ==
                "NO_GO_REVISED_DEV_FOUR_SEEDS_PHYSICAL_OR_CONTROL_FAILURE" and
                parent["posthoc_amendment_after_parent_result_observed"] is True,
                "PREREGISTERED_NO_GO_WAS_RELABELED")
        require(parent["parent_run_id"] == 44541671109 and
                parent["parent_artifact_id"] == 14543216459 and
                parent["parent_artifact_sha256"] ==
                "ae7ce3870016be927f06e4c1d6ffc058f251f9075386b0a508bbd585e1b02f9a",
                "P7_PARENT_OF_PARENT_CHANGED")
        require(parent["num_new_simulations"] == 0 and
                parent["official_F3_labels_constructed"] == 0 and
                parent["F3_PR_AUC_computed"] is False and
                parent["training_executed"] is False and
                parent["seeds"] == list(SEEDS), "P7_OUTPUT_SCIENCE_SCOPE_CHANGED")
        for name, value in SCIENTIFIC_LOCKS.items():
            require(parent[name] is value, "P7_SCIENTIFIC_LOCK_" + name)
        f = [json.loads(line) for line in z.read(ROOT + "DEV_FEATURES_ONLY_POSTHOC_v05210.jsonl").splitlines()]
        l = [json.loads(line) for line in z.read(ROOT + "DEV_DIAGNOSTIC_FUTURE_EVENTS_ONLY_POSTHOC_v05210.jsonl").splitlines()]
    require(len(f) == len(l) == 5184, "P7_RECONSTRUCTION_LOST_EPISODES")
    groups = defaultdict(list)
    keys = set()
    for feature, label in zip(f, l):
        metadata = feature["metadata_NOT_A_PREDICTOR"]
        key = metadata["row_key"]
        require(key not in keys and label["row_key"] == key and
                label["DIAGNOSTIC_ONLY_not_official_F3"] is True,
                "LABEL_FEATURE_PAIRING_OR_LEAKAGE")
        keys.add(key)
        seed, site, load, telemetry = (metadata[k] for k in ("seed", "site", "load", "telemetry"))
        require(seed in SEEDS and site in SITES and load in LOADS and
                telemetry in TELEMETRIES, "UNAUTHORIZED_PARTITION_OR_POSITION")
        y = label["retrospective_future_selected_path_QUEUE_DROP_75ms"]
        require(y in (0, 1) and label["retrospective_future_drop_event_count"] >= y,
                "DIAGNOSTIC_LABEL_INVALID")
        fixed = scores_from_feature_row(feature, allow_remote=(telemetry == "on_20ms"))
        # Time is available at decision, but used only in *explicitly named*
        # calendar/time controls. No seed, site, load, or traffic-type predictor.
        t = float(metadata["decision_ns"])
        fixed["TIME_ASCENDING_BASELINE"] = t
        fixed["TIME_DESCENDING_BASELINE"] = -t
        groups[(seed, site, load, telemetry)].append((y, fixed))
    require(len(groups) == 48 and all(len(rows) == 108 for rows in groups.values()),
            "ALL_48_STRATA_NOT_PRESERVED")
    require(sum(y for rows in groups.values() for y, _ in rows) == 1466,
            "P7_FUTURE_LABEL_COUNTS_CHANGED")
    output_dir.mkdir(parents=True, exist_ok=False)
    details = []
    for seed in SEEDS:
        for site in SITES:
            for load in LOADS:
                for telemetry in TELEMETRIES:
                    rows = groups[(seed, site, load, telemetry)]
                    ys = [row[0] for row in rows]
                    measures = {name: average_precision(ys, [r[1][name] for r in rows])
                                for name in rows[0][1]}
                    report = dict(seed=seed, site=site, load=load, telemetry=telemetry,
                                  episode_count=108, positives=sum(ys),
                                  negatives=108-sum(ys), prevalence=sum(ys)/108,
                                  AP_exploratory_development_only=measures,
                                  AP_one_class_undefined=(sum(ys) in (0,108)))
                    details.append(report)
    high_on = [row for row in details if row["load"] == "high_pressure" and row["telemetry"] == "on_20ms"]
    high_off = [row for row in details if row["load"] == "high_pressure" and row["telemetry"] == "off"]
    require(len(high_on) == len(high_off) == 12 and
            all(row["AP_one_class_undefined"] is False for row in high_on+high_off),
            "HIGH_PRESSURE_CLASS_VARIATION_LOST")
    metric_names = list(high_on[0]["AP_exploratory_development_only"])
    macro = {name: sum(row["AP_exploratory_development_only"][name] for row in high_on)/12
             for name in metric_names}
    by_seed = {str(seed): {name: sum(row["AP_exploratory_development_only"][name]
                                      for row in high_on if row["seed"] == seed)/3
                            for name in metric_names} for seed in SEEDS}
    minus_seed = {str(seed): {name: sum(row["AP_exploratory_development_only"][name]
                                        for row in high_on if row["seed"] != seed)/9
                              for name in metric_names} for seed in SEEDS}
    off_macro = {name: sum(row["AP_exploratory_development_only"][name]
                           for row in high_off)/12
                 for name in high_off[0]["AP_exploratory_development_only"]}
    # Explicitly show whether scores exceed the *same stratum's* baseline;
    # no significance test based on 108 overlapping windows is permitted.
    excess = {name: macro[name]-macro["CONSTANT_PREVALENCE"] for name in metric_names}
    status = dict(status="PASS_POSTHOC_EXPLORATORY_DEV_AP_NO_MODEL_NO_CONFIRMATION",
                  parent_run_id=PARENT_RUN, parent_artifact_id=PARENT_ARTIFACT,
                  parent_commit=PARENT_COMMIT, parent_sha256=PARENT_SHA256,
                  parent_original_v0529_NO_GO_unchanged=True,
                  score_selection_made_from_outcomes=False,
                  scores_fixed_pre_analysis_using_only_online_fields=True,
                  AP_convention="NONINTERPOLATED_AVERAGE_PRECISION_TIE_GROUPED",
                  AP_official_F3_computed=False,
                  AP_development_exploratory_computed=True,
                  model_training_executed=False,
                  num_seed_blocks=4, all_48_conditions_retained=True,
                  num_episodes=5184, high_on_telemetry_strata=12,
                  high_off_telemetry_control_strata=12,
                  all_high_strata_both_classes=True,
                  low_single_class_AP_is_null=True,
                  scoring_primary_group="HIGH_PRESSURE_AND_TELEMETRY_ON_ONLY",
                  confounding_controls="LOCAL_QUEUE,TIME_ASCENDING,TIME_DESCENDING,CONSTANT",
                  macro_AP_per_high_on_stratum=macro,
                  macro_AP_minus_within_stratum_prevalence=excess,
                  macro_AP_high_off_strata=off_macro,
                  mean_AP_per_independent_seed_block=by_seed,
                  leave_one_seed_out_macro_AP_sensitivity=minus_seed,
                  physical_gates_still_failed_in_original_v0529=True,
                  temporal_overlap_dependent_episodes=True,
                  cannot_claim_predictability_or_generalization_from_dev=True,
                  official_F3_labels_constructed=0,
                  F3_PR_AUC_computed=False, training_executed=False,
                  validation_seeds_consumed=0, heldout_seeds_consumed=0,
                  **SCIENTIFIC_LOCKS)
    (output_dir / "P4P8_DEV_AP_EXPLORATORY_SUMMARY.json").write_text(
        json.dumps(status, sort_keys=True, indent=2, ensure_ascii=False) + "\n")
    (output_dir / "P4P8_DEV_AP_PER_STRATUM.json").write_text(
        json.dumps(details, sort_keys=True, indent=2, ensure_ascii=False) + "\n")
    out_cols = ["seed", "site", "load", "telemetry", "episode_count", "positives", "negatives", "prevalence"]
    score_names = ["CONSTANT_PREVALENCE", "LOCAL_QUEUE_FRACTION", "TIME_ASCENDING_BASELINE",
                   "TIME_DESCENDING_BASELINE", "REMOTE_MAX_QUEUE_PACKETS",
                   "REMOTE_SUM_QUEUE_PACKETS", "REMOTE_NONEMPTY_SITES",
                   "PAST_CUMULATIVE_QUEUE_DROPS"]
    with (output_dir / "P4P8_DEV_AP_PER_STRATUM.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(out_cols + ["AP_" + name for name in score_names])
        for row in details:
            writer.writerow([row[c] for c in out_cols] +
                            [row["AP_exploratory_development_only"].get(name) for name in score_names])
    (output_dir / "P4P8_SCIENTIFIC_LOCKS.txt").write_text(
        "v0.52.9 prereg NO_GO persists; v0.52.10 posthoc DEV only; v0.52.11 "
        "AP is purely exploratory and has no trained model or final F3 metric.\n"+
        "No official labels, no Validation, no Test, no Stage1AO, no NSGA-III.\n"+
        str(SCIENTIFIC_LOCKS)+"\n")
    output_paths = sorted(path for path in output_dir.iterdir() if path.is_file())
    (output_dir / "P4P8_SHA256SUMS.txt").write_text(
        "".join(sha256_file(path)+"  "+path.name+"\n" for path in output_paths))
    print("P4P8_EXPLORATORY_AP_SUMMARY", json.dumps({
        "baseline":macro["CONSTANT_PREVALENCE"],
        "local":macro["LOCAL_QUEUE_FRACTION"],
        "remote_max":macro["REMOTE_MAX_QUEUE_PACKETS"],
        "remote_sum":macro["REMOTE_SUM_QUEUE_PACKETS"],
        "time_ascending":macro["TIME_ASCENDING_BASELINE"],
        "time_descending":macro["TIME_DESCENDING_BASELINE"],
        "independent_seeds":4, "strata_high_on":12,
        "status":status["status"]}, sort_keys=True), flush=True)
    return status


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--parent-zip", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    analysis(args.parent_zip, args.output)


if __name__ == "__main__":
    main()
