#!/usr/bin/env python3
"""Four DEV-only physical queue-capacity feasibility probes, never F3 calibration.

The registered v0.52.0 traffic *schedule* is reused but the physical queue
capacity is deliberately changed.  The results cannot enter preregistration,
training, Validation/Test, or any F3 scientific metric.
"""
import argparse
from bisect import bisect_right
from collections import Counter
import json
import pathlib
import subprocess

from run_stage1am_f3_future_path_queue_calibration_v0521 import (
    ROOT, locked_plan, assert_send_plan, check, LOCKS,
)
from run_stage1am_f3_queue_telemetry_smoke_v0522 import (
    BIN, selections, spec, verify_transport,
)
from validate_online_queue_telemetry_v0522 import read_lines

DEST = ROOT / "episode_output/stage1am_f3_queue_pressure_feasibility_v0523"
CAPACITIES = (12, 8)
PROFILES = (("baseline", False), ("telemetry20", True))
HORIZON_NS = 75_000_000  # Read-only diagnostic window; NOT the official F3 label.
ROLES = ("selected_relay_node_id", "selected_mid_node_id",
         "selected_producer_node_id")


def fixture():
    row = next(r for r in selections() if r["arm"] == "PRODUCER_RETURN_12M")
    check(str(row["rng_block"]) == "22001" and
          row["family"] == "C_STAGGERED_BURSTS" and
          row["instrumented"] == "1", "P3_UNEXPECTED_HISTORICAL_TRAFFIC_FIXTURE")
    check(row["split"] == "CALIBRATION", "P3_NON_CALIBRATION_FIXTURE")
    return row


def independent_queue_audit(dest, config):
    """Only independent physical witness B; NOT queue telemetry or an F3 label."""
    witness = dest / "pathwide_witness_b.jsonl"
    decisions_file = dest / "events.jsonl.decisions.jsonl"
    check(witness.is_file() and decisions_file.is_file(),
          "P3_MISSING_INDEPENDENT_PHYSICAL_WITNESS_OR_DECISIONS")
    senders = {int(config[key]): role for key, role in zip(ROLES, ("relay", "mid", "producer"))}
    check(len(senders) == 3 and config["selected_face_slot"] == 0,
          "P3_SELECTED_RETURN_PATH_INCONSISTENT")
    per_sender = {name: {"node_id": node, "device_index": 0,
                         "enqueues": 0, "drops": 0, "max_queue_packets": 0,
                         "last_cumulative_drop": 0}
                  for node, name in senders.items()}
    selected_drop_times = []
    physical_drops_any_device = 0
    invalid_witness = 0
    last_drop_cum = {}
    seen_any = False
    for event in read_lines(witness):
        check(event.get("schema_version") == "PATHWIDE_WITNESS_B.1" and
              event.get("monitor_id") == "B", "P3_WRONG_WITNESS_SCHEMA")
        seen_any = True
        node = int(event["node_id"])
        dev = int(event["device_index"])
        kind = event["event_type"]
        cumulative = int(event["drop_packets_cumulative"])
        key = (node, dev)
        prior = last_drop_cum.get(key, 0)
        check(cumulative >= prior, "P3_WITNESS_DROP_COUNTER_DECREASED")
        diff = cumulative - prior
        if kind == "QUEUE_DROP":
            physical_drops_any_device += 1
            if diff != 1:
                invalid_witness += 1
        elif diff:
            # Cumulative increments and event type must agree before reporting.
            invalid_witness += 1
        last_drop_cum[key] = cumulative
        if node not in senders or dev != 0:
            continue
        role = senders[node]
        info = per_sender[role]
        info["max_queue_packets"] = max(info["max_queue_packets"],
                                        int(event["queue_packets"]))
        info["last_cumulative_drop"] = cumulative
        if kind == "QUEUE_ENQUEUE":
            info["enqueues"] += 1
        elif kind == "QUEUE_DROP":
            info["drops"] += 1
            selected_drop_times.append(int(event["timestamp_ns"]))
    check(seen_any and invalid_witness == 0, "P3_INVALID_OR_EMPTY_INDEPENDENT_DROP_WITNESS")
    for info in per_sender.values():
        check(info["drops"] == info["last_cumulative_drop"],
              "P3_SELECTED_SENDER_DROP_COUNT_DISAGREES_WITH_CUMULATIVE")
    selected_drop_times.sort()
    times = []
    for decision in read_lines(decisions_file):
        check(decision["node_id"] == 1 and
              decision["name"].startswith(("/hcraf/pilot/", "/hcraf/competitor/")),
              "P3_RESEARCH_DECISION_CONTAMINATED_BY_CONTROL_TRAFFIC")
        times.append(int(decision["time_ns"]))
    check(len(times) > 0, "P3_NO_RESEARCH_DECISIONS")
    # (t, t+75ms] diagnostic only. No negative-label inference, no censoring claim.
    windows = sum(bisect_right(selected_drop_times, t + HORIZON_NS) >
                  bisect_right(selected_drop_times, t) for t in times)
    return {
        "independent_physical_witness": "PATHWIDE_WITNESS_B.1",
        "selected_return_senders_device_0": per_sender,
        "selected_path_physical_queue_drop_events": len(selected_drop_times),
        "all_physical_devices_queue_drop_events": physical_drops_any_device,
        "research_decisions": len(times),
        "decisions_with_future_selected_path_queue_drop_in_75ms_diagnostic_window": windows,
        "diagnostic_window_rule": "(decision_ns,decision_ns+75000000ns]",
        "diagnostic_windows_are_not_scientific_F3_labels": True,
        "official_F3_labels_constructed": 0,
    }


def run_one(row, capacity, name, enabled):
    dest = DEST / ("queue_%02dp" % capacity) / name
    dest.mkdir(parents=True, exist_ok=False)
    command = spec(row, dest, 20, enabled) + " --technicalQueueMaxPackets=%d" % capacity
    (dest / "command.txt").write_text(command + "\n")
    fixture_info = {
        "historical_traffic_schedule": row,
        "p3_DEV_UNREGISTERED_GLOBAL_PHYSICAL_QUEUE_CAPACITY": capacity,
        "registered_v0520_reference_queue_capacity": 20,
        "scientific_partition": "NOT_AN_OFFICIAL_CALIBRATION_RUN",
        "technical_monitoring": enabled,
        "heldout_runs_executed": 0,
        **LOCKS,
    }
    (dest / "p3_deviation_from_locked_scenario.json").write_text(
        json.dumps(fixture_info, indent=2) + "\n")
    with (dest / "simulator.log").open("w") as log:
        subprocess.run(["/usr/bin/time", "-f", "wall_seconds=%e\\nmax_rss_kib=%M",
                        "-o", str(dest / "resource_usage.txt"), "python3", "./waf",
                        "--run-no-build", command], cwd=ROOT / "episode_sources/ns-3",
                       stdout=log, stderr=subprocess.STDOUT, check=True)
    assert_send_plan(dest, locked_plan(row))
    config = json.loads((dest / "scenario.json").read_text())
    check(config["holdout_partition"] == "CALIBRATION" and
          config["technical_queue_max_packets"] == capacity and
          config["queue_capacity_packets"] == capacity and
          config["v0520_locked_reference_queue_capacity_packets"] == 20 and
          config["p3_dev_global_queue_cap_override_not_in_v0520_lock"] is True and
          config["p3_queue_capacity_intervention_is_exploratory_only"] is True and
          config["only_locked_physical_intervention_varies"].startswith("NO_P3_DEV") and
          config["purpose"].startswith("P3_DEV_QUEUE_CAP_FEASIBILITY") and
          config["selected_face_slot"] == 0 and
          config["telemetry_enabled"] is enabled,
          "P3_UNMARKED_QUEUE_CAPACITY_DEVIATION_OR_SCENARIO_MISMATCH")
    for key, value in LOCKS.items():
        check(config[key] is value, "P3_SCIENCE_LOCK_VIOLATED:" + key)
    physical = independent_queue_audit(dest, config)
    transport = {"telemetry_contract_pass": False}
    if enabled:
        try:
            transport = verify_transport(dest, True)
            transport["telemetry_contract_pass"] = True
        except (AssertionError, ValueError, RuntimeError, KeyError, OSError) as exc:
            # Real drops may make 3-of-3 NDN telemetry unavailable. This is
            # informative failure, not permission to forge missing receipts.
            transport["technical_transport_contract_error"] = str(exc)
    else:
        check(not (dest / "queue_telemetry_receipts.jsonl").exists(),
              "P3_BASELINE_HAS_TELEMETRY_RECEIPTS")
        transport.update(telemetry_enabled=False, telemetry_contract_pass=None)
    result = {
        "queue_capacity_packets": capacity,
        "profile": name,
        "telemetry_enabled": enabled,
        "physical": physical,
        "transport": transport,
        "science_claim": "NONE_P3_UNREGISTERED_TECHNICAL_FEASIBILITY_ONLY",
        "heldout_runs_executed": 0,
        **LOCKS,
    }
    (dest / "p3_physical_pressure_audit.json").write_text(
        json.dumps(result, indent=2) + "\n")
    return result


def summarize(results):
    pairs = []
    for capacity in CAPACITIES:
        base = next(r for r in results if r["queue_capacity_packets"] == capacity and
                    r["profile"] == "baseline")
        telemetry = next(r for r in results if r["queue_capacity_packets"] == capacity and
                         r["profile"] == "telemetry20")
        drop_b = base["physical"]["selected_path_physical_queue_drop_events"]
        drop_t = telemetry["physical"]["selected_path_physical_queue_drop_events"]
        window_b = base["physical"]["decisions_with_future_selected_path_queue_drop_in_75ms_diagnostic_window"]
        window_t = telemetry["physical"]["decisions_with_future_selected_path_queue_drop_in_75ms_diagnostic_window"]
        pairs.append({"capacity_packets": capacity,
                      "baseline_selected_path_drops": drop_b,
                      "telemetry20_selected_path_drops": drop_t,
                      "baseline_positive_diagnostic_windows": window_b,
                      "telemetry20_positive_diagnostic_windows": window_t,
                      "both_arms_have_physical_drops": drop_b > 0 and drop_t > 0,
                      "both_arms_have_future_drop_windows": window_b > 0 and window_t > 0,
                      "telemetry_transport_contract_pass": telemetry["transport"].get(
                          "telemetry_contract_pass"),
                      "paired_scenario_is_not_preregistered": True})
    both = [p for p in pairs if p["both_arms_have_future_drop_windows"]]
    return {"status": "P3_DEV_QUEUE_CAPACITY_FEASIBILITY_ONLY_SCIENCE_GATE_CLOSED",
            "technical_experiment": "GLOBAL_8P_AND_12P_QUEUE_CAPACITIES_WITH_BASELINE_AND_NDN_TELEMETRY20",
            "simulations": len(results),
            "observed_paired_future_drop_feasibility": len(both) > 0,
            "paired_capacity_results": pairs,
            "results": results,
            "historical_v0520_calibration_schedule_reused": True,
            "v0520_physical_matrix_preserved_unchanged": True,
            "P3_queue_capacities_not_in_v0520_lock": [8, 12],
            "P3_results_excluded_from_preregistered_calibration": True,
            "official_F3_labels_constructed": 0,
            "heldout_runs_executed": 0,
            "model_training_executed": False,
            **LOCKS}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--preflight-only", action="store_true")
    args = parser.parse_args()
    row = fixture()
    if args.preflight_only:
        print(json.dumps({"status": "P3_DEV_CAPACITY_FIXTURE_PREFLIGHT_ONLY",
                          "historically_seen_rng": row["rng_block"],
                          "historically_seen_family": row["family"],
                          "historically_seen_arm": row["arm"],
                          "capacity_packets": list(CAPACITIES),
                          "profiles": [p[0] for p in PROFILES],
                          "simulations_planned": 4,
                          "global_physical_queue_cap_deviates_from_v0520": True,
                          "heldout_runs_executed": 0, **LOCKS}, indent=2))
        return
    check((ROOT / "episode_sources/ns-3/build/scratch" / BIN).is_file(),
          "P3_NDNSIM_CXX_BINARY_MISSING")
    check(not DEST.exists(), "P3_REFUSE_OVERWRITE_PREVIOUS_EXPERIMENT")
    results = []
    for capacity in CAPACITIES:
        for name, enabled in PROFILES:
            result = run_one(row, capacity, name, enabled)
            results.append(result)
            print("P3_TECHNICAL_SIMULATION_COMPLETE", capacity, name,
                  "physical_queue_drops=", result["physical"][
                      "selected_path_physical_queue_drop_events"], flush=True)
    report = summarize(results)
    (DEST / "p3_dev_queue_pressure_feasibility_summary.json").write_text(
        json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k != "results"}, indent=2))


if __name__ == "__main__":
    main()
