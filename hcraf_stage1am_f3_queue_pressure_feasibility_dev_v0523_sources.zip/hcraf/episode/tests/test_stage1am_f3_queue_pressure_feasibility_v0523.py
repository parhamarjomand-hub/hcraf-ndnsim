"""P3 feasibility selftests; full ndnSIM remains mandatory on GitHub."""
import ast
from bisect import bisect_right
from collections import Counter
import json
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[3]
CPP = ROOT / "hcraf/episode/src/hcraf-stage1am-f3-queue-telemetry-smoke-v0522.cpp"
SCRIPT = ROOT / "hcraf/episode/scripts/run_stage1am_f3_queue_pressure_feasibility_v0523.py"
DOC = ROOT / "hcraf/episode/docs/1AM/F3_CAUSAL_TELEMETRY_DEV_v0.52.3/P3_DEV_PROTOCOL_FA.md"


def load_queue_audit_in_isolation():
    """Extract the actual function, so the selftest needs no simulator install."""
    tree = ast.parse(SCRIPT.read_text())
    function = next(n for n in tree.body if isinstance(n, ast.FunctionDef)
                    and n.name == "independent_queue_audit")
    namespace = {
        "bisect_right": bisect_right, "ROLES": (
            "selected_relay_node_id", "selected_mid_node_id",
            "selected_producer_node_id"), "HORIZON_NS": 75_000_000,
        "read_lines": lambda path: (json.loads(s) for s in path.read_text().splitlines() if s),
        "check": lambda passed, reason: None if passed else (_ for _ in ()).throw(
            AssertionError(reason)),
    }
    exec(compile(ast.Module(body=[function], type_ignores=[]), str(SCRIPT), "exec"), namespace)
    return namespace["independent_queue_audit"]


class P3QueueFeasibility(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cpp = CPP.read_text()
        cls.script = SCRIPT.read_text()

    def test_01_queue_capacity_override_whitelist_and_default(self):
        for part in ("uint32_t technicalQueueMaxPackets = 20;",
                     "technicalQueueMaxPackets!=8 && technicalQueueMaxPackets!=12 && technicalQueueMaxPackets!=20",
                     "--technicalQueueMaxPackets=%d"):
            self.assertIn(part, self.script if part.startswith("--") else self.cpp)
        self.assertIn('StringValue(std::to_string(technicalQueueMaxPackets)+"p")', self.cpp)

    def test_02_schema_marks_unregistered_physical_change(self):
        for part in ("p3_dev_global_queue_cap_override_not_in_v0520_lock",
                     "p3_queue_capacity_intervention_is_exploratory_only",
                     "v0520_locked_reference_queue_capacity_packets",
                     "P3_DEV_UNREGISTERED_QUEUE_CAP_WITH_REUSED_V0520_CALIBRATION_TRAFFIC_CSV",
                     "P3_DEV_QUEUE_CAP_FEASIBILITY_NOT_REGISTERED_CALIBRATION"):
            self.assertIn(part, self.cpp)
        self.assertIn('<< technicalQueueMaxPackets', self.cpp)
        self.assertIn('v0523-P3-DEV-globalqueue-', self.cpp)

    def test_03_control_transport_excluded_from_research_nfd(self):
        self.assertIn('NFD_decision_stream_includes_control_interests\\\":false', self.cpp)
        self.assertIn('NFD_telemetry_control_excluded_from_research_recorder\\\":true', self.cpp)
        self.assertIn('v0.52.2-P1-pinned-recorder-scope', self.cpp)
        self.assertIn('/hcraf-queue-telemetry', self.cpp)
        self.assertNotIn('/hcraf/telemetry', self.cpp)

    def test_04_no_heldout_training_or_science_unlock(self):
        self.assertNotIn('HELDOUT_CONFIRMATORY', self.script)
        self.assertIn('"heldout_runs_executed": 0', self.script)
        self.assertIn('"official_F3_labels_constructed": 0', self.script)
        self.assertIn('"model_training_executed": False', self.script)
        self.assertIn('"P3_results_excluded_from_preregistered_calibration": True', self.script)
        self.assertIn('Congestion=null', DOC.read_text())

    def test_05_genuine_queue_drops_and_future_window_only(self):
        fn = load_queue_audit_in_isolation()
        with tempfile.TemporaryDirectory() as td:
            folder = Path(td)
            config = {"selected_face_slot": 0,
                      "selected_relay_node_id": 2,
                      "selected_mid_node_id": 7,
                      "selected_producer_node_id": 8}
            events = [
                (2, "INITIAL", 0, 0, 0, 0),
                (7, "INITIAL", 0, 0, 0, 0),
                (8, "INITIAL", 0, 0, 0, 0),
                (8, "QUEUE_ENQUEUE", 10, 1, 0, 0),
                (8, "QUEUE_DROP", 30, 1, 1, 0),
                (2, "QUEUE_ENQUEUE", 50, 1, 0, 0),
            ]
            with (folder / "pathwide_witness_b.jsonl").open("w") as f:
                for node, kind, when, queue, drops, device in events:
                    f.write(json.dumps({"schema_version": "PATHWIDE_WITNESS_B.1",
                                        "monitor_id": "B", "node_id": node,
                                        "device_index": device, "event_type": kind,
                                        "timestamp_ns": when,
                                        "queue_packets": queue,
                                        "drop_packets_cumulative": drops}) + "\n")
            with (folder / "events.jsonl.decisions.jsonl").open("w") as f:
                for when in (0, 30, 50):
                    f.write(json.dumps({"node_id": 1, "name": "/hcraf/pilot/1",
                                        "time_ns": when}) + "\n")
            physical = fn(folder, config)
            self.assertEqual(physical["selected_path_physical_queue_drop_events"], 1)
            self.assertEqual(physical["decisions_with_future_selected_path_queue_drop_in_75ms_diagnostic_window"], 1)
            self.assertEqual(physical["selected_return_senders_device_0"]["producer"]["drops"], 1)
            self.assertEqual(physical["official_F3_labels_constructed"], 0)

    def test_06_counter_mismatch_is_fail_closed(self):
        fn = load_queue_audit_in_isolation()
        with tempfile.TemporaryDirectory() as td:
            folder = Path(td)
            (folder / "pathwide_witness_b.jsonl").write_text(json.dumps({
                "schema_version": "PATHWIDE_WITNESS_B.1", "monitor_id": "B",
                "node_id": 8, "device_index": 0, "event_type": "QUEUE_ENQUEUE",
                "timestamp_ns": 1, "queue_packets": 1,
                "drop_packets_cumulative": 1}) + "\n")
            (folder / "events.jsonl.decisions.jsonl").write_text(json.dumps({
                "node_id": 1, "name": "/hcraf/pilot/0", "time_ns": 0}) + "\n")
            with self.assertRaisesRegex(AssertionError, "P3_INVALID_OR_EMPTY_INDEPENDENT_DROP_WITNESS"):
                fn(folder, {"selected_face_slot": 0, "selected_relay_node_id": 2,
                            "selected_mid_node_id": 7, "selected_producer_node_id": 8})


if __name__ == "__main__":
    unittest.main()
