# قرارداد علمی و مهندسی HCRAF — مرحله 1T (v0.18.0)

## دامنه و ورودی معتبر

پایۀ این مرحله، **Artifact واقعی و تأییدشده 1S v0.17.0** با ۱۲ اجرای ndnSIM است. تحلیل 1T کاملاً آفلاین است؛ نه سناریوی جدید اجرا شده، نه NFD patch یا استراتژی HCRAF تغییر یافته و نه به ورودی الگوریتم آنلاین ویژگی جدیدی اضافه شده است.

## مسئله

در 1S پیوند Interest خروجی و Episode قابل‌ممیزی بود، ولی بازبین محافظه‌کار، Data را تنها بر اساس Name به PIT نسبت نمی‌داد؛ در نتیجه ۴۸ وضعیت `UNRESOLVED_REPEATED_NAME` و ۴۸ وضعیت `NOT_ASSIGNED_BY_NAME_ONLY` باقی ماندند. این ابهام صرفاً یک مشکل JOIN در ابزار تحلیل بود؛ وجود یا عدم وجود شاهد خام را باید مستقل وارسی کرد.

## قرارداد انتساب موفق

برای مثبت‌کردن وضعیت `MATCHED_UNIQUE_PIT_DATA` تمام شروط زیر باید برقرار باشند:

۱. رویداد `DATA_MATCH` واقعی NFD حاوی `(node=1, pit_instance_id, name, ingress_face_id, time_ns)` موجود باشد. یک رویداد `PIT_SATISFIED` هم‌نام، هم‌PIT، هم‌Face، هم‌زمان و متأخر در ترتیب رویدادها باید آن را تأیید کند.

۲. Episode واقعی `(PIT, Name, Face)` باید یکتا، دارای Outcome=`SUCCESS`، دلیل پایان `PIT_SATISFIED_THIS_FACE`، `terminal_event_seq` سازگار و `end_ns` دقیقاً مطابق رویداد `DATA_MATCH` باشد.

۳. در Trace همان روتر، دقیقاً یک `MAC_RX` از نوع `DATA` با `wire_status=PILOT`، همان نام، همان Face و همان نانوثانیه وجود داشته باشد. UID بسته فقط در دامنه `(node_id, device_index, packet_uid)` معتبر است.

۴. بر اساس توپولوژی واقعی سناریو و زوج NetDeviceها، دقیقاً یک ارسال `PHY_TX_END` از جهت فیزیکی مقابل قابل تأیید باشد. این بازسازی در توپولوژی *point-to-point، FIFO و بدون ابهام در پنجره زمانی* معتبر است. UID را بین دو دستگاه برابر فرض نمی‌کنیم.

۵. اگر چند PIT یا چند بسته برای همان کلید/لحظه نامزد باشند، یا شواهد فیزیکی ناقص باشد، خروجی `AMBIGUOUS_*` یا `NOT_OBSERVED_*` می‌ماند؛ هیچ پیوند یکتای حدسی ایجاد نمی‌شود.

## حالت‌های خاص

- **Retransmission:** در یک PIT، ممکن است Episodeِ Face برنده SUCCESS و Episodeِ Face دیگر CANCELLED شود. Data برنده فقط به همان Face دارای `PIT_SATISFIED_THIS_FACE` نسبت داده می‌شود. Data بعدی که NFD آن را `UNSOLICITED_DATA` می‌نامد، به PIT بسته‌شده برنمی‌گردد.
- **PIT aggregation:** یک ارسال خروجی می‌تواند چند Interest ورودی را نمایندگی کند. یک Data دریافت‌شده در روتر، دو Episode خروجی تولید نمی‌کند. در این مرحله انتساب Data به تک‌تک درخواست‌های مصرف‌کننده هدف نیست.
- **Cache hit:** رویداد واقعی `CACHE_HIT` از روتر گزارش می‌شود؛ اما خروجی آن یک Episode از Face بالادستی و دریافت Data از لینک خارجی جدید نیست.
- **Multi-hop:** ارتباط با Router در Face ورودی تأیید می‌شود، نه با برابری Packet UID در دو Hop.

## خروجی‌های معتبر و مرز تعمیم

از ۹۶ Episode، تعداد ۸۸ SUCCESS دارای زنجیره یکتای قابل‌ممیزی و ۸ CANCELLED بدون انتساب Data موفق هستند. از ۴۸ وضعیت قبلی با نام تکراری، ۴۰ SUCCESS اکنون دارای انتساب فیزیکی معتبرند و ۸ CANCELLED همچنان به‌درستی فاقد Data موفق‌اند. ۴۸ وضعیت بدون اتصال قبلی از نوع `NOT_ASSIGNED_BY_NAME_ONLY` نیز با شاهد PIT و لینک به انتساب یکتا می‌رسند.

این نتایج **اثباتِ انتساب عمومی Data در صورت هم‌زمانیِ نام‌های یکسان، collision نانوثانیه‌ای، fragmentation، تغییر مسیر در پرواز یا سناریوی چندگامی پیچیده نیستند**. برای آن موارد باید instrument صریح بسته-به-PIT در ingress NFD و آزمایش مستقل طراحی شود. `DATA_MATCH` خود رخداد واقعی NFD است، ولی شناسه یکتای فیزیکی End-to-End را در تمامی Hopها ایجاد نمی‌کند.

تمامی `Congestion`، `FutureCongestion` و `causal_congestion_attribution` همچنان `null` و `training_ready=false` است. هیچ برچسب F3، دیتاست نهایی، وزن NSGA-III یا نتیجه Gate از 1T استخراج نشده است.

## بازتولید

در محیطی با Python 3.8 یا جدیدتر، `hcraf_stage1t_sources.zip` را استخراج و `hcraf-stage1s-2-1.zip` (ورودی واقعی همراه بسته) را در مسیر جداگانه باز کنید. سپس از پوشه پروژه:

```
python hcraf/episode/scripts/summarize_data_pit_stage1t.py <stage1s_root> --out <output_dir>
python hcraf/episode/scripts/crosscheck_data_pit_stage1t.py <stage1s_root> <output_dir>
```

`<stage1s_root>` همان پوشه `stage1s` استخراج‌شده است. برای اجرای همه تست‌ها متغیر محیطی `HCRAF_STAGE1S_RUN_ROOT` را روی آن مسیر تنظیم کرده و `python -m unittest discover -s hcraf/episode/tests -p 'test_*.py'` اجرا کنید. **مستقیماً روی Artifact خام خروجی ننویسید.**
