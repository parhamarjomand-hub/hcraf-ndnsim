# HCRAF Stage 1Y-A1 — Supplemental paced fragmentation control

**Nature: post-observation amendment (NOT pre-registered); not a correction to historical results.**

The original 1Y v0.23.0 30 monitored runs and six unmonitored paired runs remain unchanged.
The mixed-fragmented control caused 79 QUEUE_DROP and 21 incomplete LP groups in each RngRun.
This is real loss evidence, not a verifier parsing error. The amended control addresses a
separate question: can LP reassembly and PIT binding across two hops be certified when
the 256 kbps return bottleneck is NOT saturated by simultaneous 4096-byte Data bursts?

Only the request inter-arrival interval is changed for this *new*, separately identified
control: 2 ms -> 250 ms (24 requests, 600 B MTU, 4096-byte Data,
256 kbps primary return, seed 17, runs 1001/1002/1003; everything else as v0.23.0).
Three separately matched uninstrumented runs are included for the paired monitoring check.

Acceptance: source integrity; 14 link directions; LP groups with complete indices and
payload; no incomplete LP group, queue drop, unresolved enqueues; at least one explicit PIT
binding at each router; 24 SUCCESS and byte-matched consumer results in each paired run;
three distinct realized arrival hashes. On failure: INCOMPLETE, NOT PASS.

The original mixed-fragmented result remains INCOMPLETE and must not be rewritten. All
F3 labels and training readiness remain UNKNOWN/false. Observing these control events
is NOT proof of path-wide congestion-negative ground truth or of causal congestion labels.

No HCRAF Cost/Reward/Gate, F1..F5, topology/MTU or NFD core logic is changed.
