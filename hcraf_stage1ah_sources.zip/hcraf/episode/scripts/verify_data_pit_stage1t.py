#!/usr/bin/env python3
"""Stage 1T -- fail-closed *offline* NFD DATA_MATCH to physical MAC_RX attribution.

Inputs are REAL, unchanged Stage1S 1S.1 pilot traces.  This does not synthesize
packet identity, assign counterfactual faces, or produce congestion targets.
Works on Python 3.8+ without third-party dependencies.
"""
import argparse
from collections import Counter, defaultdict
import csv
import json
from pathlib import Path
from verify_robustness import validate_graph, MODES

class EvidenceError(ValueError):
    pass

def need(ok, message):
    if not ok:
        raise EvidenceError(message)

def read_jsonl(path):
    result=[]
    for i,line in enumerate(path.read_text(encoding='utf-8').splitlines(),1):
        if line.strip():
            try: obj=json.loads(line)
            except Exception as exc: raise EvidenceError('Malformed %s line %s: %s'%(path.name,i,exc))
            need(isinstance(obj,dict),'Non-object row in '+str(path))
            result.append(obj)
    return result

def read_run(folder):
    folder=Path(folder)
    config=json.loads((folder/'scenario.json').read_text(encoding='utf-8'))
    need(config.get('collector_stage')=='1S.1' and config.get('mode') in MODES,
         'Source must be official Stage 1S pilot, not arbitrary files')
    need(config.get('run') in (1001,1002) and config.get('seed')==17,
         'Unexpected Stage1S run/seed')
    need(config.get('training_ready') is False and
         config.get('final_congestion_label') is None and
         config.get('future_congestion_label') is None and
         config.get('causal_congestion_attribution') is None,
         'Congestion/training contract was changed')
    files={key:read_jsonl(folder/name) for key,name in {
        'nfd':'events.jsonl','link':'link_events.jsonl',
        'episodes':'episodes.jsonl','old':'robustness_return_status.jsonl'
    }.items()}
    return config,files

def physical_index(link):
    rx=defaultdict(list); tx=defaultdict(list); scoped=defaultdict(list)
    for x in link:
        if x.get('ndn_packet_type')!='DATA' or x.get('wire_status')!='PILOT':
            continue
        endpoint=(x['node_id'],x['device_index'])
        k=(x['node_id'],x['face_id'],x['ndn_name'],x['time_ns'])
        if x['event_type']=='MAC_RX':rx[k].append(x)
        if x['event_type']=='PHY_TX_END':tx[(endpoint,x['ndn_name'])].append(x)
        if x['packet_uid'] is not None:
            scoped[(endpoint,x['packet_uid'])].append(x)
    for vals in tx.values():vals.sort(key=lambda x:x['time_ns'])
    return rx,tx,scoped

def sender_proof(packet,link,peer_graph,tx_by_endpoint,device_face):
    receiver=(packet['node_id'],packet['device_index'])
    if receiver not in peer_graph:
        return 'UNKNOWN_LINK',None
    sender=peer_graph[receiver]
    # Only a trace from the *physical opposite direction* qualifies.
    if sender not in device_face:
        return 'UNKNOWN_SENDER',None
    candidates=[r for r in tx_by_endpoint.get((sender,packet['ndn_name']),[]) if
                r['time_ns']<=packet['time_ns']]
    # Cannot use Name alone when it has previously been observed on the same link.
    # In a FIFO one-to-one point-to-point link, the prior MAC_RX of this Name on
    # this receiving endpoint bounds the current frame's causal emission interval.
    earlier_receives=[r for r in link if r['event_type']=='MAC_RX' and
                      (r['node_id'],r['device_index'])==receiver and
                      r['ndn_packet_type']=='DATA' and r['ndn_name']==packet['ndn_name'] and
                      r['link_event_seq']<packet['link_event_seq']]
    prior_time=max((r['time_ns'] for r in earlier_receives),default=-1)
    candidates=[r for r in candidates if r['time_ns']>=prior_time]
    if len(candidates)!=1:
        return ('NOT_OBSERVED_SENDER' if not candidates else 'AMBIGUOUS_SENDER'),None
    return 'MATCHED_UNIQUE_SENDER',candidates[0]

def audit_rows(cfg,info):
    need(cfg.get('training_ready') is False and
         cfg.get('final_congestion_label') is None and
         cfg.get('future_congestion_label') is None and
         cfg.get('causal_congestion_attribution') is None,
         'Unapproved training/congestion target')
    nfd=info['nfd']; link=info['link']; episodes=info['episodes']; old=info['old']
    graph, device_faces=validate_graph(link,cfg['mode'])
    need(len({x['link_event_seq'] for x in link})==len(link),'Duplicate physical event sequence')
    need(len({x['event_seq'] for x in nfd})==len(nfd),'Duplicate NFD event sequence')
    need(all(x['schema_version']=='1R.1' for x in link),'Unknown physical trace schema')
    need(len({e['episode_id'] for e in episodes})==len(episodes),'Duplicate episode IDs')
    need(len(old)==len(episodes),'Stage1S return status count mismatch')
    for x in link:
        need((x['node_id'],x['device_index']) in device_faces and
             device_faces[(x['node_id'],x['device_index'])]==x['face_id'],
             'Physical Face/index mismatch')
    rx_index,tx_index,scoped=physical_index(link)
    for (endpoint,uid),arr in scoped.items():
        identity={(x['ndn_packet_type'],x['ndn_name']) for x in arr}
        need(len(identity)==1,'Contradictory DATA packet UID on a single device')
    matched=[x for x in nfd if x['event_type']=='DATA_MATCH']
    need(all(x['node_id']==1 and x['face_id']>=0 for x in matched),
         'NFD DATA_MATCH from unexpected router or local Face')
    satisfied=[x for x in nfd if x['event_type']=='PIT_SATISFIED']
    cache=[x for x in nfd if x['event_type']=='CACHE_HIT']
    unsolicited=[x for x in nfd if x['event_type']=='UNSOLICITED_DATA']
    received_by_key=defaultdict(list)
    for m in matched:
        received_by_key[(m['node_id'],m['face_id'],m['name'],m['time_ns'])].append(m)
    matches_by_pit=defaultdict(list)
    for m in matched: matches_by_pit[(str(m['pit_instance_id']),m['name'],m['face_id'])].append(m)
    eps_by_pit=defaultdict(list)
    for ep in episodes:eps_by_pit[(str(ep['pit_instance_id']),ep['name'],ep['face_id'])].append(ep)
    # Semantic consistency is required even before considering physical matching.
    for m in matched:
        s=[e for e in satisfied if e['pit_instance_id']==m['pit_instance_id'] and
           e['name']==m['name'] and e['face_id']==m['face_id'] and
           e['time_ns']==m['time_ns'] and e['event_seq']>m['event_seq']]
        need(len(s)==1,'DATA_MATCH lacks unique same-PIT PIT_SATISFIED')
    results=[]
    for ep in episodes:
        key=(str(ep['pit_instance_id']),ep['name'],ep['face_id'])
        matches=matches_by_pit.get(key,[])
        base={'episode_id':ep['episode_id'],'pit_instance_id':str(ep['pit_instance_id']),
              'name':ep['name'],'face_id':ep['face_id'],'outcome':ep['outcome'],
              'episode_end_ns':ep['end_ns'],'match_event_seq':None,
              'data_mac_rx_event_seq':None,'data_mac_rx_time_ns':None,
              'receiver_packet_uid':None,'receiver_device_index':None,
              'sender_packet_uid':None,'sender_node_id':None,'sender_device_index':None,
              'sender_tx_end_event_seq':None,'status':'UNRESOLVED',
              'Congestion':None,'FutureCongestion':None,'training_ready':False}
        if ep['outcome']!='SUCCESS':
            need(not matches,'Non-success Face owns a DATA_MATCH (could mislabel outcome)')
            base['status']='NO_MATCH_'+str(ep['outcome'])
            results.append(base);continue
        need(ep['terminal_reason']=='PIT_SATISFIED_THIS_FACE',
             'Success terminal reason incompatible with incoming Data')
        if len(matches)!=1:
            base['status']='NOT_OBSERVED_NFD_MATCH' if not matches else 'AMBIGUOUS_NFD_MATCH'
            results.append(base);continue
        m=matches[0]
        satisfied_for_ep=[e for e in satisfied if e['pit_instance_id']==m['pit_instance_id']
                          and e['name']==m['name'] and e['face_id']==m['face_id']
                          and e['time_ns']==m['time_ns'] and e['event_seq']>m['event_seq']]
        if ep.get('terminal_event_seq')!=satisfied_for_ep[0]['event_seq']:
            base['status']='INCONSISTENT_TERMINAL_EVENT';results.append(base);continue
        if ep['end_ns']!=m['time_ns']:
            base['status']='INCONSISTENT_PIT_TIME';results.append(base);continue
        base['match_event_seq']=m['event_seq']
        rx_key=(m['node_id'],m['face_id'],m['name'],m['time_ns'])
        if len(received_by_key[rx_key])!=1:
            base['status']='AMBIGUOUS_PIT_TO_PHYSICAL';results.append(base);continue
        physical=rx_index.get(rx_key,[])
        if len(physical)!=1:
            base['status']='NOT_OBSERVED_MAC_RX' if not physical else 'AMBIGUOUS_MAC_RX'
            results.append(base);continue
        packet=physical[0]
        base.update(data_mac_rx_event_seq=packet['link_event_seq'],
                    data_mac_rx_time_ns=packet['time_ns'],
                    receiver_packet_uid=packet['packet_uid'],
                    receiver_device_index=packet['device_index'])
        if packet['packet_uid'] is None:
            base['status']='NO_PHYSICAL_PACKET_UID';results.append(base);continue
        sender_status,sender=sender_proof(packet,link,graph,tx_index,device_faces)
        if sender_status!='MATCHED_UNIQUE_SENDER':
            base['status']=sender_status;results.append(base);continue
        base.update(sender_node_id=sender['node_id'],sender_device_index=sender['device_index'],
                    sender_packet_uid=sender['packet_uid'],sender_tx_end_event_seq=sender['link_event_seq'],
                    status='MATCHED_UNIQUE_PIT_DATA')
        results.append(base)
    # Explicitly do not assign late, unsolicited Data to a closed PIT.
    extras=[]
    for e in unsolicited:
        rx_key=(e['node_id'],e['face_id'],e['name'],e['time_ns'])
        c=rx_index.get(rx_key,[])
        extras.append({'type':'UNSOLICITED_DATA','nfd_event_seq':e['event_seq'],
                       'name':e['name'],'time_ns':e['time_ns'],'face_id':e['face_id'],
                       'candidate_mac_rx_count':len(c),
                       'packet_uid':c[0]['packet_uid'] if len(c)==1 else None,
                       'pit_instance_id':None,'episode_id':None,
                       'status':'UNSOLICITED_NO_PIT_LINK_UNIQUE' if len(c)==1 else 'UNSOLICITED_NO_PIT_UNRESOLVED'})
    for e in cache:
        tx=[x for x in nfd if x['event_type']=='TX_INTEREST' and
            x['pit_instance_id']==e['pit_instance_id']]
        need(not tx,'CS hit is incorrectly mixed with upstream Interest transmission')
        extras.append({'type':'CACHE_HIT','nfd_event_seq':e['event_seq'],
                       'name':e['name'],'time_ns':e['time_ns'],'face_id':e['face_id'],
                       'candidate_mac_rx_count':0,'packet_uid':None,
                       'pit_instance_id':str(e['pit_instance_id']),'episode_id':None,
                       'status':'CACHE_SERVED_NO_UPSTREAM_DATA_EPISODE'})
    status=Counter(r['status'] for r in results)
    return results,extras,{
        'mode':cfg['mode'],'run':cfg['run'],'source_stage':'1S.1',
        'episodes':len(episodes),'accepted_data_match_events':len(matched),
        'matched_success_data':status['MATCHED_UNIQUE_PIT_DATA'],
        'success_episode_count':sum(r['outcome']=='SUCCESS' for r in results),
        'episode_status_counts':dict(sorted(status.items())),
        'cache_hit_events':len(cache),'unsolicited_data_events':len(unsolicited),
        'physical_data_mac_rx_count':sum(x['event_type']=='MAC_RX' and x.get('ndn_packet_type')=='DATA'
                                      for x in link),
        'unique_physical_rx_to_pit':len({r['data_mac_rx_event_seq'] for r in results
                                     if r['status']=='MATCHED_UNIQUE_PIT_DATA'}),
        'Congestion':None,'FutureCongestion':None,'training_ready':False,
        'validation':'PASS' if status['MATCHED_UNIQUE_PIT_DATA']==sum(r['outcome']=='SUCCESS' for r in results)
                     and status.get('AMBIGUOUS_PIT_TO_PHYSICAL',0)==0 else 'INCOMPLETE'
    }

def audit(folder):
    cfg,info=read_run(folder)
    return audit_rows(cfg,info)

def write_run(folder,outdir):
    rows,extras,summary=audit(folder)
    outdir=Path(outdir);outdir.mkdir(parents=True,exist_ok=True)
    def lines(path, data):
        path.write_text(''.join(json.dumps(x,ensure_ascii=False,sort_keys=True)+'\n' for x in data),encoding='utf-8')
    lines(outdir/'data_pit_ledger.jsonl',rows)
    lines(outdir/'non_pit_data_events.jsonl',extras)
    (outdir/'stage1t_verification.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n',encoding='utf-8')
    return summary

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('run_folder',type=Path)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    print(json.dumps(write_run(a.run_folder,a.out),sort_keys=True))

if __name__=='__main__':main()
