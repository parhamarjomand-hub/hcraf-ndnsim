#!/usr/bin/env python3
"""Manifest even on failed simulations: complete inputs and partial logs kept."""
from pathlib import Path
import hashlib,json,os,platform,subprocess,sys
from datetime import datetime,timezone
root=Path(sys.argv[1]).resolve();topology=sys.argv[2]
assert topology in ('DEV_CHAIN_A','DEV_CHAIN_B')
out=root/'episode_output';out.mkdir(exist_ok=True)
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()
try:commit=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True,stderr=subprocess.DEVNULL).strip()
except (OSError,subprocess.CalledProcessError):commit=os.getenv('GITHUB_SHA','UNAVAILABLE')
files={str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='manifest.json'}
code={str(p.relative_to(root)):sha(p) for p in sorted((root/'hcraf/episode').rglob('*'))
      if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
wf=root/'.github/workflows/hcraf-stage1ah.yml'
if wf.is_file():code[str(wf.relative_to(root))]=sha(wf)
src=root/'hcraf_stage1ah_sources.zip'
manifest={'schema_version':'1AH.GROUP_AWARE.0','topology_id':topology,
 'created_utc':datetime.now(timezone.utc).isoformat(),'github_commit':commit,
 'github_run_id':os.getenv('GITHUB_RUN_ID'),'source_zip_sha256':sha(src) if src.is_file() else None,
 'python_version':platform.python_version(),'file_sha256':files,'code_sha256':code,
 'fully_pinned_environment':False,'container_image':'ubuntu:20.04 (tag, not OCI digest)',
 'Congestion':None,'FutureCongestion':None,'F3_ready':False,'training_ready':False}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
