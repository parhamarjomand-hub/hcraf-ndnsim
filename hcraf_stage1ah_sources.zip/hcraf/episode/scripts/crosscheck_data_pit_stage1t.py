#!/usr/bin/env python3
"""Read-only 1T cross-check that does not import the 1T join implementation."""
import argparse
from collections import Counter,defaultdict
import json
from pathlib import Path

def read(p):return [json.loads(s) for s in p.read_text(encoding='utf8').splitlines() if s.strip()]
def verify(root,out):
    checks=[];totals=Counter();errors=[]
    for source in sorted(root.glob('*/run-*')):
        relative=source.relative_to(root)
        ledger=read(out/'runs'/relative/'data_pit_ledger.jsonl')
        nfd=read(source/'events.jsonl');link=read(source/'link_events.jsonl');episodes=read(source/'episodes.jsonl')
        accepted={(e['pit_instance_id'],e['name'],e['face_id'],e['time_ns']):e
                  for e in nfd if e['event_type']=='DATA_MATCH'}
        suc=[e for e in episodes if e['outcome']=='SUCCESS']
        cancelled=[e for e in episodes if e['outcome']=='CANCELLED']
        if len(ledger)!=len(episodes):errors.append(str(relative)+': wrong ledger size')
        if len(accepted)!=len(suc):errors.append(str(relative)+': NFD/PIT count mismatch')
        for r in ledger:
            if r['outcome']!='SUCCESS':
                if r['receiver_packet_uid'] is not None or r['sender_packet_uid'] is not None:
                    errors.append(str(relative)+': assigned physical Data to cancelled episode')
                continue
            ep=[e for e in suc if e['episode_id']==r['episode_id']]
            if len(ep)!=1:errors.append(str(relative)+': wrong episode ID');continue
            e=ep[0]
            key=(int(r['pit_instance_id']),r['name'],r['face_id'],r['data_mac_rx_time_ns'])
            if key not in accepted:
                errors.append(str(relative)+': no DATA_MATCH for ledger row');continue
            a=accepted[key]
            physical=[x for x in link if x['event_type']=='MAC_RX' and
                      x['node_id']==1 and x['face_id']==a['face_id'] and
                      x['time_ns']==a['time_ns'] and x.get('ndn_packet_type')=='DATA' and
                      x['ndn_name']==a['name'] and x.get('wire_status')=='PILOT']
            if len(physical)!=1 or physical[0]['link_event_seq']!=r['data_mac_rx_event_seq']:
                errors.append(str(relative)+': physical Data mismatch');continue
            if e['end_ns']!=a['time_ns'] or e['terminal_face_id']!=a['face_id'] or e['terminal_reason']!='PIT_SATISFIED_THIS_FACE':
                errors.append(str(relative)+': terminal Outcome mismatch')
            if r['status']!='MATCHED_UNIQUE_PIT_DATA':errors.append(str(relative)+': unsupported positive status')
        totals['runs']+=1;totals['success']+=len(suc);totals['cancelled']+=len(cancelled)
        totals['verified']+=len([r for r in ledger if r['status']=='MATCHED_UNIQUE_PIT_DATA'])
        checks.append({'run':str(relative),'success':len(suc),'cancelled':len(cancelled),
                       'joined':sum(r['status']=='MATCHED_UNIQUE_PIT_DATA' for r in ledger)})
    return {'status':'PASS' if not errors and totals['runs']==12 and totals['verified']==totals['success'] else 'FAIL',
            'count':dict(totals),'checks':checks,'errors':errors,
            'method':'Independent raw exact-time/NFD-PIT/MAC_RX reference check. Does not certify arbitrary traffic.'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('stage1s',type=Path);p.add_argument('result',type=Path)
    a=p.parse_args();r=verify(a.stage1s,a.result)
    (a.result/'stage1t_independent_crosscheck.json').write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
    print(json.dumps(r['count'],sort_keys=True),r['status']);raise SystemExit(0 if r['status']=='PASS' else 1)
