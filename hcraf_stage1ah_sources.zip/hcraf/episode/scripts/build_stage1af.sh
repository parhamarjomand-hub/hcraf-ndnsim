#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
# Identical pinned NFD/ns-3 patch chain as Stage1AD; append only a scratch pilot.
bash "$TASK/scripts/build_stage1ad.sh"
cd "$ROOT/episode_sources/ns-3"
for header in hcraf-stage1w-monitor.hpp hcraf-stage1w-lp.hpp hcraf-wire-decode.hpp hcraf-collection-policy.hpp; do
  test -s "$TASK/src/$header"
  cp "$TASK/src/$header" "scratch/$header"
  cmp -s "$TASK/src/$header" "scratch/$header"
done
cp "$TASK/src/hcraf-stage1af-pilot.cpp" scratch/hcraf-stage1af-pilot.cc
cmp -s "$TASK/src/hcraf-stage1af-pilot.cpp" scratch/hcraf-stage1af-pilot.cc
python3 ./waf -j 2
test -x build/scratch/hcraf-stage1af-pilot
