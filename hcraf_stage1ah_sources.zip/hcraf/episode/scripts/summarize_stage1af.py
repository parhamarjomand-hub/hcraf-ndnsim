#!/usr/bin/env python3
"""Aggregate only independent RUN blocks; never treat 90 design slots as outcomes."""
import collections,hashlib,json,sys
from pathlib import Path

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def resources(p):
    data={}
    if p.is_file():
        for line in p.read_text().splitlines():
            if '=' in line:
                k,v=line.split('=',1)
                try:data[k]=float(v)
                except ValueError:pass
    return data

def summarize(root,topology):
    root=Path(root)
    rows=[];pairs=[]
    for slot in range(3):
        for mode in ('LOW_LOAD','BUFFER_NO_DROP','OVERFLOW_DROP','LP_CLEAN','LP_PRESSURE'):
            for rng in (8101,8102,8103):
                d=root/'monitored'/f'slot-{slot}'/mode/f'run-{rng}'
                vf=d/'stage1af_verification.json'
                row={'topology_id':topology,'slot':slot,'mode':mode,'rng_run':rng,
                     'status':'NO_VERIFIER_RESULT'}
                if vf.is_file():row.update(json.loads(vf.read_text()))
                rows.append(row)
    for mode in ('LOW_LOAD','LP_CLEAN'):
        for rng in (8101,8102,8103):
            mon=root/'monitored'/'slot-0'/mode/f'run-{rng}'
            raw=root/'uninstrumented'/'slot-0'/mode/f'run-{rng}'
            a=mon/'consumer_events.jsonl';b=raw/'consumer_events.jsonl'
            x=mon/'consumer_events.jsonl.arrivals.jsonl';y=raw/'consumer_events.jsonl.arrivals.jsonl'
            pairs.append({'topology_id':topology,'slot':0,'regime':mode,'rng_run':rng,
              'consumer_equal':a.is_file() and b.is_file() and sha(a)==sha(b),
              'arrival_equal':x.is_file() and y.is_file() and sha(x)==sha(y),
              'monitored_resource':resources(mon/'resource_usage.txt'),
              'unmonitored_resource':resources(raw/'resource_usage.txt'),
              'observer_cost_is_HCRAF_decision_time':False})
    summary={'stage':'1AF.DEV_MULTIFACE.0','topology_id':topology,
       'planned_monitored':45,'recorded_monitored':len(rows),
       'statuses':dict(collections.Counter(r['status'] for r in rows)),
       'planned_uninstrumented':6,'recorded_pairs':len(pairs),
       'all_pair_inputs_and_outcomes_identical':all(p['arrival_equal'] and p['consumer_equal'] for p in pairs),
       'actual_HCRAF_policy_evaluated':False,'decision_time_gate':'BLOCKED',
       'GO_FREEZE':False,'Congestion':None,'FutureCongestion':None,'F3_ready':False,'training_ready':False,
       'warning':'Development-only forced Face assignment; nominal 1/3 is not behavioral propensity.'}
    for filename,data in [('stage1af_runs.json',rows),('stage1af_pairs.json',pairs),('stage1af_summary.json',summary)]:
        (root/filename).write_text(json.dumps(data,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps(summary,ensure_ascii=False))
    if len(rows)!=45 or len(pairs)!=6:return 2
    if any(r['status']!='PASS_TARGET_EVENT_ONLY' for r in rows):return 3
    if not summary['all_pair_inputs_and_outcomes_identical']:return 4
    return 0

if __name__=='__main__':raise SystemExit(summarize(sys.argv[1],sys.argv[2]))
