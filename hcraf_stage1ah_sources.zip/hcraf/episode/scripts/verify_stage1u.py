#!/usr/bin/env python3
"""Stage1U strict auditor: local NFD ingress ordinal -> explicit PIT matches.

Does not infer one-to-one physical packets when (name,time,face) collides.
No assertion that an intended contention pattern necessarily materialized;
reports observed cases and flags absent coverage for human review.
"""
import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path

MODES = ('burst-identical', 'overlap-prefix', 'duplicate-data',
         'interleaved-retransmission', 'multi-hop-overlap', 'dual-source-overlap')
EXTRA = {'DATA_ARRIVE_1U', 'DATA_MATCH_SET_1U', 'DATA_PIT_BIND_1U'}


def require(cond, message):
    if not cond:
        raise ValueError(message)


def load(path):
    with Path(path).open(encoding='utf-8') as stream:
        return [json.loads(line) for line in stream if line.strip()]


def audit_events(events, links):
    require(events and events[-1]['event_type']=='SIMULATION_END', 'incomplete NFD trace')
    require(all(e.get('event_seq') == i for i, e in enumerate(events, 1)),
            'NFD events sequence corrupt')
    last_time=-1
    for e in events:
        require(e['time_ns']>=last_time, 'NFD time went backwards')
        last_time=e['time_ns']
    arrivals = {}
    sets = {}
    binds = defaultdict(list)
    paired_data_matches = set()
    matched_pits = set()
    for index, ev in enumerate(events):
        typ = ev['event_type']
        if typ not in EXTRA:
            continue
        token = ev['reason']
        require(type(token) is int and 0 < token < 2**63,
                'invalid router-local Data arrival ordinal')
        require(ev['node_id'] == 1 and ev['face_id'] >= 0,
                'Stage1U NFD instrumentation ran on unexpected node/Face')
        if typ == 'DATA_ARRIVE_1U':
            require(token not in arrivals and ev['pit_instance_id']==0,
                    'duplicate arrival ordinal or ingress PIT should be zero')
            arrivals[token] = ev
        elif typ == 'DATA_MATCH_SET_1U':
            require(token not in sets and ev['pit_instance_id']==0,
                    'duplicate set ordinal or invalid PIT')
            require(type(ev['nonce']) is int and ev['nonce'] >= 0,
                    'match count malformed')
            sets[token] = ev
        else:
            require(ev['pit_instance_id'] > 0, 'PIT bind without actual PIT')
            require(index > 0, 'PIT bind without preceding NFD match')
            prior = events[index-1]
            require(prior['event_type'] == 'DATA_MATCH' and
                    prior['pit_instance_id'] == ev['pit_instance_id'] and
                    prior['name'] == ev['name'] and prior['face_id'] == ev['face_id'] and
                    prior['time_ns'] == ev['time_ns'],
                    'explicit PIT binding is not adjacent to an authentic NFD DATA_MATCH')
            require(prior['event_seq'] not in paired_data_matches,
                    'DATA_MATCH reused across different PIT binds')
            paired_data_matches.add(prior['event_seq'])
            binds[token].append(ev)
    require(len(arrivals)>0, 'no Data ingress events observed')
    require(sorted(arrivals) == list(range(1,len(arrivals)+1)),
            'missing or duplicated router-local arrival ordinal')
    require(arrivals.keys()==sets.keys(), 'missing DATA_MATCH_SET for ingress')
    original_matches={e['event_seq'] for e in events if e['event_type']=='DATA_MATCH'}
    require(original_matches == paired_data_matches,
            'a NFD DATA_MATCH was not covered by Stage1U PIT bind')
    rx_index=defaultdict(list)
    for x in links:
        if x['event_type']=='MAC_RX' and x.get('ndn_packet_type')=='DATA':
            rx_index[(x['node_id'],x['face_id'],x['time_ns'],x['ndn_name'])].append(x)
    report=[]
    physical_counts=Counter()
    binding_outcome_counts=Counter()
    seen_match_keys=set()
    for token in sorted(arrivals):
        ingress=arrivals[token]; matched=sets[token]
        require(ingress['event_seq'] < matched['event_seq'], 'match-set before ingress')
        for field in ('node_id','face_id','name','time_ns'):
            require(ingress[field] == matched[field], 'different arrival and match-set '+field)
        group=binds[token]
        require(matched['nonce']==len(group), 'NFD match count disagrees with PIT binds')
        require(ingress['event_seq'] < min([b['event_seq'] for b in group] + [10**18]),
                'bind precedes arrival')
        require(all(b['event_seq']>matched['event_seq'] for b in group), 'bind precedes match set')
        next_arrival_seq = (arrivals[token+1]['event_seq'] if token+1 in arrivals
                            else events[-1]['event_seq'])
        binding_outcomes=[]
        for b in group:
            require(b['face_id']==ingress['face_id'] and b['time_ns']==ingress['time_ns'] and
                    (b['name']==ingress['name'] or ingress['name'].startswith(b['name']+'/')),
                    'bound PIT cannot match observed Data name/face/time')
            key=(token,b['pit_instance_id'])
            require(key not in seen_match_keys, 'same PIT repeated for a single NFD Data arrival')
            seen_match_keys.add(key)
            require(b['event_seq'] < events[-1]['event_seq'], 'PIT bind after simulation finished')
            # A bind only means NFD matched PIT at ingress. It is not a proof
            # of SUCCESS, a terminal outcome, or a physical UID.
            matched_pits.add(b['pit_instance_id'])
            terminal_candidates=[x for x in events if
                x['event_type']=='PIT_SATISFIED' and
                b['event_seq'] < x['event_seq'] < next_arrival_seq and
                x['pit_instance_id']==b['pit_instance_id'] and
                x['face_id']==b['face_id'] and x['name']==b['name'] and
                x['time_ns']==b['time_ns']]
            require(len(terminal_candidates)<=1,
                    'one NFD ingress has conflicting PIT_SATISFIED events')
            state=('PIT_SATISFIED_EVENT_OBSERVED' if terminal_candidates
                   else 'PIT_MATCH_ONLY_NO_SATISFIED_EVENT')
            binding_outcome_counts[state]+=1
            binding_outcomes.append({'pit_instance_id':b['pit_instance_id'],
                                     'binding_event_seq':b['event_seq'],
                                     'state':state})
        candidates=rx_index.get((ingress['node_id'],ingress['face_id'],ingress['time_ns'],ingress['name']),[])
        physical = 'UNIQUE_TIME_FACE_NAME' if len(candidates)==1 else (
            'NO_MAC_RX' if not candidates else 'AMBIGUOUS_MAC_RX')
        physical_counts[physical]+=1
        report.append(dict(schema='1U.1', node_id=ingress['node_id'],
            rx_ordinal=token,name=ingress['name'],time_ns=ingress['time_ns'],
            ingress_face_id=ingress['face_id'],match_count=len(group),
            pit_instance_ids=[b['pit_instance_id'] for b in group],
            pit_binding_outcomes=binding_outcomes,
            nfd_match_event_seqs=[b['event_seq']-1 for b in group],
            physical_status=physical,physical_candidate_count=len(candidates),
            physical_packet_uid=(candidates[0]['packet_uid'] if len(candidates)==1 else None),
            Congestion=None,FutureCongestion=None,training_ready=False))
    require(sum(len(x['pit_instance_ids']) for x in report)==len(original_matches),
            'lost PIT binding')
    stats = dict(ingress_count=len(report), pit_bind_count=len(original_matches),
        data_match_sets=len(sets), many_pit_arrivals=sum(r['match_count']>1 for r in report),
        no_pit_arrivals=sum(r['match_count']==0 for r in report),
        physical_status_counts=dict(sorted(physical_counts.items())),
        pit_binding_outcome_counts=dict(sorted(binding_outcome_counts.items())),
        repeated_name_arrivals=sum(n>1 for n in Counter(r['name'] for r in report).values()),
        same_time_face_name_groups=sum(n>1 for n in Counter((r['time_ns'],r['ingress_face_id'],r['name']) for r in report).values()),
        verified_nfd_binding=True,full_physical_attribution_verified=all(r['physical_status']=='UNIQUE_TIME_FACE_NAME' for r in report),
        final_congestion_label=None,future_congestion_label=None,training_ready=False)
    return report,stats



def observed_late_duplicate_and_cross_face(rows):
    """Count witnessed no-PIT Data occurring after a matching Data with PIT.

    Comparisons use *NFD ingress* records ordered by actual NFD receive ordinal,
    not a hypothesized source response. Multiple Face IDs are required for the
    cross-face metric; timestamps must be strictly increasing. No PIT or UID is
    ever attributed to the unmatched Data.
    """
    prior = defaultdict(list)
    same_name_late = 0
    cross_face_late = 0
    for r in sorted(rows,key=lambda x: x['rx_ordinal']):
        name = r['name']
        if r['match_count'] == 0:
            earlier = [m for m in prior[name] if m['time_ns'] < r['time_ns']]
            if earlier:
                same_name_late += 1
                if any(m['ingress_face_id'] != r['ingress_face_id'] for m in earlier):
                    cross_face_late += 1
        else:
            prior[name].append(r)
    return same_name_late, cross_face_late

def verify_folder(folder):
    folder=Path(folder)
    cfg=json.loads((folder/'scenario.json').read_text(encoding='utf8'))
    require(cfg['mode'] in MODES and cfg['collector_stage']=='1U.1' and
            cfg.get('data_pit_schema')=='1U.1', 'invalid 1U scenario')
    require(cfg['training_ready'] is False and cfg['final_congestion_label'] is None and
            cfg['future_congestion_label'] is None and cfg['causal_congestion_attribution'] is None,
            'Congestion research labels must remain null')
    events=load(folder/'events.jsonl')
    links=load(folder/'link_events.jsonl')
    for i,x in enumerate(links,1):
        require(x['schema_version']=='1R.1' and x['link_event_seq']==i, 'invalid link sequence')
    rows,stats=audit_events(events,links)
    late_same, late_cross_face = observed_late_duplicate_and_cross_face(rows)
    stats['unmatched_after_matched_same_name'] = late_same
    stats['cross_face_unmatched_after_matched_same_name'] = late_cross_face
    if cfg['mode'] in ('duplicate-data', 'dual-source-overlap'):
        require(cfg.get('selection_policy')=='diagnostic_multicast' and
                cfg.get('router_strategy')=='diagnostic_multicast',
                'contention modes must record explicit diagnostic multicast strategy')
    episodes=load(folder/'episodes.jsonl')
    require(episodes and all(e.get('outcome') in ('SUCCESS','TIMEOUT','NACK','CANCELLED',None)
                              for e in episodes), 'invalid reconstructed Episode')
    stats.update(mode=cfg['mode'],run=cfg['run'],episode_count=len(episodes),
                 episode_outcomes=dict(Counter(str(e['outcome']) for e in episodes)),
                 acceptance='PASS_NFD_BINDINGS_WITH_REPORTED_PHYSICAL_LIMITATIONS')
    return rows,stats


def main():
    p=argparse.ArgumentParser()
    p.add_argument('folder',type=Path)
    args=p.parse_args()
    rows,summary=verify_folder(args.folder)
    with (args.folder/'stage1u_data_bindings.jsonl').open('w',encoding='utf8') as f:
        for r in rows:f.write(json.dumps(r,sort_keys=True)+'\n')
    (args.folder/'stage1u_verification.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(json.dumps(summary,sort_keys=True))

if __name__=='__main__':main()
