#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
OUT="$ROOT/episode_output/stage1w"
mkdir -p "$OUT"
cd "$ROOT/episode_sources/ns-3"
failed=0
for mode in same-time-dual-face fragmented multi-hop-fragmented; do
  for run in 1001 1002; do
    folder="$OUT/$mode/run-$run"
    mkdir -p "$folder"
    command="hcraf-stage1w-pilot --mode=$mode --output=$folder --seed=17 --run=$run"
    printf '%s\n' "$command" > "$folder/command.txt"
    if ! python3 ./waf --run-no-build "$command" > "$folder/simulator.log" 2>&1; then
      echo "SIMULATION_FAIL mode=$mode run=$run"; failed=1; continue
    fi
    if ! python3 "$TASK/scripts/episodes_stage1u.py" "$folder" --run-id "1w-$mode-17-$run"; then
      echo "EPISODE_RECONSTRUCTION_FAIL mode=$mode run=$run"; failed=1; continue
    fi
    if ! python3 "$TASK/scripts/verify_stage1w.py" "$folder"; then
      echo "EVIDENCE_VERIFY_FAIL mode=$mode run=$run"; failed=1
    fi
  done
done
if ! python3 "$TASK/scripts/summarize_stage1w.py" "$OUT"; then failed=1;fi
exit "$failed"
