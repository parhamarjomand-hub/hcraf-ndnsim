#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK_DIR="$PROJECT_DIR/hcraf/episode"
OUTPUT_DIR="$PROJECT_DIR/episode_output"
cd "$PROJECT_DIR/episode_sources/ns-3"
status=0
for policy in uniform coverage; do
  for mode in control receive-outage; do
    for run in 1001 1002 1003 1004; do
      repetitions=1
      if [[ "$run" == 1001 ]]; then repetitions="1 2"; fi
      for rep in $repetitions; do
        folder="$OUTPUT_DIR/$policy/$mode/run-$run/repeat-$rep"
        mkdir -p "$folder"
        command="hcraf-coverage-pilot --policy=$policy --mode=$mode --output=$folder --seed=17 --run=$run"
        printf '%s\n' "$command" > "$folder/command.txt"
        if ! python3 ./waf --run-no-build "$command" 2>&1 | tee "$folder/simulator.log"; then status=1; continue; fi
        if ! python3 "$TASK_DIR/scripts/episodes.py" "$folder" --run-id "$policy-$mode-seed17-run$run"; then status=1; continue; fi
        if ! python3 "$TASK_DIR/scripts/verify_coverage.py" "$folder"; then status=1; fi
      done
    done
  done
done
# Frozen two-face control, repeated once for deterministic regression.
for rep in 1 2; do
  folder="$OUTPUT_DIR/regression/repeat-$rep"
  mkdir -p "$folder"
  command="hcraf-episode-pilot --collectionMode=single --mode=control --probeProbability=0 --output=$folder --seed=17 --run=1001"
  printf '%s\n' "$command" > "$folder/command.txt"
  if ! python3 ./waf --run-no-build "$command" 2>&1 | tee "$folder/simulator.log"; then status=1; continue; fi
  if ! python3 "$TASK_DIR/scripts/episodes.py" "$folder" --run-id "control-p0-seed17-run1001"; then status=1; continue; fi
  if ! python3 "$TASK_DIR/scripts/verify_selection.py" "$folder"; then status=1; fi
done
if ! python3 "$TASK_DIR/scripts/compare_coverage.py" "$OUTPUT_DIR"; then status=1; fi
exit "$status"
