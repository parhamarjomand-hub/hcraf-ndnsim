#!/usr/bin/env python3
"""Manifest for full/partial Stage1W cloud results, including negative controls."""
import hashlib,json,os,platform,subprocess,sys
from pathlib import Path
from datetime import datetime,timezone
root=Path(sys.argv[1]).resolve()
out=root/'episode_output';out.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
try:rev=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()
except (OSError,subprocess.CalledProcessError):rev=os.environ.get('GITHUB_SHA')
files={str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='manifest.json'}
code={str(p.relative_to(root)):sha(p) for p in sorted((root/'hcraf/episode').rglob('*'))
      if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
wf=root/'.github/workflows/hcraf-stage1w.yml'
if wf.exists():code[str(wf.relative_to(root))]=sha(wf)
report=dict(schema_version='1W.0',purpose='CONCURRENT_INGRESS_LP_FRAGMENTATION_CROSS_HOP_NOT_TRAINING',
 created_at_utc=datetime.now(timezone.utc).isoformat(),github_run_id=os.environ.get('GITHUB_RUN_ID'),
 github_run_attempt=os.environ.get('GITHUB_RUN_ATTEMPT'),git_commit=rev,
 python=platform.python_version(),artifact_sha256=files,code_sha256=code,
 congestion_label_final=None,future_congestion_label_final=None,training_ready=False,
 environment_fully_locked=False,
 limitation='Pinned ndnSIM/NFD source commits; apt state and container image digest not locked.')
(out/'manifest.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
