#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
OUT="$ROOT/episode_output/stage1y"
mkdir -p "$OUT"
cd "$ROOT/episode_sources/ns-3"
failed=0
for mode in idle low-load forward-buffered return-buffered forward-overflow return-overflow receive-loss propagation-only no-route mixed-fragmented; do
  for run in 1001 1002 1003; do
    folder="$OUT/$mode/run-$run"
    mkdir -p "$folder"
    command="hcraf-stage1y-pilot --mode=$mode --output=$folder --seed=17 --run=$run --instrument=1"
    printf '%s\n' "$command" > "$folder/command.txt"
    if ! /usr/bin/time -f 'wall_seconds=%e\nmax_rss_kib=%M' -o "$folder/resource_usage.txt" \
      python3 ./waf --run-no-build "$command" > "$folder/simulator.log" 2>&1; then
      echo "SIMULATION_FAIL mode=$mode run=$run"; failed=1; continue
    fi
    if [[ $mode != idle && $mode != no-route ]]; then
      if ! python3 "$TASK/scripts/episodes_stage1u.py" "$folder" --run-id "1y-$mode-17-$run" \
            > "$folder/episode_reconstruction.log" 2>&1; then
        echo "EPISODE_RECONSTRUCTION_FAIL mode=$mode run=$run"; failed=1; continue
      fi
    fi
    if ! python3 "$TASK/scripts/verify_stage1y.py" "$folder" > "$folder/verify.log" 2>&1; then
      echo "TARGET_EVIDENCE_INCOMPLETE mode=$mode run=$run"; failed=1
    fi
  done
done
# Paired, uninstrumented controls use the same inputs and simulator versions.
# These are engineering controls, NOT new F3 training episodes.
for mode in low-load mixed-fragmented; do
  for run in 1001 1002 1003; do
    folder="$OUT/uninstrumented/$mode/run-$run"
    mkdir -p "$folder"
    command="hcraf-stage1y-pilot --mode=$mode --output=$folder --seed=17 --run=$run --instrument=0"
    printf '%s\n' "$command" > "$folder/command.txt"
    if ! /usr/bin/time -f 'wall_seconds=%e\nmax_rss_kib=%M' -o "$folder/resource_usage.txt" \
      python3 ./waf --run-no-build "$command" > "$folder/simulator.log" 2>&1; then
      echo "UNINSTRUMENTED_SIMULATION_FAIL mode=$mode run=$run"; failed=1
    fi
  done
done
if ! python3 "$TASK/scripts/summarize_stage1y.py" "$OUT"; then failed=1; fi
exit "$failed"
