#!/usr/bin/env python3
"""Verify multipath observations; administrative route changes are not learned adaptation."""
import json
from pathlib import Path
import sys
from collections import Counter,defaultdict
from episodes import load,reconstruct,require
from verify_decisions import verify as verify_decisions
from verify_load import link_busy_intervals


def selection_checks(rows,cfg):
    groups=defaultdict(list)
    for r in rows: groups[r['decision_id']].append(r)
    selected=[]
    for pair in groups.values():
        require(len(pair)==2,'not exactly two FIB candidates')
        chosen=[r for r in pair if r['selected']]
        require(len(chosen)==1,'BestRoute must select exactly one Face for unique Interest')
        c=chosen[0]; selected.append(c)
        require(c['routing_cost']==min(r['routing_cost'] for r in pair),'selected Face not lowest observed FIB cost')
        require(len(c['tx_event_seqs'])==len(c['episode_ids'])==1,'bad selected linkage')
        for r in pair:
            if not r['selected']:
                require(not r['tx_event_seqs'] and not r['episode_ids'],'unchosen Face given fabricated episode')
    if cfg['mode']=='multi-change':
        pre=[r for r in selected if r['time_ns']<5000000000]
        post=[r for r in selected if r['time_ns']>=5000000000]
        require(pre and post,'no observations on both sides of change')
        require(all(r['face_id']==cfg['primary_face_id'] for r in pre),'wrong pre-change Face')
        require(all(r['face_id']==cfg['secondary_face_id'] for r in post),'wrong post-change Face')
    else:
        require(all(r['face_id']==cfg['primary_face_id'] for r in selected),'unexpected secondary path selection')
    return selected


def verify(folder):
    cfg=json.loads((folder/'scenario.json').read_text());mode=cfg['mode']
    require(mode in ('multi-low','multi-mid','multi-change'),'unsupported scenario')
    rate={'multi-low':5,'multi-mid':12,'multi-change':30}[mode]
    for k,v in dict(instrumentation_stage='1D.1',request_rate_per_s=rate,planned_requests=8*rate,
        stop_ns=13000000000,traffic_start_ns=1000000000,traffic_stop_exclusive_ns=9000000000,
        primary_rate_bps=128000,secondary_rate_bps=512000,link_rate_bps=10000000,
        primary_delay_ms=10,secondary_delay_ms=30,access_delay_ms=10,initial_primary_cost=1,
        secondary_cost=2,changed_primary_cost=3,queue_capacity_packets=20,interest_lifetime_ms=1000,
        payload_bytes=1024,cs_packets=0,consumer_retransmissions=False,
        change_time_ns=5000000000 if mode=='multi-change' else None).items():
        require(cfg.get(k)==v,'configuration mismatch: '+k)
    a,b=cfg['primary_face_id'],cfg['secondary_face_id'];require(a!=b,'duplicate upstream mapping')
    events=load(folder/'events.jsonl');ep=load(folder/'episodes.jsonl');links=load(folder/'link_events.jsonl')
    consumer=load(folder/'consumer_events.jsonl');control=load(folder/'control_events.jsonl')
    require(ep and ep==reconstruct(events,ep[0]['run_id']),'episode reconstruction mismatch')
    require(events[-1]['time_ns']==cfg['stop_ns'],'wrong simulation end')
    rows,dr=verify_decisions(folder,multi_profile=True)
    selected=selection_checks(rows,cfg)
    initial={(x['node_id'],x['device_index']):x['face_id'] for x in links if x['event_type']=='INITIAL'}
    require(initial.get((1,1))==a and initial.get((1,2))==b,'configuration differs from observed device-Face mapping')
    require(all(0<=x['queue_packets']<=20 for x in links),'queue exceeds configured capacity')
    require(all(x['queue_packets']==0 for x in links if x['event_type']=='FINAL'),'queues not drained')
    busy=link_busy_intervals(links,1000000000,9000000000)
    expected_control=[] if mode!='multi-change' else [dict(event='ROUTE_COST_UPDATE_REQUEST',
        time_ns=5000000000,node_id=1,face_id=a,prefix='/hcraf',new_cost=3)]
    require(control==expected_control,'administrative control log mismatch')
    sends=[x for x in consumer if x['event']=='SEND'];data=[x for x in consumer if x['event']=='DATA']
    require(all(x['event'] in ('SEND','DATA','NACK') for x in consumer),'unknown consumer event')
    require(all(0<=x['time_ns']<=cfg['stop_ns'] for x in consumer),'consumer outside observation')
    require(all(x['time_ns']<=y['time_ns'] for x,y in zip(consumer,consumer[1:])),'consumer ordering')
    names=['/hcraf/pilot/'+str(i) for i in range(8*rate)]
    require([x['name'] for x in sends]==names,'offered request count/names mismatch')
    require([x['time_ns'] for x in sends]==[1000000000+i*1000000000//rate for i in range(8*rate)],'offered timing mismatch')
    require(len(ep)==len(names) and {e['name'] for e in ep}==set(names),'missing or duplicate episode')
    require(all(e['outcome'] in ('SUCCESS','TIMEOUT','NACK') and e['tx_count']==1 for e in ep),'censored or unexpected episode')
    require(len(data)==len({x['name'] for x in data}),'duplicate consumer Data')
    epmap={e['name']:e for e in ep};sendmap={x['name']:x for x in sends}
    for x in data:
        require(x['name'] in epmap and epmap[x['name']]['outcome']=='SUCCESS','consumer Data without router SUCCESS')
        require(x['payload_bytes']==1024 and x['time_ns']>sendmap[x['name']]['time_ns'],'invalid consumer Data/delay')
    for e in ep:
        require(e['face_id'] in (a,b),'episode on unknown path')
        if e['outcome']=='SUCCESS':require(e['delay_valid'] and e['delay_ns']>0,'invalid successful RTT')
        else:require(e['delay_ns'] is None,'invented failure delay')
    if mode=='multi-low': require(len(data)==len(sends),'low-load control not completely delivered')
    # Do not predeclare exact loss/delay improvement or force a particular scientific result.
    perface=[]
    for face in (a,b):
        subset=[e for e in ep if e['face_id']==face]
        perface.append(dict(face_id=face,episodes=len(subset),outcomes=dict(Counter(e['outcome'] for e in subset))))
    phase=[]
    for label,lo,hi in [('before',1000000000,5000000000),('after',5000000000,9000000000)]:
        subset=[e for e in ep if lo<=e['start_ns']<hi]
        successes=[e for e in subset if e['outcome']=='SUCCESS']
        phase.append(dict(phase=label,episode_start_window_ns=[lo,hi],episodes=len(subset),
          outcomes=dict(Counter(e['outcome'] for e in subset)),mean_successful_face_rtt_ns=
          sum(e['delay_ns'] for e in successes)/len(successes) if successes else None))
    post=[r for r in selected if r['time_ns']>=5000000000 and r['face_id']==b]
    report=dict(status='PASS',stage='1D.1',mode=mode,offered_requests=len(sends),episodes=len(ep),
      decisions=dr['decisions'],candidate_rows=len(rows),unselected_candidate_rows=sum(not r['selected'] for r in rows),
      outcomes=dict(Counter(e['outcome'] for e in ep)),consumer_delivered=len(data),
      consumer_delivery_fraction=len(data)/len(sends),
      router_success_without_consumer_data=sum(e['outcome']=='SUCCESS' for e in ep)-len(data),
      mean_consumer_delay_ns=sum(x['time_ns']-sendmap[x['name']]['time_ns'] for x in data)/len(data) if data else None,
      consumer_goodput_active_window_bps=8*sum(x['payload_bytes'] for x in data if 1000000000<x['time_ns']<=9000000000)/8,
      consumer_goodput_full_observation_bps=8*sum(x['payload_bytes'] for x in data)/12,
      link_busy_active_window=busy,total_queue_drop_events=sum(x['event_type']=='QUEUE_DROP' for x in links),
      per_face=perface,phases_by_episode_start=phase,
      first_observed_secondary_decision_after_change_ns=min(r['time_ns'] for r in post) if mode=='multi-change' and post else None,
      research_training_eligible=False,proves_hcraf_adaptation=False,
      purpose='MULTIPATH_INSTRUMENTATION_ADMINISTRATIVE_CHANGE')
    return rows,report

if __name__=='__main__':
    folder=Path(sys.argv[1])
    try:
        rows,report=verify(folder)
        (folder/'decision_faces.jsonl').write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in rows))
    except Exception as e: report=dict(status='FAIL',stage='1D.1',error=str(e))
    (folder/'multi_verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
    sys.exit(0 if report['status']=='PASS' else 1)
