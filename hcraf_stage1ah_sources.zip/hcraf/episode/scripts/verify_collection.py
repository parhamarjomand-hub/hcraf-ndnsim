"""Fail-closed checks for the restricted two-face integration pilot."""
import json, math, sys
from pathlib import Path
from collections import Counter, defaultdict
from episodes import load, require, reconstruct
from verify_states import verify as verify_state


def check(c, d, tx):
    p, u = c['probe_probability'], c['uniform_draw']
    require(type(p) in (float,int) and math.isfinite(p) and 0 <= p <= 1, 'invalid probability')
    require(type(u) in (float,int) and math.isfinite(u) and 0 <= u < 1, 'invalid draw')
    selected = u < p
    require(c['probe_selected'] is selected, 'draw/selection mismatch')
    require(c['joint_action_probability'] == (p if selected else 1-p), 'joint action probability mismatch')
    require(c['primary_inclusion_probability'] == 1, 'primary probability')
    a,b=c['primary_face_id'],c['alternative_face_id']
    require(a != b and c['eligible_face_ids'] == [a,b], 'eligibility mismatch')
    candidates={x['face_id']:x for x in d['candidates']}
    require(set(candidates)=={a,b} and len(d['candidates'])==2, 'FIB candidates mismatch')
    require(candidates[a]['routing_cost'] < candidates[b]['routing_cost'], 'primary cost mismatch')
    require(all(not x['is_ingress'] for x in candidates.values()), 'ingress candidate')
    require([x['face_id'] for x in tx] == ([a,b] if selected else [a]), 'actual sends disagree with planned roles')
    for x in tx:
        require(x['pit_instance_id']==d['pit_instance_id'] and x['name']==d['name'], 'TX/PIT mismatch')
        require(x['time_ns']==d['time_ns'] and x['event_seq']>d['after_event_seq'], 'TX anchor mismatch')


def verify(folder):
    cfg=json.loads((folder/'scenario.json').read_text())
    require(cfg['collector_stage']=='1K.1' and cfg['mode'] in ('control','receive-outage'), 'wrong collector scenario')
    ds=load(folder/'events.jsonl.decisions.jsonl');cs=load(folder/'events.jsonl.collection.jsonl')
    ev=load(folder/'events.jsonl'); ep=load(folder/'episodes.jsonl');consumer=load(folder/'consumer_events.jsonl')
    require(len(ds)==len(cs)==40 and len({d['decision_id'] for d in ds})==40,'decision count/uniqueness')
    require(ep==reconstruct(ev,ep[0]['run_id']), 'reconstructed episodes mismatch')
    by=defaultdict(list)
    for x in ev:
        if x['event_type']=='TX_INTEREST':by[x['decision_id']].append(x)
    require(set(by)=={d['decision_id'] for d in ds},'orphan TX')
    index={e['tx_event_seqs'][0]:e for e in ep}
    require(len(index)==len(ep) and all(e['tx_count']==1 and e['outcome'] in ('SUCCESS','CANCELLED','TIMEOUT') for e in ep),'unexpected outcome/retx')
    roles=[]
    for c,d in zip(cs,ds):
        require(c['schema_version']=='1K.1' and c['decision_id']==d['decision_id'],'collector order/schema')
        require(c['probe_probability']==cfg['probe_probability'],'configuration probability')
        require(c['primary_face_id']==cfg['primary_face_id'] and c['alternative_face_id']==cfg['secondary_face_id'],'configured faces')
        check(c,d,by[d['decision_id']])
        for x in by[d['decision_id']]:
            e=index[x['event_seq']];primary=x['face_id']==c['primary_face_id']
            roles.append(dict(episode_id=e['episode_id'],decision_id=d['decision_id'],face_id=x['face_id'],
                role='NORMAL' if primary else 'PROBE',inclusion_probability=1 if primary else c['probe_probability'],
                joint_action_probability=c['joint_action_probability'],outcome=e['outcome']))
    require(len(roles)==len(ep),'episode role coverage')
    counts=Counter(e['outcome'] for e in ep);p=cfg['probe_probability']
    require(counts['SUCCESS']+counts['TIMEOUT']+counts['CANCELLED']==len(ep),'unclosed episode')
    sends=[x for x in consumer if x['event']=='SEND'];data=[x for x in consumer if x['event']=='DATA']
    require(len(sends)==40 and len({x['name'] for x in sends})==40,'consumer request count')
    require([x['time_ns'] for x in sends]==[10**9+i*200000000 for i in range(40)],'arrival schedule')
    require(len(data)==counts['SUCCESS'] and len({x['name'] for x in data})==len(data),'consumer success evidence')
    if cfg['mode']=='control':
        require(counts['SUCCESS']==40 and counts['TIMEOUT']==0,'control success')
    if p==0:
        require(len(ep)==40 and counts['CANCELLED']==0,'zero probe mismatch')
        if cfg['mode']=='receive-outage':require(counts==Counter(SUCCESS=25,TIMEOUT=15),'outage control mismatch')
    if p==1:require(counts==Counter(SUCCESS=40,CANCELLED=40),'forced probe cancellation mismatch')
    verify_state(folder)
    (folder/'episode_roles.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in roles))
    probes=sum(r['role']=='PROBE' for r in roles)
    report=dict(status='PASS',decisions=len(ds),episodes=len(ep),outcomes=dict(counts),probe_transmissions=probes,
        extra_interest_count_ratio=probes/40,counts_by_role={role:dict(Counter(r['outcome'] for r in roles if r['role']==role)) for role in ('NORMAL','PROBE')},
        valid_outcomes_by_face={str(f):sum(e['face_id']==f and e['outcome'] in ('SUCCESS','NACK','TIMEOUT') for e in ep) for f in (cfg['primary_face_id'],cfg['secondary_face_id'])},
        probabilities_are_behavior_inclusion_not_counterfactual=True,training_ready=False)
    (folder/'collection_verification.json').write_text(json.dumps(report,indent=2)+'\n')
    return report

if __name__=='__main__':
    folder=Path(sys.argv[1])
    try: print(json.dumps(verify(folder)))
    except Exception as e:
        (folder/'collection_verification.json').write_text(json.dumps(dict(status='FAIL',error=str(e)))+'\n');raise
