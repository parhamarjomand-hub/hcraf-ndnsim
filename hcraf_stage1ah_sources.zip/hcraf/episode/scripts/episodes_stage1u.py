#!/usr/bin/env python3
"""Unchanged 1T Episode semantics with strictly non-outcome 1U trace events."""
import episodes

# Existing episode reconstruct() enforces event sequence and timestamp order.
# Allow Stage1U's observational-only event types without changing its branch logic.
episodes.TYPES.update({'DATA_ARRIVE_1U','DATA_MATCH_SET_1U','DATA_PIT_BIND_1U'})

if __name__=='__main__':
    episodes.main()
