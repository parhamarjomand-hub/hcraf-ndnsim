#!/usr/bin/env python3
"""Reproduce Stage1T evidence directly from extracted Stage1S real raw traces."""
import argparse
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
from verify_data_pit_stage1t import write_run, need

MODES=('baseline','repeat-name','retransmission','aggregation','cache-hit','multi-hop')
RUNS=(1001,1002)

def sha256(f):
    h=hashlib.sha256()
    with open(f,'rb') as src:
        for block in iter(lambda:src.read(1<<20),b''): h.update(block)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('stage1s_root',type=Path,help='extracted stage1s/ directory (UNMODIFIED)')
    ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args();src=args.stage1s_root;out=args.out
    out.mkdir(parents=True,exist_ok=True)
    need(all((src/m/('run-%d'%r)).is_dir() for m in MODES for r in RUNS),
         'Missing a Stage1S real execution')
    actual={str(f.relative_to(src)) for f in src.glob('*/run-*/scenario.json')}
    expected={m+'/run-%d/scenario.json'%r for m in MODES for r in RUNS}
    need(actual==expected,'Extra/missing run provenance')
    runs=[];ledger=[];extras=[];old=Counter();old_to_new=Counter()
    for mode in MODES:
        for run in RUNS:
            inp=src/mode/('run-%d'%run)
            folder=out/'runs'/mode/('run-%d'%run)
            summary=write_run(inp,folder)
            need(summary['validation']=='PASS','Incomplete attribution in '+str(inp))
            rows=[json.loads(line) for line in (folder/'data_pit_ledger.jsonl').read_text().splitlines()]
            nonpit=[json.loads(line) for line in (folder/'non_pit_data_events.jsonl').read_text().splitlines()]
            prior=[json.loads(line) for line in (inp/'robustness_return_status.jsonl').read_text().splitlines()]
            bypit={(str(x['pit_instance_id']),x['name']):x['status'] for x in prior}
            for x in prior:old[x['status']]+=1
            for x in rows:
                x['scenario']=mode;x['run']=run
                x['prior_1s_status']=bypit.get((x['pit_instance_id'],x['name']))
                old_to_new[(x['prior_1s_status'],x['status'])]+=1
            for x in nonpit:x['scenario']=mode;x['run']=run
            ledger+=rows;extras+=nonpit;runs.append(summary)
    fields=list(ledger[0].keys())
    with (out/'stage1t_per_episode.csv').open('w',newline='',encoding='utf-8') as dest:
        w=csv.DictWriter(dest,fieldnames=fields);w.writeheader();w.writerows(ledger)
    with (out/'stage1t_per_run.csv').open('w',newline='',encoding='utf-8') as dest:
        keys=('mode','run','episodes','success_episode_count','matched_success_data',
              'accepted_data_match_events','cache_hit_events','unsolicited_data_events',
              'physical_data_mac_rx_count','validation')
        w=csv.DictWriter(dest,fieldnames=keys);w.writeheader()
        for r in runs:w.writerow({k:r[k] for k in keys})
    for name,items in [('stage1t_evidence.jsonl',ledger),('stage1t_non_pit_evidence.jsonl',extras)]:
        (out/name).write_text(''.join(json.dumps(x,sort_keys=True,ensure_ascii=False)+'\n'
                                      for x in items),encoding='utf-8')
    total=Counter(x['status'] for x in ledger)
    summary={
        'stage':'1T','version':'v0.18.0','input':'Stage1S v0.17.0 validated artifact',
        'run_count':len(runs),'episodes':len(ledger),
        'accepted_nfd_data_matches':sum(x['accepted_data_match_events'] for x in runs),
        'success_episodes':sum(x['outcome']=='SUCCESS' for x in ledger),
        'cancelled_episodes':sum(x['outcome']=='CANCELLED' for x in ledger),
        'matched_physical_data_to_pit':total['MATCHED_UNIQUE_PIT_DATA'],
        'status_counts':dict(sorted(total.items())),
        'old_status_counts':dict(sorted(old.items())),
        'transition_counts':{'%s -> %s'%k:v for k,v in sorted(old_to_new.items())},
        'cache_hits_no_upstream_episode':sum(x['type']=='CACHE_HIT' for x in extras),
        'unsolicited_data_without_pit':sum(x['type']=='UNSOLICITED_DATA' for x in extras),
        'all_physical_data_mac_rx':sum(x['physical_data_mac_rx_count'] for x in runs),
        'f3_ready':False,'Congestion':None,'FutureCongestion':None,'training_ready':False,
        'qualification':'Only observed Stage1S pilot; same-face/name/exact-ns PIT anchor and unique MAC_RX/sender. No proof for concurrent same-name collisions, caching over arbitrary topologies, fragmentation, or counterfactual paths.',
        'status':'PASS_OFFLINE_STAGE1T_LIMITED_TO_STAGE1S_TRACE',
        'trace_sha256':{
             mode+'/run-%d/%s'%(run,filename):sha256(src/mode/('run-%d'%run)/filename)
             for mode in MODES for run in RUNS
             for filename in ('scenario.json','events.jsonl','episodes.jsonl','link_events.jsonl',
                              'robustness_return_status.jsonl')}
    }
    (out/'stage1t_summary.json').write_text(json.dumps(summary,sort_keys=True,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in summary.items() if k!='trace_sha256'},ensure_ascii=False,sort_keys=True))

if __name__=='__main__':main()
