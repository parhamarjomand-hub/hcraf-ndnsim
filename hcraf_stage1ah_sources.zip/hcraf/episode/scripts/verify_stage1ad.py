#!/usr/bin/env python3
"""Stage 1AD real-ndnSIM fail-closed evidence verifier (development-only)."""
import argparse
import collections
import json
from pathlib import Path
from analyze_1ad import contextual_pressure, find_episode_direct_events, classify, PATH_DIRS
from verify_stage1ab import complete_path

MODES={'low-load','long-lifetime','forward-buffered','return-buffered',
       'forward-overflow','return-overflow','mixed-fragmented'}

def read_jsonl(path):
    if not path.is_file():raise ValueError('Required trace missing: '+str(path))
    return [json.loads(s) for s in path.read_text(encoding='utf-8').splitlines() if s.strip()]

def verify(root):
    root=Path(root)
    config=json.loads((root/'scenario.json').read_text(encoding='utf-8'))
    mode=config['mode']
    if config.get('collector_stage')!='1AD.BOUNDARY_PILOT.0' or mode not in MODES:
        raise ValueError('Wrong stage or unregistered mode')
    if config.get('stage1ad_case_role')!='DEVELOPMENT_ONLY' or config.get('stage1ad_target_window')!='EPISODE_TERMINAL_CLIPPED':
        raise ValueError('Wrong study split or timing semantics')
    if config.get('training_ready') is not False or config.get('F3_ready') is not False or config.get('future_congestion') is not None or config.get('congestion') is not None:
        raise ValueError('Research label leaked into pilot')
    if config.get('instrument_enabled') is not True or config.get('multi_hop_enabled') is not True:
        raise ValueError('Incomplete instrumentation')
    eps=read_jsonl(root/'episodes.jsonl')
    ev=read_jsonl(root/'link_events.jsonl')
    nfd=read_jsonl(root/'events.jsonl')
    nfd2=read_jsonl(root/'events_hop2.jsonl')
    arrivals=read_jsonl(root/'consumer_events.jsonl.arrivals.jsonl')
    if len(arrivals)!=config['planned_requests'] or len(eps)!=len(arrivals):
        raise ValueError('Episode/arrival mismatch')
    if len({e['name'] for e in eps})!=len(eps) or len({str(e['episode_id']) for e in eps})!=len(eps):
        raise ValueError('Ambiguous episode/name identity')
    if any(e.get('schema_version')!='1W.0' or e.get('link_event_seq')!=idx+1 for idx,e in enumerate(ev)):
        raise ValueError('Link sequence/schema mismatch')
    init={(e['node_id'],e['device_index']) for e in ev if e['event_type']=='INITIAL'}
    final={(e['node_id'],e['device_index']) for e in ev if e['event_type']=='FINAL'}
    if len(init)!=14 or init!=final or not PATH_DIRS.issubset(init):
        raise ValueError('Missing direction monitors')
    if any(e.get('time_ns',-1)>config['stop_ns'] for e in ev):
        raise ValueError('Events outside simulation')
    theta=2;horizon_ms=1000
    rows=[]
    for ep in eps:
        if ep['node_id']!=1 or ep['outcome'] not in ('SUCCESS','NACK','TIMEOUT','CANCELLED'):
            raise ValueError('Invalid episode node/outcome')
        start=ep['start_ns'];end=ep['end_ns']
        if not isinstance(start,int) or not isinstance(end,int) or start>end:
            raise ValueError('Bad terminal boundary')
        clipped=min(start+horizon_ms*1000000,end,config['stop_ns'])
        iscomplete,proof_reason,path=complete_path(ep,ev,nfd,nfd2)
        prior={'complete_path':iscomplete,'matched_directions':path}
        ctx=contextual_pressure(ev,start,clipped,theta)
        direct=find_episode_direct_events(ep,ev,nfd2,theta,start,clipped)
        tier,reason=classify(ep,prior,ctx,direct,end,clipped,mode)
        rows.append({'episode_id':ep['episode_id'],'pit_instance_id':ep['pit_instance_id'],
          'name':ep['name'],'selected_face':ep['face_id'],'outcome':ep['outcome'],
          'start_ns':start,'terminal_ns':end,'horizon_end_ns':clipped,
          'complete_path':iscomplete,'direct_proof_codes':direct['source_codes'],
          'direct_events':direct['event_seqs'],'direct_wait':direct['high_wait'],'direct_drop':direct['drop'],
          'context_count':len(ctx['pressure']),'physical_loss_count':len(ctx['phy']),
          'ambiguous_direct_candidates':direct['invalid'],'diagnostic_tier':tier,'reason':reason,
          'Congestion':None,'FutureCongestion':None,'F3_ready':False,'training_ready':False})
    tiers=collections.Counter(x['diagnostic_tier'] for x in rows)
    target=False
    if mode=='low-load':target=tiers['ZERO_QUEUE_PRESSURE_CERTIFICATE_DIAGNOSTIC']>0
    elif mode=='long-lifetime':target=any(x['outcome']=='SUCCESS' and x['terminal_ns']-x['start_ns']>1_000_000_000 for x in rows)
    elif mode=='forward-buffered':target=any(x['direct_wait']>0 for x in rows)
    elif mode=='return-buffered':target=any(x['direct_wait']>0 for x in rows)
    elif mode=='forward-overflow':target=any(x['direct_drop']>0 for x in rows)
    elif mode=='return-overflow':target=any(x['direct_drop']>0 for x in rows)
    elif mode=='mixed-fragmented':target=any(x.get('lp_status')=='FRAGMENT' and x.get('event_type')=='MAC_RX' for x in ev)
    summary={'stage':'1AD.BOUNDARY_PILOT.0','mode':mode,'rng_run':config['run'],
       'status':'PASS_TARGET_EVENT_ONLY' if target else 'INCOMPLETE_TARGET_EVENT',
       'target_observed':target,'episode_count':len(eps),
       'tier_counts':dict(tiers),'complete_paths':sum(x['complete_path'] for x in rows),
       'long_lifetime_successes':sum(x['outcome']=='SUCCESS' and x['terminal_ns']-x['start_ns']>1_000_000_000 for x in rows),
       'Causal_Attribution_Proven':False,'Congestion':None,'FutureCongestion':None,'F3_ready':False,'training_ready':False}
    (root/'stage1ad_verification.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    with (root/'stage1ad_episode_tiers.jsonl').open('w',encoding='utf-8') as f:
        for row in rows:f.write(json.dumps(row,ensure_ascii=False,sort_keys=True)+'\n')
    return summary

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('run_dir');p.add_argument('--fail-on-incomplete',action='store_true');a=p.parse_args()
    result=verify(a.run_dir);print(json.dumps(result,ensure_ascii=False))
    if a.fail_on_incomplete and not result['target_observed']:raise SystemExit(2)
