#!/usr/bin/env python3
"""1Y fail-closed observability verifier. Never produces final congestion/F3 labels.

Input must be raw ndnSIM 1Y trace files from ONE stage/run. The scientific
contract is not a classifier; missing or ambiguous information remains UNKNOWN.
"""
import argparse
import collections
import json
from pathlib import Path

MODES = ('idle','low-load','forward-buffered','return-buffered','forward-overflow',
         'return-overflow','receive-loss','propagation-only','no-route','mixed-fragmented')
DELTAS_NS = (250_000_000, 1_000_000_000, 2_000_000_000)
WAIT_NS = (0, 5_000_000, 20_000_000, 100_000_000)

class TraceInvalid(ValueError):
    pass


def rows(path, required=True):
    path = Path(path)
    if not path.exists():
        if required: raise TraceInvalid('Missing file: '+str(path))
        return []
    result=[]
    for n,line in enumerate(path.read_text(encoding='utf-8').splitlines(),1):
        if not line.strip(): continue
        try: x=json.loads(line)
        except json.JSONDecodeError as e: raise TraceInvalid(f'{path}:{n}: {e}')
        if not isinstance(x,dict): raise TraceInvalid(f'{path}:{n}: expected object')
        result.append(x)
    return result


def _identity(e):
    return (e.get('node_id'),e.get('device_index'),e.get('packet_uid'))


def validate(folder):
    p=Path(folder)
    cfg=json.loads((p/'scenario.json').read_text(encoding='utf-8'))
    mode=cfg.get('mode')
    if mode not in MODES or cfg.get('collector_stage') != '1Y.PILOT.0':
        raise TraceInvalid('Wrong source stage/mode')
    if any(cfg.get(k) is not None for k in ('congestion','future_congestion','causal_congestion_attribution')) or cfg.get('training_ready') is not False:
        raise TraceInvalid('Training/label invariant violated')
    events=rows(p/'link_events.jsonl')
    nfd=rows(p/'events.jsonl')
    consumer=rows(p/'consumer_events.jsonl')
    arrivals=rows(p/'consumer_events.jsonl.arrivals.jsonl')
    episodes=rows(p/'episodes.jsonl',required=mode not in ('idle','no-route'))
    if cfg['planned_requests']!=len(arrivals):
        raise TraceInvalid('Arrival trace is incomplete')
    if len([r for r in consumer if r.get('event')=='SEND'])!=len(arrivals):
        raise TraceInvalid('Consumer send count mismatch')
    if len({r.get('sequence') for r in arrivals})!=len(arrivals):
        raise TraceInvalid('Duplicate arrival sequence')
    if any(r.get('jitter_ns') is None or not 0<=r['jitter_ns']<100000 for r in arrivals):
        raise TraceInvalid('Arrival jitter missing or outside pre-registration')
    if not events: raise TraceInvalid('Empty link trace')
    devices={(e.get('node_id'),e.get('device_index')) for e in events if e.get('event_type')=='INITIAL'}
    finals={(e.get('node_id'),e.get('device_index')) for e in events if e.get('event_type')=='FINAL'}
    if not devices or devices!=finals: raise TraceInvalid('Missing initial/final direction coverage')
    if cfg['multi_hop_enabled'] and len(devices)<14: raise TraceInvalid('Missing multihop monitored link directions')
    if not cfg['multi_hop_enabled'] and len(devices)<8: raise TraceInvalid('Missing monitored link directions')
    if any(e.get('time_ns') is None or e['time_ns'] < 0 or e['time_ns'] > cfg['stop_ns'] for e in events):
        raise TraceInvalid('Out-of-window link event')
    if any(events[i].get('link_event_seq')!=i+1 for i in range(len(events))):
        raise TraceInvalid('Noncontiguous link event sequence')
    enq=collections.defaultdict(collections.deque)
    dequeues=drops=phy_drop=positive_wait=0
    per_node=collections.Counter()
    wait_by_node=collections.Counter()
    for e in events:
        typ=e['event_type']; uid=e.get('packet_uid')
        if typ=='QUEUE_ENQUEUE':
            if uid is None: raise TraceInvalid('Enqueue without local UID')
            enq[_identity(e)].append(e['time_ns'])
        elif typ=='QUEUE_DEQUEUE':
            k=_identity(e)
            if not enq[k]: raise TraceInvalid('Dequeue without prior enqueue on same device')
            t=enq[k].popleft()
            w=e.get('queue_wait_ns')
            if w is None or e['time_ns']-t!=w or w<0:
                raise TraceInvalid('Corrupt queue wait or timestamp')
            dequeues+=1
            per_node[(typ,e.get('node_id'))]+=1
            if w>0: positive_wait+=1; wait_by_node[e.get('node_id')]+=1
        elif typ=='QUEUE_DROP':
            drops+=1; per_node[(typ,e.get('node_id'))]+=1
        elif typ=='PHY_RX_DROP':
            phy_drop+=1; per_node[(typ,e.get('node_id'))]+=1
    success=sum(x.get('outcome')=='SUCCESS' for x in episodes)
    cancelled=sum(x.get('outcome')=='CANCELLED' for x in episodes)
    timeouts=sum(x.get('outcome')=='TIMEOUT' for x in episodes)
    nacks=sum(x.get('event')=='NACK' for x in consumer)
    nfd_pit=sum(x.get('event_type')=='DATA_PIT_BIND_1U' for x in nfd)
    # For fragmented payload, physical groups are valid only after a COMPLETE
    # set of indices with the expected count. No packet UID crosses hops.
    groups=collections.defaultdict(list)
    for e in events:
        if e.get('event_type')!='MAC_RX' or e.get('lp_status')!='FRAGMENT': continue
        k=(e.get('node_id'),e.get('face_id'),e.get('lp_group_start_seq'))
        groups[k].append(e)
    complete=0; bad_groups=0
    for g in groups.values():
        counts={e.get('lp_frag_count') for e in g}; idx=[e.get('lp_frag_index') for e in g]
        if len(counts)!=1: bad_groups+=1;continue
        count=next(iter(counts))
        if not isinstance(count,int) or count<2 or len(idx)!=count or set(idx)!=set(range(count)):
            bad_groups+=1;continue
        if any(not e.get('lp_fragment_hex') for e in g): bad_groups+=1;continue
        complete+=1
    # Target verification is an observation, not an F3 label.
    checks={
      'idle': len(arrivals)==0 and len(episodes)==0,
      'low-load': success>0 and drops==0 and dequeues>0,
      'forward-buffered': wait_by_node[1]>0 and per_node[('QUEUE_DROP',1)]==0,
      'return-buffered': wait_by_node[2]>0 and per_node[('QUEUE_DROP',2)]==0,
      'forward-overflow': per_node[('QUEUE_DROP',1)]>0,
      'return-overflow': per_node[('QUEUE_DROP',2)]>0,
      'receive-loss': per_node[('PHY_RX_DROP',2)]>0 and drops==0,
      'propagation-only': success>0 and drops==0 and positive_wait==0 and cfg.get('multi_hop_enabled') is False,
      'no-route': nacks>0 and sum(e.get('event_type')=='TX_INTEREST' for e in nfd)==0,
      'mixed-fragmented': complete>0 and nfd_pit>0 and bad_groups==0 and any(
          x.get('event_type')=='DATA_PIT_BIND_1U' for x in rows(p/'events_hop2.jsonl',required=False)),
    }
    # If a trace is truncated, only attest raw visibility, not path coverage.
    status='PASS_TARGET_EVENT_ONLY' if checks[mode] else 'INCOMPLETE_TARGET_EVENT'
    return {
      'stage':'1Y.PILOT.0','mode':mode,'seed':cfg['seed'],'rng_run':cfg['run'],
      'status':status,'target_event_observed':bool(checks[mode]),
      'n_link_directions':len(devices),'n_raw_link_events':len(events),
      'n_consumer_interest_sends':len(arrivals), 'n_nfd_pit_binds':nfd_pit,
      'n_episodes':len(episodes),'success':success,'timeout':timeouts,'cancelled':cancelled,
      'n_consumer_nacks':nacks,'queue_dequeues':dequeues,'queue_positive_wait':positive_wait,
      'queue_drops':drops,'phy_rx_drops':phy_drop,
      'queue_wait_positive_by_node':{str(k):v for k,v in sorted(wait_by_node.items())},
      'queue_drop_by_node':{str(k[1]):v for k,v in sorted(per_node.items()) if k[0]=='QUEUE_DROP'},
      'phy_rx_drop_by_node':{str(k[1]):v for k,v in sorted(per_node.items()) if k[0]=='PHY_RX_DROP'},
      'complete_lp_groups':complete,'incomplete_lp_groups':bad_groups,
      'unmatched_queue_enqueues_at_trace_end':sum(map(len,enq.values())),
      'path_level_negative_validated':False,
      'online_congestion':None,'future_congestion':None,
      'causal_congestion_attribution':None,'F3_ready':False,'training_ready':False,
      'label_status':'UNKNOWN_NOT_FULL_PATH_VALIDATED',
      'monitor_overhead_comparison_completed':False,
      'note':'A scenario PASS is a control occurrence, not an F3 label or causal proof.'
    }


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('run_dir'); ap.add_argument('--output')
    a=ap.parse_args()
    r=validate(a.run_dir)
    dest=Path(a.output) if a.output else Path(a.run_dir)/'stage1y_verification.json'
    dest.write_text(json.dumps(r,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')
    print(r['mode'],r['status'], 'queueDrops', r['queue_drops'], 'lpGroups',r['complete_lp_groups'])
    if not r['target_event_observed']: raise SystemExit(2)

if __name__=='__main__':main()
