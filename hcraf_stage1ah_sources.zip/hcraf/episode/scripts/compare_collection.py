import json,sys
from pathlib import Path
from episodes import require
root=Path(sys.argv[1]);reports=[]
for mode in ('control','receive-outage'):
 for p in ('0','0.05','1'):
  a,b=[root/(mode+'-p'+p)/('repeat-'+str(i)) for i in (1,2)]
  for name in ('events.jsonl','events.jsonl.decisions.jsonl','events.jsonl.collection.jsonl','events.jsonl.states.jsonl','link_events.jsonl','consumer_events.jsonl','fault_events.jsonl','episodes.jsonl','episode_roles.jsonl','collection_verification.json','state_verification.json'):
   require((a/name).read_bytes()==(b/name).read_bytes(),'repeat mismatch '+str(a/name))
  for f in (a,b):
   r=json.loads((f/'collection_verification.json').read_text());require(r['status']=='PASS','failed verification');reports.append(r)
result=dict(status='PASS',runs=len(reports),episodes=sum(r['episodes'] for r in reports),repeated_runs_are_not_independent=True,main_campaign_executed=False,training_ready=False)
(root/'collection_summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
