#!/usr/bin/env python3
"""Stage 1AF: development-only, fail-closed multi-Face mechanism verifier.

All outputs are diagnostic evidence tiers, NEVER FutureCongestion or training labels.
The forced Face assignment has behavioral probability 1.0, not the nominal
uniform 1/3 recorded inside the NFD collection trace.
"""
import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path
from verify_stage1w import fragmented_groups, audit_ingresses

REGIMES=('LOW_LOAD','BUFFER_NO_DROP','OVERFLOW_DROP','LP_CLEAN','LP_PRESSURE')
TOPOLOGIES=('DEV_CHAIN_A','DEV_CHAIN_B')
RUNS=(8101,8102,8103)
THETA=2
HORIZON_NS=2_000_000_000

class EvidenceError(ValueError): pass

def require(condition,message):
    if not condition: raise EvidenceError(message)

def read(path):
    p=Path(path)
    require(p.is_file(), 'Missing required file '+str(path))
    return [json.loads(s) for s in p.read_text(encoding='utf8').splitlines() if s.strip()]

def pressure(e,theta=THETA):
    if e.get('event_type')=='QUEUE_DROP':return True
    if e.get('event_type')!='QUEUE_DEQUEUE':return False
    w,n,b=e.get('queue_wait_ns'),e.get('packet_bytes'),e.get('data_rate_bps')
    require(all(type(x)==int and x>=0 for x in (w,n,b)) and n>0 and b>0,
            'Invalid queue service evidence')
    return w*b>theta*8*n*1_000_000_000

def extract_plan(cfg):
    require(cfg.get('collector_stage')=='1AF.DEV_MULTIFACE.0','Wrong stage identity')
    require(cfg.get('topology_id') in TOPOLOGIES and cfg.get('mode') in REGIMES,'Unknown development case')
    require(cfg.get('run') in RUNS and cfg.get('seed')==17,'Unexpected RNG identity')
    require(cfg.get('selected_face_slot') in (0,1,2),'Slot mismatch')
    s=cfg['selected_face_slot'];e=cfg.get('eligible_face_ids')
    require(isinstance(e,list) and len(e)==len(set(e))==3 and all(type(x)==int for x in e), 'Three distinct actual Faces required')
    require(cfg.get('selected_face_id')==e[s],'Selected slot does not match real NFD Face mapping')
    require(cfg.get('actual_assignment_probability')==1.0 and
            abs(cfg.get('nominal_uniform_probability_NOT_behavioral_propensity',0)-1/3)<1e-10 and
            cfg.get('selection_policy')=='FORCED_DETERMINISTIC_DRAW_UNIFORM_NOMINAL', 'Confused nominal and behavioral propensity')
    relay=2+s
    producer=({0:5,1:6,2:7} if cfg['topology_id']=='DEV_CHAIN_A' else {0:7,1:5,2:6})[s]
    require(cfg.get('path_nodes')==[0,1,relay,producer] and
            cfg.get('selected_relay_node_id')==relay and cfg.get('selected_producer_node_id')==producer,
            'Actual path topology was not pinned')
    require(cfg.get('multi_hop_enabled') is True and cfg.get('cache_enabled') is False,
            'Wrong controlled topology')
    require(cfg.get('planned_requests',0)>0 and type(cfg['nominal_arrival_interval_ns'])==int, 'Missing arrival plan')
    require(cfg.get('interest_lifetime_ms')==2600 and cfg.get('stop_ns')==20_000_000_000,'Unexpected time boundaries')
    require(cfg.get('theta_pilot')==2 and cfg.get('horizon_ms_pilot')==2000,'Threshold or horizon changed')
    require(cfg.get('instrument_enabled') is True,'Monitor absent')
    require(cfg.get('decision_time_us_real_HCRAF') is None and cfg.get('observer_cost_is_decision_time') is False,
            'Misleading decision time')
    for field in ('congestion','future_congestion'):
        require(cfg.get(field) is None,'Research label present')
    for field in ('training_ready','F3_ready'):
        require(cfg.get(field) is False,'Premature research authorization')
    return relay,producer

def complete_unfragmented_path(ep, cfg, link, hop1, hop2):
    """Strict full 2-hop packet/service/PIT certificate; UID never crosses devices."""
    if ep['outcome']!='SUCCESS' or ep['end_ns']>ep['start_ns']+HORIZON_NS:
        return False,'OUTCOME_OR_HORIZON_CENSORED',[],[]
    start,end=ep['start_ns'],ep['end_ns']
    name=ep['name']; nonce=ep['tx_nonces'][0]
    relay=cfg['selected_relay_node_id'];producer=cfg['selected_producer_node_id']
    face=cfg['selected_face_id']
    rel_tx=[e for e in hop2 if e.get('event_type')=='TX_INTEREST' and e.get('name')==name and e.get('nonce')==nonce]
    binds1=[e for e in hop1 if e.get('event_type')=='DATA_PIT_BIND_1U' and e.get('name')==name and
            str(e.get('pit_instance_id'))==str(ep.get('pit_instance_id'))]
    binds2=[e for e in hop2 if e.get('event_type')=='DATA_PIT_BIND_1U' and e.get('name')==name]
    if len(rel_tx)!=1 or len(binds1)!=1 or len(binds2)!=1:
        return False,'MISSING_OR_AMBIGUOUS_NFD_BIND',[],[]
    if not start<=binds1[0]['time_ns']<=end or not start<=binds2[0]['time_ns']<=end:
        return False,'NFD_BIND_OUT_OF_WINDOW',[],[]
    def getone(kind,node,face_id,typ,lower=start,upper=end):
        return [e for e in link if e.get('event_type')==typ and e.get('node_id')==node and
                e.get('face_id')==face_id and e.get('ndn_packet_type')==kind and e.get('ndn_name')==name and
                (kind!='INTEREST' or e.get('ndn_nonce')==nonce) and lower<=e['time_ns']<=upper]
    # Receiving devices supply their own local Face IDs; not hardcoded or inherited UID.
    rx1=[e for e in link if e.get('event_type')=='MAC_RX' and e.get('node_id')==relay and
         e.get('ndn_packet_type')=='INTEREST' and e.get('ndn_name')==name and
         e.get('ndn_nonce')==nonce and start<=e['time_ns']<=end]
    rx2=[e for e in link if e.get('event_type')=='MAC_RX' and e.get('node_id')==producer and
         e.get('ndn_packet_type')=='INTEREST' and e.get('ndn_name')==name and
         e.get('ndn_nonce')==nonce and start<=e['time_ns']<=end]
    if len(rx1)!=1 or len(rx2)!=1:return False,'INGRESS_FACE_AMBIGUOUS',[],[]
    ingress_face=rx1[0]['face_id'];prod_face=rx2[0]['face_id']
    steps=[(1,face,relay,ingress_face,'INTEREST'),
           (relay,rel_tx[0]['face_id'],producer,prod_face,'INTEREST'),
           (producer,prod_face,relay,rel_tx[0]['face_id'],'DATA'),
           (relay,ingress_face,1,face,'DATA')]
    proofs=[]
    for sender,sface,receiver,rface,kind in steps:
        dq=getone(kind,sender,sface,'QUEUE_DEQUEUE')
        if len(dq)!=1:return False,'QUEUE_SERVICE_MISSING_OR_AMBIGUOUS',[],[]
        event=dq[0]
        if event.get('lp_status')=='FRAGMENT':return False,'LP_REASSEMBLY_REQUIRED',[],[]
        key=(event['node_id'],event['device_index'],event['packet_uid'])
        def local(typ):
            return [x for x in link if x.get('event_type')==typ and
                    (x.get('node_id'),x.get('device_index'),x.get('packet_uid'))==key]
        enq=local('QUEUE_ENQUEUE');tb=local('PHY_TX_BEGIN');te=local('PHY_TX_END')
        if len(enq)!=1 or len(tb)!=1 or len(te)!=1:
            return False,'LOCAL_PACKET_LIFECYCLE_INCOMPLETE',[],[]
        if not (start<=enq[0]['time_ns']<=event['time_ns']<=tb[0]['time_ns']<=te[0]['time_ns']<=end):
            return False,'INVALID_SEND_TIME_ORDER',[],[]
        if event.get('queue_wait_ns')!=event['time_ns']-enq[0]['time_ns']:
            return False,'QUEUE_WAIT_NOT_REPRODUCIBLE',[],[]
        receptions=getone(kind,receiver,rface,'MAC_RX',te[0]['time_ns'],end)
        if len(receptions)!=1:return False,'PHYSICAL_RECEIVE_MISSING_OR_AMBIGUOUS',[],[]
        proofs.append(event)
    directions={(sender,sface) for sender,sface,_,_,_ in steps}
    require(len(directions)==4,'Path directions collided')
    return True,'COMPLETE_FOUR_DIRECTION_PATH',proofs,directions

def verify(root):
    root=Path(root)
    cfg=json.loads((root/'scenario.json').read_text(encoding='utf8'))
    relay,producer=extract_plan(cfg)
    regime=cfg['mode'];slot=cfg['selected_face_slot']
    eps=read(root/'episodes.jsonl')
    decisions=read(root/'events.jsonl.decisions.jsonl')
    collection=read(root/'events.jsonl.collection.jsonl')
    first=read(root/'events.jsonl')
    relay_nfd=read(root/f'events_hop2_node{relay}.jsonl')
    link=read(root/'link_events.jsonl')
    schedule=read(root/'consumer_events.jsonl.arrivals.jsonl')
    sent=[r for r in read(root/'consumer_events.jsonl') if r['event']=='SEND']
    state=read(root/'events.jsonl.states.jsonl')
    observer=read(root/'observer_cost.jsonl')
    n=cfg['planned_requests']
    require(len(eps)==len(decisions)==len(collection)==len(sent)==len(schedule)==n,
            'Decision/Episode/selection/schedule cardinality mismatch')
    require(len({e['name'] for e in eps})==n and len({e['episode_id'] for e in eps})==n,
            'Names or Episode keys are not unique in this pilot')
    require({r['name'] for r in sent}=={e['name'] for e in eps},'Consumer and PIT name mismatch')
    require(len({r['decision_id'] for r in decisions})==n,'Duplicate decision ID')
    require(len(observer)==n and all(r.get('is_NFD_decision_latency') is False for r in observer),
            'Observer overhead is not HCRAF decision latency')
    require(all(r.get('Congestion') is None and r.get('research_training_eligible') is False for r in state),
            'Online feature leakage')
    expected_face=cfg['selected_face_id']
    for d,s in zip(decisions,collection):
        require(d.get('decision_id')==s.get('decision_id') and d['name'] in {x['name'] for x in eps},
                'Non-aligned NFD decision/selection')
        actual={x['face_id'] for x in d['candidates']}
        require(actual==set(cfg['eligible_face_ids']) and len(actual)==3,'Actual FIB has not exactly three Faces')
        require(s.get('policy')=='uniform' and s.get('selected_face_id')==expected_face and
                abs(s.get('selected_action_probability',0)-1/3)<1e-10,
                'NFD controlled Face selection/nominal probability unexpected')
        require({x['face_id'] for x in s.get('candidates',[])}==actual,
                'Nominal policy candidate set inconsistent with FIB')
        require(abs(s['uniform_draw']-(slot+0.5)/3.0)<1e-12,'Controlled draw not pinned')
    tx=[e for e in first if e.get('event_type')=='TX_INTEREST']
    require(len(tx)==n and all(e['face_id']==expected_face for e in tx),
            'Interest not sent exactly once on targeted Face')
    require(all(ep.get('face_id')==expected_face and ep.get('node_id')==1 and
                ep.get('outcome') in ('SUCCESS','TIMEOUT','NACK','CANCELLED') for ep in eps),
            'Incorrect terminal Episode or selected Face')
    require(all(e['schema_version']=='1W.0' and e['link_event_seq']==i and
                type(e['time_ns'])==int for i,e in enumerate(link,1)),
            'Invalid link trace sequence/schema')
    init={(e['node_id'],e['device_index']) for e in link if e['event_type']=='INITIAL'}
    final={(e['node_id'],e['device_index']) for e in link if e['event_type']=='FINAL'}
    require(len(init)==14 and init==final,'Not all 14 physical directions monitored')
    require(all(e['time_ns']<=cfg['stop_ns'] for e in link),'Out-of-simulation event')
    by_name=defaultdict(list)
    for ev in link:
        if ev.get('ndn_name'):by_name[ev['ndn_name']].append(ev)
    tx_by={e['name']:e for e in tx}
    sent_by={x['name']:x for x in sent}
    require(len(tx_by)==len(sent_by)==n,'Duplicated outgoing Interests')
    for ep in eps:
        t=tx_by[ep['name']];c=sent_by[ep['name']]
        require(t.get('nonce')==c.get('nonce') and ep['start_ns']==t['time_ns'] and
                len(ep.get('tx_nonces',[]))==1 and ep['tx_nonces'][0]==t['nonce'],
                'PIT/Nonce/time mismatch')
    rel_tx=[x for x in relay_nfd if x.get('event_type')=='TX_INTEREST']
    require(all(x.get('node_id')==relay for x in relay_nfd) and len(rel_tx)>0,
            'Second-hop forwarding evidence missing')
    # Queue lifecycle audit independent of Outcome and NFD evidence.
    from collections import deque
    queued=defaultdict(deque)
    for e in link:
        key=(e.get('node_id'),e.get('device_index'),e.get('packet_uid'))
        typ=e['event_type']
        if typ=='QUEUE_ENQUEUE':queued[key].append(e['time_ns'])
        elif typ=='QUEUE_DEQUEUE':
            require(queued[key],'Orphan queue dequeue')
            require(e['time_ns']-queued[key].popleft()==e.get('queue_wait_ns'),'Queue wait not reproducible')
    # Actual selected hop link directions are identified from NFD Face + trace.
    primary_directions={(e['node_id'],e['device_index']) for e in link
        if e['node_id']==1 and e['face_id']==expected_face}
    require(len(primary_directions)==1,'Selected outgoing Face not uniquely mapped to a device')
    primary_dir=next(iter(primary_directions))
    rows=[]
    for ep in eps:
        start=ep['start_ns'];end=min(ep['end_ns'],start+HORIZON_NS,cfg['stop_ns'])
        require(type(start)==int and type(ep['end_ns'])==int and ep['end_ns']>=start,
                'Invalid Episode time')
        nonce=ep['tx_nonces'][0]
        local=[e for e in by_name[ep['name']]
               if e['event_type'] in ('QUEUE_DROP','QUEUE_DEQUEUE') and
               e.get('node_id')==1 and e.get('face_id')==expected_face and
               e.get('ndn_packet_type')=='INTEREST' and e.get('ndn_nonce')==nonce and
               start<=e['time_ns']<=end]
        direct=[e['link_event_seq'] for e in local if pressure(e)]
        # Do not promote contextual queue pressure or fragmented, name-only Data.
        ctx=[e['link_event_seq'] for e in link if
             (e['node_id'],e['device_index'])==primary_dir and
             e['event_type'] in ('QUEUE_DROP','QUEUE_DEQUEUE') and
             start<=e['time_ns']<=end and pressure(e)]
        complete, completeness_reason, path_packets, path_dirs = (
            complete_unfragmented_path(ep,cfg,link,first,relay_nfd)
            if regime not in ('LP_CLEAN','LP_PRESSURE') else
            (False,'FRAGMENT_PATH_CERTIFICATE_SEPARATE',[],[]))
        if complete:
            for q in path_packets:
                if pressure(q):direct.append(q['link_event_seq'])
            # Path pressure may be due to other traffic: don't silently issue zero.
            path_context=[e['link_event_seq'] for e in link if
                (e['node_id'],e['face_id']) in path_dirs and
                e['event_type'] in ('QUEUE_DROP','QUEUE_DEQUEUE') and
                start<=e['time_ns']<=end and pressure(e)]
        else:path_context=ctx
        if direct: tier='DIRECT_PACKET_DIAGNOSTIC';reason='UNIQUE_PACKET_QUEUE_PROOF'
        elif path_context: tier='CONTEXT_ONLY';reason='SHARED_PATH_NOT_SAME_PACKET'
        elif complete: tier='NEGATIVE_FOUR_DIRECTION_DIAGNOSTIC';reason='COMPLETE_PATH_NO_QUEUE_PRESSURE'
        else: tier='UNKNOWN';reason=completeness_reason
        rows.append(dict(episode_id=ep['episode_id'],name=ep['name'],outcome=ep['outcome'],
             selected_face_id=expected_face,topology_id=cfg['topology_id'],regime=regime,
             rng_run=cfg['run'],t_start_ns=start,t_end_ns=ep['end_ns'],horizon_end_ns=end,
             direct_event_seqs=sorted(set(direct)),path_context_event_seqs=sorted(set(path_context)),
             complete_four_direction_path=bool(complete),
             evidence_tier=tier,reason=reason,Congestion=None,FutureCongestion=None,
             F3_ready=False,training_ready=False))
    # Link-layer fragmentation proof: CLEAN must have complete physical groups
    # and router Data/PIT bindings; PRESSURE may remain censored/UNKNOWN.
    grouped=[];fragment_status='NOT_APPLICABLE';fragment_unresolved=0
    if regime in ('LP_CLEAN','LP_PRESSURE'):
        rxfrag=[x for x in link if x.get('event_type')=='MAC_RX' and x.get('lp_status')=='FRAGMENT']
        groups=defaultdict(list)
        for e in rxfrag:groups[(e['node_id'],e['face_id'],e['lp_group_start_seq'])].append(e)
        fragment_unresolved=sum(len({x.get('lp_frag_index') for x in g})!=g[0].get('lp_frag_count') for g in groups.values())
        if regime=='LP_CLEAN':
            grouped=fragmented_groups(link)
            require(grouped and not fragment_unresolved,'LP_CLEAN had no complete all-physical groups')
            # Explicit binding at relay; complete LP grouping is not itself an Episode label.
            ingress=audit_ingresses(relay_nfd,link,grouped)
            require(any(x.get('physical_evidence')=='COMPLETE_NDN_LP_REASSEMBLY' for x in ingress),
                    'LP_CLEAN lacks relay NFD↔reassembled MAC_RX↔PIT proof')
            fragment_status='COMPLETE_REASSEMBLY_WITH_NFD_BIND'
        else:
            fragment_status='UNRESOLVED_ALLOWED_AS_UNKNOWN' if fragment_unresolved else 'ALL_OBSERVED_GROUPS_COMPLETE'
    target=False
    if regime=='LOW_LOAD':
        # Strictly no zero label from SUCCESS. Only require a clean control
        # with unambiguous NFD Episode termination and no local pressure.
        target=any(r['evidence_tier']=='NEGATIVE_FOUR_DIRECTION_DIAGNOSTIC' for r in rows)
    elif regime=='BUFFER_NO_DROP':
        target=any(r['direct_event_seqs'] for r in rows) and not any(e['event_type']=='QUEUE_DROP'
               and (e['node_id'],e['device_index'])==primary_dir for e in link)
    elif regime=='OVERFLOW_DROP':
        target=any(e['event_type']=='QUEUE_DROP' and (e['node_id'],e['device_index'])==primary_dir and
                   e.get('ndn_packet_type')=='INTEREST' for e in link)
    elif regime=='LP_CLEAN':target=fragment_status=='COMPLETE_REASSEMBLY_WITH_NFD_BIND'
    elif regime=='LP_PRESSURE':target=bool(rxfrag) and (fragment_unresolved>0 or any(e['event_type']=='QUEUE_DROP' and e.get('lp_status')=='FRAGMENT' for e in link))
    summary=dict(stage='1AF.DEV_MULTIFACE.0',status='PASS_TARGET_EVENT_ONLY' if target else 'INCOMPLETE_TARGET_EVENT',
       topology_id=cfg['topology_id'],regime=regime,rng_run=cfg['run'],slot=slot,selected_face_id=expected_face,
       eligible_face_ids=cfg['eligible_face_ids'],behavioral_assignment_probability=1.0,
       nominal_uniform_probability=1/3,episode_count=len(eps),outcomes=dict(Counter(x['outcome'] for x in eps)),
       diagnostic_tiers=dict(Counter(x['evidence_tier'] for x in rows)),
       fragment_status=fragment_status,fragment_incomplete_groups=fragment_unresolved,
       all_14_directions_monitored=True,observed_target=bool(target),
       HCRAF_policy_evaluation=False,decision_time_gate='BLOCKED',
       Congestion=None,FutureCongestion=None,F3_ready=False,training_ready=False)
    (root/'stage1af_verification.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n',encoding='utf8')
    with (root/'stage1af_episode_tiers.jsonl').open('w',encoding='utf8') as f:
        for row in rows:f.write(json.dumps(row,sort_keys=True)+'\n')
    return summary

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('run_dir');a.add_argument('--fail-on-incomplete',action='store_true')
    args=a.parse_args();r=verify(args.run_dir);print(json.dumps(r,ensure_ascii=False))
    if args.fail_on_incomplete and r['status']!='PASS_TARGET_EVENT_ONLY':raise SystemExit(2)
