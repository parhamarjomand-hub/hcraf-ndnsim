#!/usr/bin/env python3
"""1AD: conservative attribution/timing audit of authentic 1AB GitHub artifact.

Research-safe by construction: all classifications are DEVELOPMENT_DIAGNOSTIC,
Congestion / FutureCongestion remain null, F3_ready/training_ready are false.
No off-policy labels, no unknown -> zero, and no run-level pseudo-replication.
"""
import argparse
import collections
import csv
import hashlib
import json
from pathlib import Path
import zipfile

MODES = ('low-load','propagation-only','forward-buffered','return-buffered',
         'forward-overflow','return-overflow','receive-loss','mixed-fragmented')
RUNS=(6101,6102,6103)
HORIZONS=(250,1000,2000)
THETAS=(1,2,4)
# Node+device ID at transmitting end of monitored two-hop path.
PATH_DIRS={(1,1),(2,1),(5,0),(2,0)}
FORWARD={(1,1),(2,1)}
BACKWARD={(5,0),(2,0)}
PHYSICAL_RECEIVE={(2,0),(5,0),(2,1),(1,1)}
EXPECTED_COMMIT='e80fa69d916c5878604b7a1f049e83dc65f3df4d'


def jsonl(data):
    return [json.loads(s) for s in data.decode('utf-8').splitlines() if s.strip()]


def assert_artifact(z):
    manifest=json.loads(z.read('manifest.json'))
    expected=manifest.get('artifact_sha256',{})
    if len(expected)!=692 or manifest.get('git_commit')!=EXPECTED_COMMIT:
        raise ValueError('Unexpected origin, commit or hash list length')
    for name,hash_value in expected.items():
        if hashlib.sha256(z.read(name)).hexdigest()!=hash_value:
            raise ValueError('SHA256 mismatch in '+name)
    if hashlib.sha256(z.read('source_bundle.zip')).hexdigest()!=manifest['source_zip_sha256']:
        raise ValueError('Unpinned source ZIP')
    return len(expected)


def safe_ratio_exceeded(e,theta):
    w=e.get('queue_wait_ns'); n=e.get('packet_bytes'); bps=e.get('data_rate_bps')
    if not all(isinstance(x,int) and not isinstance(x,bool) and x>=0 for x in (w,n,bps)) or n==0 or bps==0:
        return None
    # Exact integer computation, never float threshold or equality ambiguity.
    return w*bps>theta*8*n*1_000_000_000


def check_pit_binding(events,ep, end):
    # Under this *controlled* 1AB topology, one unique full name per run,
    # no CS, one producer, and NFD PIT binding on relay node 2.
    target=ep['name']
    binds=[x for x in events if x.get('event_type')=='DATA_PIT_BIND_1U'
           and x.get('name')==target and x.get('node_id')==2 and x.get('time_ns',-1)<=end]
    tx=[x for x in events if x.get('event_type')=='TX_INTEREST' and x.get('name')==target
        and x.get('node_id')==2]
    return len(binds)==1 and len(tx)==1 and tx[0]['time_ns']<=binds[0]['time_ns']


def find_episode_direct_events(ep,linked,nfd_relay,theta,start,end):
    """Use only packet/face/time evidence plus relay PIT bind for Data.

    On sender 1,1 Interest matches exact name+nonce+face. At hop-2 forwarding,
    a known relay TX and unique name+nonce are required. Data needs unique
    producer name and explicit relay PIT binding when available; without the
    binding, it is unobserved/ambiguous rather than direct proof. Fragmented
    wire packets do not qualify as complete packet evidence here.
    """
    if not isinstance(ep.get('tx_nonces'),list) or len(ep['tx_nonces'])!=1:
        return {'count':0,'drop':0,'high_wait':0,'invalid':1,'source_codes':[],'event_seqs':[],
                'reasons':['NOT_SINGLE_TX_NONCE']}
    nonce=ep['tx_nonces'][0]
    relay_txs=[x for x in nfd_relay if x.get('event_type')=='TX_INTEREST' and x.get('name')==ep['name']]
    relay_tx_unique=len(relay_txs)==1
    relay_data_bound=check_pit_binding(nfd_relay,ep,end)
    # Name uniqueness is independently enforced per run; no name-only matching across runs.
    observed=[];bad=[]
    for e in linked:
        typ=e.get('event_type'); loc=(e.get('node_id'),e.get('device_index'))
        if loc not in PATH_DIRS or typ not in ('QUEUE_DROP','QUEUE_DEQUEUE'):
            continue
        # A packet directly identified by PIT/Name/Nonce/Face may be queued or dropped
        # at the same ns tick as the decision; its NFD TX identity supplies
        # logical causality where cross-source event numbers are incomparable.
        if not start <= e.get('time_ns',-1) <= end: continue
        if e.get('ndn_name')!=ep['name']:continue
        if e.get('lp_status')=='FRAGMENT':
            bad.append('FRAGMENT_REQUIRES_REASSEMBLY');continue
        if e.get('wire_status') not in ('PILOT','VALID'):
            bad.append('INVALID_WIRE');continue
        ptype=e.get('ndn_packet_type')
        if loc in FORWARD and ptype=='INTEREST':
            if e.get('ndn_nonce')!=nonce:
                bad.append('NONCE_MISMATCH');continue
            if loc==(1,1) and e.get('face_id')!=ep.get('face_id'):
                bad.append('FACE_MISMATCH');continue
            if loc==(2,1) and not relay_tx_unique:
                bad.append('RELAY_TX_UNPROVEN');continue
        elif loc in BACKWARD and ptype=='DATA':
            if not relay_data_bound:
                bad.append('NO_UNIQUE_RELAY_DATA_PIT_BIND');continue
        else:
            continue
        if typ=='QUEUE_DEQUEUE':
            comp=safe_ratio_exceeded(e,theta)
            if comp is None:
                bad.append('QUEUE_SERVICE_INCOMPLETE');continue
            flag=bool(comp)
        else:
            flag=True
        if flag:
            observed.append(e)
    codes=[]
    if any(x['event_type']=='QUEUE_DROP' for x in observed):codes.append('DIRECT_EPISODE_DROP')
    if any(x['event_type']=='QUEUE_DEQUEUE' for x in observed):codes.append('DIRECT_EPISODE_WAIT')
    return {'count':len(observed),'drop':sum(x['event_type']=='QUEUE_DROP' for x in observed),
            'high_wait':sum(x['event_type']=='QUEUE_DEQUEUE' for x in observed),
            'invalid':len(bad),'source_codes':codes,
            'event_seqs':[x['link_event_seq'] for x in observed],'reasons':sorted(set(bad))}


def contextual_pressure(link,start,end,theta):
    pressure=[];invalid=[];phy=[]
    for e in link:
        typ=e.get('event_type');loc=(e.get('node_id'),e.get('device_index'))
        if not start < e.get('time_ns',-1) <= end:continue
        if typ=='PHY_RX_DROP' and loc in PHYSICAL_RECEIVE:
            phy.append(e['link_event_seq'])
        if loc not in PATH_DIRS or typ not in ('QUEUE_DROP','QUEUE_DEQUEUE'):continue
        if e.get('ndn_packet_type') not in ('INTEREST','DATA') and e.get('lp_status')!='FRAGMENT':
            invalid.append(e['link_event_seq']);continue
        if typ=='QUEUE_DROP':pressure.append(e['link_event_seq'])
        else:
            outcome=safe_ratio_exceeded(e,theta)
            if outcome is None:invalid.append(e['link_event_seq'])
            elif outcome:pressure.append(e['link_event_seq'])
    return {'pressure':pressure,'invalid':invalid,'phy':phy}


def classify(ep,prior,context,direct,finish, horizon,mode):
    # Provisional EVIDENCE TIER, NOT a binary classifier training label.
    if direct['count']:
        return 'DIRECT_EPISODE_PRESSURE_DIAGNOSTIC','DIRECT_PACKET_EVIDENCE'
    # Not a negative when routing/wire evidence is ambiguous or fragmented.
    if mode=='mixed-fragmented':return 'UNKNOWN','FRAGMENT_REASSEMBLY_NOT_PROVEN_FOR_QUEUE'
    if context['pressure']:
        return 'PATH_CONTEXT_ONLY','NON_EPISODE_SPECIFIC_PRESSURE'
    if direct['invalid'] or context['invalid']:
        return 'UNKNOWN','INVALID_OR_AMBIGUOUS_LINK_EVIDENCE'
    if context['phy']:
        return 'UNKNOWN','PHYSICAL_RECEIVE_LOSS'
    if finish > horizon:return 'UNKNOWN','TERMINAL_AFTER_HORIZON'
    if ep['outcome']!='SUCCESS':return 'UNKNOWN','NON_SUCCESS_WITHOUT_DIRECT_PROOF'
    if not prior.get('complete_path'):return 'UNKNOWN','INCOMPLETE_TWO_HOP_CHAIN'
    # The prior verifier certified four directions and all services / receive events.
    matched=prior.get('matched_directions') or []
    if len(matched)!=4 or any(
            not isinstance(x.get('queue_wait_ns'),int) or x.get('queue_wait_ns')<0
            or not isinstance(x.get('packet_bytes'),int) or x.get('packet_bytes')<=0
            for x in matched):return 'UNKNOWN','MISSING_QUEUE_SERVICE_CERTIFICATE'
    return 'ZERO_QUEUE_PRESSURE_CERTIFICATE_DIAGNOSTIC','COMPLETE_TWO_HOP_AND_NO_PRESSURE'


def process_one(z,mode,run,theta=2,horizon_ms=1000):
    base=f'stage1ab/monitored/{mode}/run-{run}/'
    cfg=json.loads(z.read(base+'scenario.json'))
    if cfg.get('collector_stage')!='1AB.FEASIBILITY.0' or cfg.get('stage1ab_case_role')!='DEVELOPMENT_ONLY':
        raise ValueError('Wrong stage or training split')
    if cfg.get('congestion') is not None or cfg.get('future_congestion') is not None or cfg.get('training_ready'):
        raise ValueError('Forbidden training-ready input')
    eps=jsonl(z.read(base+'episodes.jsonl'))
    diags=jsonl(z.read(base+'stage1ab_episode_diagnostics.jsonl'))
    dr={str(e['episode_id']):e for e in diags}
    if len(dr)!=len(diags) or len(eps)!=len(diags):raise ValueError('Duplicated/missing diagnostic Episode')
    names=[e['name'] for e in eps]
    if len(set(names))!=len(names):raise ValueError('Ambiguous Name collision; requires a different pilot')
    link=jsonl(z.read(base+'link_events.jsonl'))
    nfd=jsonl(z.read(base+'events_hop2.jsonl'))
    # Strong source-level consistency checks. Do not silently skip incomplete trace.
    if any(e.get('schema_version')!='1W.0' or e.get('link_event_seq')!=i+1 for i,e in enumerate(link)):
        raise ValueError('Corrupt link sequence/schema')
    if not {(x['node_id'],x['device_index']) for x in link if x['event_type']=='INITIAL'}.issuperset(PATH_DIRS):
        raise ValueError('Missing path direction monitoring')
    results=[]
    for ep in eps:
        prior=dr.get(str(ep['episode_id']))
        if not prior or prior.get('name')!=ep['name'] or prior['start_ns']!=ep['start_ns'] or prior['end_ns']!=ep['end_ns']:
            raise ValueError('Inconsistent original Episode/diagnostic identity')
        start=ep['start_ns']
        finish=ep['end_ns']
        if not isinstance(finish,int) or finish<start:raise ValueError('Invalid terminal time')
        horizon=min(start+horizon_ms*1_000_000,finish,cfg['stop_ns'])
        ct=contextual_pressure(link,start,horizon,theta)
        dc=find_episode_direct_events(ep,link,nfd,theta,start,horizon)
        tier,reason=classify(ep,prior,ct,dc,finish,horizon,mode)
        results.append({'stage':'1AD.DIAGNOSTIC.0','mode':mode,'rng_run':run,'episode_id':ep['episode_id'],
             'pit_instance_id':ep['pit_instance_id'],'selected_face':ep['face_id'],
             'name':ep['name'],'outcome':ep['outcome'],'start_ns':start,'terminal_ns':finish,
             'window_end_ns':horizon,'horizon_ms':horizon_ms,'theta':theta,
             'complete_path':bool(prior['complete_path']),'direct_drop_count':dc['drop'],
             'direct_high_wait_count':dc['high_wait'],'direct_source_codes':'|'.join(dc['source_codes']),
             'direct_event_seq_ids':'|'.join(map(str,dc['event_seqs'])),
             'ambiguous_direct_candidates':dc['invalid'],
             'context_pressure_count':len(ct['pressure']),
             'context_event_seq_ids':'|'.join(map(str,ct['pressure'])),
             'invalid_context_count':len(ct['invalid']),'physical_loss_count':len(ct['phy']),
             'diagnostic_tier':tier,'reason':reason,
             'Congestion':None,'FutureCongestion':None,'F3_ready':False,'training_ready':False})
    return results


def save_csv(path,rows):
    with open(path,'w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]),extrasaction='raise')
        writer.writeheader();writer.writerows(rows)


def compute(zip_path,out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(zip_path) as z:
        count=assert_artifact(z)
        primary=[];sensitivity=[]
        for mode in MODES:
            for run in RUNS:
                primary+=process_one(z,mode,run)
                for h in (250,2000):
                    sensitivity+=process_one(z,mode,run,horizon_ms=h)
                for theta in (1,4):
                    sensitivity+=process_one(z,mode,run,theta=theta)
    assert len(primary)==1116 and len(sensitivity)==4464
    runs=[]
    for mode in MODES:
        for run in RUNS:
            subset=[r for r in primary if r['mode']==mode and r['rng_run']==run]
            c=collections.Counter(r['diagnostic_tier'] for r in subset)
            runs.append({'mode':mode,'rng_run':run,'episodes':len(subset),
                 'direct':c['DIRECT_EPISODE_PRESSURE_DIAGNOSTIC'],
                 'context_only':c['PATH_CONTEXT_ONLY'],
                 'zero_queue_certificate':c['ZERO_QUEUE_PRESSURE_CERTIFICATE_DIAGNOSTIC'],
                 'unknown':c['UNKNOWN'],
                 'complete_path':sum(r['complete_path'] for r in subset),
                 'direct_on_timeout':sum(r['diagnostic_tier']=='DIRECT_EPISODE_PRESSURE_DIAGNOSTIC' and r['outcome']=='TIMEOUT' for r in subset)})
    save_csv(out/'episode_evidence_1ad.csv',primary)
    save_csv(out/'per_run_1ad.csv',runs)
    totals=collections.Counter(r['diagnostic_tier'] for r in primary)
    # Store concise sensitivity per different parameter, no manipulated study records.
    sweeps=[]
    for h,theta in ((250,2),(1000,1),(1000,2),(1000,4),(2000,2)):
        records=primary if (h,theta)==(1000,2) else [r for r in sensitivity if r['horizon_ms']==h and r['theta']==theta]
        co=collections.Counter(r['diagnostic_tier'] for r in records)
        sweeps.append({'horizon_ms':h,'theta':theta,'episodes':len(records),
               'direct':co['DIRECT_EPISODE_PRESSURE_DIAGNOSTIC'],
               'context_only':co['PATH_CONTEXT_ONLY'],
               'negative_diagnostic':co['ZERO_QUEUE_PRESSURE_CERTIFICATE_DIAGNOSTIC'],
               'unknown':co['UNKNOWN']})
    save_csv(out/'sensitivity_1ad.csv',sweeps)
    summary={'stage':'1AD','status':'DEVELOPMENT_ONLY_NEEDS_NEW_VALIDATION','source':'1AB v0.26.2 real GitHub Action',
      'verified_artifact_sha256_items':count,'run_count':len(runs),'episode_count':len(primary),
      'primary_definition':'EPISODE_TERMINAL_CLIPPED','proposal_theta':2,'proposal_horizon_ms':1000,
      'diagnostic_counts':dict(totals),'direct_dropout_timeouts':sum(r['direct_drop_count']>0 and r['outcome']=='TIMEOUT' for r in primary),
      'direct_positive_timeouts':sum(r['diagnostic_tier']=='DIRECT_EPISODE_PRESSURE_DIAGNOSTIC' and r['outcome']=='TIMEOUT' for r in primary),
      'by_sensitivity':sweeps,'scientific_decision':'REVISE_SCOPE','GO_FREEZE':False,
      'Congestion':None,'FutureCongestion':None,'F3_ready':False,'training_ready':False,
      'note':'Evidence tiers are NON-TRAINING exploratory diagnostics. No final causal congestion label or dataset is generated.'}
    (out/'summary_1ad.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))
    return summary

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('artifact_zip');p.add_argument('out_folder');a=p.parse_args()
    compute(a.artifact_zip,a.out_folder)
