import json,hashlib,sys
from pathlib import Path
from episodes import load,require


def verify(root):
    hashes=json.loads((Path(__file__).resolve().parents[1]/'docs/stage1l_control_baseline.json').read_text())['hashes']
    for name,h in hashes.items():require(hashlib.sha256((root/'regression'/name).read_bytes()).hexdigest()==h,'two-face regression mismatch '+name)
    reports=[];unique=[]
    files=('events.jsonl','events.jsonl.decisions.jsonl','events.jsonl.collection.jsonl','events.jsonl.states.jsonl','link_events.jsonl','consumer_events.jsonl','consumer_events.jsonl.arrivals.jsonl','fault_events.jsonl','episodes.jsonl','episode_roles.jsonl','coverage_verification.json','state_verification.json')
    for policy in ('uniform','coverage'):
        for mode in ('control','receive-outage'):
            for run in range(1001,1005):
                f=root/policy/mode/('run-'+str(run))/'repeat-1'
                r=json.loads((f/'coverage_verification.json').read_text());require(r['status']=='PASS','failed run')
                reports.append(dict(mode=mode,run=run,repeat=1,**r))
                unique.append(dict(mode=mode,run=run,**r))
                if run==1001:
                    g=f.parent/'repeat-2'
                    for name in files:require((f/name).read_bytes()==(g/name).read_bytes(),'repeated-run mismatch '+str(g/name))
                    reports.append(dict(mode=mode,run=run,repeat=2,**r))
                reference=root/'uniform'/'control'/('run-'+str(run))/'repeat-1'
                require((f/'consumer_events.jsonl.arrivals.jsonl').read_bytes()==(reference/'consumer_events.jsonl.arrivals.jsonl').read_bytes(),'unpaired offered traffic')
                x=load(f/'events.jsonl.collection.jsonl');y=load(reference/'events.jsonl.collection.jsonl')
                require([c['uniform_draw'] for c in x]==[c['uniform_draw'] for c in y],'unpaired selection draws')
    schedules=[(root/'uniform'/'control'/('run-'+str(r))/'repeat-1/consumer_events.jsonl.arrivals.jsonl').read_bytes() for r in range(1001,1005)]
    require(len(set(schedules))==4,'RngRun variation did not change arrivals')
    result=dict(status='PASS',new_simulator_runs=len(reports),distinct_conditions=16,independent_rng_run_blocks=4,deterministic_repeats=4,regression_runs=2,regression_raw_hash_checks=len(hashes),episodes_including_repeats=sum(x['episodes'] for x in reports),episodes_excluding_repeats=sum(x['episodes'] for x in unique),training_ready=False,main_campaign_executed=False,results=reports)
    (root/'coverage_summary.json').write_text(json.dumps(result,indent=2)+'\n');return {k:v for k,v in result.items() if k!='results'}

if __name__=='__main__':
    root=Path(sys.argv[1])
    try:print(json.dumps(verify(root)))
    except Exception as e:
        (root/'coverage_summary.json').write_text(json.dumps(dict(status='FAIL',error=str(e)))+'\n');raise
