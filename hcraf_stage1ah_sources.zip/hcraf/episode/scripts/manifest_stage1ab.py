#!/usr/bin/env python3
"""Manifest even for incomplete 1AB attempts, with pinned artifact provenance."""
import hashlib,json,os,platform,subprocess,sys
from pathlib import Path
from datetime import datetime,timezone
root=Path(sys.argv[1]).resolve()
out=root/'episode_output';out.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
try:revision=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()
except (OSError,subprocess.CalledProcessError):revision=os.getenv('GITHUB_SHA','UNAVAILABLE')
files={str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='manifest.json'}
code={str(p.relative_to(root)):sha(p) for p in sorted((root/'hcraf/episode').rglob('*'))
      if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
wf=root/'.github/workflows/hcraf-stage1ab.yml'
if wf.is_file():code[str(wf.relative_to(root))]=sha(wf)
m={'schema_version':'1AB.FEASIBILITY.0','created_at_utc':datetime.now(timezone.utc).isoformat(),
 'git_commit':revision,'github_run_id':os.getenv('GITHUB_RUN_ID'),'github_run_attempt':os.getenv('GITHUB_RUN_ATTEMPT'),
 'source_zip_sha256':sha(root/'hcraf_stage1ab_sources.zip') if (root/'hcraf_stage1ab_sources.zip').exists() else None,
 'python':platform.python_version(),'artifact_sha256':files,'code_sha256':code,
 'F3_ready':False,'training_ready':False,'Congestion':None,'FutureCongestion':None,
 'environment_fully_locked':False,'limit':'ubuntu:20.04 tag and apt repository snapshot not pinned by OCI digest'}
(out/'manifest.json').write_text(json.dumps(m,indent=2,sort_keys=True)+'\n')
