import hashlib,json,sys
from pathlib import Path
from collections import Counter
from episodes import load,require


def verify(root):
    baseline=json.loads((Path(__file__).resolve().parents[1]/'docs/stage1k_raw_baseline.json').read_text())
    checks=0
    for name,digest in baseline['hashes'].items():
        require(hashlib.sha256((root/'add-on'/name).read_bytes()).hexdigest()==digest,'Stage1K regression mismatch '+name);checks+=1
    rows=[]
    for policy in ('add-on','single'):
        probabilities=('0','0.05','1') if policy=='add-on' else ('0','0.05','0.5','1')
        for mode in ('control','receive-outage'):
            for p in probabilities:
                a,b=[root/policy/(mode+'-p'+p)/('repeat-'+str(i)) for i in (1,2)]
                report='selection_verification.json' if policy=='single' else 'collection_verification.json'
                for name in ('events.jsonl','events.jsonl.decisions.jsonl','events.jsonl.collection.jsonl','events.jsonl.states.jsonl','link_events.jsonl','consumer_events.jsonl','fault_events.jsonl','episodes.jsonl','episode_roles.jsonl',report,'state_verification.json'):
                    require((a/name).read_bytes()==(b/name).read_bytes(),'repeat mismatch '+str(a/name))
                for f in (a,b):
                    r=json.loads((f/report).read_text());require(r['status']=='PASS','verification failed')
                    rows.append(dict(policy=policy,mode=mode,p=float(p),repeat=f.name,**r))
                # Paired RNG: same draw per request across policies; not independent replications.
                if policy=='single' and p in ('0','0.05','1'):
                    ref=root/'add-on'/(mode+'-p'+p)/'repeat-1'
                    x=load(a/'events.jsonl.collection.jsonl');y=load(ref/'events.jsonl.collection.jsonl')
                    require([v['uniform_draw'] for v in x]==[v['uniform_draw'] for v in y],'paired RNG mismatch')
                if policy=='single' and p=='0':
                    ref=root/'add-on'/(mode+'-p'+p)/'repeat-1'
                    for name in ('events.jsonl','events.jsonl.decisions.jsonl','events.jsonl.states.jsonl','consumer_events.jsonl','link_events.jsonl'):
                        require((a/name).read_bytes()==(ref/name).read_bytes(),'p0 behavioral equivalence '+name)
    # This is a smoke-test support requirement, not a general coverage guarantee.
    for mode in ('control','receive-outage'):
        f=root/'single'/(mode+'-p0.5')/'repeat-1';ep=load(f/'episodes.jsonl')
        faces=Counter(e['face_id'] for e in ep)
        require(len(faces)==2 and min(faces.values())>0,'p0.5 did not sample both faces')
    report=dict(status='PASS',runs=len(rows),stage1k_raw_hash_checks=checks,
        episodes=sum(r['episodes'] for r in rows),repeats_are_not_independent=True,
        research_training_ready=False,main_campaign_executed=False,results=rows)
    (root/'selection_summary.json').write_text(json.dumps(report,indent=2)+'\n')
    return {k:v for k,v in report.items() if k!='results'}

if __name__=='__main__':
    root=Path(sys.argv[1])
    try:print(json.dumps(verify(root)))
    except Exception as e:
        (root/'selection_summary.json').write_text(json.dumps(dict(status='FAIL',error=str(e)))+'\n');raise
