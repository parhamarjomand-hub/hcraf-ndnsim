"""Compare C++ live decision state with the frozen Stage1E Python definition."""
import json,math,sys
from pathlib import Path
from collections import defaultdict
from episodes import load,require
from causal_reference import past_features

def compare_values(actual,expected):
 for key,v in expected.items():
  require(key in actual,'missing state field '+key)
  got=actual[key]
  if v is None:require(got is None,'expected missing '+key)
  elif type(v) is int:require(type(got) is int and got==v,'integer mismatch '+key)
  else:require(type(got) in (int,float) and math.isfinite(got) and math.isclose(got,v,rel_tol=1e-12,abs_tol=1e-9),'numeric mismatch '+key)

def compare(ep,ev,ds,states):
 evidence={e['event_seq']:e for e in ev};by=defaultdict(list)
 for e in ep:by[e['face_id']].append(e)
 require(len(states)==sum(len(d['candidates']) for d in ds),'missing state rows')
 lookup={(x['decision_id'],x['face_id']):x for x in states};require(len(lookup)==len(states),'duplicate state row')
 for d in ds:
  for c in d['candidates']:
   key=(d['decision_id'],c['face_id']);require(key in lookup,'missing decision-face state');row=lookup[key]
   f,missing,a=past_features(by[c['face_id']],evidence,d['time_ns'],d['after_event_seq'],10**9,.125,c['routing_cost'])
   expected={k:f[k] for k in ('RoutingCost','SRTT_ms','SuccessEstimate','Goodput_bps')}
   expected.update(time_ns=d['time_ns'],after_event_seq=d['after_event_seq'],valid_outcomes=a['valid_outcomes'],valid_rtt=a['valid_rtt'],max_terminal_event_seq=a['max_terminal_event_seq'] or 0,
    last_outcome_evidence_age_ns=a['last_outcome_evidence_age_ns'],last_rtt_evidence_age_ns=a['last_rtt_evidence_age_ns'])
   compare_values(row,expected)
 return len(states)

def verify(folder):
 ev=load(folder/'events.jsonl');ep=load(folder/'episodes.jsonl');ds=load(folder/'events.jsonl.decisions.jsonl');states=load(folder/'events.jsonl.states.jsonl');links=load(folder/'link_events.jsonl');cfg=json.loads((folder/'scenario.json').read_text())
 require(cfg.get('state_estimator_stage')=='1I.1','missing live-state scenario marker')
 n=compare(ep,ev,ds,states)
 for s in states:
  require(s['schema_version']=='1I.1' and s['node_id']==1 and s['context_prefix']=='/hcraf/pilot','state scope')
  require(s['Congestion'] is None and s['research_training_eligible'] is False,'unexpected final congestion')
 snap={(x['decision_id'],x['node_id'],x['face_id']):x for x in links if x['event_type']=='DECISION_SNAPSHOT'}
 for s in states:
  x=snap[(s['decision_id'],s['node_id'],s['face_id'])]
  compare_values(x,{'LocalQueueOccupancyFraction':x['queue_packets']/cfg['queue_capacity_packets']})
  require(x['time_ns']==s['time_ns'],'queue snapshot time mismatch')
 r=dict(status='PASS',state_rows=n,causal_reference='STAGE1E_TERMINAL_EVIDENCE_ARRIVAL',window_ns=10**9,srtt_alpha=.125,parameters_final=False,local_queue_candidate_checked=True,proves_hcraf_performance=False)
 (folder/'state_verification.json').write_text(json.dumps(r,indent=2)+'\n');return r
if __name__=='__main__':
 p=Path(sys.argv[1])
 try:print(json.dumps(verify(p)))
 except Exception as e:
  (p/'state_verification.json').write_text(json.dumps({'status':'FAIL','error':str(e)})+'\n');raise
