#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK_DIR="$PROJECT_DIR/hcraf/episode"
OUTPUT_DIR="$PROJECT_DIR/episode_output"
cd "$PROJECT_DIR/episode_sources/ns-3"
status=0
for mode in baseline repeat-name retransmission aggregation cache-hit multi-hop; do
  for run in 1001 1002; do
    folder="$OUTPUT_DIR/stage1s/$mode/run-$run"
    mkdir -p "$folder"
    command="hcraf-robustness-pilot --mode=$mode --output=$folder --seed=17 --run=$run"
    printf '%s\n' "$command" > "$folder/command.txt"
    if ! python3 ./waf --run-no-build "$command" > "$folder/simulator.log" 2>&1; then
      echo "FAIL simulator mode=$mode run=$run";status=1;continue
    fi
    if ! python3 "$TASK_DIR/scripts/episodes.py" "$folder" --run-id "1s-$mode-17-$run"; then
      echo "FAIL episode reconstruction mode=$mode run=$run";status=1;continue
    fi
    if ! python3 "$TASK_DIR/scripts/verify_robustness.py" "$folder"; then
      echo "FAIL robustness verification mode=$mode run=$run";status=1
    fi
  done
done
if ! python3 "$TASK_DIR/scripts/summarize_robustness.py" "$OUTPUT_DIR/stage1s"; then status=1;fi
exit "$status"
