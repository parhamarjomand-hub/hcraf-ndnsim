#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
bash "$TASK/scripts/build_stage1ab.sh"
cd "$ROOT/episode_sources/ns-3"
test -s "$TASK/src/hcraf-stage1ad-pilot.cpp"
cp "$TASK/src/hcraf-stage1ad-pilot.cpp" scratch/hcraf-stage1ad-pilot.cc
cmp -s "$TASK/src/hcraf-stage1ad-pilot.cpp" scratch/hcraf-stage1ad-pilot.cc
# These approved headers are installed by build_stage1ab.sh.
for h in hcraf-stage1w-monitor.hpp hcraf-stage1w-lp.hpp hcraf-wire-decode.hpp; do
  test -s "scratch/$h"
done
python3 ./waf -j 2
test -x build/scratch/hcraf-stage1ad-pilot
