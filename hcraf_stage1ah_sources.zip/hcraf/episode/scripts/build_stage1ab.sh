#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
bash "$TASK/scripts/build_stage1y_amendment.sh"
cd "$ROOT/episode_sources/ns-3"
for header in hcraf-stage1w-monitor.hpp hcraf-stage1w-lp.hpp hcraf-wire-decode.hpp; do
  test -s "$TASK/src/$header"
done
cp "$TASK/src/hcraf-stage1ab-pilot.cpp" scratch/hcraf-stage1ab-pilot.cc
cp "$TASK/src/hcraf-stage1w-monitor.hpp" scratch/hcraf-stage1w-monitor.hpp
cp "$TASK/src/hcraf-stage1w-lp.hpp" scratch/hcraf-stage1w-lp.hpp
cp "$TASK/src/hcraf-wire-decode.hpp" scratch/hcraf-wire-decode.hpp
cmp -s "$TASK/src/hcraf-stage1ab-pilot.cpp" scratch/hcraf-stage1ab-pilot.cc
python3 ./waf -j 2
test -x build/scratch/hcraf-stage1ab-pilot
