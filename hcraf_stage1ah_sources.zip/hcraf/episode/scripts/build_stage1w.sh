#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK_DIR="$PROJECT_DIR/hcraf/episode"
SOURCE_DIR="$PROJECT_DIR/episode_sources/ns-3"
# 1W v0.21.1 build-wiring repair only. No changes to the forwarding path.
# Reuse exactly pinned NFD and prior Stage1U instrumentation.
bash "$TASK_DIR/scripts/build_stage1u.sh"
# waf builds scratch targets in the scratch/ tree. Headers required by the
# Stage1W monitor must be copied next to the pilot, not left in hcraf/episode/src.
for header in hcraf-stage1w-monitor.hpp hcraf-stage1w-lp.hpp; do
  test -s "$TASK_DIR/src/$header"
  cp "$TASK_DIR/src/$header" "$SOURCE_DIR/scratch/$header"
  cmp -s "$TASK_DIR/src/$header" "$SOURCE_DIR/scratch/$header" || {
    echo "Stage1W header copy mismatch: $header" >&2
    exit 1
  }
done
# Headers installed by the pinned prior stages must still be present.
test -s "$SOURCE_DIR/scratch/hcraf-wire-decode.hpp"
test -s "$SOURCE_DIR/scratch/hcraf-collection-policy.hpp"
cp "$TASK_DIR/src/hcraf-stage1w-pilot.cpp" "$SOURCE_DIR/scratch/hcraf-stage1w-pilot.cc"
cmp -s "$TASK_DIR/src/hcraf-stage1w-pilot.cpp" "$SOURCE_DIR/scratch/hcraf-stage1w-pilot.cc"
cd "$SOURCE_DIR"
python3 ./waf -j 2
test -x build/scratch/hcraf-stage1w-pilot
