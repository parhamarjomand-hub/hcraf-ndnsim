#!/usr/bin/env python3
"""Observed-evidence acceptance only. Missing or invalid runs must be INCOMPLETE."""
import json
import sys
from pathlib import Path
from collections import Counter
from verify_stage1w import MODES


def summarize(folder):
    folder=Path(folder)
    detail=[]
    missing=[]
    for mode in MODES:
        for run in (1001,1002):
            p=folder/mode/('run-'+str(run))/'stage1w_verification.json'
            if not p.is_file():
                missing.append(str(p))
                continue
            r=json.loads(p.read_text(encoding='utf8'))
            if r.get('scenario')!=mode or r.get('run')!=run or r.get('acceptance')!='PASS_SCENARIO_EVIDENCE':
                missing.append(str(p)+' (failed check)')
                continue
            detail.append(r)
    result={'schema':'1W.0','expected_runs':len(MODES)*2,'verified_runs':len(detail),
            'missing_or_invalid_runs':missing,
            'physical_evidence_counts':dict(sum((Counter(r['physical_evidence_counts']) for r in detail),Counter())),
            'nfd_data_ingresses':sum(r['nfd_data_ingresses'] for r in detail),
            'ndnlp_complete_reassembly_groups_at_mac_rx':sum(r['complete_lp_groups_at_mac_rx'] for r in detail),
            'simultaneous_different_face_groups':sum(len(r['same_time_different_face_groups']) for r in detail),
            'acceptance':'PASS' if not missing else 'INCOMPLETE',
            'congestion':None,'future_congestion':None,'training_ready':False,
            'runs_detail':[{'scenario':r['scenario'],'run':r['run'],'nfd_data_ingresses':r['nfd_data_ingresses'],
                            'complete_lp_groups':r['complete_lp_groups_at_mac_rx'],
                            'simultaneous_groups':len(r['same_time_different_face_groups'])} for r in detail]}
    (folder/'stage1w_summary.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf8')
    if missing:
        raise ValueError('INCOMPLETE: missing/failed scenario evidence; see stage1w_summary.json')
    return result

if __name__=='__main__':
    try:
        print(json.dumps(summarize(sys.argv[1]),sort_keys=True))
    except Exception as exc:
        print('Stage1W summary invalid:', str(exc),file=sys.stderr)
        sys.exit(1)
