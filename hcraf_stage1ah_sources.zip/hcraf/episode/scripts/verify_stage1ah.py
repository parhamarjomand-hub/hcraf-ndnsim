#!/usr/bin/env python3
"""Stage 1AH group-aware *diagnostic* verifier. No F3 or training labels.

Names/TrafficClass are observed on actual NDN Data reassembly; unreceived
fragments are not identified by name, by regime, or by sender-side packet UID.
Each physical packet is keyed by sender-local (node,device,uid); LP sequence
is used only within a sender/receiver Face. Unknown is NOT negative.
"""
import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path
from verify_stage1af import EvidenceError, require
from verify_stage1w import varnum, need

STAGE='1AH.GROUP_AWARE.0'
TOPOLOGIES=('DEV_CHAIN_A','DEV_CHAIN_B')
REGIMES=('LP_SELF_ONLY','LP_INDEPENDENT_COMPETITOR_NO_DROP',
         'LP_INDEPENDENT_COMPETITOR_DROP','UNFRAGMENTED_MATCHED_BYTES')
RUNS=(9101,9102,9103)
THETAS=(1,2,4)
HORIZONS_NS=(1_000_000_000,1_500_000_000,2_000_000_000)

def read(path):
    require(path.is_file(),'Missing file '+str(path))
    return [json.loads(s) for s in path.read_text().splitlines() if s.strip()]

def one(items,message):
    require(len(items)==1,message+': '+str(len(items)))
    return items[0]

def traffic_class(name):
    if name.startswith('/hcraf/pilot/'):
        return 'TARGET'
    if name.startswith('/hcraf/competitor/'):
        return 'INDEPENDENT_COMPETITOR'
    return 'UNATTRIBUTED'

def parse_data_groupaware(data):
    """Stage 1AH: strictly decode complete Data for both preregistered traffic classes."""
    kind, off = varnum(data, 0)
    length, off = varnum(data, off)
    need(kind == 6 and off+length == len(data), 'Reassembly is not a whole NDN Data packet')
    end = off+length
    names = []
    while off < end:
        field, p = varnum(data, off)
        size, p = varnum(data, p)
        need(p+size <= end, 'NDN Data field crosses boundary')
        if field == 7:
            need(not names, 'Duplicate NDN Data name')
            components=[]
            start=p
            while p < start+size:
                c, p = varnum(data, p)
                n, p = varnum(data, p)
                need(c == 8 and p+n <= start+size, 'Unsupported or invalid NDN name component')
                item=data[p:p+n]
                components.append(''.join(chr(x) if (48<=x<=57 or 65<=x<=90 or 97<=x<=122 or x in (45,46,95,126)) else '%%%02X'%x for x in item))
                p += n
            need(components and p == start+size,'Invalid NDN name')
            names.append('/'+'/'.join(components))
        off = p+size if field != 7 else start+size
    need(len(names)==1 and traffic_class(names[0]) in ('TARGET','INDEPENDENT_COMPETITOR'),
         'No unique registered-class Data name in reassembly')
    return names[0]



def validate_config(c):
    require(c.get('collector_stage')==STAGE,'Unexpected stage identifier')
    require(c.get('mode') in REGIMES and c.get('topology_id') in TOPOLOGIES,'Unregistered regime/topology')
    require(c.get('run') in RUNS and c.get('seed')==17,'Non-pre-registered RNG')
    s=c.get('selected_face_slot');faces=c.get('eligible_face_ids')
    require(type(s)==int and s in (0,1,2),'Invalid Face slot')
    require(type(faces)==list and len(faces)==len(set(faces))==3 and
            all(type(f)==int for f in faces) and c.get('selected_face_id')==faces[s],
            'Three actual distinct Faces must match recorded selection')
    require(c.get('actual_assignment_probability')==1.0 and
            abs(c.get('nominal_uniform_probability_NOT_behavioral_propensity',0)-1/3)<1e-10,
            'Nominal policy probability was confused with forced assignment')
    relay=2+s;producer=({0:5,1:6,2:7} if c['topology_id']=='DEV_CHAIN_A' else
                       {0:7,1:5,2:6})[s]
    require(c.get('selected_relay_node_id')==relay and
            c.get('selected_producer_node_id')==producer and
            c.get('path_nodes')==[0,1,relay,producer], 'Wrong actual three-Face topology')
    require(c.get('instrument_enabled') is True and c.get('cache_enabled') is False and
            c.get('multi_hop_enabled') is True, 'Missing complete monitoring')
    require(c.get('traffic_class_primary')=='TARGET' and
            c.get('traffic_class_competitor')=='INDEPENDENT_COMPETITOR' and
            c.get('target_prefix')=='/hcraf/pilot' and
            c.get('competitor_prefix')=='/hcraf/competitor','Missing registered traffic identities')
    inject=c['mode'] in REGIMES[1:3]
    require(c.get('competitor_injection_enabled') is inject and
            bool(c.get('competitor_planned_requests')) is inject,'Competitor design mismatch')
    require(c.get('planned_requests',0)>0 and type(c.get('nominal_arrival_interval_ns'))==int and
            c['nominal_arrival_interval_ns']>0, 'Missing target traffic schedule')
    require(c.get('payload_bytes')==4096 and c.get('mtu_bytes')==(9000 if c['mode']==REGIMES[3] else 600),
            'Matched payload or LP MTU incorrect')
    require(c.get('interest_lifetime_ms')==2600 and c.get('stop_ns')==20_000_000_000,
            'Unexpected Episode/lifetime boundaries')
    require(c.get('theta_pilot')==2 and c.get('horizon_ms_pilot')==2000,
            'Unregistered initial threshold/horizon')
    require(c.get('decision_time_us_real_HCRAF') is None and
            c.get('observer_cost_is_decision_time') is False,
            'Observer wall clock is NOT HCRAF decision time')
    require(all(c.get(k) is None for k in ('congestion','future_congestion')) and
            all(c.get(k) is False for k in ('training_ready','F3_ready')),
            'Research labels/training approval cannot be generated in 1AH')
    return relay

def ratio_positive(e,theta):
    if e['event_type']=='QUEUE_DROP':return True
    if e['event_type']!='QUEUE_DEQUEUE':return False
    wait,bits,size=e.get('queue_wait_ns'),e.get('data_rate_bps'),e.get('packet_bytes')
    require(type(wait)==int and wait>=0 and type(bits)==int and bits>0 and
            type(size)==int and size>0, 'Invalid queue wait/size/rate')
    return wait*bits>theta*8*size*1_000_000_000

def overlap(a,b,c,d):
    return max(0,min(b,d)-max(a,c))

def union_length(intervals):
    intervals=sorted((a,b) for a,b in intervals if b>a)
    if not intervals:return 0
    x,y=intervals[0];total=0
    for a,b in intervals[1:]:
        if a>y:total+=y-x;x,y=a,b
        else:y=max(y,b)
    return total+y-x

def adjusted_wait(q, earlier_tx):
    """M2: subtract actual preceding same-LP-Group transmit busy time, never an estimate.
    Reject incomplete or ambiguous transmit intervals rather than impute them.
    """
    w=q['queue_wait_ns'];require(type(w)==int and w>=0,'Unknown queue wait')
    enq=q['time_ns']-w;deq=q['time_ns']
    same=union_length([(max(enq,a),min(deq,b)) for a,b in earlier_tx])
    require(0<=same<=w,'Same-group busy time exceeds wait window')
    return w-same

def recovered_groups(link, node, face):
    """Only actually received, complete and parsed Data groups are name-attributed."""
    rx=defaultdict(list)
    for e in link:
        if e.get('event_type')=='MAC_RX' and e.get('node_id')==node and e.get('face_id')==face and e.get('lp_status')=='FRAGMENT':
            rx[e.get('lp_group_start_seq')].append(e)
    ok=[];bad=[]
    for seq,items in sorted(rx.items()):
        ns={x.get('lp_frag_count') for x in items}
        n=next(iter(ns)) if len(ns)==1 else None
        ix=[x.get('lp_frag_index') for x in items]
        if type(seq)!=int or type(n)!=int or n<2 or len(items)!=n or sorted(ix)!=list(range(n)):
            bad.append(dict(lp_group_start_seq=seq,reason='INCOMPLETE_OR_AMBIGUOUS_RX_GROUP',rx_count=len(items)))
            continue
        if any(x.get('lp_seq')!=(seq+x['lp_frag_index'])%(2**64) for x in items):
            bad.append(dict(lp_group_start_seq=seq,reason='LP_SEQUENCE_INCONSISTENT',rx_count=len(items)));continue
        try:
            data=b''.join(bytes.fromhex(x['lp_fragment_hex']) for x in sorted(items,key=lambda x:x['lp_frag_index']))
            name=parse_data_groupaware(data)
        except (ValueError,KeyError,TypeError):
            bad.append(dict(lp_group_start_seq=seq,reason='UNPARSEABLE_RECEIVED_DATA',rx_count=len(items)));continue
        ok.append(dict(start_seq=seq,name=name,traffic_class=traffic_class(name),
                       recv_time_ns=max(x['time_ns'] for x in items),rx=items,
                       total_rx_bytes=sum(x['packet_bytes'] for x in items)))
    return ok,bad

def build_sender_index(link):
    events=defaultdict(lambda: defaultdict(list))
    for e in link:
        if e['event_type'] in ('QUEUE_ENQUEUE','QUEUE_DEQUEUE','QUEUE_DROP','PHY_TX_BEGIN','PHY_TX_END'):
            key=(e.get('node_id'),e.get('device_index'),e.get('packet_uid'))
            events[key][e['event_type']].append(e)
    return events

def lifecycle(dq,events):
    key=(dq['node_id'],dq['device_index'],dq['packet_uid'])
    z=events[key]
    enq=one(z['QUEUE_ENQUEUE'],'Missing/ambiguous QUEUE_ENQUEUE')
    tb=one(z['PHY_TX_BEGIN'],'Missing/ambiguous PHY_TX_BEGIN')
    te=one(z['PHY_TX_END'],'Missing/ambiguous PHY_TX_END')
    require(enq['time_ns']<=dq['time_ns']<=tb['time_ns']<=te['time_ns'],
            'Invalid physical lifecycle ordering')
    require(dq['queue_wait_ns']==dq['time_ns']-enq['time_ns'],'Nonreproducible queue wait')
    for f in ('lp_seq','lp_group_start_seq','lp_frag_count','lp_frag_index'):
        require(enq.get(f)==dq.get(f)==tb.get(f)==te.get(f),'Local LP identity changed')
    return enq,tb,te

def queue_group_metrics(group,link, sender_node, sender_dev, by_uid, nfd, known_groups, theta=2):
    """Metrics are group diagnostics ONLY. Only actual received groups can obtain traffic class.
    Fragment from *another group* must be distinguished from same-group service.
    """
    seq=group['start_seq'];qs=[]
    for rx in sorted(group['rx'],key=lambda x:x['lp_frag_index']):
        m=[x for x in link if x.get('event_type')=='QUEUE_DEQUEUE' and
           x.get('node_id')==sender_node and x.get('device_index')==sender_dev and
           x.get('lp_status')=='FRAGMENT' and x.get('lp_group_start_seq')==seq and
           x.get('lp_seq')==rx['lp_seq'] and x.get('lp_frag_index')==rx['lp_frag_index']]
        q=one(m,'Missing sender local fragment service')
        enq,tb,te=lifecycle(q,by_uid)
        require(te['time_ns']<=rx['time_ns'] and te['packet_bytes']==rx['packet_bytes'],
                'Physical Data RX mismatch')
        qs.append((q,enq,tb,te))
    require(len(qs)==len(group['rx']),'Fragment service set incomplete')
    waits=[];adjusted=[];first=qs[0][0]
    for i,(q,enq,tb,te) in enumerate(qs):
        prior=[(x[2]['time_ns'],x[3]['time_ns']) for x in qs[:i]]
        r=adjusted_wait(q,prior)
        adjusted.append(r)
        waits.append(q['queue_wait_ns'])
    t0=min(x[1]['time_ns'] for x in qs);t1=max(x[3]['time_ns'] for x in qs)
    keys={x[0]['packet_uid'] for x in qs}
    # Observed independent-group occupancy: a physical service interval of a
    # DIFFERENT LP group overlaps the target group service epoch on this device.
    competing=[]
    for e in link:
        if e.get('event_type')!='PHY_TX_BEGIN' or e.get('node_id')!=sender_node or e.get('device_index')!=sender_dev:
            continue
        if e.get('packet_uid') in keys:continue
        if e.get('lp_status')=='FRAGMENT' and e.get('lp_group_start_seq')==seq:
            continue # even an extra physical retransmission of THIS group is not foreign traffic
        k=(sender_node,sender_dev,e['packet_uid']);z=by_uid[k]
        if len(z['PHY_TX_END'])!=1:continue
        ex=z['PHY_TX_END'][0]
        if overlap(t0,t1,e['time_ns'],ex['time_ns']):
            competing.append(dict(uid=e['packet_uid'],seq=e['link_event_seq'],
                                  lp_group_start_seq=e.get('lp_group_start_seq')))
    # Confirm actual PIT join at receiving decision node, not merely SUCCESS.
    bind=[x for x in nfd if x.get('event_type')=='DATA_PIT_BIND_1U' and
          x.get('name')==group['name'] and x.get('time_ns')==group['recv_time_ns'] and
          x.get('face_id')==group['receiver_face']]
    nfd_confirmed=len(bind)==1
    # No missing-source default: even if no wait, no automatic negative F3 label.
    m0=any(ratio_positive(x[0],theta) for x in qs)
    m1=ratio_positive(first,theta)
    m2=any((r*x[0]['data_rate_bps']>theta*8*x[0]['packet_bytes']*1_000_000_000)
           for r,x in zip(adjusted,qs))
    m3=bool(competing)
    verified_competitor=[x for x in competing if known_groups.get((sender_node,sender_dev,x['uid']))==
                         'INDEPENDENT_COMPETITOR']
    # Deliberately distinguish proven competitor class from any other group.
    # A missing/partial LP reassembly never supplies a made-up traffic class.
    ratios=[q['queue_wait_ns']*q['data_rate_bps']/(8*q['packet_bytes']*1_000_000_000)
            for q,_,_,_ in qs]
    adjusted_ratios=[w*q['data_rate_bps']/(8*q['packet_bytes']*1_000_000_000)
                     for w,(q,_,_,_) in zip(adjusted,qs)]
    return dict(group_start_seq=seq,name=group['name'],traffic_class=group['traffic_class'],
         received_fragments=len(qs),matched_nfd_pit=bool(nfd_confirmed),
         queue_service_complete=True,sender_node=sender_node,sender_device=sender_dev,
         receiver_face_id=group['receiver_face'],first_enqueue_ns=t0,last_phy_tx_end_ns=t1,
         raw_max_queue_wait_ns=max(waits),adjusted_max_wait_ns=max(adjusted),
         first_fragment_wait_ns=first['queue_wait_ns'],
         foreign_group_service_overlap_count=len(competing),
         verified_competitor_service_overlap_count=len(verified_competitor),
         raw_max_ratio=max(ratios),first_fragment_ratio=ratios[0],
         adjusted_max_ratio=max(adjusted_ratios),
         M0_raw_fragment_wait=bool(m0),M1_first_fragment_wait=bool(m1),
         M2_adjusted_fragment_wait=bool(m2),M3_observed_exogenous_service=bool(m3),
         theta=theta,congestion=None,future_congestion=None,F3_ready=False,training_ready=False)

def verify(root):
    root=Path(root)
    cfg=json.loads((root/'scenario.json').read_text(encoding='utf8'))
    relay=validate_config(cfg)
    mode=cfg['mode'];face=cfg['selected_face_id'];n=cfg['planned_requests'];competitors=cfg['competitor_planned_requests']
    target=read(root/'consumer_events.jsonl');comp=read(root/'competitor_events.jsonl') if competitors else []
    for rows,prefix,klass,count in ((target,'/hcraf/pilot/','TARGET',n),
                                    (comp,'/hcraf/competitor/','INDEPENDENT_COMPETITOR',competitors)):
        sends=[x for x in rows if x['event']=='SEND']
        require(len(sends)==count and len({x['name'] for x in sends})==count,
                'Missing or duplicated independent traffic schedule')
        require(all(x.get('traffic_class')==klass and x['name'].startswith(prefix) for x in sends),
                'TrafficClass/name provenance mismatch')
    for klass,filename,count in (('TARGET','consumer_events.jsonl.arrivals.jsonl',n),
                                  ('INDEPENDENT_COMPETITOR','competitor_events.jsonl.arrivals.jsonl',competitors)):
        if count:
            arrivals=read(root/filename)
            require(len(arrivals)==count and all(x.get('traffic_class')==klass for x in arrivals),
                    'Arrival schedule changed or lost TrafficClass identity')
    link=read(root/'link_events.jsonl')
    require(all(e.get('schema_version')=='1W.0' and e.get('link_event_seq')==i for i,e in enumerate(link,1)),
            'Invalid ordered link event stream')
    init={(e['node_id'],e['device_index']) for e in link if e['event_type']=='INITIAL'}
    final={(e['node_id'],e['device_index']) for e in link if e['event_type']=='FINAL'}
    require(len(init)==14 and init==final,'All 14 directions need paired INITIAL/FINAL')
    nfd=read(root/'events.jsonl')
    fwd=[x for x in nfd if x.get('event_type')=='TX_INTEREST']
    expected={x['name'] for x in target+comp if x['event']=='SEND'}
    require(len(fwd)==len(expected) and {x['name'] for x in fwd}==expected and
            all(x['face_id']==face for x in fwd),
            'Both independent classes must actually use the selected NFD Face')
    eps=read(root/'episodes.jsonl')
    require(len(eps)==len(expected) and {x['name'] for x in eps}==expected,
            'Actual reconstructed Episode/Name count mismatch')
    require(all(x.get('outcome') in ('SUCCESS','TIMEOUT','NACK','CANCELLED') for x in eps),
            'Unclosed Episode')
    selected=[(e['node_id'],e['device_index']) for e in link if e.get('node_id')==1 and e.get('face_id')==face and e['event_type']=='INITIAL']
    require(len(selected)==1,'Actual selected Face not mapped to exactly one link')
    # Return direction: NFD forwarding relay node on actual route, uniquely determined
    # by physical MAC_RX at decision node (not a guessed Face id).
    ret_rx=[e for e in link if e['event_type']=='MAC_RX' and e.get('node_id')==1 and e.get('face_id')==face]
    require(ret_rx,'No return-direction physical observation')
    candidate_nodes={e.get('node_id') for e in link if e.get('event_type')=='PHY_TX_END' and e.get('node_id')==relay}
    require(relay in candidate_nodes,'Selected relay has no PHY transmission')
    return_devs={(e['node_id'],e['device_index']) for e in link if e.get('node_id')==relay and
                 e.get('event_type')=='INITIAL' and e.get('face_id') is not None and
                 e.get('device_index') is not None}
    # Join sender↔receiver by LP sequence, packet size and observed PHY end order.
    complete=[];bad=[];data_recovered=[];unknown_sender_groups=[];sensitivity=[]
    if mode!='UNFRAGMENTED_MATCHED_BYTES':
        complete,bad=recovered_groups(link,1,face)
        by_uid=build_sender_index(link)
        # Index sender-local fragment groups; groups without valid receiver-side
        # reassembly are UNATTRIBUTABLE, not target or competitor by guess.
        sender_groups=defaultdict(list)
        for e in link:
            if (e.get('node_id')==relay and e.get('event_type') in ('QUEUE_ENQUEUE','QUEUE_DROP') and
                    e.get('lp_status')=='FRAGMENT' and type(e.get('lp_group_start_seq'))==int):
                sender_groups[(e['node_id'],e['device_index'],e['lp_group_start_seq'])].append(e)
        require(bool(complete or bad or sender_groups),'Expected physical fragment observation')
        # Complete groups are joined by all sender packet fragments, not only an LP sequence.
        group_senders={}
        known_groups={}
        for group in complete:
            tx_matches=[]
            for node,dev in sorted(return_devs):
                qs=[e for e in link if e.get('event_type')=='QUEUE_DEQUEUE' and
                    e.get('node_id')==node and e.get('device_index')==dev and
                    e.get('lp_group_start_seq')==group['start_seq'] and
                    e.get('lp_status')=='FRAGMENT']
                if len(qs)==len(group['rx']) and len(qs)>1:
                    tx_matches.append((node,dev,qs))
            require(len(tx_matches)==1,'Ambiguous sender return direction for LP group')
            node,dev,qs=tx_matches[0]
            group_senders[group['start_seq']]=(node,dev)
            for q in qs:known_groups[(node,dev,q['packet_uid'])]=group['traffic_class']
        confirmed_sender_group_keys={(node,dev,seq) for seq,(node,dev) in group_senders.items()}
        for key,items in sorted(sender_groups.items()):
            if key not in confirmed_sender_group_keys:
                unknown_sender_groups.append(dict(sender_node=key[0],sender_device=key[1],
                    lp_group_start_seq=key[2],reason='NO_COMPLETE_RECEIVER_AND_PIT_JOIN',
                    physical_queue_drop_events=sum(e['event_type']=='QUEUE_DROP' for e in items)))
        for group in complete:
            group['receiver_face']=face
            node,dev=group_senders[group['start_seq']]
            data_recovered.append(queue_group_metrics(group,link,node,dev,by_uid,nfd,known_groups))
    else:
        require(not any(e.get('lp_status')=='FRAGMENT' for e in link),
                'Unfragmented matched-byte regime had real LP fragments')
        unfrag=[e for e in link if e['event_type']=='MAC_RX' and e.get('node_id')==1 and
                e.get('face_id')==face and e.get('ndn_packet_type')=='DATA' and
                traffic_class(e.get('ndn_name') or '')=='TARGET']
        require(unfrag,'No actual non-LP target Data receipts')
        require(all(type(e.get('packet_bytes'))==int and 4096<=e['packet_bytes']<=9000
                    for e in unfrag),'Real unfragmented Data bytes do not match intended payload')
        data_recovered=[dict(name=e['ndn_name'],traffic_class='TARGET',receiver_face_id=face,
            queue_service_complete=False,matched_nfd_pit=bool([x for x in nfd if
            x.get('event_type')=='DATA_PIT_BIND_1U' and x.get('name')==e['ndn_name'] and
            x.get('time_ns')==e['time_ns']]),M0_raw_fragment_wait=None,
            M1_first_fragment_wait=None,M2_adjusted_fragment_wait=None,
            M3_observed_exogenous_service=None) for e in unfrag]
    drop=[e for e in link if e['event_type']=='QUEUE_DROP' and e.get('node_id')==relay and
          any(e['device_index']==d for _,d in return_devs) and e.get('lp_status')=='FRAGMENT']
    # Sensitivity is bound to the actual Episode start and NFD completion. No
    # negative/positive TRAINING labels are materialized, even in clean runs.
    eps_by_name={x['name']:x for x in eps}
    require(len(eps_by_name)==len(eps),'Duplicate Episode name makes join ambiguous')
    for group in data_recovered:
        ep=eps_by_name.get(group['name'])
        require(ep is not None,'Reassembled Data without actual Episode')
        if ep['outcome']=='SUCCESS':
            require(ep.get('payload_bytes')==4096,'Real delivered Data content size mismatch')
        for horizon in HORIZONS_NS:
            within=bool(group.get('matched_nfd_pit') and ep['start_ns']<=
                        group.get('last_phy_tx_end_ns',ep['end_ns'])<=
                        ep['start_ns']+horizon and ep['end_ns']<=ep['start_ns']+horizon)
            for theta in THETAS:
                sensitivity.append(dict(name=group['name'],traffic_class=group['traffic_class'],
                  horizon_ms=horizon//1_000_000,theta=theta,
                  evidence_status='GROUP_DIAGNOSTIC_ONLY' if within else 'UNKNOWN',
                  M0=(group.get('raw_max_ratio',-1)>theta) if within and 'raw_max_ratio' in group else None,
                  M1=(group.get('first_fragment_ratio',-1)>theta) if within and 'first_fragment_ratio' in group else None,
                  M2=(group.get('adjusted_max_ratio',-1)>theta) if within and 'adjusted_max_ratio' in group else None,
                  M3=group.get('M3_observed_exogenous_service') if within else None,
                  verified_competitor_overlap=group.get('verified_competitor_service_overlap_count') if within else None,
                  Congestion=None,FutureCongestion=None,F3_ready=False,training_ready=False))
    actual_competitor_sent=len([e for e in fwd if traffic_class(e['name'])=='INDEPENDENT_COMPETITOR'])
    # IMPORTANT: C2 dropped fragments are not treated as known TARGET/COMPETITOR without an RX join.
    # Fail-open results are never allowed: all runs retain raw evidence and an incomplete status.
    detected=False
    if mode=='LP_SELF_ONLY':
        detected=(not drop and not actual_competitor_sent and
                  any(x['traffic_class']=='TARGET' for x in data_recovered))
    elif mode=='LP_INDEPENDENT_COMPETITOR_NO_DROP':
        detected=(not drop and actual_competitor_sent==competitors and
                  any(x['traffic_class']=='TARGET' and x.get('matched_nfd_pit') for x in data_recovered) and
                  any(x['traffic_class']=='INDEPENDENT_COMPETITOR' and x.get('matched_nfd_pit')
                      for x in data_recovered) and
                  any(x.get('verified_competitor_service_overlap_count',0)>0
                      for x in data_recovered if x['traffic_class']=='TARGET'))
    elif mode=='LP_INDEPENDENT_COMPETITOR_DROP':
        detected=bool(drop and actual_competitor_sent==competitors)
    elif mode=='UNFRAGMENTED_MATCHED_BYTES':
        detected=bool(data_recovered and not actual_competitor_sent)
    status='PASS_TARGET_EVENT_ONLY' if detected else 'INCOMPLETE_TARGET_EVENT'
    # Explicitly do not turn dropped unknown fragments or success into a zero label.
    summary=dict(stage=STAGE,status=status,regime=mode,topology_id=cfg['topology_id'],
      face_slot=cfg['selected_face_slot'],selected_face_id=face,rng_run=cfg['run'],
      actual_assignment_probability=1.0,monitored_all_14_directions=True,
      target_episodes=sum(traffic_class(x['name'])=='TARGET' for x in eps),
      competitor_episodes=sum(traffic_class(x['name'])=='INDEPENDENT_COMPETITOR' for x in eps),
      outcomes=dict(Counter(x['outcome'] for x in eps)),
      complete_return_fragment_groups=len(complete),incomplete_return_fragment_groups=len(bad),
      sender_fragment_groups_without_complete_rx=len(unknown_sender_groups),
      unassignable_fragment_drop_events=sum(x['physical_queue_drop_events'] for x in unknown_sender_groups),
      observed_return_fragment_queue_drops=len(drop),
      verified_target_groups=sum(x['traffic_class']=='TARGET' and x.get('matched_nfd_pit') for x in data_recovered),
      verified_competitor_groups=sum(x['traffic_class']=='INDEPENDENT_COMPETITOR' and x.get('matched_nfd_pit') for x in data_recovered),
      target_groups_with_verified_competitor_overlap=sum(x['traffic_class']=='TARGET' and
        x.get('verified_competitor_service_overlap_count',0)>0 for x in data_recovered),
      observed_group_metrics={k:sum(x.get(k) is True for x in data_recovered)
          for k in ('M0_raw_fragment_wait','M1_first_fragment_wait','M2_adjusted_fragment_wait','M3_observed_exogenous_service')},
      dropped_fragment_class_inference='FORBIDDEN',
      HCRAF_policy_evaluation=False,decision_latency_evaluated=False,
      group_diagnostics_only=True,GO_FREEZE=False,Congestion=None,FutureCongestion=None,
      F3_ready=False,training_ready=False)
    (root/'stage1ah_verification.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n')
    with (root/'stage1ah_sensitivity.jsonl').open('w') as f:
        for row in sensitivity:f.write(json.dumps(row,sort_keys=True)+'\n')
    with (root/'stage1ah_group_diagnostics.jsonl').open('w') as f:
        for x in data_recovered:f.write(json.dumps(x,sort_keys=True)+'\n')
        for x in bad:
            x.update(traffic_class='UNATTRIBUTABLE',name=None,Congestion=None,FutureCongestion=None,
                     M0_raw_fragment_wait=None,M1_first_fragment_wait=None,
                     M2_adjusted_fragment_wait=None,M3_observed_exogenous_service=None)
            f.write(json.dumps(x,sort_keys=True)+'\n')
        for x in unknown_sender_groups:
            x.update(traffic_class='UNATTRIBUTABLE',name=None,Congestion=None,FutureCongestion=None,
                     M0_raw_fragment_wait=None,M1_first_fragment_wait=None,
                     M2_adjusted_fragment_wait=None,M3_observed_exogenous_service=None)
            f.write(json.dumps(x,sort_keys=True)+'\n')
    return summary

if __name__=='__main__':
    a=argparse.ArgumentParser()
    a.add_argument('run_dir');a.add_argument('--fail-on-incomplete',action='store_true')
    args=a.parse_args();out=verify(args.run_dir)
    print(json.dumps(out,ensure_ascii=False))
    if args.fail_on_incomplete and out['status']!='PASS_TARGET_EVENT_ONLY':raise SystemExit(2)
