#!/usr/bin/env python3
"""Run-based completeness and paired overhead summary; no training or F3 labels."""
import collections,hashlib,json,sys
from pathlib import Path

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def resource(path):
    out={}
    if path.is_file():
        for line in path.read_text(encoding='utf8').splitlines():
            if '=' in line:
                k,v=line.split('=',1)
                try:out[k]=float(v)
                except ValueError:pass
    return out

def summarize(root):
    root=Path(root);data=[];pairs=[]
    for p in sorted((root/'monitored').glob('*/run-*')):
        vf=p/'stage1ad_verification.json'
        record={'mode':p.parent.name,'run':p.name,'status':'NO_VERIFIER_RESULT'}
        if vf.is_file():record.update(json.loads(vf.read_text(encoding='utf8')))
        data.append(record)
        other=root/'uninstrumented'/p.parent.name/p.name
        if other.is_dir():
            a=p/'consumer_events.jsonl';b=other/'consumer_events.jsonl'
            x=p/'consumer_events.jsonl.arrivals.jsonl';y=other/'consumer_events.jsonl.arrivals.jsonl'
            pair={'mode':p.parent.name,'run':p.name,'consumer_matches':a.is_file() and b.is_file() and digest(a)==digest(b),
                  'schedule_matches':x.is_file() and y.is_file() and digest(x)==digest(y),
                  'monitored_resources':resource(p/'resource_usage.txt'),
                  'unmonitored_resources':resource(other/'resource_usage.txt'),
                  'observer_is_not_HCRAF_decision_latency':True}
            pairs.append(pair)
    status=collections.Counter(x['status'] for x in data)
    report={'stage':'1AD.BOUNDARY_PILOT.0','run_count':len(data),'paired_run_count':len(pairs),
        'statuses':dict(status),'schedule_and_consumer_identical':all(x['consumer_matches'] and x['schedule_matches'] for x in pairs),
        'scientific_decision':'REVISE_SCOPE','GO_FREEZE':False,'F3_ready':False,'training_ready':False,
        'Congestion':None,'FutureCongestion':None,
        'note':'Preliminary development-only feasibility, no formal F3 target or training.'}
    for name,obj in [('stage1ad_run_summary.json',data),('stage1ad_pairs.json',pairs),('stage1ad_decision.json',report)]:
        (root/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
    print(json.dumps(report,ensure_ascii=False))
    if len(data)!=21 or len(pairs)!=9:return 2
    if any(x['status']!='PASS_TARGET_EVENT_ONLY' for x in data):return 3
    if not report['schedule_and_consumer_identical']:return 4
    return 0
if __name__=='__main__':raise SystemExit(summarize(sys.argv[1]))
