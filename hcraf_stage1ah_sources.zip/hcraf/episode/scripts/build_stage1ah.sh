#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
# Reuse exact pinned ndnSIM/NFD patch chain and verified 1AF builder.
bash "$TASK/scripts/build_stage1af.sh"
# ADDITIVE v0.32.1: baseline NFD recorder is scoped to /hcraf/pilot only.
# Both target and competitor must be PIT/Face-traceable; change scope for
# 1AH alone, after the approved 1AF build. The strict 1AH verifier is unchanged.
NFD="$ROOT/episode_sources/ns-3/src/ndnSIM/NFD"
python3 "$TASK/scripts/patch_nfd_stage1ah_scope.py" \
  "$NFD/daemon/fw/forwarder.cpp" > "$ROOT/episode_output/nfd_stage1ah_scope_patch.json"
git -C "$NFD" diff -- daemon/fw/forwarder.cpp daemon/fw/forwarder.hpp \
  > "$ROOT/episode_output/nfd_stage1ah_instrumentation.patch"
test -s "$ROOT/episode_output/nfd_stage1ah_instrumentation.patch"
cd "$ROOT/episode_sources/ns-3"
cp "$TASK/src/hcraf-stage1ah-pilot.cpp" scratch/hcraf-stage1ah-pilot.cc
cmp -s "$TASK/src/hcraf-stage1ah-pilot.cpp" scratch/hcraf-stage1ah-pilot.cc
python3 ./waf -j 2
test -x build/scratch/hcraf-stage1ah-pilot
