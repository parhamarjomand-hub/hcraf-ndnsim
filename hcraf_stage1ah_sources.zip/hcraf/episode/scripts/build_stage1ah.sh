#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
# Reuse exact pinned ndnSIM/NFD patch chain and verified 1AF builder.
bash "$TASK/scripts/build_stage1af.sh"
cd "$ROOT/episode_sources/ns-3"
cp "$TASK/src/hcraf-stage1ah-pilot.cpp" scratch/hcraf-stage1ah-pilot.cc
cmp -s "$TASK/src/hcraf-stage1ah-pilot.cpp" scratch/hcraf-stage1ah-pilot.cc
python3 ./waf -j 2
test -x build/scratch/hcraf-stage1ah-pilot
