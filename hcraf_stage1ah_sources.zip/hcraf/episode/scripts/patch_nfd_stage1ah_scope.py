#!/usr/bin/env python3
"""Stage1AH-only NFD recorder scope expansion; leaves 1S..1AF sources unchanged.

The pinned NFD instrumentation (1B/1U) records /hcraf/pilot only. A separate
source-class /hcraf/competitor is physically present but missing from NFD logs.
Change precisely one post-1AF-build NFD instance from /hcraf/pilot to /hcraf;
never weaken any episode/Face/nonce evidence checks in the 1AH verifier.
"""
import hashlib,json,sys
from pathlib import Path

def sha(blob):return hashlib.sha256(blob).hexdigest()

def patch(path):
    path=Path(path)
    if path.name!='forwarder.cpp' or tuple(path.parts[-4:])!=('NFD','daemon','fw','forwarder.cpp'):
        raise ValueError('Expected pinned ndnSIM NFD/daemon/fw/forwarder.cpp only')
    original=path.read_bytes()
    old=b'm_hcrafRecorder.reset(new hcraf::Recorder(path, nodeId, "/hcraf/pilot"));'
    new=b'm_hcrafRecorder.reset(new hcraf::Recorder(path, nodeId, "/hcraf"));'
    if original.count(old)!=1 or original.count(new)!=0:
        raise ValueError('Original Stage1U recorder call missing, duplicated, or already changed')
    result=original.replace(old,new,1)
    if result.count(new)!=1:raise AssertionError('Unexpected replacement count')
    path.write_bytes(result)
    return {'stage':'1AH.GROUP_AWARE.0','scope':'/hcraf',
            'target_prefix':'/hcraf/pilot','competitor_prefix':'/hcraf/competitor',
            'status':'APPLIED_SCOPE_ONLY','original_sha256':sha(original),
            'patched_sha256':sha(result),'scope_edits':1}

if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('Usage: patch_nfd_stage1ah_scope.py NFD/daemon/fw/forwarder.cpp')
    print(json.dumps(patch(sys.argv[1]),sort_keys=True))
