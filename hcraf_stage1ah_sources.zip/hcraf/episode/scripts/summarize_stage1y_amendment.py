#!/usr/bin/env python3
"""1Y-A1 additive evidence gate. No original preregistered 1Y result is rewritten.
All labels remain UNKNOWN; positive/negative F3 labels are explicitly forbidden.
"""
import hashlib,json,sys
from pathlib import Path

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def assess_run(root, run):
    d=root/'mixed-fragmented-paced'/('run-%s'%run)
    b=root/'uninstrumented'/'mixed-fragmented-paced'/('run-%s'%run)
    r=json.loads((d/'stage1y_verification.json').read_text())
    cfg=json.loads((d/'scenario.json').read_text())
    events=(d/'consumer_events.jsonl.arrivals.jsonl').read_text().splitlines()
    when=[json.loads(x)['time_ns'] for x in events if x.strip()]
    spacing=[when[i]-when[i-1] for i in range(1,len(when))]
    hop2=[json.loads(x) for x in (d/'events_hop2.jsonl').read_text().splitlines() if x.strip()]
    paired=(d/'consumer_events.jsonl').read_bytes()==(b/'consumer_events.jsonl').read_bytes()
    valid=(cfg.get('amendment_id')=='1Y.A1.PACED_FRAGMENTATION' and
       cfg.get('nominal_arrival_interval_ns')==250000000 and
       cfg.get('mode')=='mixed-fragmented' and len(when)==24 and
       len(set(when))==24 and bool(spacing) and min(spacing)>249800000 and max(spacing)<250200000 and
       r.get('status')=='PASS_TARGET_EVENT_ONLY' and r.get('n_link_directions',0)>=14 and
       r.get('complete_lp_groups',0)>0 and r.get('incomplete_lp_groups')==0 and
       r.get('n_nfd_pit_binds',0)>0 and
       sum(x.get('event_type')=='DATA_PIT_BIND_1U' for x in hop2)>0 and
       r.get('queue_drops')==0 and r.get('unmatched_queue_enqueues_at_trace_end')==0 and
       r.get('success')==r.get('n_episodes')==24 and paired and
       r.get('future_congestion') is None and not r.get('training_ready') and not r.get('F3_ready'))
    return {'run':run,'status':'PASS_TARGET_EVENT_ONLY' if valid else 'INCOMPLETE_TARGET_EVENT',
      'target_event_observed':valid,'instrumented_consumer_bytes_equal_uninstrumented':paired,
      'episodes':r.get('n_episodes'),'success':r.get('success'),'timeout':r.get('timeout'),
      'lp_groups_complete':r.get('complete_lp_groups'),'lp_groups_incomplete':r.get('incomplete_lp_groups'),
      'queue_drops':r.get('queue_drops'), 'n_link_directions':r.get('n_link_directions'),
      'realized_arrival_schedule_sha256':sha(d/'consumer_events.jsonl.arrivals.jsonl')}

def summarize(root):
    root=Path(root)
    rows=[assess_run(root,i) for i in (1001,1002,1003)]
    ok=all(r['target_event_observed'] for r in rows) and len(set(r['realized_arrival_schedule_sha256'] for r in rows))==3
    out={'schema':'1Y.A1.0','amendment_id':'1Y.A1.PACED_FRAGMENTATION',
      'purpose':'COMPLEMENTARY_DIAGNOSTIC_NOT_REPLACING_ORIGINAL_1Y',
      'original_1y_observed_incomplete_reruns':3,
      'preregistration_deviation':'Interval from 2ms to 250ms in supplemental 24-request mixed-fragmented runs; all other original 1Y measurements remain immutable.',
      'monitored_runs_expected':3,'paired_uninstrumented_runs_expected':3,
      'all_amendment_target_events_observed':ok,
      'scientific_decision':'NO_GO_TO_F3_TRAINING',
      'Congestion':None,'FutureCongestion':None,'F3_ready':False,'training_ready':False,
      'per_run':rows}
    (root/'stage1y_amendment_summary.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print('1Y.A1 PACED', 'PASS_TARGET_EVENT_ONLY' if ok else 'INCOMPLETE_TARGET_EVENT',
          'F3_ready=false training_ready=false')
    return ok

if __name__=='__main__':sys.exit(0 if summarize(sys.argv[1]) else 2)
