#!/usr/bin/env python3
"""Stage 1AB evidence gate (DEVELOPMENT diagnostics only; no F3 labels).

Requires real per-run NFD, Episode and point-to-point traces. A certificate means
operational queue-pressure evidence on the fully observed 2-hop forwarding path,
NOT a causal congestion diagnosis or a training label.
"""
import argparse
import collections
import hashlib
import json
from pathlib import Path

HORIZON_NS = 2_000_000_000
THETA = 2
FORWARD = ((1, 1), (2, 1))
RETURN = ((5, 0), (2, 0))
PATH_DIRECTIONS = FORWARD + RETURN
RECEIVER = {(1,1):(2,0), (2,1):(5,0), (5,0):(2,1), (2,0):(1,1)}
TARGETS = {
    'low-load': 'NEGATIVE', 'propagation-only':'NEGATIVE',
    'forward-buffered': 'POSITIVE_FORWARD', 'return-buffered':'POSITIVE_RETURN',
    'forward-overflow':'DROP_FORWARD', 'return-overflow':'DROP_RETURN',
    'receive-loss':'LOSS_NUISANCE', 'mixed-fragmented':'LP_NUISANCE'
}
class EvidenceError(ValueError): pass

def read_jsonl(path, required=True):
    path=Path(path)
    if not path.exists():
        if required: raise EvidenceError('missing '+str(path))
        return []
    try:
        return [json.loads(line) for line in path.read_text(encoding='utf8').splitlines() if line.strip()]
    except (ValueError,UnicodeError) as e: raise EvidenceError('malformed '+str(path)+': '+str(e))

def write_json(path, obj):
    Path(path).write_text(json.dumps(obj,indent=2,sort_keys=True,ensure_ascii=False)+'\n',encoding='utf8')

def is_ndn(e):
    return e.get('ndn_packet_type') in ('INTEREST','DATA') or e.get('lp_status')=='FRAGMENT'

def exceed_ratio(e, theta=THETA):
    w=e.get('queue_wait_ns'); bytes_=e.get('packet_bytes'); rate=e.get('data_rate_bps')
    if not isinstance(w,int) or w<0 or not isinstance(bytes_,int) or bytes_<=0 or not isinstance(rate,int) or rate<=0:
        return None
    # integer comparison, avoiding floating point rounding
    return w*rate > theta*8*bytes_*1_000_000_000

def pressure_stats(link,start,end):
    stats={'forward_high_wait':0,'return_high_wait':0,'forward_drops':0,'return_drops':0,
           'unresolved_queue_service':0,'path_phy_drops':0,'unknown_wire_events':0,
           'forward_high_wait_theta1':0,'return_high_wait_theta1':0,
           'forward_high_wait_theta4':0,'return_high_wait_theta4':0}
    for e in link:
        t=e['time_ns']; direction=(e.get('node_id'),e.get('device_index'))
        if not start < t <= end: continue
        if direction not in PATH_DIRECTIONS and direction not in RECEIVER.values(): continue
        typ=e.get('event_type')
        if typ=='PHY_RX_DROP' and direction in RECEIVER.values(): stats['path_phy_drops']+=1
        if direction not in PATH_DIRECTIONS: continue
        if typ in ('QUEUE_DEQUEUE','QUEUE_DROP'):
            if not is_ndn(e):
                stats['unknown_wire_events']+=1; continue
            side='forward' if direction in FORWARD else 'return'
            if typ=='QUEUE_DROP': stats[side+'_drops']+=1
            else:
                v=exceed_ratio(e)
                if v is None:stats['unresolved_queue_service']+=1
                else:
                    if v:stats[side+'_high_wait']+=1
                    for theta in (1,4):
                        if exceed_ratio(e,theta):stats[side+'_high_wait_theta'+str(theta)]+=1
    return stats

def _is_packet(e,kind,name,nonce=None):
    return e.get('ndn_packet_type')==kind and e.get('ndn_name')==name and (nonce is None or e.get('ndn_nonce')==nonce)

def _candidate_unique(events,typ,direction,kind,name,start,end,nonce=None):
    return [e for e in events if e.get('event_type')==typ
        and (e.get('node_id'),e.get('device_index'))==direction
        and start<=e['time_ns']<=end and _is_packet(e,kind,name,nonce)]

def complete_path(ep, link, hop1, hop2, horizon=HORIZON_NS):
    """Fail-closed causal path: two Interest sends and two Data returns, per-device UID,
    receiving MAC_RX on opposite endpoint and PIT Data bind at both routers.
    No global UID or cross-hop UID continuity is assumed.
    """
    start=ep.get('start_ns');end=ep.get('end_ns');name=ep.get('name')
    nonce_list=ep.get('tx_nonces') or []
    if ep.get('outcome')!='SUCCESS' or not isinstance(start,int) or not isinstance(end,int) or not name:
        return False,'NOT_SUCCESS_OR_INCOMPLETE_EPISODE',[]
    if end<start or end>start+horizon:return False,'CENSORED_BY_HORIZON',[]
    if len(nonce_list)!=1: return False,'MULTIPLE_OR_MISSING_NONCE',[]
    nonce=nonce_list[0]
    for evts,node in ((hop1,1),(hop2,2)):
        tx=[e for e in evts if e.get('event_type')=='TX_INTEREST'
              and e.get('node_id')==node and e.get('name')==name and e.get('nonce')==nonce]
        bind=[e for e in evts if e.get('event_type')=='DATA_PIT_BIND_1U'
              and e.get('node_id')==node and e.get('name')==name]
        if len(tx)!=1 or len(bind)!=1:return False,'PIT_TX_OR_BIND_MISSING_OR_AMBIGUOUS',[]
        if any(b['time_ns']<start or b['time_ns']>end for b in bind):return False,'PIT_TIME_INVALID',[]
        if node==1 and str(bind[0]['pit_instance_id'])!=str(ep.get('pit_instance_id')):
            return False,'PIT_INSTANCE_MISMATCH',[]
    direction_steps=[(FORWARD[0],'INTEREST'),(FORWARD[1],'INTEREST'),(RETURN[0],'DATA'),(RETURN[1],'DATA')]
    matched=[]
    for dr,kind in direction_steps:
        n=nonce if kind=='INTEREST' else None
        dq=_candidate_unique(link,'QUEUE_DEQUEUE',dr,kind,name,start,end,n)
        if len(dq)!=1:return False,'QUEUE_PACKET_MISSING_OR_AMBIGUOUS',[]
        one=dq[0]
        if exceed_ratio(one) is None:return False,'INVALID_WAIT_OR_RATE',[]
        # UID is used ONLY to join queue/tx lifecycle on the same device.
        enq=[e for e in link if e.get('event_type')=='QUEUE_ENQUEUE'
              and (e.get('node_id'),e.get('device_index'),e.get('packet_uid'))==
                 (one.get('node_id'),one.get('device_index'),one.get('packet_uid'))
              and e['time_ns']<=one['time_ns'] and e['time_ns']>=start]
        if len(enq)!=1 or one['time_ns']-enq[0]['time_ns']!=one['queue_wait_ns']:
            return False,'LOCAL_QUEUE_LIFECYCLE_UNVERIFIED',[]
        t_begin=[e for e in link if e.get('event_type')=='PHY_TX_BEGIN'
                  and (e.get('node_id'),e.get('device_index'),e.get('packet_uid'))==
                  (one.get('node_id'),one.get('device_index'),one.get('packet_uid'))
                  and e['time_ns']>=one['time_ns'] and e['time_ns']<=end]
        if len(t_begin)!=1:return False,'PHY_SEND_MISSING_OR_AMBIGUOUS',[]
        t_end=[e for e in link if e.get('event_type')=='PHY_TX_END'
                  and (e.get('node_id'),e.get('device_index'),e.get('packet_uid'))==
                  (one.get('node_id'),one.get('device_index'),one.get('packet_uid'))
                  and t_begin[0]['time_ns']<=e['time_ns']<=end]
        if len(t_end)!=1:return False,'PHY_TX_END_MISSING_OR_AMBIGUOUS',[]
        # Receive matching uses NDN identity + opposite endpoint, never UID across nodes.
        recv_dir=RECEIVER[dr]
        receive=_candidate_unique(link,'MAC_RX',recv_dir,kind,name,t_end[0]['time_ns'],end,n)
        if len(receive)!=1:return False,'PHYSICAL_RECEIVE_MISSING_OR_AMBIGUOUS',[]
        matched.append({'sender':list(dr),'receiver':list(recv_dir),'kind':kind,
                        'name':name,'queue_wait_ns':one['queue_wait_ns'],'packet_bytes':one['packet_bytes'],
                        'rate_bps':one['data_rate_bps'],'sender_local_uid':one['packet_uid'],
                        'receiver_local_uid':receive[0]['packet_uid']})
    return True,'COMPLETE_TWO_HOP',matched

def verify_run(folder):
    folder=Path(folder);cfg=json.loads((folder/'scenario.json').read_text(encoding='utf8'))
    mode=cfg.get('mode')
    if cfg.get('collector_stage')!='1AB.FEASIBILITY.0' or mode not in TARGETS:
        raise EvidenceError('wrong source stage/control')
    if cfg.get('multi_hop_enabled') is not True or cfg.get('stage1ab_path_nodes')!=[0,1,2,5]:
        raise EvidenceError('path topology identity changed')
    if cfg.get('stage1ab_case_role')!='DEVELOPMENT_ONLY':raise EvidenceError('invalid split identity')
    if cfg.get('stage1ab_proposal_theta')!=THETA or cfg.get('stage1ab_proposal_horizon_ns')!=HORIZON_NS:
        raise EvidenceError('unregistered threshold/horizon')
    if cfg.get('instrument_enabled') is not True:raise EvidenceError('no instrumented path evidence')
    if any(cfg.get(k) is not None for k in ('congestion','future_congestion','causal_congestion_attribution')) or cfg.get('F3_ready') is not False or cfg.get('training_ready') is not False:
        raise EvidenceError('training/label invariant violated')
    events=read_jsonl(folder/'link_events.jsonl')
    hop1=read_jsonl(folder/'events.jsonl');hop2=read_jsonl(folder/'events_hop2.jsonl')
    episodes=read_jsonl(folder/'episodes.jsonl')
    names=[x.get('name') for x in episodes]
    if any(not name for name in names) or len(names)!=len(set(names)):
        raise EvidenceError('1AB pilot uniqueness assumption violated; cannot assign Data by Name')
    arrivals=read_jsonl(folder/'consumer_events.jsonl.arrivals.jsonl')
    obs=read_jsonl(folder/'observer_cost.jsonl')
    states=read_jsonl(folder/'events.jsonl.states.jsonl')
    if not events:raise EvidenceError('missing link events')
    if len({x.get('sequence') for x in arrivals})!=len(arrivals) or len(arrivals)!=cfg.get('planned_requests'):
        raise EvidenceError('arrival schedule inconsistency')
    if any(x.get('schema_version')!='1W.0' for x in events):raise EvidenceError('wrong link schema')
    if any(x.get('link_event_seq')!=i+1 or not isinstance(x.get('time_ns'),int) for i,x in enumerate(events)):
        raise EvidenceError('link sequence or timestamps invalid')
    initials={(x['node_id'],x['device_index']) for x in events if x['event_type']=='INITIAL'}
    finals={(x['node_id'],x['device_index']) for x in events if x['event_type']=='FINAL'}
    if len(initials)!=14 or initials!=finals or not set(PATH_DIRECTIONS).issubset(initials):
        raise EvidenceError('incomplete physical direction coverage')
    if any(x['time_ns']<0 or x['time_ns']>cfg['stop_ns'] for x in events):raise EvidenceError('out-of-window events')
    if any(x.get('Congestion') is not None or x.get('research_training_eligible') is not False or any(k.lower().startswith('future') for k in x) for x in states):
        raise EvidenceError('future evidence leaked into online state')
    ids=[x.get('decision_id') for x in obs]
    if len(ids)!=len(set(ids)) or any(x.get('is_NFD_decision_latency') is not False or x.get('snapshot_observer_wall_ns',-1)<0 for x in obs):
        raise EvidenceError('invalid observer timing semantics')
    # Queue evidence lifecycle globally, independent of episode matching.
    pending=collections.defaultdict(collections.deque)
    for e in events:
        dr=(e.get('node_id'),e.get('device_index'))
        key=(dr,e.get('packet_uid'))
        if e['event_type']=='QUEUE_ENQUEUE':pending[key].append(e['time_ns'])
        elif e['event_type']=='QUEUE_DEQUEUE':
            if not pending[key]:raise EvidenceError('queue dequeue with no enqueue')
            earlier=pending[key].popleft()
            if e['time_ns']-earlier!=e.get('queue_wait_ns'):raise EvidenceError('queue wait not reproducible')
    # Non-negative/unknown classification is diagnostic only; no final labels.
    ledger=[]
    for ep in episodes:
        start=ep.get('start_ns')
        if not isinstance(start,int):raise EvidenceError('missing episode start')
        horizon=min(start+HORIZON_NS,cfg['stop_ns'])
        status,reason,path=complete_path(ep,events,hop1,hop2)
        stats=pressure_stats(events,start,horizon)
        if mode=='mixed-fragmented':
            label='UNKNOWN';why='FRAGMENTED_PATH_NOT_CERTIFIED_FOR_F3'
        elif stats['forward_drops'] or stats['return_drops'] or stats['forward_high_wait'] or stats['return_high_wait']:
            label='POSITIVE_PATH_DIAGNOSTIC';why='OBSERVED_QUEUE_PRESSURE_ON_SELECTED_PATH'
        elif status and all(stats[k]==0 for k in ('forward_high_wait','return_high_wait',
            'forward_drops','return_drops','unresolved_queue_service','path_phy_drops','unknown_wire_events')):
            label='NEGATIVE_TWO_HOP_DIAGNOSTIC_CERTIFICATE';why='COMPLETE_TWO_HOP_NO_THRESHOLD_EXCEEDANCE'
        else:
            label='UNKNOWN';why=reason if not status else 'OTHER_PATH_UNCERTAINTY'
        sensitivity={}
        for ms in (250,1000,2000):
            boundary=min(start+ms*1_000_000,cfg['stop_ns'])
            summary=pressure_stats(events,start,boundary)
            sensitivity[str(ms)+'ms']={
                'episode_finished_inside_horizon':bool(status and ep.get('end_ns')<=boundary),
                'high_wait_theta1_forward':summary['forward_high_wait_theta1'],
                'high_wait_theta2_forward':summary['forward_high_wait'],
                'high_wait_theta4_forward':summary['forward_high_wait_theta4'],
                'high_wait_theta1_return':summary['return_high_wait_theta1'],
                'high_wait_theta2_return':summary['return_high_wait'],
                'high_wait_theta4_return':summary['return_high_wait_theta4'],
                'queue_drop_forward':summary['forward_drops'],
                'queue_drop_return':summary['return_drops'],
                'F3_ready':False}
        ledger.append({'episode_id':ep.get('episode_id'),'pit_instance_id':ep.get('pit_instance_id'),
          'name':ep.get('name'),'outcome':ep.get('outcome'),'start_ns':start,'end_ns':ep.get('end_ns'),
          'horizon_end_ns':horizon,'diagnostic_status':label,'unknown_or_support_reason':why,
          'complete_path':status,'path_verification_reason':reason,'queue_evidence':stats,
          'matched_directions':path,'sensitivity_only':sensitivity,'Congestion':None,'FutureCongestion':None,'F3_ready':False,'training_ready':False})
    drop=collections.Counter((e['node_id'],e['event_type']) for e in events if e.get('event_type') in ('QUEUE_DROP','PHY_RX_DROP'))
    flagged=collections.Counter(x['diagnostic_status'] for x in ledger)
    reasons=collections.Counter(x['unknown_or_support_reason'] for x in ledger if x['diagnostic_status']=='UNKNOWN')
    target=TARGETS[mode];observed=False
    if target=='NEGATIVE':observed=bool(flagged['NEGATIVE_TWO_HOP_DIAGNOSTIC_CERTIFICATE'])
    elif target=='POSITIVE_FORWARD':observed=any(e['queue_evidence']['forward_high_wait']>0 and e['queue_evidence']['forward_drops']==0 for e in ledger)
    elif target=='POSITIVE_RETURN':observed=any(e['queue_evidence']['return_high_wait']>0 and e['queue_evidence']['return_drops']==0 for e in ledger)
    elif target=='DROP_FORWARD':observed=drop[(1,'QUEUE_DROP')]>0
    elif target=='DROP_RETURN':observed=drop[(2,'QUEUE_DROP')]>0
    elif target=='LOSS_NUISANCE':observed=drop[(2,'PHY_RX_DROP')]>0
    elif target=='LP_NUISANCE':observed=any(e.get('event_type')=='MAC_RX' and e.get('lp_status')=='FRAGMENT' for e in events)
    status='PASS_TARGET_EVENT_ONLY' if observed else 'INCOMPLETE_TARGET_EVENT'
    report={'stage':'1AB.FEASIBILITY.0','mode':mode,'rng_run':cfg['run'],'seed':cfg['seed'],
      'status':status,'target_observed':observed,'episode_count':len(episodes),
      'diagnostic_status_counts':dict(flagged),'unknown_reason_counts':dict(reasons),'path_directions':len(initials),
      'path_certificate_count':sum(x['complete_path'] for x in ledger),
      'queue_drop_by_node':{str(node):v for (node,kind),v in drop.items() if kind=='QUEUE_DROP'},
      'phy_drop_by_node':{str(node):v for (node,kind),v in drop.items() if kind=='PHY_RX_DROP'},
      'observer_cost_count':len(obs),'observer_cost_kind':'snapshot_callback_only_NOT_NFD_decision_latency',
      'Congestion':None,'FutureCongestion':None,'F3_ready':False,'training_ready':False,
      'final_F3_labels_created':0,'note':'Diagnostic only; not a final F3 label. Multiple Episode windows overlap.'}
    return report,ledger

def main():
    a=argparse.ArgumentParser();a.add_argument('folder');a.add_argument('--fail-on-incomplete',action='store_true')
    args=a.parse_args();r,ledger=verify_run(args.folder)
    write_json(Path(args.folder)/'stage1ab_verification.json',r)
    with (Path(args.folder)/'stage1ab_episode_diagnostics.jsonl').open('w',encoding='utf8') as f:
        for row in ledger:f.write(json.dumps(row,sort_keys=True,ensure_ascii=False)+'\n')
    print(r['mode'],r['status'],r['diagnostic_status_counts'])
    if args.fail_on_incomplete and not r['target_observed']:raise SystemExit(2)
if __name__=='__main__':main()
