"""Validate real multi-face traces; synthetic test fixtures are separate."""
import json,math,sys
from pathlib import Path
from collections import Counter,defaultdict
from episodes import load,require,reconstruct
from verify_states import verify as verify_state


def expected_probabilities(counts,policy):
    require(policy in ('uniform','coverage'),'unknown policy')
    require(counts and all(type(n) is int and n>=0 for n in counts),'invalid historical counts')
    if policy=='uniform':return [1/len(counts)]*len(counts)
    low=min(counts);ties=counts.count(low)
    return [.2/len(counts)+(.8/ties if n==low else 0) for n in counts]


def check_choice(c,d,states,tx):
    require(c['schema_version']=='1M.1' and c['decision_id']==d['decision_id'],'decision/schema')
    require(c['time_ns']==d['time_ns'] and c['after_event_seq']==d['after_event_seq'],'causal anchor')
    require(c['eligibility_rule']=='NFD_isNextHopEligible_FRESH_PIT_THREE_FACES','eligibility rule')
    candidates=c['candidates'];faces=[x['face_id'] for x in candidates]
    require(len(faces)==len(set(faces))==3,'three distinct faces required')
    require(faces==[x['face_id'] for x in d['candidates']],'eligible/FIB ordering')
    require(all(not x['is_ingress'] for x in d['candidates']),'ingress candidate')
    counts=[]
    for x in candidates:
        n=states[(d['decision_id'],x['face_id'])]['valid_outcomes']
        require(x['valid_outcomes_before']==n,'coverage used unavailable or wrong historical outcome count')
        counts.append(n)
    probabilities=expected_probabilities(counts,c['policy'])
    for x,p in zip(candidates,probabilities):
        require(type(x['probability']) in (int,float) and math.isfinite(x['probability']) and math.isclose(x['probability'],p,rel_tol=1e-12,abs_tol=1e-14),'probability formula')
    u=c['uniform_draw'];require(type(u) in (int,float) and 0<=u<1,'invalid RNG draw')
    cumulative=0;selected=len(faces)-1
    for i,p in enumerate(probabilities):
        cumulative+=p
        if u<cumulative:selected=i;break
    require(c['selected_face_id']==faces[selected],'draw/selected face mismatch')
    require(math.isclose(c['selected_action_probability'],probabilities[selected],rel_tol=1e-12,abs_tol=1e-14),'selected probability')
    require(len(tx)==1 and tx[0]['face_id']==faces[selected],'not exactly one selected TX')
    x=tx[0]
    require(x['decision_id']==d['decision_id'] and x['pit_instance_id']==d['pit_instance_id'] and x['name']==d['name'],'TX identity')
    require(x['time_ns']==d['time_ns'] and x['event_seq']>d['after_event_seq'],'TX chronology')


def check_arrivals(arrivals,sends):
    require(arrivals and arrivals[-1]['included'] is False,'missing stop-crossing draw')
    time=10**9;included=[]
    for i,x in enumerate(arrivals):
        require(x['sequence']==i,'arrival order')
        u=x['uniform_draw'];require(type(u) in (int,float) and 0<=u<1,'arrival draw')
        dt=max(1,math.floor(-math.log1p(-u)*1e9/20+.5))
        require(type(x['interval_ns']) is int and abs(x['interval_ns']-dt)<=1,'arrival transform')
        time+=x['interval_ns'];require(x['time_ns']==time,'arrival accumulation')
        require(x['included'] is (time<9*10**9),'arrival stop rule')
        if x['included']:included.append(x)
        else:require(i==len(arrivals)-1,'draw after stop')
    require(len(sends)==len(included)>0,'arrival/send counts')
    for x,y in zip(included,sends):
        require(x['time_ns']==y['time_ns'] and y['name']=='/hcraf/pilot/'+str(x['sequence']),'scheduled/actual request mismatch')
    return len(included)


def verify(folder):
    cfg=json.loads((folder/'scenario.json').read_text());require(cfg['collector_stage']=='1M.1','wrong stage')
    require(cfg['policy'] in ('uniform','coverage') and cfg['request_rate_per_s']==20 and cfg['arrival_stream']==10 and cfg['selection_stream']==20,'configuration')
    ev=load(folder/'events.jsonl');ep=load(folder/'episodes.jsonl');ds=load(folder/'events.jsonl.decisions.jsonl');cs=load(folder/'events.jsonl.collection.jsonl');states=load(folder/'events.jsonl.states.jsonl')
    consumer=load(folder/'consumer_events.jsonl');sends=[x for x in consumer if x['event']=='SEND'];data=[x for x in consumer if x['event']=='DATA']
    n=check_arrivals(load(folder/'consumer_events.jsonl.arrivals.jsonl'),sends)
    require(len(ds)==len(cs)==len(ep)==n,'one decision and episode per request')
    require(len({d['decision_id'] for d in ds})==n,'duplicate decision')
    require(ep==reconstruct(ev,ep[0]['run_id']),'episode reconstruction')
    require(all(e['tx_count']==1 and e['outcome'] in ('SUCCESS','TIMEOUT') for e in ep),'unexpected retx/censor/cancel/NACK')
    tx=defaultdict(list)
    for x in ev:
        if x['event_type']=='TX_INTEREST':tx[x['decision_id']].append(x)
    require(set(tx)=={d['decision_id'] for d in ds},'orphan TX')
    lookup={(x['decision_id'],x['face_id']):x for x in states}
    verify_state(folder) # Offline causal reference validates the history used by the policy.
    faces=[cfg['primary_face_id'],cfg['secondary_face_id'],cfg['third_face_id']]
    roles=[];index={e['tx_event_seqs'][0]:e for e in ep}
    for c,d in zip(cs,ds):
        require(c['policy']==cfg['policy'],'policy mismatch')
        require([x['face_id'] for x in c['candidates']]==faces,'configured face mapping')
        check_choice(c,d,lookup,tx[d['decision_id']])
        e=index[tx[d['decision_id']][0]['event_seq']]
        roles.append(dict(episode_id=e['episode_id'],decision_id=d['decision_id'],face_id=e['face_id'],role='SINGLE_SELECTED',policy=c['policy'],inclusion_probability=c['selected_action_probability'],outcome=e['outcome']))
    require({x['name'] for x in data}=={e['name'] for e in ep if e['outcome']=='SUCCESS'} and len(data)==sum(e['outcome']=='SUCCESS' for e in ep),'consumer success evidence')
    counts=Counter(e['outcome'] for e in ep)
    links=load(folder/'link_events.jsonl');faults=load(folder/'fault_events.jsonl')
    require(not any(x['event_type']=='QUEUE_DROP' for x in links),'unexpected queue drop in low-load pilot')
    drops=[x for x in faults if x['event']=='PHY_RX_DROP']
    if cfg['mode']=='control':require(counts['SUCCESS']==n and not drops,'control failure')
    else:
        require(cfg['mode']=='receive-outage','unsupported mode')
        require(all(e['face_id']==faces[0] for e in ep if e['outcome']=='TIMEOUT'),'timeout on unaffected face')
        require(counts['TIMEOUT']==len(drops),'timeout/drop evidence mismatch')
        require(all(3*10**9<=x['time_ns']<=6*10**9 for x in drops),'drop outside outage')
    valid={str(f):sum(e['face_id']==f for e in ep) for f in faces}
    require(min(valid.values())>0,'pilot failed to observe every face')
    (folder/'episode_roles.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in roles))
    r=dict(status='PASS',policy=cfg['policy'],requests=n,episodes=len(ep),outcomes=dict(counts),valid_outcomes_by_face=valid,extra_interest_count_ratio=0.0,training_ready=False)
    (folder/'coverage_verification.json').write_text(json.dumps(r,indent=2)+'\n');return r

if __name__=='__main__':
    folder=Path(sys.argv[1])
    try:print(json.dumps(verify(folder)))
    except Exception as e:
        (folder/'coverage_verification.json').write_text(json.dumps(dict(status='FAIL',error=str(e)))+'\n');raise
