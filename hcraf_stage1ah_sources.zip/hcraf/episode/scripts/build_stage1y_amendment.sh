#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
# Compile ORIGINAL pinned sources first; never rewrite any approved 1Y or earlier source.
bash "$ROOT/hcraf/episode/scripts/build_stage1y.sh"
cd "$ROOT/episode_sources/ns-3"
cp "$ROOT/hcraf/episode/src/hcraf-stage1y-paced-pilot.cpp" scratch/hcraf-stage1y-paced-pilot.cc
cmp -s "$ROOT/hcraf/episode/src/hcraf-stage1y-paced-pilot.cpp" scratch/hcraf-stage1y-paced-pilot.cc
python3 ./waf -j 2
test -x build/scratch/hcraf-stage1y-paced-pilot
