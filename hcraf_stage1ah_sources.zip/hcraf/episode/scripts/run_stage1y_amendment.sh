#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
OUT="$ROOT/episode_output/stage1y_amendment"
mkdir -p "$OUT"
cd "$ROOT/episode_sources/ns-3"
failed=0
for run in 1001 1002 1003; do
  for instrument in 1 0; do
    if [[ $instrument == 1 ]]; then folder="$OUT/mixed-fragmented-paced/run-$run"
    else folder="$OUT/uninstrumented/mixed-fragmented-paced/run-$run"; fi
    mkdir -p "$folder"
    command="hcraf-stage1y-paced-pilot --mode=mixed-fragmented --output=$folder --seed=17 --run=$run --instrument=$instrument"
    printf '%s\n' "$command" > "$folder/command.txt"
    if ! /usr/bin/time -f 'wall_seconds=%e\nmax_rss_kib=%M' -o "$folder/resource_usage.txt" \
        python3 ./waf --run-no-build "$command" > "$folder/simulator.log" 2>&1; then
      echo "AMENDMENT_SIMULATION_FAIL run=$run instrument=$instrument";failed=1;continue
    fi
    if [[ $instrument == 1 ]]; then
      if ! python3 "$TASK/scripts/episodes_stage1u.py" "$folder" --run-id "1y-amendment-mixed-paced-17-$run" \
            > "$folder/episode_reconstruction.log" 2>&1;then
          echo "AMENDMENT_EPISODE_RECONSTRUCTION_FAIL run=$run";failed=1;continue
      fi
      if ! python3 "$TASK/scripts/verify_stage1y.py" "$folder" > "$folder/verify.log" 2>&1;then
          echo "AMENDMENT_TARGET_EVIDENCE_INCOMPLETE run=$run";failed=1
      fi
    fi
  done
done
if ! python3 "$TASK/scripts/summarize_stage1y_amendment.py" "$OUT";then failed=1;fi
exit "$failed"
