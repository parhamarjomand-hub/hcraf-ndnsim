#!/usr/bin/env python3
"""Hash entire development artifact, preserving failure logs and provenance."""
import hashlib,json,os,platform,subprocess,sys
from pathlib import Path
from datetime import datetime,timezone
root=Path(sys.argv[1]).resolve()
out=root/'episode_output';out.mkdir(exist_ok=True)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
try:commit=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()
except (OSError,subprocess.CalledProcessError):commit=os.getenv('GITHUB_SHA','UNAVAILABLE')
files={str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='manifest.json'}
code={str(p.relative_to(root)):sha(p) for p in sorted((root/'hcraf/episode').rglob('*'))
      if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
wf=root/'.github/workflows/hcraf-stage1ad.yml'
if wf.is_file():code[str(wf.relative_to(root))]=sha(wf)
manifest={'schema_version':'1AD.BOUNDARY_PILOT.0','created_at_utc':datetime.now(timezone.utc).isoformat(),
 'git_commit':commit,'github_run_id':os.getenv('GITHUB_RUN_ID'),
 'github_run_attempt':os.getenv('GITHUB_RUN_ATTEMPT'),
 'source_zip_sha256':sha(root/'hcraf_stage1ad_sources.zip') if (root/'hcraf_stage1ad_sources.zip').exists() else None,
 'python':platform.python_version(),'artifact_sha256':files,'code_sha256':code,
 'F3_ready':False,'training_ready':False,'Congestion':None,'FutureCongestion':None,
 'environment_fully_locked':False,'limit':'ubuntu:20.04 tag and apt repositories not pinned by OCI digest'}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n',encoding='utf8')
