"""Compile-independent replay harness for the supplied native executable."""
import argparse,json,zipfile,subprocess,hashlib
from pathlib import Path
from verify_states import compare
from episodes import require

def run(binary,artifacts):
 reports=[]
 for path in artifacts:
  with zipfile.ZipFile(path) as z:
   m=json.loads(z.read('manifest.json'))
   for n,sha in m['artifact_sha256'].items():require(hashlib.sha256(z.read(n)).hexdigest()==sha,'hash mismatch')
   folders=sorted(n[:-len('episodes.jsonl')] for n in z.namelist() if n.endswith('/episodes.jsonl'))
   for prefix in folders:
    def rows(n):return [json.loads(x) for x in z.read(prefix+n).splitlines() if x.strip()]
    ev=rows('events.jsonl');ep=rows('episodes.jsonl');ds=rows('events.jsonl.decisions.jsonl');commands=[];i=0
    for d in ds:
     while i<d['after_event_seq']:
      e=ev[i];commands.append('E {event_seq} {event_type} {pit_instance_id} {face_id} {time_ns} {deadline_ns} {nonce} {payload_bytes}'.format(**e));i+=1
     for c in d['candidates']:commands.append('Q {} {} {} {} {}'.format(d['decision_id'],c['face_id'],d['time_ns'],d['after_event_seq'],c['routing_cost']))
    for e in ev[i:]:commands.append('E {event_seq} {event_type} {pit_instance_id} {face_id} {time_ns} {deadline_ns} {nonce} {payload_bytes}'.format(**e))
    output=subprocess.run([str(binary)],input='\n'.join(commands)+'\n',text=True,capture_output=True,check=True)
    states=[json.loads(x) for x in output.stdout.splitlines()];n=compare(ep,ev,ds,states)
    reports.append(dict(artifact=path.name,artifact_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),source_run=m['github_run_id'],folder=prefix,state_rows=n,status='PASS'))
 return dict(status='PASS_NATIVE_REPLAY_ONLY',ndnsim_live_state_validated=False,runs=len(reports),state_rows=sum(x['state_rows'] for x in reports),reports=reports)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--binary',type=Path,required=True);p.add_argument('--artifact',type=Path,action='append',required=True);p.add_argument('--report',type=Path,required=True);a=p.parse_args();r=run(a.binary,a.artifact);a.report.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='reports'}))
