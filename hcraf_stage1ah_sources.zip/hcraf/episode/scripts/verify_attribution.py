#!/usr/bin/env python3
"""Stage 1R: fail-closed, trace-grounded joining of NFD decisions and link packet IDs.

This is a DEVELOPMENT diagnostic. No final Congestion/FutureCongestion values.
Each link packet identity is (device, UID) and never assumed to persist across hops.
For this five-node, one-Interest-per-name pilot ONLY, a unique Data name permits a
restricted return-path correspondence; it does not establish causal congestion.
"""
import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path
from verify_visibility import verify_trace, require, read_jsonl

SCENARIOS = ('baseline', 'forward-buffered', 'return-buffered', 'forward-overflow', 'return-overflow')
PRODUCER = {258: 2, 259: 3, 260: 4}  # PINNED 1P/1R PILOT TOPOLOGY ONLY
LINK_EVENTS = ('QUEUE_ENQUEUE', 'QUEUE_DROP')
RX_EVENTS = ('MAC_RX','PHY_RX_DROP')

def packet_index(link):
    """All packet-bearing link callbacks must agree on the same decoded identity."""
    by_uid = defaultdict(list)
    by_name = defaultdict(list)
    decode_counts = Counter()
    for event in link:
        if event['packet_uid'] is None:
            require(event['wire_status'] == 'NO_PACKET' and
                    event['ndn_name'] is None and event['ndn_nonce'] is None,
                    'snapshot contains fabricated packet identity')
            continue
        status = event.get('wire_status')
        require(status in ('PILOT','NON_PILOT','INVALID','UNSUPPORTED'), 'unknown wire status')
        decode_counts[status] += 1
        if status == 'PILOT':
            require(event.get('ndn_name', '').startswith('/hcraf/pilot/'), 'out-of-scope packet named pilot')
            require(event.get('ndn_packet_type') in ('INTEREST','DATA'), 'missing pilot packet kind')
            if event['ndn_packet_type']=='INTEREST':
                require(type(event.get('ndn_nonce')) is int, 'Interest lacks decoded nonce')
            else:
                require(event.get('ndn_nonce') is None, 'Data should not have Interest nonce')
        else:
            require(status == 'NON_PILOT' or event.get('ndn_name') is None or
                    not event['ndn_name'].startswith('/hcraf/pilot/'), 'unsupported pilot was silently decoded')
        key = event['node_id'], event['device_index'], event['packet_uid']
        by_uid[key].append(event)
    for key, seq in by_uid.items():
        identities = {(x.get('wire_status'), x.get('ndn_packet_type'),
                       x.get('ndn_name'), x.get('ndn_nonce')) for x in seq}
        require(len(identities) == 1, 'one UID has conflicting decode on one device: '+str(key))
        ingress = [x for x in seq if x['event_type'] in LINK_EVENTS]
        receptions = [x for x in seq if x['event_type'] == 'MAC_RX']
        require(len(ingress)<=1 and len(receptions)<=1, 'duplicate queue admission/receive per UID: '+str(key))
        if not ingress and not receptions:
            # A corrupt packet may be dropped at the receiver before MacRx.
            require(all(x['event_type']=='PHY_RX_DROP' for x in seq),
                    'orphan UID not explained by PHY receive drop: '+str(key))
            continue
        require(bool(ingress) != bool(receptions), 'UID must represent exactly one device-side TX or RX flow: '+str(key))
        if ingress:
            require(not receptions, 'same UID cannot be TX and RX on one monitored device')
            e=ingress[0]
        else:
            # Receiver-side UID: it has no queue admission at this device.
            require(all(x['event_type'] in RX_EVENTS for x in seq), 'receiver UID has unrelated events')
            e=receptions[0]
        if e['wire_status']=='PILOT':
            k=(e['node_id'],e['face_id'],e['ndn_packet_type'],e['ndn_name'],
               e['ndn_nonce'] if e['ndn_packet_type']=='INTEREST' else None, e['event_type'])
            by_name[k].append(e)
    return by_uid,by_name,decode_counts

def get_admission(by_name, base_key, minimum_ns):
    matches=[]
    for event_type in LINK_EVENTS:
        matches.extend(e for e in by_name.get(base_key+(event_type,),()) if e['time_ns'] >= minimum_ns)
    if not matches: return 'NOT_OBSERVED',None
    if len(matches)>1: return 'AMBIGUOUS_MULTIPLE_PACKETS',None
    return 'MATCHED_UNIQUE',matches[0]

def get_one(by_name, key, minimum_ns):
    matches=[e for e in by_name.get(key,()) if e['time_ns'] >= minimum_ns]
    if not matches: return 'NOT_OBSERVED',None
    if len(matches)>1: return 'AMBIGUOUS_MULTIPLE_PACKETS',None
    return 'MATCHED_UNIQUE',matches[0]

def summary_uid(seq):
    if seq is None: return None
    key=(seq['node_id'],seq['device_index'],seq['packet_uid'])
    return key

def link_record(first,by_uid):
    if first is None: return None
    key=summary_uid(first)
    events=by_uid[key]
    counts=Counter(x['event_type'] for x in events)
    waits=[x['queue_wait_ns'] for x in events if x['event_type']=='QUEUE_DEQUEUE']
    require(len(waits)<=1, 'multiple dequeues for one packet UID')
    require(not waits or type(waits[0]) is int and waits[0]>=0, 'missing or invalid queue wait')
    require(counts['QUEUE_DROP']+counts['QUEUE_ENQUEUE']==1, 'not a unique admission attempt')
    require(not counts['QUEUE_DROP'] or not counts['PHY_TX_BEGIN'], 'dropped packet also transmitted')
    require(counts['PHY_TX_BEGIN']<=1 and counts['PHY_TX_END']<=1, 'duplicate PHY stage')
    return dict(node_id=first['node_id'],face_id=first['face_id'],
                device_index=first['device_index'],packet_uid=first['packet_uid'],
                first_event_seq=first['link_event_seq'],first_time_ns=first['time_ns'],
                admission='QUEUE_DROP' if counts['QUEUE_DROP'] else 'QUEUE_ENQUEUE',
                queue_wait_ns=waits[0] if waits else None,
                phy_tx_begin_observed=bool(counts['PHY_TX_BEGIN']),
                phy_tx_end_observed=bool(counts['PHY_TX_END']),
                phy_rx_drop_observed=bool(counts['PHY_RX_DROP']))

def verify(folder):
    folder=Path(folder)
    cfg=json.loads((folder/'scenario.json').read_text(encoding='utf-8'))
    require(cfg['collector_stage']=='1R.1' and cfg['queue_trace_schema']=='1R.1', 'wrong 1R scenario schema')
    require(cfg['mode'] in SCENARIOS and cfg['seed']==17 and cfg['run'] in (1001,1002), 'unexpected scenario')
    require(cfg['training_ready'] is False and cfg['final_congestion_label'] is None and
            cfg['future_congestion_label'] is None, 'research label must remain null')
    decisions=read_jsonl(folder/'events.jsonl.decisions.jsonl')
    selections=read_jsonl(folder/'events.jsonl.collection.jsonl')
    events=read_jsonl(folder/'events.jsonl')
    episodes=read_jsonl(folder/'episodes.jsonl')
    link=read_jsonl(folder/'link_events.jsonl')
    sends=[x for x in read_jsonl(folder/'consumer_events.jsonl') if x['event']=='SEND']
    arrivals=read_jsonl(folder/'consumer_events.jsonl.arrivals.jsonl')
    planned=cfg['planned_requests']
    require(len(decisions)==len(selections)==len(episodes)==len(sends)==len(arrivals)==planned,
            '1 decision/selection/episode/send per offered Interest violated')
    # Validate full 1R event order, then reuse unmodified 1P queue invariants on
    # its original event types. MAC_RX is new and is separately checked below.
    prev_t=-1
    for pos,ev in enumerate(link,1):
        require(ev.get('schema_version')=='1R.1' and ev.get('link_event_seq')==pos,
                '1R link event order/schema mismatch')
        require(type(ev.get('time_ns')) is int and ev['time_ns']>=prev_t,
                '1R link trace has nonmonotonic time')
        prev_t=ev['time_ns']
    old=[dict(ev,schema_version='1P.1',link_event_seq=i)
         for i,ev in enumerate((x for x in link if x['event_type']!='MAC_RX'),1)]
    base=verify_trace(old,cfg['queue_capacity_packets'])
    require(base['decisions_with_complete_snapshots']==planned, 'decision snapshot not complete')
    decisions_by={d['decision_id']:d for d in decisions}
    selection_by={s['decision_id']:s for s in selections}
    require(len(decisions_by)==len(selection_by)==planned, 'duplicate or missing decision ID')
    require({d['name'] for d in decisions}=={x['name'] for x in sends}, 'consumer/decision name mismatch')
    require(len({x['name'] for x in sends})==planned, 'PILOT REQUIRES unique names')
    send_by={x['name']:x for x in sends}
    eps_by={(int(e['pit_instance_id']),e['name'],e['face_id']):e for e in episodes}
    require(len(eps_by)==planned, 'episode identity is ambiguous')
    tx_by=defaultdict(list)
    for e in events:
        if e['event_type']=='TX_INTEREST': tx_by[(e['pit_instance_id'],e['name'],e['face_id'])].append(e)
    by_uid,by_name,decode_counts=packet_index(link)
    rows=[];states=Counter()
    for ident,d in sorted(decisions_by.items()):
        s=selection_by.get(ident)
        require(s is not None and s['policy']=='uniform', 'selection must be controlled uniform')
        require(s['selected_face_id'] in PRODUCER and len(s['candidates'])==3, 'wrong selected Face')
        face=s['selected_face_id'];name=d['name'];pit=d['pit_instance_id']
        require(s['time_ns']==d['time_ns'], 'selection time mismatch')
        tx=tx_by.get((pit,name,face),())
        require(len(tx)==1 and tx[0]['decision_id']==ident, 'NFD TX not unique for decision')
        t=tx[0]
        consumer=send_by[name]
        require(t['nonce']==consumer['nonce'], 'NFD Nonce differs from consumer')
        require(t['time_ns']>=consumer['time_ns'], 'TX precedes application send')
        episode=eps_by.get((pit,name,face))
        require(episode is not None and episode['start_ns']==t['time_ns'], 'missing chosen PIT×Face episode')
        require(episode['outcome'] in ('SUCCESS','NACK','TIMEOUT','CANCELLED',None), 'unknown outcome')
        fw_key=(1,face,'INTEREST',name,t['nonce'])
        fw_status,fw=get_admission(by_name,fw_key,t['time_ns'])
        # The receiving device is checked by decoded Name/Nonce, never by cross-hop UID equality.
        frx_status,frx=get_one(by_name,(PRODUCER[face],257,'INTEREST',name,t['nonce'],'MAC_RX'),t['time_ns'])
        # Only this topology's directly attached producer can be checked in return direction.
        ret_key=(PRODUCER[face],257,'DATA',name,None)
        return_status,ret=get_admission(by_name,ret_key,t['time_ns'])
        rrx_status,rrx=get_one(by_name,(1,face,'DATA',name,None,'MAC_RX'),t['time_ns'])
        fw_record=link_record(fw,by_uid)
        ret_record=link_record(ret,by_uid)
        if fw_status=='MATCHED_UNIQUE':
            require(fw['node_id']==1 and fw['face_id']==face and
                    fw['ndn_name']==name and fw['ndn_nonce']==t['nonce'], 'forward packet mismatch')
        if return_status=='MATCHED_UNIQUE':
            require(ret['node_id']==PRODUCER[face] and ret['face_id']==257 and
                    ret['ndn_name']==name, 'return packet mismatch')
        if fw_status=='MATCHED_UNIQUE' and frx_status=='MATCHED_UNIQUE':
            require(frx['time_ns']>=fw['time_ns'], 'forward reception predates outgoing Interest')
        if return_status=='MATCHED_UNIQUE' and rrx_status=='MATCHED_UNIQUE':
            require(rrx['time_ns']>=ret['time_ns'], 'return reception predates outgoing Data')
        for status in (fw_status,frx_status,return_status,rrx_status): states[status]+=1
        rows.append(dict(schema_version='1R.1',run_id=episode['run_id'],decision_id=ident,
            pit_instance_id=pit,selected_face_id=face,name=name,interest_nonce=t['nonce'],
            decision_time_ns=d['time_ns'],nfd_tx_event_seq=t['event_seq'],
            observed_episode_outcome=episode['outcome'],episode_end_ns=episode['end_ns'],
            forward_join_status=fw_status,forward_link_packet=fw_record,
            forward_receive_status=frx_status,
            forward_receiver_uid=frx['packet_uid'] if frx is not None else None,
            forward_receive_time_ns=frx['time_ns'] if frx is not None else None,
            return_join_status=return_status,return_link_packet=ret_record,
            return_receive_status=rrx_status,
            return_receiver_uid=rrx['packet_uid'] if rrx is not None else None,
            return_receive_time_ns=rrx['time_ns'] if rrx is not None else None,
            return_correlation_rule='UNIQUE_NAME_SELECTED_PRODUCER_PILOT_ONLY',
            cross_hop_packet_uid_assumed_equal=False,
            causal_congestion_attribution=None,Congestion=None,FutureCongestion=None,training_ready=False))
    # If all pilot packets are unobservable, the new instrument is NOT ACCEPTABLE.
    completed_forward=sum(r['forward_join_status']=='MATCHED_UNIQUE' for r in rows)
    completed_forward_rx=sum(r['forward_receive_status']=='MATCHED_UNIQUE' for r in rows if r['observed_episode_outcome']=='SUCCESS')
    completed_return=sum(r['return_join_status']=='MATCHED_UNIQUE' for r in rows if r['observed_episode_outcome']=='SUCCESS')
    completed_return_rx=sum(r['return_receive_status']=='MATCHED_UNIQUE' for r in rows if r['observed_episode_outcome']=='SUCCESS')
    success=sum(r['observed_episode_outcome']=='SUCCESS' for r in rows)
    status=('PASS_PILOT_LINK_ATTRIBUTION_NOT_FINAL_CONGESTION'
        if completed_forward==planned and completed_forward_rx==success and
           completed_return==success and completed_return_rx==success
        else 'INCOMPLETE_LINK_ATTRIBUTION_REQUIRES_AUDIT')
    out=dict(status=status,mode=cfg['mode'],run=cfg['run'],decision_count=planned,
             successful_episodes=success,unique_forward_packet_joins=completed_forward,
             unique_forward_receives_for_success=completed_forward_rx,
             unique_return_joins_for_success=completed_return,
             unique_return_receives_for_success=completed_return_rx,
             link_decode_events=dict(decode_counts),
             join_statuses=dict(states),monitored_directions=base['observed_directions'],
             final_congestion=None,future_congestion=None,training_ready=False,
             qualification='No packet UID equality across hops; no causal congestion claim.')
    (folder/'attribution.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False,sort_keys=True)+'\n' for r in rows),encoding='utf-8')
    (folder/'attribution_verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    require(status.startswith('PASS_'), 'packet attribution did not meet controlled pilot gate: '+json.dumps(out))
    return out

def main():
    ap=argparse.ArgumentParser();ap.add_argument('folder',type=Path);args=ap.parse_args()
    result=verify(args.folder)
    print(json.dumps(result,ensure_ascii=False,sort_keys=True))
if __name__=='__main__':main()
