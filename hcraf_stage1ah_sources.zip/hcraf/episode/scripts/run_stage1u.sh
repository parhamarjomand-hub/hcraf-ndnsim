#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
OUT="$ROOT/episode_output/stage1u"
mkdir -p "$OUT"
cd "$ROOT/episode_sources/ns-3"
failed=0
for mode in burst-identical overlap-prefix duplicate-data interleaved-retransmission multi-hop-overlap dual-source-overlap; do
  for run in 1001 1002; do
    folder="$OUT/$mode/run-$run"
    mkdir -p "$folder"
    command="hcraf-stage1u-pilot --mode=$mode --output=$folder --seed=17 --run=$run"
    printf '%s\n' "$command" > "$folder/command.txt"
    if ! python3 ./waf --run-no-build "$command" > "$folder/simulator.log" 2>&1; then
      echo "SIMULATION_FAIL mode=$mode run=$run"; failed=1; continue
    fi
    if ! python3 "$TASK/scripts/episodes_stage1u.py" "$folder" --run-id "1u-$mode-17-$run"; then
      echo "EPISODE_RECONSTRUCTION_FAIL mode=$mode run=$run"; failed=1; continue
    fi
    if ! python3 "$TASK/scripts/verify_stage1u.py" "$folder"; then
      echo "ATTRIBUTION_FAIL mode=$mode run=$run"; failed=1
    fi
  done
done
if ! python3 "$TASK/scripts/summarize_stage1u.py" "$OUT"; then failed=1;fi
exit "$failed"
