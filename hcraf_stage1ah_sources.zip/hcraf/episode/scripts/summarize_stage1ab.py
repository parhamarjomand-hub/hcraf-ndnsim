#!/usr/bin/env python3
"""Aggregate verified 1AB development runs and overhead; never create F3 labels."""
import collections
import csv
import hashlib
import json
import sys
from pathlib import Path

def load(path): return json.loads(path.read_text(encoding='utf8'))
def res(path):
    out={}
    for line in path.read_text().splitlines():
        if '=' in line:
            k,v=line.split('=',1)
            try:out[k]=float(v)
            except ValueError:pass
    return out

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main(root):
    root=Path(root);records=[];pair=[]
    for mon in sorted((root/'monitored').glob('*/run-*')):
        vf=mon/'stage1ab_verification.json'
        if not vf.exists():
            records.append({'mode':mon.parent.name,'run':mon.name,'status':'NO_VERIFIER_RESULT'})
            continue
        r=load(vf)
        r['schedule_sha256']=digest(mon/'consumer_events.jsonl.arrivals.jsonl')
        r['consumer_events_sha256']=digest(mon/'consumer_events.jsonl')
        records.append(r)
        other=root/'uninstrumented'/mon.parent.name/mon.name
        if other.exists() and (other/'consumer_events.jsonl').exists():
            a=res(mon/'resource_usage.txt'); b=res(other/'resource_usage.txt')
            pair.append({'mode':mon.parent.name,'run':mon.name,
                'outcomes_identical_bytes':digest(mon/'consumer_events.jsonl')==digest(other/'consumer_events.jsonl'),
                'schedule_identical_bytes':digest(mon/'consumer_events.jsonl.arrivals.jsonl')==digest(other/'consumer_events.jsonl.arrivals.jsonl'),
                'instrumented':a,'uninstrumented':b,
                'instrumented_trace_bytes':sum(p.stat().st_size for p in mon.glob('*.jsonl')),
                'uninstrumented_trace_bytes':sum(p.stat().st_size for p in other.glob('*.jsonl')),
                'note':'wall CPU and RSS are observational; includes workflow noise. Observer time is NOT decision latency.'})
    statuses=collections.Counter(r.get('status','UNKNOWN') for r in records)
    counters=collections.Counter()
    for r in records:counters.update(r.get('diagnostic_status_counts') or {})
    hold={'stage':'1AB.FEASIBILITY.0','validation_status':'PRELIMINARY_PILOT_ONLY',
       'monitored_runs':len(records),'paired_runs':len(pair),'status_counts':dict(statuses),
       'diagnostic_counts':dict(counters),'paired_behavior_and_schedule_identical':all(p['outcomes_identical_bytes'] and p['schedule_identical_bytes'] for p in pair),
       'GO_FREEZE':False,'F3_ready':False,'training_ready':False,
       'Congestion':None,'FutureCongestion':None,
       'decision':'NO_GO_UNTIL_INDEPENDENT_MULTIHOP_AUDIT_AND_SCIENTIFIC_FREEZE',
       'limitations':['No real results until ndnSIM cloud artifact returned',
          'No HCRAF decision timing captured; only snapshot observer time',
          'No data for Test-ID/OOD may be used to tune label threshold',
          'Episode windows and RNG runs do not imply independent samples']}
    (root/'stage1ab_run_summary.json').write_text(json.dumps(records,indent=2,sort_keys=True)+'\n')
    (root/'stage1ab_overhead_pairs.json').write_text(json.dumps(pair,indent=2,sort_keys=True)+'\n')
    (root/'stage1ab_decision.json').write_text(json.dumps(hold,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'run_status':dict(statuses),'diag':dict(counters),'paired':len(pair)}))
    if len(records)!=24 or len(pair)!=9:return 2
    if any(r.get('status')!='PASS_TARGET_EVENT_ONLY' for r in records):return 3
    if any(not p['outcomes_identical_bytes'] or not p['schedule_identical_bytes'] for p in pair):return 4
    return 0
if __name__=='__main__':sys.exit(main(sys.argv[1]))
