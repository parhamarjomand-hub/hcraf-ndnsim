#!/usr/bin/env python3
"""Causal replay of measured pilot traces. No simulated data are generated here."""
import argparse
from collections import Counter,defaultdict
import hashlib
import json
from pathlib import Path
import zipfile

VALID={'SUCCESS','NACK','TIMEOUT'}
FEATURES=('RoutingCost','SRTT_ms','Congestion','SuccessEstimate','Goodput_bps')
FUTURE=('Success','Delay_ms','Congestion','Goodput_bps')

def require(ok,message):
    if not ok:raise ValueError(message)

def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def past_features(same,evidence,t,seq,window,alpha,cost):
    past=[]
    for e in same:
        if e['outcome'] not in VALID:continue
        raw=evidence[e['terminal_event_seq']]
        if raw['event_seq']<=seq and raw['time_ns']<=t:past.append(e)
    past.sort(key=lambda e:e['terminal_event_seq'])
    success=[e for e in past if e['outcome']=='SUCCESS']
    rtt=[e for e in success if e['delay_valid']]
    srtt=None
    for e in rtt:srtt=float(e['delay_ns']) if srtt is None else (1-alpha)*srtt+alpha*e['delay_ns']
    recent=[e for e in success if t-window<evidence[e['terminal_event_seq']]['time_ns']<=t]
    features=dict(RoutingCost=cost,SRTT_ms=None if srtt is None else srtt/1e6,Congestion=None,
        SuccessEstimate=len(success)/len(past) if past else None,
        Goodput_bps=8*sum(e['payload_bytes'] for e in recent)/(window/1e9) if t>=window else None)
    missing=dict(RoutingCost=None,SRTT_ms=None if rtt else 'NO_PAST_VALID_RTT',
        Congestion='FINAL_CONGESTION_DEFINITION_PENDING',SuccessEstimate=None if past else 'NO_PAST_VALID_OUTCOME',
        Goodput_bps=None if t>=window else 'INCOMPLETE_PAST_WINDOW')
    audit=dict(valid_outcomes=len(past),valid_rtt=len(rtt),max_terminal_event_seq=max((e['terminal_event_seq'] for e in past),default=None),
        evidence_episode_ids_sha256=digest([e['episode_id'] for e in past]),
        last_outcome_evidence_age_ns=t-evidence[past[-1]['terminal_event_seq']]['time_ns'] if past else None,
        last_rtt_evidence_age_ns=t-evidence[rtt[-1]['terminal_event_seq']]['time_ns'] if rtt else None)
    return features,missing,audit

def future_labels(same,t,horizon,stop):
    full=t+horizon<=stop
    ended=[e for e in same if e['end_ns'] is not None and t<e['end_ns']<=t+horizon]
    valid=[e for e in ended if e['outcome'] in VALID]
    success=[e for e in valid if e['outcome']=='SUCCESS']
    rtt=[e for e in success if e['delay_valid']]
    why=None if full and valid else 'INCOMPLETE_FUTURE_WINDOW' if not full else 'NO_VALID_FUTURE_OUTCOMES'
    values=dict(Success=None if why else len(success)/len(valid),
        Delay_ms=sum(e['delay_ns'] for e in rtt)/len(rtt)/1e6 if full and rtt else None,
        Congestion=None,Goodput_bps=None if why else 8*sum(e['payload_bytes'] for e in success)/(horizon/1e9))
    missing=dict(Success=why,Delay_ms=None if full and rtt else 'NO_VALID_FUTURE_RTT' if full else 'INCOMPLETE_FUTURE_WINDOW',
                 Congestion='FINAL_CONGESTION_DEFINITION_PENDING',Goodput_bps=why)
    audit=dict(full_window=full,observed_future=bool(full and valid),
      valid_outcomes=len(valid) if full else None,valid_rtt=len(rtt) if full else None,
      cancelled_excluded=sum(e['outcome']=='CANCELLED' for e in ended) if full else None,
      evidence_episode_ids_sha256=digest([e['episode_id'] for e in valid]) if full else None)
    return values,missing,audit

def busy_fraction(visible,start,end):
    """Uses only records supplied by caller; open transmission contributes elapsed time."""
    require(end>start,'invalid busy window')
    opened=None;busy=0
    for e in visible:
        if e['event_type']=='PHY_TX_BEGIN':
            require(opened is None,'overlapping directed transmissions')
            opened=e
        elif e['event_type']=='PHY_TX_END':
            require(opened is not None and opened['packet_uid']==e['packet_uid'],'unmatched transmission')
            busy+=max(0,min(end,e['time_ns'])-max(start,opened['time_ns']))
            opened=None
    if opened is not None:busy+=max(0,end-max(start,opened['time_ns']))
    require(0<=busy<=end-start,'invalid busy duration')
    return busy/(end-start)


def link_features(same,snapshot,t,window):
    visible=[x for x in same if x['link_event_seq']<=snapshot['link_event_seq']]
    require(all(x['time_ns']<=t for x in visible),'future link record before snapshot')
    complete=t>=window and visible and visible[0]['event_type']=='INITIAL' and visible[0]['time_ns']==0
    return dict(queue_packets=snapshot['queue_packets'],queue_bytes=snapshot['queue_bytes'],
      link_up=snapshot['link_up'],data_rate_bps=snapshot['data_rate_bps'],
      queue_drop_packets_total=snapshot['queue_drop_packets_total'],
      queue_drop_count_past_window=sum(x['event_type']=='QUEUE_DROP' and t-window<x['time_ns']<=t for x in visible) if complete else None,
      phy_busy_fraction_past_window=busy_fraction(visible,t-window,t) if complete else None,
      snapshot_link_event_seq=snapshot['link_event_seq'])


def future_link_evidence(same,t,horizon,stop):
    if t+horizon>stop:return dict(full_window=False,queue_drop_count=None,queue_drop_observed=None,phy_tx_started_count=None)
    within=[x for x in same if t<x['time_ns']<=t+horizon]
    n=sum(x['event_type']=='QUEUE_DROP' for x in within)
    return dict(full_window=True,queue_drop_count=n,queue_drop_observed=bool(n),
                phy_tx_started_count=sum(x['event_type']=='PHY_TX_BEGIN' for x in within))


def extract_run(ep,events,decisions,links,cfg,horizon=10**9,window=10**9,alpha=.125):
    require(horizon>0 and window>0 and 0<alpha<=1,'invalid parameters')
    evidence={e['event_seq']:e for e in events}
    require(len(evidence)==len(events),'duplicate event sequence')
    require(events[-1]['event_type']=='SIMULATION_END' and events[-1]['time_ns']==cfg['stop_ns'],'incomplete trace')
    byface=defaultdict(list);linkface=defaultdict(list);snapshots={};winners=set()
    for e in ep:
        require(e['name'].startswith('/hcraf/pilot/'),'out of scope episode')
        require(e['terminal_event_seq'] in evidence,'missing terminal evidence')
        require(e['end_ns'] is None or evidence[e['terminal_event_seq']]['time_ns']>=e['end_ns'],'terminal evidence precedes outcome')
        if e['outcome']=='SUCCESS':
            k=(e['node_id'],e['pit_instance_id']);require(k not in winners,'duplicate useful Data credit');winners.add(k)
            require(type(e.get('payload_bytes')) is int and e['payload_bytes']>=0,'missing payload')
        byface[(e['node_id'],e['face_id'])].append(e)
    for x in links:
        k=(x['node_id'],x['face_id']);linkface[k].append(x)
        if x['event_type']=='DECISION_SNAPSHOT':
            key=(x['decision_id'],k);require(key not in snapshots,'duplicate snapshot');snapshots[key]=x
    tx=defaultdict(list)
    for e in events:
        if e['event_type']=='TX_INTEREST':tx[(e['decision_id'],e['face_id'])].append(e['event_seq'])
    candidates=[];lookup={}
    for d in decisions:
        t=d['time_ns'];seq=d['after_event_seq']
        require(d['anchor']=='BEFORE_AFTER_RECEIVE_INTEREST','not a pre-decision snapshot')
        require(0<=seq<=len(events),'invalid event boundary')
        require(not seq or evidence[seq]['time_ns']<=t,'past boundary after decision')
        for c in d['candidates']:
            key=(d['node_id'],c['face_id']);same=byface[key]
            snap=snapshots[(d['decision_id'],key)];require(snap['time_ns']==t,'snapshot time mismatch')
            features,missing,audit=past_features(same,evidence,t,seq,window,alpha,c['routing_cost'])
            row=dict(decision_id=d['decision_id'],node_id=d['node_id'],pit_instance_id=str(d['pit_instance_id']),
              face_id=c['face_id'],name=d['name'],anchor_time_ns=t,after_event_seq=seq,
              anchor_kind=d['anchor'],context_prefix='/hcraf/pilot',
              selected=bool(tx[(d['decision_id'],c['face_id'])]),strategy_eligible=c['strategy_eligible'],
              features=features,feature_missing_reasons=missing,past_evidence=audit,
              local_link_primitives=link_features(linkface[key],snap,t,window),
              research_training_eligible=False)
            k=(d['decision_id'],c['face_id']);require(k not in lookup,'duplicate decision-face');lookup[k]=row
            candidates.append(row)
    dataset=[]
    for e in ep:
        first=evidence[e['tx_event_seqs'][0]]
        row=lookup[(first['decision_id'],e['face_id'])]
        require(row['selected'] and row['pit_instance_id']==str(e['pit_instance_id']),'wrong episode anchor')
        require(e['start_ns']==row['anchor_time_ns'] and first['event_seq']>row['after_event_seq'],'action not after snapshot')
        same=byface[(e['node_id'],e['face_id'])];t=row['anchor_time_ns']
        future,missing,audit=future_labels(same,t,horizon,cfg['stop_ns'])
        dataset.append(dict(row,episode_id=e['episode_id'],source_run_id=e['run_id'],
          episode_outcome=e['outcome'],censor_reason=e.get('censor_reason'),
          tx_count=e['tx_count'],future=future,future_missing_reasons=missing,future_evidence=audit,
          future_local_link_evidence=future_link_evidence(linkface[(e['node_id'],e['face_id'])],t,horizon,cfg['stop_ns'])))
    return dataset,candidates


def lines(z,name):return [json.loads(l) for l in z.read(name).splitlines() if l.strip()]

def build(artifacts,out,horizon=10**9,window=10**9,alpha=.125):
    out.mkdir(parents=True,exist_ok=True)
    all_ep=[];all_candidates=[];sources=[];runs=[];seen=set()
    for artifact in artifacts:
        artifact_sha=hashlib.sha256(artifact.read_bytes()).hexdigest();require(artifact_sha not in seen,'duplicate input artifact');seen.add(artifact_sha)
        with zipfile.ZipFile(artifact) as z:
            manifest=json.loads(z.read('manifest.json'))
            for n,sha in manifest['artifact_sha256'].items():require(hashlib.sha256(z.read(n)).hexdigest()==sha,'hash mismatch: '+n)
            repname=next((n for n in ('multi_reproducibility.json','load_reproducibility.json','reproducibility.json') if n in z.namelist()),None)
            require(repname is not None,'missing verification report');rep=json.loads(z.read(repname));require(rep['status']=='PASS','unverified source')
            for mode,hashes in rep['modes'].items():
                for n,sha in hashes.items():
                    a=z.read(mode+'/repeat-1/'+n);b=z.read(mode+'/repeat-2/'+n)
                    require(a==b and hashlib.sha256(a).hexdigest()==sha,'source determinism/hash mismatch')
                derived=[]
                for repeat in (1,2):
                    prefix=mode+'/repeat-'+str(repeat)+'/'
                    for n in ('verification.json','decision_verification.json','load_verification.json','multi_verification.json'):
                        if prefix+n in z.namelist():require(json.loads(z.read(prefix+n))['status']=='PASS','source run failed')
                    cfg=json.loads(z.read(prefix+'scenario.json'))
                    dataset,candidates=extract_run(lines(z,prefix+'episodes.jsonl'),lines(z,prefix+'events.jsonl'),
                      lines(z,prefix+'events.jsonl.decisions.jsonl'),lines(z,prefix+'link_events.jsonl'),cfg,horizon,window,alpha)
                    derived.append((digest(dataset),digest(candidates)))
                    runkey=str(manifest['github_run_id'])+'/'+prefix.rstrip('/')
                    for kind,rows in [('episode',dataset),('candidate',candidates)]:
                        for row in rows:
                            row.update(run_key=runkey,source_artifact_sha256=artifact_sha,source_directory=prefix,
                              repeat=repeat,mode=mode,split_role='ENGINEERING_PILOT_ONLY',
                              independent_repeat=False,horizon_ns=horizon,window_ns=window)
                            row['row_id']=runkey+'/'+(row['episode_id'] if kind=='episode' else str(row['decision_id'])+'/'+str(row['face_id']))
                    all_ep.extend(dataset);all_candidates.extend(candidates)
                    runs.append(dict(run_key=runkey,episodes=len(dataset),candidate_rows=len(candidates),
                        future_valid={k:sum(r['future'][k] is not None for r in dataset) for k in FUTURE}))
                require(derived[0]==derived[1],'derived data not reproducible')
            sources.append(dict(artifact=artifact.name,sha256=artifact_sha,github_run=manifest['github_run_id'],
               git_commit=manifest['git_commit'],verified_manifest_files=len(manifest['artifact_sha256'])))
    require(len({r['row_id'] for r in all_ep})==len(all_ep),'duplicate output row ID')
    output_hashes={}
    for filename,rows in [('episode_dataset.jsonl',all_ep),('candidate_predecision_features.jsonl',all_candidates)]:
        p=out/filename;p.write_text(''.join(json.dumps(r,sort_keys=True,ensure_ascii=False)+'\n' for r in rows))
        output_hashes[filename]=hashlib.sha256(p.read_bytes()).hexdigest()
    report=dict(status='PASS_PARTIAL_CAUSAL_EXTRACTION',research_training_ready=False,
      parameters=dict(horizon_ns=horizon,window_ns=window,srtt_alpha=alpha,success_estimator='CUMULATIVE_EMPIRICAL_RATIO',
        parameter_status='PROVISIONAL_ENGINEERING_NOT_OPTIMIZED',update_policy='TERMINAL_EVIDENCE_ARRIVAL'),
      sources=sources,runs=runs,episode_rows=len(all_ep),candidate_rows=len(all_candidates),
      outcomes=dict(Counter(r['episode_outcome'] or 'CENSORED' for r in all_ep)),
      valid_features={k:sum(r['features'][k] is not None for r in all_ep) for k in FEATURES},
      valid_future={k:sum(r['future'][k] is not None for r in all_ep) for k in FUTURE},
      nonzero_future_local_drop_rows=sum(r['future_local_link_evidence']['queue_drop_observed'] is True for r in all_ep),
      unresolved=['Final Congestion feature/label definition','Production state estimator and parameters',
      'Strategy eligibility and probe roles','Independent diverse runs and Train/Val/Test split',
      'Selection bias and future observation coverage across Faces','Online replay equivalence not tested in simulator'],
      output_sha256=output_hashes)
    (out/'extraction_report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ('status','episode_rows','candidate_rows','valid_features','valid_future')},indent=2))
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--artifact',type=Path,action='append',required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--horizon-ms',type=int,default=1000)
    p.add_argument('--window-ms',type=int,default=1000);p.add_argument('--srtt-alpha',type=float,default=.125)
    a=p.parse_args();build(a.artifact,a.output,a.horizon_ms*10**6,a.window_ms*10**6,a.srtt_alpha)
