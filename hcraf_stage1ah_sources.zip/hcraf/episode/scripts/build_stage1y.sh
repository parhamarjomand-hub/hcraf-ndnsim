#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK_DIR="$PROJECT_DIR/hcraf/episode"
SOURCE_DIR="$PROJECT_DIR/episode_sources/ns-3"
# Preserve all prior sources, patches and their pinned origins.
bash "$TASK_DIR/scripts/build_stage1w.sh"
for header in hcraf-stage1w-monitor.hpp hcraf-stage1w-lp.hpp; do
  test -s "$TASK_DIR/src/$header"
  cmp -s "$TASK_DIR/src/$header" "$SOURCE_DIR/scratch/$header"
done
cp "$TASK_DIR/src/hcraf-stage1y-pilot.cpp" "$SOURCE_DIR/scratch/hcraf-stage1y-pilot.cc"
cmp -s "$TASK_DIR/src/hcraf-stage1y-pilot.cpp" "$SOURCE_DIR/scratch/hcraf-stage1y-pilot.cc"
cd "$SOURCE_DIR"
python3 ./waf -j 2
test -x build/scratch/hcraf-stage1y-pilot
