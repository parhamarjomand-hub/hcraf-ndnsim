"""Predeclared acceptance checks; no expected counts are substituted for measurements."""
import json,sys
from pathlib import Path
from collections import Counter
from episodes import load,require,reconstruct
from verify_decisions import verify
from verify_load import link_busy_intervals
MODES=('control','local-pressure','return-pressure','random-loss','receive-outage','no-route')
def check(p):
 c=json.loads((p/'scenario.json').read_text());mode=c['mode'];require(mode in MODES,'unknown mode')
 rate=600 if mode=='local-pressure' else 30 if mode=='return-pressure' else 5
 require(c['instrumentation_stage']=='1G.1' and c['request_rate_per_s']==rate and c['planned_requests']==8*rate and c['stop_ns']==13*10**9,'scenario configuration mismatch')
 require(c['primary_rate_bps']==(128000 if mode=='local-pressure' else 10000000) and c['return_rate_bps']==(128000 if mode=='return-pressure' else 10000000),'directional capacity mismatch')
 rows,decision_report=verify(p,multi_profile=True)
 require(all(r['selected'] and r['face_id']==c['primary_face_id'] and len(r['tx_event_seqs'])==1 for r in rows),'wrong selected face')
 decision_report['stage']='1G.1'
 (p/'decision_faces.jsonl').write_text(''.join(json.dumps(r,sort_keys=True)+'\n' for r in rows))
 (p/'decision_verification.json').write_text(json.dumps(decision_report,indent=2)+'\n')
 e=load(p/'episodes.jsonl');raw=load(p/'events.jsonl');links=load(p/'link_events.jsonl');faults=load(p/'fault_events.jsonl');consumer=load(p/'consumer_events.jsonl')
 require(e==reconstruct(raw,mode+'-seed1-run1'),'episode reconstruction mismatch')
 counts=Counter(x['outcome'] for x in e)
 require(len(e)==c['planned_requests'] and None not in counts and counts['CANCELLED']==0,'unexpected episode count/censoring')
 require(all(x['tx_count']==1 for x in e),'unexpected retransmission')
 sends=[x for x in consumer if x['event']=='SEND']; require(len(sends)==c['planned_requests'],'SEND count')
 require([x['time_ns'] for x in sends]==[10**9+i*10**9//c['request_rate_per_s'] for i in range(c['planned_requests'])],'SEND schedule')
 require(all(x['queue_packets']==0 for x in links if x['event_type']=='FINAL'),'queue not drained')
 link_busy_intervals(links,0,c['stop_ns'])
 drops=Counter(x['node_id'] for x in links if x['event_type']=='QUEUE_DROP');rx=[x for x in faults if x['event']=='PHY_RX_DROP']
 transmitted={x['packet_uid'] for x in links if x['event_type']=='PHY_TX_BEGIN' and x['node_id']==1 and x['face_id']==c['primary_face_id']}
 require(all(x.get('node_id')==2 and x.get('packet_uid') in transmitted and 0<=x['time_ns']<=c['stop_ns'] for x in rx),'RX drop without upstream transmission evidence')
 require(all(x['event'] in ('PHY_RX_DROP','RX_OUTAGE_START','RX_OUTAGE_END') for x in faults),'unknown fault')
 successful={x['name'] for x in e if x['outcome']=='SUCCESS'};delivered=[x['name'] for x in consumer if x['event']=='DATA']
 require(len(delivered)==len(set(delivered)) and set(delivered)<=successful,'consumer evidence mismatch')
 if mode=='control': require(counts['SUCCESS']==len(e) and len(delivered)==len(e) and not drops and not rx,'control failed')
 if mode=='local-pressure': require(drops[1]>0 and drops[2]==0 and counts['TIMEOUT']>0 and not rx,'local pressure not isolated')
 if mode=='return-pressure': require(drops[2]>0 and drops[1]==0 and counts['TIMEOUT']>0 and not rx,'return pressure not isolated')
 if mode=='random-loss': require(rx and not drops and counts['SUCCESS']>0 and counts['TIMEOUT']>0,'random loss evidence absent')
 if mode=='receive-outage':
  require([x for x in faults if x['event']!='PHY_RX_DROP']==[{'event':'RX_OUTAGE_START','time_ns':3*10**9},{'event':'RX_OUTAGE_END','time_ns':6*10**9}],'outage schedule')
  require(rx and all(3*10**9<=x['time_ns']<6*10**9 for x in rx) and not drops,'outage drop evidence')
  require(counts['TIMEOUT']>0 and any(x['outcome']=='SUCCESS' and x['start_ns']>6*10**9 for x in e),'outage/recovery evidence')
 if mode=='no-route':
  require(counts['NACK']==len(e) and not rx and not drops,'no-route outcome')
  require(any(x['event_type']=='NACK_ACCEPTED' and x['reason']==150 for x in raw),'NO_ROUTE reason missing')
 result={'status':'PASS','mode':mode,'episodes':len(e),'outcomes':dict(counts),'queue_drops_by_node':dict(drops),'rx_drops':len(rx),'consumer_delivered':len(delivered),'training_ready':False,'physical_link_down_tested':False}
 (p/'cause_verification.json').write_text(json.dumps(result,indent=2)+'\n');return result
if __name__=='__main__':
 p=Path(sys.argv[1])
 try: print(json.dumps(check(p)))
 except Exception as ex:
  (p/'cause_verification.json').write_text(json.dumps({'status':'FAIL','error':str(ex)},indent=2)+'\n');raise
