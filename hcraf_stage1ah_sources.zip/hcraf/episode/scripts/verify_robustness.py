#!/usr/bin/env python3
"""Stage1S: conservative real-trace audit for invalidated Stage1R uniqueness assumptions.

Distinct physical packet UIDs are ONLY scoped to (node_id, device_index, UID).
Ambiguous name-only Data mappings remain unresolved; CS hits do not create phantom
TX_INTEREST episodes. Not a congestion labeler. Compatible with Python 3.8.
"""
import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path

from verify_visibility_1s import verify_trace, require, read_jsonl
from verify_attribution import packet_index, get_admission

MODES = ('baseline','repeat-name','retransmission','aggregation','cache-hit','multi-hop')
EDGES = ((0,1), (1,2), (1,3), (1,4))
OUTCOMES = ('SUCCESS','NACK','TIMEOUT','CANCELLED',None)

def graph(mode):
    """Expected node/device positions from the C++ link.Install call order."""
    edges=list(EDGES)
    if mode=='aggregation': edges.append((5,1))
    if mode=='multi-hop': edges.extend(((2,5),(3,6),(4,7)))
    bynode=Counter()
    result={}
    for a,b in edges:
        k=(a,bynode[a]);bynode[a]+=1
        j=(b,bynode[b]);bynode[b]+=1
        result[k]=j;result[j]=k
    return result

def validate_graph(link,mode):
    expected=graph(mode)
    observed={(x['node_id'],x['device_index']):x['face_id']
              for x in link if x['event_type']=='INITIAL'}
    require(set(expected)==set(observed), 'wrong monitored topology or device mapping')
    require(len(set((n,f) for (n,_),f in observed.items()))==len(observed),
            'face ID reused on one node')
    return expected,observed

def source_events(folder,mode):
    filenames=['consumer_events.jsonl']
    if mode=='aggregation': filenames.append('consumer_events_secondary.jsonl')
    sends=[];datas=[];arrivals=[]
    for source,filename in enumerate(filenames):
        path=folder/filename
        raw=read_jsonl(path)
        scheduled=read_jsonl(folder/(filename+'.arrivals.jsonl'))
        srcs=[x for x in raw if x['event']=='SEND']
        values=[x for x in raw if x['event']=='DATA']
        require(len(srcs)==len(scheduled),'arrival schedule/SEND mismatch')
        for s,a in zip(srcs,scheduled):
            require(s['time_ns']==a['time_ns'] and s['source_id']==a['source_id']==source,
                    'consumer schedule not applied or source mismatch')
            require(s['name'].startswith('/hcraf/pilot/') and type(s['nonce']) is int,
                    'invalid consumer Interest identity')
        sends.extend(srcs);datas.extend([dict(x,source_id=source) for x in values]);arrivals.extend(scheduled)
    require(len({(s['source_id'],s['nonce']) for s in sends})==len(sends),'duplicate source Nonce')
    return sends,datas,arrivals

def find_send_candidates(send_by_name, name, nonce, tx_ns):
    return [s for s in send_by_name[name] if s['nonce']==nonce and s['time_ns']<=tx_ns]

def evidence_state(link_by_name, node, face, kind, name, nonce, minimum_ns):
    key=(node,face,kind,name,nonce if kind=='INTEREST' else None)
    return get_admission(link_by_name,key,minimum_ns)

def nfd_tx_join(tx, by_name, send_by_name):
    source=find_send_candidates(send_by_name,tx['name'],tx['nonce'],tx['time_ns'])
    if len(source)!=1:
        return {'status':('NO_SOURCE' if not source else 'AMBIGUOUS_SOURCE'), 'packet':None}
    status, packet=evidence_state(by_name,tx['node_id'],tx['face_id'],'INTEREST',
                                 tx['name'],tx['nonce'],tx['time_ns'])
    return {'status':status,'packet':packet,'consumer_source_id':source[0]['source_id']}

def packet_on(link, endpoint, kind, name, nonce, event_type, min_ns):
    """Select only a unique actual link event on the specified physical endpoint."""
    rows=[r for r in link if r['event_type']==event_type and
          (r['node_id'],r['device_index'])==endpoint and
          r['ndn_packet_type']==kind and r['ndn_name']==name and
          (kind=='DATA' or r['ndn_nonce']==nonce) and r['time_ns']>=min_ns]
    require(len(rows)==1,
            'missing/ambiguous %s %s %s on endpoint %s: %s candidates' %
            (event_type,kind,name,endpoint,len(rows)))
    return rows[0]

def check_multihop_chain(tx,link,expected,device_faces):
    # One exact original Interest Name per send in this scenario, so data-by-name
    # may be linked within this explicitly controlled (CS disabled) topology.
    router_end=[k for k,f in device_faces.items()
                if k[0]==1 and f==tx['face_id']]
    require(len(router_end)==1,'selected router Face lacks physical interface')
    a=router_end[0]; b=expected[a]
    require(b[0] in (2,3,4),'first hop did not reach middle router')
    downstream=[k for k in expected if k[0]==b[0] and expected[k][0] in (5,6,7)]
    require(len(downstream)==1,'ambiguous second hop')
    c=downstream[0];d=expected[c]
    name=tx['name'];nonce=tx['nonce'];t=tx['time_ns']
    stages=[
      (a,'INTEREST','QUEUE_ENQUEUE'),(b,'INTEREST','MAC_RX'),
      (c,'INTEREST','QUEUE_ENQUEUE'),(d,'INTEREST','MAC_RX'),
      (d,'DATA','QUEUE_ENQUEUE'),(c,'DATA','MAC_RX'),
      (b,'DATA','QUEUE_ENQUEUE'),(a,'DATA','MAC_RX')]
    samples=[]
    for endpoint,kind,event in stages:
        x=packet_on(link,endpoint,kind,name,nonce,event,t)
        t=x['time_ns'];samples.append(x)
    # UID scopes must be local; no cross-device equality is used.
    return {'name':name,'nonce':nonce,'source_face_id':tx['face_id'],
            'pit_instance_id':tx.get('pit_instance_id'),
            'nfd_tx_event_seq':tx.get('event_seq'),
            'decision_id':tx.get('decision_id'),
            'router_data_mac_rx_ns':samples[-1]['time_ns'],
            'forward_hops':2,'return_hops':2,'observed_events':len(samples),
            'link_packet_keys':[[x['node_id'],x['device_index'],x['packet_uid']] for x in samples]}

def assert_closed_labels(cfg,episodes):
    require(cfg.get('training_ready') is False and cfg.get('final_congestion_label') is None and
            cfg.get('future_congestion_label') is None and cfg.get('causal_congestion_attribution') is None,
            'unapproved congestion label/training flag')
    require(all(e.get('outcome') in OUTCOMES for e in episodes), 'unexpected Episode outcome')

def verify(folder):
    folder=Path(folder)
    cfg=json.loads((folder/'scenario.json').read_text(encoding='utf8'))
    mode=cfg['mode']
    require(cfg['collector_stage']=='1S.1' and cfg['queue_trace_schema']=='1R.1' and
            mode in MODES and cfg['run'] in (1001,1002) and cfg['seed']==17,
            'incorrect Stage1S scenario provenance')
    link=read_jsonl(folder/'link_events.jsonl')
    expected,device_faces=validate_graph(link,mode)
    # Make sure all event records have a real (node,device) and matching local Face.
    for x in link:
        k=(x['node_id'],x['device_index'])
        require(k in device_faces and x['face_id']==device_faces[k],
                'link event refers to unknown or conflicting local Face')
    prev=-1
    for i,x in enumerate(link,1):
        require(x['schema_version']=='1R.1' and x['link_event_seq']==i and
                type(x['time_ns']) is int and x['time_ns']>=prev,
                'broken event sequence/time')
        prev=x['time_ns']
    original=[dict(x,schema_version='1P.1',link_event_seq=i)
              for i,x in enumerate((x for x in link if x['event_type']!='MAC_RX'),1)]
    v=verify_trace(original,cfg['queue_capacity_packets'],len(expected))
    by_uid,by_name,decode=packet_index(link)
    sends,consumer_data,arrivals=source_events(folder,mode)
    require(len(sends)==len(arrivals)==cfg['planned_requests'],'wrong offered Interest count')
    decisions=read_jsonl(folder/'events.jsonl.decisions.jsonl')
    selections=read_jsonl(folder/'events.jsonl.collection.jsonl')
    nfd=read_jsonl(folder/'events.jsonl')
    episodes=read_jsonl(folder/'episodes.jsonl')
    assert_closed_labels(cfg,episodes)
    require(len({x['decision_id'] for x in decisions})==len(decisions),'duplicate decision id')
    require(v['decisions_with_complete_snapshots']==len(decisions),'missing monitor snapshots for NFD decisions')
    require(len(sends)>=len(episodes),'more PIT-Face Episode than originating Interests in pilot')
    send_by_name=defaultdict(list)
    for s in sends:send_by_name[s['name']].append(s)
    tx=[e for e in nfd if e['event_type']=='TX_INTEREST']
    cache=[e for e in nfd if e['event_type']=='CACHE_HIT']
    join=[];statuses=Counter();rx_states=Counter()
    for t in tx:
        require(t['node_id']==1 and t['face_id']>=0 and t['time_ns']>=0,'unexpected NFD TX location')
        r=nfd_tx_join(t,by_name,send_by_name)
        statuses[r['status']]+=1
        rx_status='UNRESOLVED_NO_UNIQUE_TX'
        rx_uid=None
        if r['status']=='MATCHED_UNIQUE':
            pkt=r['packet']
            if pkt['event_type']=='QUEUE_DROP':
                rx_status='DROPPED_AT_QUEUE'
            else:
                peer=expected[(pkt['node_id'],pkt['device_index'])]
                receivers=[x for x in link if x['event_type']=='MAC_RX' and
                           (x['node_id'],x['device_index'])==peer and
                           x['ndn_packet_type']=='INTEREST' and x['ndn_name']==t['name'] and
                           x['ndn_nonce']==t['nonce'] and x['time_ns']>=pkt['time_ns']]
                if len(receivers)==1:
                    rx_status='MATCHED_UNIQUE_RECEIVE'
                    rx_uid=receivers[0]['packet_uid']
                elif not receivers:
                    rx_status='NOT_OBSERVED'
                else:
                    rx_status='AMBIGUOUS_MULTIPLE_RECEIVES'
        rx_states[rx_status]+=1
        join.append(dict(event_seq=t['event_seq'],name=t['name'],nonce=t['nonce'],
                    pit_instance_id=t['pit_instance_id'],face_id=t['face_id'],
                    decision_id=t['decision_id'],time_ns=t['time_ns'],
                    join_status=r['status'],
                    first_hop_receive_status=rx_status,first_hop_receiver_uid=rx_uid,
                    packet_uid=r['packet']['packet_uid'] if r['packet'] else None,
                    packet_node_id=r['packet']['node_id'] if r['packet'] else None,
                    packet_device_index=r['packet']['device_index'] if r['packet'] else None,
                    consumer_source_id=r.get('consumer_source_id'),
                    Congestion=None,FutureCongestion=None,training_ready=False))
    # Deliberately do not join Data by Name when that Name was requested multiple times.
    sends_per_name=Counter(s['name'] for s in sends)
    unresolved_names={name for name,n in sends_per_name.items() if n>1}
    possible_return=[]
    for e in episodes:
        require(type(e['pit_instance_id']) in (str,int),'bad PIT identifier')
        if e['name'] in unresolved_names:
            possible_return.append({'pit_instance_id':e['pit_instance_id'],'name':e['name'],
                                    'status':'UNRESOLVED_REPEATED_NAME','linked_return_packet':None})
        else:
            possible_return.append({'pit_instance_id':e['pit_instance_id'],'name':e['name'],
                                    'status':'NOT_ASSIGNED_BY_NAME_ONLY','linked_return_packet':None})
    # Multi-hop requires true link evidence on a second physical hop. No UID equality across hops.
    hop2=[];chain=[]
    if mode=='multi-hop':
        for t in tx:
            for x in link:
                if (x['node_id'] in (2,3,4) and x['event_type'] in ('QUEUE_ENQUEUE','QUEUE_DROP') and
                    x['ndn_packet_type']=='INTEREST' and x['ndn_name']==t['name'] and
                    x['ndn_nonce']==t['nonce'] and x['time_ns']>=t['time_ns']):
                    hop2.append(x)
        require(len(hop2)>0,'multi-hop scenario produced no actual second-hop Interest')
        for t in tx:
            ep=[e for e in episodes if (int(e['pit_instance_id'])==t['pit_instance_id'] and
               e['name']==t['name'] and e['face_id']==t['face_id'])]
            require(len(ep)==1 and ep[0]['outcome']=='SUCCESS' and ep[0]['tx_count']==1,
                    'no unique successful PIT×Face episode for multi-hop TX')
            connected=check_multihop_chain(t,link,expected,device_faces)
            require(connected['router_data_mac_rx_ns']<=ep[0]['end_ns'],
                    'multi-hop router received Data after claimed Episode SUCCESS')
            connected['episode_id']=ep[0]['episode_id']
            connected['episode_outcome']=ep[0]['outcome']
            chain.append(connected)
        for x in hop2:
            peer=expected[(x['node_id'],x['device_index'])]
            require(peer[0] in (5,6,7),'second-hop reached unexpected endpoint')
            rx=[r for r in link if (r['event_type']=='MAC_RX' and
                (r['node_id'],r['device_index'])==peer and
                r['ndn_packet_type']=='INTEREST' and r['ndn_name']==x['ndn_name'] and
                r['ndn_nonce']==x['ndn_nonce'] and r['time_ns']>=x['time_ns'])]
            require(len(rx)==1,'second-hop receive missing or ambiguous')
    duplicate_pits=defaultdict(set)
    for d in decisions: duplicate_pits[(d['pit_instance_id'],d['name'])].add(d['ingress_face_id'])
    same_pit_decisions=Counter((d['pit_instance_id'],d['name']) for d in decisions)
    shared_pit_count=sum(n>1 for n in same_pit_decisions.values())
    aggregated_ingresses=sum(len(faces)>1 for faces in duplicate_pits.values())
    # Acceptance gates are based only on real observations, never on fabricated episode rows.
    if mode=='baseline':
        require(len(tx)==len(sends)==12 and statuses['MATCHED_UNIQUE']==len(tx),
                'Stage1S control requires all outgoing Interests to join uniquely')
        require(len(consumer_data)==12, 'control consumer responses incomplete')
        require(rx_states['MATCHED_UNIQUE_RECEIVE']==12,'control first-hop receipt is incomplete')
    elif mode=='repeat-name':
        require(len(unresolved_names)>=4 and len(tx)==8 and
                statuses['MATCHED_UNIQUE']==8 and len(consumer_data)==8,
                'sequential repeated names were not cleanly observed')
        require(rx_states['MATCHED_UNIQUE_RECEIVE']==8,'repeated-name first-hop receipt is incomplete')
        require(len({(e['pit_instance_id'],e['name']) for e in episodes})==len(episodes),
                'reused PIT identity for new generation')
    elif mode=='retransmission':
        require(len(unresolved_names)>=4 and shared_pit_count>=1,
                'no repeated Interests reached the same PIT generation')
        require(len(consumer_data)>=4,'no retransmission responses observed')
    elif mode=='aggregation':
        require(len(unresolved_names)>=4 and aggregated_ingresses>=1,
                'two distinct ingress Faces did not aggregate into PIT')
        require(len(consumer_data)>=4,'aggregated requests lack consumer Data')
    elif mode=='cache-hit':
        require(all(not any(t['pit_instance_id']==hit['pit_instance_id'] for t in tx) for hit in cache),
                'cache hit PIT was also forwarded upstream')
        require(len(unresolved_names)>=4 and len(cache)>0,
                'the scenario has not demonstrated a real NFD CS hit')
        require(len(consumer_data)>=5,'not enough consumer responses for CS diagnostic')
    elif mode=='multi-hop':
        require(len(tx)==len(sends)==12 and statuses['MATCHED_UNIQUE']==12 and
                len(consumer_data)==12,'multi-hop first-link attribution incomplete')
        require(rx_states['MATCHED_UNIQUE_RECEIVE']==12,'multi-hop first-hop receives incomplete')
    # Fail closed if selected unique evidence is contradicted within the originating packet.
    for r in join:
        if r['join_status']=='MATCHED_UNIQUE':
            pkt=next(x for x in tx if x['event_seq']==r['event_seq'])
            key=(r['packet_node_id'],r['packet_device_index'],r['packet_uid'])
            samples=by_uid[key]
            require(all(y['ndn_name']==pkt['name'] and y['ndn_nonce']==pkt['nonce']
                        for y in samples),'packet UID conflicting with NFD TX')
    out=dict(status='PASS_STAGE1S_DIAGNOSTIC_PENDING_INDEPENDENT_CLOUD_AUDIT',
             mode=mode,run=cfg['run'],send_count=len(sends),consumer_data_count=len(consumer_data),
             nfd_decisions=len(decisions),nfd_transmissions=len(tx),episodes=len(episodes),
             cache_hits=len(cache),same_pit_repeated_decisions=shared_pit_count,
             aggregated_ingress_pits=aggregated_ingresses,
             repeated_names=len(unresolved_names),
             joined_nfd_tx=dict(statuses),first_hop_receive_statuses=dict(rx_states),
             second_hop_interest_packets=len(hop2),
             validated_four_leg_multihop_chains=len(chain),
             observed_directions=len(expected),wire_decode_events=dict(decode),
             return_data_link_policy='REQUIRE_PACKET_DISAMBIGUATION_WHEN_NAMES_REPEAT',
             final_congestion=None,future_congestion=None,training_ready=False)
    (folder/'robustness_attribution.jsonl').write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in join),encoding='utf8')
    (folder/'robustness_multihop_chains.jsonl').write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in chain),encoding='utf8')
    (folder/'robustness_return_status.jsonl').write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in possible_return),encoding='utf8')
    (folder/'robustness_verification.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n',encoding='utf8')
    return out

def main():
    ap=argparse.ArgumentParser();ap.add_argument('folder',type=Path);args=ap.parse_args()
    try:
        print(json.dumps(verify(args.folder),sort_keys=True))
    except Exception as error:
        (args.folder/'robustness_verification.json').write_text(json.dumps(dict(status='FAIL',error=str(error)),indent=2)+'\n')
        raise
if __name__=='__main__':main()
