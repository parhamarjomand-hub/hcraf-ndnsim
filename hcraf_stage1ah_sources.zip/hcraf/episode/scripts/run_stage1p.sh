#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK_DIR="$PROJECT_DIR/hcraf/episode"
OUTPUT_DIR="$PROJECT_DIR/episode_output"
cd "$PROJECT_DIR/episode_sources/ns-3"
status=0
for mode in baseline forward-buffered return-buffered forward-overflow return-overflow; do
  for run in 1001 1002; do
    folder="$OUTPUT_DIR/stage1p/$mode/run-$run"
    mkdir -p "$folder"
    command="hcraf-visibility-pilot --mode=$mode --output=$folder --seed=17 --run=$run"
    printf '%s\n' "$command" > "$folder/command.txt"
    if ! python3 ./waf --run-no-build "$command" > "$folder/simulator.log" 2>&1; then
      echo "FAIL sim $mode run=$run"; status=1; continue
    fi
    if ! python3 "$TASK_DIR/scripts/episodes.py" "$folder" --run-id "1p-$mode-17-$run"; then
      echo "FAIL episodes $mode run=$run"; status=1; continue
    fi
    if ! python3 "$TASK_DIR/scripts/verify_visibility.py" "$folder"; then
      echo "FAIL visibility $mode run=$run"; status=1
    fi
  done
done
if ! python3 "$TASK_DIR/scripts/summarize_visibility.py" "$OUTPUT_DIR/stage1p"; then status=1; fi
exit "$status"
