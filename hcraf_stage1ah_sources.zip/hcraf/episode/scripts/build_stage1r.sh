#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK_DIR="$PROJECT_DIR/hcraf/episode"
SOURCE_DIR="$PROJECT_DIR/episode_sources/ns-3"
# Reuse the unchanged, exact-commit, fail-closed NFD patch and Stage1P build.
bash "$TASK_DIR/scripts/build.sh"
cp "$TASK_DIR/src/hcraf-wire-decode.hpp" "$SOURCE_DIR/scratch/hcraf-wire-decode.hpp"
cp "$TASK_DIR/src/hcraf-attribution-monitor.hpp" "$SOURCE_DIR/scratch/hcraf-attribution-monitor.hpp"
cp "$TASK_DIR/src/hcraf-attribution-pilot.cpp" "$SOURCE_DIR/scratch/hcraf-attribution-pilot.cc"
cd "$SOURCE_DIR"
python3 ./waf -j 2
test -x build/scratch/hcraf-attribution-pilot
