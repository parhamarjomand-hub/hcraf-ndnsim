#!/usr/bin/env python3
"""Aggregate real Stage1S runs. Does not impute missing runs or produce final labels."""
import argparse
from collections import Counter
import json
from pathlib import Path

MODES=('baseline','repeat-name','retransmission','aggregation','cache-hit','multi-hop')
RUNS=(1001,1002)

def summary(root):
    root=Path(root)
    results=[];failed=[]
    for mode in MODES:
        for run in RUNS:
            f=root/mode/('run-%d'%run)/'robustness_verification.json'
            try:
                record=json.loads(f.read_text(encoding='utf8'))
                if not record['status'].startswith('PASS_') or record['mode']!=mode or record['run']!=run:
                    raise ValueError('invalid run identity/status')
                results.append(record)
            except (OSError,KeyError,ValueError) as e:
                failed.append(dict(mode=mode,run=run,problem=str(e)))
    report=dict(stage='1S.1',expected_run_count=len(MODES)*len(RUNS),
                completed_run_count=len(results),failed_runs=failed,
                mode_run_counts=dict(Counter(r['mode'] for r in results)),
                measured_sends=sum(r['send_count'] for r in results),
                measured_episodes=sum(r['episodes'] for r in results),
                real_cache_hits=sum(r['cache_hits'] for r in results),
                measured_multihop_four_leg_chains=sum(r['validated_four_leg_multihop_chains'] for r in results),
                status=('PILOT_VERIFICATION_PASS_NOT_FINAL_HCRAF' if not failed else 'FAIL_INCOMPLETE_STAGE1S'),
                Congestion=None,FutureCongestion=None,training_ready=False,
                qualification='Developmental attribution robustness only; no causal path-congestion label.')
    (root/'robustness_summary.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n',encoding='utf8')
    if failed:raise ValueError('Stage1S incomplete: '+json.dumps(failed))
    return report

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('root',type=Path);args=ap.parse_args()
    print(json.dumps(summary(args.root),sort_keys=True))
