#!/usr/bin/env python3
"""Fail-closed Stage 1U NFD instrumentation on the exact *already-patched* 1T/1S NFD.

This adds observable per-invocation DATA_ARRIVE_1U, DATA_MATCH_SET_1U,
DATA_PIT_BIND_1U. The ordinal is router-local, not a physical or cross-hop UID.
The original packet-forwarding logic is not modified.
"""
import hashlib
import json
import sys
from pathlib import Path

EXPECTED = {
    'forwarder.cpp': '5b3b1f03170fad6d243c791b77003908f605fa5bba580e309e7acb8c38f4a8f3',
    'forwarder.hpp': '9aaae69935a99f8948b2e2a408722149be38fbaf2319a374ca3790fa92cf2d34',
}


def instrument(nfd_dir):
    nfd_dir = Path(nfd_dir)
    original = {}
    for name, expected in EXPECTED.items():
        data = (nfd_dir / name).read_bytes()
        actual = hashlib.sha256(data).hexdigest()
        if actual != expected:
            raise ValueError('Stage1U requires verified v0.17 NFD patch; ' + name + ': ' + actual)
        original[name] = data.decode('utf8')
    files = dict(original)

    def replace(name, needle, replacement):
        if files[name].count(needle) != 1:
            raise ValueError('Stage1U NFD anchor mismatch: ' + name + ': ' + repr(needle[:100]))
        files[name] = files[name].replace(needle, replacement, 1)

    replace('forwarder.hpp',
            '  std::function<void(uint64_t)> m_hcrafDecisionObserver;\n',
            '  std::function<void(uint64_t)> m_hcrafDecisionObserver;\n'
            '  // Stage1U only: each onIncomingData invocation gets a new local ordinal.\n'
            '  uint64_t m_hcrafStage1uRxOrdinal = 0;\n')

    # This anchor occurs once in the pinned, already-patched NFD source.
    replace('forwarder.cpp',
            '  ++m_counters.nInData;\n',
            '  ++m_counters.nInData;\n'
            '  uint64_t hcrafStage1uRxOrdinal = 0;\n'
            '  if (m_hcrafRecorder && m_hcrafRecorder->inScope(data.getName().toUri())) {\n'
            '    hcrafStage1uRxOrdinal = ++m_hcrafStage1uRxOrdinal;\n'
            '    m_hcrafRecorder->event("DATA_ARRIVE_1U", nullptr, data.getName().toUri(),\n'
            '      ns3::Simulator::Now().GetNanoSeconds(), ingress.face.getId(), -1, -1,\n'
            '      static_cast<int64_t>(hcrafStage1uRxOrdinal), data.getContent().value_size());\n'
            '  }\n')
    replace('forwarder.cpp',
            '  pit::DataMatchResult pitMatches = m_pit.findAllDataMatches(data);\n',
            '  pit::DataMatchResult pitMatches = m_pit.findAllDataMatches(data);\n'
            '  if (m_hcrafRecorder && hcrafStage1uRxOrdinal != 0)\n'
            '    m_hcrafRecorder->event("DATA_MATCH_SET_1U", nullptr, data.getName().toUri(),\n'
            '      ns3::Simulator::Now().GetNanoSeconds(), ingress.face.getId(), -1,\n'
            '      static_cast<int64_t>(pitMatches.size()), static_cast<int64_t>(hcrafStage1uRxOrdinal));\n')
    replace('forwarder.cpp',
            '    // invoke PIT satisfy callback\n',
            '    if (m_hcrafRecorder && hcrafStage1uRxOrdinal != 0)\n'
            '      m_hcrafRecorder->event("DATA_PIT_BIND_1U", pitEntry.get(), pitEntry->getName().toUri(),\n'
            '        ns3::Simulator::Now().GetNanoSeconds(), ingress.face.getId(), -1, -1,\n'
            '        static_cast<int64_t>(hcrafStage1uRxOrdinal));\n'
            '    // invoke PIT satisfy callback\n')
    for name, contents in files.items():
        (nfd_dir / name).write_text(contents, encoding='utf8')
    return {k: hashlib.sha256((nfd_dir/k).read_bytes()).hexdigest() for k in files}


if __name__ == '__main__':
    if len(sys.argv) != 2:
        raise SystemExit('usage: patch_nfd_stage1u.py path/to/NFD/daemon/fw')
    print(json.dumps(instrument(sys.argv[1]), sort_keys=True, indent=2))
