#!/usr/bin/env python3
"""Fail-closed summary of 1Y controlled runs; no F3 labels are generated."""
import collections,hashlib,json,sys
from pathlib import Path
from verify_stage1y import MODES

def main(root):
    root=Path(root)
    records=[]; diffs={}; missing=[]
    for mode in MODES:
        hashes=[]
        for run in (1001,1002,1003):
            d=root/mode/f'run-{run}'
            f=d/'stage1y_verification.json'
            if not f.exists():
                missing.append(str(f)); continue
            r=json.loads(f.read_text()); records.append(r)
            schedule=d/'consumer_events.jsonl.arrivals.jsonl'
            if schedule.exists() and mode!='idle':
                hashes.append(hashlib.sha256(schedule.read_bytes()).hexdigest())
        if mode!='idle': diffs[mode]=len(set(hashes))
    overhead_pairs=[]
    paired_ok=True
    for mode in ('low-load','mixed-fragmented'):
        for run in (1001,1002,1003):
            observed=root/mode/f'run-{run}'
            bare=root/'uninstrumented'/mode/f'run-{run}'
            if not all((d/'consumer_events.jsonl').exists() for d in (observed,bare)):
                paired_ok=False; continue
            oa=(observed/'consumer_events.jsonl').read_bytes()
            ba=(bare/'consumer_events.jsonl').read_bytes()
            same=(oa==ba)
            paired_ok=paired_ok and same
            def metrics(d):
                result={}
                f=d/'resource_usage.txt'
                if f.exists():
                    for ln in f.read_text().splitlines():
                        k,_,v=ln.partition('=')
                        try: result[k]=float(v)
                        except ValueError: pass
                result['trace_bytes']=sum(x.stat().st_size for x in d.rglob('*') if x.is_file())
                return result
            overhead_pairs.append({'mode':mode,'run':run,'consumer_events_byte_equal':same,
                                   'monitored':metrics(observed),'unmonitored':metrics(bare)})
    all_target=len(records)==30 and all(r['target_event_observed'] for r in records)
    # Distinct realized schedules are required. One RngRun does not establish independence.
    distinct=all(v==3 for v in diffs.values())
    out={'schema':'1Y.0','runs_present':len(records),'runs_expected':30,
      'target_control_matrix_complete':all_target,'distinct_realized_schedules':distinct,
      'paired_uninstrumented_consumer_outcomes_equal':paired_ok,
      'overhead_pairs':overhead_pairs,
      'realized_schedule_hash_distinct_counts':diffs, 'missing_run_reports':missing,
      'scientific_decision':'NO_GO_TO_F3_TRAINING',
      'decision_reason':['Complete positive AND negative whole-path queue labels have not yet been independently certified.',
                         'The paired overhead observations do not establish broad topology-generalization or equivalence for every scenario.',
                         'Do not relabel test episodes or choose thresholds using Test.'],
      'Congestion':None,'FutureCongestion':None,'F3_ready':False,'training_ready':False,
      'per_run':records}
    (root/'stage1y_summary.json').write_text(json.dumps(out,sort_keys=True,ensure_ascii=False,indent=2)+'\n')
    print('1Y PILOT',len(records),'of 30; controls',all_target,'distinct schedules',distinct,'paired outcomes',paired_ok,
          'research gate',out['scientific_decision'])
    if not (all_target and distinct and paired_ok): raise SystemExit(2)

if __name__=='__main__':main(sys.argv[1])
