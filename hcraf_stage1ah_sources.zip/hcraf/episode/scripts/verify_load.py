#!/usr/bin/env python3
"""Evidence-based acceptance for controlled load, not a congestion-label definition."""
import json
from pathlib import Path
import sys
from collections import Counter
from episodes import load, reconstruct, require
from verify_decisions import verify as verify_decisions


def link_busy_intervals(links, start_ns, end_ns):
    require(end_ns > start_ns, 'invalid observation window')
    active, busy, packets = {}, {}, {}
    for x in links:
        key=(x['node_id'],x['face_id'])
        busy.setdefault(key,0); packets.setdefault(key,0)
        if x['event_type']=='PHY_TX_BEGIN':
            require(key not in active, 'overlapping transmissions on one direction')
            require(type(x['packet_uid']) is int and x['packet_bytes']>0, 'missing PHY packet identity')
            active[key]=x
        elif x['event_type']=='PHY_TX_END':
            require(key in active, 'PHY end without start')
            first=active.pop(key)
            require(first['packet_uid']==x['packet_uid'], 'PHY packet mismatch')
            require(first['packet_bytes']==x['packet_bytes'], 'PHY size mismatch')
            require(x['time_ns']>first['time_ns'], 'nonpositive transmission duration')
            # Point-to-point PhyTxEnd occurs after serialization + configured IFG.
            # This experiment retains the official zero IFG; inspect both begin/end evidence.
            busy[key]+=max(0,min(end_ns,x['time_ns'])-max(start_ns,first['time_ns']))
            packets[key]+=1
    require(not active, 'transmission still open at observation end')
    require(all(0<=n<=end_ns-start_ns for n in busy.values()), 'invalid occupied fraction')
    return [dict(node_id=k[0],face_id=k[1],busy_ns=n,
                 observed_busy_fraction=n/(end_ns-start_ns),completed_phy_transmissions=packets[k])
            for k,n in sorted(busy.items())]


def check_load_evidence(mode, candidate_rows, episodes, links, consumer_sends, consumer_data):
    outcomes=Counter(e['outcome'] for e in episodes)
    require(None not in outcomes, 'unclosed/censored episode: investigate, do not relabel')
    require(set(outcomes)<= {'SUCCESS','NACK','TIMEOUT','CANCELLED'}, 'invalid outcome')
    local_faces={(r['node_id'],r['face_id']) for r in candidate_rows}
    local_drop=sum(x['event_type']=='QUEUE_DROP' and (x['node_id'],x['face_id']) in local_faces for x in links)
    local_q=max((r['local_queue_packets'] for r in candidate_rows),default=0)
    total_drop=sum(x['event_type']=='QUEUE_DROP' for x in links)
    require(all(x['queue_packets']==0 for x in links if x['event_type']=='FINAL'), 'queues not drained')
    if mode=='load-low':
        require(outcomes['SUCCESS']==len(consumer_sends)==len(consumer_data), 'low-load control not fully successful')
        require(total_drop==0, 'unexpected low-load queue drops')
    elif mode=='load-high':
        require(local_drop>0, 'no measured drop on router candidate Face')
        require(local_q>0, 'no nonempty candidate queue at decision time')
        require(outcomes['SUCCESS']>0 and outcomes['TIMEOUT']>0, 'high-load success/timeout evidence missing')
    else: raise ValueError('unsupported load mode')
    return dict(outcomes=dict(outcomes),local_candidate_queue_drop_events=local_drop,
                max_local_candidate_queue_packets_at_decision=local_q,total_queue_drop_events=total_drop)


def verify(folder):
    cfg=json.loads((folder/'scenario.json').read_text())
    mode=cfg['mode']; require(mode in ('load-low','load-high'),'not a load scenario')
    expected_rate,expected_n=(5,20) if mode=='load-low' else (600,2400)
    for k,v in dict(instrumentation_stage='1C.1',request_rate_per_s=expected_rate,planned_requests=expected_n,
                    stop_ns=9000000000,traffic_start_ns=1000000000,traffic_stop_exclusive_ns=5000000000,
                    bottleneck_rate_bps=128000,link_rate_bps=10000000,queue_capacity_packets=20,
                    interest_lifetime_ms=1000,payload_bytes=1024,cs_packets=0,consumer_retransmissions=False).items():
        require(cfg.get(k)==v,'configuration mismatch: '+k)
    events=load(folder/'events.jsonl'); ep=load(folder/'episodes.jsonl')
    links=load(folder/'link_events.jsonl'); consumer=load(folder/'consumer_events.jsonl')
    require(ep and reconstruct(events,ep[0]['run_id'])==ep,'episode reconstruction mismatch')
    require(events[-1]['time_ns']==cfg['stop_ns'],'wrong observation end')
    rows,decision_report=verify_decisions(folder,load_profile=True)
    require(all(0<=x['queue_packets']<=cfg['queue_capacity_packets'] for x in links),'queue capacity exceeded')
    require(all(x['event'] in {'SEND','DATA','NACK'} for x in consumer),'unknown consumer event')
    require(all(0<=x['time_ns']<=cfg['stop_ns'] for x in consumer),'consumer outside run')
    require(all(a['time_ns']<=b['time_ns'] for a,b in zip(consumer,consumer[1:])),'consumer time order')
    sends=[x for x in consumer if x['event']=='SEND']; data=[x for x in consumer if x['event']=='DATA']
    require(len(sends)==expected_n,'incorrect offered request count')
    names=['/hcraf/pilot/'+str(i) for i in range(expected_n)]
    require([x['name'] for x in sends]==names,'request names/order mismatch')
    require([x['time_ns'] for x in sends]==[1000000000+i*1000000000//expected_rate for i in range(expected_n)],'offered timing mismatch')
    require(len(ep)==expected_n and {e['name'] for e in ep}==set(names),'missing/duplicate router episodes')
    require(all(e['tx_count']==1 for e in ep),'unexpected retransmission')
    require(all(e['outcome'] in {'SUCCESS','TIMEOUT','NACK'} for e in ep),'unexpected cancellation or censoring')
    require(len(data)==len({x['name'] for x in data}),'duplicate consumer Data')
    send_map={x['name']:x for x in sends}; epmap={x['name']:x for x in ep}
    for x in data:
        require(x['name'] in send_map and x['payload_bytes']==1024,'unmatched or wrong Data')
        require(x['time_ns']>send_map[x['name']]['time_ns'],'nonpositive consumer delay')
        require(epmap[x['name']]['outcome']=='SUCCESS','consumer Data without router success')
    # Router and consumer PIT deadlines differ by propagation time. A Data may
    # satisfy the router yet arrive after consumer PIT expiry. Preserve this gap.
    router_success_names={e['name'] for e in ep if e['outcome']=='SUCCESS'}
    delivered_names={x['name'] for x in data}
    require(delivered_names <= router_success_names, 'consumer success lacks router success')
    for x in consumer:
        if x['event']=='NACK': require(epmap.get(x['name'],{}).get('outcome')=='NACK','unmatched consumer NACK')
    for e in ep:
        if e['outcome']=='SUCCESS': require(e['delay_valid'] and e['delay_ns']>0,'invalid successful RTT')
        else: require(e['delay_ns'] is None,'failure carries invented RTT')
    evidence=check_load_evidence(mode,rows,ep,links,sends,data)
    busy=link_busy_intervals(links,cfg['traffic_start_ns'],cfg['traffic_stop_exclusive_ns'])
    active_data=[x for x in data if cfg['traffic_start_ns']<x['time_ns']<=cfg['traffic_stop_exclusive_ns']]
    report=dict(status='PASS',stage='1C.1',purpose='CONTROLLED_LOAD_INSTRUMENTATION_NOT_TRAINING',
       research_training_eligible=False,mode=mode,offered_requests=len(sends),consumer_delivered=len(data),
       consumer_delivery_fraction=len(data)/len(sends),
       router_success_without_consumer_data=len(router_success_names-delivered_names),episodes=len(ep),decisions=decision_report['decisions'],
       candidate_rows=len(rows),mean_consumer_delay_ns=(sum(x['time_ns']-send_map[x['name']]['time_ns'] for x in data)/len(data) if data else None),
       consumer_goodput_active_window_bps=8*sum(x['payload_bytes'] for x in active_data)/4,
       consumer_goodput_full_observation_bps=8*sum(x['payload_bytes'] for x in data)/8,
       active_window_ns=[1000000000,5000000000],full_observation_window_ns=[1000000000,9000000000],
       link_busy_active_window=busy,**evidence)
    return rows,report

if __name__=='__main__':
    folder=Path(sys.argv[1])
    try:
        rows,report=verify(folder)
        (folder/'decision_faces.jsonl').write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in rows))
    except Exception as e:
        report=dict(status='FAIL',stage='1C.1',error=str(e))
    (folder/'load_verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
    sys.exit(0 if report['status']=='PASS' else 1)
