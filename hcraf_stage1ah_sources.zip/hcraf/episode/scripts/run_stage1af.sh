#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
TOPOLOGY="${1:?DEV_CHAIN_A or DEV_CHAIN_B required}"
case "$TOPOLOGY" in DEV_CHAIN_A|DEV_CHAIN_B) ;; *) echo 'Unregistered development topology' >&2;exit 2;; esac
OUT="$ROOT/episode_output/stage1af/$TOPOLOGY"
mkdir -p "$OUT"
cd "$ROOT/episode_sources/ns-3"
failed=0
modes=(LOW_LOAD BUFFER_NO_DROP OVERFLOW_DROP LP_CLEAN LP_PRESSURE)
params() {
  case "$1" in
    LOW_LOAD) echo '--requestCount=12 --intervalNs=150000000' ;;
    BUFFER_NO_DROP) echo '--requestCount=16 --intervalNs=1000000' ;;
    OVERFLOW_DROP) echo '--requestCount=70 --intervalNs=1000000' ;;
    LP_CLEAN) echo '--requestCount=12 --intervalNs=250000000' ;;
    LP_PRESSURE) echo '--requestCount=24 --intervalNs=2000000' ;;
    *) return 2;;
  esac
}
for slot in 0 1 2; do
  for mode in "${modes[@]}"; do
    for run in 8101 8102 8103; do
      dest="$OUT/monitored/slot-${slot}/${mode}/run-${run}"
      mkdir -p "$dest"
      command="hcraf-stage1af-pilot --mode=$mode --topology=$TOPOLOGY --selectedSlot=$slot --output=$dest --seed=17 --run=$run --instrument=1 --lifetimeMs=2600 $(params "$mode")"
      printf '%s\n' "$command" > "$dest/command.txt"
      if ! /usr/bin/time -f 'wall_seconds=%e\nuser_seconds=%U\nsystem_seconds=%S\nmax_rss_kib=%M' -o "$dest/resource_usage.txt" \
        python3 ./waf --run-no-build "$command" > "$dest/simulator.log" 2>&1; then
        echo "SIM_FAIL topology=$TOPOLOGY slot=$slot mode=$mode run=$run"; failed=1;continue
      fi
      if ! python3 "$TASK/scripts/episodes_stage1u.py" "$dest" --run-id "1af-$TOPOLOGY-$slot-$mode-17-$run" > "$dest/episodes.log" 2>&1; then
        echo "EPISODE_FAIL topology=$TOPOLOGY slot=$slot mode=$mode run=$run";failed=1;continue
      fi
      if ! python3 "$TASK/scripts/verify_stage1af.py" "$dest" --fail-on-incomplete > "$dest/verify.log" 2>&1; then
        echo "TARGET_INCOMPLETE topology=$TOPOLOGY slot=$slot mode=$mode run=$run";failed=1
      fi
    done
  done
done
# Exactly 6 paired per topology: slot zero, two regimes, all 3 RNG runs.
# BestRoute is naturally slot zero (lowest FIB cost), unlike forced monitored
# assignment, so only these pairs permit honest instrument/no-instrument matches.
for mode in LOW_LOAD LP_CLEAN; do
  for run in 8101 8102 8103; do
    dest="$OUT/uninstrumented/slot-0/$mode/run-$run";mkdir -p "$dest"
    command="hcraf-stage1af-pilot --mode=$mode --topology=$TOPOLOGY --selectedSlot=0 --output=$dest --seed=17 --run=$run --instrument=0 --lifetimeMs=2600 $(params "$mode")"
    printf '%s\n' "$command" > "$dest/command.txt"
    if ! /usr/bin/time -f 'wall_seconds=%e\nuser_seconds=%U\nsystem_seconds=%S\nmax_rss_kib=%M' -o "$dest/resource_usage.txt" \
      python3 ./waf --run-no-build "$command" > "$dest/simulator.log" 2>&1; then
      echo "PAIR_SIM_FAIL topology=$TOPOLOGY mode=$mode run=$run";failed=1
    fi
  done
done
if ! python3 "$TASK/scripts/summarize_stage1af.py" "$OUT" "$TOPOLOGY";then failed=1;fi
exit "$failed"
