#!/usr/bin/env python3
"""Stage 1S: verify trace completeness, provenance, queue waits, and visibility.
Development evidence only. NEVER emits final Congestion / FutureCongestion.
Works with Python 3.8+. No third-party dependency.
"""
import argparse
from collections import Counter, defaultdict, deque
import json
from pathlib import Path

MODES = ('baseline', 'forward-buffered', 'return-buffered', 'forward-overflow', 'return-overflow')
TYPES = {'INITIAL', 'DECISION_SNAPSHOT', 'FINAL', 'PHY_TX_BEGIN', 'PHY_TX_END',
         'PHY_RX_DROP', 'QUEUE_DROP', 'QUEUE_ENQUEUE', 'QUEUE_DEQUEUE'}

def require(ok, message):
    if not ok:
        raise ValueError(message)

def read_jsonl(path):
    with path.open(encoding='utf8') as f:
        return [json.loads(s) for s in f if s.strip()]

def verify_trace(events, expected_capacity=20, expected_directions=8):
    require(events, 'empty link events')
    observed = set()
    queues = defaultdict(deque)
    previous_time = -1
    by_device = defaultdict(lambda: Counter())
    queue_positive = Counter()
    waiting_positive = Counter()
    sum_wait_ns = Counter()
    max_wait_ns = Counter()
    snapshot = defaultdict(list)
    last_drop = defaultdict(int)
    last_tx = defaultdict(int)
    missing_waits = Counter()
    for n, ev in enumerate(events, 1):
        require(ev.get('schema_version') == '1P.1', 'wrong schema at event '+str(n))
        require(ev.get('link_event_seq') == n, 'link event seq discontinuity')
        t = ev.get('time_ns')
        require(type(t) is int and t >= previous_time, 'non-monotonic time')
        previous_time = t
        et = ev.get('event_type')
        require(et in TYPES, 'unsupported link event '+str(et))
        key = (ev['node_id'], ev['device_index'])
        require(type(key[0]) is int and type(key[1]) is int, 'invalid device ID')
        observed.add(key)
        require(type(ev['queue_packets']) is int and 0 <= ev['queue_packets'] <= expected_capacity,
                'queue capacity exceeded')
        require(abs(ev['LocalQueueOccupancyFraction'] - ev['queue_packets']/expected_capacity) < 1e-8,
                'queue fraction mismatch')
        require(ev['queue_drop_packets_total'] == last_drop[key] + (et == 'QUEUE_DROP'), 'queue-drop counter delta mismatch')
        require(ev['phy_tx_started_bytes_total'] == last_tx[key] + (ev['packet_bytes'] if et == 'PHY_TX_BEGIN' else 0), 'TX byte counter delta mismatch')
        last_drop[key] = ev['queue_drop_packets_total']
        last_tx[key] = ev['phy_tx_started_bytes_total']
        by_device[key][et] += 1
        if ev['queue_packets'] > 0:
            queue_positive[key] += 1
        if et == 'DECISION_SNAPSHOT':
            require(type(ev['decision_id']) is int and ev['decision_id'] > 0, 'invalid decision_id')
            snapshot[ev['decision_id']].append((key, t, n))
        elif et == 'QUEUE_ENQUEUE':
            require(type(ev['packet_uid']) is int, 'missing enqueue UID')
            require(ev.get('queue_wait_ns') is None, 'unexpected enqueue wait')
            queues[(key, ev['packet_uid'])].append(t)
        elif et == 'QUEUE_DEQUEUE':
            require(type(ev['packet_uid']) is int, 'missing dequeue UID')
            qkey = (key, ev['packet_uid'])
            if queues[qkey]:
                wait = t - queues[qkey].popleft()
                require(ev['queue_wait_ns'] == wait, 'measured dequeue wait differs from trace')
                if wait > 0: waiting_positive[key] += 1
                sum_wait_ns[key] += wait
                max_wait_ns[key] = max(max_wait_ns[key], wait)
            else:
                require(ev.get('queue_wait_ns') is None, 'matched wait without an enqueue')
                missing_waits[key] += 1
    for key in observed:
        require(by_device[key]['INITIAL'] == 1 and by_device[key]['FINAL'] == 1,
                'missing initial/final snapshot '+str(key))
        require(by_device[key]['QUEUE_DROP'] == last_drop[key], 'queue-drop counter mismatch')
    require(len(observed) == expected_directions, 'wrong monitored directions, got '+str(len(observed)))
    require(not sum(missing_waits.values()), 'dequeue without matching enqueue')
    for decision, samples in snapshot.items():
        require(len(samples) == len(observed), 'incomplete decision snapshot '+str(decision))
        require({x[0] for x in samples} == observed, 'missing snapshot directions')
        require(len({x[1] for x in samples}) == 1, 'snapshot time disagreement')
    summary = {}
    for key in sorted(observed):
        counts = by_device[key]
        summary['%d:%d' % key] = dict(node_id=key[0], device_index=key[1],
            enqueue=counts['QUEUE_ENQUEUE'], dequeue=counts['QUEUE_DEQUEUE'],
            pending_at_stop=sum(len(v) for k,v in queues.items() if k[0] == key),
            queue_drop=counts['QUEUE_DROP'], phy_rx_drop=counts['PHY_RX_DROP'],
            queue_positive_events=queue_positive[key], positive_wait_packets=waiting_positive[key],
            total_observed_wait_ns=sum_wait_ns[key], max_observed_wait_ns=max_wait_ns[key],
            diagnostic_queueing_without_drop=(waiting_positive[key] > 0 and counts['QUEUE_DROP'] == 0))
    return dict(observed_directions=len(observed), decisions_with_complete_snapshots=len(snapshot),
                directions=summary)

def verify(folder):
    folder = Path(folder)
    cfg = json.loads((folder/'scenario.json').read_text(encoding='utf8'))
    require(cfg['collector_stage'] == '1P.1' and cfg['mode'] in MODES, 'wrong scenario stage/mode')
    require(cfg['training_ready'] is False and cfg['final_congestion_label'] is None and
            cfg['future_congestion_label'] is None, 'must not be labeled for training')
    rows = read_jsonl(folder/'link_events.jsonl')
    result = verify_trace(rows, cfg['queue_capacity_packets'])
    directions = result['directions']
    router_direction = [d for d in directions.values()
                        if d['node_id'] == 1 and any(x['node_id'] == 1 and
                           x['face_id'] == cfg['primary_face_id'] and
                           x['device_index'] == d['device_index'] for x in rows if x['event_type'] == 'INITIAL')]
    return_direction = [d for d in directions.values() if d['node_id'] == 2]
    require(len(router_direction) == len(return_direction) == 1, 'primary direction mapping absent')
    selections = read_jsonl(folder/'events.jsonl.collection.jsonl')
    decisions = read_jsonl(folder/'events.jsonl.decisions.jsonl')
    episodes = read_jsonl(folder/'episodes.jsonl')
    sends = [x for x in read_jsonl(folder/'consumer_events.jsonl') if x['event'] == 'SEND']
    arrivals = read_jsonl(folder/'consumer_events.jsonl.arrivals.jsonl')
    n = cfg['planned_requests']
    require(len(sends) == len(arrivals) == n, 'offered load does not match scenario')
    require(len(decisions) == len(selections) == len(episodes) == n,
            'one decision/episode/selection per Interest violated')
    require(result['decisions_with_complete_snapshots'] == n, 'missing decision snapshot')
    decision_ids = {d['decision_id'] for d in decisions}
    require({s['decision_id'] for s in selections} == decision_ids, 'selection/decision mismatch')
    for d in decisions:
        require(d['anchor'] == 'BEFORE_AFTER_RECEIVE_INTEREST', 'incorrect decision anchor')
    times = {d['decision_id']:d['time_ns'] for d in decisions}
    for s in selections:
        require(s['policy'] == 'uniform', 'expected passive uniform sampling')
        require(s['time_ns'] == times[s['decision_id']], 'selection timing mismatch')
        require(len(s['candidates']) == 3, 'three candidates required')
        require(abs(sum(x['probability'] for x in s['candidates']) - 1.0) < 1e-12,
                'invalid probabilities')
        require(all(abs(x['probability']-1.0/3.0)<1e-12 for x in s['candidates']),
                'not uniform selection')
        require(s['selected_face_id'] in {x['face_id'] for x in s['candidates']},
                'chosen face is ineligible')
    for e in episodes:
        require(e['outcome'] in ('SUCCESS','NACK','TIMEOUT','CANCELLED',None), 'invalid outcome')
    target = 'router_forward' if cfg['mode'].startswith('forward-') else 'producer_return'
    return dict(status='PASS_OBSERVABILITY_NOT_CONGESTION_VALIDATION', mode=cfg['mode'],
                run=cfg['run'], offered_interests=n, reconstructed_episodes=len(episodes),
                observed_outcomes=dict(Counter(str(e['outcome']) for e in episodes)),
                target_direction=target,
                forward_router=router_direction[0], reverse_producer=return_direction[0],
                monitor=result, training_ready=False, final_congestion_label=None,
                future_congestion_label=None,
                interpretation='Observed queue wait/drop is adjacent directional telemetry, not final path congestion.')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('folder', type=Path)
    args = parser.parse_args()
    try:
        summary = verify(args.folder)
        (args.folder/'visibility_verification.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
        print(json.dumps(dict(status=summary['status'],mode=summary['mode'],run=summary['run'],
            forward=summary['forward_router'],reverse=summary['reverse_producer'])))
    except Exception as error:
        (args.folder/'visibility_verification.json').write_text(json.dumps(dict(status='FAIL',error=str(error)),indent=2)+'\n')
        raise
if __name__=='__main__':
    main()
