#!/usr/bin/env python3
"""Independent structural checks and predeclared expectations for pilot only."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
from episodes import load, require

EXPECTED = {
 'success': {'SUCCESS': 3}, 'nack': {'NACK': 3}, 'timeout': {'TIMEOUT': 3},
 'cancel': {'SUCCESS': 3, 'CANCELLED': 3}, 'retransmit': {'SUCCESS': 3},
 'open': {'OPEN': 1},
}

def verify(folder):
    config = json.loads((folder/'scenario.json').read_text())
    mode = config['mode']
    events, rows, consumer = (load(folder/name) for name in
                              ('events.jsonl', 'episodes.jsonl', 'consumer_events.jsonl'))
    counts = Counter(row['outcome'] or 'OPEN' for row in rows)
    require(dict(counts) == EXPECTED[mode], 'unexpected outcomes: '+str(dict(counts)))
    require(events[-1]['event_type'] == 'SIMULATION_END' and
            events[-1]['time_ns'] == config['stop_ns'], 'incomplete simulation')
    by_seq = {e['event_seq']: e for e in events}
    tx_ids, identities = [], set()
    intervals = {}
    success_names = set()
    for row in rows:
        ident = (row['run_id'], row['node_id'], row['episode_id'])
        require(ident not in identities, 'duplicate episode identity')
        identities.add(ident)
        tx = row['tx_event_seqs']
        require(len(tx) == row['tx_count'] and tx, 'invalid TX count')
        tx_ids.extend(tx)
        times = []
        for index, seq in enumerate(tx):
            event = by_seq[seq]
            require(event['event_type'] == 'TX_INTEREST' and
                    str(event['pit_instance_id']) == row['pit_instance_id'] and
                    event['face_id'] == row['face_id'] and event['name'] == row['name'] and
                    event['nonce'] == row['tx_nonces'][index], 'TX/episode mismatch')
            times.append(event['time_ns'])
        require(times == row['tx_times_ns'] and times == sorted(times), 'TX timeline mismatch')
        require(row['start_ns'] == times[0], 'start must equal first TX')
        require(row['deadline_ns'] == by_seq[tx[-1]]['deadline_ns'], 'deadline mismatch')
        outcome, end = row['outcome'], row['end_ns']
        terminal = by_seq[row['terminal_event_seq']]
        if outcome is None:
            require(end is None and row['censor_reason'] == 'SIMULATION_END', 'unexpected censoring in pilot')
            require(row['observed_until_ns'] < row['deadline_ns'], 'expired episode left open')
        else:
            require(times[-1] <= end <= row['deadline_ns'], 'invalid terminal time')
            require(row['censor_reason'] is None, 'closed episode censored')
            if outcome in ('SUCCESS', 'CANCELLED'):
                require(terminal['event_type'] == 'PIT_SATISFIED' and terminal['time_ns'] == end
                        and str(terminal['pit_instance_id']) == row['pit_instance_id'],
                        'Data termination without PIT satisfaction')
                require((terminal['face_id'] == row['face_id']) == (outcome == 'SUCCESS'), 'wrong winner')
            elif outcome == 'NACK':
                require(terminal['event_type'] == 'NACK_ACCEPTED' and terminal['time_ns'] == end
                        and terminal['face_id'] == row['face_id']
                        and str(terminal['pit_instance_id']) == row['pit_instance_id']
                        and terminal['nonce'] == row['tx_nonces'][-1], 'NACK evidence missing')
            elif outcome == 'TIMEOUT':
                require(end == row['deadline_ns'] and terminal['time_ns'] >= end, 'premature TIMEOUT')
        require(row['delay_valid'] == (outcome == 'SUCCESS' and row['tx_count'] == 1),
                'delay validity policy mismatch')
        if row['delay_valid']:
            require(outcome == 'SUCCESS' and row['tx_count'] == 1 and
                    row['delay_ns'] == end-row['start_ns'], 'ambiguous delay')
        else: require(row['delay_ns'] is None, 'invalid delay must be null')
        if outcome == 'SUCCESS': success_names.add(row['name'])
        key = (row['pit_instance_id'], row['face_id'])
        intervals.setdefault(key, []).append((row['start_ns'], end))
    require(len(tx_ids) == len(set(tx_ids)), 'TX assigned twice')
    require(set(tx_ids) == {e['event_seq'] for e in events if e['event_type'] == 'TX_INTEREST'},
            'missing TX assignment')
    for values in intervals.values():
        values.sort(key=lambda x:x[0])
        for previous, current in zip(values, values[1:]):
            require(previous[1] is not None and previous[1] <= current[0], 'active episode overlap')
    consumer_data = {e['name'] for e in consumer if e['event'] == 'DATA'}
    require(consumer_data == success_names, 'consumer/forwarder satisfaction mismatch')
    sends = [e for e in consumer if e['event'] == 'SEND']
    require(len(sends) == (1 if mode == 'open' else 6 if mode == 'retransmit' else 3), 'consumer send mismatch')
    if mode == 'nack': require(sum(e['event']=='NACK' for e in consumer)==3, 'consumer NACK mismatch')
    if mode == 'retransmit':
        require(all(r['tx_count']==2 and not r['delay_valid'] for r in rows), 'retx test did not exercise ambiguity')
    hashes = {name: hashlib.sha256((folder/name).read_bytes()).hexdigest() for name in
              ('events.jsonl', 'episodes.jsonl', 'consumer_events.jsonl', 'scenario.json')}
    return dict(status='PASS', scope='CONTROLLED_INSTRUMENTATION_PILOT', mode=mode,
                episodes=len(rows), counts=dict(counts), sha256=hashes)

if __name__ == '__main__':
    p=argparse.ArgumentParser(); p.add_argument('folder',type=Path); args=p.parse_args()
    try:
        report=verify(args.folder)
    except (ValueError,KeyError,TypeError,OSError) as error:
        report=dict(status='FAIL',error=str(error))
    (args.folder/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
    raise SystemExit(0 if report['status']=='PASS' else 1)
