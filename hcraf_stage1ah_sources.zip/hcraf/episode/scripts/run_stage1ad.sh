#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
OUT="$ROOT/episode_output/stage1ad"
mkdir -p "$OUT"
cd "$ROOT/episode_sources/ns-3"
# Targeted DEVELOPMENT ONLY. Do not run held-out 1AA Test-ID/OOD topologies.
modes=(low-load long-lifetime forward-buffered return-buffered forward-overflow return-overflow mixed-fragmented)
paired=(low-load long-lifetime mixed-fragmented)
failed=0
params() {
  case "$1" in
    low-load) echo '--requestCount=16 --intervalNs=100000000 --lifetimeMs=2600 --producerDelayMs=0' ;;
    long-lifetime) echo '--requestCount=16 --intervalNs=200000000 --lifetimeMs=2600 --producerDelayMs=1400' ;;
    forward-buffered) echo '--requestCount=18 --intervalNs=1000000 --lifetimeMs=2600 --forwardBps=32000' ;;
    return-buffered) echo '--requestCount=18 --intervalNs=1000000 --lifetimeMs=2600 --returnBps=64000' ;;
    forward-overflow) echo '--requestCount=80 --intervalNs=1000000 --lifetimeMs=2600 --forwardBps=8000' ;;
    return-overflow) echo '--requestCount=80 --intervalNs=1000000 --lifetimeMs=2600 --returnBps=16000' ;;
    mixed-fragmented) echo '--requestCount=24 --intervalNs=250000000 --lifetimeMs=2600 --returnBps=256000' ;;
    *) return 2 ;;
  esac
}
for mode in "${modes[@]}"; do
  for run in 7101 7102 7103; do
    dest="$OUT/monitored/$mode/run-$run";mkdir -p "$dest"
    command="hcraf-stage1ad-pilot --mode=$mode --output=$dest --seed=17 --run=$run --instrument=1 $(params "$mode")"
    printf '%s\n' "$command" > "$dest/command.txt"
    if ! /usr/bin/time -f 'wall_seconds=%e\nuser_seconds=%U\nsystem_seconds=%S\nmax_rss_kib=%M' -o "$dest/resource_usage.txt" \
      python3 ./waf --run-no-build "$command" > "$dest/simulator.log" 2>&1; then
      echo "STAGE1AD_SIM_FAIL mode=$mode run=$run";failed=1;continue
    fi
    if ! python3 "$TASK/scripts/episodes_stage1u.py" "$dest" --run-id "1ad-$mode-17-$run" > "$dest/episodes.log" 2>&1; then
      echo "STAGE1AD_EPISODE_FAIL mode=$mode run=$run";failed=1;continue
    fi
    if ! python3 "$TASK/scripts/verify_stage1ad.py" "$dest" --fail-on-incomplete > "$dest/verify.log" 2>&1; then
      echo "STAGE1AD_TARGET_INCOMPLETE mode=$mode run=$run";failed=1
    fi
  done
done
for mode in "${paired[@]}"; do
  for run in 7101 7102 7103; do
    dest="$OUT/uninstrumented/$mode/run-$run";mkdir -p "$dest"
    command="hcraf-stage1ad-pilot --mode=$mode --output=$dest --seed=17 --run=$run --instrument=0 $(params "$mode")"
    printf '%s\n' "$command" > "$dest/command.txt"
    if ! /usr/bin/time -f 'wall_seconds=%e\nuser_seconds=%U\nsystem_seconds=%S\nmax_rss_kib=%M' -o "$dest/resource_usage.txt" \
      python3 ./waf --run-no-build "$command" > "$dest/simulator.log" 2>&1; then
      echo "STAGE1AD_PAIRED_FAIL mode=$mode run=$run";failed=1
    fi
  done
done
if ! python3 "$TASK/scripts/summarize_stage1ad.py" "$OUT"; then failed=1;fi
exit "$failed"
