#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK_DIR="$PROJECT_DIR/hcraf/episode"
SOURCE_DIR="$PROJECT_DIR/episode_sources/ns-3"
# Reuse exact pinned sources and unchanged NFD patch from verified Stage 1R.
bash "$TASK_DIR/scripts/build_stage1r.sh"
cp "$TASK_DIR/src/hcraf-robustness-pilot.cpp" "$SOURCE_DIR/scratch/hcraf-robustness-pilot.cc"
cd "$SOURCE_DIR"
python3 ./waf -j 2
test -x build/scratch/hcraf-robustness-pilot
