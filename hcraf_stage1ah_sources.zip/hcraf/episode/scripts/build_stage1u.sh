#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK_DIR="$PROJECT_DIR/hcraf/episode"
SOURCE_DIR="$PROJECT_DIR/episode_sources/ns-3"
# Preserve the exact source revisions, original NFD instrumentation and previous pilots.
bash "$TASK_DIR/scripts/build_stage1s.sh"
python3 "$TASK_DIR/scripts/patch_nfd_stage1u.py" \
  "$SOURCE_DIR/src/ndnSIM/NFD/daemon/fw" > "$PROJECT_DIR/episode_output/patched_stage1u_source_hashes.json"
git -C "$SOURCE_DIR/src/ndnSIM/NFD" diff -- daemon/fw/forwarder.cpp daemon/fw/forwarder.hpp \
  > "$PROJECT_DIR/episode_output/nfd_stage1u_instrumentation.patch"
cp "$TASK_DIR/src/hcraf-stage1u-pilot.cpp" "$SOURCE_DIR/scratch/hcraf-stage1u-pilot.cc"
cd "$SOURCE_DIR"
python3 ./waf -j 2
test -x build/scratch/hcraf-stage1u-pilot
