#!/usr/bin/env python3
"""Stage1W fail-closed evidence verifier; no synthetic research outcomes.

- Match exact NFD Data ingress to observed single-packet MAC_RX or *complete*
  NDN-LP fragmented MAC_RX reassembly on the same node/Face.
- Never match physical UIDs between hops, or infer PIT by NDN name alone.
- Keep NDNLP reassembly visibility distinct from NFD explicit PIT binding.
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path

MODES = ('same-time-dual-face', 'fragmented', 'multi-hop-fragmented')


def need(ok, why):
    if not ok:
        raise ValueError(why)


def load(path):
    need(path.is_file(), 'Missing evidence file: ' + str(path))
    try:
        return [json.loads(line) for line in path.read_text(encoding='utf8').splitlines() if line.strip()]
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError('Invalid JSONL ' + str(path) + ': ' + str(exc)) from exc


def varnum(buf, pos):
    need(pos < len(buf), 'Incomplete TLV type/length')
    v = buf[pos]
    pos += 1
    if v < 253:
        return v, pos
    n = {253: 2, 254: 4, 255: 8}[v]
    need(pos+n <= len(buf), 'Incomplete wide TLV field')
    value = int.from_bytes(buf[pos:pos+n], 'big')
    need(value >= 253 and (n != 4 or value > 65535) and (n != 8 or value > 4294967295),
         'Non-canonical TLV varnum')
    return value, pos+n


def parse_data(data):
    """Read the *complete* NDN-TLV Data name, no NDN-LP headers."""
    kind, off = varnum(data, 0)
    length, off = varnum(data, off)
    need(kind == 6 and off+length == len(data), 'Reassembly is not a whole NDN Data packet')
    end = off+length
    names = []
    while off < end:
        field, p = varnum(data, off)
        size, p = varnum(data, p)
        need(p+size <= end, 'NDN Data field crosses boundary')
        if field == 7:
            need(not names, 'Duplicate NDN Data name')
            components=[]
            start=p
            while p < start+size:
                c, p = varnum(data, p)
                n, p = varnum(data, p)
                need(c == 8 and p+n <= start+size, 'Unsupported or invalid NDN name component')
                item=data[p:p+n]
                components.append(''.join(chr(x) if (48<=x<=57 or 65<=x<=90 or 97<=x<=122 or x in (45,46,95,126)) else '%%%02X'%x for x in item))
                p += n
            need(components and p == start+size,'Invalid NDN name')
            names.append('/'+'/'.join(components))
        off = p+size if field != 7 else start+size
    need(len(names)==1 and names[0].startswith('/hcraf/pilot/'), 'No unique pilot Data name in reassembly')
    return names[0]


def fragmented_groups(links):
    """Group local LP fragments by node, Face, starting Sequence; reject incomplete groups."""
    groups = defaultdict(list)
    for ev in links:
        if ev.get('event_type')!='MAC_RX' or ev.get('lp_status')!='FRAGMENT':
            continue
        need(ev.get('wire_status')!='PILOT', 'Fragment was incorrectly decoded as a full NDN pilot packet')
        k=(ev['node_id'], ev['face_id'], ev['lp_group_start_seq'])
        groups[k].append(ev)
    results=[]
    for (node,face,first), items in sorted(groups.items()):
        counts={r['lp_frag_count'] for r in items}
        need(len(counts)==1, 'Inconsistent LP FragCount on the same group')
        n=next(iter(counts))
        indices=[r['lp_frag_index'] for r in items]
        need(type(first) is int and 0<=first<2**64, 'Invalid 64-bit LP group-start sequence')
        need(type(n) is int and n>1 and len(items)==n and sorted(indices)==list(range(n)),
             'Incomplete/duplicate LP fragment group')
        ordered=sorted(items, key=lambda x:x['lp_frag_index'])
        for r in ordered:
            seq=r['lp_seq']
            need(type(seq) is int and 0<=seq<2**64, 'Invalid 64-bit LP sequence')
            # NDN-LP Sequence wraps at UINT64_MAX. Never reject rollover as missing evidence.
            need(seq==(first+r['lp_frag_index']) % (2**64), 'Inconsistent LP sequence-index pair')
            need(isinstance(r.get('lp_fragment_hex'),str), 'Missing fragment bytes at MAC_RX')
        try:payload=b''.join(bytes.fromhex(r['lp_fragment_hex']) for r in ordered)
        except ValueError as e:raise ValueError('Invalid fragment hex') from e
        name=parse_data(payload)
        results.append(dict(node_id=node,face_id=face,group_start_seq=first,
                            name=name,earliest_time_ns=min(r['time_ns'] for r in ordered),
                            completion_time_ns=max(r['time_ns'] for r in ordered),
                            n_frags=n,payload_sha256=hashlib.sha256(payload).hexdigest(),
                            physical_packet_uids=[r['packet_uid'] for r in ordered]))
    return results


def audit_ingresses(events, links, groups):
    """Join by strict NFD ingress key; apply locally measured physical evidence only."""
    arrivals={}
    sets={}
    bindings=defaultdict(list)
    matched_events=[]
    last_seq=0
    for e in events:
        need(e['event_seq']>last_seq, 'NFD event sequence out of order')
        last_seq=e['event_seq']
        t=e['event_type']
        if t not in ('DATA_ARRIVE_1U','DATA_MATCH_SET_1U','DATA_PIT_BIND_1U'):
            continue
        ord_=e.get('reason')
        need(type(ord_) is int and ord_>0, 'Invalid router-local Data ordinal')
        if t=='DATA_ARRIVE_1U':
            need(ord_ not in arrivals,'Duplicate Data arrival ordinal')
            arrivals[ord_]=e
        elif t=='DATA_MATCH_SET_1U':
            need(ord_ not in sets,'Duplicate PIT set ordinal')
            sets[ord_]=e
        else:
            need(e['pit_instance_id']>0, 'Cannot bind Data to unknown PIT')
            bindings[ord_].append(e)
    need(arrivals and arrivals.keys()==sets.keys(), 'Data ingress missing its PIT match-set')
    need(sorted(arrivals)==list(range(1,len(arrivals)+1)), 'Missing NFD ordinal')
    singles=defaultdict(list)
    for e in links:
        if e['event_type']=='MAC_RX' and e.get('ndn_packet_type')=='DATA':
            singles[(e['node_id'],e['face_id'],e['time_ns'],e['ndn_name'])].append(e)
    grouped=defaultdict(list)
    for g in groups:
        grouped[(g['node_id'],g['face_id'],g['completion_time_ns'],g['name'])].append(g)
    for e in events:
        if e['event_type']=='DATA_MATCH':
            matched_events.append(e)
    need(sum(map(len,bindings.values()))==len(matched_events), 'Mismatch with unmodified NFD DATA_MATCH count')
    rows=[]
    for ordinal,a in sorted(arrivals.items()):
        b=sets[ordinal]
        need(a['event_seq']<b['event_seq'],'Match set before NFD arrival')
        for key in ('node_id','face_id','name','time_ns'):
            need(a[key]==b[key],'NFD arrival vs PIT match mismatch: '+key)
        matched=bindings[ordinal]
        need(b.get('nonce')==len(matched),'PIT match-set count does not match explicit binds')
        need(len({x['pit_instance_id'] for x in matched})==len(matched),'PIT repeated within Data arrival')
        for x in matched:
            need(x['time_ns']==a['time_ns'] and x['face_id']==a['face_id'] and x['event_seq']>b['event_seq'],
                 'Out-of-scope PIT binding')
        k=(a['node_id'],a['face_id'],a['time_ns'],a['name'])
        physical=singles[k]
        fragments=grouped[k]
        need(len(physical)+len(fragments)==1,
             'Missing or ambiguous physical MAC_RX/group for Data ingress %r: singles=%s, groups=%s' % (k,len(physical),len(fragments)))
        if physical:
            link_source='SINGLE_PACKET_MAC_RX'
            units=1
            source={'packet_uid':physical[0]['packet_uid'],'fragment_group':None}
        else:
            link_source='COMPLETE_NDN_LP_REASSEMBLY'
            units=fragments[0]['n_frags']
            source={'packet_uid':None,'fragment_group':fragments[0]['group_start_seq']}
        rows.append(dict(node_id=a['node_id'],rx_ordinal=ordinal,name=a['name'],time_ns=a['time_ns'],
                         face_id=a['face_id'],pit_ids=[x['pit_instance_id'] for x in matched],
                         physical_evidence=link_source,physical_units=units,**source))
    return rows


def verify_folder(folder):
    folder=Path(folder)
    cfg=json.loads((folder/'scenario.json').read_text())
    mode=cfg.get('mode')
    need(mode in MODES and cfg.get('collector_stage')=='1W.0', 'Wrong Stage1W scenario/collector version')
    need(cfg.get('training_ready') is False and cfg.get('final_congestion_label') is None and
         cfg.get('future_congestion_label') is None and cfg.get('causal_congestion_attribution') is None,
         'Training or congestion labels must not be created')
    links=load(folder/'link_events.jsonl')
    need(links and all(x.get('schema_version')=='1W.0' for x in links),'Wrong link trace format')
    need(all(x['link_event_seq']==i for i,x in enumerate(links,1)), 'Missing/duplicate link events')
    groups=fragmented_groups(links)
    nodes_to_audit=[(1,'events.jsonl')]
    if mode=='multi-hop-fragmented':nodes_to_audit.append((2,'events_hop2.jsonl'))
    rows=[]
    for expected_node,path in nodes_to_audit:
        events=load(folder/path)
        need(all(x['node_id']==expected_node for x in events), 'Trace contains other NFD node')
        rows.extend(audit_ingresses(events,links,groups))
    episodes=load(folder/'episodes.jsonl')
    need(bool(episodes), 'No actual reconstructed Episode evidence')
    need(all(e.get('outcome') in ('SUCCESS','NACK','TIMEOUT','CANCELLED',None) for e in episodes),
         'Unexpected Episode outcome')
    successes=[e for e in episodes if e.get('outcome')=='SUCCESS']
    need(successes, 'No successful Episode for Data/PIT verification')
    need(any(any(str(pit)==ep.get('pit_instance_id') and row['node_id']==1 and row['name']==ep['name']
                 and row['time_ns']==ep['end_ns'] for pit in row['pit_ids']) for row in rows
             for ep in successes), 'Data/PIT proof inconsistent with observed successful Episode')
    physical=Counter(x['physical_evidence'] for x in rows)
    same_time=defaultdict(set)
    for x in rows:
        if x['node_id']==1:same_time[(x['time_ns'],x['name'])].add(x['face_id'])
    concurrent=[dict(time_ns=t,name=name,face_ids=sorted(fs)) for (t,name),fs in same_time.items() if len(fs)>=2]
    if mode=='same-time-dual-face':
        need(concurrent, 'INCOMPLETE: no simultaneous same-name Data arrivals from distinct Faces')
        need(physical['SINGLE_PACKET_MAC_RX']>=2,'No independently observed physical packets')
        need(cfg.get('router_strategy')=='diagnostic_multicast','Multiple upstreams must be explicitly solicited')
    else:
        need(physical['COMPLETE_NDN_LP_REASSEMBLY']>=1,'INCOMPLETE: no complete actual NDN-LP reassembly')
        need(cfg.get('mtu_bytes')==600 and cfg.get('payload_bytes')==4096,'MTU/payload test setup unexpected')
    if mode=='multi-hop-fragmented':
        hop1=[x for x in rows if x['node_id']==1]
        hop2=[x for x in rows if x['node_id']==2]
        need(len(hop1)==1 and len(hop2)==1 and hop1[0]['name']==hop2[0]['name']
             and hop2[0]['time_ns']<hop1[0]['time_ns'], 'INCOMPLETE: unique ordered 2-hop Data chain absent')
        need(all(x['pit_ids'] for x in (hop1[0],hop2[0])),
             'INCOMPLETE: no explicit PIT link on one of the two hops')
        need(all(x['physical_evidence']=='COMPLETE_NDN_LP_REASSEMBLY' for x in (hop1[0],hop2[0])),
             'INCOMPLETE: fragment-level physical evidence missing at one of two hops')
    result={'schema':'1W.0','scenario':mode,'run':cfg['run'],'nfd_data_ingresses':len(rows),'observed_episode_outcomes':dict(Counter(e['outcome'] for e in episodes)),
            'complete_lp_groups_at_mac_rx':len(groups),'physical_evidence_counts':dict(physical),
            'same_time_different_face_groups':concurrent,
            'nfd_ingress_rows':rows,'acceptance':'PASS_SCENARIO_EVIDENCE',
            'congestion':None,'future_congestion':None,'training_ready':False,
            'limits':['no UID continuity across hops','no causal congestion label',
                      'same-time P2P arrivals are not collisions on shared wireless media']}
    (folder/'stage1w_verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
    return result


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('folder',type=Path)
    args=parser.parse_args()
    out=verify_folder(args.folder)
    print(json.dumps({k:v for k,v in out.items() if k!='nfd_ingress_rows'},sort_keys=True))

if __name__=='__main__':main()
