#!/usr/bin/env python3
"""Summarize stage 1AH by RUN blocks, no pseudo-independent episode statistics."""
from collections import Counter
import hashlib,json,sys
from pathlib import Path

MODES=('LP_SELF_ONLY','LP_INDEPENDENT_COMPETITOR_NO_DROP','LP_INDEPENDENT_COMPETITOR_DROP','UNFRAGMENTED_MATCHED_BYTES')

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None

def resources(p):
    data={}
    if p.is_file():
        for line in p.read_text().splitlines():
            if '=' in line:
                k,v=line.split('=',1)
                try:data[k]=float(v)
                except ValueError:pass
    return data

def summarize(root,topology):
    root=Path(root);rows=[];pairs=[]
    for slot in range(3):
        for mode in MODES:
            for run in (9101,9102,9103):
                p=root/'monitored'/f'slot-{slot}'/mode/f'run-{run}'
                r={'topology_id':topology,'slot':slot,'mode':mode,'rng_run':run,
                   'status':'NO_VERIFIER_RESULT'}
                if (p/'stage1ah_verification.json').is_file():
                    r.update(json.loads((p/'stage1ah_verification.json').read_text()))
                rows.append(r)
    for mode in MODES[:2]:
        for run in (9101,9102,9103):
            a=root/'monitored'/'slot-0'/mode/f'run-{run}'
            b=root/'uninstrumented'/'slot-0'/mode/f'run-{run}'
            raw={key:sha(a/key)==sha(b/key) and sha(a/key) is not None for key in
                 ('consumer_events.jsonl','consumer_events.jsonl.arrivals.jsonl')}
            if mode==MODES[1]:
                raw.update({key:sha(a/key)==sha(b/key) and sha(a/key) is not None for key in
                   ('competitor_events.jsonl','competitor_events.jsonl.arrivals.jsonl')})
            pairs.append(dict(topology_id=topology,slot=0,mode=mode,rng_run=run,
                streams_equal=raw,paired_equal=all(raw.values()),
                monitored_resource=resources(a/'resource_usage.txt'),
                uninstrumented_resource=resources(b/'resource_usage.txt'),
                real_HCRAF_decision_cost_measured=False))
    summary=dict(stage='1AH.GROUP_AWARE.0',topology_id=topology,
       planned_monitored=36,actual_monitored=len(rows),
       status_counts=dict(Counter(r['status'] for r in rows)),
       planned_uninstrumented=6,recorded_pairs=len(pairs),
       matching_input_and_consumer_output=all(x['paired_equal'] for x in pairs),
       HCRAF_strategy_implemented_here=False,development_only=True,
       GO_FREEZE=False,Congestion=None,FutureCongestion=None,F3_ready=False,training_ready=False)
    for name,data in [('stage1ah_runs.json',rows),('stage1ah_pairs.json',pairs),('stage1ah_summary.json',summary)]:
        (root/name).write_text(json.dumps(data,sort_keys=True,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(summary,ensure_ascii=False))
    if len(rows)!=36 or len(pairs)!=6:return 2
    if any(x['status']!='PASS_TARGET_EVENT_ONLY' for x in rows):return 3
    if not summary['matching_input_and_consumer_output']:return 4
    return 0
if __name__=='__main__':raise SystemExit(summarize(sys.argv[1],sys.argv[2]))
