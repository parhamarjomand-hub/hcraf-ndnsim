#!/usr/bin/env python3
"""Aggregate only audited 1R runs, preserving failed/partial statuses."""
import json
from pathlib import Path
import argparse
from collections import Counter
MODES=('baseline','forward-buffered','return-buffered','forward-overflow','return-overflow')
def main():
    ap=argparse.ArgumentParser();ap.add_argument('stage_dir',type=Path);args=ap.parse_args()
    root=args.stage_dir
    out={'stage':'1R.1','purpose':'LINK_ATTRIBUTION_DIAGNOSTIC','training_ready':False,
         'Congestion':None,'FutureCongestion':None,'runs':[]}
    for mode in MODES:
        for run in (1001,1002):
            p=root/mode/('run-'+str(run))/'attribution_verification.json'
            if p.exists():out['runs'].append(json.loads(p.read_text()))
            else:out['runs'].append({'status':'MISSING_RESULT','mode':mode,'run':run})
    ok=all(r.get('status','').startswith('PASS_') for r in out['runs'])
    out['status']='PASS_PILOT_ATTRIBUTION_NOT_FINAL_LABEL' if ok else 'FAIL_OR_INCOMPLETE'
    out['decisions']=sum(r.get('decision_count',0) for r in out['runs'])
    out['forward_unique']=sum(r.get('unique_forward_packet_joins',0) for r in out['runs'])
    out['successful_episode_returns_unique']=sum(r.get('unique_return_joins_for_success',0) for r in out['runs'])
    out['note']='Pilot packet join is NOT a demonstrated cause of congestion or a final F3 label.'
    root.mkdir(parents=True,exist_ok=True)
    (root/'stage1r_summary.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:out[k] for k in ('status','decisions','forward_unique','successful_episode_returns_unique')}))
    if not ok:raise SystemExit(1)
if __name__=='__main__':main()
