#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
OUT="$ROOT/episode_output/stage1ab"
mkdir -p "$OUT"
cd "$ROOT/episode_sources/ns-3"
modes=(low-load propagation-only forward-buffered return-buffered forward-overflow return-overflow receive-loss mixed-fragmented)
paired=(low-load forward-buffered mixed-fragmented)
failed=0
for mode in "${modes[@]}"; do
  for run in 6101 6102 6103; do
    dest="$OUT/monitored/$mode/run-$run"
    mkdir -p "$dest"
    command="hcraf-stage1ab-pilot --mode=$mode --output=$dest --seed=17 --run=$run --instrument=1"
    printf '%s\n' "$command" > "$dest/command.txt"
    if ! /usr/bin/time -f 'wall_seconds=%e\nuser_seconds=%U\nsystem_seconds=%S\nmax_rss_kib=%M' -o "$dest/resource_usage.txt" \
      python3 ./waf --run-no-build "$command" > "$dest/simulator.log" 2>&1; then
      echo "STAGE1AB_SIM_FAIL mode=$mode run=$run";failed=1;continue
    fi
    if ! python3 "$TASK/scripts/episodes_stage1u.py" "$dest" --run-id "1ab-$mode-17-$run" \
      > "$dest/episodes.log" 2>&1; then
      echo "STAGE1AB_EPISODE_FAIL mode=$mode run=$run"; failed=1;continue
    fi
    if ! python3 "$TASK/scripts/verify_stage1ab.py" "$dest" --fail-on-incomplete \
      > "$dest/verify.log" 2>&1; then
      echo "STAGE1AB_INCOMPLETE_TARGET mode=$mode run=$run";failed=1
    fi
  done
done
for mode in "${paired[@]}"; do
  for run in 6101 6102 6103; do
    dest="$OUT/uninstrumented/$mode/run-$run"
    mkdir -p "$dest"
    command="hcraf-stage1ab-pilot --mode=$mode --output=$dest --seed=17 --run=$run --instrument=0"
    printf '%s\n' "$command" > "$dest/command.txt"
    if ! /usr/bin/time -f 'wall_seconds=%e\nuser_seconds=%U\nsystem_seconds=%S\nmax_rss_kib=%M' -o "$dest/resource_usage.txt" \
      python3 ./waf --run-no-build "$command" > "$dest/simulator.log" 2>&1; then
      echo "STAGE1AB_PAIRED_FAIL mode=$mode run=$run"; failed=1
    fi
  done
done
if ! python3 "$TASK/scripts/summarize_stage1ab.py" "$OUT"; then failed=1;fi
exit "$failed"
