#!/usr/bin/env python3
"""Integrity manifest, including partial outputs on workflow failure."""
import hashlib
import json
import os
import platform
import subprocess
import sys
from datetime import datetime,timezone
from pathlib import Path

root=Path(sys.argv[1]).resolve()
out=root/'episode_output';out.mkdir(exist_ok=True)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
try:revision=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()
except (OSError,subprocess.CalledProcessError):revision=os.environ.get('GITHUB_SHA')
files={str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='manifest.json'}
code={str(p.relative_to(root)):sha(p) for p in sorted((root/'hcraf/episode').rglob('*'))
      if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
workflow=root/'.github/workflows/hcraf-stage1s.yml'
if workflow.is_file():code[str(workflow.relative_to(root))]=sha(workflow)
report=dict(schema_version='1S.1',created_at_utc=datetime.now(timezone.utc).isoformat(),
    purpose='ATTRIBUTION_ROBUSTNESS_DIAGNOSTIC_NOT_TRAINING',
    git_commit=revision,github_run_id=os.environ.get('GITHUB_RUN_ID'),
    github_run_attempt=os.environ.get('GITHUB_RUN_ATTEMPT'),
    python=platform.python_version(),artifact_sha256=files,code_sha256=code,
    environment_fully_locked=False,
    limitation='Pinned ndnSIM/NFD sources; apt repository state and container digest are not locked.')
(out/'manifest.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
