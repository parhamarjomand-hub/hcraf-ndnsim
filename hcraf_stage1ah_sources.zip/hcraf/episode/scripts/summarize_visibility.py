#!/usr/bin/env python3
import json,sys,csv
from pathlib import Path
ROOT = Path(sys.argv[1])
rows=[]
for mode in ('baseline','forward-buffered','return-buffered','forward-overflow','return-overflow'):
 for run in (1001,1002):
  path=ROOT/mode/('run-'+str(run))/'visibility_verification.json'
  if not path.exists():
   rows.append(dict(mode=mode,run=run,status='MISSING',reason='Artifact missing'))
   continue
  d=json.loads(path.read_text())
  entry=dict(mode=mode,run=run,status=d['status'])
  if d['status']=='PASS_OBSERVABILITY_NOT_CONGESTION_VALIDATION':
   for name,short in (('forward_router','forward'),('reverse_producer','return')):
    e=d[name]
    for field in ('queue_drop','positive_wait_packets','queue_positive_events','max_observed_wait_ns','pending_at_stop'):
     entry[short+'_'+field]=e[field]
   entry['episodes']=d['reconstructed_episodes']
   entry['outcomes']=json.dumps(d['observed_outcomes'],sort_keys=True)
  rows.append(entry)
columns=['mode','run','status','episodes','outcomes'] + [name+'_'+field for name in ('forward','return') for field in ('queue_drop','positive_wait_packets','queue_positive_events','max_observed_wait_ns','pending_at_stop')]
with (ROOT/'visibility_summary.csv').open('w',newline='',encoding='utf-8') as o:
 writer=csv.DictWriter(o,fieldnames=columns,extrasaction='ignore');writer.writeheader();writer.writerows(rows)
complete=all(r['status']=='PASS_OBSERVABILITY_NOT_CONGESTION_VALIDATION' for r in rows)
paired=True
pair_warnings=[]
if complete:
    by_run={}
    for run in (1001,1002):
        arrays=[]
        choices=[]
        for mode in ('baseline','forward-buffered','return-buffered','forward-overflow','return-overflow'):
            folder=ROOT/mode/('run-'+str(run))
            selections=[json.loads(line) for line in (folder/'events.jsonl.collection.jsonl').read_text().splitlines() if line.strip()]
            arrivals=[json.loads(line) for line in (folder/'consumer_events.jsonl.arrivals.jsonl').read_text().splitlines() if line.strip()]
            arrays.append([x['time_ns'] for x in arrivals])
            choices.append([x['uniform_draw'] for x in selections])
        if arrays[1]!=arrays[2] or arrays[3]!=arrays[4]:
            paired=False;pair_warnings.append('Buffered/overflow offered traffic not paired in RngRun '+str(run))
        if choices[1]!=choices[2] or choices[3]!=choices[4]:
            paired=False;pair_warnings.append('Collection RNG draws not paired in RngRun '+str(run))
        by_run[run]=choices
    if by_run[1001][1]==by_run[1002][1]:
        paired=False;pair_warnings.append('RngRun did not change collection random sequence')
complete = complete and paired
with (ROOT/'visibility_summary.json').open('w',encoding='utf8') as o:
 json.dump(dict(status='PASS_MEASUREMENT_PIPELINE_NOT_FINAL_LABEL' if complete else 'INCOMPLETE',
                runs_expected=10,runs_verified=sum(r['status'].startswith('PASS_') for r in rows),
                independent_rng_blocks=2,
                final_congestion=None,future_congestion=None,training_ready=False,
                guarantee_of_queueing_without_drop=False,
                paired_random_stream_checks_passed=paired,
                pairing_warnings=pair_warnings,
                note='Buffering/drops are measured outcomes, not forced PASS assumptions. Independent run blocks, not each packet, are statistical units.',
                rows=rows),o,indent=2,ensure_ascii=False)
 o.write('\n')
if not complete:sys.exit(1)
print('PASS measurement pipeline; 10 runs. No final congestion label produced.')
