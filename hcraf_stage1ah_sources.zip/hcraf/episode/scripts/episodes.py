#!/usr/bin/env python3
"""Deterministic reconstruction from actual forwarder events. Python >=3.8."""
import argparse
import json
from pathlib import Path

TYPES = {'TX_INTEREST', 'PIT_TIMER', 'DATA_MATCH', 'PIT_SATISFIED',
         'NACK_ACCEPTED', 'PIT_FINALIZE', 'CACHE_HIT', 'UNSOLICITED_DATA', 'SIMULATION_END'}

def require(condition, message):
    if not condition:
        raise ValueError(message)

def reconstruct(events, run_id):
    rows, active, retired = [], {}, set()
    last_time, seq, node, ended = -1, 0, None, False
    def close(key, outcome, t, event, terminal_face=None, reason=None, source='NFD_EVENT'):
        row = active.pop(key)
        row.update(outcome=outcome, end_ns=t, observed_until_ns=t,
                   terminal_face_id=terminal_face, terminal_reason=reason,
                   terminal_event_seq=event['event_seq'], terminal_source=source)
        if outcome == 'SUCCESS' and row['tx_count'] == 1:
            row.update(delay_valid=True, delay_ns=t-row['start_ns'])
        if outcome == 'NACK':
            row.update(nack_matches_outrecord=True, nack_reason=event['reason'])
        rows.append(row)
    def censor(key, t, event, reason):
        row = active.pop(key)
        row.update(observed_until_ns=t, censor_reason=reason,
                   terminal_event_seq=event['event_seq'], terminal_source='OBSERVATION_END')
        rows.append(row)
    for event in events:
        require(not ended, 'event after SIMULATION_END')
        require(event.get('schema_version') == '0.2', 'unsupported schema')
        t, n, kind = event['time_ns'], event['node_id'], event['event_type']
        require(type(t) is int and t >= last_time and t >= 0, 'invalid time ordering')
        require(type(n) is int and n >= 0, 'invalid node id')
        require(event['event_seq'] == seq+1, 'missing, duplicate or reordered event')
        require(kind in TYPES, 'unknown event')
        if node is None: node = n
        require(node == n, 'this pilot expects one router per event file')
        last_time, seq = t, event['event_seq']
        pit, face = event['pit_instance_id'], event['face_id']
        require(type(pit) is int and pit >= 0, 'invalid PIT identity')
        require(pit not in retired or pit == 0, 'PIT instance reused after finalization')
        # At exact equality the recorded callback order wins. Strictly later
        # callbacks cannot turn an expired out-record into a SUCCESS.
        for key in list(active):
            if active[key]['deadline_ns'] < t:
                close(key, 'TIMEOUT', active[key]['deadline_ns'], event,
                      reason='OUT_RECORD_DEADLINE', source='DEADLINE_RECONSTRUCTION')
        key = (pit, face)
        if kind == 'TX_INTEREST':
            require(pit > 0 and type(face) is int and face >= 0, 'invalid TX key')
            require(type(event['deadline_ns']) is int and event['deadline_ns'] >= t, 'invalid deadline')
            require(type(event['nonce']) is int and 0 <= event['nonce'] < 2**32, 'invalid nonce')
            if key not in active:
                active[key] = dict(schema_version='0.2', run_id=run_id, node_id=node,
                    episode_id='e' + str(seq), pit_instance_id=str(pit), face_id=face,
                    name=event['name'], start_ns=t, end_ns=None, observed_until_ns=t,
                    outcome=None, censor_reason=None, delay_valid=False, delay_ns=None,
                    tx_times_ns=[], tx_nonces=[], tx_event_seqs=[], tx_count=0,
                    deadline_history_ns=[], terminal_face_id=None, terminal_reason=None)
            row = active[key]
            require(row['name'] == event['name'], 'name changed within PIT')
            row['tx_times_ns'].append(t)
            row['tx_nonces'].append(event['nonce'])
            row['tx_event_seqs'].append(seq)
            row['tx_count'] += 1
            row['deadline_ns'] = event['deadline_ns']
            row['deadline_history_ns'].append(event['deadline_ns'])
        elif kind == 'NACK_ACCEPTED' and key in active:
            require(active[key]['tx_nonces'][-1] == event['nonce'], 'NACK nonce mismatch')
            require(event['reason'] >= 0, 'missing NACK reason')
            close(key, 'NACK', t, event, face, 'MATCHED_NACK')
        elif kind == 'PIT_SATISFIED':
            require(event['payload_bytes'] >= 0, 'missing Data payload size')
            for pending in list(active):
                if pending[0] != pit: continue
                if pending[1] == face:
                    active[pending]['payload_bytes'] = event['payload_bytes']
                    close(pending, 'SUCCESS', t, event, face, 'PIT_SATISFIED_THIS_FACE')
                else:
                    close(pending, 'CANCELLED', t, event, face, 'PIT_SATISFIED_OTHER_FACE')
        elif kind == 'PIT_FINALIZE':
            for pending in list(active):
                if pending[0] != pit: continue
                if active[pending]['deadline_ns'] <= t:
                    close(pending, 'TIMEOUT', active[pending]['deadline_ns'], event,
                          reason='OUT_RECORD_DEADLINE', source='DEADLINE_RECONSTRUCTION')
                else:
                    censor(pending, t, event, 'PIT_FINALIZED_BEFORE_FACE_DEADLINE')
            retired.add(pit)
        elif kind == 'SIMULATION_END':
            for pending in list(active):
                if active[pending]['deadline_ns'] <= t:
                    close(pending, 'TIMEOUT', active[pending]['deadline_ns'], event,
                          reason='OUT_RECORD_DEADLINE', source='DEADLINE_RECONSTRUCTION')
                else:
                    censor(pending, t, event, 'SIMULATION_END')
            ended = True
    require(ended, 'missing SIMULATION_END: incomplete run, do not label')
    require(rows, 'no episodes recorded')
    return sorted(rows, key=lambda row: (row['start_ns'], row['face_id'], row['tx_event_seqs'][0]))

def load(path):
    with path.open(encoding='utf-8') as stream:
        return [json.loads(line) for line in stream if line.strip()]

def main():
    p = argparse.ArgumentParser()
    p.add_argument('folder', type=Path)
    p.add_argument('--run-id', required=True)
    args = p.parse_args()
    rows = reconstruct(load(args.folder/'events.jsonl'), args.run_id)
    with (args.folder/'episodes.jsonl').open('w', encoding='utf-8') as out:
        for row in rows: out.write(json.dumps(row, sort_keys=True)+'\n')
    print(json.dumps({'episodes': len(rows), 'status': 'RECONSTRUCTED_NOT_YET_VERIFIED'}))

if __name__ == '__main__': main()
