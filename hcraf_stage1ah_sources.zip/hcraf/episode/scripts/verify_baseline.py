"""Verify observational state instrumentation did not change Stage1G traffic."""
import hashlib,json,sys
from pathlib import Path

def canonical(rows):return hashlib.sha256(json.dumps(rows,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def verify(root,baseline):
 ref=json.loads(baseline.read_text());count=0
 for mode,expected in ref['modes'].items():
  for repeat in (1,2):
   p=root/mode/('repeat-'+str(repeat))
   for n,sha in expected['files'].items():
    if hashlib.sha256((p/n).read_bytes()).hexdigest()!=sha:raise ValueError('Baseline changed: '+mode+'/'+n)
    count+=1
   links=[json.loads(x) for x in (p/'link_events.jsonl').read_text().splitlines()]
   for x in links:x.pop('LocalQueueOccupancyFraction',None)
   if canonical(links)!=expected['link_semantics_sha256']:raise ValueError('Baseline link events changed: '+mode)
 return dict(status='PASS',baseline_run=ref['github_run_id'],raw_file_comparisons=count,link_trace_comparisons=12,scope='same-seed Stage1G engineering pilot; no wall-clock overhead claim')
if __name__=='__main__':
 root=Path(sys.argv[1])
 try:r=verify(root,Path(__file__).resolve().parents[1]/'docs/stage1g_baseline.json')
 except Exception as e:r=dict(status='FAIL',error=str(e))
 (root/'baseline_verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));sys.exit(0 if r['status']=='PASS' else 1)
