"""Fail-closed checks for the restricted two-face integration pilot."""
import json, math, sys
from pathlib import Path
from collections import Counter, defaultdict
from episodes import load, require, reconstruct
from verify_states import verify as verify_state


def check(c, d, tx):
    p, u = c['alternative_inclusion_probability'], c['uniform_draw']
    require(type(p) in (float,int) and math.isfinite(p) and 0 <= p <= 1, 'invalid probability')
    require(type(u) in (float,int) and math.isfinite(u) and 0 <= u < 1, 'invalid draw')
    selected = u < p
    a,b=c['primary_face_id'],c['alternative_face_id']
    require(c['alternative_selected'] is selected, 'draw/selection mismatch')
    require(c['primary_inclusion_probability'] == 1-p, 'primary probability')
    require(c['selected_action_probability'] == (p if selected else 1-p) and c['selected_action_probability'] > 0, 'selected probability')
    require(c['selected_face_id'] == (b if selected else a), 'selected face')
    require(c['policy']=='EXCLUSIVE_TWO_FACE_BERNOULLI', 'policy')
    require(c['eligibility_rule']=='NFD_isNextHopEligible_FRESH_PIT_TWO_FACES', 'eligibility rule')
    require(a != b and c['eligible_face_ids']==[a,b], 'eligible faces')
    candidates={x['face_id']:x for x in d['candidates']}
    require(set(candidates)=={a,b} and len(d['candidates'])==2, 'FIB mismatch')
    require(candidates[a]['routing_cost'] < candidates[b]['routing_cost'], 'cost ordering')
    require(all(not x['is_ingress'] for x in candidates.values()), 'ingress candidate')
    require(len(tx)==1 and tx[0]['face_id']==c['selected_face_id'], 'must send exactly one selected face')
    x=tx[0]
    require(x['pit_instance_id']==d['pit_instance_id'] and x['name']==d['name'], 'TX/PIT mismatch')
    require(x['time_ns']==d['time_ns'] and x['event_seq']>d['after_event_seq'], 'TX anchor mismatch')


def verify(folder):
    cfg=json.loads((folder/'scenario.json').read_text())
    require(cfg['collector_stage']=='1L.1' and cfg['collection_mode']=='single' and cfg['mode'] in ('control','receive-outage'), 'wrong collector scenario')
    ds=load(folder/'events.jsonl.decisions.jsonl');cs=load(folder/'events.jsonl.collection.jsonl')
    ev=load(folder/'events.jsonl'); ep=load(folder/'episodes.jsonl');consumer=load(folder/'consumer_events.jsonl')
    require(len(ds)==len(cs)==40 and len({d['decision_id'] for d in ds})==40,'decision count/uniqueness')
    require(ep==reconstruct(ev,ep[0]['run_id']), 'reconstructed episodes mismatch')
    by=defaultdict(list)
    for x in ev:
        if x['event_type']=='TX_INTEREST':by[x['decision_id']].append(x)
    require(set(by)=={d['decision_id'] for d in ds},'orphan TX')
    index={e['tx_event_seqs'][0]:e for e in ep}
    require(len(index)==len(ep) and all(e['tx_count']==1 and e['outcome'] in ('SUCCESS','TIMEOUT') for e in ep),'unexpected outcome/retx')
    roles=[]
    for c,d in zip(cs,ds):
        require(c['schema_version']=='1L.1' and c['decision_id']==d['decision_id'],'collector order/schema')
        require(c['alternative_inclusion_probability']==cfg['probe_probability'],'configuration probability')
        require(c['primary_face_id']==cfg['primary_face_id'] and c['alternative_face_id']==cfg['secondary_face_id'],'configured faces')
        check(c,d,by[d['decision_id']])
        for x in by[d['decision_id']]:
            e=index[x['event_seq']];primary=x['face_id']==c['primary_face_id']
            roles.append(dict(episode_id=e['episode_id'],decision_id=d['decision_id'],face_id=x['face_id'],
                role='PRIMARY' if primary else 'EXPLORATION',inclusion_probability=c['selected_action_probability'],
                selected_action_probability=c['selected_action_probability'],outcome=e['outcome']))
    require(len(roles)==len(ep),'episode role coverage')
    counts=Counter(e['outcome'] for e in ep);p=cfg['probe_probability']
    require(counts['SUCCESS']+counts['TIMEOUT']+counts['CANCELLED']==len(ep),'unclosed episode')
    sends=[x for x in consumer if x['event']=='SEND'];data=[x for x in consumer if x['event']=='DATA']
    require(len(sends)==40 and len({x['name'] for x in sends})==40,'consumer request count')
    require([x['time_ns'] for x in sends]==[10**9+i*200000000 for i in range(40)],'arrival schedule')
    require(len(data)==counts['SUCCESS'] and len({x['name'] for x in data})==len(data),'consumer success evidence')
    if cfg['mode']=='control':
        require(counts['SUCCESS']==40 and counts['TIMEOUT']==0,'control success')
    if p==0:
        require(len(ep)==40 and counts['CANCELLED']==0,'zero probe mismatch')
        if cfg['mode']=='receive-outage':require(counts==Counter(SUCCESS=25,TIMEOUT=15),'outage control mismatch')
    require(len(ep)==40 and counts['CANCELLED']==0,'exclusive episodes/cancellations')
    if p==1:require(counts==Counter(SUCCESS=40),'alternative-only outcome')
    for c,d in zip(cs,ds):
        e=index[by[d['decision_id']][0]['event_seq']]
        fails=(cfg['mode']=='receive-outage' and c['selected_face_id']==cfg['primary_face_id'] and 3*10**9<=d['time_ns']<6*10**9)
        require(e['outcome']==('TIMEOUT' if fails else 'SUCCESS'),'outcome inconsistent with controlled path/outage')
    require({x['name'] for x in data}=={e['name'] for e in ep if e['outcome']=='SUCCESS'},'consumer/episode successful names')
    verify_state(folder)
    (folder/'episode_roles.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in roles))
    alternatives=sum(r['role']=='EXPLORATION' for r in roles)
    report=dict(status='PASS',decisions=len(ds),episodes=len(ep),outcomes=dict(counts),alternative_selections=alternatives,
        extra_interest_count_ratio=0.0,counts_by_role={role:dict(Counter(r['outcome'] for r in roles if r['role']==role)) for role in ('PRIMARY','EXPLORATION')},
        valid_outcomes_by_face={str(f):sum(e['face_id']==f and e['outcome'] in ('SUCCESS','NACK','TIMEOUT') for e in ep) for f in (cfg['primary_face_id'],cfg['secondary_face_id'])},
        probabilities_are_behavior_inclusion_not_counterfactual=True,training_ready=False)
    (folder/'selection_verification.json').write_text(json.dumps(report,indent=2)+'\n')
    return report

if __name__=='__main__':
    folder=Path(sys.argv[1])
    try: print(json.dumps(verify(folder)))
    except Exception as e:
        (folder/'selection_verification.json').write_text(json.dumps(dict(status='FAIL',error=str(e)))+'\n');raise
