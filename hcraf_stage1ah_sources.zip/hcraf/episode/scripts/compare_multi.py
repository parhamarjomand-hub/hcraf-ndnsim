#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
import sys

def compare(root):
    result=dict(status='PASS',purpose='DETERMINISM_NOT_INDEPENDENT_REPLICATIONS',modes={})
    summaries={}
    for mode in ('multi-low','multi-mid','multi-change'):
        hashes={}
        for filename in ('events.jsonl','episodes.jsonl','consumer_events.jsonl','scenario.json',
                         'events.jsonl.decisions.jsonl','link_events.jsonl','decision_faces.jsonl','multi_verification.json','control_events.jsonl'):
            a=(root/mode/'repeat-1'/filename).read_bytes()
            b=(root/mode/'repeat-2'/filename).read_bytes()
            if a!=b: raise ValueError('Repetitions differ: '+mode+'/'+filename)
            hashes[filename]=hashlib.sha256(a).hexdigest()
        report=json.loads((root/mode/'repeat-1/multi_verification.json').read_text())
        if report['status']!='PASS': raise ValueError('Scenario verification failed: '+mode)
        summaries[mode]=report
        result['modes'][mode]=hashes
    # Publish measured summaries once per condition; do not treat repeat-2 as another sample.
    result['measured_comparison']=summaries
    result['statistical_inference_valid']=False
    return result

if __name__=='__main__':
    root=Path(sys.argv[1])
    try: report=compare(root)
    except Exception as e: report=dict(status='FAIL',error=str(e))
    (root/'multi_reproducibility.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
    sys.exit(0 if report['status']=='PASS' else 1)
