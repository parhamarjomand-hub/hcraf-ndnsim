#ifndef HCRAF_STATE_HPP
#define HCRAF_STATE_HPP
#include <cstdint>
#include <deque>
#include <map>
#include <optional>
#include <stdexcept>
#include <string>
#include <utility>
namespace hcraf {
// Reference shadow estimator: observes events, never selects a Face or schedules events.
// One instance per observed node and fixed configured prefix; not per arbitrary name.
class State {
public:
  static constexpr int64_t Window = 1000000000LL;
  struct Face {
    uint64_t valid=0, success=0, rttCount=0, bytes=0, maxSeq=0;
    std::optional<double> srttNs;
    std::optional<int64_t> lastOutcome, lastRtt;
    std::deque<std::pair<int64_t,uint64_t>> recent;
  };
  struct Sample {
    std::optional<double> srttMs, successEstimate, goodputBps;
    uint64_t valid, rttCount, maxSeq, retained;
    std::optional<int64_t> outcomeAge, rttAge;
  };
  void event(const std::string& type,uint64_t pit,int64_t face,int64_t now,
             int64_t deadline,int64_t nonce,int64_t bytes,uint64_t seq) {
    if (now<m_lastTime || seq!=m_lastSeq+1) throw std::runtime_error("State event ordering");
    m_lastTime=now; m_lastSeq=seq;
    for (auto& f:m_faces) prune(f.second,now);
    for(auto i=m_active.begin();i!=m_active.end();) {
      if(i->second.deadline<now) { fail(i->first.second,now,seq); i=m_active.erase(i); }
      else ++i;
    }
    const Key key{pit,face};
    if(type=="TX_INTEREST") {
      if(!pit || face<0 || deadline<now) throw std::runtime_error("Invalid state TX");
      auto r=m_active.emplace(key,Episode{now,deadline,nonce,0});
      auto& e=r.first->second;e.deadline=deadline;e.nonce=nonce;++e.txCount;
    }
    else if(type=="NACK_ACCEPTED") {
      auto i=m_active.find(key);
      if(i!=m_active.end()) {
        if(i->second.nonce!=nonce)throw std::runtime_error("State NACK nonce mismatch");
        fail(face,now,seq);m_active.erase(i);
      }
    }
    else if(type=="PIT_SATISFIED") {
      if(bytes<0)throw std::runtime_error("State missing payload");
      for(auto i=m_active.begin();i!=m_active.end();) {
        if(i->first.first!=pit){++i;continue;}
        if(i->first.second==face) {
          auto& f=m_faces[face];++f.valid;++f.success;f.maxSeq=seq;f.lastOutcome=now;
          if(i->second.txCount==1) {
            const double rtt=static_cast<double>(now-i->second.start);
            f.srttNs=f.srttNs ? .875*(*f.srttNs)+.125*rtt : rtt;
            ++f.rttCount;f.lastRtt=now;
          }
          f.recent.emplace_back(now,static_cast<uint64_t>(bytes));f.bytes+=bytes;
        }
        // Other Face is CANCELLED: no success or failure evidence.
        i=m_active.erase(i);
      }
    }
    else if(type=="PIT_FINALIZE" || type=="SIMULATION_END") {
      for(auto i=m_active.begin();i!=m_active.end();) {
        if(type=="PIT_FINALIZE" && i->first.first!=pit){++i;continue;}
        if(i->second.deadline<=now)fail(i->first.second,now,seq);
        // Before deadline = censored; never convert to failure.
        i=m_active.erase(i);
      }
    }
  }
  Sample sample(int64_t face,int64_t now) {
    if(now<m_lastTime)throw std::runtime_error("State query before evidence");
    m_lastTime=now;
    auto& f=m_faces[face];prune(f,now);
    return {f.srttNs ? std::optional<double>(*f.srttNs/1e6):std::nullopt,
      f.valid ? std::optional<double>(double(f.success)/f.valid):std::nullopt,
      now>=Window ? std::optional<double>(8.0*f.bytes):std::nullopt,
      f.valid,f.rttCount,f.maxSeq,f.recent.size(),
      f.lastOutcome ? std::optional<int64_t>(now-*f.lastOutcome):std::nullopt,
      f.lastRtt ? std::optional<int64_t>(now-*f.lastRtt):std::nullopt};
  }
private:
  using Key=std::pair<uint64_t,int64_t>;
  struct Episode {int64_t start,deadline,nonce;uint64_t txCount;};
  static void prune(Face& f,int64_t now) {
    while(!f.recent.empty() && f.recent.front().first<=now-Window) {
      f.bytes-=f.recent.front().second;f.recent.pop_front();
    }
  }
  void fail(int64_t face,int64_t now,uint64_t seq) {
    auto& f=m_faces[face];++f.valid;f.lastOutcome=now;f.maxSeq=seq;
  }
  int64_t m_lastTime=0;uint64_t m_lastSeq=0;
  std::map<Key,Episode> m_active;
  std::map<int64_t,Face> m_faces;
};
}
#endif
