#ifndef HCRAF_VISIBILITY_MONITOR_HPP
#define HCRAF_VISIBILITY_MONITOR_HPP
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/ndnSIM/model/ndn-l3-protocol.hpp"
#include "ns3/ndnSIM/NFD/daemon/face/face.hpp"
#include <fstream>
#include <vector>
#include <unordered_map>
#include <deque>
#include <cstdint>
#include <stdexcept>

// All link traffic (including management), not a prefix-filtered goodput counter.
// No extra simulator events are scheduled by this observer.
class HcrafVisibilityMonitor {
  struct Device {
    ns3::Ptr<ns3::PointToPointNetDevice> dev;
    uint32_t node;
    uint64_t face;
    uint64_t txBytes = 0, dropPackets = 0;
    std::unordered_map<uint64_t, std::deque<int64_t>> pendingEnqueues;
    Device(ns3::Ptr<ns3::PointToPointNetDevice> device, uint32_t nodeId, uint64_t faceId)
      : dev(device), node(nodeId), face(faceId) {}
  };
public:
  HcrafVisibilityMonitor(const ns3::NodeContainer& nodes, const std::string& path) : m_out(path) {
    if (!m_out) throw std::runtime_error("Cannot open link trace");
    for (uint32_t n = 0; n < nodes.GetN(); ++n) {
      auto node = nodes.Get(n);
      auto l3 = node->GetObject<ns3::ndn::L3Protocol>();
      for (uint32_t d = 0; d < node->GetNDevices(); ++d) {
        auto dev = ns3::DynamicCast<ns3::PointToPointNetDevice>(node->GetDevice(d));
        if (!dev) continue;
        auto face = l3->getFaceByNetDevice(dev);
        if (!face || !dev->GetQueue()) throw std::runtime_error("Missing device/Face/queue mapping");
        if (dev->GetQueue()->GetMaxSize().GetUnit() != ns3::QueueSizeUnit::PACKETS ||
            dev->GetQueue()->GetMaxSize().GetValue() == 0)
          throw std::runtime_error("Queue occupancy candidate requires finite packet capacity");
        uint32_t index = static_cast<uint32_t>(m_devices.size());
        m_devices.emplace_back(dev, node->GetId(), face->getId());
        bool connected = dev->TraceConnectWithoutContext("PhyTxBegin",
          ns3::MakeBoundCallback(&HcrafVisibilityMonitor::TxBegin, this, index));
        connected = dev->TraceConnectWithoutContext("PhyTxEnd",
          ns3::MakeBoundCallback(&HcrafVisibilityMonitor::TxEnd, this, index)) && connected;
        connected = dev->GetQueue()->TraceConnectWithoutContext("Drop",
          ns3::MakeBoundCallback(&HcrafVisibilityMonitor::Drop, this, index)) && connected;
        connected = dev->GetQueue()->TraceConnectWithoutContext("Enqueue",
          ns3::MakeBoundCallback(&HcrafVisibilityMonitor::Enqueue, this, index)) && connected;
        connected = dev->GetQueue()->TraceConnectWithoutContext("Dequeue",
          ns3::MakeBoundCallback(&HcrafVisibilityMonitor::Dequeue, this, index)) && connected;
        connected = dev->TraceConnectWithoutContext("PhyRxDrop",
          ns3::MakeBoundCallback(&HcrafVisibilityMonitor::RxDrop, this, index)) && connected;
        if (!connected) throw std::runtime_error("Required link trace unavailable");
      }
    }
    Snapshot(0, "INITIAL");
  }
  void Snapshot(uint64_t decision, const char* kind = "DECISION_SNAPSHOT") {
    for (uint32_t i = 0; i < m_devices.size(); ++i) Write(i, kind, decision, nullptr);
  }
  void Finish() {
    Snapshot(0, "FINAL");
    m_out.flush();
    if (!m_out) throw std::runtime_error("Link trace flush failed");
  }
private:
  static void Enqueue(HcrafVisibilityMonitor* self, uint32_t i, ns3::Ptr<const ns3::Packet> p) {
    self->m_devices.at(i).pendingEnqueues[p->GetUid()].push_back(ns3::Simulator::Now().GetNanoSeconds());
    self->Write(i, "QUEUE_ENQUEUE", 0, p);
  }
  static void Dequeue(HcrafVisibilityMonitor* self, uint32_t i, ns3::Ptr<const ns3::Packet> p) {
    auto& waits = self->m_devices.at(i).pendingEnqueues;
    auto it = waits.find(p->GetUid());
    int64_t waitNs = -1;
    if (it != waits.end() && !it->second.empty()) {
      waitNs = ns3::Simulator::Now().GetNanoSeconds() - it->second.front();
      it->second.pop_front();
      if (it->second.empty()) waits.erase(it);
    }
    self->Write(i, "QUEUE_DEQUEUE", 0, p, waitNs);
  }
  static void RxDrop(HcrafVisibilityMonitor* self, uint32_t i, ns3::Ptr<const ns3::Packet> p) {
    self->Write(i, "PHY_RX_DROP", 0, p);
  }
  static void TxBegin(HcrafVisibilityMonitor* self, uint32_t i, ns3::Ptr<const ns3::Packet> p) {
    self->m_devices.at(i).txBytes += p->GetSize();
    self->Write(i, "PHY_TX_BEGIN", 0, p);
  }
  static void TxEnd(HcrafVisibilityMonitor* self, uint32_t i, ns3::Ptr<const ns3::Packet> p) {
    self->Write(i, "PHY_TX_END", 0, p);
  }
  static void Drop(HcrafVisibilityMonitor* self, uint32_t i, ns3::Ptr<const ns3::Packet> p) {
    ++self->m_devices.at(i).dropPackets;
    self->Write(i, "QUEUE_DROP", 0, p);
  }
  void Write(uint32_t i, const char* kind, uint64_t decision, ns3::Ptr<const ns3::Packet> p, int64_t queueWaitNs = -1) {
    const auto& d = m_devices.at(i);
    ns3::DataRateValue rate;
    d.dev->GetAttribute("DataRate", rate);
    m_out << "{\"schema_version\":\"1P.1\",\"link_event_seq\":" << ++m_seq
      << ",\"event_type\":\"" << kind << "\",\"time_ns\":" << ns3::Simulator::Now().GetNanoSeconds()
      << ",\"decision_id\":" << decision << ",\"decision_node_id\":1"
      << ",\"node_id\":" << d.node << ",\"device_index\":" << d.dev->GetIfIndex()
      << ",\"face_id\":" << d.face << ",\"link_up\":" << (d.dev->IsLinkUp() ? "true" : "false")
      << ",\"data_rate_bps\":" << rate.Get().GetBitRate()
      << ",\"queue_packets\":" << d.dev->GetQueue()->GetNPackets()
      << ",\"LocalQueueOccupancyFraction\":" << double(d.dev->GetQueue()->GetNPackets()) / d.dev->GetQueue()->GetMaxSize().GetValue()
      << ",\"queue_bytes\":" << d.dev->GetQueue()->GetNBytes()
      << ",\"phy_tx_started_bytes_total\":" << d.txBytes
      << ",\"queue_drop_packets_total\":" << d.dropPackets
      << ",\"packet_uid\":" << (p ? std::to_string(p->GetUid()) : "null")
      << ",\"packet_bytes\":" << (p ? std::to_string(p->GetSize()) : "null")
      << ",\"queue_wait_ns\":" << (queueWaitNs >= 0 ? std::to_string(queueWaitNs) : "null")
      << "}\n";
    if (!m_out) throw std::runtime_error("Link trace write failed");
  }
  std::ofstream m_out;
  std::vector<Device> m_devices;
  uint64_t m_seq = 0;
};
#endif
