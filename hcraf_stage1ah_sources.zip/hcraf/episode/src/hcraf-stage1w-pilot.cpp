// Stage1W diagnostic: physical co-arrival, NDN-LP fragments, multi-hop attribution.
// NOT a causal congestion experiment or a final HCRAF strategy evaluation.
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/ndnSIM-module.h"
#include "ns3/ndnSIM/apps/ndn-app.hpp"
#include "ns3/ndnSIM/model/ndn-l3-protocol.hpp"
#include "ns3/ndnSIM/NFD/daemon/fw/forwarder.hpp"
#include <fstream>
#include "hcraf-collection-policy.hpp"
#include "hcraf-stage1w-monitor.hpp"
#include <set>
#include "ns3/error-model.h"
#include <stdexcept>

namespace ns3 {
class HcrafRequester : public ns3::ndn::App {
public:
  static TypeId GetTypeId() {
    static TypeId tid = TypeId("ns3::HcrafRequester").SetParent<ns3::ndn::App>()
      .AddConstructor<HcrafRequester>();
    return tid;
  }
  void Configure(const std::string& mode, const std::string& output, uint32_t sourceId = 0) {
    m_mode = mode;
    m_sourceId = sourceId;
    m_nonce = 1000 + 10000 * sourceId;
    m_out.open(output);
    m_arrivals.open(output + ".arrivals.jsonl");
    if(!m_arrivals)throw std::runtime_error("Cannot open arrival schedule");
    m_arrivals << std::setprecision(17);
    if (!m_out) throw std::runtime_error("Cannot open consumer event file");
  }
  void OnData(std::shared_ptr<const ::ndn::Data> data) override {
    ns3::ndn::App::OnData(data);
    m_out << "{\"event\":\"DATA\",\"time_ns\":" << Simulator::Now().GetNanoSeconds()
          << ",\"name\":" << hcraf::Recorder::quote(data->getName().toUri())
          << ",\"payload_bytes\":" << data->getContent().value_size() << "}\n";
    m_out.flush();
  }
  void OnNack(std::shared_ptr<const ::ndn::lp::Nack> nack) override {
    ns3::ndn::App::OnNack(nack);
    m_out << "{\"event\":\"NACK\",\"time_ns\":" << Simulator::Now().GetNanoSeconds()
          << ",\"name\":" << hcraf::Recorder::quote(nack->getInterest().getName().toUri())
          << ",\"reason\":" << static_cast<int>(nack->getReason()) << "}\n";
    m_out.flush();
  }
protected:
  void StartApplication() override {
    ns3::ndn::App::StartApplication();
    // Pre-registered fixed offered load: no traffic-generating RNG is required.
    // Deterministic input schedules, no fabricated packet outcomes.
    const uint32_t requests = 1u;
    for (uint32_t i=0; i<requests; ++i) {
      const int64_t time = 2000000000LL +
        (m_mode == "burst-identical" ? int64_t(i%4) * 500000LL + int64_t(i/4) * 1500000000LL :
         m_mode == "interleaved-retransmission" ? int64_t(i/2) * 1800000000LL + int64_t(i%2) * 100000000LL :
         int64_t(i) * 2000000LL);
      m_arrivals << "{\"sequence\":" << i << ",\"time_ns\":" << time
        << ",\"source_id\":" << m_sourceId
        << ",\"included\":true,\"schedule\":\"DETERMINISTIC_STAGE1U\"}\n";
      Simulator::Schedule(NanoSeconds(time),&HcrafRequester::Send,this,i);
    }
    m_arrivals.flush();if(!m_arrivals)throw std::runtime_error("Arrival trace failed");
  }
private:
  void Send(uint32_t sequence) {
    if (!m_active) return;
    const uint32_t nameId = (m_mode == "burst-identical") ? sequence % 2 :
                            (m_mode == "interleaved-retransmission") ? sequence / 2 : 0u;
    const bool prefixInterest = false;
    auto interest = std::make_shared<::ndn::Interest>(
      ::ndn::Name(prefixInterest ? "/hcraf/pilot" : "/hcraf/pilot/" + std::to_string(nameId)));
    interest->setNonce(++m_nonce);
    interest->setInterestLifetime(::ndn::time::milliseconds(1000));
    interest->setCanBePrefix(prefixInterest);
    interest->setMustBeFresh(true);
    m_out << "{\"event\":\"SEND\",\"time_ns\":" << Simulator::Now().GetNanoSeconds()
          << ",\"name\":" << hcraf::Recorder::quote(interest->getName().toUri())
          << ",\"nonce\":" << m_nonce << ",\"source_id\":" << m_sourceId << "}\n";
    m_out.flush();
    m_transmittedInterests(interest, this, m_face);
    m_appLink->onReceiveInterest(*interest);
  }
  uint32_t m_nonce = 1000;
  uint32_t m_sourceId = 0;
  std::string m_mode;
  std::ofstream m_out;
  std::ofstream m_arrivals;
};
NS_OBJECT_ENSURE_REGISTERED(HcrafRequester);

class HcrafResponder : public ns3::ndn::App {
public:
  static TypeId GetTypeId() {
    static TypeId tid = TypeId("ns3::HcrafResponder").SetParent<ns3::ndn::App>()
      .AddConstructor<HcrafResponder>();
    return tid;
  }
  void Configure(bool silent, double delay, bool forceLeaf, bool doubleReply, bool spontaneous, bool bigPayload) {
    m_silent = silent; m_delay = delay; m_forceLeaf = forceLeaf;
    m_doubleReply = doubleReply; m_spontaneous = spontaneous; m_bigPayload = bigPayload;
  }
  void OnInterest(std::shared_ptr<const ::ndn::Interest> interest) override {
    ns3::ndn::App::OnInterest(interest);
    if (!m_active || m_silent) return;
    auto name = m_forceLeaf ? ::ndn::Name("/hcraf/pilot/0") : interest->getName();
    Simulator::Schedule(Seconds(m_delay), &HcrafResponder::Reply, this, name);
    if (m_doubleReply) Simulator::Schedule(Seconds(m_delay + 0.0001), &HcrafResponder::Reply, this, name);
  }
protected:
  void StartApplication() override {
    ns3::ndn::App::StartApplication();
    ns3::ndn::FibHelper::AddRoute(GetNode(), "/hcraf", m_face, 0);
    if (m_spontaneous)
      Simulator::Schedule(Seconds(2.06), &HcrafResponder::Reply, this, ::ndn::Name("/hcraf/pilot/0"));
  }
private:
  void Reply(::ndn::Name name) {
    if (!m_active) return;
    auto data = std::make_shared<::ndn::Data>(name);
    data->setFreshnessPeriod(::ndn::time::milliseconds(1000));
    data->setContent(std::make_shared<::ndn::Buffer>(m_bigPayload ? 4096 : 1024));
    // Same simulation signature convention as the official ndnSIM Producer.
    ::ndn::SignatureInfo signature(static_cast<::ndn::tlv::SignatureTypeValue>(255));
    data->setSignatureInfo(signature);
    ::ndn::EncodingEstimator estimator;
    ::ndn::EncodingBuffer encoder(estimator.appendVarNumber(0), 0);
    encoder.appendVarNumber(0);
    data->setSignatureValue(encoder.getBuffer());
    data->wireEncode();
    m_transmittedDatas(data, this, m_face);
    m_appLink->onReceiveData(*data);
  }
  bool m_silent = false, m_forceLeaf = false, m_doubleReply = false, m_spontaneous = false, m_bigPayload = false;
  double m_delay = 0;
};
NS_OBJECT_ENSURE_REGISTERED(HcrafResponder);
}

static void RecordRxDrop(std::ofstream* out, ns3::Ptr<const ns3::Packet> packet) {
  *out << "{\"event\":\"PHY_RX_DROP\",\"node_id\":2,\"time_ns\":"
       << ns3::Simulator::Now().GetNanoSeconds() << ",\"packet_uid\":" << packet->GetUid() << "}\n";
  out->flush();
}

int main(int argc, char* argv[]) {
  using namespace ns3;
  std::string mode = "same-time-dual-face", output = ".";
  uint32_t seed = 1;
  uint64_t run = 1;
  CommandLine cmd;
  cmd.AddValue("mode", "same-time-dual-face/fragmented/multi-hop-fragmented", mode);
  cmd.AddValue("output", "Existing output directory", output);
  cmd.AddValue("seed", "ns-3 random seed", seed);
  cmd.AddValue("run", "ns-3 random run number", run);

  cmd.Parse(argc, argv);
  if (std::set<std::string>{"same-time-dual-face", "fragmented", "multi-hop-fragmented"}.count(mode) == 0)
    throw std::runtime_error("Unknown Stage1U scenario");

  RngSeedManager::SetSeed(seed); RngSeedManager::SetRun(run);
  NodeContainer nodes;
  nodes.Create(mode == "multi-hop-fragmented" ? 8u : 5u);
  PointToPointHelper link;
  link.SetQueue("ns3::DropTailQueue<Packet>", "MaxSize", StringValue("20p"));
  link.SetDeviceAttribute("InterframeGap", TimeValue(NanoSeconds(0)));
  link.SetDeviceAttribute("DataRate", StringValue("10Mbps"));
  link.SetChannelAttribute("Delay", StringValue("10ms"));
  link.Install(nodes.Get(0), nodes.Get(1));
  link.SetDeviceAttribute("DataRate", StringValue("10Mbps"));
  auto primaryDevices = link.Install(nodes.Get(1), nodes.Get(2));
  auto routerDevice = DynamicCast<PointToPointNetDevice>(primaryDevices.Get(0));
  auto producerDevice = DynamicCast<PointToPointNetDevice>(primaryDevices.Get(1));
  const uint64_t forwardRate = 10000000;
  const uint64_t returnRate = 10000000;
  routerDevice->SetDataRate(DataRate(forwardRate));
  producerDevice->SetDataRate(DataRate(returnRate));
  auto errors = CreateObject<RateErrorModel>();
  errors->SetUnit(RateErrorModel::ERROR_UNIT_PACKET);
  errors->SetRate(0.0);
  errors->AssignStreams(71);
  producerDevice->SetReceiveErrorModel(errors);
  std::ofstream faults(output + "/fault_events.jsonl");
  if (!faults) throw std::runtime_error("Cannot open fault log");
  if (!producerDevice->TraceConnectWithoutContext("PhyRxDrop", MakeBoundCallback(&RecordRxDrop, &faults)))
    throw std::runtime_error("Missing PhyRxDrop trace");
  link.SetDeviceAttribute("DataRate", StringValue(mode == "same-time-dual-face" ? "10Mbps" : "512kbps"));
  link.SetChannelAttribute("Delay", StringValue(mode == "same-time-dual-face" ? "10ms" : "30ms"));
  auto secondaryDevices = link.Install(nodes.Get(1), nodes.Get(3));
  link.SetDeviceAttribute("DataRate", StringValue(mode == "same-time-dual-face" ? "10Mbps" : "1Mbps"));
  link.SetChannelAttribute("Delay", StringValue(mode == "same-time-dual-face" ? "10ms" : "20ms"));
  auto thirdDevices=link.Install(nodes.Get(1),nodes.Get(4));
  if (mode == "multi-hop-fragmented") {
    link.SetDeviceAttribute("DataRate", StringValue("10Mbps"));
    link.SetChannelAttribute("Delay", StringValue("10ms"));
    link.Install(nodes.Get(2), nodes.Get(5));
    link.Install(nodes.Get(3), nodes.Get(6));
    link.Install(nodes.Get(4), nodes.Get(7));
  }
  // NFD NetDeviceTransport reads device MTU during StackHelper::InstallAll.
  // Constrain BOTH endpoints to ensure LP (not IP) fragmentation on these point-to-point faces.
  if (mode != "same-time-dual-face") {
    for (uint32_t n=0; n<nodes.GetN(); ++n) {
      auto node = nodes.Get(n);
      for (uint32_t d=0;d<node->GetNDevices();++d) {
        auto dev=DynamicCast<PointToPointNetDevice>(node->GetDevice(d));
        if (dev && !dev->SetMtu(600)) throw std::runtime_error("Cannot set test face MTU");
      }
    }
  }
  ns3::ndn::StackHelper stack;
  // Cache ONLY on the audited forwarding router: a consumer-local CS hit
  // would never reach the instrumented node and would confound the test.
  stack.setCsSize(0);
  stack.InstallAll();
  ns3::ndn::StrategyChoiceHelper::InstallAll("/hcraf", "/localhost/nfd/strategy/best-route");
  // Stage1U diagnostic only: two producer-contention modes need two or more
  // independently solicited replies. With BestRoute, only node 2 received an
  // Interest; unsolicited App::Reply on node 3 was discarded by its own NFD.
  // Do not change the HCRAF forwarding strategy or other 1U control modes.
  if (mode == "same-time-dual-face") {
    ns3::ndn::StrategyChoiceHelper::Install(nodes.Get(1), "/hcraf",
      "/localhost/nfd/strategy/multicast");
  }
  ns3::ndn::FibHelper::AddRoute(nodes.Get(0), "/hcraf", nodes.Get(1), 1);
  ns3::ndn::FibHelper::AddRoute(nodes.Get(1), "/hcraf", nodes.Get(2), 1);
  ns3::ndn::FibHelper::AddRoute(nodes.Get(1), "/hcraf", nodes.Get(3), 2);
  ns3::ndn::FibHelper::AddRoute(nodes.Get(1), "/hcraf", nodes.Get(4), 3);
  if (mode == "multi-hop-fragmented") {
    for (uint32_t n = 2; n <= 4; ++n)
      ns3::ndn::FibHelper::AddRoute(nodes.Get(n), "/hcraf", nodes.Get(n+3), 1);
  }
  const std::vector<uint32_t> producerNodes = mode == "multi-hop-fragmented" ?
    std::vector<uint32_t>{5u,6u,7u} : std::vector<uint32_t>{2u,3u,4u};
  for (uint32_t n : producerNodes) {
    auto responder = CreateObject<HcrafResponder>();
    responder->Configure(false,
      0.06,
      false, false, false, mode != "same-time-dual-face"); // large Data requires NDN-LP fragmentation
    nodes.Get(n)->AddApplication(responder); responder->SetStartTime(Seconds(0));
  }
  auto requester = CreateObject<HcrafRequester>();
  requester->Configure(mode, output + "/consumer_events.jsonl", 0);
  nodes.Get(0)->AddApplication(requester); requester->SetStartTime(Seconds(0));
  auto l3 = nodes.Get(1)->GetObject<ns3::ndn::L3Protocol>();
  auto primary = l3->getFaceByNetDevice(primaryDevices.Get(0));
  auto secondary = l3->getFaceByNetDevice(secondaryDevices.Get(0));
  auto third=l3->getFaceByNetDevice(thirdDevices.Get(0));
  if (!primary || !secondary || !third) throw std::runtime_error("Missing upstream Face mapping");
  auto forwarder = l3->getForwarder();
  forwarder->hcrafEnable(output + "/events.jsonl", nodes.Get(1)->GetId());
  std::shared_ptr<nfd::Forwarder> secondaryForwarder;
  if (mode == "multi-hop-fragmented") {
    auto l3b = nodes.Get(2)->GetObject<ns3::ndn::L3Protocol>();
    secondaryForwarder = l3b->getForwarder();
    secondaryForwarder->hcrafEnable(output + "/events_hop2.jsonl", nodes.Get(2)->GetId());
  }
  auto probeRng = CreateObject<UniformRandomVariable>();
  probeRng->SetStream(20);
  // The coverage collector requires a fresh PIT. Do NOT run it on duplicated
  // or aggregated Interests: preserve native NFD retransmission semantics.
  // Native BestRoute: no collector's fresh-PIT-only override in a contention experiment.
  (void)probeRng;
  HcrafStage1wMonitor linkMonitor(nodes, output + "/link_events.jsonl");
  forwarder->hcrafSetDecisionObserver([&linkMonitor](uint64_t id) { linkMonitor.Snapshot(id); });
  std::ofstream control(output + "/control_events.jsonl");
  if (!control) throw std::runtime_error("Cannot open control log");
  std::ofstream config(output + "/scenario.json");
  const uint32_t offered = 1u;
  config << "{\"mode\":" << hcraf::Recorder::quote(mode)
    << ",\"collector_stage\":\"1W.0\",\"selection_policy\":"
    << hcraf::Recorder::quote(
         (mode == "same-time-dual-face") ?
         "diagnostic_multicast" : "native_best_route")
    << ",\"purpose\":\"CONCURRENT_INGRESS_LP_FRAGMENTATION_CROSS_HOP_NOT_TRAINING\""
    << ",\"seed\":" << seed << ",\"run\":" << run
    << ",\"planned_requests\":" << offered
    << ",\"stop_ns\":16000000000,\"decision_node_id\":1"
    << ",\"interest_lifetime_ms\":1000,\"queue_capacity_packets\":20"
    << ",\"cache_enabled\":false"
    << ",\"router_strategy\":" << hcraf::Recorder::quote(
       (mode == "same-time-dual-face") ?
       "diagnostic_multicast" : "native_best_route")
    << ",\"multi_hop_enabled\":" << (mode=="multi-hop-fragmented"?"true":"false")
    << ",\"mtu_bytes\":" << (mode=="same-time-dual-face"?1500:600)
    << ",\"payload_bytes\":" << (mode=="same-time-dual-face"?1024:4096)
    << ",\"primary_face_id\":" << primary->getId()
    << ",\"secondary_face_id\":" << secondary->getId()
    << ",\"third_face_id\":" << third->getId()
    << ",\"observability_monitors_all_point_to_point_directions\":true"
    << ",\"queue_trace_schema\":\"1W.0\",\"data_pit_schema\":\"1U.1\",\"final_congestion_label\":null"
    << ",\"future_congestion_label\":null,\"causal_congestion_attribution\":null"
    << ",\"training_ready\":false}\n";
  config.flush();
  if (!config) throw std::runtime_error("Cannot write configuration");
  config.close();
  Simulator::Stop(Seconds(16)); Simulator::Run();
  forwarder->hcrafFinish(); forwarder->hcrafSetDecisionObserver({});
  if (secondaryForwarder) secondaryForwarder->hcrafFinish();
  linkMonitor.Finish();
  Simulator::Destroy();
  return 0;
}
