#ifndef HCRAF_WIRE_DECODE_HPP
#define HCRAF_WIRE_DECODE_HPP
// Stage1R bounded NDN-TLV identifier reader for controlled, unfragmented pilot traffic.
// Pure C++11; no forwarding changes. Fail closed on unsupported encoding or fragments.
#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>
#include <limits>

namespace hcraf { namespace wire {
struct Identity {
  std::string status = "UNDECODED";  // PILOT, NON_PILOT, INVALID, UNSUPPORTED
  std::string kind;                   // INTEREST/DATA when unambiguous
  std::string name;                   // decoded NDN name, if supported
  bool hasNonce = false;
  uint32_t nonce = 0;
  int offset = -1;                    // PPP-stripping offset (0 or 2)
};
struct Tlv {
  uint64_t type = 0;
  size_t value = 0;
  size_t end = 0;
};
inline bool varnum(const std::vector<uint8_t>& d, size_t& p, size_t stop, uint64_t& v) {
  if (p >= stop) return false;
  const uint8_t a=d[p++];
  if (a < 253) { v=a; return true; }
  const size_t n=a==253?2:a==254?4:8;
  if (n>stop-p) return false;
  uint64_t value=0;
  for(size_t i=0;i<n;++i) value=(value<<8)|d[p++];
  if (value<253 || (n==4 && value<=65535) || (n==8 && value<=4294967295ULL)) return false;
  v=value;
  return true;
}
inline bool tlv(const std::vector<uint8_t>& d, size_t& p, size_t stop, Tlv& t) {
  uint64_t type=0,length=0;
  if(!varnum(d,p,stop,type)||!varnum(d,p,stop,length) || length>stop-p) return false;
  t.type=type;t.value=p;t.end=p+static_cast<size_t>(length);p=t.end;
  return true;
}
inline std::string pct(uint8_t c) {
  if ((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='-'||c=='.'||c=='_'||c=='~')
    return std::string(1,static_cast<char>(c));
  const char* hex="0123456789ABCDEF";
  return std::string("%")+hex[(c>>4)&15]+hex[c&15];
}
inline bool name(const std::vector<uint8_t>& d, const Tlv& n, std::string& out) {
  size_t p=n.value, count=0;
  while (p<n.end) {
    Tlv c;
    if (!tlv(d,p,n.end,c) || c.type!=8 || ++count>64 || c.end-c.value>4096) return false;
    out.push_back('/');
    for(size_t i=c.value;i<c.end;++i) out+=pct(d[i]);
  }
  return count>0;
}
inline Identity parseOne(const std::vector<uint8_t>& d, size_t off, size_t stop, int depth) {
  Identity out;out.offset=static_cast<int>(off);out.status="INVALID";
  if (depth>2 || off>=stop) return out;
  size_t p=off;Tlv root;
  if (!tlv(d,p,stop,root)||p!=stop) return out;
  if(root.type==100) { // NDNLPv2 LpPacket, type 100. Fragment TLV type 80.
    size_t n=root.value;size_t fragmentCount=0; Tlv fragment;
    while(n<root.end) {
      Tlv field;
      if(!tlv(d,n,root.end,field)) return out;
      if(field.type==80) {fragment=field;++fragmentCount;}
    }
    if(fragmentCount!=1) {out.status="UNSUPPORTED";return out;}
    Identity inner=parseOne(d,fragment.value,fragment.end,depth+1);
    // Caller receives original start offset, not nested Fragment value offset.
    inner.offset=static_cast<int>(off);
    return inner;
  }
  if(root.type!=5 && root.type!=6) {out.status="UNSUPPORTED";return out;}
  out.kind=root.type==5?"INTEREST":"DATA";
  size_t n=root.value, nameCount=0, nonceCount=0;
  while(n<root.end) {
    Tlv field;
    if(!tlv(d,n,root.end,field)) return out;
    if(field.type==7) {
      if(++nameCount!=1 || !name(d,field,out.name)) return out;
    }
    if(field.type==10 && root.type==5) {
      if(++nonceCount!=1 || field.end-field.value!=4) return out;
      out.hasNonce=true;
      out.nonce=(uint32_t(d[field.value])<<24)|(uint32_t(d[field.value+1])<<16)|
                (uint32_t(d[field.value+2])<<8)|uint32_t(d[field.value+3]);
    }
  }
  if(nameCount!=1 || (root.type==5 && nonceCount!=1)) {
    out.status="UNSUPPORTED";return out;
  }
  if(out.name.compare(0,13,"/hcraf/pilot/")==0 && out.name.size()>13)
    out.status="PILOT";
  else out.status="NON_PILOT";
  return out;
}
inline Identity decode(const std::vector<uint8_t>& bytes) {
  Identity a=parseOne(bytes,0,bytes.size(),0);
  if(a.status=="PILOT" || a.status=="NON_PILOT") return a;
  // PointToPoint NetDevice queue includes a 2-byte PPP protocol header.
  if(bytes.size()>2) {
    Identity b=parseOne(bytes,2,bytes.size(),0);
    if(b.status=="PILOT" || b.status=="NON_PILOT") return b;
  }
  return a;
}
}} // namespace
#endif
