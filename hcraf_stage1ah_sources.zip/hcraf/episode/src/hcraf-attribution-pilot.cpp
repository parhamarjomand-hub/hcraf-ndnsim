// Controlled ndnSIM integration tests, NOT an HCRAF performance experiment.
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/ndnSIM-module.h"
#include "ns3/ndnSIM/apps/ndn-app.hpp"
#include "ns3/ndnSIM/model/ndn-l3-protocol.hpp"
#include "ns3/ndnSIM/NFD/daemon/fw/forwarder.hpp"
#include <fstream>
#include "hcraf-collection-policy.hpp"
#include "hcraf-attribution-monitor.hpp"
#include <set>
#include "ns3/error-model.h"
#include <stdexcept>

namespace ns3 {
class HcrafRequester : public ns3::ndn::App {
public:
  static TypeId GetTypeId() {
    static TypeId tid = TypeId("ns3::HcrafRequester").SetParent<ns3::ndn::App>()
      .AddConstructor<HcrafRequester>();
    return tid;
  }
  void Configure(const std::string& mode, const std::string& output) {
    m_mode = mode;
    m_out.open(output);
    m_arrivals.open(output + ".arrivals.jsonl");
    if(!m_arrivals)throw std::runtime_error("Cannot open arrival schedule");
    m_arrivals << std::setprecision(17);
    if (!m_out) throw std::runtime_error("Cannot open consumer event file");
  }
  void OnData(std::shared_ptr<const ::ndn::Data> data) override {
    ns3::ndn::App::OnData(data);
    m_out << "{\"event\":\"DATA\",\"time_ns\":" << Simulator::Now().GetNanoSeconds()
          << ",\"name\":" << hcraf::Recorder::quote(data->getName().toUri())
          << ",\"payload_bytes\":" << data->getContent().value_size() << "}\n";
    m_out.flush();
  }
  void OnNack(std::shared_ptr<const ::ndn::lp::Nack> nack) override {
    ns3::ndn::App::OnNack(nack);
    m_out << "{\"event\":\"NACK\",\"time_ns\":" << Simulator::Now().GetNanoSeconds()
          << ",\"name\":" << hcraf::Recorder::quote(nack->getInterest().getName().toUri())
          << ",\"reason\":" << static_cast<int>(nack->getReason()) << "}\n";
    m_out.flush();
  }
protected:
  void StartApplication() override {
    ns3::ndn::App::StartApplication();
    // Pre-registered fixed offered load: no traffic-generating RNG is required.
    // 1 ms spacing avoids an access-device burst artifact. One Interest per name.
    const bool overflow = m_mode == "forward-overflow" || m_mode == "return-overflow";
    const bool buffered = m_mode == "forward-buffered" || m_mode == "return-buffered";
    const uint32_t requests = overflow ? 120u : (buffered ? 18u : 12u);
    const int64_t interval = m_mode == "baseline" ? 100000000LL : 1000000LL;
    for (uint32_t i=0; i<requests; ++i) {
      const int64_t time = 2000000000LL + int64_t(i) * interval;
      m_arrivals << "{\"sequence\":" << i << ",\"time_ns\":" << time
        << ",\"included\":true,\"schedule\":\"DETERMINISTIC_STAGE1R\"}\n";
      Simulator::Schedule(NanoSeconds(time),&HcrafRequester::Send,this,i);
    }
    m_arrivals.flush();if(!m_arrivals)throw std::runtime_error("Arrival trace failed");
  }
private:
  void Send(uint32_t sequence) {
    if (!m_active) return;
    auto interest = std::make_shared<::ndn::Interest>(::ndn::Name("/hcraf/pilot/" + std::to_string(sequence)));
    interest->setNonce(++m_nonce);
    interest->setInterestLifetime(::ndn::time::milliseconds(1000));
    interest->setCanBePrefix(false);
    interest->setMustBeFresh(true);
    m_out << "{\"event\":\"SEND\",\"time_ns\":" << Simulator::Now().GetNanoSeconds()
          << ",\"name\":" << hcraf::Recorder::quote(interest->getName().toUri())
          << ",\"nonce\":" << m_nonce << "}\n";
    m_out.flush();
    m_transmittedInterests(interest, this, m_face);
    m_appLink->onReceiveInterest(*interest);
  }
  uint32_t m_nonce = 1000;
  std::string m_mode;
  std::ofstream m_out;
  std::ofstream m_arrivals;
};
NS_OBJECT_ENSURE_REGISTERED(HcrafRequester);

class HcrafResponder : public ns3::ndn::App {
public:
  static TypeId GetTypeId() {
    static TypeId tid = TypeId("ns3::HcrafResponder").SetParent<ns3::ndn::App>()
      .AddConstructor<HcrafResponder>();
    return tid;
  }
  void Configure(bool silent, double delay) { m_silent = silent; m_delay = delay; }
  void OnInterest(std::shared_ptr<const ::ndn::Interest> interest) override {
    ns3::ndn::App::OnInterest(interest);
    if (!m_active || m_silent) return;
    Simulator::Schedule(Seconds(m_delay), &HcrafResponder::Reply, this, interest->getName());
  }
protected:
  void StartApplication() override {
    ns3::ndn::App::StartApplication();
    ns3::ndn::FibHelper::AddRoute(GetNode(), "/hcraf", m_face, 0);
  }
private:
  void Reply(::ndn::Name name) {
    if (!m_active) return;
    auto data = std::make_shared<::ndn::Data>(name);
    data->setFreshnessPeriod(::ndn::time::milliseconds(1000));
    data->setContent(std::make_shared<::ndn::Buffer>(1024));
    // Same simulation signature convention as the official ndnSIM Producer.
    ::ndn::SignatureInfo signature(static_cast<::ndn::tlv::SignatureTypeValue>(255));
    data->setSignatureInfo(signature);
    ::ndn::EncodingEstimator estimator;
    ::ndn::EncodingBuffer encoder(estimator.appendVarNumber(0), 0);
    encoder.appendVarNumber(0);
    data->setSignatureValue(encoder.getBuffer());
    data->wireEncode();
    m_transmittedDatas(data, this, m_face);
    m_appLink->onReceiveData(*data);
  }
  bool m_silent = false;
  double m_delay = 0;
};
NS_OBJECT_ENSURE_REGISTERED(HcrafResponder);
}

static void RecordRxDrop(std::ofstream* out, ns3::Ptr<const ns3::Packet> packet) {
  *out << "{\"event\":\"PHY_RX_DROP\",\"node_id\":2,\"time_ns\":"
       << ns3::Simulator::Now().GetNanoSeconds() << ",\"packet_uid\":" << packet->GetUid() << "}\n";
  out->flush();
}

int main(int argc, char* argv[]) {
  using namespace ns3;
  std::string mode = "baseline", output = ".";
  uint32_t seed = 1;
  uint64_t run = 1;
  CommandLine cmd;
  cmd.AddValue("mode", "baseline/forward-buffered/return-buffered/forward-overflow/return-overflow", mode);
  cmd.AddValue("output", "Existing output directory", output);
  cmd.AddValue("seed", "ns-3 random seed", seed);
  cmd.AddValue("run", "ns-3 random run number", run);

  cmd.Parse(argc, argv);
  if (std::set<std::string>{"baseline", "forward-buffered", "return-buffered",
                            "forward-overflow", "return-overflow"}.count(mode) == 0)
    throw std::runtime_error("Unknown Stage1P scenario");

  RngSeedManager::SetSeed(seed); RngSeedManager::SetRun(run);
  NodeContainer nodes; nodes.Create(5);
  PointToPointHelper link;
  link.SetQueue("ns3::DropTailQueue<Packet>", "MaxSize", StringValue("20p"));
  link.SetDeviceAttribute("InterframeGap", TimeValue(NanoSeconds(0)));
  link.SetDeviceAttribute("DataRate", StringValue("10Mbps"));
  link.SetChannelAttribute("Delay", StringValue("10ms"));
  link.Install(nodes.Get(0), nodes.Get(1));
  link.SetDeviceAttribute("DataRate", StringValue("10Mbps"));
  auto primaryDevices = link.Install(nodes.Get(1), nodes.Get(2));
  auto routerDevice = DynamicCast<PointToPointNetDevice>(primaryDevices.Get(0));
  auto producerDevice = DynamicCast<PointToPointNetDevice>(primaryDevices.Get(1));
  const uint64_t forwardRate = mode == "forward-buffered" ? 32000 :
                               mode == "forward-overflow" ? 8000 : 10000000;
  const uint64_t returnRate = mode == "return-buffered" ? 64000 :
                              mode == "return-overflow" ? 16000 : 10000000;
  routerDevice->SetDataRate(DataRate(forwardRate));
  producerDevice->SetDataRate(DataRate(returnRate));
  auto errors = CreateObject<RateErrorModel>();
  errors->SetUnit(RateErrorModel::ERROR_UNIT_PACKET);
  errors->SetRate(0.0);
  errors->AssignStreams(71);
  producerDevice->SetReceiveErrorModel(errors);
  std::ofstream faults(output + "/fault_events.jsonl");
  if (!faults) throw std::runtime_error("Cannot open fault log");
  if (!producerDevice->TraceConnectWithoutContext("PhyRxDrop", MakeBoundCallback(&RecordRxDrop, &faults)))
    throw std::runtime_error("Missing PhyRxDrop trace");
  link.SetDeviceAttribute("DataRate", StringValue("512kbps"));
  link.SetChannelAttribute("Delay", StringValue("30ms"));
  auto secondaryDevices = link.Install(nodes.Get(1), nodes.Get(3));
  link.SetDeviceAttribute("DataRate", StringValue("1Mbps"));
  link.SetChannelAttribute("Delay", StringValue("20ms"));
  auto thirdDevices=link.Install(nodes.Get(1),nodes.Get(4));
  ns3::ndn::StackHelper stack; stack.setCsSize(0); stack.InstallAll();
  ns3::ndn::StrategyChoiceHelper::InstallAll("/hcraf", "/localhost/nfd/strategy/best-route");
  ns3::ndn::FibHelper::AddRoute(nodes.Get(0), "/hcraf", nodes.Get(1), 1);
  ns3::ndn::FibHelper::AddRoute(nodes.Get(1), "/hcraf", nodes.Get(2), 1);
  ns3::ndn::FibHelper::AddRoute(nodes.Get(1), "/hcraf", nodes.Get(3), 2);
  ns3::ndn::FibHelper::AddRoute(nodes.Get(1), "/hcraf", nodes.Get(4), 3);
  for (uint32_t n : {2u, 3u, 4u}) {
    auto responder = CreateObject<HcrafResponder>(); responder->Configure(false, 0.0);
    nodes.Get(n)->AddApplication(responder); responder->SetStartTime(Seconds(0));
  }
  auto requester = CreateObject<HcrafRequester>();
  requester->Configure(mode, output + "/consumer_events.jsonl");
  nodes.Get(0)->AddApplication(requester); requester->SetStartTime(Seconds(0));
  auto l3 = nodes.Get(1)->GetObject<ns3::ndn::L3Protocol>();
  auto primary = l3->getFaceByNetDevice(primaryDevices.Get(0));
  auto secondary = l3->getFaceByNetDevice(secondaryDevices.Get(0));
  auto third=l3->getFaceByNetDevice(thirdDevices.Get(0));
  if (!primary || !secondary || !third) throw std::runtime_error("Missing upstream Face mapping");
  auto forwarder = l3->getForwarder();
  forwarder->hcrafEnable(output + "/events.jsonl", nodes.Get(1)->GetId());
  auto probeRng = CreateObject<UniformRandomVariable>();
  probeRng->SetStream(20);
  forwarder->hcrafEnableCoverage([probeRng]() { return probeRng->GetValue(0.0, 1.0); }, false);
  HcrafAttributionMonitor linkMonitor(nodes, output + "/link_events.jsonl");
  forwarder->hcrafSetDecisionObserver([&linkMonitor](uint64_t id) { linkMonitor.Snapshot(id); });
  std::ofstream control(output + "/control_events.jsonl");
  if (!control) throw std::runtime_error("Cannot open control log");
  std::ofstream config(output + "/scenario.json");
  const bool overflow = mode == "forward-overflow" || mode == "return-overflow";
  const bool buffered = mode == "forward-buffered" || mode == "return-buffered";
  const uint32_t offered = overflow ? 120u : buffered ? 18u : 12u;
  config << "{\"mode\":" << hcraf::Recorder::quote(mode)
    << ",\"collector_stage\":\"1R.1\",\"selection_policy\":\"uniform\""
    << ",\"purpose\":\"OBSERVABILITY_DIAGNOSTIC_NOT_TRAINING\""
    << ",\"seed\":" << seed << ",\"run\":" << run
    << ",\"planned_requests\":" << offered
    << ",\"traffic_start_ns\":2000000000,\"interval_ns\":" << (mode=="baseline" ? 100000000 : 1000000)
    << ",\"stop_ns\":13000000000,\"decision_node_id\":1"
    << ",\"interest_lifetime_ms\":1000,\"queue_capacity_packets\":20"
    << ",\"primary_forward_bps\":" << forwardRate
    << ",\"primary_return_bps\":" << returnRate
    << ",\"primary_face_id\":" << primary->getId()
    << ",\"secondary_face_id\":" << secondary->getId()
    << ",\"third_face_id\":" << third->getId()
    << ",\"observability_monitors_all_point_to_point_directions\":true"
    << ",\"queue_trace_schema\":\"1R.1\",\"final_congestion_label\":null"
    << ",\"future_congestion_label\":null,\"training_ready\":false}\n";
  config.flush();
  if (!config) throw std::runtime_error("Cannot write configuration");
  config.close();
  Simulator::Stop(Seconds(13)); Simulator::Run();
  forwarder->hcrafFinish(); forwarder->hcrafSetDecisionObserver({}); linkMonitor.Finish();
  Simulator::Destroy();
  return 0;
}
