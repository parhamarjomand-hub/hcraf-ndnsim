// Stage1AB independent two-hop feasibility pilot, NOT HCRAF evaluation.
// A control name is NOT evidence of occurrence. Never creates F3 training labels.
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/ndnSIM-module.h"
#include "ns3/ndnSIM/apps/ndn-app.hpp"
#include "ns3/ndnSIM/model/ndn-l3-protocol.hpp"
#include "ns3/ndnSIM/NFD/daemon/fw/forwarder.hpp"
#include <fstream>
#include "hcraf-collection-policy.hpp"
#include "hcraf-stage1w-monitor.hpp"
#include <set>
#include "ns3/error-model.h"
#include <stdexcept>
#include <memory>
#include <chrono>

namespace ns3 {
class HcrafRequester : public ns3::ndn::App {
public:
  static TypeId GetTypeId() {
    static TypeId tid = TypeId("ns3::HcrafRequester").SetParent<ns3::ndn::App>()
      .AddConstructor<HcrafRequester>();
    return tid;
  }
  void Configure(const std::string& mode, const std::string& output, uint32_t sourceId = 0) {
    m_mode = mode;
    m_sourceId = sourceId;
    m_nonce = 1000 + 10000 * sourceId;
    m_out.open(output);
    m_arrivals.open(output + ".arrivals.jsonl");
    if(!m_arrivals)throw std::runtime_error("Cannot open arrival schedule");
    m_arrivals << std::setprecision(17);
    if (!m_out) throw std::runtime_error("Cannot open consumer event file");
  }
  void OnData(std::shared_ptr<const ::ndn::Data> data) override {
    ns3::ndn::App::OnData(data);
    m_out << "{\"event\":\"DATA\",\"time_ns\":" << Simulator::Now().GetNanoSeconds()
          << ",\"name\":" << hcraf::Recorder::quote(data->getName().toUri())
          << ",\"payload_bytes\":" << data->getContent().value_size() << "}\n";
    m_out.flush();
  }
  void OnNack(std::shared_ptr<const ::ndn::lp::Nack> nack) override {
    ns3::ndn::App::OnNack(nack);
    m_out << "{\"event\":\"NACK\",\"time_ns\":" << Simulator::Now().GetNanoSeconds()
          << ",\"name\":" << hcraf::Recorder::quote(nack->getInterest().getName().toUri())
          << ",\"reason\":" << static_cast<int>(nack->getReason()) << "}\n";
    m_out.flush();
  }
protected:
  void StartApplication() override {
    ns3::ndn::App::StartApplication();
    // Fixed protocol; change only after registration. Jitter uses an ns-3 RNG
    // with fixed stream so changing RngRun changes actual input, not only a label.
    const bool overflow = m_mode == "forward-overflow" || m_mode == "return-overflow";
    const bool buffered = m_mode == "forward-buffered" || m_mode == "return-buffered";
    const bool mixed = m_mode == "mixed-fragmented";
    const uint32_t requests = m_mode == "idle" ? 0u : overflow ? 120u : buffered ? 18u :
                              m_mode == "receive-loss" ? 40u : mixed ? 24u : 16u;
    const int64_t interval = overflow || buffered ? 1000000LL : mixed ? 250000000LL :
                             m_mode == "receive-loss" ? 10000000LL : 100000000LL;
    auto jitter = CreateObject<UniformRandomVariable>();
    jitter->SetStream(129);
    for (uint32_t i=0; i<requests; ++i) {
      const int64_t jitterNs = int64_t(jitter->GetInteger(0, 99999));
      const int64_t time = 2000000000LL + int64_t(i)*interval + jitterNs;
      m_arrivals << "{\"sequence\":" << i << ",\"time_ns\":" << time
        << ",\"jitter_ns\":" << jitterNs
        << ",\"included\":true,\"schedule\":\"STAGE1AB_DEV_RNG_STREAM_129\"}\n";
      Simulator::Schedule(NanoSeconds(time), &HcrafRequester::Send, this, i);
    }
    m_arrivals.flush();if(!m_arrivals)throw std::runtime_error("Arrival trace failed");
  }
private:
  void Send(uint32_t sequence) {
    if (!m_active) return;
    const uint32_t nameId = sequence;
    const bool prefixInterest = false;
    auto interest = std::make_shared<::ndn::Interest>(
      ::ndn::Name(prefixInterest ? "/hcraf/pilot" : "/hcraf/pilot/" + std::to_string(nameId)));
    interest->setNonce(++m_nonce);
    interest->setInterestLifetime(::ndn::time::milliseconds(1000));
    interest->setCanBePrefix(prefixInterest);
    interest->setMustBeFresh(true);
    m_out << "{\"event\":\"SEND\",\"time_ns\":" << Simulator::Now().GetNanoSeconds()
          << ",\"name\":" << hcraf::Recorder::quote(interest->getName().toUri())
          << ",\"nonce\":" << m_nonce << ",\"source_id\":" << m_sourceId << "}\n";
    m_out.flush();
    m_transmittedInterests(interest, this, m_face);
    m_appLink->onReceiveInterest(*interest);
  }
  uint32_t m_nonce = 1000;
  uint32_t m_sourceId = 0;
  std::string m_mode;
  std::ofstream m_out;
  std::ofstream m_arrivals;
};
NS_OBJECT_ENSURE_REGISTERED(HcrafRequester);

class HcrafResponder : public ns3::ndn::App {
public:
  static TypeId GetTypeId() {
    static TypeId tid = TypeId("ns3::HcrafResponder").SetParent<ns3::ndn::App>()
      .AddConstructor<HcrafResponder>();
    return tid;
  }
  void Configure(bool silent, double delay, bool forceLeaf, bool doubleReply, bool spontaneous, bool bigPayload) {
    m_silent = silent; m_delay = delay; m_forceLeaf = forceLeaf;
    m_doubleReply = doubleReply; m_spontaneous = spontaneous; m_bigPayload = bigPayload;
  }
  void OnInterest(std::shared_ptr<const ::ndn::Interest> interest) override {
    ns3::ndn::App::OnInterest(interest);
    if (!m_active || m_silent) return;
    auto name = m_forceLeaf ? ::ndn::Name("/hcraf/pilot/0") : interest->getName();
    Simulator::Schedule(Seconds(m_delay), &HcrafResponder::Reply, this, name);
    if (m_doubleReply) Simulator::Schedule(Seconds(m_delay + 0.0001), &HcrafResponder::Reply, this, name);
  }
protected:
  void StartApplication() override {
    ns3::ndn::App::StartApplication();
    ns3::ndn::FibHelper::AddRoute(GetNode(), "/hcraf", m_face, 0);
    if (m_spontaneous)
      Simulator::Schedule(Seconds(2.06), &HcrafResponder::Reply, this, ::ndn::Name("/hcraf/pilot/0"));
  }
private:
  void Reply(::ndn::Name name) {
    if (!m_active) return;
    auto data = std::make_shared<::ndn::Data>(name);
    data->setFreshnessPeriod(::ndn::time::milliseconds(1000));
    data->setContent(std::make_shared<::ndn::Buffer>(m_bigPayload ? 4096 : 1024));
    // Same simulation signature convention as the official ndnSIM Producer.
    ::ndn::SignatureInfo signature(static_cast<::ndn::tlv::SignatureTypeValue>(255));
    data->setSignatureInfo(signature);
    ::ndn::EncodingEstimator estimator;
    ::ndn::EncodingBuffer encoder(estimator.appendVarNumber(0), 0);
    encoder.appendVarNumber(0);
    data->setSignatureValue(encoder.getBuffer());
    data->wireEncode();
    m_transmittedDatas(data, this, m_face);
    m_appLink->onReceiveData(*data);
  }
  bool m_silent = false, m_forceLeaf = false, m_doubleReply = false, m_spontaneous = false, m_bigPayload = false;
  double m_delay = 0;
};
NS_OBJECT_ENSURE_REGISTERED(HcrafResponder);
}

static void RecordRxDrop(std::ofstream* out, ns3::Ptr<const ns3::Packet> packet) {
  *out << "{\"event\":\"PHY_RX_DROP\",\"node_id\":2,\"time_ns\":"
       << ns3::Simulator::Now().GetNanoSeconds() << ",\"packet_uid\":" << packet->GetUid() << "}\n";
  out->flush();
}

int main(int argc, char* argv[]) {
  using namespace ns3;
  std::string mode = "low-load", output = ".";
  uint32_t seed = 1;
  uint64_t run = 1;
  bool instrument = true;
  CommandLine cmd;
  cmd.AddValue("mode", "idle/low-load/forward-buffered/return-buffered/forward-overflow/return-overflow/receive-loss/propagation-only/no-route/mixed-fragmented", mode);
  cmd.AddValue("output", "Existing output directory", output);
  cmd.AddValue("seed", "ns-3 random seed", seed);
  cmd.AddValue("run", "ns-3 random run number", run);
  cmd.AddValue("instrument", "Enable event and queue monitor (1/0)", instrument);

  cmd.Parse(argc, argv);
  if (std::set<std::string>{"idle", "low-load", "forward-buffered", "return-buffered",
      "forward-overflow", "return-overflow", "receive-loss", "propagation-only",
      "no-route", "mixed-fragmented"}.count(mode) == 0)
    throw std::runtime_error("Unknown Stage1AB control");

  RngSeedManager::SetSeed(seed); RngSeedManager::SetRun(run);
  NodeContainer nodes;
  const bool fragmented = mode == "mixed-fragmented";
  const bool mixed = true; // 1AB always uses eight-node, complete two-router path.
  nodes.Create(8u);
  PointToPointHelper link;
  link.SetQueue("ns3::DropTailQueue<Packet>", "MaxSize", StringValue("20p"));
  link.SetDeviceAttribute("InterframeGap", TimeValue(NanoSeconds(0)));
  link.SetDeviceAttribute("DataRate", StringValue("10Mbps"));
  link.SetChannelAttribute("Delay", StringValue("10ms"));
  link.Install(nodes.Get(0), nodes.Get(1));
  link.SetDeviceAttribute("DataRate", StringValue("10Mbps"));
  if (mode == "propagation-only") link.SetChannelAttribute("Delay", StringValue("250ms"));
  auto primaryDevices = link.Install(nodes.Get(1), nodes.Get(2));
  auto routerDevice = DynamicCast<PointToPointNetDevice>(primaryDevices.Get(0));
  auto producerDevice = DynamicCast<PointToPointNetDevice>(primaryDevices.Get(1));
  const uint64_t forwardRate = mode == "forward-buffered" ? 32000 :
    mode == "forward-overflow" ? 8000 : 10000000;
  const uint64_t returnRate = mode == "return-buffered" ? 64000 :
    mode == "return-overflow" ? 16000 : fragmented ? 256000 : 10000000;
  routerDevice->SetDataRate(DataRate(forwardRate));
  producerDevice->SetDataRate(DataRate(returnRate));
  auto errors = CreateObject<RateErrorModel>();
  errors->SetUnit(RateErrorModel::ERROR_UNIT_PACKET);
  errors->SetRate(mode == "receive-loss" ? 0.25 : 0.0);
  errors->AssignStreams(71);
  producerDevice->SetReceiveErrorModel(errors);
  std::ofstream faults(output + "/fault_events.jsonl");
  if (!faults) throw std::runtime_error("Cannot open fault log");
  if (!producerDevice->TraceConnectWithoutContext("PhyRxDrop", MakeBoundCallback(&RecordRxDrop, &faults)))
    throw std::runtime_error("Missing PhyRxDrop trace");
  link.SetDeviceAttribute("DataRate", StringValue("512kbps"));
  link.SetChannelAttribute("Delay", StringValue("30ms"));
  auto secondaryDevices = link.Install(nodes.Get(1), nodes.Get(3));
  link.SetDeviceAttribute("DataRate", StringValue("1Mbps"));
  link.SetChannelAttribute("Delay", StringValue("20ms"));
  auto thirdDevices=link.Install(nodes.Get(1),nodes.Get(4));
  if (mixed) {
    link.SetDeviceAttribute("DataRate", StringValue("10Mbps"));
    link.SetChannelAttribute("Delay", StringValue("10ms"));
    link.Install(nodes.Get(2), nodes.Get(5));
    link.Install(nodes.Get(3), nodes.Get(6));
    link.Install(nodes.Get(4), nodes.Get(7));
  }
  // NFD NetDeviceTransport reads device MTU during StackHelper::InstallAll.
  // Constrain BOTH endpoints to ensure LP (not IP) fragmentation on these point-to-point faces.
  if (fragmented) {
    for (uint32_t n=0; n<nodes.GetN(); ++n) {
      auto node = nodes.Get(n);
      for (uint32_t d=0;d<node->GetNDevices();++d) {
        auto dev=DynamicCast<PointToPointNetDevice>(node->GetDevice(d));
        if (dev && !dev->SetMtu(600)) throw std::runtime_error("Cannot set test face MTU");
      }
    }
  }
  ns3::ndn::StackHelper stack;
  // Disable all content stores for the controlled queue/loss experiment.
  // Cache and retransmission remain separately evidenced in approved 1S/1U.
  stack.setCsSize(0);
  stack.InstallAll();
  ns3::ndn::StrategyChoiceHelper::InstallAll("/hcraf", "/localhost/nfd/strategy/best-route");
  // Native NFD BestRoute is used for diagnostic controls ONLY.
  // This does not implement or alter the HCRAF two-branch/Gate strategy.
  // No special forwarding policy: all controls use native NFD BestRoute.
  // An absent route is deliberately created ONLY in the no-route control.
  ns3::ndn::FibHelper::AddRoute(nodes.Get(0), "/hcraf", nodes.Get(1), 1);
  if (mode != "no-route")
    ns3::ndn::FibHelper::AddRoute(nodes.Get(1), "/hcraf", nodes.Get(2), 1);
  if (mixed) {
    for (uint32_t n = 2; n <= 4; ++n)
      ns3::ndn::FibHelper::AddRoute(nodes.Get(n), "/hcraf", nodes.Get(n+3), 1);
  }
  const std::vector<uint32_t> producerNodes = mixed ?
    std::vector<uint32_t>{5u} : std::vector<uint32_t>{2u};
  for (uint32_t n : producerNodes) {
    auto responder = CreateObject<HcrafResponder>();
    responder->Configure(false,
      0.0,
      false, false, false, fragmented); // fragmentation nuisance is isolated
    nodes.Get(n)->AddApplication(responder); responder->SetStartTime(Seconds(0));
  }
  auto requester = CreateObject<HcrafRequester>();
  requester->Configure(mode, output + "/consumer_events.jsonl", 0);
  nodes.Get(0)->AddApplication(requester); requester->SetStartTime(Seconds(0));
  auto l3 = nodes.Get(1)->GetObject<ns3::ndn::L3Protocol>();
  auto primary = l3->getFaceByNetDevice(primaryDevices.Get(0));
  auto secondary = l3->getFaceByNetDevice(secondaryDevices.Get(0));
  auto third=l3->getFaceByNetDevice(thirdDevices.Get(0));
  if (!primary || !secondary || !third) throw std::runtime_error("Missing upstream Face mapping");
  auto forwarder = l3->getForwarder();
  if (instrument) forwarder->hcrafEnable(output + "/events.jsonl", nodes.Get(1)->GetId());
  std::shared_ptr<nfd::Forwarder> secondaryForwarder;
  if (mixed) {
    auto l3b = nodes.Get(2)->GetObject<ns3::ndn::L3Protocol>();
    secondaryForwarder = l3b->getForwarder();
    if (instrument) secondaryForwarder->hcrafEnable(output + "/events_hop2.jsonl", nodes.Get(2)->GetId());
  }
  std::unique_ptr<HcrafStage1wMonitor> linkMonitor;
  std::ofstream observerCosts;
  if (instrument) {
    linkMonitor.reset(new HcrafStage1wMonitor(nodes, output + "/link_events.jsonl"));
    observerCosts.open(output + "/observer_cost.jsonl");
    if (!observerCosts) throw std::runtime_error("Cannot open observer cost log");
    forwarder->hcrafSetDecisionObserver([&linkMonitor, &observerCosts](uint64_t id) {
      const auto a = std::chrono::steady_clock::now();
      linkMonitor->Snapshot(id);
      const auto b = std::chrono::steady_clock::now();
      const auto duration = std::chrono::duration_cast<std::chrono::nanoseconds>(b-a).count();
      observerCosts << "{\"decision_id\":" << id << ",\"snapshot_observer_wall_ns\":" << duration
                    << ",\"is_NFD_decision_latency\":false}\n";
      if (!observerCosts) throw std::runtime_error("Observer timing write failure");
    });
  }
  std::ofstream control(output + "/control_events.jsonl");
  if (!control) throw std::runtime_error("Cannot open control log");
  std::ofstream config(output + "/scenario.json");
  const bool overflow = mode == "forward-overflow" || mode == "return-overflow";
  const bool buffered = mode == "forward-buffered" || mode == "return-buffered";
  const uint32_t offered = mode == "idle" ? 0u : overflow ? 120u : buffered ? 18u :
                           mode == "receive-loss" ? 40u : fragmented ? 24u : 16u;
  config << "{\"mode\":" << hcraf::Recorder::quote(mode)
    << ",\"collector_stage\":\"1AB.FEASIBILITY.0\",\"selection_policy\":\"native_best_route\""
    << ",\"purpose\":\"FUTURE_CONGESTION_ADMISSIBILITY_NOT_TRAINING\""
    << ",\"amendment_id\":\"1Y.A1.PACED_FRAGMENTATION\""
    << ",\"nominal_arrival_interval_ns\":250000000"
    << ",\"seed\":" << seed << ",\"run\":" << run
    << ",\"instrument_enabled\":" << (instrument?"true":"false")
    << ",\"planned_requests\":" << offered
    << ",\"randomized_arrival_jitter_stream\":129,\"jitter_range_ns\":[0,99999]"
    << ",\"stop_ns\":20000000000,\"decision_node_id\":1"
    << ",\"interest_lifetime_ms\":1000,\"queue_capacity_packets\":20"
    << ",\"cache_enabled\":false,\"router_strategy\":\"native_best_route\""
    << ",\"multi_hop_enabled\":" << (mixed?"true":"false")
    << ",\"mtu_bytes\":" << (fragmented?600:1500)
    << ",\"payload_bytes\":" << (fragmented?4096:1024)
    << ",\"rx_packet_error_rate_on_primary_producer\":" << (mode=="receive-loss"?0.25:0.0)
    << ",\"primary_forward_bps\":" << forwardRate
    << ",\"primary_return_bps\":" << returnRate
    << ",\"primary_face_id\":" << primary->getId()
    << ",\"secondary_face_id\":" << secondary->getId()
    << ",\"third_face_id\":" << third->getId()
    << ",\"observability_monitors_all_point_to_point_directions\":" << (instrument?"true":"false")
    << ",\"queue_trace_schema\":\"1W.0\",\"data_pit_schema\":\"1U.1\""
    << ",\"stage1ab_proposal_theta\":2,\"stage1ab_proposal_horizon_ns\":2000000000"
    << ",\"stage1ab_path_nodes\":[0,1,2,5],\"stage1ab_case_role\":\"DEVELOPMENT_ONLY\""
    << ",\"congestion\":null,\"future_congestion\":null"
    << ",\"causal_congestion_attribution\":null,\"F3_ready\":false"
    << ",\"training_ready\":false}\n";
  config.flush();
  if (!config) throw std::runtime_error("Cannot write configuration");
  config.close();
  Simulator::Stop(Seconds(20)); Simulator::Run();
  if (instrument) {
    forwarder->hcrafFinish(); forwarder->hcrafSetDecisionObserver({});
    if (secondaryForwarder) secondaryForwarder->hcrafFinish();
    linkMonitor->Finish();
    observerCosts.flush();
    if (!observerCosts) throw std::runtime_error("Observer cost flush failure");
  }
  Simulator::Destroy();
  return 0;
}
