#ifndef HCRAF_COLLECTION_POLICY_HPP
#define HCRAF_COLLECTION_POLICY_HPP
#include <vector>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <stdexcept>
namespace hcraf {
inline std::vector<double> collectionProbabilities(const std::vector<uint64_t>& valid, bool coverage) {
  if (valid.empty()) throw std::runtime_error("No eligible faces");
  const auto minimum=*std::min_element(valid.begin(),valid.end());
  const auto ties=std::count(valid.begin(),valid.end(),minimum);
  std::vector<double> p;
  for(auto n:valid)p.push_back(coverage ? 0.2/valid.size()+(n==minimum ? 0.8/ties : 0.0) : 1.0/valid.size());
  return p;
}
inline size_t collectionIndex(const std::vector<double>& p, double draw) {
  if(p.empty() || !(draw>=0 && draw<1))throw std::runtime_error("Invalid selection draw");
  double total=0;
  for(double x:p){if(!std::isfinite(x)||x<=0)throw std::runtime_error("Invalid probability");total+=x;}
  if(std::abs(total-1)>1e-12)throw std::runtime_error("Probabilities do not sum to one");
  double cumulative=0;
  for(size_t i=0;i<p.size();++i){cumulative+=p[i];if(draw<cumulative)return i;}
  return p.size()-1; // floating-point summation residue only
}
inline int64_t arrivalIntervalNs(double draw) {
  if(!(draw>=0 && draw<1))throw std::runtime_error("Invalid arrival draw");
  return std::max<int64_t>(1,std::llround(-std::log1p(-draw)*1e9/20.0));
}
}
#endif
