// Stage1AF controlled multi-Face DEVELOPMENT-only pilot. Not HCRAF policy/evaluation.
// A control name is NOT evidence of occurrence. Never creates F3 training labels.
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/ndnSIM-module.h"
#include "ns3/ndnSIM/apps/ndn-app.hpp"
#include "ns3/ndnSIM/model/ndn-l3-protocol.hpp"
#include "ns3/ndnSIM/NFD/daemon/fw/forwarder.hpp"
#include <fstream>
#include "hcraf-collection-policy.hpp"
#include "hcraf-stage1w-monitor.hpp"
#include <set>
#include "ns3/error-model.h"
#include <stdexcept>
#include <memory>
#include <chrono>

namespace ns3 {
class HcrafRequester : public ns3::ndn::App {
public:
  static TypeId GetTypeId() {
    static TypeId tid = TypeId("ns3::HcrafRequester").SetParent<ns3::ndn::App>()
      .AddConstructor<HcrafRequester>();
    return tid;
  }
  void Configure(const std::string& mode, const std::string& output, uint32_t sourceId,
                 uint32_t requestOverride, uint64_t intervalOverrideNs, uint32_t lifetimeMs) {
    m_requestOverride = requestOverride; m_intervalOverrideNs = intervalOverrideNs; m_lifetimeMs = lifetimeMs;
    m_mode = mode;
    m_sourceId = sourceId;
    m_nonce = 1000 + 10000 * sourceId;
    m_out.open(output);
    m_arrivals.open(output + ".arrivals.jsonl");
    if(!m_arrivals)throw std::runtime_error("Cannot open arrival schedule");
    m_arrivals << std::setprecision(17);
    if (!m_out) throw std::runtime_error("Cannot open consumer event file");
  }
  void OnData(std::shared_ptr<const ::ndn::Data> data) override {
    ns3::ndn::App::OnData(data);
    m_out << "{\"event\":\"DATA\",\"time_ns\":" << Simulator::Now().GetNanoSeconds()
          << ",\"name\":" << hcraf::Recorder::quote(data->getName().toUri())
          << ",\"payload_bytes\":" << data->getContent().value_size() << "}\n";
    m_out.flush();
  }
  void OnNack(std::shared_ptr<const ::ndn::lp::Nack> nack) override {
    ns3::ndn::App::OnNack(nack);
    m_out << "{\"event\":\"NACK\",\"time_ns\":" << Simulator::Now().GetNanoSeconds()
          << ",\"name\":" << hcraf::Recorder::quote(nack->getInterest().getName().toUri())
          << ",\"reason\":" << static_cast<int>(nack->getReason()) << "}\n";
    m_out.flush();
  }
protected:
  void StartApplication() override {
    ns3::ndn::App::StartApplication();
    // Fixed protocol; change only after registration. Jitter uses an ns-3 RNG
    // with fixed stream so changing RngRun changes actual input, not only a label.
    const bool overflow = m_mode == "forward-overflow" || m_mode == "return-overflow";
    const bool buffered = m_mode == "forward-buffered" || m_mode == "return-buffered";
    const bool mixed = m_mode == "mixed-fragmented";
    const uint32_t requests = m_requestOverride ? m_requestOverride :
                              m_mode == "idle" ? 0u : overflow ? 120u : buffered ? 18u :
                              m_mode == "receive-loss" ? 40u : mixed ? 24u : 16u;
    const int64_t interval = m_intervalOverrideNs ? static_cast<int64_t>(m_intervalOverrideNs) :
                             overflow || buffered ? 1000000LL : mixed ? 250000000LL :
                             m_mode == "receive-loss" ? 10000000LL : 100000000LL;
    auto jitter = CreateObject<UniformRandomVariable>();
    jitter->SetStream(129);
    for (uint32_t i=0; i<requests; ++i) {
      const int64_t jitterNs = int64_t(jitter->GetInteger(0, 99999));
      const int64_t time = 2000000000LL + int64_t(i)*interval + jitterNs;
      m_arrivals << "{\"sequence\":" << i << ",\"time_ns\":" << time
        << ",\"jitter_ns\":" << jitterNs
        << ",\"included\":true,\"schedule\":\"STAGE1AD_DEV_RNG_STREAM_129\"}\n";
      Simulator::Schedule(NanoSeconds(time), &HcrafRequester::Send, this, i);
    }
    m_arrivals.flush();if(!m_arrivals)throw std::runtime_error("Arrival trace failed");
  }
private:
  void Send(uint32_t sequence) {
    if (!m_active) return;
    const uint32_t nameId = sequence;
    const bool prefixInterest = false;
    auto interest = std::make_shared<::ndn::Interest>(
      ::ndn::Name(prefixInterest ? "/hcraf/pilot" : "/hcraf/pilot/" + std::to_string(nameId)));
    interest->setNonce(++m_nonce);
    interest->setInterestLifetime(::ndn::time::milliseconds(m_lifetimeMs));
    interest->setCanBePrefix(prefixInterest);
    interest->setMustBeFresh(true);
    m_out << "{\"event\":\"SEND\",\"time_ns\":" << Simulator::Now().GetNanoSeconds()
          << ",\"name\":" << hcraf::Recorder::quote(interest->getName().toUri())
          << ",\"nonce\":" << m_nonce << ",\"source_id\":" << m_sourceId << "}\n";
    m_out.flush();
    m_transmittedInterests(interest, this, m_face);
    m_appLink->onReceiveInterest(*interest);
  }
  uint32_t m_nonce = 1000;
  uint32_t m_sourceId = 0;
  uint32_t m_requestOverride = 0, m_lifetimeMs = 1000;
  uint64_t m_intervalOverrideNs = 0;
  std::string m_mode;
  std::ofstream m_out;
  std::ofstream m_arrivals;
};
NS_OBJECT_ENSURE_REGISTERED(HcrafRequester);

class HcrafResponder : public ns3::ndn::App {
public:
  static TypeId GetTypeId() {
    static TypeId tid = TypeId("ns3::HcrafResponder").SetParent<ns3::ndn::App>()
      .AddConstructor<HcrafResponder>();
    return tid;
  }
  void Configure(bool silent, double delay, bool forceLeaf, bool doubleReply, bool spontaneous, bool bigPayload) {
    m_silent = silent; m_delay = delay; m_forceLeaf = forceLeaf;
    m_doubleReply = doubleReply; m_spontaneous = spontaneous; m_bigPayload = bigPayload;
  }
  void OnInterest(std::shared_ptr<const ::ndn::Interest> interest) override {
    ns3::ndn::App::OnInterest(interest);
    if (!m_active || m_silent) return;
    auto name = m_forceLeaf ? ::ndn::Name("/hcraf/pilot/0") : interest->getName();
    Simulator::Schedule(Seconds(m_delay), &HcrafResponder::Reply, this, name);
    if (m_doubleReply) Simulator::Schedule(Seconds(m_delay + 0.0001), &HcrafResponder::Reply, this, name);
  }
protected:
  void StartApplication() override {
    ns3::ndn::App::StartApplication();
    ns3::ndn::FibHelper::AddRoute(GetNode(), "/hcraf", m_face, 0);
    if (m_spontaneous)
      Simulator::Schedule(Seconds(2.06), &HcrafResponder::Reply, this, ::ndn::Name("/hcraf/pilot/0"));
  }
private:
  void Reply(::ndn::Name name) {
    if (!m_active) return;
    auto data = std::make_shared<::ndn::Data>(name);
    data->setFreshnessPeriod(::ndn::time::milliseconds(1000));
    data->setContent(std::make_shared<::ndn::Buffer>(m_bigPayload ? 4096 : 1024));
    // Same simulation signature convention as the official ndnSIM Producer.
    ::ndn::SignatureInfo signature(static_cast<::ndn::tlv::SignatureTypeValue>(255));
    data->setSignatureInfo(signature);
    ::ndn::EncodingEstimator estimator;
    ::ndn::EncodingBuffer encoder(estimator.appendVarNumber(0), 0);
    encoder.appendVarNumber(0);
    data->setSignatureValue(encoder.getBuffer());
    data->wireEncode();
    m_transmittedDatas(data, this, m_face);
    m_appLink->onReceiveData(*data);
  }
  bool m_silent = false, m_forceLeaf = false, m_doubleReply = false, m_spontaneous = false, m_bigPayload = false;
  double m_delay = 0;
};
NS_OBJECT_ENSURE_REGISTERED(HcrafResponder);
}

static void RecordRxDrop(std::ofstream* out, ns3::Ptr<const ns3::Packet> packet) {
  *out << "{\"event\":\"PHY_RX_DROP\",\"node_id\":2,\"time_ns\":"
       << ns3::Simulator::Now().GetNanoSeconds() << ",\"packet_uid\":" << packet->GetUid() << "}\n";
  out->flush();
}

int main(int argc, char* argv[]) {
  using namespace ns3;
  std::string mode = "LOW_LOAD", output = ".";
  std::string topology = "DEV_CHAIN_A";
  uint32_t selectedSlot = 0;
  uint32_t seed = 1;
  uint64_t run = 1;
  bool instrument = true;
  uint32_t requestOverride=0, lifetimeMs=1000, producerDelayMs=0;
  uint64_t intervalOverrideNs=0, forwardBps=0, returnBps=0;
  CommandLine cmd;
  cmd.AddValue("mode", "LOW_LOAD/BUFFER_NO_DROP/OVERFLOW_DROP/LP_CLEAN/LP_PRESSURE", mode);
  cmd.AddValue("topology", "DEV_CHAIN_A or DEV_CHAIN_B (development, not held-out)", topology);
  cmd.AddValue("selectedSlot", "Controlled upstream face slot 0/1/2 (forced assignment)", selectedSlot);
  cmd.AddValue("output", "Existing output directory", output);
  cmd.AddValue("seed", "ns-3 random seed", seed);
  cmd.AddValue("run", "ns-3 random run number", run);
  cmd.AddValue("instrument", "Enable event and queue monitor (1/0)", instrument);
  cmd.AddValue("requestCount", "Override number of distinct requests (0 keeps mode defaults)", requestOverride);
  cmd.AddValue("intervalNs", "Override request separation in nanoseconds", intervalOverrideNs);
  cmd.AddValue("lifetimeMs", "Interest lifetime in milliseconds", lifetimeMs);
  cmd.AddValue("producerDelayMs", "Producer response delay in milliseconds", producerDelayMs);
  cmd.AddValue("forwardBps", "Override primary forward link bps", forwardBps);
  cmd.AddValue("returnBps", "Override primary return link bps", returnBps);

  cmd.Parse(argc, argv);
  if (std::set<std::string>{"LOW_LOAD","BUFFER_NO_DROP","OVERFLOW_DROP","LP_CLEAN","LP_PRESSURE"}.count(mode)==0)
    throw std::runtime_error("Unregistered 1AF regime");
  if ((topology!="DEV_CHAIN_A" && topology!="DEV_CHAIN_B") || selectedSlot>2)
    throw std::runtime_error("Unregistered 1AF topology or slot");

  if(lifetimeMs<100 || lifetimeMs>5000 || producerDelayMs>3000 || requestOverride>200 ||
     intervalOverrideNs>1000000000ULL) throw std::runtime_error("Invalid registered 1AD bounds");
  RngSeedManager::SetSeed(seed); RngSeedManager::SetRun(run);
  NodeContainer nodes;
  const bool fragmented = (mode == "LP_CLEAN" || mode == "LP_PRESSURE");
  const bool mixed = true; // 1AB always uses eight-node, complete two-router path.
  nodes.Create(8u);
  PointToPointHelper link;
  link.SetQueue("ns3::DropTailQueue<Packet>", "MaxSize", StringValue("20p"));
  link.SetDeviceAttribute("InterframeGap", TimeValue(NanoSeconds(0)));
  link.SetDeviceAttribute("DataRate", StringValue("10Mbps"));
  link.SetChannelAttribute("Delay", StringValue(topology=="DEV_CHAIN_A" ? "10ms" : "14ms"));
  link.Install(nodes.Get(0), nodes.Get(1));
  link.SetDeviceAttribute("DataRate", StringValue("10Mbps"));
  link.SetChannelAttribute("Delay", StringValue(topology=="DEV_CHAIN_A" ? "10ms" : "14ms"));
  auto primaryDevices = link.Install(nodes.Get(1), nodes.Get(2));
  auto routerDevice = DynamicCast<PointToPointNetDevice>(primaryDevices.Get(0));
  auto producerDevice = DynamicCast<PointToPointNetDevice>(primaryDevices.Get(1));
  const uint64_t forwardRate = forwardBps ? forwardBps : 10000000;
  const uint64_t returnRate = returnBps ? returnBps : 10000000;
  routerDevice->SetDataRate(DataRate(forwardRate));
  producerDevice->SetDataRate(DataRate(returnRate));
  auto errors = CreateObject<RateErrorModel>();
  errors->SetUnit(RateErrorModel::ERROR_UNIT_PACKET);
  errors->SetRate(mode == "receive-loss" ? 0.25 : 0.0);
  errors->AssignStreams(71);
  producerDevice->SetReceiveErrorModel(errors);
  std::ofstream faults(output + "/fault_events.jsonl");
  if (!faults) throw std::runtime_error("Cannot open fault log");
  if (!producerDevice->TraceConnectWithoutContext("PhyRxDrop", MakeBoundCallback(&RecordRxDrop, &faults)))
    throw std::runtime_error("Missing PhyRxDrop trace");
  link.SetDeviceAttribute("DataRate", StringValue("512kbps"));
  link.SetChannelAttribute("Delay", StringValue("30ms"));
  auto secondaryDevices = link.Install(nodes.Get(1), nodes.Get(3));
  link.SetDeviceAttribute("DataRate", StringValue("1Mbps"));
  link.SetChannelAttribute("Delay", StringValue("20ms"));
  auto thirdDevices=link.Install(nodes.Get(1),nodes.Get(4));
  const std::vector<uint32_t> relayToProducer = topology=="DEV_CHAIN_A" ?
    std::vector<uint32_t>{5u,6u,7u} : std::vector<uint32_t>{7u,5u,6u};
  link.SetDeviceAttribute("DataRate", StringValue(topology=="DEV_CHAIN_A" ? "10Mbps" : "8Mbps"));
  link.SetChannelAttribute("Delay", StringValue(topology=="DEV_CHAIN_A" ? "10ms" : "17ms"));
  for (uint32_t s=0; s<3; ++s)
    link.Install(nodes.Get(2+s), nodes.Get(relayToProducer[s]));
  // Slot-specific bottleneck controls use the actual path, not a hardcoded Face ID.

  // NFD NetDeviceTransport reads device MTU during StackHelper::InstallAll.
  // Constrain BOTH endpoints to ensure LP (not IP) fragmentation on these point-to-point faces.
  if (fragmented) {
    for (uint32_t n=0; n<nodes.GetN(); ++n) {
      auto node = nodes.Get(n);
      for (uint32_t d=0;d<node->GetNDevices();++d) {
        auto dev=DynamicCast<PointToPointNetDevice>(node->GetDevice(d));
        if (dev && !dev->SetMtu(600)) throw std::runtime_error("Cannot set test face MTU");
      }
    }
  }
  // Bottleneck is limited to the selected branch and direction.
  auto candidateUp = selectedSlot==0 ? primaryDevices.Get(0) :
    (selectedSlot==1 ? secondaryDevices.Get(0) : thirdDevices.Get(0));
  auto candidateDown = selectedSlot==0 ? primaryDevices.Get(1) :
    (selectedSlot==1 ? secondaryDevices.Get(1) : thirdDevices.Get(1));
  const uint64_t rate = mode=="OVERFLOW_DROP" ? 12000u :
                       mode=="BUFFER_NO_DROP" ? 150000u :
                       mode=="LP_PRESSURE" ? 256000u : 10000000u;
  if (mode=="BUFFER_NO_DROP" || mode=="OVERFLOW_DROP")
    DynamicCast<PointToPointNetDevice>(candidateUp)->SetDataRate(DataRate(rate));
  if (mode=="LP_PRESSURE")
    DynamicCast<PointToPointNetDevice>(candidateDown)->SetDataRate(DataRate(rate));
  ns3::ndn::StackHelper stack;
  // Disable all content stores for the controlled queue/loss experiment.
  // Cache and retransmission remain separately evidenced in approved 1S/1U.
  stack.setCsSize(0);
  stack.InstallAll();
  ns3::ndn::StrategyChoiceHelper::InstallAll("/hcraf", "/localhost/nfd/strategy/best-route");
  // Native NFD BestRoute is used for diagnostic controls ONLY.
  // This does not implement or alter the HCRAF two-branch/Gate strategy.
  // No special forwarding policy: all controls use native NFD BestRoute.
  // An absent route is deliberately created ONLY in the no-route control.
  ns3::ndn::FibHelper::AddRoute(nodes.Get(0), "/hcraf", nodes.Get(1), 1);
  for (uint32_t s=0; s<3; ++s)
    ns3::ndn::FibHelper::AddRoute(nodes.Get(1), "/hcraf", nodes.Get(2+s), 1+s);
  for (uint32_t s=0; s<3; ++s)
    ns3::ndn::FibHelper::AddRoute(nodes.Get(2+s), "/hcraf", nodes.Get(relayToProducer[s]), 1);
  const std::vector<uint32_t> producerNodes = {5u,6u,7u};
  for (uint32_t n : producerNodes) {
    auto responder = CreateObject<HcrafResponder>();
    responder->Configure(false,
      double(producerDelayMs)/1000.0,
      false, false, false, fragmented); // same payload within a controlled LP regime
    nodes.Get(n)->AddApplication(responder); responder->SetStartTime(Seconds(0));
  }
  auto requester = CreateObject<HcrafRequester>();
  requester->Configure(mode, output + "/consumer_events.jsonl", 0, requestOverride, intervalOverrideNs, lifetimeMs);
  nodes.Get(0)->AddApplication(requester); requester->SetStartTime(Seconds(0));
  auto l3 = nodes.Get(1)->GetObject<ns3::ndn::L3Protocol>();
  auto primary = l3->getFaceByNetDevice(primaryDevices.Get(0));
  auto secondary = l3->getFaceByNetDevice(secondaryDevices.Get(0));
  auto third=l3->getFaceByNetDevice(thirdDevices.Get(0));
  if (!primary || !secondary || !third) throw std::runtime_error("Missing upstream Face mapping");
  auto forwarder = l3->getForwarder();
  if (instrument) {
    forwarder->hcrafEnable(output + "/events.jsonl", nodes.Get(1)->GetId());
    // Deliberately deterministic allocation; nominal Uniform prob 1/3 is NOT
    // the behavioral propensity for this forced action (which is 1).
    forwarder->hcrafEnableCoverage([selectedSlot]() {
      return (static_cast<double>(selectedSlot)+0.5)/3.0;
    }, false);
  }
  std::vector<std::shared_ptr<nfd::Forwarder>> relayForwarders;
  for (uint32_t s=0; s<3; ++s) {
    auto relay=nodes.Get(2+s)->GetObject<ns3::ndn::L3Protocol>()->getForwarder();
    relayForwarders.push_back(relay);
    if (instrument)
      relay->hcrafEnable(output + "/events_hop2_node" + std::to_string(2+s) + ".jsonl", 2+s);
  }
  std::unique_ptr<HcrafStage1wMonitor> linkMonitor;
  std::ofstream observerCosts;
  if (instrument) {
    linkMonitor.reset(new HcrafStage1wMonitor(nodes, output + "/link_events.jsonl"));
    observerCosts.open(output + "/observer_cost.jsonl");
    if (!observerCosts) throw std::runtime_error("Cannot open observer cost log");
    forwarder->hcrafSetDecisionObserver([&linkMonitor, &observerCosts](uint64_t id) {
      const auto a = std::chrono::steady_clock::now();
      linkMonitor->Snapshot(id);
      const auto b = std::chrono::steady_clock::now();
      const auto duration = std::chrono::duration_cast<std::chrono::nanoseconds>(b-a).count();
      observerCosts << "{\"decision_id\":" << id << ",\"snapshot_observer_wall_ns\":" << duration
                    << ",\"is_NFD_decision_latency\":false}\n";
      if (!observerCosts) throw std::runtime_error("Observer timing write failure");
    });
  }
  std::ofstream control(output + "/control_events.jsonl");
  if (!control) throw std::runtime_error("Cannot open control log");
  std::ofstream config(output + "/scenario.json");
  // Explicit local device validation: avoid using hardcoded Face IDs.
  const std::vector<uint64_t> actualFaces = {primary->getId(),secondary->getId(),third->getId()};
  const uint32_t selectedRelay=2+selectedSlot;
  const uint32_t selectedProducer=relayToProducer[selectedSlot];
  const uint64_t plannedCount = requestOverride;
  const uint64_t nominalInterval = intervalOverrideNs;
  if (!plannedCount || !nominalInterval) throw std::runtime_error("1AF requires explicit registered traffic plan");
  config << "{\"mode\":" << hcraf::Recorder::quote(mode)
    << ",\"collector_stage\":\"1AF.DEV_MULTIFACE.0\""
    << ",\"topology_id\":" << hcraf::Recorder::quote(topology)
    << ",\"selected_face_slot\":" << selectedSlot
    << ",\"selected_face_id\":" << actualFaces[selectedSlot]
    << ",\"actual_assignment_probability\":1.0"
    << ",\"nominal_uniform_probability_NOT_behavioral_propensity\":0.33333333333333331"
    << ",\"selection_policy\":\"FORCED_DETERMINISTIC_DRAW_UNIFORM_NOMINAL\""
    << ",\"eligible_face_ids\":[" << actualFaces[0] << "," << actualFaces[1] << "," << actualFaces[2] << "]"
    << ",\"path_nodes\":[0,1," << selectedRelay << "," << selectedProducer << "]"
    << ",\"decision_node_id\":1,\"selected_relay_node_id\":" << selectedRelay
    << ",\"selected_producer_node_id\":" << selectedProducer
    << ",\"purpose\":\"DEVELOPMENT_ONLY_NOT_HCRAF_POLICY\""
    << ",\"seed\":" << seed << ",\"run\":" << run
    << ",\"instrument_enabled\":" << (instrument?"true":"false")
    << ",\"planned_requests\":" << plannedCount
    << ",\"nominal_arrival_interval_ns\":" << nominalInterval
    << ",\"randomized_arrival_jitter_stream\":129"
    << ",\"interest_lifetime_ms\":" << lifetimeMs
    << ",\"stop_ns\":20000000000,\"cache_enabled\":false,\"multi_hop_enabled\":true"
    << ",\"queue_capacity_packets\":20,\"queue_trace_schema\":\"1W.0\""
    << ",\"mtu_bytes\":" << (fragmented?600:1500)
    << ",\"payload_bytes\":" << (fragmented?4096:1024)
    << ",\"selected_forward_bps\":" << ((mode=="BUFFER_NO_DROP" || mode=="OVERFLOW_DROP") ? rate : forwardRate)
    << ",\"selected_return_bps\":" << (mode=="LP_PRESSURE" ? rate : returnRate)
    << ",\"theta_pilot\":2,\"horizon_ms_pilot\":2000"
    << ",\"decision_time_us_real_HCRAF\":null,\"observer_cost_is_decision_time\":false"
    << ",\"congestion\":null,\"future_congestion\":null,\"F3_ready\":false,\"training_ready\":false}\n";
  config.flush();
  if (!config) throw std::runtime_error("Cannot write configuration");
  config.close();
  Simulator::Stop(Seconds(20)); Simulator::Run();
  if (instrument) {
    forwarder->hcrafFinish(); forwarder->hcrafSetDecisionObserver({});
    for (auto& relay : relayForwarders) relay->hcrafFinish();
    linkMonitor->Finish();
    observerCosts.flush();
    if (!observerCosts) throw std::runtime_error("Observer cost flush failure");
  }
  Simulator::Destroy();
  return 0;
}
