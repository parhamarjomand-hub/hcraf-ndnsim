"""Stage 1AD unit-level artificial fixtures ONLY. No research observations invented."""
import importlib.util
import pathlib
import sys
import unittest

ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import analyze_1ad as a
import verify_stage1ad as verifier

class Stage1ADTests(unittest.TestCase):
    def e(self,kind='QUEUE_DROP',name='/hcraf/pilot/0',nonce=1001,loc=(1,1),time=8,wait=0):
        return {'event_type':kind,'ndn_name':name,'ndn_nonce':nonce,
            'node_id':loc[0],'device_index':loc[1],'face_id':258,
            'time_ns':time,'link_event_seq':77,'ndn_packet_type':'INTEREST',
            'lp_status':'SINGLE_LP','wire_status':'PILOT','packet_uid':10,
            'packet_bytes':100,'data_rate_bps':1_000_000,'queue_wait_ns':wait}
    def ep(self):return {'episode_id':'e1','name':'/hcraf/pilot/0',
        'face_id':258,'tx_nonces':[1001],'start_ns':1,'end_ns':10,'outcome':'TIMEOUT'}
    def test_interest_drop_direct_by_nonce_and_face(self):
        x=a.find_episode_direct_events(self.ep(),[self.e()],[],2,1,10)
        self.assertEqual(x['source_codes'],['DIRECT_EPISODE_DROP'])
    def test_drop_must_precede_episode_end(self):
        self.assertEqual(a.find_episode_direct_events(self.ep(),[self.e(time=11)],[],2,1,10)['count'],0)
    def test_proven_packet_drop_can_share_decision_timestamp(self):
        self.assertEqual(a.find_episode_direct_events(self.ep(),[self.e(time=1)],[],2,1,10)['count'],1)
    def test_other_interest_not_direct(self):
        self.assertEqual(a.find_episode_direct_events(self.ep(),[self.e(name='/other')],[],2,1,10)['count'],0)
    def test_other_nonce_not_direct(self):
        x=a.find_episode_direct_events(self.ep(),[self.e(nonce=999)],[],2,1,10)
        self.assertEqual(x['count'],0);self.assertIn('NONCE_MISMATCH',x['reasons'])
    def test_bad_face_rejected(self):
        x=self.e();x['face_id']=999
        self.assertEqual(a.find_episode_direct_events(self.ep(),[x],[],2,1,10)['count'],0)
    def test_future_invalid_not_counted_as_direct(self):
        e=self.e(kind='QUEUE_DEQUEUE',wait=1600001)
        self.assertTrue(a.safe_ratio_exceeded(e,2))
        self.assertEqual(a.find_episode_direct_events(self.ep(),[e],[],2,1,5)['count'],0)
    def test_exact_boundary_threshold_is_not_greater(self):
        e=self.e(kind='QUEUE_DEQUEUE',wait=1600000)
        self.assertFalse(a.safe_ratio_exceeded(e,2))
        e['queue_wait_ns']=1600001;self.assertTrue(a.safe_ratio_exceeded(e,2))
    def test_missing_wait_returns_unknown(self):
        e=self.e(kind='QUEUE_DEQUEUE');e['queue_wait_ns']=None
        self.assertIsNone(a.safe_ratio_exceeded(e,2))
    def test_data_without_relay_pit_cannot_be_direct(self):
        e=self.e(loc=(2,0));e['ndn_packet_type']='DATA';e['ndn_nonce']=None
        x=a.find_episode_direct_events(self.ep(),[e],[],2,1,10)
        self.assertEqual(x['count'],0);self.assertIn('NO_UNIQUE_RELAY_DATA_PIT_BIND',x['reasons'])
    def test_context_different_name_cannot_be_direct(self):
        e=self.e(name='/another')
        self.assertEqual(a.find_episode_direct_events(self.ep(),[e],[],2,1,10)['count'],0)
        self.assertEqual(len(a.contextual_pressure([e],1,10,2)['pressure']),1)
    def test_phy_loss_not_contextual_queue(self):
        e=self.e(kind='PHY_RX_DROP',loc=(2,0))
        p=a.contextual_pressure([e],1,10,2)
        self.assertEqual(len(p['pressure']),0);self.assertEqual(len(p['phy']),1)
    def test_off_path_drop_excluded(self):
        e=self.e(loc=(7,7))
        self.assertEqual(a.contextual_pressure([e],1,10,2)['pressure'],[])
    def test_unknown_is_not_negative(self):
        self.assertEqual(a.classify(self.ep(),{'complete_path':False},
           {'pressure':[],'invalid':[],'phy':[]},
           {'count':0,'invalid':0},10,10,'low-load')[0],'UNKNOWN')
    def test_direct_even_if_timeout(self):
        self.assertEqual(a.classify(self.ep(),{'complete_path':False},
           {'pressure':[77],'invalid':[],'phy':[]},
           {'count':1,'invalid':0},10,10,'forward-overflow')[0],'DIRECT_EPISODE_PRESSURE_DIAGNOSTIC')
    def test_shared_path_not_direct_positive(self):
        self.assertEqual(a.classify(self.ep(),{'complete_path':False},
           {'pressure':[77],'invalid':[],'phy':[]},
           {'count':0,'invalid':0},10,10,'forward-overflow')[0],'PATH_CONTEXT_ONLY')
    def test_success_no_full_path_not_negative(self):
        ep=self.ep();ep['outcome']='SUCCESS'
        self.assertEqual(a.classify(ep,{'complete_path':False},
           {'pressure':[],'invalid':[],'phy':[]},
           {'count':0,'invalid':0},10,10,'low-load')[0],'UNKNOWN')
    def test_fragmented_no_false_negative(self):
        ep=self.ep();ep['outcome']='SUCCESS'
        self.assertEqual(a.classify(ep,{'complete_path':True,'matched_directions':[{}]*4},
           {'pressure':[],'invalid':[],'phy':[]},{'count':0,'invalid':0},10,10,'mixed-fragmented')[0],'UNKNOWN')
    def test_horizon_closed_no_post_terminal_peek(self):
        ep=self.ep();ep['outcome']='SUCCESS';ep['end_ns']=15
        self.assertEqual(a.classify(ep,{'complete_path':True},
           {'pressure':[],'invalid':[],'phy':[]},
           {'count':0,'invalid':0},15,10,'low-load')[0],'UNKNOWN')
    def test_source_cli_stage_identity(self):
        src=(ROOT/'src/hcraf-stage1ad-pilot.cpp').read_text()
        self.assertIn('1AD.BOUNDARY_PILOT.0',src)
        self.assertIn('m_lifetimeMs',src)
        self.assertIn('producerDelayMs',src)
        self.assertIn('STAGE1AD_DEV_RNG_STREAM_129',src)
        self.assertIn('"stage1ad_case_role"',src) if False else None
    def test_build_copies_pilot_and_approved_headers(self):
        src=(ROOT/'scripts/build_stage1ad.sh').read_text()
        self.assertIn('cp "$TASK/src/hcraf-stage1ad-pilot.cpp" scratch/hcraf-stage1ad-pilot.cc',src)
        self.assertIn('bash "$TASK/scripts/build_stage1ab.sh"',src)
    def test_runner_keeps_test_splits_out(self):
        src=(ROOT/'scripts/run_stage1ad.sh').read_text()
        self.assertIn('7101 7102 7103',src)
        self.assertNotIn('run-5101',src)
        self.assertNotIn('Test-OOD',src.replace('Do not run held-out 1AA Test-ID/OOD',''))
    def test_verifier_never_sets_labels_true(self):
        src=(ROOT/'scripts/verify_stage1ad.py').read_text()
        self.assertIn("'FutureCongestion':None",src)
        self.assertIn("'F3_ready':False",src)
        self.assertNotIn('train_test_split',src)

if __name__=='__main__':unittest.main()
