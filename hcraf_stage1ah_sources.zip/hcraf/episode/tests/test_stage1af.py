"""Unit-only synthetic metadata: never an empirical ndnSIM Episode or F3 label."""
import importlib.util
import sys
from pathlib import Path
import unittest

TASK=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(TASK/'scripts'))
from verify_stage1af import extract_plan, pressure, EvidenceError, REGIMES, TOPOLOGIES, RUNS

class Stage1AFUnitTests(unittest.TestCase):
    def cfg(self,top='DEV_CHAIN_A',slot=0):
        return {'collector_stage':'1AF.DEV_MULTIFACE.0','topology_id':top,
          'mode':'LOW_LOAD','run':8101,'seed':17,'selected_face_slot':slot,
          'eligible_face_ids':[258,259,260], 'selected_face_id':258+slot,
          'actual_assignment_probability':1.0,
          'nominal_uniform_probability_NOT_behavioral_propensity':1/3,
          'selection_policy':'FORCED_DETERMINISTIC_DRAW_UNIFORM_NOMINAL',
          'path_nodes':[0,1,2+slot,({0:5,1:6,2:7} if top=='DEV_CHAIN_A' else {0:7,1:5,2:6})[slot]],
          'selected_relay_node_id':2+slot,
          'selected_producer_node_id':({0:5,1:6,2:7} if top=='DEV_CHAIN_A' else {0:7,1:5,2:6})[slot],
          'multi_hop_enabled':True,'cache_enabled':False,
          'planned_requests':12,'nominal_arrival_interval_ns':150000000,
          'interest_lifetime_ms':2600,'stop_ns':20000000000,
          'theta_pilot':2,'horizon_ms_pilot':2000,'instrument_enabled':True,
          'decision_time_us_real_HCRAF':None,'observer_cost_is_decision_time':False,
          'congestion':None,'future_congestion':None,'F3_ready':False,'training_ready':False}
    def test_all_six_designs_identify_real_route(self):
        for t in TOPOLOGIES:
            for slot in range(3):
                relay,prod=extract_plan(self.cfg(t,slot))
                self.assertEqual(relay,2+slot)
                self.assertIn(prod,(5,6,7))
    def test_nominal_propensity_is_not_behavioral(self):
        c=self.cfg();c['actual_assignment_probability']=1/3
        with self.assertRaises(EvidenceError):extract_plan(c)
    def test_selected_face_mismatch_rejected(self):
        c=self.cfg();c['selected_face_id']=260
        with self.assertRaises(EvidenceError):extract_plan(c)
    def test_face_collisions_rejected(self):
        c=self.cfg();c['eligible_face_ids']=[258,258,260]
        with self.assertRaises(EvidenceError):extract_plan(c)
    def test_wrong_topology_route_rejected(self):
        c=self.cfg('DEV_CHAIN_B',0);c['selected_producer_node_id']=5
        with self.assertRaises(EvidenceError):extract_plan(c)
    def test_heldout_topology_rejected(self):
        c=self.cfg();c['topology_id']='T04'
        with self.assertRaises(EvidenceError):extract_plan(c)
    def test_future_label_rejected(self):
        c=self.cfg();c['future_congestion']=0
        with self.assertRaises(EvidenceError):extract_plan(c)
    def test_training_rejected(self):
        c=self.cfg();c['F3_ready']=True
        with self.assertRaises(EvidenceError):extract_plan(c)
    def test_unscheduled_regime_rejected(self):
        c=self.cfg();c['mode']='RANDOM'
        with self.assertRaises(EvidenceError):extract_plan(c)
    def test_invalid_run_rejected(self):
        c=self.cfg();c['run']=9001
        with self.assertRaises(EvidenceError):extract_plan(c)
    def test_pressure_at_threshold_is_not_greater(self):
        e={'event_type':'QUEUE_DEQUEUE','queue_wait_ns':16000,'packet_bytes':1000,'data_rate_bps':1_000_000_000}
        self.assertFalse(pressure(e))
        e['queue_wait_ns']=16001;self.assertTrue(pressure(e))
    def test_drop_is_not_equivalent_to_timeout(self):
        self.assertTrue(pressure({'event_type':'QUEUE_DROP'}))
        self.assertFalse(pressure({'event_type':'PHY_RX_DROP'}))
    def test_missing_queue_service_not_zero(self):
        with self.assertRaises(EvidenceError):pressure({'event_type':'QUEUE_DEQUEUE','packet_bytes':12,'data_rate_bps':1200})
    def test_no_unpinned_research_split(self):
        c=self.cfg();c['selected_face_slot']=3
        with self.assertRaises(EvidenceError):extract_plan(c)

if __name__=='__main__':unittest.main()
