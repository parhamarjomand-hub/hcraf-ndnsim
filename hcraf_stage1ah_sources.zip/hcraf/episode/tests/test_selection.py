"""Synthetic software fixtures only; not research dataset rows."""
import json,sys,subprocess,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from verify_selection import check

class SelectionTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.tmp=tempfile.TemporaryDirectory();cls.work=Path(cls.tmp.name)
  (cls.work/'driver.cpp').write_text(r'''
#include "hcraf-recorder.hpp"
int main(int argc,char**argv) {
 (void)argc;
 try {
 hcraf::Recorder r(argv[1],1,"/hcraf/pilot");int pit=1;
 auto id=r.beginDecision(&pit,"/hcraf/pilot/0",1000000000,9,"/hcraf",{{10,1},{11,2}});
 r.selection(10,11,std::stod(argv[2]),std::stod(argv[3]));r.endDecision(id);r.finish(2000000000);
 } catch (const std::exception&) {return 2;}
}
''')
  subprocess.run(['g++','-std=c++17','-Wall','-Wextra','-Werror','-I'+str(ROOT/'src'),str(cls.work/'driver.cpp'),'-o',str(cls.work/'driver')],check=True,capture_output=True)
 @classmethod
 def tearDownClass(cls):cls.tmp.cleanup()
 def fixture(self,p,u):
  out=self.work/'events'
  subprocess.run([str(self.work/'driver'),str(out),str(p),str(u)],check=True,capture_output=True)
  c=json.loads(Path(str(out)+'.collection.jsonl').read_text());d=json.loads(Path(str(out)+'.decisions.jsonl').read_text())
  t=[dict(face_id=11 if u<p else 10,pit_instance_id=d['pit_instance_id'],name=d['name'],time_ns=d['time_ns'],event_seq=1)]
  return c,d,t
 def test_zero_primary(self):check(*self.fixture(0,0))
 def test_one_alternative(self):check(*self.fixture(1,.99999))
 def test_boundary_primary(self):check(*self.fixture(.5,.5))
 def test_below_boundary_alternative(self):check(*self.fixture(.5,.4999))
 def test_low_probability(self):check(*self.fixture(.05,.01))
 def test_two_sends_rejected(self):
  c,d,t=self.fixture(.5,.1);t.append(dict(t[0],face_id=10))
  with self.assertRaises(ValueError):check(c,d,t)
 def test_wrong_selected_face_rejected(self):
  c,d,t=self.fixture(.5,.1);t[0]['face_id']=10
  with self.assertRaises(ValueError):check(c,d,t)
 def test_primary_probability_rejected(self):
  c,d,t=self.fixture(.05,.5);c['primary_inclusion_probability']=1
  with self.assertRaises(ValueError):check(c,d,t)
 def test_selected_probability_rejected(self):
  c,d,t=self.fixture(.05,.5);c['selected_action_probability']=.05
  with self.assertRaises(ValueError):check(c,d,t)
 def test_invalid_native_inputs(self):
  for p,u in [(-.1,.2),(1.1,.2),(.5,1),(.5,-.1),('nan',.2),(.5,'nan')]:
   r=subprocess.run([str(self.work/'driver'),str(self.work/'bad'),str(p),str(u)],capture_output=True)
   self.assertEqual(r.returncode,2)
 def test_wrong_eligibility_rejected(self):
  c,d,t=self.fixture(.5,.1);c['eligible_face_ids']=[10]
  with self.assertRaises(ValueError):check(c,d,t)
 def test_wrong_temporal_anchor_rejected(self):
  c,d,t=self.fixture(.5,.1);t[0]['event_seq']=0
  with self.assertRaises(ValueError):check(c,d,t)
