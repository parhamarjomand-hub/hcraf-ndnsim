"""Native state boundary tests. Artificial sequences, never scientific data."""
import json,subprocess,tempfile,unittest,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from verify_states import compare_values
class StateTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.temp=tempfile.TemporaryDirectory();cls.binary=Path(cls.temp.name)/'state'
  subprocess.run(['g++','-std=c++17','-Wall','-Wextra','-Werror','-pedantic','-I'+str(ROOT/'src'),str(ROOT/'tests/state_replay.cpp'),'-o',str(cls.binary)],check=True)
 @classmethod
 def tearDownClass(cls):cls.temp.cleanup()
 def run_rows(self,lines):
  p=subprocess.run([str(self.binary)],input='\n'.join(lines)+'\n',text=True,capture_output=True,check=True)
  return [json.loads(x) for x in p.stdout.splitlines()]
 def test_empty_and_window_coverage(self):
  rows=self.run_rows(['Q 1 2 0 0 1','Q 2 2 1000000000 0 1'])
  self.assertIsNone(rows[0]['SRTT_ms']);self.assertIsNone(rows[0]['Goodput_bps']);self.assertEqual(rows[1]['Goodput_bps'],0)
 def test_success_and_left_boundary(self):
  rows=self.run_rows(['E 1 TX_INTEREST 1 2 1000000000 2000000000 9 -1','E 2 PIT_SATISFIED 1 2 1100000000 -1 -1 1024','Q 1 2 1100000000 2 1','Q 2 2 2100000000 2 1'])
  compare_values(rows[0],{'SRTT_ms':100.,'SuccessEstimate':1.,'Goodput_bps':8192.})
  self.assertEqual(rows[1]['retained_success_records'],0);self.assertEqual(rows[1]['Goodput_bps'],0)
 def test_cancelled_excluded(self):
  rows=self.run_rows(['E 1 TX_INTEREST 1 2 100 1000 9 -1','E 2 TX_INTEREST 1 3 100 1000 9 -1','E 3 PIT_SATISFIED 1 2 200 -1 -1 1024','Q 1 3 200 3 1'])
  self.assertEqual(rows[0]['valid_outcomes'],0)
 def test_retransmission_rtt_missing(self):
  rows=self.run_rows(['E 1 TX_INTEREST 1 2 100 1000 9 -1','E 2 TX_INTEREST 1 2 200 1200 10 -1','E 3 PIT_SATISFIED 1 2 300 -1 -1 1024','Q 1 2 300 3 1'])
  self.assertIsNone(rows[0]['SRTT_ms']);self.assertEqual(rows[0]['SuccessEstimate'],1)
 def test_timeout_evidence_not_query_clock(self):
  rows=self.run_rows(['E 1 TX_INTEREST 1 2 100 200 9 -1','Q 1 2 300 1 1','E 2 PIT_TIMER 2 -1 400 900 -1 -1','Q 2 2 400 2 1'])
  self.assertIsNone(rows[0]['SuccessEstimate']);self.assertEqual(rows[1]['SuccessEstimate'],0);self.assertEqual(rows[1]['last_outcome_evidence_age_ns'],0)
 def test_equal_deadline_success_precedes_finalization(self):
  rows=self.run_rows(['E 1 TX_INTEREST 1 2 100 200 9 -1','E 2 PIT_SATISFIED 1 2 200 -1 -1 10','Q 1 2 200 2 1'])
  self.assertEqual(rows[0]['SuccessEstimate'],1)
 def test_early_finalization_censored(self):
  rows=self.run_rows(['E 1 TX_INTEREST 1 2 100 200 9 -1','E 2 PIT_FINALIZE 1 -1 150 -1 -1 -1','Q 1 2 150 2 1'])
  self.assertEqual(rows[0]['valid_outcomes'],0)
 def test_same_time_sequence(self):
  rows=self.run_rows(['E 1 TX_INTEREST 1 2 100 200 9 -1','Q 1 2 150 1 1','E 2 NACK_ACCEPTED 1 2 150 -1 9 -1','Q 2 2 150 2 1'])
  self.assertIsNone(rows[0]['SuccessEstimate']);self.assertEqual(rows[1]['SuccessEstimate'],0)
 def test_tampered_numeric_rejected(self):
  with self.assertRaises(ValueError):compare_values({'SRTT_ms':12.},{'SRTT_ms':13.})
 def test_missing_not_zero(self):
  with self.assertRaises(ValueError):compare_values({'SuccessEstimate':0},{'SuccessEstimate':None})
