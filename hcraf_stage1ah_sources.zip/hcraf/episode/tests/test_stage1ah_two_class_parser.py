"""Stage 1AH v0.32.2 synthetic parser regression; NOT scientific/simulated evidence."""
import sys, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from verify_stage1ah import parse_data_groupaware, recovered_groups
from verify_stage1w import parse_data as original_stage1w_parse

def tlv(typ,value):
    assert len(value)<253
    return bytes([typ,len(value)])+value

def data_wire(name):
    return tlv(6,tlv(7,b''.join(tlv(8,x.encode('ascii')) for x in name.strip('/').split('/'))))

class GroupAwareParserRegression(unittest.TestCase):
    def test_target_data_is_accepted(self):
        self.assertEqual(parse_data_groupaware(data_wire('/hcraf/pilot/1')),'/hcraf/pilot/1')
    def test_competitor_data_is_accepted(self):
        self.assertEqual(parse_data_groupaware(data_wire('/hcraf/competitor/1')),'/hcraf/competitor/1')
    def test_stage1w_remains_target_only(self):
        with self.assertRaises(ValueError):
            original_stage1w_parse(data_wire('/hcraf/competitor/1'))
    def test_unregistered_path_rejected(self):
        for s in ('/hcraf/other/0','/hcraf/competitorx/0','/unrelated/pilot/1'):
            with self.subTest(s=s),self.assertRaises(ValueError):parse_data_groupaware(data_wire(s))
    def test_non_data_packet_rejected(self):
        a=data_wire('/hcraf/competitor/0')
        with self.assertRaises(ValueError):parse_data_groupaware(bytes([5])+a[1:])
    def test_trailing_bytes_rejected(self):
        with self.assertRaises(ValueError):parse_data_groupaware(data_wire('/hcraf/competitor/0')+b'\x00')
    def test_duplicate_names_rejected(self):
        n=tlv(7,b''.join(tlv(8,x.encode()) for x in ['hcraf','pilot','0']))
        with self.assertRaises(ValueError):parse_data_groupaware(tlv(6,n+n))
    def test_complete_competitor_fragment_group(self):
        a=data_wire('/hcraf/competitor/0');s=len(a)//2
        ev=[dict(event_type='MAC_RX',node_id=1,face_id=258,lp_status='FRAGMENT',
                 lp_group_start_seq=77,lp_seq=77+i,lp_frag_count=2,lp_frag_index=i,
                 lp_fragment_hex=b.hex(),time_ns=100+i,packet_bytes=len(b))
            for i,b in enumerate((a[:s],a[s:]))]
        ok,bad=recovered_groups(ev,1,258)
        self.assertEqual(len(ok),1);self.assertEqual(bad,[])
        self.assertEqual(ok[0]['traffic_class'],'INDEPENDENT_COMPETITOR')
    def test_missing_competitor_fragment_fail_closed(self):
        a=data_wire('/hcraf/competitor/0')
        ev=[dict(event_type='MAC_RX',node_id=1,face_id=258,lp_status='FRAGMENT',
                 lp_group_start_seq=77,lp_seq=77,lp_frag_count=2,lp_frag_index=0,
                 lp_fragment_hex=a[:8].hex(),time_ns=100,packet_bytes=8)]
        ok,bad=recovered_groups(ev,1,258)
        self.assertEqual(ok,[]);self.assertEqual(len(bad),1)
if __name__=='__main__':unittest.main()
