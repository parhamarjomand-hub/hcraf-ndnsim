"""Unit fixtures only (NOT experimental results)."""
import json
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from verify_stage1w import parse_data,fragmented_groups,audit_ingresses,verify_folder
from summarize_stage1w import summarize


def enc(n):
    if n<253:return bytes([n])
    if n<65536:return b'\xfd'+n.to_bytes(2,'big')
    return b'\xfe'+n.to_bytes(4,'big')

def tlv(t,v):return enc(t)+enc(len(v))+v

def data_packet(name='/hcraf/pilot/0'):
    name_tlv=tlv(7,b''.join(tlv(8,c.encode()) for c in name.split('/')[1:]))
    return tlv(6,name_tlv + tlv(21,b'ab'))

def frag_events(miss=None,duplicate=False,rename=False):
    raw=data_packet()
    chunks=[raw[:7],raw[7:]]
    out=[]
    for i,b in enumerate(chunks):
        if i==miss:continue
        out.append(dict(event_type='MAC_RX',node_id=1,face_id=7,
                        lp_status='FRAGMENT', wire_status='INVALID',
                        lp_group_start_seq=100,lp_seq=100+i,lp_frag_index=i,
                        lp_frag_count=2,lp_fragment_hex=b.hex(),
                        packet_uid=100+i,time_ns=10+i))
    if duplicate:out.append(dict(out[-1]))
    if rename:out[-1]['lp_fragment_hex']='00'
    return out


class Stage1WTests(unittest.TestCase):
    def test_valid_ndn_reassembly(self):
        self.assertEqual(parse_data(data_packet()),'/hcraf/pilot/0')
    def test_reject_not_data(self):
        with self.assertRaises(ValueError):parse_data(tlv(5,tlv(7,tlv(8,b'hcraf'))))
    def test_reject_truncated(self):
        with self.assertRaises(ValueError):parse_data(data_packet()[:-1])
    def test_reject_duplicate_name(self):
        name=tlv(7,tlv(8,b'hcraf'))
        with self.assertRaises(ValueError):parse_data(tlv(6,name+name))
    def test_full_fragments(self):
        groups=fragmented_groups(frag_events())
        self.assertEqual(len(groups),1)
        self.assertEqual(groups[0]['name'],'/hcraf/pilot/0')
        self.assertEqual(groups[0]['n_frags'],2)
    def test_real_ndnlp_uint64_sequence_wrap(self):
        # Observed in real 1W trace: start=max uint64; later 0,1,... .
        chunks=[data_packet()[:3],data_packet()[3:]]
        start=(1<<64)-1
        events=[dict(event_type='MAC_RX',node_id=1,face_id=258,
                     lp_status='FRAGMENT',wire_status='INVALID',
                     lp_group_start_seq=start,lp_seq=(start+i)%(1<<64),
                     lp_frag_index=i,lp_frag_count=2,lp_fragment_hex=b.hex(),
                     packet_uid=10+i,time_ns=20+i) for i,b in enumerate(chunks)]
        groups=fragmented_groups(events)
        self.assertEqual(len(groups),1)
        self.assertEqual(groups[0]['group_start_seq'],start)
        self.assertEqual(groups[0]['name'],'/hcraf/pilot/0')

    def test_reject_sequence_nonmodular_or_out_of_range(self):
        rows=frag_events()
        rows[1]['lp_seq']=100 + (1<<64) + 1
        with self.assertRaisesRegex(ValueError,'Invalid 64-bit'):
            fragmented_groups(rows)
        rows=frag_events()
        rows[1]['lp_seq']=100
        with self.assertRaisesRegex(ValueError,'sequence-index'):
            fragmented_groups(rows)

    def test_missing_fragment_fails(self):
        with self.assertRaisesRegex(ValueError,'Incomplete'):
            fragmented_groups(frag_events(miss=1))
    def test_duplicate_fragment_fails(self):
        with self.assertRaisesRegex(ValueError,'Incomplete'):
            fragmented_groups(frag_events(duplicate=True))
    def test_corrupt_fragment_fails(self):
        with self.assertRaises(ValueError):fragmented_groups(frag_events(rename=True))
    def test_cross_hop_uid_not_equal_requirement(self):
        # The group key contains node_id and Face, not an inter-hop UID.
        a=frag_events();b=[dict(x,node_id=2,face_id=17,packet_uid=x['packet_uid']+1000) for x in a]
        groups=fragmented_groups(a+b)
        self.assertEqual(len(groups),2)
        self.assertNotEqual(groups[0]['physical_packet_uids'],groups[1]['physical_packet_uids'])
    def test_ambiguous_phy_rejected(self):
        arrival={'event_seq':1,'node_id':1,'event_type':'DATA_ARRIVE_1U','reason':1,
                 'time_ns':20,'face_id':7,'name':'/hcraf/pilot/0','pit_instance_id':0}
        match=dict(arrival,event_seq=2,event_type='DATA_MATCH_SET_1U',nonce=0)
        e=dict(node_id=1,face_id=7,time_ns=20,ndn_name='/hcraf/pilot/0',
               ndn_packet_type='DATA',event_type='MAC_RX',packet_uid=1)
        with self.assertRaisesRegex(ValueError,'ambiguous'):
            audit_ingresses([arrival,match],[e,dict(e,packet_uid=2)],[])
    def test_missing_phy_rejected(self):
        arrival={'event_seq':1,'node_id':1,'event_type':'DATA_ARRIVE_1U','reason':1,
                 'time_ns':20,'face_id':7,'name':'/hcraf/pilot/0','pit_instance_id':0}
        match=dict(arrival,event_seq=2,event_type='DATA_MATCH_SET_1U',nonce=0)
        with self.assertRaisesRegex(ValueError,'Missing'):
            audit_ingresses([arrival,match],[],[])
    def test_empty_summary_is_incomplete(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaisesRegex(ValueError,'INCOMPLETE'):summarize(d)
            result=json.loads((Path(d)/'stage1w_summary.json').read_text())
            self.assertEqual(result['acceptance'],'INCOMPLETE')
            self.assertEqual(result['verified_runs'],0)
    def test_scenario_missing_source(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(FileNotFoundError):verify_folder(d)

if __name__=='__main__':unittest.main()
