"""Build-plumbing regression; mocked waf validates header installation, not ns-3 execution."""
import pathlib
import shutil
import subprocess
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]

class Stage1WBuildWiringTests(unittest.TestCase):
    def test_stage1w_headers_are_installed_before_waf(self):
        with tempfile.TemporaryDirectory(prefix='stage1w-install-') as folder:
            root = pathlib.Path(folder)
            task = root / 'hcraf' / 'episode'
            (task / 'scripts').mkdir(parents=True)
            (task / 'src').mkdir(parents=True)
            scratch = root / 'episode_sources' / 'ns-3' / 'scratch'
            scratch.mkdir(parents=True)
            for name in ('hcraf-stage1w-pilot.cpp', 'hcraf-stage1w-monitor.hpp', 'hcraf-stage1w-lp.hpp'):
                shutil.copyfile(ROOT / 'src' / name, task / 'src' / name)
            shutil.copyfile(ROOT / 'scripts' / 'build_stage1w.sh', task / 'scripts' / 'build_stage1w.sh')
            # This stub stands in for a *successful prior-stage build* only.
            (task / 'scripts' / 'build_stage1u.sh').write_text(
                '#!/usr/bin/env bash\nset -euo pipefail\n'
                'printf previous_header > "' + str(scratch / 'hcraf-wire-decode.hpp') + '"\n'
                'printf previous_header > "' + str(scratch / 'hcraf-collection-policy.hpp') + '"\n',
                encoding='utf-8')
            fake_waf = root / 'episode_sources' / 'ns-3' / 'waf'
            fake_waf.write_text(
                'from pathlib import Path\n'
                'for f in ("hcraf-stage1w-monitor.hpp", "hcraf-stage1w-lp.hpp", '
                '"hcraf-stage1w-pilot.cc", "hcraf-wire-decode.hpp", "hcraf-collection-policy.hpp"):\n'
                '    assert (Path("scratch") / f).is_file(), "Missing staged file: " + f\n'
                'out = Path("build/scratch/hcraf-stage1w-pilot")\n'
                'out.parent.mkdir(parents=True, exist_ok=True)\n'
                'out.write_text("#!/bin/sh\\nexit 0\\n")\n'
                'out.chmod(0o755)\n', encoding='utf-8')
            result = subprocess.run(['bash', str(task / 'scripts' / 'build_stage1w.sh')],
                                    cwd=str(root), capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stdout + '\n' + result.stderr)
            for name in ('hcraf-stage1w-monitor.hpp', 'hcraf-stage1w-lp.hpp'):
                self.assertEqual((scratch / name).read_bytes(), (task / 'src' / name).read_bytes())

if __name__ == '__main__':
    unittest.main()
