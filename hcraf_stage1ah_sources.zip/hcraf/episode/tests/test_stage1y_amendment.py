import unittest
from pathlib import Path
class Stage1YAmendmentSmoke(unittest.TestCase):
    def test_original_pilot_unchanged(self):
        p=Path(__file__).parents[1]/'src'
        self.assertIn('mixed ? 2000000LL :',(p/'hcraf-stage1y-pilot.cpp').read_text())
    def test_paced_pilot_changes_only_interval_and_provenance(self):
        p=Path(__file__).parents[1]/'src'
        original=(p/'hcraf-stage1y-pilot.cpp').read_text()
        new=(p/'hcraf-stage1y-paced-pilot.cpp').read_text()
        self.assertIn('mixed ? 250000000LL :',new)
        self.assertIn('1Y.A1.PACED_FRAGMENTATION',new)
        self.assertIn('STAGE1Y_A1_PACED_RNG_STREAM_129',new)
        self.assertEqual(new.count('250000000LL'),1)
        self.assertNotEqual(original,new)
    def test_summary_does_not_approve_training(self):
        s=(Path(__file__).parents[1]/'scripts'/'summarize_stage1y_amendment.py').read_text()
        self.assertIn("'scientific_decision':'NO_GO_TO_F3_TRAINING'",s)
        self.assertIn("'F3_ready':False",s)
        self.assertIn("'training_ready':False",s)
if __name__=='__main__': unittest.main()
