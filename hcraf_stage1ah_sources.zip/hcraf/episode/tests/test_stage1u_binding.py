"""Pure unit fixtures only. These are NOT simulation observations or final labels."""
import os
import sys
import tempfile
import unittest
from pathlib import Path
from copy import deepcopy

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'scripts'))
from verify_stage1u import audit_events
from patch_nfd_stage1u import instrument, EXPECTED


def sample(multi=False, duplicated_mac=False):
    events=[]
    def e(kind,pit,name='/hcraf/pilot/0',face=258,nonce=-1,reason=-1):
        events.append(dict(event_seq=len(events)+1,event_type=kind,node_id=1,pit_instance_id=pit,
                           name=name,face_id=face,time_ns=2000000000,
                           deadline_ns=-1,nonce=nonce,reason=reason,payload_bytes=1024))
    e('DATA_ARRIVE_1U',0,reason=1)
    e('DATA_MATCH_SET_1U',0,nonce=2 if multi else 1,reason=1)
    e('DATA_MATCH',11)
    e('DATA_PIT_BIND_1U',11,reason=1)
    if multi:
        e('DATA_MATCH',12,name='/hcraf/pilot')
        e('DATA_PIT_BIND_1U',12,name='/hcraf/pilot',reason=1)
    e('PIT_SATISFIED',11)
    e('SIMULATION_END',0)
    links=[]
    for i in range(1+(1 if duplicated_mac else 0)):
        links.append(dict(event_type='MAC_RX',ndn_packet_type='DATA',
            node_id=1,face_id=258,time_ns=2000000000,ndn_name='/hcraf/pilot/0',packet_uid=101+i))
    return events, links


class Stage1UBindingUnitTests(unittest.TestCase):
    def test_unique_one_pit(self):
        rows,s=audit_events(*sample())
        self.assertEqual((len(rows),s['pit_bind_count'],rows[0]['physical_status']),
                         (1,1,'UNIQUE_TIME_FACE_NAME'))
    def test_one_data_two_pit_overlapping_prefixes(self):
        rows,s=audit_events(*sample(multi=True))
        self.assertEqual(rows[0]['pit_instance_ids'],[11,12])
        self.assertEqual(s['many_pit_arrivals'],1)
    def test_physical_collision_is_not_guessed(self):
        rows,s=audit_events(*sample(duplicated_mac=True))
        self.assertEqual(rows[0]['physical_status'],'AMBIGUOUS_MAC_RX')
        self.assertIsNone(rows[0]['physical_packet_uid'])
        self.assertFalse(s['full_physical_attribution_verified'])
    def test_mac_absent_not_guessed(self):
        events,_=sample()
        rows,s=audit_events(events,[])
        self.assertEqual(rows[0]['physical_status'],'NO_MAC_RX')
        self.assertIsNone(rows[0]['physical_packet_uid'])
    def test_missing_match_set_rejected(self):
        events,links=sample()
        events=[e for e in events if e['event_type']!='DATA_MATCH_SET_1U']
        for i,e in enumerate(events,1):e['event_seq']=i
        with self.assertRaises(ValueError):audit_events(events,links)
    def test_missing_bind_rejected(self):
        events,links=sample()
        events=[e for e in events if e['event_type']!='DATA_PIT_BIND_1U']
        for i,e in enumerate(events,1):e['event_seq']=i
        with self.assertRaises(ValueError):audit_events(events,links)
    def test_mismatched_count_rejected(self):
        events,links=sample()
        events[1]['nonce']=5
        with self.assertRaises(ValueError):audit_events(events,links)
    def test_wrong_face_rejected(self):
        events,links=sample()
        events[3]['face_id']=259
        with self.assertRaises(ValueError):audit_events(events,links)
    def test_name_not_matching_pit_prefix_rejected(self):
        events,links=sample()
        events[2]['name']=events[3]['name']='/different/pit'
        with self.assertRaises(ValueError):audit_events(events,links)
    def test_duplicate_ordinal_rejected(self):
        events,links=sample()
        extra=deepcopy(events[0]);events.insert(1,extra)
        for i,e in enumerate(events,1):e['event_seq']=i
        with self.assertRaises(ValueError):audit_events(events,links)
    def test_time_regression_rejected(self):
        events,links=sample()
        events[3]['time_ns']-=1
        with self.assertRaises(ValueError):audit_events(events,links)
    def test_no_fabricated_positive_from_unmatched(self):
        events,links=sample()
        events=[e for e in events if e['event_type'] not in ('DATA_MATCH','DATA_PIT_BIND_1U')]
        events[1]['nonce']=0
        for i,e in enumerate(events,1):e['event_seq']=i
        rows,s=audit_events(events,links)
        self.assertEqual(rows[0]['match_count'],0)
        self.assertEqual(s['pit_bind_count'],0)
    def test_no_data_trace_rejected(self):
        events,links=sample()
        with self.assertRaises(ValueError):audit_events([events[-1]],links)
    def test_malformed_event_sequence_rejected(self):
        events,links=sample(); events[3]['event_seq']=77
        with self.assertRaises(ValueError):audit_events(events,links)
    def test_pinned_source_mismatch_closed_without_writes(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            for name in EXPECTED:(root/name).write_text('not pinned',encoding='utf8')
            with self.assertRaises(ValueError):instrument(root)
            self.assertEqual((root/'forwarder.cpp').read_text(),'not pinned')
    def test_bind_does_not_create_training_labels(self):
        rows,s=audit_events(*sample())
        self.assertFalse(rows[0]['training_ready'])
        self.assertIsNone(rows[0]['Congestion'])
        self.assertIsNone(rows[0]['FutureCongestion'])
        self.assertIsNone(s['final_congestion_label'])

if __name__=='__main__':unittest.main()
