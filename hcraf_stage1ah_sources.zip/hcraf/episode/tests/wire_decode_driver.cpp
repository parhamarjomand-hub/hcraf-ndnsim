// Pure C++ fixture test: these are synthetic *unit bytes*, not simulated research outcomes.
#include "hcraf-wire-decode.hpp"
#include <cassert>
#include <cstdint>
#include <vector>
#include <iostream>
#include <string>

using Bytes=std::vector<uint8_t>;
static Bytes tlv(uint8_t kind,Bytes content){
  assert(content.size()<253);
  Bytes out={kind,static_cast<uint8_t>(content.size())};out.insert(out.end(),content.begin(),content.end());return out;
}
static void put(Bytes& dst,const Bytes& b){dst.insert(dst.end(),b.begin(),b.end());}
static Bytes makeName(const std::string& name){
  Bytes parts;size_t offset=1;
  while(offset<name.size()){
    auto end=name.find('/',offset);if(end==std::string::npos)end=name.size();
    const std::string component=name.substr(offset,end-offset);
    put(parts,tlv(8,Bytes(component.begin(),component.end())));
    offset=end+1;
  }
  return tlv(7,parts);
}
static Bytes interest(const std::string& name){
  Bytes inside=makeName(name);put(inside,tlv(10,{0,0,3,233}));return tlv(5,inside);
}
static Bytes data(const std::string& name){Bytes inside=makeName(name);return tlv(6,inside);}
int main(){
  auto raw=interest("/hcraf/pilot/5");
  auto d=hcraf::wire::decode(raw);
  assert(d.status=="PILOT"&&d.kind=="INTEREST"&&d.name=="/hcraf/pilot/5"&&d.nonce==1001&&d.offset==0);
  Bytes withPpp={0x77,0x77};put(withPpp,raw);
  d=hcraf::wire::decode(withPpp);
  assert(d.status=="PILOT"&&d.kind=="INTEREST"&&d.nonce==1001&&d.offset==2);
  d=hcraf::wire::decode(data("/hcraf/pilot/5"));
  assert(d.status=="PILOT"&&d.kind=="DATA"&&d.name=="/hcraf/pilot/5"&&!d.hasNonce);
  d=hcraf::wire::decode(interest("/not/pilot/5"));assert(d.status=="NON_PILOT");
  d=hcraf::wire::decode(tlv(100,tlv(80,interest("/hcraf/pilot/5"))));
  assert(d.status=="PILOT"&&d.kind=="INTEREST"&&d.nonce==1001);
  d=hcraf::wire::decode(tlv(100,{}));assert(d.status=="UNSUPPORTED");
  Bytes invalid=raw;invalid.back()=0x00;
  d=hcraf::wire::decode(invalid);assert(d.status=="PILOT"&&d.nonce==768); // payload change visible, no checksum inferred
  invalid=raw;invalid.pop_back();d=hcraf::wire::decode(invalid);assert(d.status!="PILOT");
  invalid={0x05,0xFD,0,5,0x07,0};d=hcraf::wire::decode(invalid);assert(d.status!="PILOT");
  std::cout<<"STAGE1R_WIRE_UNIT_PASS\n";
}
