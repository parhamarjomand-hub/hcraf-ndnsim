"""Synthetic software fixtures ONLY; not simulation observations."""
import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from verify_decisions import verify
from episodes import reconstruct

def write(folder, name, rows):
    (folder/name).write_text(''.join(json.dumps(x)+'\n' for x in rows))

def fixture(folder):
    # Small synthetic open-mode fixture; never packaged as research output.
    d=dict(schema_version='1B.1',decision_id=1,node_id=1,pit_instance_id=1,
      name='/hcraf/pilot/0',time_ns=10,after_event_seq=0,ingress_face_id=10,
      anchor='BEFORE_AFTER_RECEIVE_INTEREST',fib_prefix='/hcraf',
      candidate_semantics='RAW_NAME_FIB_NOT_STRATEGY_ELIGIBILITY',
      candidates=[dict(face_id=20,routing_cost=1,is_ingress=False,strategy_eligible=None)])
    base=dict(schema_version='0.2',node_id=1,pit_instance_id=1,name=d['name'],
              face_id=20,deadline_ns=100,nonce=42,reason=-1,payload_bytes=-1)
    events=[dict(base,event_type='TX_INTEREST',time_ns=10,event_seq=1,decision_id=1),
            dict(base,event_type='SIMULATION_END',time_ns=50,event_seq=2,decision_id=0,pit_instance_id=0)]
    links=[]
    devices=[(0,10),(1,10),(1,20),(1,21),(2,10),(3,10)]
    counts={key:0 for key in devices}
    def emit(kind,t,key,decision=0):
        if kind=='PHY_TX_BEGIN': counts[key]+=64
        links.append(dict(link_event_seq=len(links)+1,event_type=kind,time_ns=t,node_id=key[0],
          face_id=key[1],device_index=devices.index(key),decision_id=decision,decision_node_id=1,
          queue_packets=0,queue_bytes=0,phy_tx_started_bytes_total=counts[key],
          queue_drop_packets_total=0,data_rate_bps=10000000,link_up=True,
          packet_bytes=64 if kind=='PHY_TX_BEGIN' else None))
    for key in devices: emit('INITIAL',0,key)
    for key in devices: emit('DECISION_SNAPSHOT',10,key,1)
    emit('PHY_TX_BEGIN',10,(1,20))
    for key in devices: emit('FINAL',50,key)
    write(folder,'events.jsonl',[*events])
    write(folder,'events.jsonl.decisions.jsonl',[d])
    write(folder,'link_events.jsonl',links)
    write(folder,'episodes.jsonl',reconstruct(events,'UNIT_TEST_ONLY'))
    (folder/'scenario.json').write_text(json.dumps(dict(mode='open',stop_ns=50,link_rate_bps=10000000)))
    return d,events,links

class DecisionTests(unittest.TestCase):
    def test_native_context_costs_and_pit_reuse(self):
        with tempfile.TemporaryDirectory() as temp:
            folder=Path(temp); binary=folder/'driver'; out=folder/'events'
            subprocess.run(['g++','-std=c++17','-Wall','-Wextra','-Werror','-pedantic',
              '-I'+str(ROOT/'src'),str(ROOT/'tests/decision_driver.cpp'),'-o',str(binary)],check=True,capture_output=True)
            subprocess.run([str(binary),str(out)],check=True)
            events=[json.loads(x) for x in out.read_text().splitlines()]
            ds=[json.loads(x) for x in Path(str(out)+'.decisions.jsonl').read_text().splitlines()]
            states=[json.loads(x) for x in Path(str(out)+'.states.jsonl').read_text().splitlines()]
            self.assertEqual(len(states),3)
            self.assertIsNone(states[0]['SuccessEstimate'])
            self.assertEqual(states[-1]['RoutingCost'],8)
            self.assertEqual(states[-1]['valid_outcomes'],1)
            self.assertAlmostEqual(states[-1]['SRTT_ms'],0.00001)
            self.assertEqual(states[-1]['last_outcome_evidence_age_ns'],10)
            self.assertEqual(len(ds),2)
            self.assertEqual([c['routing_cost'] for c in ds[0]['candidates']],[7,999])
            self.assertEqual([x['decision_id'] for x in events if x['event_type']=='TX_INTEREST'],[1,1,0])
            self.assertNotEqual(ds[0]['pit_instance_id'],ds[1]['pit_instance_id'])
            self.assertEqual(ds[1]['after_event_seq'],4)
            self.assertEqual([r['outcome'] for r in reconstruct(events,'UNIT_TEST_ONLY')],['SUCCESS','CANCELLED',None])
    def test_valid_fixture(self):
        with tempfile.TemporaryDirectory() as temp:
            f=Path(temp); fixture(f); rows,r=verify(f)
            self.assertEqual(r['status'],'PASS'); self.assertEqual(rows[0]['routing_cost'],1)
            self.assertIsNone(rows[0]['congestion']); self.assertTrue(rows[0]['selected'])
    def tamper(self, target, mutate):
        with tempfile.TemporaryDirectory() as temp:
            f=Path(temp); fixture(f)
            values=[json.loads(x) for x in (f/target).read_text().splitlines()]
            mutate(values); write(f,target,values)
            with self.assertRaises(ValueError): verify(f)
    def test_missing_decision_tx_rejected(self):
        self.tamper('events.jsonl',lambda v:v[0].update(decision_id=0))
    def test_future_snapshot_rejected(self):
        self.tamper('events.jsonl.decisions.jsonl',lambda v:v[0].update(time_ns=11))
    def test_wrong_cost_rejected(self):
        self.tamper('events.jsonl.decisions.jsonl',lambda v:v[0]['candidates'][0].update(routing_cost=7))
    def test_guessed_eligibility_rejected(self):
        self.tamper('events.jsonl.decisions.jsonl',lambda v:v[0]['candidates'][0].update(strategy_eligible=True))
    def test_counter_tamper_rejected(self):
        self.tamper('link_events.jsonl',lambda v:v[-1].update(phy_tx_started_bytes_total=999))
    def test_missing_link_snapshot_rejected(self):
        self.tamper('link_events.jsonl',lambda v:v.pop(6))
    def test_missing_final_rejected(self):
        self.tamper('link_events.jsonl',lambda v:v.pop())
    def test_wrong_pit_link_rejected(self):
        self.tamper('events.jsonl',lambda v:v[0].update(pit_instance_id=99))

if __name__=='__main__': unittest.main()
