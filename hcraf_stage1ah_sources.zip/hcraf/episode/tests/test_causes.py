"""Synthetic software tests only. Never data for thesis results."""
import json,tempfile,unittest
from pathlib import Path
from test_multi import fixture
from episodes import load,reconstruct
from verify_causes import check

def base(p):
 fixture(p,'multi-low')
 c=json.loads((p/'scenario.json').read_text());c.update(mode='control',instrumentation_stage='1G.1',primary_rate_bps=10000000,return_rate_bps=10000000)
 (p/'scenario.json').write_text(json.dumps(c))
 ds=load(p/'events.jsonl.decisions.jsonl')
 for d in ds:d['candidates']=d['candidates'][:1]
 ll=load(p/'link_events.jsonl')
 for x in ll:
  if x['node_id']==2 or (x['node_id']==1 and x['face_id']==20):x['data_rate_bps']=10000000
 for name,rows in [('events.jsonl.decisions.jsonl',ds),('link_events.jsonl',ll),('episodes.jsonl',reconstruct(load(p/'events.jsonl'),'control-seed1-run1'))]:
  (p/name).write_text(''.join(json.dumps(x)+'\n' for x in rows))
 (p/'fault_events.jsonl').write_text('')

class CauseTests(unittest.TestCase):
 def test_complete_control(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp);base(p);self.assertEqual(check(p)['episodes'],40)
   self.assertTrue((p/'decision_faces.jsonl').exists())
 def test_control_rx_drop_rejected(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp);base(p);(p/'fault_events.jsonl').write_text('{"event":"PHY_RX_DROP","time_ns":2000000000}\n')
   with self.assertRaises(ValueError):check(p)
 def test_capacity_tamper_rejected(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp);base(p);c=json.loads((p/'scenario.json').read_text());c['return_rate_bps']=128000;(p/'scenario.json').write_text(json.dumps(c))
   with self.assertRaises(ValueError):check(p)
 def test_unobserved_random_loss_rejected(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp);base(p);c=json.loads((p/'scenario.json').read_text());c['mode']='random-loss';(p/'scenario.json').write_text(json.dumps(c))
   e=reconstruct(load(p/'events.jsonl'),'random-loss-seed1-run1');(p/'episodes.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in e))
   with self.assertRaisesRegex(ValueError,'random loss evidence'):check(p)
