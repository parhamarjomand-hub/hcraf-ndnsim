// Regression test: artificial byte values only, not simulation observations.
#include "hcraf-recorder.hpp"
#include <cassert>
#include <type_traits>
// Same public base conversion used by the pinned ndn-cxx Interest::Nonce.
struct DerivedNonce final : std::array<uint8_t, 4> {};
int main() {
  assert(hcraf::Recorder::nonceValue({{0,0,0,0}}) == 0);
  assert(hcraf::Recorder::nonceValue({{0,0,3,233}}) == 1001);
  assert(hcraf::Recorder::nonceValue({{1,2,3,4}}) == 16909060);
  assert(hcraf::Recorder::nonceValue({{4,3,2,1}}) == 67305985);
  assert(hcraf::Recorder::nonceValue({{128,0,0,0}}) == 2147483648LL);
  assert(hcraf::Recorder::nonceValue({{255,255,255,255}}) == 4294967295LL);
  DerivedNonce nonce;
  nonce[0]=0; nonce[1]=0; nonce[2]=3; nonce[3]=233;
  assert(hcraf::Recorder::nonceValue(nonce) == 1001);
  static_assert(!std::is_convertible<DerivedNonce,int64_t>::value,
                "The regression test must not hide the original type mismatch");
}
