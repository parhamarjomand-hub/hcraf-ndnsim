"""Only artificial unit fixtures. Never classify them as experimental network data."""
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from verify_attribution import get_one,get_admission,packet_index,link_record,summary_uid,PRODUCER


def sample(kind='INTEREST', nonce=1001, uid=9, et='QUEUE_ENQUEUE', node=1, face=258, seq=1):
    return dict(schema_version='1R.1',link_event_seq=seq,event_type=et,
                time_ns=500,node_id=node,device_index=1,face_id=face,
                packet_uid=uid,wire_status='PILOT',ndn_packet_type=kind,
                ndn_name='/hcraf/pilot/0',ndn_nonce=nonce if kind=='INTEREST' else None,
                queue_wait_ns=None)

class AttributionTests(unittest.TestCase):
    def test_topology(self):self.assertEqual(PRODUCER,{258:2,259:3,260:4})
    def test_empty(self):
        by_uid,by_name,counts=packet_index([]);self.assertFalse(by_uid);self.assertFalse(by_name)
    def test_unique_identity(self):
        ev=sample();uid,by_name,counts=packet_index([ev])
        status,hit=get_one(by_name,(1,258,'INTEREST','/hcraf/pilot/0',1001,'QUEUE_ENQUEUE'),500)
        self.assertEqual(status,'MATCHED_UNIQUE');self.assertEqual(hit['packet_uid'],9)
    def test_name_nonce_mismatch(self):
        _,b,_=packet_index([sample()]);self.assertEqual(get_one(b,(1,258,'INTEREST','/hcraf/pilot/0',1002,'QUEUE_ENQUEUE'),500)[0],'NOT_OBSERVED')
    def test_time_bound(self):
        _,b,_=packet_index([sample()]);self.assertEqual(get_one(b,(1,258,'INTEREST','/hcraf/pilot/0',1001,'QUEUE_ENQUEUE'),501)[0],'NOT_OBSERVED')
    def test_wrong_face(self):
        _,b,_=packet_index([sample()]);self.assertEqual(get_one(b,(1,259,'INTEREST','/hcraf/pilot/0',1001,'QUEUE_ENQUEUE'),500)[0],'NOT_OBSERVED')
    def test_wrong_node(self):
        _,b,_=packet_index([sample()]);self.assertEqual(get_one(b,(2,258,'INTEREST','/hcraf/pilot/0',1001,'QUEUE_ENQUEUE'),500)[0],'NOT_OBSERVED')
    def test_data_has_no_nonce(self):
        _,b,_=packet_index([sample(kind='DATA',nonce=None,node=2,face=257)]);self.assertEqual(get_one(b,(2,257,'DATA','/hcraf/pilot/0',None,'QUEUE_ENQUEUE'),500)[0],'MATCHED_UNIQUE')
    def test_ambiguous(self):
        _,b,_=packet_index([sample(uid=8,seq=1),sample(uid=9,seq=2)]);
        self.assertEqual(get_one(b,(1,258,'INTEREST','/hcraf/pilot/0',1001,'QUEUE_ENQUEUE'),500)[0],'AMBIGUOUS_MULTIPLE_PACKETS')
    def test_admission_duplicate_drop_and_enqueue_ambiguous(self):
        _,by_name,_=packet_index([sample(uid=4),sample(uid=5,et='QUEUE_DROP',seq=2)])
        status,_=get_admission(by_name,(1,258,'INTEREST','/hcraf/pilot/0',1001),500)
        self.assertEqual(status,'AMBIGUOUS_MULTIPLE_PACKETS')
    def test_cross_device_uid_not_confused(self):
        e1=sample(uid=5,node=1,face=258);e2=sample(uid=5,node=2,face=257,seq=2)
        ids,b,_=packet_index([e1,e2]);self.assertEqual(len(ids),2)
    def test_uid_conflict_fails_closed(self):
        e1=sample();e2=sample(et='PHY_TX_BEGIN',seq=2);e2['ndn_nonce']=1002
        with self.assertRaises(ValueError):packet_index([e1,e2])
    def test_snapshot_no_packet(self):
        e=sample();e['packet_uid']=None;e['wire_status']='NO_PACKET';e['ndn_name']=None;e['ndn_nonce']=None
        packet_index([e])
    def test_snapshot_fake_name_fails(self):
        e=sample();e['packet_uid']=None;e['wire_status']='NO_PACKET';e['ndn_nonce']=None
        with self.assertRaises(ValueError):packet_index([e])
    def test_uid_queue_wait(self):
        e=sample();d=sample(et='QUEUE_DEQUEUE',seq=2);d['queue_wait_ns']=7
        ids,b,_=packet_index([e,d]);info=link_record(e,ids)
        self.assertEqual(info['queue_wait_ns'],7)
    def test_drop_no_transmit(self):
        e=sample(et='QUEUE_DROP');ids,b,_=packet_index([e]);self.assertEqual(link_record(e,ids)['admission'],'QUEUE_DROP')
    def test_drop_and_tx_fails(self):
        e=sample(et='QUEUE_DROP');x=sample(et='PHY_TX_BEGIN',seq=2)
        ids,b,_=packet_index([e,x]);
        with self.assertRaises(ValueError):link_record(e,ids)
    def test_no_decoding_pilot_fails(self):
        e=sample();e['wire_status']='INVALID';e['ndn_name']='/hcraf/pilot/0'
        with self.assertRaises(ValueError):packet_index([e])
    def test_out_of_scope_fails(self):
        e=sample();e['ndn_name']='/other/0'
        with self.assertRaises(ValueError):packet_index([e])
    def test_no_admission_event_fails(self):
        e=sample(et='PHY_TX_BEGIN')
        with self.assertRaises(ValueError):packet_index([e])
    def test_mac_rx_only_uid_allowed(self):
        e=sample(et='MAC_RX',node=2,face=257)
        ids,b,_=packet_index([e])
        status,hit=get_one(b,(2,257,'INTEREST','/hcraf/pilot/0',1001,'MAC_RX'),500)
        self.assertEqual(status,'MATCHED_UNIQUE')
        self.assertEqual(hit['packet_uid'],9)
    def test_phy_rx_drop_only_is_preserved(self):
        e=sample(et='PHY_RX_DROP',node=2,face=257)
        ids,b,_=packet_index([e]);self.assertEqual(len(ids),1);self.assertFalse(b)
    def test_mac_rx_and_queue_same_uid_disallowed(self):
        e=sample(et='QUEUE_ENQUEUE');x=sample(et='MAC_RX',seq=2)
        with self.assertRaises(ValueError):packet_index([e,x])

if __name__=='__main__':unittest.main()
