"""Stage1T software tests. Mutation cases are TEST FIXTURES, not research observations."""
import copy
import sys
from pathlib import Path
import unittest

sys.path.insert(0,str(Path(__file__).parents[1]/'scripts'))
from verify_data_pit_stage1t import audit, audit_rows, read_run, EvidenceError

ROOT=Path(__file__).resolve().parents[4]/'artifact'/'stage1s'
# Environment override is required when running source package on another system.
import os
ROOT=Path(os.environ.get('HCRAF_STAGE1S_RUN_ROOT',str(ROOT)))

class Stage1TTest(unittest.TestCase):
    def data(self,mode='repeat-name',run=1001):
        p=ROOT/mode/('run-%d'%run)
        self.assertTrue(p.is_dir(),str(p))
        return read_run(p)
    def audit(self,mode='repeat-name',run=1001):
        cfg,info=self.data(mode,run)
        return audit_rows(cfg,info)
    def changed(self,edit,mode='repeat-name'):
        cfg,info=self.data(mode)
        info=copy.deepcopy(info)
        edit(info)
        return audit_rows(cfg,info)
    def test_both_runs_every_mode(self):
        for mode in ('baseline','repeat-name','retransmission','aggregation','cache-hit','multi-hop'):
            for run in (1001,1002):
                with self.subTest(mode=mode,run=run):
                    rows,extras,s=self.audit(mode,run)
                    self.assertEqual(s['validation'],'PASS')
                    self.assertEqual(s['matched_success_data'],s['success_episode_count'])
    def test_repeat_name_not_assigned_by_name_only(self):
        rows,_,s=self.audit('repeat-name')
        self.assertEqual(s['matched_success_data'],8)
        self.assertEqual(len({(r['name'],r['pit_instance_id']) for r in rows}),8)
        self.assertLess(len({r['name'] for r in rows}),8)
    def test_retransmission_cancelled_never_success(self):
        rows,extras,s=self.audit('retransmission')
        self.assertEqual(s['episode_status_counts']['NO_MATCH_CANCELLED'],4)
        self.assertEqual(s['matched_success_data'],4)
        self.assertTrue(all(x['data_mac_rx_event_seq'] is None for x in rows if x['outcome']=='CANCELLED'))
        self.assertEqual(len([x for x in extras if x['type']=='UNSOLICITED_DATA']),4)
    def test_cache_not_credited_to_transmitted_episode(self):
        rows,extras,s=self.audit('cache-hit')
        self.assertEqual(len(rows),4)
        self.assertEqual(len([x for x in extras if x['type']=='CACHE_HIT']),4)
        self.assertTrue(all(x['episode_id'] is None for x in extras))
    def test_multi_hop_physical_receiver(self):
        rows,_,_=self.audit('multi-hop')
        self.assertTrue(all(x['receiver_packet_uid'] is not None for x in rows))
        self.assertTrue(all(x['sender_node_id'] in (2,3,4) for x in rows))
    def test_duplicate_mac_rx_is_ambiguous(self):
        def corrupt(info):
            orig=next(x for x in info['link'] if x['event_type']=='MAC_RX' and x.get('ndn_packet_type')=='DATA' and x['node_id']==1)
            clone=copy.deepcopy(orig);clone['link_event_seq']=max(x['link_event_seq'] for x in info['link'])+1
            info['link'].append(clone)
        rows,_,s=self.changed(corrupt)
        self.assertEqual(s['validation'],'INCOMPLETE')
        self.assertIn('AMBIGUOUS_MAC_RX',[x['status'] for x in rows])
    def test_missing_mac_rx_is_unobserved(self):
        def corrupt(info):
            orig=next(x for x in info['link'] if x['event_type']=='MAC_RX' and x.get('ndn_packet_type')=='DATA' and x['node_id']==1)
            info['link'].remove(orig)
        rows,_,s=self.changed(corrupt)
        self.assertEqual(s['validation'],'INCOMPLETE')
        self.assertIn('NOT_OBSERVED_MAC_RX',[x['status'] for x in rows])
    def test_duplicate_nfd_match_is_ambiguous(self):
        def corrupt(info):
            orig=next(x for x in info['nfd'] if x['event_type']=='DATA_MATCH')
            clone=copy.deepcopy(orig);clone['event_seq']=max(x['event_seq'] for x in info['nfd'])+1
            info['nfd'].append(clone)
        with self.assertRaises(EvidenceError):self.changed(corrupt)
    def test_wire_status_missing_is_not_positive(self):
        def corrupt(info):
            orig=next(x for x in info['link'] if x['event_type']=='MAC_RX' and x.get('ndn_packet_type')=='DATA' and x['node_id']==1)
            orig['wire_status']='UNSUPPORTED'
        rows,_,s=self.changed(corrupt)
        self.assertEqual(s['validation'],'INCOMPLETE')
    def test_wrong_face_not_positive(self):
        def corrupt(info):
            orig=next(x for x in info['nfd'] if x['event_type']=='DATA_MATCH')
            orig['face_id']=999
        with self.assertRaises(EvidenceError):self.changed(corrupt)
    def test_episode_terminal_time_mismatch(self):
        def corrupt(info):
            ep=next(x for x in info['episodes'] if x['outcome']=='SUCCESS')
            ep['end_ns']+=1
        rows,_,s=self.changed(corrupt)
        self.assertEqual(s['validation'],'INCOMPLETE')
        self.assertIn('INCONSISTENT_PIT_TIME',[x['status'] for x in rows])
    def test_episode_terminal_event_mismatch(self):
        def corrupt(info):
            ep=next(x for x in info['episodes'] if x['outcome']=='SUCCESS')
            ep['terminal_event_seq']+=100
        rows,_,s=self.changed(corrupt)
        self.assertIn('INCONSISTENT_TERMINAL_EVENT',[x['status'] for x in rows])
    def test_missing_sender_proof_fails_closed(self):
        def corrupt(info):
            orig=next(x for x in info['link'] if x['event_type']=='PHY_TX_END' and x.get('ndn_packet_type')=='DATA')
            info['link'].remove(orig)
        rows,_,s=self.changed(corrupt)
        self.assertEqual(s['validation'],'INCOMPLETE')
        self.assertIn('NOT_OBSERVED_SENDER',[x['status'] for x in rows])
    def test_ambiguous_sender_fails_closed(self):
        def corrupt(info):
            orig=next(x for x in info['link'] if x['event_type']=='PHY_TX_END' and x.get('ndn_packet_type')=='DATA')
            clone=copy.deepcopy(orig);clone['link_event_seq']=max(x['link_event_seq'] for x in info['link'])+1
            clone['packet_uid']=87654321
            info['link'].append(clone)
        rows,_,s=self.changed(corrupt)
        self.assertEqual(s['validation'],'INCOMPLETE')
        self.assertIn('AMBIGUOUS_SENDER',[x['status'] for x in rows])
    def test_packet_uid_wire_contradiction_rejected(self):
        def corrupt(info):
            orig=next(x for x in info['link'] if x['event_type']=='MAC_RX' and x.get('ndn_packet_type')=='DATA' and x['node_id']==1)
            clone=copy.deepcopy(orig);clone['ndn_name']='/hcraf/pilot/conflict';clone['event_type']='PHY_TX_END'
            clone['link_event_seq']=max(x['link_event_seq'] for x in info['link'])+1
            info['link'].append(clone)
        with self.assertRaises(EvidenceError):self.changed(corrupt)
    def test_false_congestion_label_rejected(self):
        cfg,info=self.data();cfg['final_congestion_label']=1
        with self.assertRaises(EvidenceError):audit_rows(cfg,info)
    def test_duplicate_episode_id_rejected(self):
        def corrupt(info):info['episodes'][1]['episode_id']=info['episodes'][0]['episode_id']
        with self.assertRaises(EvidenceError):self.changed(corrupt)
    def test_duplicate_physical_seq_rejected(self):
        def corrupt(info):info['link'][1]['link_event_seq']=info['link'][0]['link_event_seq']
        with self.assertRaises(EvidenceError):self.changed(corrupt)
    def test_outcome_without_data_stays_cancelled(self):
        rows,_,_=self.audit('retransmission')
        self.assertEqual(sum(r['outcome']=='CANCELLED' for r in rows),4)
        self.assertEqual(sum(r['status']=='MATCHED_UNIQUE_PIT_DATA' for r in rows if r['outcome']=='CANCELLED'),0)
    def test_run_level_immutable_provenance(self):
        cfg,info=self.data('baseline')
        self.assertIs(cfg['training_ready'],False)
        self.assertIsNone(cfg['future_congestion_label'])
        self.assertIsNone(cfg['final_congestion_label'])
        rows,extras,s=audit_rows(cfg,info)
        self.assertIsNone(s['Congestion']);self.assertIsNone(s['FutureCongestion'])
        self.assertIs(s['training_ready'],False)

if __name__=='__main__':unittest.main()
