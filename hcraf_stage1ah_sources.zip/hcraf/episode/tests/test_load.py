"""Artificial software fixtures, never scientific observations."""
import copy
from pathlib import Path
import sys
import unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from verify_load import link_busy_intervals,check_load_evidence

def phy(kind,t,uid=1,node=1,face=20):
    return dict(event_type=kind,time_ns=t,packet_uid=uid,packet_bytes=100,node_id=node,face_id=face)

class LoadTests(unittest.TestCase):
    def test_utilization_clips_both_window_edges(self):
        events=[phy('PHY_TX_BEGIN',5),phy('PHY_TX_END',15),
                phy('PHY_TX_BEGIN',18,2),phy('PHY_TX_END',25,2)]
        result=link_busy_intervals(events,10,20)[0]
        self.assertEqual(result['busy_ns'],7)
        self.assertEqual(result['observed_busy_fraction'],0.7)
    def test_no_bytes_rate_shortcut(self):
        result=link_busy_intervals([phy('PHY_TX_BEGIN',0),phy('PHY_TX_END',10)],5,10)[0]
        self.assertEqual(result['busy_ns'],5)
    def test_open_transmission_rejected(self):
        with self.assertRaises(ValueError): link_busy_intervals([phy('PHY_TX_BEGIN',1)],0,10)
    def test_overlap_rejected(self):
        with self.assertRaises(ValueError): link_busy_intervals([phy('PHY_TX_BEGIN',1),phy('PHY_TX_BEGIN',2,2)],0,10)
    def test_packet_mismatch_rejected(self):
        with self.assertRaises(ValueError): link_busy_intervals([phy('PHY_TX_BEGIN',1),phy('PHY_TX_END',2,2)],0,10)
    def test_missing_start_rejected(self):
        with self.assertRaises(ValueError): link_busy_intervals([phy('PHY_TX_END',2)],0,10)
    def high(self):
        return ('load-high',[dict(node_id=1,face_id=20,local_queue_packets=3)],
                [dict(outcome='SUCCESS'),dict(outcome='TIMEOUT')],
                [dict(event_type='QUEUE_DROP',node_id=1,face_id=20),
                 dict(event_type='FINAL',node_id=1,face_id=20,queue_packets=0)],[],[])
    def test_measured_local_congestion_accepted(self):
        result=check_load_evidence(*self.high())
        self.assertEqual(result['local_candidate_queue_drop_events'],1)
    def test_remote_congestion_cannot_replace_local_evidence(self):
        args=list(self.high());args[3][0]['node_id']=2
        with self.assertRaises(ValueError): check_load_evidence(*args)
    def test_missing_decision_queue_evidence_rejected(self):
        args=list(self.high());args[1][0]['local_queue_packets']=0
        with self.assertRaises(ValueError): check_load_evidence(*args)
    def test_censored_not_relabelled_timeout(self):
        args=list(self.high());args[2][1]['outcome']=None
        with self.assertRaises(ValueError): check_load_evidence(*args)
    def test_nonempty_final_queue_rejected(self):
        args=list(self.high());args[3][1]['queue_packets']=1
        with self.assertRaises(ValueError): check_load_evidence(*args)
    def test_low_control_acceptance(self):
        r=check_load_evidence('load-low',[],[dict(outcome='SUCCESS')],[],[1],[1])
        self.assertEqual(r['total_queue_drop_events'],0)
    def test_low_control_failure_rejected(self):
        with self.assertRaises(ValueError): check_load_evidence('load-low',[],[dict(outcome='TIMEOUT')],[],[1],[])

if __name__=='__main__': unittest.main()
