// Artificial unit-test events, NOT simulator output or scientific observations.
#include "hcraf-recorder.hpp"
int main(int argc, char** argv) {
  if (argc != 2) return 2;
  hcraf::Recorder recorder(argv[1], 1);
  int object = 0;
  recorder.event("TX_INTEREST", &object, "/unit/\"\\\n", 10, 2, 100, 7);
  recorder.event("PIT_SATISFIED", &object, "/unit/\"\\\n", 20, 2, -1, -1, -1, 1024);
  recorder.event("PIT_FINALIZE", &object, "/unit/\"\\\n", 20, -1, -1, -1, 1);
  // Same memory address after erase must receive a NEW PIT instance identifier.
  recorder.event("TX_INTEREST", &object, "/unit/new", 30, 2, 130, 8);
  recorder.finish(50);
}
