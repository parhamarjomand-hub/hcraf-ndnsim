"""Synthetic unit fixtures verify acceptance logic. Not simulation results."""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from verify_stage1u import observed_late_duplicate_and_cross_face


def record(ord, time, face, count, name='/hcraf/pilot/0'):
    return dict(rx_ordinal=ord, time_ns=time, ingress_face_id=face,
                match_count=count, name=name)


class ContentionCoverageTests(unittest.TestCase):
    def test_same_name_late_unmatched_data(self):
        rows=[record(1,100,258,1),record(2,200,258,0)]
        self.assertEqual(observed_late_duplicate_and_cross_face(rows),(1,0))

    def test_cross_face_unmatched_data(self):
        rows=[record(1,100,258,1),record(2,200,259,0)]
        self.assertEqual(observed_late_duplicate_and_cross_face(rows),(1,1))

    def test_no_pit_without_prior_match_not_positive(self):
        self.assertEqual(observed_late_duplicate_and_cross_face([record(1,100,258,0)]),(0,0))

    def test_unmatched_before_match_not_positive(self):
        rows=[record(1,100,259,0),record(2,200,258,1)]
        self.assertEqual(observed_late_duplicate_and_cross_face(rows),(0,0))

    def test_same_timestamp_not_assumed_ordered_match(self):
        rows=[record(1,100,258,1),record(2,100,259,0)]
        self.assertEqual(observed_late_duplicate_and_cross_face(rows),(0,0))

    def test_other_name_not_duplicate(self):
        rows=[record(1,100,258,1),record(2,200,259,0,'/hcraf/pilot/1')]
        self.assertEqual(observed_late_duplicate_and_cross_face(rows),(0,0))

    def test_multiple_unmatched_counted_without_pit_fabrication(self):
        rows=[record(1,100,258,1),record(2,200,259,0),record(3,300,260,0)]
        self.assertEqual(observed_late_duplicate_and_cross_face(rows),(2,2))

    def test_multiple_matched_not_falsely_counted_as_unmatched(self):
        rows=[record(1,100,258,1),record(2,200,259,2)]
        self.assertEqual(observed_late_duplicate_and_cross_face(rows),(0,0))

if __name__ == '__main__':
    unittest.main()
