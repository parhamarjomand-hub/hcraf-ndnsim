"""End-to-end verifier test using explicitly artificial input, not ndnSIM results."""
import json
from pathlib import Path
import sys
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from episodes import reconstruct
from verify_load import verify


def make_fixture(folder):
    events=[];decisions=[];links=[];consumer=[]
    devices=[(0,10),(1,10),(1,20),(1,21),(2,10),(3,10)]
    total={k:0 for k in devices}
    def link(kind,t,key,decision=0,uid=None):
        if kind=='PHY_TX_BEGIN':total[key]+=100
        links.append(dict(schema_version='1B.1',link_event_seq=len(links)+1,event_type=kind,time_ns=t,
          decision_id=decision,decision_node_id=1,node_id=key[0],face_id=key[1],device_index=devices.index(key),
          queue_packets=0,queue_bytes=0,phy_tx_started_bytes_total=total[key],queue_drop_packets_total=0,
          link_up=True,data_rate_bps=128000 if key in ((1,20),(2,10)) else 10000000,
          packet_uid=uid,packet_bytes=100 if uid is not None else None))
    for key in devices:link('INITIAL',0,key)
    for i in range(20):
        send=1000000000+i*200000000;t=send+10000000;name='/hcraf/pilot/'+str(i)
        decisions.append(dict(schema_version='1B.1',decision_id=i+1,node_id=1,pit_instance_id=i+1,
          name=name,time_ns=t,after_event_seq=len(events),ingress_face_id=10,
          anchor='BEFORE_AFTER_RECEIVE_INTEREST',fib_prefix='/hcraf',
          candidate_semantics='RAW_NAME_FIB_NOT_STRATEGY_ELIGIBILITY',
          candidates=[dict(face_id=20,routing_cost=1,is_ingress=False,strategy_eligible=None)]))
        base=dict(schema_version='0.2',node_id=1,pit_instance_id=i+1,name=name,face_id=20,
                  nonce=i+1,deadline_ns=t+1000000000,reason=-1,payload_bytes=-1)
        for kind,at,extra in [('TX_INTEREST',t,dict(decision_id=i+1)),
                              ('PIT_SATISFIED',t+80000000,dict(payload_bytes=1024)),
                              ('PIT_FINALIZE',t+80000000,dict(reason=1))]:
            e=dict(base,event_type=kind,time_ns=at,event_seq=len(events)+1);e.update(extra);events.append(e)
        consumer.extend([dict(event='SEND',time_ns=send,name=name),
                         dict(event='DATA',time_ns=send+100000000,name=name,payload_bytes=1024)])
        for key in devices:link('DECISION_SNAPSHOT',t,key,i+1)
        link('PHY_TX_BEGIN',t+1,(1,20),uid=i)
        link('PHY_TX_END',t+6250001,(1,20),uid=i)
    events.append(dict(base,event_type='SIMULATION_END',time_ns=9000000000,event_seq=len(events)+1,pit_instance_id=0))
    for key in devices:link('FINAL',9000000000,key)
    cfg=dict(mode='load-low',instrumentation_stage='1C.1',request_rate_per_s=5,planned_requests=20,
      stop_ns=9000000000,traffic_start_ns=1000000000,traffic_stop_exclusive_ns=5000000000,
      bottleneck_rate_bps=128000,link_rate_bps=10000000,queue_capacity_packets=20,
      interest_lifetime_ms=1000,payload_bytes=1024,cs_packets=0,consumer_retransmissions=False)
    (folder/'scenario.json').write_text(json.dumps(cfg))
    for filename,rows in [('events.jsonl',events),('events.jsonl.decisions.jsonl',decisions),
                          ('link_events.jsonl',links),('consumer_events.jsonl',consumer),
                          ('episodes.jsonl',reconstruct(events,'UNIT_TEST_ONLY'))]:
        (folder/filename).write_text(''.join(json.dumps(x)+'\n' for x in rows))

class LoadIntegrationTests(unittest.TestCase):
    def test_complete_artificial_fixture(self):
        with tempfile.TemporaryDirectory() as temp:
            f=Path(temp);make_fixture(f);rows,report=verify(f)
            self.assertEqual(report['status'],'PASS')
            self.assertEqual(len(rows),20)
            self.assertEqual(report['consumer_goodput_active_window_bps'],40960)
            self.assertEqual(report['consumer_goodput_full_observation_bps'],20480)
    def test_offered_timing_tamper_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            f=Path(temp);make_fixture(f)
            p=f/'consumer_events.jsonl';v=[json.loads(x) for x in p.read_text().splitlines()]
            v[0]['time_ns']+=1;p.write_text(''.join(json.dumps(x)+'\n' for x in v))
            with self.assertRaises(ValueError):verify(f)

if __name__=='__main__':unittest.main()
