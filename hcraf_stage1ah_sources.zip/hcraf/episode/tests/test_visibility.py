"""Synthetic fixture tests ONLY. Not research evidence or simulator output."""
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from verify_visibility import verify_trace


def example():
    ev=[]
    devices=[(0,0),(1,0),(1,1),(2,0),(1,2),(3,0),(1,3),(4,0)]
    previous_drop={i:0 for i in devices}
    previous_tx={i:0 for i in devices}
    def add(ty,t,dev,**kw):
        d=dict(schema_version='1P.1',link_event_seq=len(ev)+1,event_type=ty,time_ns=t,
            node_id=dev[0],device_index=dev[1],face_id=258 if dev==(1,1) else 999,
            decision_id=0,queue_packets=0,LocalQueueOccupancyFraction=0.0,
            queue_drop_packets_total=previous_drop[dev],phy_tx_started_bytes_total=previous_tx[dev],
            packet_uid=None,packet_bytes=None,queue_wait_ns=None)
        if ty=='QUEUE_DROP':d['queue_drop_packets_total']+=1
        if ty=='PHY_TX_BEGIN':d['phy_tx_started_bytes_total']+=kw['packet_bytes']
        d.update(kw)
        previous_drop[dev]=d['queue_drop_packets_total']
        previous_tx[dev]=d['phy_tx_started_bytes_total']
        ev.append(d)
    for device in devices:add('INITIAL',0,device)
    for device in devices:add('DECISION_SNAPSHOT',10,device,decision_id=1)
    add('QUEUE_ENQUEUE',100,(1,1),packet_uid=4,packet_bytes=90,queue_packets=1,LocalQueueOccupancyFraction=0.05)
    add('QUEUE_DEQUEUE',110,(1,1),packet_uid=4,packet_bytes=90,queue_wait_ns=10)
    add('PHY_TX_BEGIN',110,(1,1),packet_uid=4,packet_bytes=90)
    for device in devices:add('FINAL',200,device)
    return ev

class Stage1PTraceContractTests(unittest.TestCase):
    def test_valid(self):
        d=verify_trace(example())
        self.assertEqual(d['observed_directions'],8)
        self.assertEqual(d['decisions_with_complete_snapshots'],1)
        self.assertEqual(d['directions']['1:1']['max_observed_wait_ns'],10)
        self.assertTrue(d['directions']['1:1']['diagnostic_queueing_without_drop'])
    def test_missing_direction(self):
        d=[e for e in example() if not (e['node_id']==4 and e['device_index']==0)]
        for i,e in enumerate(d,1):e['link_event_seq']=i
        with self.assertRaisesRegex(ValueError,'eight monitored'):verify_trace(d)
    def test_duplicate_seq(self):
        d=example();d[3]['link_event_seq']=1
        with self.assertRaisesRegex(ValueError,'seq discontinuity'):verify_trace(d)
    def test_non_monotone(self):
        d=example();d[9]['time_ns']=-1
        with self.assertRaisesRegex(ValueError,'non-monotonic'):verify_trace(d)
    def test_wrong_schema(self):
        d=example();d[0]['schema_version']='1M.1'
        with self.assertRaisesRegex(ValueError,'wrong schema'):verify_trace(d)
    def test_wrong_wait(self):
        d=example(); next(e for e in d if e['event_type']=='QUEUE_DEQUEUE')['queue_wait_ns']=11
        with self.assertRaisesRegex(ValueError,'wait differs'):verify_trace(d)
    def test_missing_enqueue(self):
        d=[e for e in example() if e['event_type']!='QUEUE_ENQUEUE']
        for i,e in enumerate(d,1):e['link_event_seq']=i
        with self.assertRaisesRegex(ValueError,'wait without an enqueue'):verify_trace(d)
    def test_missing_snapshot_direction(self):
        d=[e for e in example() if not (e['event_type']=='DECISION_SNAPSHOT' and e['node_id']==2)]
        for i,e in enumerate(d,1):e['link_event_seq']=i
        with self.assertRaisesRegex(ValueError,'incomplete decision snapshot'):verify_trace(d)
    def test_invalid_occupancy(self):
        d=example();d[-1]['queue_packets']=22
        with self.assertRaisesRegex(ValueError,'queue capacity'):verify_trace(d)
    def test_invalid_fraction(self):
        d=example();d[-1]['LocalQueueOccupancyFraction']=0.5
        with self.assertRaisesRegex(ValueError,'fraction'):verify_trace(d)
    def test_tampered_counter(self):
        d=example();d[-1]['queue_drop_packets_total']=2
        with self.assertRaisesRegex(ValueError,'delta mismatch'):verify_trace(d)
    def test_missing_final(self):
        d=example()[:-1]
        with self.assertRaisesRegex(ValueError,'initial/final'):verify_trace(d)
    def test_positive_wait_not_congestion_label(self):
        d=verify_trace(example())
        self.assertNotIn('FutureCongestion',d)
        self.assertNotIn('Congestion',d)
    def test_drop_overrides_clean_queueing_diagnostic(self):
        d=example()
        drop=next(e for e in d if e['event_type']=='FINAL' and e['node_id']==1 and e['device_index']==1)
        idx=next(i for i,e in enumerate(d) if e['event_type']=='FINAL')
        ev=dict(drop,event_type='QUEUE_DROP',time_ns=190,packet_uid=5,packet_bytes=100,decision_id=0,queue_drop_packets_total=1)
        d.insert(idx,ev)
        for i in range(idx+1,len(d)):
            if d[i]['node_id']==1 and d[i]['device_index']==1:d[i]['queue_drop_packets_total']=1
        for i,e in enumerate(d,1):e['link_event_seq']=i
        outcome=verify_trace(d)
        self.assertFalse(outcome['directions']['1:1']['diagnostic_queueing_without_drop'])
if __name__=='__main__':unittest.main()
