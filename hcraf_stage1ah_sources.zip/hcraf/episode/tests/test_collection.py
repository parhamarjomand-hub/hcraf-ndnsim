"""Synthetic unit fixtures, never research observations."""
import json,sys,subprocess,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from verify_collection import check

class CollectionTest(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.tmp=tempfile.TemporaryDirectory();cls.work=Path(cls.tmp.name)
  (cls.work/'driver.cpp').write_text(r'''
#include "hcraf-recorder.hpp"
#include <cstdlib>
int main(int argc,char**argv) {
 hcraf::Recorder r(argv[1],1,"/hcraf/pilot"); int pit=1;
 auto id=r.beginDecision(&pit,"/hcraf/pilot/0",1000000000,9,"/hcraf",{{10,1},{11,2}});
 r.collection(10,11,std::stod(argv[2]),std::stod(argv[3]));r.endDecision(id);r.finish(2000000000);
}
''')
  subprocess.run(['g++','-std=c++17','-Wall','-Wextra','-I'+str(ROOT/'src'),str(cls.work/'driver.cpp'),'-o',str(cls.work/'driver')],check=True,capture_output=True)
 @classmethod
 def tearDownClass(cls):cls.tmp.cleanup()
 def fixture(self,p,u):
  out=self.work/'events'
  subprocess.run([str(self.work/'driver'),str(out),str(p),str(u)],check=True,capture_output=True)
  c=json.loads(Path(str(out)+'.collection.jsonl').read_text());d=json.loads(Path(str(out)+'.decisions.jsonl').read_text())
  tx=[dict(face_id=f,pit_instance_id=d['pit_instance_id'],name=d['name'],time_ns=d['time_ns'],event_seq=i+1) for i,f in enumerate([10,11] if u<p else [10])]
  return c,d,tx
 def test_zero(self):check(*self.fixture(0,0))
 def test_one(self):check(*self.fixture(1,.99999))
 def test_boundary_excluded(self):check(*self.fixture(.05,.05))
 def test_below_selected(self):check(*self.fixture(.05,.0499))
 def test_missing_probe_rejected(self):
  c,d,t=self.fixture(1,.2)
  with self.assertRaises(ValueError):check(c,d,t[:1])
 def test_extra_probe_rejected(self):
  c,d,t=self.fixture(0,.2);t.append(dict(t[0],face_id=11))
  with self.assertRaises(ValueError):check(c,d,t)
 def test_wrong_probability_rejected(self):
  c,d,t=self.fixture(.05,.01);c['joint_action_probability']=.95
  with self.assertRaises(ValueError):check(c,d,t)
 def test_future_anchor_rejected(self):
  c,d,t=self.fixture(0,.2);t[0]['event_seq']=d['after_event_seq']
  with self.assertRaises(ValueError):check(c,d,t)
 def test_ingress_rejected(self):
  c,d,t=self.fixture(0,.2);d['candidates'][0]['is_ingress']=True
  with self.assertRaises(ValueError):check(c,d,t)
 def test_nan_probability_rejected(self):
  c,d,t=self.fixture(0,.2);c['probe_probability']=float('nan')
  with self.assertRaises(ValueError):check(c,d,t)
