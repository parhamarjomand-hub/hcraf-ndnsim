#include "hcraf-recorder.hpp"
int main(int argc, char** argv) {
  if (argc != 2) return 2;
  hcraf::Recorder recorder(argv[1], 1, "/hcraf/pilot");
  int a=0,b=0,c=0;
  recorder.event("TX_INTEREST", &a, "/localhost/nfd/test", 0, 1, 100, 1);
  recorder.event("TX_INTEREST", &b, "/hcraf/pilot-extra/0", 1, 2, 100, 2);
  recorder.event("TX_INTEREST", &c, "/hcraf/pilot/0", 10, 258, 100, 3);
  recorder.event("PIT_SATISFIED", &c, "/hcraf/pilot/0", 20, 258, -1, -1, -1, 1024);
  recorder.finish(50);
}
