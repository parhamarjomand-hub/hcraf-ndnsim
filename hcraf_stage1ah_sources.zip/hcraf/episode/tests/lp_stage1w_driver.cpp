#include "hcraf-stage1w-lp.hpp"
#include <cassert>
#include <iostream>
#include <vector>
using namespace hcraf::lp1w;
int main() {
  // Test fixture, never a simulation measurement.
  // LP=100; Sequence=1001; FragIndex=1; FragCount=3; Fragment arbitrary two bytes.
  std::vector<uint8_t> good={100,18,81,2,3,233,82,1,1,83,1,3,80,2,0xAB,0xCD};
  good[1]=14;
  auto a=decode(good);
  assert(a.status=="FRAGMENT" && a.seq==1001 && a.index==1 && a.count==3 && a.group==1000);
  std::vector<uint8_t> ppp={0,0};ppp.insert(ppp.end(),good.begin(),good.end());
  auto b=decode(ppp);
  assert(b.status=="FRAGMENT" && b.offset==2 && b.payload.size()==2);
  auto bad=good;bad[9]=0;assert(decode(bad).status=="INVALID_LP");
  auto noseq=good;noseq.erase(noseq.begin()+2,noseq.begin()+6);noseq[1]=10;
  assert(decode(noseq).status=="INVALID_LP");
  // Regression from real 1W v0.21.1: first LP Sequence=UINT64_MAX,
  // next LP Sequence=0. Both belong to the SAME fragmented Data group.
  std::vector<uint8_t> maxSeq={100,26,81,8,
    255,255,255,255,255,255,255,255,82,1,0,83,1,8,80,8,
    0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08};
  maxSeq[1]=26;
  auto maxFrag=decode(maxSeq);
  assert(maxFrag.status=="FRAGMENT" && maxFrag.seq==UINT64_MAX &&
         maxFrag.index==0 && maxFrag.count==8 && maxFrag.group==UINT64_MAX);
  auto zeroSeq=maxSeq;
  for(size_t i=4;i<12;++i)zeroSeq[i]=0;
  zeroSeq[14]=1;
  auto wrapFrag=decode(zeroSeq);
  assert(wrapFrag.status=="FRAGMENT" && wrapFrag.seq==0 &&
         wrapFrag.index==1 && wrapFrag.group==UINT64_MAX);
  auto badWrap=zeroSeq;
  badWrap[14]=8; // FragIndex must remain strictly below FragCount.
  assert(decode(badWrap).status=="INVALID_LP");
  std::cout<<"Stage1W LP fixture tests PASS\n";
}
