#include "hcraf-state.hpp"
#include <iostream>
#include <iomanip>
#include <string>
template<class T> void value(const std::optional<T>& x){if(x)std::cout<<*x;else std::cout<<"null";}
int main(){
 hcraf::State state; std::cout<<std::setprecision(17);char op;
 while(std::cin>>op){
  if(op=='E'){
   std::string kind;uint64_t seq,pit;int64_t face,t,deadline,nonce,bytes;
   std::cin>>seq>>kind>>pit>>face>>t>>deadline>>nonce>>bytes;
   if(!std::cin)return 2;
   state.event(kind,pit,face,t,deadline,nonce,bytes,seq);
  }else if(op=='Q'){
   uint64_t id,seq,cost;int64_t face,t;std::cin>>id>>face>>t>>seq>>cost;
   if(!std::cin)return 2;
   auto s=state.sample(face,t);
   std::cout<<"{\"decision_id\":"<<id<<",\"face_id\":"<<face<<",\"time_ns\":"<<t<<",\"after_event_seq\":"<<seq<<",\"RoutingCost\":"<<cost;
   std::cout<<",\"SRTT_ms\":";value(s.srttMs);
   std::cout<<",\"SuccessEstimate\":";value(s.successEstimate);
   std::cout<<",\"Goodput_bps\":";value(s.goodputBps);
   std::cout<<",\"last_outcome_evidence_age_ns\":";value(s.outcomeAge);
   std::cout<<",\"last_rtt_evidence_age_ns\":";value(s.rttAge);
   std::cout<<",\"valid_outcomes\":"<<s.valid<<",\"valid_rtt\":"<<s.rttCount<<",\"max_terminal_event_seq\":"<<s.maxSeq<<",\"retained_success_records\":"<<s.retained<<"}\n";
  }else return 2;
 }
}
