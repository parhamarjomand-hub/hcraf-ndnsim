#include "hcraf-recorder.hpp"
int main(int argc, char** argv) {
  if (argc != 2) return 1;
  hcraf::Recorder r(argv[1], 1, "/hcraf/pilot");
  int pit = 0;
  if (r.beginDecision(&pit,"/localhost/test",0,1,"/",{}) != 0) return 2;
  auto id = r.beginDecision(&pit,"/hcraf/pilot/0",10,10,"/hcraf",{{20,7},{21,999}});
  r.event("TX_INTEREST",&pit,"/hcraf/pilot/0",10,20,100,42);
  r.event("TX_INTEREST",&pit,"/hcraf/pilot/0",10,21,100,42);
  r.endDecision(id);
  r.event("PIT_SATISFIED",&pit,"/hcraf/pilot/0",20,20,-1,-1,-1,1024);
  r.event("PIT_FINALIZE",&pit,"/hcraf/pilot/0",20,-1,-1,-1,1);
  id = r.beginDecision(&pit,"/hcraf/pilot/1",30,10,"/hcraf",{{20,8}});
  r.endDecision(id); // legitimate decision with no transmitted Interest
  r.event("TX_INTEREST",&pit,"/hcraf/pilot/1",31,20,100,43); // asynchronous: no invented linkage
  r.finish(50);
}
