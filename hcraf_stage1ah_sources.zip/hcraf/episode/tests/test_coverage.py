"""Artificial unit fixtures; no records from these tests enter research data."""
import json,math,subprocess,sys,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from verify_coverage import expected_probabilities,check_choice,check_arrivals

class CoverageTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.tmp=tempfile.TemporaryDirectory();cls.work=Path(cls.tmp.name)
  (cls.work/'driver.cpp').write_text(r'''
#include "hcraf-recorder.hpp"
#include <iostream>
int main(int argc,char**argv) {
 (void)argc;
 try {
 if(std::string(argv[1])=="interval") {std::cout<<hcraf::arrivalIntervalNs(std::stod(argv[2]));return 0;}
 if(std::string(argv[1])=="prob") {
   auto p=hcraf::collectionProbabilities({std::stoull(argv[3]),std::stoull(argv[4]),std::stoull(argv[5])},std::string(argv[2])=="coverage");
   std::cout<<std::setprecision(17)<<p[0]<<' '<<p[1]<<' '<<p[2]<<' '<<hcraf::collectionIndex(p,std::stod(argv[6]));return 0;
 }
 hcraf::Recorder r(argv[2],1,"/hcraf/pilot");int a=1,b=2,c=3,d=4;
 r.event("TX_INTEREST",&a,"/hcraf/pilot/0",0,10,1000000000,1);
 if(std::string(argv[1])=="cancel")r.event("TX_INTEREST",&a,"/hcraf/pilot/0",0,11,1000000000,1);
 r.event("PIT_SATISFIED",&a,"/hcraf/pilot/0",100000000,10,-1,-1,-1,1024);
 if(std::string(argv[1])!="cancel") {
   r.event("TX_INTEREST",&b,"/hcraf/pilot/1",200000000,11,300000000,2);
   r.event("PIT_TIMER",&c,"/hcraf/pilot/2",400000000);
 }
 r.event("TX_INTEREST",&d,"/hcraf/pilot/3",500000000,12,1500000000,3);
 auto id=r.beginDecision(&c,"/hcraf/pilot/2",600000000,9,"/hcraf",{{10,1},{11,2},{12,3}});
 r.coverageSelection({{10,1},{11,2},{12,3}},600000000,.5,true);r.endDecision(id);r.finish(1600000000);
 } catch(const std::exception&){return 2;}
}
''')
  subprocess.run(['g++','-std=c++17','-Wall','-Wextra','-Werror','-I'+str(ROOT/'src'),str(cls.work/'driver.cpp'),'-o',str(cls.work/'driver')],check=True,capture_output=True)
 @classmethod
 def tearDownClass(cls):cls.tmp.cleanup()
 def native(self,*args):return subprocess.run([str(self.work/'driver'),*map(str,args)],capture_output=True,text=True)
 def probs(self,counts,policy,u):
  r=self.native('prob',policy,*counts,u);self.assertEqual(r.returncode,0);v=r.stdout.split();p=list(map(float,v[:3]));i=int(v[3])
  for actual,expected in zip(p,expected_probabilities(counts,policy)):self.assertAlmostEqual(actual,expected,places=14)
  self.assertAlmostEqual(sum(p),1,places=14);self.assertGreaterEqual(min(p),.2/3-1e-14)
  return p,i
 def test_uniform_ignores_counts(self):self.probs([100,0,50],'uniform',.5)
 def test_coverage_unique_minimum(self):self.assertEqual(self.probs([10,10,0],'coverage',.5)[1],2)
 def test_coverage_tied_minimum(self):self.probs([0,0,10],'coverage',.5)
 def test_coverage_all_equal(self):self.probs([10,10,10],'coverage',.5)
 def test_zero_draw(self):self.assertEqual(self.probs([0,2,2],'coverage',0)[1],0)
 def test_upper_draw(self):self.assertEqual(self.probs([0,2,2],'coverage',.999999)[1],2)
 def test_invalid_draw(self):
  for u in (-.1,1,'nan'):self.assertEqual(self.native('prob','coverage',0,0,0,u).returncode,2)
 def test_arrival_inverse_transform(self):
  for u in (0,.1,.5,.9,.999999):
   r=self.native('interval',u);self.assertEqual(r.returncode,0)
   self.assertLessEqual(abs(int(r.stdout)-max(1,math.floor(-math.log1p(-u)*1e9/20+.5))),1)
 def test_arrival_invalid(self):
  for u in (-.1,1,'nan'):self.assertEqual(self.native('interval',u).returncode,2)
 def fixture(self,mode):
  path=self.work/'events';r=self.native(mode,path);self.assertEqual(r.returncode,0)
  c=json.loads(Path(str(path)+'.collection.jsonl').read_text());d=json.loads(Path(str(path)+'.decisions.jsonl').read_text())
  states=[json.loads(x) for x in Path(str(path)+'.states.jsonl').read_text().splitlines()]
  lookup={(x['decision_id'],x['face_id']):x for x in states}
  tx=[dict(face_id=c['selected_face_id'],decision_id=d['decision_id'],pit_instance_id=d['pit_instance_id'],name=d['name'],time_ns=d['time_ns'],event_seq=d['after_event_seq']+1)]
  return c,d,lookup,tx
 def test_pending_is_not_valid_coverage(self):
  c,d,s,t=self.fixture('record');self.assertEqual([x['valid_outcomes_before'] for x in c['candidates']],[1,1,0]);check_choice(c,d,s,t)
 def test_cancelled_is_not_valid_coverage(self):
  c,d,s,t=self.fixture('cancel');self.assertEqual([x['valid_outcomes_before'] for x in c['candidates']],[1,0,0]);check_choice(c,d,s,t)
 def test_future_count_rejected(self):
  c,d,s,t=self.fixture('record');c['candidates'][2]['valid_outcomes_before']=2
  with self.assertRaises(ValueError):check_choice(c,d,s,t)
 def test_wrong_probability_rejected(self):
  c,d,s,t=self.fixture('record');c['candidates'][2]['probability']=.5
  with self.assertRaises(ValueError):check_choice(c,d,s,t)
 def test_extra_tx_rejected(self):
  c,d,s,t=self.fixture('record');t.append(dict(t[0],face_id=10))
  with self.assertRaises(ValueError):check_choice(c,d,s,t)
 def test_arrival_missing_stop_draw(self):
  with self.assertRaises(ValueError):check_arrivals([],[])
