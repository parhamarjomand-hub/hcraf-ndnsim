"""Artificial software test cases only; never imported as research observations."""
import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from episodes import reconstruct
from patch_nfd import patch
from verify_pilot import verify

def event(kind,t,face=-1,deadline=-1,nonce=-1,reason=-1,pit=1,bytes=-1):
    return dict(schema_version='0.2',node_id=1,pit_instance_id=pit,time_ns=t,
                event_type=kind,name='/UNIT_TEST_ONLY',face_id=face,
                deadline_ns=deadline,nonce=nonce,reason=reason,payload_bytes=bytes)
def stream(*items):
    return [dict(item,event_seq=i+1) for i,item in enumerate(items)]
def tx(t=10,face=2,deadline=100,nonce=7):
    return event('TX_INTEREST',t,face,deadline,nonce)
def end(t=200): return event('SIMULATION_END',t,pit=0)
def satisfaction(t=20,face=2): return event('PIT_SATISFIED',t,face,bytes=1024)
def make(*items): return reconstruct(stream(*items),'UNIT_TEST_ONLY')

class EpisodeTests(unittest.TestCase):
    def test_success(self):
        rows=make(tx(),satisfaction(),end())
        self.assertEqual(rows[0]['outcome'],'SUCCESS')
        self.assertEqual(rows[0]['delay_ns'],10)
    def test_nack(self):
        row=make(tx(),event('NACK_ACCEPTED',20,2,nonce=7,reason=150),end())[0]
        self.assertEqual(row['outcome'],'NACK')
        self.assertTrue(row['nack_matches_outrecord'])
    def test_wrong_nonce(self):
        with self.assertRaises(ValueError):
            make(tx(),event('NACK_ACCEPTED',20,2,nonce=8,reason=150),end())
    def test_timeout(self):
        row=make(tx(),event('PIT_FINALIZE',100,reason=0),end())[0]
        self.assertEqual((row['outcome'],row['end_ns']),('TIMEOUT',100))
    def test_cancel_not_failure(self):
        rows=make(tx(),tx(face=3),satisfaction(),end())
        self.assertEqual([r['outcome'] for r in rows],['SUCCESS','CANCELLED'])
        self.assertIsNone(rows[1]['delay_ns'])
    def test_late_data_does_not_rewrite_timeout(self):
        row=make(tx(),satisfaction(101),end())[0]
        self.assertEqual(row['outcome'],'TIMEOUT')
    def test_exact_deadline_data_callback_first(self):
        self.assertEqual(make(tx(),satisfaction(100),end())[0]['outcome'],'SUCCESS')
    def test_retransmission_has_no_unambiguous_rtt(self):
        row=make(tx(),tx(15,deadline=105,nonce=8),satisfaction(),end())[0]
        self.assertEqual(row['tx_count'],2)
        self.assertFalse(row['delay_valid'])
        self.assertIsNone(row['delay_ns'])
    def test_post_nack_new_generation(self):
        rows=make(tx(),event('NACK_ACCEPTED',20,2,nonce=7,reason=150),
                  tx(30,deadline=130,nonce=8),satisfaction(40),end())
        self.assertEqual([r['outcome'] for r in rows],['NACK','SUCCESS'])
        self.assertNotEqual(rows[0]['episode_id'],rows[1]['episode_id'])
    def test_open_is_censored_not_timeout(self):
        row=make(tx(),end(50))[0]
        self.assertIsNone(row['outcome'])
        self.assertEqual(row['censor_reason'],'SIMULATION_END')
    def test_early_pit_finalization_is_not_timeout(self):
        row=make(tx(),event('PIT_FINALIZE',20,reason=0),end())[0]
        self.assertIsNone(row['outcome'])
        self.assertEqual(row['censor_reason'],'PIT_FINALIZED_BEFORE_FACE_DEADLINE')
    def test_cache_hit_no_extra_episode(self):
        self.assertEqual(len(make(event('CACHE_HIT',1,pit=2),tx(),satisfaction(),end())),1)
    def test_missing_end_rejected(self):
        with self.assertRaises(ValueError): make(tx())
    def test_event_gap_rejected(self):
        data=stream(tx(),end()); data[-1]['event_seq']=3
        with self.assertRaises(ValueError): reconstruct(data,'UNIT_TEST_ONLY')
    def test_retired_pit_cannot_be_reused(self):
        with self.assertRaises(ValueError):
            make(tx(),event('PIT_FINALIZE',100,reason=0),tx(110,deadline=210),end(300))
    def test_duplicate_event_rejected(self):
        data=stream(tx(),end()); data.insert(1,copy.deepcopy(data[0]))
        with self.assertRaises(ValueError): reconstruct(data,'UNIT_TEST_ONLY')
    def test_patch_rejects_unknown_sources_without_changes(self):
        with tempfile.TemporaryDirectory() as temp:
            folder=Path(temp)
            for name in ('forwarder.cpp','forwarder.hpp'): (folder/name).write_text('unknown')
            with self.assertRaises(ValueError): patch(folder,ROOT/'src/hcraf-recorder.hpp')
            self.assertEqual((folder/'forwarder.cpp').read_text(),'unknown')
    def test_independent_verifier_and_tamper_detection(self):
        with tempfile.TemporaryDirectory() as temp:
            folder=Path(temp)
            events=[]
            for i in range(3):
                for e in (tx(10+i*30,deadline=200),satisfaction(20+i*30)):
                    e['pit_instance_id']=i+1
                    e['name']='/UNIT_TEST_ONLY/'+str(i)
                    events.append(e)
            events=stream(*events,end())
            rows=reconstruct(events,'UNIT_TEST_ONLY')
            consumer=[]
            for row in rows:
                consumer.extend([dict(event='SEND',name=row['name']),dict(event='DATA',name=row['name'])])
            for name,values in (('events.jsonl',events),('episodes.jsonl',rows),('consumer_events.jsonl',consumer)):
                (folder/name).write_text(''.join(json.dumps(v)+'\n' for v in values))
            (folder/'scenario.json').write_text(json.dumps(dict(mode='success',stop_ns=200)))
            self.assertEqual(verify(folder)['status'],'PASS')
            rows[0]['tx_count']=99
            (folder/'episodes.jsonl').write_text(''.join(json.dumps(v)+'\n' for v in rows))
            with self.assertRaises(ValueError): verify(folder)
    def test_nonce_byte_conversion(self):
        with tempfile.TemporaryDirectory() as temp:
            binary=Path(temp)/'nonce-test'
            subprocess.run(['g++','-std=c++17','-Wall','-Wextra','-Werror','-pedantic',
                            '-I'+str(ROOT/'src'),str(ROOT/'tests/nonce_driver.cpp'),
                            '-o',str(binary)],check=True,capture_output=True,text=True)
            subprocess.run([str(binary)],check=True)

    def test_prefix_scope_and_background_preservation(self):
        with tempfile.TemporaryDirectory() as temp:
            folder=Path(temp); binary=folder/'scope'; output=folder/'events.jsonl'
            subprocess.run(['g++','-std=c++17','-Wall','-Wextra','-Werror','-pedantic',
                            '-I'+str(ROOT/'src'),str(ROOT/'tests/scope_driver.cpp'),
                            '-o',str(binary)],check=True,capture_output=True,text=True)
            subprocess.run([str(binary),str(output)],check=True)
            events=[json.loads(line) for line in output.read_text().splitlines()]
            background=[json.loads(line) for line in Path(str(output)+'.background.jsonl').read_text().splitlines()]
            self.assertEqual([e['event_seq'] for e in events],[1,2,3])
            self.assertEqual(len(background),2)
            self.assertEqual(reconstruct(events,'UNIT_TEST_ONLY')[0]['outcome'],'SUCCESS')

    def test_native_cpp_recorder(self):
        with tempfile.TemporaryDirectory() as temp:
            folder=Path(temp); binary=folder/'recorder'; output=folder/'unit-events.jsonl'
            subprocess.run(['g++','-std=c++17','-Wall','-Wextra','-Werror','-pedantic',
                            '-I'+str(ROOT/'src'),str(ROOT/'tests/recorder_driver.cpp'),
                            '-o',str(binary)],check=True,capture_output=True,text=True)
            subprocess.run([str(binary),str(output)],check=True)
            events=[json.loads(line) for line in output.read_text().splitlines()]
            self.assertEqual(events[0]['name'],'/unit/"\\\n')
            self.assertNotEqual(events[0]['pit_instance_id'],events[3]['pit_instance_id'])
            rows=reconstruct(events,'UNIT_TEST_ONLY')
            self.assertEqual([r['outcome'] for r in rows],['SUCCESS',None])

if __name__=='__main__': unittest.main()
