"""Stage1S unit fixtures only. They are NEVER empirical ndnSIM observations."""
import json
from collections import defaultdict
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from verify_robustness import (graph,validate_graph,source_events,find_send_candidates,
                               nfd_tx_join,assert_closed_labels,packet_on,check_multihop_chain,
                               MODES)

class Stage1SUnitTests(unittest.TestCase):
    def test_scenario_list(self):self.assertEqual(len(MODES),6)
    def test_baseline_directions(self):self.assertEqual(len(graph('baseline')),8)
    def test_repeat_directions(self):self.assertEqual(len(graph('repeat-name')),8)
    def test_retransmit_directions(self):self.assertEqual(len(graph('retransmission')),8)
    def test_cache_directions(self):self.assertEqual(len(graph('cache-hit')),8)
    def test_aggregation_directions(self):self.assertEqual(len(graph('aggregation')),10)
    def test_multi_directions(self):self.assertEqual(len(graph('multi-hop')),14)
    def test_graph_symmetric(self):
        for m in MODES:
            g=graph(m)
            for k,v in g.items():self.assertEqual(g[v],k)
    def test_multi_second_hops(self):
        g=graph('multi-hop')
        self.assertEqual(g[(2,1)],(5,0))
        self.assertEqual(g[(3,1)],(6,0))
        self.assertEqual(g[(4,1)],(7,0))
    def test_aggregation_extra_link(self):self.assertEqual(graph('aggregation')[(5,0)],(1,4))
    def test_invalid_device_map_rejected(self):
        with self.assertRaises(ValueError):validate_graph([], 'baseline')
    def test_face_reuse_rejected(self):
        rows=[dict(node_id=n,device_index=d,face_id=257) for n,d in graph('baseline')]
        for r in rows:r['event_type']='INITIAL'
        with self.assertRaises(ValueError):validate_graph(rows,'baseline')
    def test_correct_face_graph(self):
        rows=[dict(node_id=n,device_index=d,face_id=d+257,event_type='INITIAL') for n,d in graph('multi-hop')]
        self.assertEqual(len(validate_graph(rows,'multi-hop')[0]),14)
    def test_consumer_candidates_use_nonce(self):
        sends=defaultdict(list)
        sends['/hcraf/pilot/1']=[dict(name='/hcraf/pilot/1',nonce=2,time_ns=200),
                                 dict(name='/hcraf/pilot/1',nonce=3,time_ns=300)]
        self.assertEqual(len(find_send_candidates(sends,'/hcraf/pilot/1',2,250)),1)
        self.assertEqual(find_send_candidates(sends,'/hcraf/pilot/1',3,250),[])
    def test_no_source_match(self):
        r=nfd_tx_join(dict(node_id=1,face_id=258,name='/hcraf/pilot/x',nonce=1,time_ns=10),
                      defaultdict(list),defaultdict(list))
        self.assertEqual(r['status'],'NO_SOURCE')
    def test_ambiguous_source_match(self):
        name='/hcraf/pilot/0';source=defaultdict(list)
        source[name]=[dict(source_id=i,name=name,nonce=10,time_ns=0) for i in (0,1)]
        r=nfd_tx_join(dict(node_id=1,face_id=258,name=name,nonce=10,time_ns=10),
                      defaultdict(list),source)
        self.assertEqual(r['status'],'AMBIGUOUS_SOURCE')
    def test_unique_packet_match(self):
        name='/hcraf/pilot/0';source=defaultdict(list)
        source[name]=[dict(source_id=0,name=name,nonce=10,time_ns=0)]
        index=defaultdict(list)
        key=(1,258,'INTEREST',name,10,'QUEUE_ENQUEUE')
        index[key]=[dict(node_id=1,face_id=258,packet_uid=7,time_ns=11)]
        r=nfd_tx_join(dict(node_id=1,face_id=258,name=name,nonce=10,time_ns=10),index,source)
        self.assertEqual(r['status'],'MATCHED_UNIQUE')
        self.assertEqual(r['packet']['packet_uid'],7)
    def test_ambiguous_packet_match(self):
        name='/hcraf/pilot/0';source=defaultdict(list)
        source[name]=[dict(source_id=0,name=name,nonce=10,time_ns=0)]
        index=defaultdict(list)
        key=(1,258,'INTEREST',name,10,'QUEUE_ENQUEUE')
        index[key]=[dict(time_ns=11,packet_uid=1),dict(time_ns=12,packet_uid=2)]
        r=nfd_tx_join(dict(node_id=1,face_id=258,name=name,nonce=10,time_ns=10),index,source)
        self.assertEqual(r['status'],'AMBIGUOUS_MULTIPLE_PACKETS')
        self.assertIsNone(r['packet'])
    def test_missing_packet_match(self):
        name='/hcraf/pilot/0';source=defaultdict(list)
        source[name]=[dict(source_id=0,name=name,nonce=10,time_ns=0)]
        r=nfd_tx_join(dict(node_id=1,face_id=258,name=name,nonce=10,time_ns=10),
                      defaultdict(list),source)
        self.assertEqual(r['status'],'NOT_OBSERVED')
        self.assertIsNone(r['packet'])
    def test_pre_tx_packet_rejected(self):
        name='/hcraf/pilot/0';source=defaultdict(list)
        source[name]=[dict(source_id=0,name=name,nonce=10,time_ns=0)]
        ix=defaultdict(list)
        ix[(1,258,'INTEREST',name,10,'QUEUE_ENQUEUE')]=[dict(time_ns=9,packet_uid=10)]
        self.assertEqual(nfd_tx_join(dict(node_id=1,face_id=258,name=name,nonce=10,time_ns=10),ix,source)['status'],'NOT_OBSERVED')
    def test_closed_labels(self):
        assert_closed_labels(dict(training_ready=False,final_congestion_label=None,
                                  future_congestion_label=None,causal_congestion_attribution=None),
                             [dict(outcome='SUCCESS'),dict(outcome=None),dict(outcome='CANCELLED')])
    def test_reject_final_label(self):
        with self.assertRaises(ValueError):
            assert_closed_labels(dict(training_ready=False,final_congestion_label=0,
                                      future_congestion_label=None),[])
    def test_reject_training_ready(self):
        with self.assertRaises(ValueError):
            assert_closed_labels(dict(training_ready=True,final_congestion_label=None,
                                      future_congestion_label=None),[])
    def test_reject_unknown_outcome(self):
        with self.assertRaises(ValueError):
            assert_closed_labels(dict(training_ready=False,final_congestion_label=None,
                                      future_congestion_label=None),[dict(outcome='OPEN')])
    def test_packet_on_unique(self):
        pkt=dict(node_id=2,device_index=1,event_type='QUEUE_ENQUEUE',time_ns=20,
                 ndn_packet_type='DATA',ndn_name='/hcraf/pilot/1',ndn_nonce=None)
        self.assertIs(packet_on([pkt],(2,1),'DATA','/hcraf/pilot/1',None,'QUEUE_ENQUEUE',10),pkt)
    def test_packet_on_ambiguous(self):
        pkt=dict(node_id=2,device_index=1,event_type='QUEUE_ENQUEUE',time_ns=20,
                 ndn_packet_type='DATA',ndn_name='/hcraf/pilot/1',ndn_nonce=None)
        with self.assertRaises(ValueError):
            packet_on([pkt,pkt],(2,1),'DATA','/hcraf/pilot/1',None,'QUEUE_ENQUEUE',10)
    def test_packet_on_wrong_time(self):
        pkt=dict(node_id=2,device_index=1,event_type='QUEUE_ENQUEUE',time_ns=9,
                 ndn_packet_type='DATA',ndn_name='/hcraf/pilot/1',ndn_nonce=None)
        with self.assertRaises(ValueError):
            packet_on([pkt],(2,1),'DATA','/hcraf/pilot/1',None,'QUEUE_ENQUEUE',10)
    def test_source_events_repeat_not_deduped(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            name='/hcraf/pilot/0'
            rows=[dict(event='SEND',time_ns=10+i,source_id=0,name=name,nonce=10+i) for i in range(2)]
            schedules=[dict(time_ns=10+i,source_id=0) for i in range(2)]
            (root/'consumer_events.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in rows))
            (root/'consumer_events.jsonl.arrivals.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in schedules))
            sends,datas,arrivals=source_events(root,'repeat-name')
            self.assertEqual(len(sends),2)
            self.assertEqual(len(arrivals),2)
            self.assertEqual(len(datas),0)
    def test_source_events_duplicate_nonce_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            rows=[dict(event='SEND',time_ns=10+i,source_id=0,name='/hcraf/pilot/0',nonce=10) for i in range(2)]
            schedules=[dict(time_ns=10+i,source_id=0) for i in range(2)]
            (root/'consumer_events.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in rows))
            (root/'consumer_events.jsonl.arrivals.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in schedules))
            with self.assertRaises(ValueError):source_events(root,'repeat-name')
    def test_multihop_name_and_nonce_chain(self):
        # Pure isolated unit-test fixture: not simulated network evidence.
        name='/hcraf/pilot/0';nonce=123
        ep=graph('multi-hop')
        faces={key:257+key[1] for key in ep}
        tx=dict(face_id=258,name=name,nonce=nonce,time_ns=1)
        steps=[((1,1),'INTEREST','QUEUE_ENQUEUE'),((2,0),'INTEREST','MAC_RX'),
               ((2,1),'INTEREST','QUEUE_ENQUEUE'),((5,0),'INTEREST','MAC_RX'),
               ((5,0),'DATA','QUEUE_ENQUEUE'),((2,1),'DATA','MAC_RX'),
               ((2,0),'DATA','QUEUE_ENQUEUE'),((1,1),'DATA','MAC_RX')]
        rows=[dict(node_id=endpoint[0],device_index=endpoint[1],
                   event_type=e,ndn_packet_type=kind,ndn_name=name,
                   ndn_nonce=nonce if kind=='INTEREST' else None,
                   time_ns=2+i,packet_uid=10+i) for i,(endpoint,kind,e) in enumerate(steps)]
        result=check_multihop_chain(tx,rows,ep,faces)
        self.assertEqual(result['observed_events'],8)
        self.assertEqual(result['return_hops'],2)
    def test_multihop_missing_leg_rejected(self):
        name='/hcraf/pilot/0';nonce=123
        ep=graph('multi-hop');faces={key:257+key[1] for key in ep}
        with self.assertRaises(ValueError):
            check_multihop_chain(dict(face_id=258,name=name,nonce=nonce,time_ns=0),[],ep,faces)

if __name__=='__main__':unittest.main()
