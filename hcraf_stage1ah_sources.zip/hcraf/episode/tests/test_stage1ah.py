"""Synthetic-only contract tests. They are NOT simulated evidence/labels."""
import sys,unittest
from pathlib import Path
TASK=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(TASK/'scripts'))
from verify_stage1ah import (validate_config,ratio_positive,adjusted_wait,traffic_class,
                           overlap,union_length,recovered_groups,STAGE,REGIMES,RUNS,THETAS)
from verify_stage1af import EvidenceError

class Stage1AHContract(unittest.TestCase):
    def cfg(self,mode='LP_SELF_ONLY',slot=0,top='DEV_CHAIN_A'):
        return dict(collector_stage=STAGE,mode=mode,topology_id=top,run=9101,seed=17,
          selected_face_slot=slot,eligible_face_ids=[258,259,260],selected_face_id=258+slot,
          actual_assignment_probability=1.0,nominal_uniform_probability_NOT_behavioral_propensity=1/3,
          selected_relay_node_id=slot+2,selected_producer_node_id=(
            ({0:5,1:6,2:7} if top=='DEV_CHAIN_A' else {0:7,1:5,2:6})[slot]),
          path_nodes=[0,1,slot+2,({0:5,1:6,2:7} if top=='DEV_CHAIN_A' else {0:7,1:5,2:6})[slot]],
          instrument_enabled=True,cache_enabled=False,multi_hop_enabled=True,
          traffic_class_primary='TARGET',traffic_class_competitor='INDEPENDENT_COMPETITOR',
          target_prefix='/hcraf/pilot',competitor_prefix='/hcraf/competitor',
          competitor_injection_enabled=mode in REGIMES[1:3],
          competitor_planned_requests=12 if mode in REGIMES[1:3] else 0,
          planned_requests=12,nominal_arrival_interval_ns=250000000,
          payload_bytes=4096,mtu_bytes=9000 if mode==REGIMES[3] else 600,
          interest_lifetime_ms=2600,stop_ns=20000000000,
          theta_pilot=2,horizon_ms_pilot=2000,
          decision_time_us_real_HCRAF=None,observer_cost_is_decision_time=False,
          congestion=None,future_congestion=None,F3_ready=False,training_ready=False)
    def test_all_24_scoped_topology_slot_regime_mappings(self):
        for t in ('DEV_CHAIN_A','DEV_CHAIN_B'):
            for slot in (0,1,2):
                for mode in REGIMES:
                    with self.subTest(t=t,slot=slot,mode=mode):
                        self.assertEqual(validate_config(self.cfg(mode,slot,t)),2+slot)
    def test_wrong_stage_rejected(self):
        c=self.cfg();c['collector_stage']='1AF.DEV_MULTIFACE.0'
        with self.assertRaises(EvidenceError):validate_config(c)
    def test_unregistered_rng_rejected(self):
        c=self.cfg();c['run']=8101
        with self.assertRaises(EvidenceError):validate_config(c)
    def test_heldout_topology_rejected(self):
        c=self.cfg();c['topology_id']='T04'
        with self.assertRaises(EvidenceError):validate_config(c)
    def test_duplicate_face_rejected(self):
        c=self.cfg();c['eligible_face_ids']=[258,258,260]
        with self.assertRaises(EvidenceError):validate_config(c)
    def test_selected_face_mismatch_rejected(self):
        c=self.cfg();c['selected_face_id']=260
        with self.assertRaises(EvidenceError):validate_config(c)
    def test_wrong_path_rejected(self):
        c=self.cfg();c['path_nodes']=[0,1,2,7]
        with self.assertRaises(EvidenceError):validate_config(c)
    def test_nominal_not_propensity(self):
        c=self.cfg();c['actual_assignment_probability']=1/3
        with self.assertRaises(EvidenceError):validate_config(c)
    def test_future_label_rejected(self):
        c=self.cfg();c['future_congestion']=False
        with self.assertRaises(EvidenceError):validate_config(c)
    def test_training_flag_rejected(self):
        c=self.cfg();c['training_ready']=True
        with self.assertRaises(EvidenceError):validate_config(c)
    def test_observer_latency_not_hcraf_latency(self):
        c=self.cfg();c['decision_time_us_real_HCRAF']=42
        with self.assertRaises(EvidenceError):validate_config(c)
    def test_competitor_cannot_be_missing_in_c1(self):
        c=self.cfg(REGIMES[1]);c['competitor_planned_requests']=0
        with self.assertRaises(EvidenceError):validate_config(c)
    def test_c0_has_no_competitor(self):
        c=self.cfg();c['competitor_injection_enabled']=True
        with self.assertRaises(EvidenceError):validate_config(c)
    def test_no_silent_payload_adjustment(self):
        c=self.cfg();c['payload_bytes']=1024
        with self.assertRaises(EvidenceError):validate_config(c)
    def test_c3_uses_large_mtu(self):
        c=self.cfg(REGIMES[3]);c['mtu_bytes']=1500
        with self.assertRaises(EvidenceError):validate_config(c)
    def test_ns3_sender_local_uid_not_global_name(self):
        self.assertEqual(traffic_class('/hcraf/pilot/12'),'TARGET')
        self.assertEqual(traffic_class('/hcraf/competitor/12'),'INDEPENDENT_COMPETITOR')
        self.assertEqual(traffic_class('/hcraf/pilot/12/extra'),'TARGET')
        self.assertEqual(traffic_class('/hcraf/pilotx/12'),'UNATTRIBUTED')
        self.assertEqual(traffic_class(''), 'UNATTRIBUTED')
    def test_drop_is_not_timeout(self):
        self.assertTrue(ratio_positive({'event_type':'QUEUE_DROP'},2))
        self.assertFalse(ratio_positive({'event_type':'PHY_RX_DROP'},2))
    def test_wait_exact_threshold(self):
        x={'event_type':'QUEUE_DEQUEUE','queue_wait_ns':16000,'packet_bytes':1000,'data_rate_bps':1000000000}
        self.assertFalse(ratio_positive(x,2))
        x['queue_wait_ns']=16001;self.assertTrue(ratio_positive(x,2))
    def test_missing_wait_is_not_zero(self):
        with self.assertRaises(EvidenceError):ratio_positive({'event_type':'QUEUE_DEQUEUE','packet_bytes':600,'data_rate_bps':10000000},2)
    def test_same_group_service_subtraction(self):
        q={'time_ns':150,'queue_wait_ns':50}
        self.assertEqual(adjusted_wait(q,[(100,150)]),0)
    def test_adjusted_exogenous_residual(self):
        q={'time_ns':180,'queue_wait_ns':80}
        self.assertEqual(adjusted_wait(q,[(110,150)]),40)
    def test_no_double_subtraction_for_overlapping_intervals(self):
        q={'time_ns':200,'queue_wait_ns':100}
        self.assertEqual(adjusted_wait(q,[(110,175),(130,180)]),30)
    def test_invalid_fragment_lifecycle_is_unknown_not_negative(self):
        # Overlapping same-group intervals cannot make residual negative.
        self.assertEqual(adjusted_wait({'time_ns':150,'queue_wait_ns':50},[(100,150),(101,140)]),0)
    def test_union_length(self):
        self.assertEqual(union_length([(10,20),(15,30),(40,50)]),30)
    def test_physical_overlap_boundary(self):
        self.assertEqual(overlap(0,10,10,20),0)
        self.assertEqual(overlap(0,10,5,20),5)
    def test_duplicate_or_missing_lp_fragments_unknown(self):
        x=[dict(event_type='MAC_RX',node_id=1,face_id=258,lp_status='FRAGMENT',
          lp_group_start_seq=10,lp_seq=10,lp_frag_count=2,lp_frag_index=0,
          lp_fragment_hex='00',time_ns=10,packet_bytes=100)]
        complete,bad=recovered_groups(x,1,258)
        self.assertEqual(complete,[])
        self.assertEqual(len(bad),1)
    def test_lp_seq_reordering_rejected(self):
        x=[dict(event_type='MAC_RX',node_id=1,face_id=258,lp_status='FRAGMENT',
          lp_group_start_seq=10,lp_seq=11+i,lp_frag_count=2,lp_frag_index=i,
          lp_fragment_hex='00',time_ns=10+i,packet_bytes=100) for i in range(2)]
        complete,bad=recovered_groups(x,1,258)
        self.assertEqual(complete,[])
        self.assertEqual(bad[0]['reason'],'LP_SEQUENCE_INCONSISTENT')

if __name__=='__main__':unittest.main()
