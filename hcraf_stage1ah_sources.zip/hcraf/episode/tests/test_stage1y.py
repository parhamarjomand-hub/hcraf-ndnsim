"""SYNTHETIC SOFTWARE TEST FIXTURES ONLY. Never used as HCRAF research evidence."""
import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPT=Path(__file__).resolve().parents[1]/'scripts'/'verify_stage1y.py'
spec=importlib.util.spec_from_file_location('verify_stage1y',SCRIPT)
mod=importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

class Stage1YContracts(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.p=Path(self.tmp.name)
    def tearDown(self): self.tmp.cleanup()
    def write(self,name,data):
        dest=self.p/name
        dest.write_text(''.join(json.dumps(x)+'\n' for x in data),encoding='utf8')
    def fixture(self,mode='low-load',n=1):
        cfg={'mode':mode,'collector_stage':'1Y.PILOT.0','planned_requests':n,
             'seed':17,'run':1001,'stop_ns':20000000000,'multi_hop_enabled':False,
             'congestion':None,'future_congestion':None,
             'causal_congestion_attribution':None,'training_ready':False}
        (self.p/'scenario.json').write_text(json.dumps(cfg))
        src=[{'event':'SEND','time_ns':1,'name':'/test/1'} for _ in range(n)]
        self.write('consumer_events.jsonl',src)
        self.write('consumer_events.jsonl.arrivals.jsonl',
                   [{'sequence':i,'time_ns':i+1,'jitter_ns':i,'schedule':'SYNTHETIC_UNIT_TEST_NOT_RESEARCH'} for i in range(n)])
        self.write('events.jsonl',[])
        self.write('episodes.jsonl',[{'outcome':'SUCCESS'}] if n else [])
        lk=[]
        for j in range(8):
            lk.append({'event_type':'INITIAL','node_id':j//2,'device_index':j%2,
                       'time_ns':0,'packet_uid':None})
        if n:
            lk.extend([
              {'event_type':'QUEUE_ENQUEUE','node_id':1,'device_index':0,'time_ns':10,'packet_uid':33},
              {'event_type':'QUEUE_DEQUEUE','node_id':1,'device_index':0,'time_ns':10,'packet_uid':33,'queue_wait_ns':0},
            ])
        for j in range(8):
            lk.append({'event_type':'FINAL','node_id':j//2,'device_index':j%2,
                       'time_ns':100,'packet_uid':None})
        for i,r in enumerate(lk):r['link_event_seq']=i+1
        self.write('link_events.jsonl',lk)
    def test_low_load_diagnostic_does_not_create_f3_label(self):
        self.fixture()
        r=mod.validate(self.p)
        self.assertTrue(r['target_event_observed'])
        self.assertIsNone(r['future_congestion'])
        self.assertFalse(r['path_level_negative_validated'])
        self.assertFalse(r['training_ready'])
    def test_idle_is_not_a_negative_label(self):
        self.fixture('idle',0)
        r=mod.validate(self.p)
        self.assertEqual(r['status'],'PASS_TARGET_EVENT_ONLY')
        self.assertEqual(r['label_status'],'UNKNOWN_NOT_FULL_PATH_VALIDATED')
    def test_missing_interest_row_is_rejected(self):
        self.fixture()
        self.write('consumer_events.jsonl',[])
        with self.assertRaises(mod.TraceInvalid): mod.validate(self.p)
    def test_out_of_window_is_rejected(self):
        self.fixture()
        ev=mod.rows(self.p/'link_events.jsonl')
        ev[0]['time_ns']=20000000001
        self.write('link_events.jsonl',ev)
        with self.assertRaises(mod.TraceInvalid):mod.validate(self.p)
    def test_corrupt_queue_wait_is_rejected(self):
        self.fixture()
        ev=mod.rows(self.p/'link_events.jsonl')
        ev[9]['queue_wait_ns']=200
        self.write('link_events.jsonl',ev)
        with self.assertRaises(mod.TraceInvalid):mod.validate(self.p)
    def test_queue_dequeue_without_enqueue_is_rejected(self):
        self.fixture()
        ev=mod.rows(self.p/'link_events.jsonl')
        ev[8]['event_type']='INITIAL'
        self.write('link_events.jsonl',ev)
        with self.assertRaises(mod.TraceInvalid):mod.validate(self.p)
    def test_overflow_name_alone_does_not_pass(self):
        self.fixture('forward-overflow')
        self.assertFalse(mod.validate(self.p)['target_event_observed'])
    def test_receive_loss_name_alone_does_not_pass(self):
        self.fixture('receive-loss')
        self.assertFalse(mod.validate(self.p)['target_event_observed'])
    def test_no_route_name_alone_does_not_pass(self):
        self.fixture('no-route')
        self.write('episodes.jsonl',[])
        self.assertFalse(mod.validate(self.p)['target_event_observed'])
    def test_fragmented_name_alone_does_not_pass(self):
        self.fixture('mixed-fragmented')
        cfg=json.loads((self.p/'scenario.json').read_text())
        cfg['multi_hop_enabled']=True
        (self.p/'scenario.json').write_text(json.dumps(cfg))
        with self.assertRaises(mod.TraceInvalid):mod.validate(self.p)
    def test_missing_link_trace_fails_closed(self):
        self.fixture(); (self.p/'link_events.jsonl').unlink()
        with self.assertRaises(mod.TraceInvalid):mod.validate(self.p)
    def test_forbidden_future_label_fails_closed(self):
        self.fixture()
        cfg=json.loads((self.p/'scenario.json').read_text())
        cfg['future_congestion']=0
        (self.p/'scenario.json').write_text(json.dumps(cfg))
        with self.assertRaises(mod.TraceInvalid):mod.validate(self.p)
    def test_forbidden_training_flag_fails_closed(self):
        self.fixture()
        cfg=json.loads((self.p/'scenario.json').read_text())
        cfg['training_ready']=True
        (self.p/'scenario.json').write_text(json.dumps(cfg))
        with self.assertRaises(mod.TraceInvalid):mod.validate(self.p)
    def test_wrong_stage_rejected(self):
        self.fixture()
        cfg=json.loads((self.p/'scenario.json').read_text())
        cfg['collector_stage']='1W.0'
        (self.p/'scenario.json').write_text(json.dumps(cfg))
        with self.assertRaises(mod.TraceInvalid):mod.validate(self.p)
    def test_duplicate_arrival_sequence_rejected(self):
        self.fixture('low-load',2)
        arr=mod.rows(self.p/'consumer_events.jsonl.arrivals.jsonl')
        arr[1]['sequence']=0
        self.write('consumer_events.jsonl.arrivals.jsonl',arr)
        with self.assertRaises(mod.TraceInvalid):mod.validate(self.p)
    def test_dequeue_positive_wait_is_not_congestion_label(self):
        self.fixture('forward-buffered')
        ev=mod.rows(self.p/'link_events.jsonl')
        ev[9]['time_ns']=20;ev[9]['queue_wait_ns']=10
        self.write('link_events.jsonl',ev)
        r=mod.validate(self.p)
        self.assertTrue(r['target_event_observed'])
        self.assertIsNone(r['future_congestion'])
    def test_idle_requires_zero_traffic(self):
        self.fixture('idle',1)
        self.assertFalse(mod.validate(self.p)['target_event_observed'])

if __name__=='__main__': unittest.main()
