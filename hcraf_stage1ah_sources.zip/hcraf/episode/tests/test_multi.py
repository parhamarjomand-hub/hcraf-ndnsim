"""Artificial verifier fixtures only, never used as research observations."""
import json
from pathlib import Path
import sys
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from episodes import reconstruct
from verify_multi import verify,selection_checks


def pair(d,t,changed=False):
    result=[]
    for face,cost,chosen in [(20,3 if changed else 1,not changed),(21,2,changed)]:
        result.append(dict(decision_id=d,time_ns=t,face_id=face,routing_cost=cost,
          selected=chosen,tx_event_seqs=[d] if chosen else [],episode_ids=['e'+str(d)] if chosen else []))
    return result


def fixture(folder,mode):
    rate={'multi-low':5,'multi-mid':12,'multi-change':30}[mode]
    cfg=dict(mode=mode,instrumentation_stage='1D.1',request_rate_per_s=rate,planned_requests=8*rate,
      stop_ns=13000000000,traffic_start_ns=1000000000,traffic_stop_exclusive_ns=9000000000,
      primary_face_id=20,secondary_face_id=21,primary_rate_bps=128000,secondary_rate_bps=512000,
      link_rate_bps=10000000,primary_delay_ms=10,secondary_delay_ms=30,access_delay_ms=10,
      initial_primary_cost=1,secondary_cost=2,changed_primary_cost=3,queue_capacity_packets=20,
      interest_lifetime_ms=1000,payload_bytes=1024,cs_packets=0,consumer_retransmissions=False,
      change_time_ns=5000000000 if mode=='multi-change' else None)
    events=[];ds=[];consumer=[];links=[]
    mapping={(0,10):0,(1,10):0,(1,20):1,(1,21):2,(2,10):0,(3,10):0}
    totals={k:0 for k in mapping}
    def link(kind,t,key,decision=0,uid=None):
        if kind=='PHY_TX_BEGIN':totals[key]+=100
        links.append(dict(schema_version='1B.1',link_event_seq=len(links)+1,event_type=kind,time_ns=t,
          node_id=key[0],face_id=key[1],device_index=mapping[key],decision_id=decision,decision_node_id=1,
          queue_packets=0,queue_bytes=0,phy_tx_started_bytes_total=totals[key],queue_drop_packets_total=0,
          data_rate_bps=128000 if key in ((1,20),(2,10)) else 512000 if key in ((1,21),(3,10)) else 10000000,
          link_up=True,packet_uid=uid,packet_bytes=100 if uid is not None else None))
    for key in mapping:link('INITIAL',0,key)
    for i in range(8*rate):
        send=1000000000+i*1000000000//rate;t=send+10000000
        changed=mode=='multi-change' and t>=5000000000;face=21 if changed else 20
        name='/hcraf/pilot/'+str(i)
        # Main events are later sorted so intervals may overlap between distinct PITs.
        ds.append(dict(schema_version='1B.1',decision_id=i+1,node_id=1,pit_instance_id=i+1,
          name=name,time_ns=t,after_event_seq=0,ingress_face_id=10,fib_prefix='/hcraf',
          anchor='BEFORE_AFTER_RECEIVE_INTEREST',candidate_semantics='RAW_NAME_FIB_NOT_STRATEGY_ELIGIBILITY',
          candidates=[dict(face_id=20,routing_cost=3 if changed else 1,is_ingress=False,strategy_eligible=None),
                      dict(face_id=21,routing_cost=2,is_ingress=False,strategy_eligible=None)]))
        base=dict(schema_version='0.2',node_id=1,pit_instance_id=i+1,name=name,face_id=face,
                  nonce=i+1,deadline_ns=t+1000000000,reason=-1,payload_bytes=-1)
        for kind,at,extra in [('TX_INTEREST',t,dict(decision_id=i+1)),('PIT_SATISFIED',t+20000000,dict(payload_bytes=1024)),
                             ('PIT_FINALIZE',t+20000000,dict(reason=1))]:
            e=dict(base,event_type=kind,time_ns=at);e.update(extra);events.append(e)
        consumer.extend([dict(event='SEND',time_ns=send,name=name),dict(event='DATA',time_ns=t+25000000,name=name,payload_bytes=1024)])
        for key in mapping:link('DECISION_SNAPSHOT',t,key,i+1)
        link('PHY_TX_BEGIN',t+1,(1,face),uid=i)
        link('PHY_TX_END',t+100001,(1,face),uid=i)
    events.sort(key=lambda x:x['time_ns'])
    events.append(dict(base,event_type='SIMULATION_END',time_ns=13000000000,pit_instance_id=0))
    for i,e in enumerate(events):e['event_seq']=i+1
    for d in ds:
        d['after_event_seq']=next(e['event_seq']-1 for e in events if e['event_type']=='TX_INTEREST' and e['decision_id']==d['decision_id'])
    consumer.sort(key=lambda x:x['time_ns'])
    for key in mapping:link('FINAL',13000000000,key)
    control=[] if mode!='multi-change' else [dict(event='ROUTE_COST_UPDATE_REQUEST',time_ns=5000000000,
      node_id=1,face_id=20,prefix='/hcraf',new_cost=3)]
    (folder/'scenario.json').write_text(json.dumps(cfg))
    for filename,values in [('events.jsonl',events),('episodes.jsonl',reconstruct(events,'UNIT_TEST_ONLY')),
      ('events.jsonl.decisions.jsonl',ds),('link_events.jsonl',links),('consumer_events.jsonl',consumer),('control_events.jsonl',control)]:
        (folder/filename).write_text(''.join(json.dumps(x)+'\n' for x in values))


class MultiTests(unittest.TestCase):
    cfg=dict(mode='multi-change',primary_face_id=20,secondary_face_id=21)
    def test_switch_uses_observed_costs(self):
        selected=selection_checks(pair(1,100)+pair(2,5000000001,True),self.cfg)
        self.assertEqual([r['face_id'] for r in selected],[20,21])
    def test_unchosen_outcome_fabrication_rejected(self):
        rows=pair(1,100)+pair(2,5000000001,True);rows[1]['episode_ids']=['fake']
        with self.assertRaises(ValueError):selection_checks(rows,self.cfg)
    def test_two_selected_faces_rejected(self):
        rows=pair(1,100);rows[1]['selected']=True
        with self.assertRaises(ValueError):selection_checks(rows,self.cfg)
    def test_missing_post_change_observation_rejected(self):
        with self.assertRaises(ValueError):selection_checks(pair(1,100),self.cfg)
    def test_stale_face_after_change_rejected(self):
        with self.assertRaises(ValueError):selection_checks(pair(1,100)+pair(2,5000000001),self.cfg)
    def test_full_low_fixture(self):
        with tempfile.TemporaryDirectory() as temp:
            f=Path(temp);fixture(f,'multi-low');rows,r=verify(f)
            self.assertEqual((r['decisions'],len(rows),r['unselected_candidate_rows']),(40,80,40))
    def test_full_change_fixture(self):
        with tempfile.TemporaryDirectory() as temp:
            f=Path(temp);fixture(f,'multi-change');rows,r=verify(f)
            self.assertEqual((r['decisions'],len(rows),r['unselected_candidate_rows']),(240,480,240))
            self.assertIsNotNone(r['first_observed_secondary_decision_after_change_ns'])
    def test_control_tampering_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            f=Path(temp);fixture(f,'multi-change');(f/'control_events.jsonl').write_text('')
            with self.assertRaises(ValueError):verify(f)
    def test_snapshot_cost_tampering_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            f=Path(temp);fixture(f,'multi-change');p=f/'events.jsonl.decisions.jsonl'
            rows=[json.loads(x) for x in p.read_text().splitlines()];rows[-1]['candidates'][0]['routing_cost']=1
            p.write_text(''.join(json.dumps(x)+'\n' for x in rows))
            with self.assertRaises(ValueError):verify(f)

if __name__=='__main__':unittest.main()
