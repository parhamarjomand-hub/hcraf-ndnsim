"""Stage1AH v0.32.1 post-1AF NFD scoped-recorder recovery tests."""
import importlib.util
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

SRC=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('patch_nfd_stage1ah_scope',
    SRC/'scripts/patch_nfd_stage1ah_scope.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
ORIGINAL=b'void Forwarder::hcrafEnable() {\n  m_hcrafRecorder.reset(new hcraf::Recorder(path, nodeId, "/hcraf/pilot"));\n}\n'
class Stage1AHRecorderScopeRecovery(unittest.TestCase):
    def make_file(self,tmp,data):
        p=Path(tmp)/'NFD/daemon/fw/forwarder.cpp'
        p.parent.mkdir(parents=True);p.write_bytes(data);return p
    def test_target_and_competitor_in_same_scoped_recorder(self):
        with TemporaryDirectory() as d:
            p=self.make_file(d,ORIGINAL)
            info=module.patch(p)
            self.assertEqual(info['scope'],'/hcraf')
            self.assertEqual(info['scope_edits'],1)
            b=p.read_bytes()
            self.assertIn(b'nodeId, "/hcraf"',b)
            self.assertNotIn(b'nodeId, "/hcraf/pilot"',b)
            self.assertEqual(b.count(b'Recorder(path, nodeId'),1)
    def test_refuses_silent_double_patch(self):
        with TemporaryDirectory() as d:
            p=self.make_file(d,ORIGINAL)
            module.patch(p)
            with self.assertRaises(ValueError):module.patch(p)
    def test_fails_missing_or_duplicated_anchor_without_edit(self):
        for data in (b'other',ORIGINAL+ORIGINAL):
            with self.subTest(data=data):
                with TemporaryDirectory() as d:
                    p=self.make_file(d,data)
                    with self.assertRaises(ValueError):module.patch(p)
                    self.assertEqual(p.read_bytes(),data)
    def test_refuses_other_file(self):
        with TemporaryDirectory() as d:
            p=Path(d)/'other.cpp';p.write_bytes(ORIGINAL)
            with self.assertRaises(ValueError):module.patch(p)
    def test_existing_stage1ah_verifier_not_weakened(self):
        verifier=(SRC/'scripts/verify_stage1ah.py').read_text()
        self.assertIn('Both independent classes must actually use the selected NFD Face',verifier)
        self.assertIn('len(fwd)==len(expected)',verifier)
        self.assertIn("all(x['face_id']==face for x in fwd)",verifier)
    def test_build_applies_scope_after_approved_stage1af(self):
        b=(SRC/'scripts/build_stage1ah.sh').read_text()
        self.assertLess(b.index('build_stage1af.sh'),b.index('patch_nfd_stage1ah_scope.py'))
        self.assertLess(b.index('patch_nfd_stage1ah_scope.py'),b.index('python3 ./waf -j 2'))
        self.assertIn('nfd_stage1ah_instrumentation.patch',b)

if __name__=='__main__':unittest.main()
