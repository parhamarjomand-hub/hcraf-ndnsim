// HCRAF instrumentation v0.2. No forwarding-policy decisions are made here.
#ifndef HCRAF_RECORDER_HPP
#define HCRAF_RECORDER_HPP
#include <cstdint>
#include <fstream>
#include <map>
#include <stdexcept>
#include <string>

namespace hcraf {
class Recorder {
public:
  Recorder(const std::string& path, uint32_t node) : m_out(path), m_node(node) {
    if (!m_out) throw std::runtime_error("Cannot open HCRAF event file: " + path);
  }
  static std::string quote(const std::string& s) {
    const char* hex = "0123456789abcdef";
    std::string out = "\"";
    for (unsigned char c : s) {
      if (c == '\"' || c == '\\') { out += '\\'; out += c; }
      else if (c < 32) { out += "\\u00"; out += hex[c >> 4]; out += hex[c & 15]; }
      else out += c;
    }
    return out + '\"';
  }
  void event(const char* type, const void* pit, const std::string& name,
             int64_t now, int64_t face = -1, int64_t deadline = -1,
             int64_t nonce = -1, int64_t reason = -1, int64_t bytes = -1) {
    uint64_t id = 0;
    if (pit) {
      auto found = m_pits.find(pit);
      if (found == m_pits.end()) found = m_pits.emplace(pit, ++m_nextPit).first;
      id = found->second;
    }
    m_out << "{\"schema_version\":\"0.2\",\"event_seq\":" << ++m_seq
          << ",\"node_id\":" << m_node << ",\"pit_instance_id\":" << id
          << ",\"time_ns\":" << now << ",\"event_type\":" << quote(type)
          << ",\"name\":" << quote(name) << ",\"face_id\":" << face
          << ",\"deadline_ns\":" << deadline << ",\"nonce\":" << nonce
          << ",\"reason\":" << reason << ",\"payload_bytes\":" << bytes << "}\n";
    if (!m_out) throw std::runtime_error("HCRAF event write failed");
    if (std::string(type) == "PIT_FINALIZE") m_pits.erase(pit);
  }
  void finish(int64_t now) {
    event("SIMULATION_END", nullptr, "", now);
    m_out.flush();
    if (!m_out) throw std::runtime_error("HCRAF event flush failed");
  }
private:
  std::ofstream m_out;
  uint32_t m_node;
  uint64_t m_seq = 0, m_nextPit = 0;
  std::map<const void*, uint64_t> m_pits;
};
}
#endif
