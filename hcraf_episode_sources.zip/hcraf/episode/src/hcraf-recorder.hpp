// HCRAF instrumentation v0.2. No forwarding-policy decisions are made here.
#ifndef HCRAF_RECORDER_HPP
#define HCRAF_RECORDER_HPP
#include <cstdint>
#include <array>
#include <fstream>
#include <map>
#include <stdexcept>
#include <string>

namespace hcraf {
class Recorder {
public:
  Recorder(const std::string& path, uint32_t node, const std::string& prefix = "")
    : m_out(path), m_node(node), m_prefix(prefix) {
    if (!m_out) throw std::runtime_error("Cannot open HCRAF event file: " + path);
    if (!m_prefix.empty()) {
      m_background.open(path + ".background.jsonl");
      if (!m_background) throw std::runtime_error("Cannot open background trace");
    }
  }
  // ndn-cxx at the pinned revision represents Nonce as four network-order
  // bytes (Interest::Nonce publicly derives from std::array<uint8_t, 4>).
  // Explicit shifts avoid host-endian and signed-overflow dependence.
  static int64_t nonceValue(const std::array<uint8_t, 4>& bytes) noexcept {
    return (int64_t(bytes[0]) << 24) | (int64_t(bytes[1]) << 16) |
           (int64_t(bytes[2]) << 8) | int64_t(bytes[3]);
  }
  static std::string quote(const std::string& s) {
    const char* hex = "0123456789abcdef";
    std::string out = "\"";
    for (unsigned char c : s) {
      if (c == '\"' || c == '\\') { out += '\\'; out += c; }
      else if (c < 32) { out += "\\u00"; out += hex[c >> 4]; out += hex[c & 15]; }
      else out += c;
    }
    return out + '\"';
  }
  void event(const char* type, const void* pit, const std::string& name,
             int64_t now, int64_t face = -1, int64_t deadline = -1,
             int64_t nonce = -1, int64_t reason = -1, int64_t bytes = -1) {
    const bool selected = m_prefix.empty() || std::string(type) == "SIMULATION_END" ||
      name == m_prefix || name.compare(0, m_prefix.size() + 1, m_prefix + "/") == 0;
    auto& out = selected ? m_out : m_background;
    auto& pits = selected ? m_pits : m_backgroundPits;
    auto& nextPit = selected ? m_nextPit : m_backgroundNextPit;
    auto& seq = selected ? m_seq : m_backgroundSeq;
    uint64_t id = 0;
    if (pit) {
      auto found = pits.find(pit);
      if (found == pits.end()) found = pits.emplace(pit, ++nextPit).first;
      id = found->second;
    }
    out << "{\"schema_version\":\"0.2\",\"event_seq\":" << ++seq
          << ",\"node_id\":" << m_node << ",\"pit_instance_id\":" << id
          << ",\"time_ns\":" << now << ",\"event_type\":" << quote(type)
          << ",\"name\":" << quote(name) << ",\"face_id\":" << face
          << ",\"deadline_ns\":" << deadline << ",\"nonce\":" << nonce
          << ",\"reason\":" << reason << ",\"payload_bytes\":" << bytes << "}\n";
    if (!out) throw std::runtime_error("HCRAF event write failed");
    if (std::string(type) == "PIT_FINALIZE") pits.erase(pit);
  }
  void finish(int64_t now) {
    event("SIMULATION_END", nullptr, "", now);
    m_out.flush();
    if (m_background.is_open()) {
      m_background.flush();
      if (!m_background) throw std::runtime_error("Background trace flush failed");
    }
    if (!m_out) throw std::runtime_error("HCRAF event flush failed");
  }
private:
  std::ofstream m_out;
  uint32_t m_node;
  std::string m_prefix;
  std::ofstream m_background;
  uint64_t m_backgroundSeq = 0, m_backgroundNextPit = 0;
  std::map<const void*, uint64_t> m_backgroundPits;
  uint64_t m_seq = 0, m_nextPit = 0;
  std::map<const void*, uint64_t> m_pits;
};
}
#endif
