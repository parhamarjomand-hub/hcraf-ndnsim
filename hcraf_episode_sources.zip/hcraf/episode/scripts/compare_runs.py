#!/usr/bin/env python3
import hashlib
import json
import sys
from pathlib import Path
root=Path(sys.argv[1])
report={'status':'PASS','purpose':'DETERMINISTIC_REPLAY_NOT_INDEPENDENT_REPLICATIONS','modes':{}}
for mode in ('success','nack','timeout','cancel','retransmit','open'):
    hashes={}
    for name in ('events.jsonl','episodes.jsonl','consumer_events.jsonl','scenario.json'):
        a=(root/mode/'repeat-1'/name).read_bytes()
        b=(root/mode/'repeat-2'/name).read_bytes()
        if a != b: raise ValueError('Determinism check failed: '+mode+'/'+name)
        hashes[name]=hashlib.sha256(a).hexdigest()
    report['modes'][mode]=hashes
(root/'reproducibility.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
