#!/usr/bin/env python3
"""Exact-source guarded patch; fails closed on another NFD revision."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil

EXPECTED = {
 'forwarder.cpp': '4a37e402ef70c3d07647655eecf454e7c344f36a6b0429975b580b6998612b68',
 'forwarder.hpp': 'd05047ed28a60cfb259f7bc843a53666eaae12bea278f9f494ac77a0dfe55b48',
}

def patch(directory, header):
    files = {}
    for name, sha in EXPECTED.items():
        data = (directory / name).read_bytes()
        if hashlib.sha256(data).hexdigest() != sha:
            raise ValueError('Unexpected or already-patched source: ' + name)
        files[name] = data.decode()
    def replace(name, old, new, count=1):
        if files[name].count(old) != count:
            raise ValueError('Patch anchor mismatch: ' + old[:90])
        files[name] = files[name].replace(old, new)
    replace('forwarder.hpp', '#include "face-table.hpp"',
            '#include "face-table.hpp"\n#include "hcraf-recorder.hpp"')
    replace('forwarder.hpp', '  ~Forwarder();', '''  ~Forwarder();

  // Explicit opt-in: scenario chooses which router to observe.
  void hcrafEnable(const std::string& path, uint32_t nodeId);
  void hcrafFinish();
private:
  std::unique_ptr<hcraf::Recorder> m_hcrafRecorder;
public:''')
    replace('forwarder.cpp', '#include "forwarder.hpp"',
            '#include "forwarder.hpp"\n#include "ns3/simulator.h"')
    replace('forwarder.cpp', 'Forwarder::~Forwarder() = default;', '''Forwarder::~Forwarder() = default;

void Forwarder::hcrafEnable(const std::string& path, uint32_t nodeId)
{
  m_hcrafRecorder.reset(new hcraf::Recorder(path, nodeId, "/hcraf/pilot"));
}
void Forwarder::hcrafFinish()
{
  if (m_hcrafRecorder) {
    m_hcrafRecorder->finish(ns3::Simulator::Now().GetNanoSeconds());
    m_hcrafRecorder.reset();
  }
}''')
    replace('forwarder.cpp', '  ++m_counters.nOutInterests;\n  return &*it;', '''  ++m_counters.nOutInterests;
  if (m_hcrafRecorder) {
    const auto now = ns3::Simulator::Now().GetNanoSeconds();
    const auto remaining = time::duration_cast<time::nanoseconds>(
      it->getExpiry() - time::steady_clock::now()).count();
    m_hcrafRecorder->event("TX_INTEREST", pitEntry.get(), pitEntry->getName().toUri(),
      now, egress.getId(), now + remaining, hcraf::Recorder::nonceValue(interest.getNonce()));
  }
  return &*it;''')
    replace('forwarder.cpp', '  // PIT delete\n  pitEntry->expiryTimer.cancel();', '''  if (m_hcrafRecorder)
    m_hcrafRecorder->event("PIT_FINALIZE", pitEntry.get(), pitEntry->getName().toUri(),
      ns3::Simulator::Now().GetNanoSeconds(), -1, -1, -1, pitEntry->isSatisfied ? 1 : 0);
  // PIT delete
  pitEntry->expiryTimer.cancel();''')
    replace('forwarder.cpp', '    // invoke PIT satisfy callback\n', '''    if (m_hcrafRecorder)
      m_hcrafRecorder->event("DATA_MATCH", pitEntry.get(), pitEntry->getName().toUri(),
        ns3::Simulator::Now().GetNanoSeconds(), ingress.face.getId(), -1, -1, -1,
        data.getContent().value_size());
    // invoke PIT satisfy callback
''')
    # Both normal and cross-entry satisfaction branches in this exact revision.
    replace('forwarder.cpp', '\n      pitEntry->isSatisfied = true;', '''
      pitEntry->isSatisfied = true;
      if (m_hcrafRecorder)
        m_hcrafRecorder->event("PIT_SATISFIED", pitEntry.get(), pitEntry->getName().toUri(),
          ns3::Simulator::Now().GetNanoSeconds(), ingress.face.getId(), -1, -1, -1,
          data.getContent().value_size());''', count=1)
    replace('forwarder.cpp', '\n        pitEntry->isSatisfied = true;', '''
        pitEntry->isSatisfied = true;
        if (m_hcrafRecorder)
          m_hcrafRecorder->event("PIT_SATISFIED", pitEntry.get(), pitEntry->getName().toUri(),
            ns3::Simulator::Now().GetNanoSeconds(), ingress.face.getId(), -1, -1, -1,
            data.getContent().value_size());''')
    replace('forwarder.cpp', '  outRecord->setIncomingNack(nack);', '''  outRecord->setIncomingNack(nack);
  if (m_hcrafRecorder)
    m_hcrafRecorder->event("NACK_ACCEPTED", pitEntry.get(), pitEntry->getName().toUri(),
      ns3::Simulator::Now().GetNanoSeconds(), ingress.face.getId(), -1,
      hcraf::Recorder::nonceValue(nack.getInterest().getNonce()), static_cast<int>(nack.getReason()));''')
    replace('forwarder.cpp', '  afterCsHit(interest, data);', '''  afterCsHit(interest, data);
  if (m_hcrafRecorder)
    m_hcrafRecorder->event("CACHE_HIT", pitEntry.get(), pitEntry->getName().toUri(),
      ns3::Simulator::Now().GetNanoSeconds(), ingress.face.getId());''')
    replace('forwarder.cpp', '  // accept to cache?\n', '''  if (m_hcrafRecorder)
    m_hcrafRecorder->event("UNSOLICITED_DATA", nullptr, data.getName().toUri(),
      ns3::Simulator::Now().GetNanoSeconds(), ingress.face.getId(), -1, -1, -1,
      data.getContent().value_size());
  // accept to cache?
''')
    replace('forwarder.cpp', '  pitEntry->expiryTimer = getScheduler().schedule(duration, [=] { onInterestFinalize(pitEntry); });', '''  pitEntry->expiryTimer = getScheduler().schedule(duration, [=] { onInterestFinalize(pitEntry); });
  if (m_hcrafRecorder)
    m_hcrafRecorder->event("PIT_TIMER", pitEntry.get(), pitEntry->getName().toUri(),
      ns3::Simulator::Now().GetNanoSeconds(), -1,
      ns3::Simulator::Now().GetNanoSeconds() + duration.count() * 1000000);''')
    for name, text in files.items():
        (directory / name).write_text(text)
    shutil.copyfile(header, directory / 'hcraf-recorder.hpp')
    return {name: hashlib.sha256((directory/name).read_bytes()).hexdigest() for name in files}

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('nfd_fw', type=Path)
    p.add_argument('header', type=Path)
    args = p.parse_args()
    print(json.dumps(patch(args.nfd_fw, args.header), indent=2))
