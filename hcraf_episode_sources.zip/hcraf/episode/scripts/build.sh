#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK_DIR="$PROJECT_DIR/hcraf/episode"
SOURCE_DIR="$PROJECT_DIR/episode_sources"
OUTPUT_DIR="$PROJECT_DIR/episode_output"
mkdir -p "$SOURCE_DIR" "$OUTPUT_DIR"
fetch_pinned() {
  local repo_url="$1" target_dir="$2" commit_sha="$3"
  if [[ -e "$target_dir" ]]; then
    echo "Refusing to overwrite existing source directory: $target_dir" >&2
    exit 1
  fi
  git init "$target_dir"
  git -C "$target_dir" remote add origin "$repo_url"
  git -C "$target_dir" fetch --depth 1 origin "$commit_sha"
  git -C "$target_dir" checkout --detach "$commit_sha"
  test "$(git -C "$target_dir" rev-parse HEAD)" = "$commit_sha"
}
fetch_pinned https://github.com/named-data-ndnSIM/ns-3-dev.git "$SOURCE_DIR/ns-3" 1b3bab9b6dba5f1e616c0b286eb889e9ce3d5d59
fetch_pinned https://github.com/named-data-ndnSIM/pybindgen.git "$SOURCE_DIR/pybindgen" a619e22a1492e586f42a688b015c551ea1facd7b
fetch_pinned https://github.com/named-data-ndnSIM/ndnSIM.git "$SOURCE_DIR/ns-3/src/ndnSIM" 90d50396654dabad54b6979f2dc8fa929ade544c
NDN_DIR="$SOURCE_DIR/ns-3/src/ndnSIM"
git -C "$NDN_DIR" submodule sync --recursive
git -C "$NDN_DIR" submodule update --init --recursive
test "$(git -C "$NDN_DIR/NFD" rev-parse HEAD)" = 361b381b9b552ff3341aa160858bea1d470d2122
test "$(git -C "$NDN_DIR/ndn-cxx" rev-parse HEAD)" = 2b51e5796415b5d41fe268b35250b9453f16d3d6
{
  date -u '+UTC: %Y-%m-%dT%H:%M:%SZ'
  git -C "$SOURCE_DIR/ns-3" rev-parse HEAD
  git -C "$SOURCE_DIR/pybindgen" rev-parse HEAD
  git -C "$NDN_DIR" rev-parse HEAD
  git -C "$NDN_DIR" submodule status --recursive
  g++ --version
  python3 --version
} > "$OUTPUT_DIR/source_versions.txt"
dpkg-query -W > "$OUTPUT_DIR/installed_packages.txt"
cp /etc/os-release "$OUTPUT_DIR/os-release.txt"
python3 "$TASK_DIR/scripts/patch_nfd.py" "$NDN_DIR/NFD/daemon/fw" \
  "$TASK_DIR/src/hcraf-recorder.hpp" > "$OUTPUT_DIR/patched_source_hashes.json"
git -C "$NDN_DIR/NFD" diff -- daemon/fw/forwarder.cpp daemon/fw/forwarder.hpp > "$OUTPUT_DIR/nfd_instrumentation.patch"
cp "$TASK_DIR/src/hcraf-episode-pilot.cpp" "$SOURCE_DIR/ns-3/scratch/hcraf-episode-pilot.cc"
cd "$SOURCE_DIR/ns-3"
python3 ./waf configure --disable-python --enable-examples
python3 ./waf -j 2 --targets=hcraf-episode-pilot
test -x build/scratch/hcraf-episode-pilot
