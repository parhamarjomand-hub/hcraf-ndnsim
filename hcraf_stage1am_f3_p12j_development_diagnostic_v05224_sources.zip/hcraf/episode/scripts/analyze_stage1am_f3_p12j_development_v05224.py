#!/usr/bin/env python3
"""P12J read-only descriptive audit of the authenticated P12G DEV artifact.

Never fits, tunes, simulates, scores validation, or reads heldout observations.
The P12G future-only diagnostic is read only after permitted decision-time
features have been sealed; it is never exported as a decision-time predictor.
"""
import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import json
import math
from pathlib import Path

SEEDS = tuple(range(24501, 24507))
PROTECTED = set(range(24601, 24605)) | set(range(24701, 24705))
SITES = ('consumer_ingress', 'producer_egress', 'transit_middle')
LOADS = ('low_control', 'high_pressure')
ROLES = ('relay', 'mid', 'producer')
SCIENCE = {'Congestion': None, 'FutureCongestion': None, 'F3_ready': False,
           'GO_FREEZE': False, 'training_ready': False,
           'heldout_release_authorized': False}
IN_DIR = Path('p12j_input/stage1am_f3_p12g_development_v05221')
OUT_DIR = Path('episode_output/stage1am_f3_p12j_development_diagnostic_v05224')
REPORT = 'P12G_DEVELOPMENT_ONLY_PR_AUC_REPORT.json'
PREDICTIONS = 'P12G_DEVELOPMENT_ONLY_OOF_PREDICTIONS.csv'
FEATURES = 'P12F_DEVELOPMENT_FEATURES_ONLY_v05220.jsonl'
FUTURE = 'P12F_DEVELOPMENT_DIAGNOSTIC_FUTURE_ONLY_v05220.jsonl'
MANIFEST = 'P12G_OUTPUT_SHA256SUMS.txt'
REQUIRED = {REPORT, PREDICTIONS, FEATURES, FUTURE,
            'P12G_AUTHENTICATED_P12F_SOURCE_SHA256.json',
            'P12G_PREREGISTERED_MODEL_PROTOCOL.json'}


def require(condition, code):
    if not condition:
        raise RuntimeError('P12J_' + code)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            digest.update(chunk)
    return digest.hexdigest()


def seal_parent(parent):
    require(parent.is_dir(), 'P12G_PARENT_MISSING')
    manifest_path = parent / MANIFEST
    require(manifest_path.is_file(), 'P12G_SHA_MANIFEST_MISSING')
    expected = {}
    for line in manifest_path.read_text(encoding='utf-8').splitlines():
        try:
            digest, name = line.split('  ', 1)
        except ValueError as exc:
            raise RuntimeError('P12J_INVALID_PARENT_MANIFEST') from exc
        require(len(digest) == 64 and all(c in '0123456789abcdef' for c in digest)
                and name not in expected and name and '/' not in name and '\\' not in name,
                'P12G_SHA_MANIFEST_INVALID')
        expected[name] = digest
    actual = {p.name for p in parent.iterdir() if p.is_file() and p.name != MANIFEST}
    require(actual == set(expected) == REQUIRED, 'P12G_FILES_OR_MANIFEST_CHANGED')
    for name, digest in expected.items():
        require(sha(parent / name) == digest, 'P12G_MEMBER_SHA_' + name)

    protocol = json.loads((parent / 'P12G_PREREGISTERED_MODEL_PROTOCOL.json').read_text())
    require(protocol['stage'] == 'v0.52.21_P12G_PROSPECTIVE_FIXED_DEV_SEED_BLOCKED_OOF_ONLY'
            and tuple(protocol['development_seed_blocks']) == SEEDS
            and set(protocol['validation_seed_blocks_protected']) |
            set(protocol['heldout_seed_blocks_protected']) == PROTECTED
            and protocol['model_search_or_hyperparameter_tuning'] is False,
            'P12G_PROTOCOL_CHANGED')
    report = json.loads((parent / REPORT).read_text())
    require(report['status'] == 'P12G_DEVELOPMENT_ONLY_DIAGNOSTIC_PR_AUC_NO_CONFIRMATORY_CLAIM'
            and report['development_only_out_of_seed_fold_predictions'] == 4608
            and report['prospective_development_rows'] == 9216
            and report['validation_runs'] == report['heldout_runs'] == 0
            and report['official_F3_PR_AUC_computed'] is False,
            'P12G_REPORT_CONTRACT')
    require(all(protocol.get(k) is v and report.get(k) is v for k, v in SCIENCE.items()),
            'P12G_SCIENCE_LOCKS')
    provenance = json.loads((parent / 'P12G_AUTHENTICATED_P12F_SOURCE_SHA256.json').read_text())
    require(provenance['parent_run_id'] == 44764413606 and
            provenance['all_2886_raw_files_SHA256_verified'] is True,
            'P12F_PROVENANCE_CHANGED')
    return report, expected


def jsonlines(path):
    with path.open('r', encoding='utf-8') as stream:
        for line in stream:
            if line.strip():
                yield json.loads(line)


def average_precision(scores_labels):
    """Tie-grouped uninterpolated AP, independently reproduced from P12G."""
    pairs = list(scores_labels)
    positives = sum(y for _, y in pairs)
    if positives == 0:
        return None
    ranked = sorted(pairs, reverse=True)
    seen = correct = i = 0
    area = 0.0
    while i < len(ranked):
        j = i
        group_positives = 0
        while j < len(ranked) and ranked[j][0] == ranked[i][0]:
            group_positives += ranked[j][1]
            j += 1
        seen += j - i
        correct += group_positives
        area += (correct / seen) * (group_positives / positives)
        i = j
    require(0 <= area <= 1.00000000001, 'AP_RANGE')
    return area


def load_predictions(parent):
    predictions = {}
    with (parent / PREDICTIONS).open(newline='', encoding='utf-8') as stream:
        reader = csv.DictReader(stream)
        require(reader.fieldnames == ['row_key', 'seed', 'site', 'load', 'telemetry',
                                     'y', 'score_local', 'score_remote'], 'PREDICTION_FIELDS')
        for row in reader:
            key = row['row_key']
            seed = int(row['seed'])
            y = int(row['y'])
            local, remote = float(row['score_local']), float(row['score_remote'])
            require(key not in predictions and seed in SEEDS and seed not in PROTECTED
                    and row['site'] in SITES and row['load'] in LOADS
                    and row['telemetry'] == 'on_20ms' and y in (0, 1)
                    and key.startswith(f"{seed}:{row['site']}:{row['load']}:on_20ms:")
                    and math.isfinite(local) and math.isfinite(remote)
                    and 0 <= local <= 1 and 0 <= remote <= 1, 'INVALID_OOF_ROW')
            predictions[key] = dict(row_key=key, seed=seed, site=row['site'],
                                    load=row['load'], y=y,
                                    score_local=local, score_remote=remote)
    require(len(predictions) == 4608 and
            Counter(p['seed'] for p in predictions.values()) == {s: 768 for s in SEEDS},
            'OOF_PARTITION')
    return predictions


def describe(rows):
    positives = sum(p['y'] for p in rows)
    local = average_precision((p['score_local'], p['y']) for p in rows)
    remote = average_precision((p['score_remote'], p['y']) for p in rows)
    return dict(n=len(rows), positive=positives, negative=len(rows)-positives,
                prevalence=positives / len(rows) if rows else None,
                AP_local=local, AP_remote=remote,
                delta_AP_remote_minus_local=None if local is None or remote is None
                else remote - local)


def load_features_and_future(parent, predictions):
    allowed = {}
    all_partitions = Counter()
    remote_nonempty_counts = Counter()
    remote_present_counts = Counter()
    role_present_counts = Counter()
    role_nonempty_counts = Counter()
    for item in jsonlines(parent / FEATURES):
        require(set(item) == {'metadata_NOT_A_PREDICTOR', 'allowed_decision_time_features'},
                'FEATURES_TOPLEVEL_FIELDS')
        m, x = item['metadata_NOT_A_PREDICTOR'], item['allowed_decision_time_features']
        seed, key, telemetry = m['seed'], m['row_key'], m['telemetry']
        require(seed in SEEDS and seed not in PROTECTED and m['site'] in SITES
                and m['load'] in LOADS and telemetry in ('off', 'on_20ms')
                and isinstance(m['decision_ns'], int) and m['decision_ns'] >= 0,
                'FEATURES_PARTITION_OR_TIME')
        all_partitions[(seed, m['site'], m['load'], telemetry)] += 1
        if telemetry != 'on_20ms':
            require(key not in predictions, 'OFF_IN_MODEL')
            continue
        require(key in predictions and key not in allowed, 'FEATURES_KEY_DUPLICATE_OR_OOF')
        p = predictions[key]
        require((p['seed'], p['site'], p['load']) == (seed, m['site'], m['load']),
                'FEATURES_METADATA_MISMATCH')
        require(set(x) == {'fib_route_cost', 'local_selected_queue_packets',
                           'local_selected_queue_fraction', 'local_selected_link_up'} |
                {f'{r}_{field}' for r in ROLES for field in
                 ('queue_packets', 'queue_drops_observed_total',
                  'telemetry_age_ms', 'telemetry_missing')}, 'FEATURES_SCHEMA')
        flags = []
        for role in ROLES:
            missing = x[f'{role}_telemetry_missing']
            age = x[f'{role}_telemetry_age_ms']
            count = x[f'{role}_queue_packets']
            require(isinstance(missing, bool), 'TELEMETRY_MISSING_SCHEMA')
            if missing:
                require(age is None and count is None, 'MISSING_WITH_REPORTED_QUEUE')
                flags.append(False)
            else:
                require(isinstance(count, int) and count >= 0 and
                        isinstance(age, (int, float)) and math.isfinite(age) and age >= 0,
                        'CAUSAL_TELEMETRY_VALUE_INVALID')
                role_present_counts[role] += 1
                role_nonempty_counts[role] += int(count > 0)
                flags.append(count > 0)
        present = any(not x[f'{role}_telemetry_missing'] for role in ROLES)
        nonempty = any(flags)
        allowed[key] = dict(any_remote_available=present,
                            any_remote_queue_nonempty=nonempty,
                            n_remote_roles_available=sum(not x[f'{r}_telemetry_missing']
                                                         for r in ROLES))
        remote_present_counts['all'] += int(present)
        remote_nonempty_counts['all'] += int(nonempty)
    require(len(allowed) == len(predictions) == 4608, 'FEATURES_COUNT')
    require(len(all_partitions) == 72 and set(all_partitions.values()) == {128},
            'SEVENTY_TWO_CASES')

    future_keys = set()
    feature_keys = set(allowed)
    total_positive = positive_telemetry_on = 0
    for lab in jsonlines(parent / FUTURE):
        require(set(lab) == {'row_key', 'DIAGNOSTIC_ONLY_not_official_F3',
                             'retrospective_future_selected_path_QUEUE_DROP_75ms',
                             'retrospective_future_drop_event_count'}, 'LABEL_SCHEMA')
        key, y = lab['row_key'], lab['retrospective_future_selected_path_QUEUE_DROP_75ms']
        require(key not in future_keys and y in (0, 1)
                and lab['DIAGNOSTIC_ONLY_not_official_F3'] is True
                and isinstance(lab['retrospective_future_drop_event_count'], int)
                and (lab['retrospective_future_drop_event_count'] > 0) == bool(y),
                'DIAGNOSTIC_FUTURE_SEMANTICS')
        future_keys.add(key)
        total_positive += y
        if key in feature_keys:
            require(predictions[key]['y'] == y, 'OOF_FUTURE_LABEL_MISMATCH')
            positive_telemetry_on += y
        else:
            require(':off:' in key, 'UNSEEN_FUTURE_CASE')
    require(len(future_keys) == 9216 and len(future_keys - feature_keys) == 4608
            and total_positive == 604 and positive_telemetry_on == 303,
            'NINE_THOUSAND_ROWS_LABEL_COUNTS')
    return allowed, all_partitions, role_present_counts, role_nonempty_counts


def diagnostic(predictions, allowed, part_counts, role_present, role_nonempty, report):
    rows = list(predictions.values())
    pooled = describe(rows)
    require(pooled['positive'] == report['positive_count'] == 303
            and pooled['negative'] == report['negative_count'] == 4305,
            'P12G_COUNTS_CHANGED')
    for key, value in [('AP_local', 'development_out_of_fold_AP_local'),
                       ('AP_remote', 'development_out_of_fold_AP_remote'),
                       ('delta_AP_remote_minus_local',
                        'development_out_of_fold_delta_AP_remote_minus_local')]:
        require(math.isclose(pooled[key], report[value], abs_tol=1e-12, rel_tol=0),
                'P12G_REPORTED_AP_CHANGED_' + key)

    seed_metrics = [dict(seed=seed, **describe([p for p in rows if p['seed'] == seed]))
                    for seed in SEEDS]
    site_metrics = [dict(site=site, **describe([p for p in rows if p['site'] == site]))
                    for site in SITES]
    load_metrics = [dict(load=load, **describe([p for p in rows if p['load'] == load]))
                    for load in LOADS]
    scenarios = []
    for seed in SEEDS:
        for site in SITES:
            for load in LOADS:
                selected = [p for p in rows if (p['seed'], p['site'], p['load']) ==
                            (seed, site, load)]
                require(len(selected) == 128, 'SCENARIO_NOT_128_DECISIONS')
                positives = [p for p in selected if p['y'] == 1]
                negatives = [p for p in selected if p['y'] == 0]
                scenarios.append(dict(seed=seed, site=site, load=load,
                    **describe(selected),
                    number_independent_seed_blocks=1,
                    remote_available=sum(allowed[p['row_key']]['any_remote_available']
                                         for p in selected),
                    remote_nonempty=sum(allowed[p['row_key']]['any_remote_queue_nonempty']
                                        for p in selected),
                    remote_nonempty_given_future_positive=sum(
                        allowed[p['row_key']]['any_remote_queue_nonempty'] for p in positives),
                    remote_nonempty_given_future_negative=sum(
                        allowed[p['row_key']]['any_remote_queue_nonempty'] for p in negatives)))
    require(len(scenarios) == 36, 'SCENARIOS_COUNT')
    leave_one_seed_out = []
    for seed in SEEDS:
        sub = [p for p in rows if p['seed'] != seed]
        leave_one_seed_out.append(dict(excluded_seed=seed, **describe(sub)))

    positive_nonempty = sum(allowed[p['row_key']]['any_remote_queue_nonempty']
                            for p in rows if p['y'])
    negative_nonempty = sum(allowed[p['row_key']]['any_remote_queue_nonempty']
                            for p in rows if not p['y'])
    report_out = dict(
        stage='P12J_v0.52.24_READ_ONLY_DEVELOPMENT_DIAGNOSTIC',
        status='PASS_P12J_DEV_ONLY_DIAGNOSTIC_WITH_P12I_CONFIRMATORY_NO_GO_UNCHANGED',
        parent_p12g_run=44779320010,
        parent_p12g_commit='9689fa0e1c5dc80a990451a282cf78f1b0e71c6c',
        parent_p12g_artifact_id=14652215437,
        parent_p12g_artifact_sha256='1792fce65047c4594f8fd8691cd8480842edfaae0a2b38bb5cf75226b5919718',
        parent_p12i_independent_audit_run=44895950750,
        parent_p12i_decision='NO_GO_P12H_VALIDATION_EVIDENCE_OR_PREDICTABILITY',
        eligible_dev_seed_blocks=list(SEEDS),
        untouched_validation_seed_blocks=list(range(24601, 24605)),
        sealed_heldout_seed_blocks=list(range(24701, 24705)),
        physical_case_count_from_authenticated_parent=72,
        telemetry_on_scenario_count=36,
        nominal_episode_count=4608,
        independent_seed_block_count=6,
        scientific_note='128 episodes per case are clustered by seed/scenario; overlapping 75ms windows are not independent.',
        original_oof_metrics_reproduced=pooled,
        seed_metrics_descriptive=seed_metrics,
        site_metrics_descriptive=site_metrics,
        load_metrics_descriptive=load_metrics,
        leave_one_seed_out_sensitivity_DESCRIPTIVE_NOT_NEW_CV=leave_one_seed_out,
        scenario_metrics_descriptive=scenarios,
        scenarios_with_zero_future_drops=sum(s['positive'] == 0 for s in scenarios),
        high_pressure_scenarios_with_zero_future_drops=sum(
            s['positive'] == 0 and s['load'] == 'high_pressure' for s in scenarios),
        low_control_scenarios_with_future_drops=sum(
            s['positive'] > 0 and s['load'] == 'low_control' for s in scenarios),
        remote_telemetry_descriptive={
            'decision_time_remote_available_count':sum(
                allowed[p['row_key']]['any_remote_available'] for p in rows),
            'decision_time_remote_nonempty_count':sum(
                allowed[p['row_key']]['any_remote_queue_nonempty'] for p in rows),
            'any_remote_nonempty_among_future_drops':positive_nonempty,
            'any_remote_nonempty_among_future_no_drop':negative_nonempty,
            'present_count_by_role':dict(role_present),
            'nonempty_count_by_role':dict(role_nonempty),
            'association_is_not_independent_prediction':True},
        authenticated_partition_cases=len(part_counts),
        no_new_simulation=True, no_model_fits=True, no_validation_or_heldout_rows_read=True,
        no_model_selection_using_validation=True, no_official_F3_label=True,
        official_F3_PR_AUC_computed=False,
        next_step_recommendation='Preregister a separate prospective sample-size/seed-matrix and frozen analysis plan. No re-testing the consumed P12H validation blocks as a fresh confirmatory test.',
        confirmatory_gate='NO_GO', Stage1AO_or_NSGAIII_authorized=False,
        **SCIENCE)
    return report_out


def run(parent=IN_DIR, output=OUT_DIR):
    require(not output.exists(), 'REFUSE_OVERWRITE_EXISTING_OUTPUT')
    report, hashes = seal_parent(parent)
    predictions = load_predictions(parent)
    allowed, partitions, present, nonempty = load_features_and_future(parent, predictions)
    summary = diagnostic(predictions, allowed, partitions, present, nonempty, report)
    output.mkdir(parents=True, exist_ok=False)
    (output / 'P12J_DEV_ONLY_DIAGNOSTIC_REPORT.json').write_text(
        json.dumps(summary, indent=2, ensure_ascii=False, sort_keys=True) + '\n', encoding='utf-8')
    (output / 'P12J_VERIFIED_P12G_INPUT_SHA256.json').write_text(
        json.dumps({'sha_manifest_verified_for_all_members': True,
                    'sha256_by_file': hashes,
                    'parent_p12g_artifact_sha256': summary['parent_p12g_artifact_sha256'],
                    **SCIENCE}, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    lines = ['# P12J ـ نتیجهٔ تشخیصی فقط بر اساس Development', '',
             'این گزارش هیچ شاهد تأییدی جدیدی محسوب نمی‌شود. نتیجهٔ P12I همچنان NO_GO است.',
             '', f"- تعداد بلوک‌های تصادفی مستقل: {summary['independent_seed_block_count']}",
             f"- تعداد Episodeهای نامی: {summary['nominal_episode_count']}",
             f"- سناریوهای فاقد افت آینده: {summary['scenarios_with_zero_future_drops']} از ۳۶",
             f"- سناریوهای پرفشار فاقد افت آینده: {summary['high_pressure_scenarios_with_zero_future_drops']}",
             f"- سناریوهای کنترل کم‌بار با افت آینده: {summary['low_control_scenarios_with_future_drops']}",
             '', 'همهٔ شاخص‌های AP این مرحله توصیفی و مبتنی بر همان داده‌های P12G هستند.',
             'هیچ ویژگی زمانی از برچسب‌های ۷۵ میلی‌ثانیهٔ آینده ساخته نشده است.',
             'هیچ بذر Validation یا Heldout و هیچ آموزش جدیدی استفاده نشده است.',
             'گام بعدی، پیش‌ثبت مستقل طرح حجم نمونه و بذرهای تازه است؛ نه تکرار P12H.',
             'قفل‌ها: Congestion=null؛ FutureCongestion=null؛ F3_ready=false؛ '
             'GO_FREEZE=false؛ training_ready=false؛ heldout_release_authorized=false.']
    (output / 'P12J_EXECUTIVE_DECISION_FA.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    (output / 'P12J_OUTPUT_SHA256SUMS.txt').write_text(''.join(
        sha(path) + '  ' + path.name + '\n' for path in sorted(output.iterdir()) if path.is_file()),
        encoding='utf-8')
    print(json.dumps({k: summary[k] for k in (
        'status', 'nominal_episode_count', 'independent_seed_block_count',
        'scenarios_with_zero_future_drops',
        'high_pressure_scenarios_with_zero_future_drops',
        'low_control_scenarios_with_future_drops', 'confirmatory_gate')},
        ensure_ascii=False, sort_keys=True))
    return summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--parent-dir', type=Path, default=IN_DIR)
    parser.add_argument('--output-dir', type=Path, default=OUT_DIR)
    args = parser.parse_args()
    run(args.parent_dir, args.output_dir)


if __name__ == '__main__':
    main()
