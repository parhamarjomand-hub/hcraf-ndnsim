"""Synthetic P12J safeguards; no physical, validation or heldout data needed."""
import csv
import tempfile
import unittest
from pathlib import Path

from analyze_stage1am_f3_p12j_development_v05224 import (
    SCIENCE, SEEDS, PROTECTED, average_precision, load_predictions, require,
)


class P12JReadOnlyTests(unittest.TestCase):
    def test_tie_grouped_uninterpolated_average_precision(self):
        scores = [(0.9, 1), (0.9, 0), (0.5, 1), (0.1, 0)]
        self.assertAlmostEqual(average_precision(scores), .5 * .5 + (2/3) * .5)

    def test_average_precision_no_future_drop_is_undefined(self):
        self.assertIsNone(average_precision([(0.3, 0), (0.8, 0)]))

    def test_seed_exclusion_and_scientific_locks(self):
        self.assertEqual(len(SEEDS), 6)
        self.assertFalse(set(SEEDS) & PROTECTED)
        self.assertIsNone(SCIENCE['Congestion'])
        self.assertIsNone(SCIENCE['FutureCongestion'])
        self.assertFalse(any(SCIENCE[k] for k in (
            'F3_ready', 'GO_FREEZE', 'training_ready',
            'heldout_release_authorized')))

    def test_reject_protected_validation_seed_in_predictions(self):
        with tempfile.TemporaryDirectory() as tmp:
            parent = Path(tmp)
            with (parent/'P12G_DEVELOPMENT_ONLY_OOF_PREDICTIONS.csv').open(
                    'w', newline='') as stream:
                writer = csv.writer(stream)
                writer.writerow(('row_key', 'seed', 'site', 'load', 'telemetry',
                                 'y', 'score_local', 'score_remote'))
                writer.writerow(('24601:consumer_ingress:low_control:on_20ms:1',
                                 24601, 'consumer_ingress', 'low_control',
                                 'on_20ms', 1, .1, .2))
            with self.assertRaisesRegex(RuntimeError, 'P12J_INVALID_OOF_ROW'):
                load_predictions(parent)

    def test_require_is_fail_closed(self):
        with self.assertRaisesRegex(RuntimeError, 'P12J_TEST_STOP'):
            require(False, 'TEST_STOP')


if __name__ == '__main__':
    unittest.main()
