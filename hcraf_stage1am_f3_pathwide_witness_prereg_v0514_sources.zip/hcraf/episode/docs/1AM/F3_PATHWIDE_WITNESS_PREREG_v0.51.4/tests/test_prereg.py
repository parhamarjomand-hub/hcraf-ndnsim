import copy
import csv
import importlib.util
import json
import pathlib
import tempfile
import unittest
from unittest.mock import patch

ROOT=pathlib.Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('prereg_verifier',ROOT/'verify_prereg.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)

class ContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.c=json.loads((ROOT/'CONTRACT_LOCKED.json').read_text())

    def test_actual_package(self):
        self.assertEqual(module.verify(ROOT)['checked_path_device_records'],1152)

    def test_three_slot_routes(self):
        self.assertEqual(len(module.device_map()),3)

    def test_eight_directed_devices_each(self):
        self.assertTrue(all(len(v)==8 for v in module.device_map().values()))

    def test_expected_return_path_node(self):
        self.assertIn((0,'RETURN',1,8,0,7),module.device_map()[0])

    def test_return_mid_device_not_producer(self):
        self.assertIn((1,'RETURN',2,6,0,3),module.device_map()[1])

    def test_no_scientific_labels(self):
        self.assertTrue(self.c['no_official_f3'])
        self.assertEqual(self.c['science_locks'],module.EXPECTED_LOCKS)

    def test_no_simulation(self):
        self.assertTrue(self.c['no_ns3_simulation'])

    def test_single_class_ap_undefined(self):
        self.assertEqual(self.c['stats']['single_class_run_ap'],'UNDEFINED_INCONCLUSIVE_REPORT_COVERAGE')

    def test_negative_requires_opportunity(self):
        self.assertTrue(self.c['outcomes']['negative_requires_observation_opportunity_on_each_required_device'])

    def test_negative_requires_age(self):
        self.assertTrue(self.c['outcomes']['negative_requires_zero_drop_and_no_wait_age_violation_all_path_devices'])

    def test_no_delivery_in_label(self):
        self.assertFalse(self.c['outcomes']['target_delivery_used_for_label'])

    def test_no_counterfactual(self):
        self.assertTrue(self.c['outcomes']['no_cf_for_unselected_face'])

    def test_witness_independence_is_bounded(self):
        self.assertIn('same simulator',self.c['witness']['independence_limit'])

    def test_calibration_separate(self):
        self.assertEqual(self.c['stats']['calibration_fit_split'],'HELD_OUT_CAL_ONLY')

    def test_threshold_only_pilot(self):
        self.assertIn('NOT_SCIENTIFIC_F3',self.c['pilot_window']['status'])

    def test_future_test_forbidden(self):
        self.assertEqual(self.c['stats']['test_after_separate_freeze'],'NO_TEST_IN_THIS_WORKFLOW')

    def test_wrong_science_lock_fail(self):
        x=copy.deepcopy(self.c);x['science_locks']['F3_ready']=True
        # Direct data guard used by production validator.
        with self.assertRaisesRegex(AssertionError,'SCIENCE_LOCK_DRIFT'):
            module.check(x['science_locks']==module.EXPECTED_LOCKS,'SCIENCE_LOCK_DRIFT')

    def test_invalid_slot_guard(self):
        with self.assertRaisesRegex(AssertionError,'INVALID_SLOT'):
            module.check(4 in module.device_map(),'INVALID_SLOT')

    def test_missing_witness_is_unknown_not_negative(self):
        self.assertIn('UNKNOWN',self.c['outcomes']['possible_candidate_states'])
        self.assertTrue(self.c['outcomes']['requires_all_path_device_coverage'])

    def _mutated_tree(self, filename, updater):
        from shutil import copytree
        with tempfile.TemporaryDirectory() as d:
            x=pathlib.Path(d)/'contract'
            copytree(ROOT,x)
            p=x/filename
            updater(p)
            with self.assertRaises(AssertionError):
                module.verify(x)

    def test_mutated_map_fails(self):
        def mutate(p):
            lines=p.read_text().splitlines()
            parts=lines[1].split(',');parts[4]='99';lines[1]=','.join(parts)
            p.write_text('\n'.join(lines)+'\n')
        self._mutated_tree('PATH_MAP_LOCKED_24.csv',mutate)

    def test_mutated_inventory_fails(self):
        def mutate(p):
            s=p.read_text();p.write_text(s.replace(',True,True', ',False,True', 1))
        self._mutated_tree('PATH_DEVICE_INVENTORY_V0510_1152.csv',mutate)

    def test_mutated_f3_lock_fails(self):
        def mutate(p):
            d=json.loads(p.read_text());d['F3_ready']=True
            p.write_text(json.dumps(d))
        self._mutated_tree('SCIENCE_LOCKS.json',mutate)

    def test_target_delivery_in_label_fails(self):
        def mutate(p):
            d=json.loads(p.read_text());d['outcomes']['target_delivery_used_for_label']=True
            p.write_text(json.dumps(d))
        self._mutated_tree('CONTRACT_LOCKED.json',mutate)

    def test_source_artifact_hash_is_frozen(self):
        self.assertEqual(self.c['evidence_zip_sha256'],module.EXPECTED_SHA)

    def test_path_map_is_complete(self):
        with (ROOT/'PATH_MAP_LOCKED_24.csv').open(newline='') as f:
            rows=list(csv.DictReader(f))
        self.assertEqual(len(rows),24)
        self.assertTrue(all(row['face_id_source']=='INITIAL_EVENT_DERIVED_NEVER_ASSUME' for row in rows))

if __name__=='__main__':
    unittest.main()
