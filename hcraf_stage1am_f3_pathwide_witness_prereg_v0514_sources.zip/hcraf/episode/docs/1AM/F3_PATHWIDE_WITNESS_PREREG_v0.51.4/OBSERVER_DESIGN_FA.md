# طرح فنی Observer مستقلِ مسیر در ndnSIM — v0.51.4

**وضعیت: طراحی و پیش‌ثبت؛ نه کد C++ کامپایل‌شده.** این سند الزاماتی را قفل می‌کند که در Executor بعد باید در C++ پیاده‌سازی و در GitHub آزمایش شوند.

## لایه‌بندی پیشنهادی

1. `PathResolver` از سناریوی واقعی `selected_slot`, `selected_face_id`, `path_nodes`, اتصال‌های net-device و `INITIAL` ۲۰ دستگاه، مسیر ۸ دستگاه جهت‌دار را استخراج می‌کند. نگاشت `Face` صرفاً از `L3Protocol::getFaceByNetDevice()` خوانده می‌شود.
2. `WitnessB` یک کلاس C++ جدید خارج از `HcrafStage1wMonitor` است. از trace sourceهای native صف `Enqueue`, `Dequeue`, `Drop` و فیزیک نقطه‌به‌نقطه `PhyTxBegin`/`PhyTxEnd` شمارنده‌های مستقل می‌سازد. Callbackها صرفاً داده می‌نویسند و حق تغییر نرخ، DropTailQueue، زمان ارسال یا FIB را ندارند.
3. `IndependentSampler` در بازه ۱ms، `queue_packets`, `queue_bytes`, ظرفیت و وضعیت فرستنده را از خود `ns3::Queue` می‌خواند. Event Counter و Snapshot باید با هم reconcile شوند. **نمونه‌برداری ۱ms به‌تنهایی عبور کوتاه از آستانه را اثبات/رد نمی‌کند**؛ event-driven age accounting لازم است.
4. `ObservationOpportunity` برای هر مسیر/پنجره، `start_ns/end_ns`, پوشش هر دستگاه، تعداد ENQUEUE/DEQUEUE, سن قدیمی‌ترین بسته در صف، Counter Drop و پیوستگی EventSeq را ثبت می‌کند. Pending enqueues از نظر سن صف نیز بررسی می‌شوند. هویت Queue و آدرس حافظه به خروجی متکی نیست.
5. `WitnessReconciler` بعد از Run فایل A و B را مستقل می‌خواند و اختلاف را به‌صورت جزئی در `witness_disagreements.jsonl` گزارش می‌کند؛ فایل A هرگز برای پرکردن مقدار گم‌شده B استفاده نمی‌شود.

## قرارداد رکورد آینده

**نام فایل پیشنهادشده:** `pathwide_witness_v0514.jsonl`، با `schema_version="PATHWIDE_WITNESS.1"`.

فیلدهای الزامی رویداد: `run_id`, `timestamp_ns`, `sequence`, `node_id`, `device_index`, `face_id`, `event_type`, `queue_packets`, `queue_bytes`, `drop_packets_cumulative`, `tx_bytes_cumulative`, `monitor_id`. رویدادهای مورد انتظار `INITIAL`, `FINAL`, `QUEUE_ENQUEUE`, `QUEUE_DEQUEUE`, `QUEUE_DROP`, `PHY_TX_BEGIN`, `PHY_TX_END`, `QUEUE_SNAPSHOT` هستند. در سطح پوشش پنجره نیز `selected_slot`, `path_direction`, `window_start_ns`, `window_end_ns`, `observation_opportunity`, `oldest_packet_age_ns_upper_bound`, `pending_age_verified`, `witnessA_status`, `witnessB_status`, `censor_reason`, `unknown_reason` ثبت شود.

**تمام رویدادهای B** باید timestamp و sequence منحصربه‌فرد، روبه‌افزایش و مطابق زمان شبیه‌ساز داشته باشند. شمارنده تجمعی Drop و Byte نباید کاهش یابد. `INITIAL/FINAL` برای تمام ۲۰ دستگاه الزامی است. پوشش یک پنجره در همه ۸ دستگاه مسیر با ساعت شبیه‌سازی یکسان کنترل می‌شود؛ no-data با no-pressure معادل نیست.

## تست‌های الزامی پیش از اجرای علمی

- `SLOT_PATH_RESOLUTION_3x8`: سه مسیر مستقل با هویت واقعاً خوانده‌شده از device؛ تست غلط بودن node یا face.
- `COVERAGE_20_DEVICES`: تمام INITIAL/FINAL و ۲۰ دستگاه، پیوستگی clock و EventSeq.
- `QUEUE_COUNTER_RECONCILIATION`: شمارنده مستقل B با رخدادهای متناظر A بعد از تعدیل تفاوت قرارداد callback تطبیق شود.
- `NO_EVENT_IS_NOT_NEGATIVE`: نبود event، queue age نامعلوم، حضور ترافیک صفر، یا back-pressure مبهم باید UNKNOWN باشد.
- `WINDOW_CENSORING`: پایان Run در وسط `(t,t+h]` باید CENSORED بدهد.
- `MISSING_FRAGMENT_OR_RECEIPT`: وجود نقصان در attribution بدون جعل منفی؛ Impact مستقل بماند.
- `NONCONGESTION_LOSS`: خطای `PhyRxDrop` بر اثر ErrorModel نباید الزاماً شاهد congestion شود.
- `NO_DECISION_LEAK`: اطلاعات Future یا نام arm نباید در NFD Online State استفاده شود.
- `MONITOR_PERTURBATION`: جفت‌های monitored/unmonitored با برنامه ارسال دقیقاً یکسان؛ سنجش زمان/CPU/RSS و اختلاف پیامد.

این قرارداد **پیاده‌سازی نشده**؛ هیچ ادعای کامپایل، نتیجه مستقل فیزیکی یا اعتبار نهایی F3 ندارد.
