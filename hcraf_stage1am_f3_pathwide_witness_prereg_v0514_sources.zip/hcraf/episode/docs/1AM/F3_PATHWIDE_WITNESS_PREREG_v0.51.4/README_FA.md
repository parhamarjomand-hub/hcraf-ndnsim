# HCRAF — Pathwide Witness Prereg v0.51.4

بسته برای **پیش‌ثبت Git فقط** است. اجرای آزمایش و کامپایل C++ در این مرحله وجود ندارد.

- `PREREG_PROTOCOL_FA.md`: قرارداد علمی و روش داوری پیشنهادی؛ قفل‌شونده در Git.
- `OBSERVER_DESIGN_FA.md`: طرح فنی مشاهده‌گر جداگانه، **بدون کد اجرایی**.
- `CONTRACT_LOCKED.json` و `SCIENCE_LOCKS.json`: قواعد قابل بررسی ماشین.
- `PATH_MAP_LOCKED_24.csv`: ۳ Slot × ۸ دستگاه جهت‌دار.
- `PATH_DEVICE_INVENTORY_V0510_1152.csv` و `PATH_AUDIT_V0510_SUMMARY.json`: ممیزی توصیفی داده‌های تاریخی، نه Witness مستقل.
- `verify_prereg.py`: کنترل تناسب مسیر، سلامت سند و گیت‌ها.
- `tests/test_prereg.py`: آزمون قفل‌ها و خطاهای ساختگی.

در مخزن GitHub فقط ZIP داخلی و Workflow جدید را Commit کن. Workflow منابع را در پوشه کاری Artifact به‌شکل موقت استخراج و بررسی می‌کند؛ فایل‌های قدیمی را بازنویسی نمی‌کند.

خروجی GitHub: رسید `prereg_lock_receipt.json` و لاگ آزمون‌ها؛ `PASS` فقط برای قرارداد Git، نه F3 علمی.

**تمام قفل‌های علمی F3 پابرجا هستند.**
