#!/usr/bin/env python3
"""Fail-closed audit of the v0.51.4 preregistration contract (no simulator)."""
import argparse
import collections
import csv
import hashlib
import json
from pathlib import Path

EXPECTED_LOCKS = {
    "Congestion": None, "FutureCongestion": None,
    "F3_ready": False, "GO_FREEZE": False, "training_ready": False,
}
EXPECTED_PATH_NODES = {
    0: [0, 1, 2, 7, 8],
    1: [0, 1, 3, 6, 9],
    2: [0, 1, 4, 5, 10],
}
EXPECTED_LINKS = [(0, 1), (1, 2), (1, 3), (1, 4),
                  (2, 7), (3, 6), (4, 5), (7, 8), (6, 9), (5, 10)]
EXPECTED_SHA = "591556124a4eeae0987e623e7aedf7f84334b6e0521ede26848abee58745b43a"


def check(condition, code):
    if not condition:
        raise AssertionError(code)


def read_csv(path):
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def device_map():
    inc = collections.defaultdict(list)
    for u, v in EXPECTED_LINKS:
        inc[u].append(v)
        inc[v].append(u)
    out = {}
    for slot, nodes in EXPECTED_PATH_NODES.items():
        d = []
        for direction, path in (("FORWARD", nodes), ("RETURN", nodes[::-1])):
            for hop, (u, v) in enumerate(zip(path, path[1:]), 1):
                d.append((slot, direction, hop, u, inc[u].index(v), v))
        out[slot] = d
    return out


def verify(root):
    root = Path(root)
    contract = json.loads((root / "CONTRACT_LOCKED.json").read_text(encoding="utf-8"))
    locks = json.loads((root / "SCIENCE_LOCKS.json").read_text(encoding="utf-8"))
    check(locks == EXPECTED_LOCKS, "SCIENCE_LOCK_DRIFT")
    check(contract["science_locks"] == EXPECTED_LOCKS, "CONTRACT_LOCK_DRIFT")
    check(contract["schema"] == "HCRAF_F3_PATHWIDE_WITNESS_PREREG_V0514", "WRONG_SCHEMA")
    check(contract["contract_status"] == "PROPOSED_LOCK_ONLY_NO_NDNSIM_EXECUTION", "CONTRACT_STATUS")
    check(contract["evidence_zip_sha256"] == EXPECTED_SHA, "EVIDENCE_REFERENCE_DRIFT")
    check(contract["github_lock_only"] and contract["no_ns3_simulation"] and contract["no_official_f3"] and contract["no_1AO"] and contract["no_NSGAIII"], "GATE_POLICY_DRIFT")
    topo = contract["topology"]
    check(topo["node_count"] == 11 and topo["physical_link_count"] == 10 and topo["directed_device_count"] == 20, "TOPOLOGY_SHAPE_DRIFT")
    check(topo["path_devices_per_slot"] == 8 and topo["path_hops_forward"] == 4 and topo["path_hops_return"] == 4, "PATH_CARDINALITY_DRIFT")
    check({int(k):v for k,v in topo["path_nodes"].items()} == EXPECTED_PATH_NODES,"PATH_NODES_DRIFT")
    horizon=contract["pilot_window"]
    check(horizon["horizon_ns"] == 75000000 and horizon["queue_wait_threshold_ns"] == 5000000, "PILOT_WINDOW_DRIFT")
    check("NOT_SCIENTIFIC_F3" in horizon["status"], "PILOT_MISREPRESENTED")
    wit=contract["witness"]
    check(wit["all_topology_devices_required"]==20 and wit["path_devices_required_per_slot"]==8, "WITNESS_COVERAGE_DRIFT")
    check(wit["poll_interval_ns"] == 1000000 and "same simulator" in wit["independence_limit"], "WITNESS_INDEPENDENCE_CLAIM")
    check({"QUEUE_DROP","QUEUE_ENQUEUE","QUEUE_DEQUEUE","INITIAL","FINAL","QUEUE_SNAPSHOT"}.issubset(set(wit["required_events"])), "WITNESS_EVENT_MISSING")
    outcomes=contract["outcomes"]
    check(outcomes["possible_candidate_states"] == ["POSITIVE_CANDIDATE", "NEGATIVE_CANDIDATE", "UNKNOWN", "CENSORED"], "CANDIDATE_STATE_DRIFT")
    for k in ("requires_all_path_device_coverage","negative_requires_observation_opportunity_on_each_required_device","negative_requires_zero_drop_and_no_wait_age_violation_all_path_devices","positive_requires_observed_physical_congestion","unknown_not_mapped_to_binary","no_cf_for_unselected_face"):
        check(outcomes[k] is True, "OUTCOME_FAIL_OPEN:"+k)
    check(outcomes["target_delivery_used_for_label"] is False, "CIRCULAR_TARGET_IMPACT")
    stat=contract["stats"]
    check(stat["group_key"] == ["topology_id", "rng"], "GROUP_SPLIT_DRIFT")
    check(stat["single_class_run_ap"].startswith("UNDEFINED"), "SINGLE_CLASS_WRONG")
    check(stat["calibration_fit_split"] == "HELD_OUT_CAL_ONLY" and stat["test_after_separate_freeze"] == "NO_TEST_IN_THIS_WORKFLOW", "CALIBRATION_LEAK")
    audit=json.loads((root/"PATH_AUDIT_V0510_SUMMARY.json").read_text(encoding="utf-8"))
    check(audit["source_artifact_sha256"] == EXPECTED_SHA, "AUDIT_SOURCE_PROVENANCE")
    check(audit["checked_monitored_runs"] == 144 and audit["path_device_records"] == 1152, "AUDIT_COUNTS")
    check({int(k):v for k,v in audit["slot_runs"].items()} == {0:48,1:48,2:48}, "AUDIT_SLOT_BALANCE")
    check(audit["initial_final_mismatches"] == [] and audit["status"] == "DESCRIPTIVE_SAME_TRACE_NOT_INDEPENDENT_WITNESS", "AUDIT_MISREPRESENTED")
    expected=device_map()
    mapped=read_csv(root/"PATH_MAP_LOCKED_24.csv")
    check(len(mapped)==24,"MAP_ROW_COUNT")
    check(set((int(r["slot"]),r["direction"],int(r["hop_order"]),int(r["sender_node_id"]),int(r["device_index"]),int(r["receiver_node_id"])) for r in mapped) == set(sum(expected.values(),[])), "MAP_INCORRECT")
    check(all(r["face_id_source"] == "INITIAL_EVENT_DERIVED_NEVER_ASSUME" for r in mapped), "FACE_ID_HARDCODED")
    inventory=read_csv(root/"PATH_DEVICE_INVENTORY_V0510_1152.csv")
    check(len(inventory) == 1152, "INVENTORY_ROW_COUNT")
    grouped=collections.defaultdict(list)
    seen=set()
    for r in inventory:
        slot=int(r["slot"]);u=int(r["sender_node"]);dev=int(r["device_index"]);peer=int(r["next_node"])
        check(slot in expected,"INVALID_SLOT")
        check(r["direction"] in ("FWD","REV"),"INVALID_DIRECTION")
        check(r["trace_initial_present"] == "True" and r["trace_final_present"] == "True", "MISSING_PATH_SNAPSHOT")
        check(r["face_id"] not in ("", "None", "null"), "MISSING_ACTUAL_FACE")
        key=(r["run_dir"],r["direction"],u,dev)
        check(key not in seen,"DUPLICATE_INVENTORY_MEMBER")
        seen.add(key)
        mapped_dir={"FWD":"FORWARD","REV":"RETURN"}[r["direction"]]
        check(any((slot,mapped_dir,i,uu,dd,vv) in expected[slot] for i in range(1,5) for (uu,dd,vv) in [(u,dev,peer)]),"INVENTORY_PATH_INCORRECT")
        grouped[r["run_dir"]].append(r)
    check(len(grouped)==144, "INVENTORY_RUN_COUNT")
    slots=collections.Counter()
    for run, rr in grouped.items():
        check(len(rr)==8, "RUN_PATH_INCOMPLETE")
        check(len({r["slot"] for r in rr})==1, "RUN_SLOT_MIXED")
        check(len({r["rng"] for r in rr})==1 and len({r["family"] for r in rr})==1 and len({r["arm"] for r in rr})==1,"RUN_IDENTITY_CONFLICT")
        slots[int(rr[0]["slot"])]+=1
    check(slots=={0:48,1:48,2:48},"INVENTORY_SLOT_COUNT")
    # Contract contents are required to explicitly distinguish target outcome from future path exposure.
    science_doc=(root/"PREREG_PROTOCOL_FA.md").read_text(encoding="utf-8")
    check(all(x in science_doc for x in ["CENSORED","UNKNOWN","NEGATIVE_CANDIDATE","POSITIVE_CANDIDATE","1AO","NSGA-III"]),"SCIENTIFIC_PROTOCOL_INCOMPLETE")
    return {"status":"PASS_PATHWIDE_WITNESS_CONTRACT_LOCAL_CHECKS_ONLY","checked_runs":len(grouped),"checked_path_device_records":len(inventory),"locked_map_rows":len(mapped),"science_locks":locks,"simulations_executed":0,"f3_scientifically_validated":False}


if __name__ == "__main__":
    p=argparse.ArgumentParser()
    p.add_argument("root",type=Path)
    p.add_argument("--output",type=Path,default=None)
    a=p.parse_args()
    result=verify(a.root)
    s=json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+"\n"
    if a.output:
        a.output.parent.mkdir(parents=True,exist_ok=True)
        a.output.write_text(s,encoding="utf-8")
    print(s)
