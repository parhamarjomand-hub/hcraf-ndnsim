#!/usr/bin/env python3
"""HCRAF 1AK: retrospective selected-return-path pressure evidence, never an F3 label.

Analyze one pinned, unmodified Stage1AJ artifact (seven arms, three runs).
Three RETURN queues: producer7/dev0 -> router2/dev1, router2/dev0 -> router1/dev1,
router1/dev0 -> consumer0/dev0.  Bind class at first two receivers via NFD PIT,
and consumer via actual DATA delivery. Fails closed on missing/duplicate evidence.
Stdlib + Python 3.8 compatible. Read-only original artifact.
"""
import argparse,csv,hashlib,json,statistics,zipfile
from pathlib import Path
from collections import defaultdict,Counter

ARMS=('OFF_10M','ON_10M','OFF_5M','ON_5M_SYNC','OFF_5M_TARGET_LAG_6MS',
      'ON_5M_TARGET_LAG_6MS','ON_5M_COMPETITOR_LAG_2MS')
RUNS=(9201,9202,9203)
HOPS=((7,0,2,1,'PRODUCER_7'),(2,0,1,1,'RELAY_2'),(1,0,0,0,'EDGE_1'))
HORIZONS_NS=(250_000_000,1_000_000_000,2_000_000_000)
PAIRS=(('ON_10M','OFF_10M'),('ON_5M_SYNC','OFF_5M'),
       ('ON_5M_TARGET_LAG_6MS','OFF_5M_TARGET_LAG_6MS'),
       ('ON_5M_COMPETITOR_LAG_2MS','OFF_5M'))
STAGE='1AK.SELECTED_RETURN_PATH_REPLAY.0'
PINNED_1AJ_SOURCE_SHA='01f0c5435623b3dba0a725037f4215083395bfac43e8d20b24dc58d79560a65d'
PINNED_1AJ_RUN_ID='42233933382'

class EvidenceError(ValueError):pass

def require(ok,message):
    if not ok:raise EvidenceError(message)

def sha(blob):return hashlib.sha256(blob).hexdigest()

def jl(z,path):
    return [json.loads(x) for x in z.read(path).splitlines() if x.strip()]

def union(intervals):
    if not intervals:return 0
    seq=sorted(intervals);a,b=seq[0];total=0
    for x,y in seq[1:]:
        if x<=b:b=max(y,b)
        else:total+=b-a;a,b=x,y
    return total+(b-a)

def named_time(events,key='time_ns'):
    out={}
    for e in events:
        t=e[key];require(t not in out,'Duplicate name binding timestamp')
        require(e['name'] not in out.values(),'Duplicate bound Data name')
        out[t]=e['name']
    return out

def hop_trace(link, bindings, hop):
    """Return {Data name: group evidence including per-fragment competitor service}.
    Complete contiguous physical events and unique end-time binding required.
    """
    snd,dev,rxnode,rxdev,label=hop
    collected=defaultdict(lambda:defaultdict(list));received=defaultdict(list)
    for e in link:
        if e.get('lp_status')!='FRAGMENT':continue
        seq=e.get('lp_group_start_seq')
        if not isinstance(seq,int):continue
        if (e['node_id'],e['device_index'])==(snd,dev) and e['event_type'] in (
                 'QUEUE_ENQUEUE','QUEUE_DEQUEUE','PHY_TX_BEGIN','PHY_TX_END'):
            collected[seq][e['event_type']].append(e)
        if (e['node_id'],e['device_index'])==(rxnode,rxdev) and e['event_type']=='MAC_RX':
            received[seq].append(e)
    require(set(collected)==set(received),'Missing group between '+label+' PHY and MAC_RX')
    names=named_time(bindings)
    decoded={}; seen=set(); classified={}
    for seq,ev in collected.items():
        ids=set(range(8));r=received[seq]
        require(len(r)==8 and {x.get('lp_frag_index') for x in r}==ids,'Incomplete receiver Fragment '+label)
        end_time=max(x['time_ns'] for x in r)
        name=names.get(end_time)
        require(name is not None and name not in seen,'Unbound or duplicated '+label+' DATA/PIT')
        seen.add(name)
        require(name.startswith(('/hcraf/pilot/','/hcraf/competitor/')),'Unregistered name '+name)
        result={}
        for event in ('QUEUE_ENQUEUE','QUEUE_DEQUEUE','PHY_TX_BEGIN','PHY_TX_END'):
            q=ev[event];require(len(q)==8 and {x.get('lp_frag_index') for x in q}==ids,
                      'Missing or duplicate '+event+' '+label)
            require(len({x['packet_uid'] for x in q})==8,'Duplicate packet UID '+label)
            result[event]={x['lp_frag_index']:x for x in q}
        for i in range(8):
            q,d,b,e=(result[t][i] for t in ('QUEUE_ENQUEUE','QUEUE_DEQUEUE','PHY_TX_BEGIN','PHY_TX_END'))
            require(len({q['packet_uid'],d['packet_uid'],b['packet_uid'],e['packet_uid']})==1,
                    'Packet UID discontinuity '+label)
            require(q['time_ns']<=d['time_ns']<=b['time_ns']<=e['time_ns']<=end_time,
                    'Noncausal event ordering '+label)
            require(d.get('queue_wait_ns')==d['time_ns']-q['time_ns'],
                    'Queue wait does not match physical timestamps '+label)
        decoded[name]={'name':name,'class':'TARGET' if name.startswith('/hcraf/pilot/') else 'COMPETITOR',
                       'by_event':result,'start_ns':min(x['time_ns'] for x in ev['QUEUE_ENQUEUE']),
                       'finish_ns':max(x['time_ns'] for x in ev['PHY_TX_END']),
                       'recv_ns':end_time}
    require(len(decoded)==len(bindings),'Not all named Data mapped on '+label)
    for name,g in decoded.items():
        intervals=[]; wait_sum=0;first_wait=0
        for i in range(8):
            q=g['by_event']['QUEUE_ENQUEUE'][i];d=g['by_event']['QUEUE_DEQUEUE'][i]
            w=d['time_ns']-q['time_ns'];wait_sum+=w
            if i==0:first_wait=w
            if g['class']=='TARGET':
                for foreign in decoded.values():
                    if foreign['class']!='COMPETITOR':continue
                    for j in range(8):
                        b=foreign['by_event']['PHY_TX_BEGIN'][j]['time_ns']
                        e=foreign['by_event']['PHY_TX_END'][j]['time_ns']
                        x=max(q['time_ns'],b);y=min(d['time_ns'],e)
                        if x<y:intervals.append((i,x,y))
        # Fragment-wait exposure (sum across fragment waits; not elapsed wall-clock time).
        exposures=0;first_exposure=0
        for i in range(8):
            duration=union([(a,b) for k,a,b in intervals if k==i]);exposures+=duration
            if i==0:first_exposure=duration
        require(0<=first_exposure<=first_wait and exposures<=wait_sum,'Pressure exceeds queue wait')
        g.update({'fragment_wait_exposure_ns':exposures,
                  'first_fragment_competitor_wait_ns':first_exposure,
                  'first_fragment_total_wait_ns':first_wait,
                  'total_fragment_wait_ns':wait_sum,
                  'pressure_observed':exposures>0})
    for g in decoded.values():
        del g['by_event']
    return decoded

def check_manifest(z,archive=None):
    require(z.testzip() is None,'ZIP CRC corruption')
    m=json.loads(z.read('manifest.json'));ff=m['file_sha256']
    require(set(z.namelist())==set(ff)|{'manifest.json'},'Manifest incomplete')
    for n,h in ff.items():require(sha(z.read(n))==h,'Hash mismatch '+n)
    require(sha(z.read('source_bundle.zip'))==m['source_zip_sha256'],'Source bundle mismatch')
    require(m.get('source_zip_sha256')==PINNED_1AJ_SOURCE_SHA and
            m.get('github_run_id')==PINNED_1AJ_RUN_ID, 'Wrong approved Stage1AJ artifact/source')
    require(m['schema_version']=='1AJ.PAIRED_INTERVENTION.0' and m.get('GO_FREEZE') is False,
           'Wrong source or falsely frozen stage')
    return m,len(ff)

def evaluate(z):
    per_target=[];per_run=[];horizons=[];group_count=0
    for arm in ARMS:
        for rng in RUNS:
            prefix='stage1aj/DEV_CHAIN_B/monitored/{}/run-{}/'.format(arm,rng)
            cfg=json.loads(z.read(prefix+'scenario.json'))
            require(cfg['topology_id']=='DEV_CHAIN_B' and cfg['selected_face_slot']==0 and
                    cfg['selected_face_id']==258 and cfg['run']==rng and cfg['phase_arm']==arm and
                    cfg['no_counterfactual_unselected_face'] and cfg['actual_assignment_probability']==1.0 and
                    cfg['F3_ready'] is False and cfg['training_ready'] is False and
                    cfg['congestion'] is None and cfg['future_congestion'] is None,
                    'Wrong scenario provenance')
            ver=json.loads(z.read(prefix+'stage1aj_verification.json'))
            require(ver['status']=='COMPLETE_PHYSICAL_OBSERVATION' and
                    ver['unattributed_return_queue_drops']==0,'Incomplete original physical evidence')
            eps=jl(z,prefix+'episodes.jsonl');names={e['name']:e for e in eps}
            require(len(eps)==len(names)==(24 if arm.startswith('ON') else 12) and
                    all(e['outcome']=='SUCCESS' and e['delay_valid'] and e['face_id']==258
                        and e['tx_count']==1 and e['censor_reason'] is None for e in eps),
                    'Censored or unexpected outcome (not a zero label)')
            link=jl(z,prefix+'link_events.jsonl')
            require(all(e['link_event_seq']==i and e['schema_version']=='1W.0' for i,e in enumerate(link,1)),
                    'Link event sequence broken')
            ins={(e['node_id'],e['device_index']) for e in link if e['event_type']=='INITIAL'}
            ends={(e['node_id'],e['device_index']) for e in link if e['event_type']=='FINAL'}
            require(len(ins)==14 and ins==ends,'Incomplete topology capture')
            require(not any(e['event_type']=='QUEUE_DROP' for e in link),'Unresolved queue drop')
            binds=[]
            for fn in ('events_hop2_node2.jsonl','events.jsonl'):
                rows=[e for e in jl(z,prefix+fn) if e['event_type']=='DATA_PIT_BIND_1U']
                expect_node=2 if fn.startswith('events_hop2') else 1
                require(len(rows)==len(eps) and len(set(e['name'] for e in rows))==len(rows) and
                        all(e['node_id']==expect_node and e['face_id']==258 for e in rows),
                        'Missing PIT membership')
                binds.append(rows)
            deliveries=[]
            for fn in ('consumer_events.jsonl','competitor_events.jsonl'):
                if prefix+fn in z.namelist():
                    deliveries.extend(e for e in jl(z,prefix+fn) if e.get('event')=='DATA')
            require(len(deliveries)==len(eps),'Missing consumer delivery')
            delivery_by_name={e['name']:e for e in deliveries}
            require(set(delivery_by_name)==set(names),'Consumer delivery names differ from PIT')
            binding_by_hop=(binds[0],binds[1],deliveries)
            byhop=[]
            for hop,bi in zip(HOPS,binding_by_hop):
                h=hop_trace(link,bi,hop)
                require(set(h)==set(names),'Different Data across path')
                byhop.append(h)
            group_count+=len(eps)
            local_m3={e['name']:e for e in jl(z,prefix+'stage1aj_groups.jsonl')}
            require(set(local_m3)==set(names),'Original Node2 physical group missing')
            for i in range(12):
                name='/hcraf/pilot/{}'.format(i)
                ep=names[name];app=delivery_by_name[name]
                target_send=next(e['time_ns'] for e in jl(z,prefix+'consumer_events.jsonl')
                                 if e['event']=='SEND' and e['name']==name)
                require(target_send<=ep['start_ns']<=ep['end_ns']<=app['time_ns'],
                        'Consumer and router causal ordering broken')
                row={'arm':arm,'rng_run':rng,'name':name,
                       'decision_ns':ep['start_ns'],'terminal_ns':ep['end_ns'],
                       'router_episode_delay_ns':ep['delay_ns'],
                       'consumer_delivery_ns':app['time_ns'],
                       'consumer_delay_ns':app['time_ns']-target_send,'node2_M3':bool(local_m3[name]['M3_group_epoch_overlap']),
                       'Congestion':None,'FutureCongestion':None,'F3_ready':False,'training_ready':False,
                       'online_remote_pressure_available':False}
                flags=[]
                for h,by in zip(HOPS,byhop):
                    g=by[name];node=h[4];flags.append(g['pressure_observed'])
                    # NFD router PIT finishes when Data arrives at node 1; the
                    # third observed return queue (1->consumer) is later.
                    horizon_end=app['time_ns'] if node=='EDGE_1' else ep['end_ns']
                    require(ep['start_ns']<=g['start_ns']<=g['finish_ns']<=horizon_end,
                            'Noncausal physical group outside its receiver interval')
                    row[node+'_first_wait_ns']=g['first_fragment_total_wait_ns']
                    row[node+'_first_competitor_wait_ns']=g['first_fragment_competitor_wait_ns']
                    row[node+'_total_competitor_wait_fragment_ns']=g['fragment_wait_exposure_ns']
                    row[node+'_pressure_observed']=int(g['pressure_observed'])
                row['observed_return_path_pressure']=int(any(flags))
                row['path_evidence_status']='OBSERVED_BLOCKING' if any(flags) else 'NO_BLOCKING_OBSERVED_COMPLETE_PATH'
                row['all_three_hops_bound']=True
                per_target.append(row)
                for horizon in HORIZONS_NS:
                    # All episodes terminate before 250ms in this pilot. The completed
                    # episode is observed, but a full FACE-level future window isn't.
                    hname=str(horizon//1_000_000)
                    require(ep['start_ns']<app['time_ns'],'Nonpositive selected-path lifetime')
                    clipped=ep['start_ns']+horizon
                    horizons.append({'arm':arm,'rng_run':rng,'name':name,'horizon_ms':horizon//1_000_000,
                       'episode_terminal_before_horizon':app['time_ns']<clipped,
                       'observed_episode_pressure_before_cutoff':row['observed_return_path_pressure'] if
                              app['time_ns']<=clipped else None,
                       'future_face_window_label':None,'F3_ready':False,
                       'decision_time_online_pressure':None})
            pr=[r for r in per_target if r['arm']==arm and r['rng_run']==rng]
            per_run.append({'arm':arm,'rng_run':rng,'episodes':len(eps),'target_episodes':12,
                    'bound_return_data_groups':len(eps)*3,
                    'node7_positive':sum(r['PRODUCER_7_pressure_observed'] for r in pr),
                    'node2_positive':sum(r['RELAY_2_pressure_observed'] for r in pr),
                    'node1_positive':sum(r['EDGE_1_pressure_observed'] for r in pr),
                    'path_positive':sum(r['observed_return_path_pressure'] for r in pr),
                    'node2_M3_positive':sum(r['node2_M3'] for r in pr),
                    'evidence_complete':True})
    require(len(per_target)==252 and len(per_run)==21 and group_count==396 and len(horizons)==756,
            'Unexpected 1AJ coverage')
    return per_target,per_run,horizons

def paired_comparison(target_rows,z):
    by={(r['arm'],r['rng_run'],r['name']):r for r in target_rows}
    published={}
    raw=jl(z,'stage1aj/DEV_CHAIN_B/stage1aj_paired_episode_deltas.jsonl')
    for x in raw:
        key=(x['arm_on'],x['rng_run'],x['name'])
        require(key not in published,'Duplicate published pair')
        published[key]=x
    pairs=[]
    for on,off in PAIRS:
        for rng in RUNS:
            for i in range(12):
                name='/hcraf/pilot/{}'.format(i);a=by[on,rng,name];b=by[off,rng,name]
                pub=published[on,rng,name]
                delta=a['router_episode_delay_ns']-b['router_episode_delay_ns']
                require(pub['comparable'] and pub['episode_delay_delta_ns']==delta,
                        'Original paired delta mismatch')
                pairs.append({'arm_on':on,'arm_off':off,'rng_run':rng,'name':name,
                   'router_delay_delta_ns':delta,
                   'consumer_delay_delta_ns':a['consumer_delay_ns']-b['consumer_delay_ns'],
                   'node2_M3':a['node2_M3'],
                   'path_blocking_observed':a['observed_return_path_pressure'],
                   'node7_first_wait_delta_ns':a['PRODUCER_7_first_wait_ns']-b['PRODUCER_7_first_wait_ns'],
                   'node2_first_wait_delta_ns':a['RELAY_2_first_wait_ns']-b['RELAY_2_first_wait_ns'],
                   'node1_first_wait_delta_ns':a['EDGE_1_first_wait_ns']-b['EDGE_1_first_wait_ns'],
                   'F3_ready':False,'FutureCongestion':None})
    require(len(pairs)==144,'Missing ON/OFF pairs')
    return pairs

def csvout(path,rows):
    with open(path,'w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def run(artifact,out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(artifact) as z:
        manifest,num=check_manifest(z)
        target,runs,horizons=evaluate(z)
        pairs=paired_comparison(target,z)
    result={'stage':STAGE,'input_sha256':sha(Path(artifact).read_bytes()),
      'input_github_run_id':manifest['github_run_id'],'input_commit':manifest['github_commit'],
      'manifest_sha256_files_verified':num,'audit_mode':'READ_ONLY_OFFLINE_REAL_ARTIFACT',
      'monitored_runs':len(runs),'original_target_episodes':len(target),
      'full_path_return_hop_groups':396*3,'evidence_joined_return_hops':3,
      'paired_episode_comparisons':len(pairs),'horizon_diagnostic_rows':len(horizons),
      'path_observed_pressure_groups':sum(x['observed_return_path_pressure'] for x in target),
      'node2_M3_positive_groups':sum(x['node2_M3'] for x in target),
      'node7_pressure_groups':sum(x['PRODUCER_7_pressure_observed'] for x in target),
      'node2_pressure_groups':sum(x['RELAY_2_pressure_observed'] for x in target),
      'node1_pressure_groups':sum(x['EDGE_1_pressure_observed'] for x in target),
      'early_terminal_horizons':sum(x['episode_terminal_before_horizon'] for x in horizons),
      'decision_feature_online_available':False,
      'status':'PASS_OFFLINE_SELECTED_PATH_RETURN_EVIDENCE_ONLY',
      'F3_ready':False,'training_ready':False,'GO_FREEZE':False,
      'Congestion':None,'FutureCongestion':None,
      'scientific_limit':'Only DEV_CHAIN_B slot0 no-drop; not an online path state, final F3, or a multi-face dataset'}
    for name,rows in [('path_target_evidence.csv',target),('run_summary.csv',runs),
                      ('paired_deltas.csv',pairs),('horizon_censoring.csv',horizons)]:
        csvout(out/name,rows)
    (out/'audit_summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
    return result

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('artifact');ap.add_argument('--out',required=True)
    args=ap.parse_args();print(json.dumps(run(args.artifact,args.out),ensure_ascii=False,indent=2))
