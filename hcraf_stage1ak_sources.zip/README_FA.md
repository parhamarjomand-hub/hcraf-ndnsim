# HCRAF — Stage 1AK v0.35.0 (بازپخش آفلاین مسیر برگشت منتخب)

این مرحله ادامه مستقیم 1AJ است، نه بازاجرای مراحل قبلی و نه ساخت دیتاست.

## فایل‌ها

- `scripts/path_audit_1ak.py`: پردازش خواندنی ZIP اصلی 1AJ، کنترل ۹۷۵ هش، ردیابی فیزیکی سه لینک و تحلیل سانسور افق زمانی.
- `tests/test_path_audit_1ak.py`: آزمون‌های منفی و آزمون بازپخش شواهد واقعی.
- `output/`: چهار جدول CSV و خلاصه JSON که فقط از Artifact واقعی حاصل شده‌اند.
- `docs/SCIENTIFIC_REPORT_FA.md`: گزارش کامل، نتیجه علمی و محدودیت‌ها.
- `docs/NEXT_1AL_PREREG_FA.md`: طرح گام بعد؛ اجرای 1AL انجام نشده است.

## اجرای محلی و آفلاین

این برنامه فقط Python استاندارد نیاز دارد، بدون ns-3، GPU یا شبکه. Artifact واقعی 1AJ را بدون استخراج به برنامه بدهید:

```bash
python scripts/path_audit_1ak.py hcraf_stage1aj_reference.zip --out reproduced
```

برای آزمون‌ها:

```bash
HCRAF_STAGE1AJ_REFERENCE=hcraf_stage1aj_reference.zip python -m unittest discover -s tests -p 'test_*.py' -v
```

در ویندوز، متغیر محیطی را در CMD با `set HCRAF_STAGE1AJ_REFERENCE=hcraf_stage1aj_reference.zip` تنظیم کنید. استفاده از GitHub Actions نیز در فایل Workflow مجزا آماده شده است؛ برای تولید این گزارش به اجرای دوباره ndnSIM نیاز نیست.

**مرز علمی:** ۲۵۲ Episode هدف، ۷۲ شاهد فشار در حداقل یک صف برگشت، ۵۴ شاهد M3 محلی گره۲، ۷۵۶ ردیف پنجره صرفاً تشخیصی. هیچ برچسب F3 تولید نشده و تمام سنجه‌های آنلاین مسیر null هستند.
