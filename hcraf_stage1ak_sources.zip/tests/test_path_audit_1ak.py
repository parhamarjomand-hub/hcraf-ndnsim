"""Negative physical-evidence checks. No fixtures are used as research observations."""
import copy,os,sys,unittest,zipfile,json,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from path_audit_1ak import hop_trace,union,check_manifest,EvidenceError,HOPS,run

class TestPhysicalEvidence(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  path=os.environ.get('HCRAF_STAGE1AJ_REFERENCE')
  if not path:
   raise unittest.SkipTest('Original Stage1AJ artifact not mounted')
  cls.z=zipfile.ZipFile(path)
  base='stage1aj/DEV_CHAIN_B/monitored/ON_10M/run-9201/'
  cls.link=[json.loads(x) for x in cls.z.read(base+'link_events.jsonl').splitlines() if x]
  cls.pit=[json.loads(x) for x in cls.z.read(base+'events_hop2_node2.jsonl').splitlines()
           if json.loads(x).get('event_type')=='DATA_PIT_BIND_1U']
 @classmethod
 def tearDownClass(cls):
  if hasattr(cls,'z'):cls.z.close()
 def test_real_join_hop7(self):
  self.assertEqual(len(hop_trace(self.link,self.pit,HOPS[0])),24)
 def test_real_join_hop7_pressure(self):
  r=hop_trace(self.link,self.pit,HOPS[0])
  self.assertEqual(sum(x['pressure_observed'] for x in r.values() if x['class']=='TARGET'),5)
 def test_missing_mac_rx_rejected(self):
  l=copy.deepcopy(self.link)
  i=next(i for i,e in enumerate(l) if e['node_id']==2 and e['device_index']==1 and
     e['event_type']=='MAC_RX' and e.get('lp_status')=='FRAGMENT')
  l.pop(i)
  with self.assertRaises(EvidenceError):hop_trace(l,self.pit,HOPS[0])
 def test_missing_phy_tx_end_rejected(self):
  l=copy.deepcopy(self.link)
  i=next(i for i,e in enumerate(l) if e['node_id']==7 and e['device_index']==0 and
     e['event_type']=='PHY_TX_END' and e.get('lp_status')=='FRAGMENT')
  l.pop(i)
  with self.assertRaises(EvidenceError):hop_trace(l,self.pit,HOPS[0])
 def test_fake_queue_wait_rejected(self):
  l=copy.deepcopy(self.link)
  i=next(i for i,e in enumerate(l) if e['node_id']==7 and e['device_index']==0 and
     e['event_type']=='QUEUE_DEQUEUE' and e.get('lp_status')=='FRAGMENT')
  l[i]['queue_wait_ns']+=1
  with self.assertRaises(EvidenceError):hop_trace(l,self.pit,HOPS[0])
 def test_fake_pit_time_rejected(self):
  p=copy.deepcopy(self.pit);p[0]['time_ns']+=1
  with self.assertRaises(EvidenceError):hop_trace(self.link,p,HOPS[0])
 def test_duplicate_pit_name_rejected(self):
  p=copy.deepcopy(self.pit);p[0]['name']=p[1]['name']
  with self.assertRaises(EvidenceError):hop_trace(self.link,p,HOPS[0])
 def test_unregistered_traffic_name_rejected(self):
  p=copy.deepcopy(self.pit);p[0]['name']='/made-up/class'
  with self.assertRaises(EvidenceError):hop_trace(self.link,p,HOPS[0])
 def test_duplicate_fragment_index_rejected(self):
  l=copy.deepcopy(self.link)
  i=next(i for i,e in enumerate(l) if e['node_id']==7 and e['device_index']==0 and
     e['event_type']=='PHY_TX_BEGIN' and e.get('lp_status')=='FRAGMENT' and e.get('lp_frag_index')==3)
  l[i]['lp_frag_index']=2
  with self.assertRaises(EvidenceError):hop_trace(l,self.pit,HOPS[0])
 def test_manifest_sha(self):
  m,n=check_manifest(self.z)
  self.assertEqual(n,975)
  self.assertEqual(m['github_run_id'],'42233933382')
 def test_union_overlap(self):
  self.assertEqual(union([(10,30),(20,40),(45,50)]),35)
 def test_union_empty(self):
  self.assertEqual(union([]),0)
 def test_union_contiguous(self):
  self.assertEqual(union([(0,10),(10,20)]),20)
 def test_full_replay_has_null_final_label(self):
  with tempfile.TemporaryDirectory() as d:
   result=run(os.environ['HCRAF_STAGE1AJ_REFERENCE'],d)
   self.assertEqual(result['path_observed_pressure_groups'],72)
   self.assertEqual(result['node2_M3_positive_groups'],54)
   self.assertIsNone(result['FutureCongestion'])
   self.assertFalse(result['F3_ready'])
   h=Path(d)/'horizon_censoring.csv'
   self.assertTrue(h.is_file());self.assertEqual(len(h.read_text().splitlines()),757)

if __name__=='__main__':unittest.main()
