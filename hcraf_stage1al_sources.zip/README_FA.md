# HCRAF — مرحله 1AL v0.36.0

**نوع خروجی:** ممیزی آفلاین توسعه‌ای؛ هیچ شبیه‌سازی جدید ndnSIM، هیچ دیتاست آموزشی و هیچ Frozen FutureCongestion تولید نشده است.

## فایل‌های ورودی GitHub (چهار فایل)

| نام فایل | مسیر نهایی مخزن `hcraf-ndnsim` |
|---|---|
| `hcraf_stage1al_sources.zip` | `hcraf_stage1al_sources.zip` در ریشه مخزن |
| `hcraf_stage1ah_A_reference.zip` | `hcraf_stage1ah_A_reference.zip` در ریشه مخزن |
| `hcraf_stage1ah_B_reference.zip` | `hcraf_stage1ah_B_reference.zip` در ریشه مخزن |
| `hcraf-stage1al.yml` | `.github/workflows/hcraf-stage1al.yml` |

دو فایل مرجع ZIP همان Artifactهای تأییدشده 1AH run-3 هستند. منابع را در GitHub استخراج نکنید؛ Workflow هش را بررسی و خودش در پوشه موقت استخراج می‌کند. Workflowهای قبلی حذف یا جایگزین نشوند.

## اجرای مستقل روی Windows (بدون GitHub و ndnSIM)

پس از استخراج `hcraf_stage1al_sources.zip` در یک پوشه، از Python 3.8+ با این فرمان استفاده کنید:

```bash
python scripts/crossface_audit_1al.py hcraf_stage1ah_A_reference.zip hcraf_stage1ah_B_reference.zip --out reproduced
python -m unittest discover -s tests -p 'test_*.py' -v
```

خروجی‌های `output/` و `reproduced/` باید بایت‌به‌بایت یکسان باشند. تمام Artifactهای اصلی فقط خوانده می‌شوند.

## اجرای GitHub

Workflow جدید: **`HCRAF - Stage 1AL Cross-Face and UNKNOWN Evidence Replay`**، اجرای دستی از **Actions → Run workflow**. Artifact خروجی با پیشوند `hcraf-stage1al-crossface-audit-` را کامل ارسال کنید، حتی اگر آزمونی شکست بخورد. گزارش آن فقط PASS آفلاین است، نه آمادگی F3 و دیتاست.
