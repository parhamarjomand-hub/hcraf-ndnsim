#!/usr/bin/env python3
"""HCRAF 1AL: Strict retrospective cross-Face, cross-topology and censoring audit.

Inputs are the ORIGINAL TWO run-3 Stage1AH GitHub artifacts, *not* simulated data.
Only complete physical path observations may report NO_OBSERVED_BLOCKING.
All DROP-regime TARGET outcomes remain UNKNOWN_FOR_F3, including SUCCESS: the
traffic-class coverage of dropped/partial groups is incomplete.  Neither past
queue evidence nor other nodes are available as online forwarding features.
"""
from __future__ import print_function
import argparse,csv,hashlib,json,sys,zipfile
from collections import Counter,defaultdict
from pathlib import Path
from path_audit_1ak import hop_trace, EvidenceError, require
STAGE='1AL.CROSS_FACE_SCOPE_AND_UNKNOWN_REPLAY.0'
REGIMES=('LP_SELF_ONLY','LP_INDEPENDENT_COMPETITOR_NO_DROP',
         'LP_INDEPENDENT_COMPETITOR_DROP','UNFRAGMENTED_MATCHED_BYTES')
ALL_FACES=(258,259,260);ALL_TOPO=('DEV_CHAIN_A','DEV_CHAIN_B');RUNS=(9101,9102,9103)
TYPES={'LP_SELF_ONLY':'FRAGMENT','LP_INDEPENDENT_COMPETITOR_NO_DROP':'FRAGMENT',
       'LP_INDEPENDENT_COMPETITOR_DROP':'FRAGMENT','UNFRAGMENTED_MATCHED_BYTES':'SINGLE_LP'}

def sha(b):return hashlib.sha256(b).hexdigest()
def lines(z,p):return [json.loads(q) for q in z.read(p).splitlines() if q.strip()]
def expected_artifact_name(t):return 'hcraf-stage1ah-'+t.replace('DEV_CHAIN_','DEV_CHAIN_')+'-3-1.zip'
def check_archive(path):
    path=Path(path)
    with zipfile.ZipFile(path) as z:
        require(z.testzip() is None,'CRC failed '+str(path))
        names=z.namelist();require(len(names)==len(set(names)),'Duplicate ZIP entries')
        m=json.loads(z.read('manifest.json'));f=m['file_sha256']
        require(set(names)==set(f)|{'manifest.json'},'Unhashed archive entries')
        for n,h in f.items():require(sha(z.read(n))==h,'File SHA mismatch '+n)
        require(sha(z.read('source_bundle.zip'))==m['source_zip_sha256'],'Wrong pinned source')
        require(m['schema_version']=='1AH.GROUP_AWARE.0' and
                m['topology_id'] in ALL_TOPO and m['github_run_id']=='42189069374',
                'Unexpected run-3 1AH provenance')
        require(m['F3_ready'] is False and m['training_ready'] is False and
                m['Congestion'] is None and m['FutureCongestion'] is None,'Unfrozen source status changed')
        return {'artifact':'hcraf-stage1ah-'+m['topology_id']+'-3-1.zip','archive_sha256':sha(path.read_bytes()),
            'topology':m['topology_id'],'github_run_id':m['github_run_id'],
            'source_sha256':m['source_zip_sha256'],'sha256_files_verified':len(f)}

def physical_named_hop(link,snd,dev,rxnode,rxdev,kind, names):
    """Strict single-LP Data path with exact PHY/MAC reception, keyed by Data name.
       Does not infer absent competitor classes. Used in unfragmented self control.
    """
    ret={};events=('QUEUE_ENQUEUE','QUEUE_DEQUEUE','PHY_TX_BEGIN','PHY_TX_END')
    for typ in events+('MAC_RX',):
        at=(rxnode,rxdev) if typ=='MAC_RX' else (snd,dev)
        sub=[e for e in link if e['event_type']==typ and e.get('lp_status')=='SINGLE_LP' and
             e.get('ndn_packet_type')=='DATA' and (e['node_id'],e['device_index'])==at]
        keyed={}
        for x in sub:
            n=x['ndn_name'];require(n in names and n not in keyed,'Unknown or duplicate single-LP Data '+kind)
            keyed[n]=x
        require(set(keyed)==set(names),'Incomplete single-LP Data '+kind+' '+typ)
        ret[typ]=keyed
    out={}
    for n in names:
        chain=[ret[k][n] for k in events+('MAC_RX',)]
        uid={x['packet_uid'] for x in chain};require(len(uid)==1,'UID changed across same-link Data '+kind)
        times=[x['time_ns'] for x in chain];require(times==sorted(times),'Noncausal Data '+kind)
        require(ret['QUEUE_DEQUEUE'][n]['queue_wait_ns']==times[1]-times[0], 'Wait mismatch')
        out[n]={'pressure_observed':False,'first_fragment_total_wait_ns':times[1]-times[0],
                'start_ns':times[0],'recv_ns':times[-1]}
    return out

def interest_path(link,names,path,face):
    """Strict real Interest PHY and MAC evidence for all 3 FORWARD hops.
       Multiple nonces or retransmissions are not silently deduplicated.
    """
    relay=path[-2];producer=path[-1]
    hops=((0,0,1,0),(1,face-257,relay,0),(relay,1,producer,0))
    for snd,dev,rnode,rdev in hops:
        ev={}
        for typ in ('PHY_TX_BEGIN','PHY_TX_END','MAC_RX'):
            loc=(rnode,rdev) if typ=='MAC_RX' else (snd,dev)
            rows=[r for r in link if r['event_type']==typ and r.get('lp_status')=='SINGLE_LP' and
                  r.get('ndn_packet_type')=='INTEREST' and (r['node_id'],r['device_index'])==loc]
            keyed={}
            for r in rows:
                key=(r['ndn_name'],r.get('ndn_nonce'))
                require(key not in keyed,'Duplicate Interest PHY event '+typ)
                keyed[key]=r
            require(set(keyed)==names,'Missing/replaced forward Interest '+typ+' '+str((snd,dev)))
            ev[typ]=keyed
        for name in names:
            tx,te,rx=(ev[k][name] for k in ('PHY_TX_BEGIN','PHY_TX_END','MAC_RX'))
            require(tx['packet_uid']==te['packet_uid']==rx['packet_uid'] and
                    tx['time_ns']<=te['time_ns']<=rx['time_ns'],'Broken Interest UID/time chain')
            if snd==1:require(tx['face_id']==face,'Selected Face not used for interest')
    return len(names)

def complete_return_for_clean(z,prefix,cfg,link,episodes,regime):
    p=cfg['path_nodes'];producer=p[-1];relay=p[-2];dev=cfg['selected_face_slot']+1
    hops=((producer,0,relay,1,'PRODUCER'),(relay,0,1,dev,'RELAY'),(1,0,0,0,'EDGE'))
    allnames=set(episodes)
    # Confirm PIT binding at each NFD router; receiver node is not inferred from absent data.
    relay_b=[x for x in lines(z,prefix+'events_hop2_node'+str(relay)+'.jsonl')
             if x['event_type']=='DATA_PIT_BIND_1U']
    decision_b=[x for x in lines(z,prefix+'events.jsonl')
             if x['event_type']=='DATA_PIT_BIND_1U']
    deliveries=[]
    for stream in ('consumer_events.jsonl','competitor_events.jsonl'):
        if prefix+stream in z.namelist():
            deliveries.extend(x for x in lines(z,prefix+stream) if x.get('event')=='DATA')
    require(set(x['name'] for x in relay_b)==allnames and
            set(x['name'] for x in decision_b)==allnames and
            set(x['name'] for x in deliveries)==allnames and
            len(relay_b)==len(decision_b)==len(deliveries)==len(allnames),
            'Missing real NFD/PIT or actual app Data delivery')
    bindings=(relay_b,decision_b,deliveries)
    if regime=='UNFRAGMENTED_MATCHED_BYTES':
        paths=[physical_named_hop(link,*hop[:4],hop[4],allnames) for hop in hops]
    else:
        paths=[hop_trace(link,bind,hop) for hop,bind in zip(hops,bindings)]
    require(all(set(h)==allnames for h in paths),'Selected return path is not complete')
    status={}
    for name in allnames:
        positive=any(x[name]['pressure_observed'] for x in paths)
        status[name]={'physical_path_complete':True,'path_observed_competitor_blocking':int(positive),
              'producer_pressure':int(paths[0][name]['pressure_observed']),
              'relay_pressure':int(paths[1][name]['pressure_observed']),
              'edge_pressure':int(paths[2][name]['pressure_observed'])}
    return status

def evaluate_run(z,topo,slot,regime,rng):
    prefix=f'stage1ah/{topo}/monitored/slot-{slot}/{regime}/run-{rng}/'
    cfg=json.loads(z.read(prefix+'scenario.json'));v=json.loads(z.read(prefix+'stage1ah_verification.json'))
    face=258+slot
    require(cfg['topology_id']==topo and cfg['selected_face_id']==face and
            cfg['selected_face_slot']==slot and cfg['mode']==regime and
            cfg['run']==rng and cfg['actual_assignment_probability']==1.0 and
            cfg['path_nodes'][:2]==[0,1] and cfg['path_nodes'][-2] in (2,3,4) and
            cfg['path_nodes'][-1] in (5,6,7) and cfg['selected_producer_node_id']==cfg['path_nodes'][-1] and
            cfg['selected_relay_node_id']==cfg['path_nodes'][-2] and
            cfg['instrument_enabled'] is True,'Wrong fixed-Face or topology provenance')
    require(cfg['F3_ready'] is False and cfg['training_ready'] is False and
            cfg['congestion'] is None and cfg['future_congestion'] is None and
            v['F3_ready'] is False and v['GO_FREEZE'] is False and v['training_ready'] is False,
            'Unauthorized learning or labeling')
    link=lines(z,prefix+'link_events.jsonl')
    require(all(e['link_event_seq']==i and e['schema_version']=='1W.0'
             for i,e in enumerate(link,1)),'Broken physical monitor sequence')
    init={(e['node_id'],e['device_index']) for e in link if e['event_type']=='INITIAL'}
    final={(e['node_id'],e['device_index']) for e in link if e['event_type']=='FINAL'}
    require(len(init)==14 and init==final and v['monitored_all_14_directions'] is True,
            'Missing physical capture direction')
    eps=lines(z,prefix+'episodes.jsonl');names={e['name']:e for e in eps}
    require(len(eps)==len(names)==v['target_episodes']+v['competitor_episodes'] and
            all(e['face_id']==face and e['outcome'] in ('SUCCESS','TIMEOUT','NACK','CANCELLED') for e in eps),
            'Corrupt PIT×Face episode ledger')
    planned={(e['name'],int(e['nonce'])) for e in lines(z,prefix+'consumer_events.jsonl')
             if e.get('event')=='SEND'}
    if prefix+'competitor_events.jsonl' in z.namelist():
        planned.update((e['name'],int(e['nonce'])) for e in lines(z,prefix+'competitor_events.jsonl')
                       if e.get('event')=='SEND')
    require(len(planned)==len(names) and {k for k,vv in planned}==set(names),'Input streams disagree with Episode ledger')
    interest_count=interest_path(link,planned,cfg['path_nodes'],face)
    sent=[e for e in lines(z,prefix+'events.jsonl') if e['event_type']=='TX_INTEREST']
    require(len(sent)==len(names) and {(e['name'],e['nonce']) for e in sent}==planned and
            all(e['face_id']==face for e in sent),'NFD did not actually use selected Face')
    hasdrop=regime=='LP_INDEPENDENT_COMPETITOR_DROP'
    dropped=sum(1 for e in link if e['event_type']=='QUEUE_DROP' and e.get('lp_status')=='FRAGMENT')
    require((dropped>0)==hasdrop,'DROP/NO-DROP observation inconsistent')
    selected_relay_dropped=sum(1 for e in link if e['event_type']=='QUEUE_DROP' and
            e.get('lp_status')=='FRAGMENT' and (e['node_id'],e['device_index'])==(cfg['selected_relay_node_id'],0))
    require(v['observed_return_fragment_queue_drops']==selected_relay_dropped,
            'Stage 1AH selected-relay drop verifier count mismatch')
    successes=sum(e['outcome']=='SUCCESS' for e in eps)
    require(successes==v['outcomes'].get('SUCCESS',0),'Outcome summary mismatch')
    clean_status=complete_return_for_clean(z,prefix,cfg,link,names,regime) if not hasdrop else {}
    rows=[]
    for name,ep in sorted(names.items()):
        is_target=name.startswith('/hcraf/pilot/')
        require(is_target or name.startswith('/hcraf/competitor/'),'Unregistered episode prefix')
        known=clean_status.get(name)
        state=('OBSERVED_COMPETITOR_BLOCKING' if known['path_observed_competitor_blocking'] else
               'NO_OBSERVED_COMPETITOR_BLOCKING_COMPLETE_PATH') if known else 'UNKNOWN_INCOMPLETE_CLASS_OR_PATH'
        rows.append({'topology':topo,'face_slot':slot,'face_id':face,'producer_node':cfg['path_nodes'][-1],
          'relay_node':cfg['path_nodes'][-2],'regime':regime,'rng_run':rng,'name':name,
          'traffic_class':'TARGET' if is_target else 'INDEPENDENT_COMPETITOR',
          'outcome':ep['outcome'],'evidence_state':state,
          'return_path_complete':bool(known),
          'observed_path_competitor_blocking':known['path_observed_competitor_blocking'] if known else None,
          'producer_pressure':known['producer_pressure'] if known else None,
          'relay_pressure':known['relay_pressure'] if known else None,
          'edge_pressure':known['edge_pressure'] if known else None,
          'future_congestion':None,'congestion':None,'F3_ready':False,'training_ready':False})
    target=[x for x in rows if x['traffic_class']=='TARGET']
    run_summary={'topology':topo,'face_slot':slot,'face_id':face,'producer_node':cfg['path_nodes'][-1],
          'relay_node':cfg['path_nodes'][-2],'regime':regime,'rng_run':rng,
          'observed_interest_path_hops':3,'forward_interest_packets_bound':interest_count,
          'target_episodes':len(target),'competitor_episodes':len(rows)-len(target),
          'success_episodes':successes,'timeout_episodes':sum(x['outcome']=='TIMEOUT' for x in rows),
          'return_path_target_groups_complete':sum(x['return_path_complete'] for x in target),
          'observed_target_blocking':sum(x['observed_path_competitor_blocking']==1 for x in target),
          'target_unknown':sum(x['return_path_complete'] is False for x in target),
          'physical_fragment_queue_drops':dropped,
          'selected_relay_fragment_queue_drops':selected_relay_dropped,
          'unassignable_fragment_drop_events':v['unassignable_fragment_drop_events'],
          'incomplete_return_fragment_groups':v['incomplete_return_fragment_groups'],
          'sender_fragment_groups_without_complete_rx':v['sender_fragment_groups_without_complete_rx'],
          'original_verifier_status':v['status'],
          'not_a_final_future_congestion_label':True}
    return rows,run_summary

def emit_csv(path,rows):
    with path.open('w',encoding='utf8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def run(a,b,out):
    out=Path(out);out.mkdir(exist_ok=True,parents=True)
    original=[check_archive(a),check_archive(b)]
    require({x['topology'] for x in original}==set(ALL_TOPO),'Missing one topology')
    all_rows=[];run_rows=[]
    for path in (a,b):
        with zipfile.ZipFile(path) as z:
            topo=json.loads(z.read('manifest.json'))['topology_id']
            for slot in range(3):
                for regime in REGIMES:
                    for rng in RUNS:
                        r,s=evaluate_run(z,topo,slot,regime,rng)
                        all_rows.extend(r);run_rows.append(s)
    require(len(run_rows)==72 and len(all_rows)==2160,'Unexpected study coverage')
    tg=[r for r in all_rows if r['traffic_class']=='TARGET']
    require(len(tg)==1080,'Unexpected TARGET Episode count')
    total_unknown=sum(r['observed_path_competitor_blocking'] is None for r in tg)
    # No final label should ever emerge from this audit.
    require(total_unknown==432,'DROP target UNKNOWN incorrectly converted to no-congestion')
    clean=[r for r in tg if r['regime']!='LP_INDEPENDENT_COMPETITOR_DROP']
    require(len(clean)==648 and all(r['return_path_complete'] for r in clean),
            'Lost physical path evidence from no-drop controls')
    coverage=[]
    for t in ALL_TOPO:
        for face in ALL_FACES:
            for regime in REGIMES:
                subset=[r for r in run_rows if (r['topology'],r['face_id'],r['regime'])==(t,face,regime)]
                require(len(subset)==3,'Missing crossface run block')
                coverage.append({'topology':t,'face_id':face,'regime':regime,'runs':len(subset),
                    'forward_interest_packets_bound':sum(r['forward_interest_packets_bound'] for r in subset),
                    'target_episodes':sum(r['target_episodes'] for r in subset),
                    'target_path_complete':sum(r['return_path_target_groups_complete'] for r in subset),
                    'target_path_positive':sum(r['observed_target_blocking'] for r in subset),
                    'target_unknown':sum(r['target_unknown'] for r in subset),
                    'raw_fragment_queue_drops':sum(r['physical_fragment_queue_drops'] for r in subset),
                    'original_1AH_incomplete_runs':sum(r['original_verifier_status']!='PASS_TARGET_EVENT_ONLY' for r in subset)})
    # Never change prior source results: 3 B/slot0 NO_DROP incomplete are retained.
    require(sum(x['original_1AH_incomplete_runs'] for x in coverage)==3,
            'Original incomplete 1AH runs have been re-labeled as PASS')
    summary={'stage':STAGE,'status':'PASS_EXISTING_CROSS_FACE_AND_UNKNOWN_EVIDENCE_ONLY',
        'sources':original,'monitored_runs':len(run_rows),'unique_topologies':2,'selected_faces':[258,259,260],
        'forward_paths_verified':72,'forward_interest_hops_per_run':3,
        'target_episodes':len(tg),'all_episodes':len(all_rows),
        'complete_clean_target_paths':len(clean),'target_unknown_drop':total_unknown,
        'path_pressure_positive_clean_targets':sum(x['observed_path_competitor_blocking']==1 for x in clean),
        'original_1AH_incomplete_runs_retained':3,
        'no_fresh_ndnsim_runs':True,'read_only_retrospective':True,
        'online_telemetry_available':False,'full_route_drop_label_claimed':False,
        'held_out_generalization_claimed':False,'GO_FREEZE':False,'F3_ready':False,
        'training_ready':False,'Congestion':None,'FutureCongestion':None}
    emit_csv(out/'episode_scope_2160.csv',all_rows)
    emit_csv(out/'run_scope_72.csv',run_rows)
    emit_csv(out/'coverage_by_topology_face_regime.csv',coverage)
    (out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')
    return summary

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('reference_a');p.add_argument('reference_b');p.add_argument('--out',required=True)
    args=p.parse_args();print(json.dumps(run(args.reference_a,args.reference_b,args.out),ensure_ascii=False,sort_keys=True))
