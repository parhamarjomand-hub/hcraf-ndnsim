"""Stage1AL v0.36.0 small deterministic contract and tamper tests; stdlib only.

These fixtures are NOT scientific simulation evidence.
"""
import csv,io,json,sys,unittest,zipfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import crossface_audit_1al as a
from path_audit_1ak import EvidenceError

class FakeZip:
    def __init__(self,data):self.data=data
    def read(self,name):return self.data[name]
    def namelist(self):return list(self.data)

def event(typ,t,uid=3,name='/hcraf/pilot/0',nonce=1001,node=0,dev=0,ptype='INTEREST'):
    return {'event_type':typ,'time_ns':t,'packet_uid':uid,'ndn_name':name,'ndn_nonce':nonce,
        'node_id':node,'device_index':dev,'ndn_packet_type':ptype,'lp_status':'SINGLE_LP',
        'face_id':259 if node==1 else 257,'queue_wait_ns':10 if typ=='QUEUE_DEQUEUE' else None}

def forward_fixture():
    name='/hcraf/pilot/0';chain=[];hops=[(0,0,1,0),(1,2,3,0),(3,1,6,0)]
    for uid,(sn,sd,rn,rd) in enumerate(hops,1):
        for typ,tt in [('PHY_TX_BEGIN',10*uid),('PHY_TX_END',10*uid+1)]:
            chain.append(event(typ,tt,uid=uid,node=sn,dev=sd))
        chain.append(event('MAC_RX',10*uid+2,uid=uid,node=rn,dev=rd))
    return chain,{(name,1001)},[0,1,3,6],259

class ForwardDirection(unittest.TestCase):
    def test_all_three_forward_interest_hops(self):
        x,k,p,face=forward_fixture();self.assertEqual(a.interest_path(x,k,p,face),1)
    def test_missing_phy_rejected(self):
        x,k,p,face=forward_fixture();x.pop(1)
        with self.assertRaises(EvidenceError):a.interest_path(x,k,p,face)
    def test_wrong_face_rejected(self):
        x,k,p,face=forward_fixture();
        for r in x:
            if r['node_id']==1:r['face_id']=258
        with self.assertRaises(EvidenceError):a.interest_path(x,k,p,face)
    def test_changed_nonce_rejected(self):
        x,k,p,face=forward_fixture();x[0]['ndn_nonce']=1010
        with self.assertRaises(EvidenceError):a.interest_path(x,k,p,face)
    def test_duplicate_interest_rejected(self):
        x,k,p,face=forward_fixture();x.append(dict(x[0]));
        with self.assertRaises(EvidenceError):a.interest_path(x,k,p,face)
    def test_broken_uid_rejected(self):
        x,k,p,face=forward_fixture();x[1]['packet_uid']+=9
        with self.assertRaises(EvidenceError):a.interest_path(x,k,p,face)
    def test_causality_rejected(self):
        x,k,p,face=forward_fixture();x[1]['time_ns']=-1
        with self.assertRaises(EvidenceError):a.interest_path(x,k,p,face)

class ReturnUnfragmented(unittest.TestCase):
    def make(self):
        name='/hcraf/pilot/0';x=[]
        for typ,t in [('QUEUE_ENQUEUE',0),('QUEUE_DEQUEUE',10),('PHY_TX_BEGIN',11),
                        ('PHY_TX_END',16)]:
            x.append(event(typ,t,ptype='DATA',node=6,dev=0))
        x.append(event('MAC_RX',20,ptype='DATA',node=3,dev=1))
        return x,{name}
    def test_complete_data(self):
        x,n=self.make();d=a.physical_named_hop(x,6,0,3,1,'X',n)
        self.assertEqual(d['/hcraf/pilot/0']['first_fragment_total_wait_ns'],10)
    def test_missing_mac_rejected(self):
        x,n=self.make();x.pop()
        with self.assertRaises(EvidenceError):a.physical_named_hop(x,6,0,3,1,'X',n)
    def test_wrong_data_name_rejected(self):
        x,n=self.make();x[0]['ndn_name']='/hcraf/other/0'
        with self.assertRaises(EvidenceError):a.physical_named_hop(x,6,0,3,1,'X',n)
    def test_wrong_queue_wait_rejected(self):
        x,n=self.make();x[1]['queue_wait_ns']=11
        with self.assertRaises(EvidenceError):a.physical_named_hop(x,6,0,3,1,'X',n)
    def test_wrong_data_uid_rejected(self):
        x,n=self.make();x[-1]['packet_uid']+=1
        with self.assertRaises(EvidenceError):a.physical_named_hop(x,6,0,3,1,'X',n)
    def test_noncausal_sequence_rejected(self):
        x,n=self.make();x[2]['time_ns']=9
        with self.assertRaises(EvidenceError):a.physical_named_hop(x,6,0,3,1,'X',n)
    def test_duplicate_data_rejected(self):
        x,n=self.make();x.append(dict(x[0]))
        with self.assertRaises(EvidenceError):a.physical_named_hop(x,6,0,3,1,'X',n)

class StatusContracts(unittest.TestCase):
    def test_regimes_are_exhaustive(self):self.assertEqual(len(a.REGIMES),4)
    def test_faces_exact(self):self.assertEqual(a.ALL_FACES,(258,259,260))
    def test_topology_blocks_exact(self):self.assertEqual(a.ALL_TOPO,('DEV_CHAIN_A','DEV_CHAIN_B'))
    def test_drop_not_in_clean_list(self):self.assertEqual(a.REGIMES[2],'LP_INDEPENDENT_COMPETITOR_DROP')
    def test_hash_not_equivalent(self):self.assertNotEqual(a.sha(b'a'),a.sha(b'b'))
    def test_output_contract_has_no_numeric_missing_value(self):
        data=a.run if callable(a.run) else None
        self.assertIsNotNone(data)

if __name__=='__main__':unittest.main()
