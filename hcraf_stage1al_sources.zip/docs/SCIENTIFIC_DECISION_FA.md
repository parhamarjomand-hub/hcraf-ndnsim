# تصمیم پژوهشی 1AL

**حکم محدود:** `PASS_EXISTING_CROSS_FACE_AND_UNKNOWN_EVIDENCE_ONLY`.

**پذیرفته‌شده:** بررسی حقیقی سه Face و دو توپولوژی و دو جهت رفت/برگشت، اعتبار ثبت PIT/Physical Link در ۶۴۸ گروه هدف بدون افت، حفظ شواهد ۴۳۲ Episode هدف افت‌دار در رده UNKNOWN، تفکیک تعداد Drop محلی (۶۶۹۹) از کل Drop مسیر (۸۰۴۵).

**پذیرفته‌نشده:** ثبات عملیاتی استراتژی HCRAF روی Faceهای مختلف، اعتبار مدل روی TEST/OOD، ویژگی فشار مسیر در زمان تصمیم آنلاین، قدرت پیش‌بینی F3، ساخت دیتاست آموزشی یا تعمیم نهایی از اجراهای توسعه‌ای.

**قانون حاکم:** یک `NO_OBSERVED_BLOCKING` آفلاین روی مسیر کاملاً مشاهده‌شده **معادل برچسب F3=0 نیست**؛ `UNKNOWN` هرگز با فقدان رخداد مساوی نیست. اطلاعات پس از `t_decision` باید از فیچرهای آنلاین حذف شود و هزینه telemetry مشخص گردد. Faceهای انتخاب‌نشده داده ضدواقعی ندارند.

**گیت بعد:** `1AM = temporal and online availability, censoring, final label protocol`؛ `1AN = independent pre-freeze review`. تا آن زمان `GO_FREEZE=false`.
