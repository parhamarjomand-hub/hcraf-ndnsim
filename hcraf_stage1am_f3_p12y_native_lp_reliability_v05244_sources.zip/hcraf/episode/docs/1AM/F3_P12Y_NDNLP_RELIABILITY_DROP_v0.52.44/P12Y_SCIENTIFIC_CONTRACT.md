# P12-Y v0.52.44 — NDNLP Native Drop Exhaustion Probe (diagnostic only)

## Motivation
Run 45879957294 (P12-X) confirmed 128 genuine NFD Nacks, but produced ZERO
native Forwarder::onDroppedInterest events even with 2791 L2 queue drops.
This is mechanistically expected if link reliability is disabled. In the
pinned NFD implementation, onDroppedInterest is signaled by LP reliability
when retransmissions exceed the configured budget, NOT by ns-3 NetDevice Drop.

## Intervention
Only two non-preregistered one-seed diagnostic conditions based on the immutable
P12-R dev schedule 24901 as an arrival stimulus:
- LP_RELIABILITY_NO_LOSS: enable link-layer reliability at both ends of the
  selected node1-to-relay Face, maxRetx=1; no deliberate receiving loss.
- LP_RELIABILITY_RX_LOSS: same options, but set RateErrorModel packet error
  probability=1 on the selected relay's actual receiving point-to-point device.

These are diagnostic capability tests, NOT fair P12-R conditions. Enabled
NDNLP itself modifies transport behavior. No diagnostic data may be used in
training, hyperparameter tuning, AP or confirmation.

## Acceptance and scientific boundaries
- Native drop evidence MUST originate only from pinned Forwarder signal
  hcrafP12VInterestDrop and agree with selected Face identity.
- Receiver packet losses are recorded separately as PHY_RX_DROP, never converted
  into NFD dropped Interests.
- A successful simulator exit and any physical receiver losses are INSUFFICIENT
  for native Drop coverage: only >0 native Forwarder InterestDrop events count.
- If ZERO native Drop, report unvalidated; never force or fabricate an event.
- Even if >0 native Drop, this confirms only diagnostic hook capability under
  forced NDNLP settings, not general B1 construct validity or F3 predictive GO.
- Keep Congestion/FutureCongestion null; F3_ready=false, GO_FREEZE=false,
  training_ready=false; confirmation seeds 25001–25036 remain sealed.
