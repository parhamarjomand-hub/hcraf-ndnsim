import unittest, pathlib, importlib.util, json, io, contextlib, tempfile
ROOT=pathlib.Path(__file__).resolve().parents[3]
SRC=ROOT/'hcraf/episode/src/hcraf-stage1am-f3-p12y-native-lp-reliability-v05244.cpp'
RUN=ROOT/'hcraf/episode/scripts/run_stage1am_f3_p12y_v05244.py'
class P12Y(unittest.TestCase):
 def test_provenance_and_single_dev_seed(self):
  s=RUN.read_text();self.assertIn("24901",s);self.assertIn('FAIR_LOCAL_DEV',s);self.assertIn('confirmation_seed_reads',s)
 def test_two_exploratory_modes(self):
  s=SRC.read_text();self.assertIn('LP_RELIABILITY_NO_LOSS',s);self.assertIn('LP_RELIABILITY_RX_LOSS',s)
 def test_no_fake_native_drop(self):
  s=SRC.read_text();self.assertIn('hcrafP12VInterestDrop.connect',s);self.assertNotIn('notifyDroppedInterest(',s)
 def test_actual_options_enabled_both_ends(self):
  s=SRC.read_text();self.assertIn('enableLp(selectedNode1Face',s);self.assertIn('enableLp(selectedRelayFace',s)
 def test_actual_relay_reception_loss(self):
  s=SRC.read_text();self.assertIn('relayRxForLP->SetReceiveErrorModel(rxError)',s)
 def test_reliability_is_diagnostic_override(self):
  s=SRC.read_text();self.assertIn('opts.reliabilityOptions.maxRetx = 1;',s);self.assertIn('P12Y_UNEXPECTED_ALREADY_ENABLED',s)
 def test_no_alias(self):
  s=RUN.read_text();self.assertIn('NFD_drop_not_an_alias_for_PHY_drop',s)
 def test_zero_drop_does_not_confirm(self):
  s=RUN.read_text();self.assertIn("len(drop)>0",s);self.assertIn('nfd_Drop_still_unvalidated_if_zero',s)
 def test_phy_fault_must_be_real(self):
  s=RUN.read_text();self.assertIn("'NO_REAL_RELAY_PACKET_LOSS'",s)
 def test_science_lock(self):
  s=RUN.read_text();self.assertIn("'model_fits':0",s);self.assertIn("'F3_ready':False",s)
 def test_pinned_parent(self):
  s=(ROOT/'hcraf/episode/scripts/build_stage1am_f3_p12y_v05244.sh').read_text();self.assertIn('build_stage1am_f3_p12x_v05243.sh',s)
 def test_no_existing_explicit_drop_simulation(self):
  s=SRC.read_text();self.assertIn('NFD_onDroppedInterest_not_injected',s)
if __name__=='__main__':unittest.main()
