#!/usr/bin/env python3
"""P12Y NDNLP reliability negative-path diagnostic ONLY; no confirm or model."""
import argparse, importlib.util, hashlib, json, subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
PARENT=ROOT/'hcraf/episode/scripts/run_stage1am_f3_p12t_smoke_v05239.py'
SPEC=importlib.util.spec_from_file_location('p12t_schedule_only',PARENT)
p12t=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(p12t)
OUTPUT=ROOT/'episode_output/stage1am_f3_p12y_v05244'
BIN='hcraf-stage1am-f3-p12y-native-lp-reliability-v05244'
PROBES=('LP_RELIABILITY_NO_LOSS','LP_RELIABILITY_RX_LOSS')
def need(ok,name):
 if not ok: raise RuntimeError('P12Y_'+name)
def rows(path):
 need(path.is_file(),'MISSING_'+path.name)
 return [json.loads(s) for s in path.read_text().splitlines() if s.strip()]
def audit(d,probe):
 scenario=json.loads((d/'scenario.json').read_text())
 opts=json.loads((d/'p12y_lp_face_options_runtime.json').read_text())
 need(scenario['p12y_exploratory_diagnostic_only'] is True,'NOT_EXPLORATORY')
 need(scenario['p12y_fault_probe']==probe and opts['probe']==probe,'WRONG_PROBE')
 need(scenario['p12y_not_in_preregistered_P12R_experimental_matrix'] is True,'FORBIDDEN_PREREG_CLAIM')
 need(scenario['p12y_data_must_never_enter_training_or_confirmation'] is True,'FORBIDDEN_TRAINING_CLAIM')
 need(scenario['p12y_lp_reliability_diagnostic_override'] is True,'RELIABILITY_NOT_EXPLICIT')
 need(opts['node1_LP_reliability_enabled'] is True and opts['relay_LP_reliability_enabled'] is True,'LP_NOT_ENABLED')
 need(opts['LP_max_retx_on_both_faces']==1 and opts['node1_face_id']>0 and opts['relay_face_id']>0,'BAD_FACE_OPTS')
 need(opts['NFD_onDroppedInterest_not_injected'] is True,'SYNTHETIC_SIGNAL_FORBIDDEN')
 need(opts['diagnostic_only_not_P12R'] is True,'RESEARCH_PROVENANCE_REQUIRED')
 loss=1 if probe=='LP_RELIABILITY_RX_LOSS' else 0
 need(opts['relay_physical_RX_loss_probability']==loss and scenario['p12y_relay_receive_loss_probability']==loss,'LOSS_NOT_LOCKED')
 need(scenario['seed']==17 and scenario['run']==24901,'DEV_ONLY')
 native=rows(d/'p12v_native_local_12_at_decision.jsonl')
 first=rows(d/'p12t_native_local_at_decision.jsonl')
 need(len(native)==len(first)==128,'EXACT_128_DECISIONS')
 for i,(n,f) in enumerate(zip(native,first),1):
  need(n['decision_id']==i and f['decision_id']==i and n['time_ns']==f['time_ns'],'DECISION_ALIGNMENT')
  need(len(n['b1_all_twelve_native'])==12,'SLOTS_NOT_12')
  need(all(abs(n['b1_all_twelve_native'][j]-f['b1_first_five_native'][j])<1e-9 for j in range(5)),'BASELINE_WIRING_CHANGED')
  need(not n['all_B1_features_validated'] and not n['model_training_authorized'] and not n['F3_ready'] and not n['GO_FREEZE'],'PREMATURE_GO')
 native_events=rows(d/'p12y_live_nfd_negative_signals.jsonl')
 phys=rows(d/'fault_events.jsonl')
 need(all(v['event'] in ('NFD_NATIVE_NACK_IN','NFD_NATIVE_INTEREST_DROP') for v in native_events),'NATIVE_SIGNAL_INVENTED')
 need(all(v['event']=='PHY_RX_DROP' for v in phys),'UNRECOGNIZED_PHY_RX')
 drop=[v for v in native_events if v['event']=='NFD_NATIVE_INTEREST_DROP']
 nack=[v for v in native_events if v['event']=='NFD_NATIVE_NACK_IN']
 need(all(v['face_id']==opts['node1_face_id'] and v['time_ns']>0 for v in drop),'WRONG_NATIVE_DROP_FACE')
 need(native[-1]['live_NFD_interest_drop_total']<=len(drop),'DROP_COUNTER_OVERRUN')
 relay_phy=[v for v in phys if v['node_id']==scenario['selected_relay_node_id']]
 if loss:
  need(len(relay_phy)>0,'NO_REAL_RELAY_PACKET_LOSS')
 else:
  need(len(relay_phy)==0,'CONTROL_HAS_RELAY_PACKET_LOSS')
 r={'probe':probe,'status':'PHYSICAL_DIAGNOSTIC_ONLY_NOT_F3_GO',
    'native_decisions':128,'selected_face_id':opts['node1_face_id'],
    'lp_reliability_enabled_both_faces':True,'maxRetx':1,
    'real_relay_phy_rx_drops':len(relay_phy),
    'real_forwarder_NFD_onDroppedInterest_events':len(drop),
    'NFD_Drop_coverage_validated_this_probe':len(drop)>0,
    'native_Nack_events':len(nack),
    'NFD_drop_not_an_alias_for_PHY_drop':True,
    'exploratory_not_P12R_trials':True,'training_ready':False,'F3_ready':False,'GO_FREEZE':False,
    'model_fits':0,'new_AP_computed':False,'heldout_reads':0,'confirmation_seed_reads':0,
    'Congestion':None,'FutureCongestion':None}
 (d/'P12Y_PHYSICAL_LP_RELIABILITY_DIAGNOSTIC_v05244.json').write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
 return r

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--preflight-only',action='store_true');args=ap.parse_args()
 r,p=p12t.plan()
 need(r['seed']=='24901' and r['partition']=='FAIR_LOCAL_DEV','WRONG_PARTITION')
 need(r['schedule_sha256']==hashlib.sha256(p.read_bytes()).hexdigest(),'MUTATED_P12R_SCHEDULE')
 print('PASS_P12Y_FROZEN_24901_SCHEDULE_USED_ONLY_AS_STIMULUS',r['seed'])
 if args.preflight_only:return
 need(not OUTPUT.exists(),'REFUSE_OVERWRITE')
 need((ROOT/'episode_sources/ns-3/build/scratch'/BIN).is_file(),'MISSING_REAL_NDNSIM_BINARY')
 OUTPUT.mkdir(parents=True)
 outputs=[]
 for probe in PROBES:
  d=OUTPUT/probe;d.mkdir()
  p12t.OUT=d;p12t.BIN=BIN
  command=p12t.cmd(r,p)+' --p12yProbe='+probe
  (d/'command.txt').write_text(command+'\n')
  with (d/'simulator.log').open('w') as f:
   subprocess.run(['python3','./waf','--run-no-build',command],cwd=ROOT/'episode_sources/ns-3',stdout=f,stderr=subprocess.STDOUT,check=True)
  receipt=audit(d,probe);outputs.append(receipt)
  print('PASS_P12Y_EXECUTED_REAL_PINNED_LP_DIAGNOSTIC',probe,'RELAY_RX_DROP',receipt['real_relay_phy_rx_drops'],'NFD_DROP',receipt['real_forwarder_NFD_onDroppedInterest_events'])
 full={'status':'PASS_P12Y_EXPLORATORY_LP_PHYSICAL_PROBES_ONLY_NOT_F3_RELEASE',
   'parent_P12X_run':45879957294,'original_P12V_run':45868303602,
   'probe_count':len(outputs),'probes':outputs,
   'native_drop_observed':any(x['NFD_Drop_coverage_validated_this_probe'] for x in outputs),
   'nfd_Drop_still_unvalidated_if_zero':True,
   'diagnostic_LP_reliability_override_not_preregistered':True,
   'may_not_train_on_any_diagnostic_data':True,'model_fits':0,'new_AP_computed':False,
   'F3_ready':False,'GO_FREEZE':False,'training_ready':False,'heldout_reads':0,
   'confirmation_seed_reads':0,'Congestion':None,'FutureCongestion':None}
 (OUTPUT/'P12Y_LP_RELIABILITY_EXHAUSTION_RECEIPT_v05244.json').write_text(json.dumps(full,indent=2,sort_keys=True)+'\n')
 print(full['status'],'NFD_DROP_COVERAGE=',full['native_drop_observed'])
if __name__=='__main__':main()
