#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
bash "$TASK/scripts/build_stage1am_f3_p12x_v05243.sh"
NS3="$ROOT/episode_sources/ns-3"
CPP="$TASK/src/hcraf-stage1am-f3-p12y-native-lp-reliability-v05244.cpp"
DEST="$NS3/scratch/hcraf-stage1am-f3-p12y-native-lp-reliability-v05244.cc"
cp "$CPP" "$DEST"
cmp -s "$CPP" "$DEST"
(cd "$NS3" && python3 ./waf -j 2)
test -x "$NS3/build/scratch/hcraf-stage1am-f3-p12y-native-lp-reliability-v05244"
echo PASS_P12Y_PINNED_NFD_LP_RELIABILITY_PHYSICAL_PROBE_BINARY_COMPILED_NO_MODEL
