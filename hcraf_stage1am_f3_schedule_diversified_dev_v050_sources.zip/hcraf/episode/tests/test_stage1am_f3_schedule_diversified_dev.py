"""Local non-ndnSIM contract tests for F3 v0.50.0 DEV pilot."""
import copy
import importlib.util
import json
import pathlib
import tempfile
import unittest

SCRIPTS=pathlib.Path(__file__).resolve().parents[1]/'scripts'
SPEC=importlib.util.spec_from_file_location('v050',(SCRIPTS/'verify_stage1am_f3_schedule_diversified_dev.py'))
M=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(M)


def config(family='A_SHIFTED_PULSES',arm='RETURN_STRESSED_6M',rng=11601,mon=True):
    return dict(topology_id='DEV_CHAIN_L',holdout_partition='DEVELOPMENT',
        amendment_stage='1AM.F3_SCHEDULE_DIVERSIFIED_DEV.0',
        purpose='SCHEDULE_DIVERSIFIED_DEV_NOT_HCRAF_POLICY',
        schedule_contract='F3_DEV_DIVERSIFIED_PREREG_V050',
        phase_arm=arm,schedule_family=family,run=rng,independent_rng_block=rng,
        selected_face_slot=M.slot_for_rng(rng),seed=17,instrument_enabled=mon,
        selected_producer_reverse_bps=M.ARMS[arm],selected_forward_bps=50_000_000,
        selected_relay_forward_bps=50_000_000,selected_mid_forward_bps=50_000_000,
        selected_return_bps=50_000_000,
        matched_rate_only_manipulated_parameter='selected_producer_reverse_bps',
        planned_requests=12,nominal_arrival_interval_ns=30_000_000,
        competitor_planned_requests=96,competitor_interval_ns=2_000_000,
        target_offset_ns=30_000_000,competitor_offset_ns=0,
        interest_lifetime_ms=2600,queue_capacity_packets=20,mtu_bytes=600,
        payload_bytes=4096,network_node_count=11,network_directed_device_count=20,
        stop_ns=M.STOP,target_schedule_rng_stream=129,competitor_schedule_rng_stream=139,
        candidate_negative_control_is_not_scientific_label=True,
        future_oracle_horizon_ns_pilot=75_000_000,diagnostic_horizons_ms=[50,75,100],
        competitor_pulse_count=2 if family==M.FAMILIES[0] else 4,
        competitor_pulse_spacing_ns=145_000_000 if family==M.FAMILIES[0] else 110_000_000,
        no_counterfactual_unselected_face=True,future_oracle_is_final_F3=False,
        remote_queue_online_feature=False,actual_assignment_probability=1.0,
        Congestion=None,FutureCongestion=None,congestion=None,future_congestion=None,
        F3_ready=False,GO_FREEZE=False,training_ready=False,
        selected_producer_node_id=8,selected_mid_node_id=7,
        local_NFD_queue_observed_before_send=mon,NFD_dispatch_wall_CPU_measured=mon)


class Contracts(unittest.TestCase):
    def test_all_12_distinct_rng_slots_and_groups(self):
        self.assertEqual(len(M.RUNS),12)
        self.assertEqual([sum(M.slot_for_rng(r)==s for r in M.RUNS) for s in range(3)],[4,4,4])
        self.assertTrue(set(M.UNMONITORED).issubset(M.RUNS))
        self.assertEqual(len(M.UNMONITORED),4)
    def test_valid_configs_all_arms_and_families(self):
        for rng in M.RUNS:
            for family in M.FAMILIES:
                for arm in M.ARMS:
                    self.assertTrue(M.check_config(config(family,arm,rng),arm,family,rng,True))
    def test_rate_arm_is_only_rate_delta(self):
        a=M.check_config(config(arm='RETURN_STRESSED_6M'),'RETURN_STRESSED_6M',M.FAMILIES[0],11601,True)
        b=M.check_config(config(arm='RETURN_MATCHED_HIGH_CAPACITY_50M'),'RETURN_MATCHED_HIGH_CAPACITY_50M',M.FAMILIES[0],11601,True)
        self.assertEqual(a,b)
    def test_monitored_pair_is_config_identical(self):
        a=M.check_config(config(),M.FAMILIES[0] and 'RETURN_STRESSED_6M',M.FAMILIES[0],11601,True)
        b=M.check_config(config(mon=False),'RETURN_STRESSED_6M',M.FAMILIES[0],11601,False)
        self.assertEqual(a,b)
    def test_reject_nonregistered_rng(self):
        with self.assertRaises(M.AuditFailure): M.slot_for_rng(11421)
    def test_reject_false_scientific_negative(self):
        a=config();a['FutureCongestion']=0
        with self.assertRaises(M.AuditFailure): M.check_config(a,'RETURN_STRESSED_6M',M.FAMILIES[0],11601,True)
    def test_reject_go_freeze(self):
        a=config();a['GO_FREEZE']=True
        with self.assertRaises(M.AuditFailure): M.check_config(a,'RETURN_STRESSED_6M',M.FAMILIES[0],11601,True)
    def test_reject_unmonitored_remote_queue_as_online_feature(self):
        a=config();a['remote_queue_online_feature']=True
        with self.assertRaises(M.AuditFailure): M.check_config(a,'RETURN_STRESSED_6M',M.FAMILIES[0],11601,True)
    def test_reject_wrong_family(self):
        a=config();a['competitor_pulse_count']=4
        with self.assertRaises(M.AuditFailure): M.check_config(a,'RETURN_STRESSED_6M',M.FAMILIES[0],11601,True)
    def test_reject_test_or_val_partition(self):
        for partition in ('VALIDATION','TEST'):
            a=config();a['holdout_partition']=partition
            with self.assertRaises(M.AuditFailure):M.check_config(a,'RETURN_STRESSED_6M',M.FAMILIES[0],11601,True)
    def test_reject_modified_third_link(self):
        a=config();a['selected_mid_forward_bps']=10_000_000
        with self.assertRaises(M.AuditFailure):M.check_config(a,'RETURN_STRESSED_6M',M.FAMILIES[0],11601,True)
    def test_reject_absent_trace(self):
        with tempfile.TemporaryDirectory() as t:
            with self.assertRaises(M.AuditFailure):M.reverse_events(pathlib.Path(t),config())
    def test_require_no_source_conflicts(self):
        content=(SCRIPTS/'run_stage1am_f3_schedule_diversified_dev.sh').read_text()
        self.assertIn('REFUSE_TO_OVERWRITE_EXISTING_DEV_OUTPUT',content)
        self.assertIn('11601|11605|11609|11610',content)
        self.assertIn('stage1am_f3_schedule_diversified_report',content)
    def test_source_protects_rng_and_schedule(self):
        cpp=(SCRIPTS.parent/'src/hcraf-stage1am-f3-schedule-diversified-dev.cpp').read_text()
        for token in ('run<11601','run>11612','scheduleFamily','F3_DEV_DIVERSIFIED_PREREG_V050',
                      'selectedSlot!=((run-11601u)%3u)','"Congestion"'):
            if token=='"Congestion"':continue
            self.assertIn(token,cpp)
    def test_physical_pressure_assessment_has_no_scientific_label(self):
        self.assertIn('FutureCongestion\':None', (SCRIPTS/'verify_stage1am_f3_schedule_diversified_dev.py').read_text())
    def sample_online(self,folder,leak=False):
        p=pathlib.Path(folder)
        decisions=[];states=[];local=[]
        for i in range(12):
            t=2_000_000_000+i*30_000_000
            decisions.append({'decision_id':i+1,'name':f'/hcraf/pilot/{i}',
                'time_ns':t,'after_event_seq':i+1})
            states.append({'decision_id':i+1,'face_id':258,'time_ns':t,
                'after_event_seq':i+1,'max_terminal_event_seq':i+2 if leak and i==0 else 0,
                'SRTT_ms':None,'SuccessEstimate':None,'Goodput_bps':0,
                'RoutingCost':1,'valid_outcomes':0,'valid_rtt':0,
                'Congestion':None})
            local.append({'decision_id':i+1,'candidate_face_id':258,'sim_time_ns':t,
                'observed_before_forwarding':True,'remote_node_queue_accessed':False,
                'future_pressure_label':None,'Congestion':None,
                'queue_packets':0,'capacity_packets':20})
        decisions.extend({'decision_id':13+j,'name':f'/hcraf/competitor/{j}',
                          'time_ns':3_000_000_000+j*1_000_000,
                          'after_event_seq':100+j} for j in range(96))
        for name,rows in [('events.jsonl.decisions.jsonl',decisions),
                          ('events.jsonl.states.jsonl',states),
                          ('nfd_local_queue_at_decision.jsonl',local)]:
            (p/name).write_text(''.join(json.dumps(r)+'\n' for r in rows))
        return p

    def test_online_feature_missing_srtt_is_not_imputed(self):
        with tempfile.TemporaryDirectory() as t:
            p=self.sample_online(t)
            features,windows=M.online_windows(p,{'selected_face_id':258},[],M.FAMILIES[0],
                         'RETURN_STRESSED_6M',11601)
            self.assertEqual(len(features),12)
            self.assertEqual(len(windows),36)
            self.assertTrue(all(x['SRTT_ms'] is None for x in features))
            self.assertTrue(all(x['diagnostic_state_NOT_F3']=='NO_DEQUEUE_UNRESOLVED' for x in windows))
            self.assertTrue(all(x['FutureCongestion'] is None for x in windows))

    def test_future_terminal_event_leakage_fails_closed(self):
        with tempfile.TemporaryDirectory() as t:
            p=self.sample_online(t,leak=True)
            with self.assertRaises(M.AuditFailure):
                M.online_windows(p,{'selected_face_id':258},[],M.FAMILIES[0],
                         'RETURN_STRESSED_6M',11601)

    def test_diagnostic_proxy_is_not_F3_label(self):
        with tempfile.TemporaryDirectory() as t:
            p=self.sample_online(t)
            reverse=[{'event_type':'QUEUE_DROP','time_ns':2_000_000_000+10_000_000}]
            _,win=M.online_windows(p,{'selected_face_id':258},reverse,M.FAMILIES[0],
                         'RETURN_STRESSED_6M',11601)
            self.assertEqual(win[0]['diagnostic_state_NOT_F3'],'PHYSICAL_PRESSURE_PROXY')
            self.assertIsNone(win[0]['FutureCongestion'])

if __name__=='__main__': unittest.main()
