# راهنمای فنی مرحله HCRAF F3 v0.50.0

این ZIP افزایشی شامل فقط فایل‌های جدید Development است و **هیچ فایل مربوط به v0.47.1 یا v0.49.0 را بازنویسی نمی‌کند**.

مسیرهای جدید:
- `hcraf/episode/src/hcraf-stage1am-f3-schedule-diversified-dev.cpp` (C++ مستقل)
- `hcraf/episode/scripts/build_stage1am_f3_schedule_diversified_dev.sh`
- `hcraf/episode/scripts/run_stage1am_f3_schedule_diversified_dev.sh`
- `hcraf/episode/scripts/verify_stage1am_f3_schedule_diversified_dev.py`
- `hcraf/episode/tests/test_stage1am_f3_schedule_diversified_dev.py`
- `hcraf/episode/docs/1AM/F3_SCHEDULE_DIVERSIFIED_DEV_v0.50/` (مستندات، قفل و ماتریس ۹۶ اجرا)

Workflow جدید فقط از ZIPهای منابع موجود v0.47 و v0.49 برای بازیابی زمینه استفاده می‌کند؛ Workflowهای گذشته را اجرا نمی‌کند. داده Validation/Test و Stage 1AO دست‌نخورده می‌مانند.

### نتایج قبل از اجرای GitHub

- ۱۸ آزمون اختصاصی Local PASS.
- آزمون قالب Trace و تاریخچه آنلاین روی سه نمونه خام واقعی v0.49.0 PASS؛ این‌ها شبیه‌سازی جدید نیستند.
- مجموعه کلی محلی ۷۲۰ تست جمع‌آوری کرد؛ ۳۱ شکست به‌دلیل نبود `artifact/stage1s` در محیط محلی رخ داد. این پوشه در Workflow GitHub از ZIP مرجع بازیابی می‌شود؛ **نمی‌توان گفت همه تست‌ها در محیط محلی پاس شده‌اند**.
- کامپایل C++ و اجرای ۹۶ شبیه‌سازی هنوز **انجام نشده** و تأیید نهایی فنی پس از GitHub است.

### سیاست علمی

فقط `DEV PILOT`; هیچ کلاس منفی علمی ساخته نمی‌شود؛ F3 همچنان NO_GO است.
