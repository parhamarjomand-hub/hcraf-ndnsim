#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
OUT="$ROOT/episode_output/stage1am_f3_schedule_diversified_dev"
REPORT="$ROOT/episode_output/stage1am_f3_schedule_diversified_report"
# Never replace evidence from any prior experiment or another attempt.
if [ -e "$OUT" ] || [ -e "$REPORT" ]; then
  echo "REFUSE_TO_OVERWRITE_EXISTING_DEV_OUTPUT" >&2; exit 10
fi
mkdir -p "$OUT"
cd "$ROOT/episode_sources/ns-3"
count=0
monitored=0
unmonitored=0
for rng in {11601..11612}; do
  slot=$(( (rng - 11601) % 3 ))
  for family in A_SHIFTED_PULSES B_INTERLEAVED_PULSES; do
    for arm in RETURN_STRESSED_6M RETURN_INTERMEDIATE_12M RETURN_MATCHED_HIGH_CAPACITY_50M; do
      for instrument in 1 0; do
        if [ "$instrument" = 0 ]; then
          # Pre-registered balanced 4 RNG controls: each occupies a different
          # independent block; one physical slot is deliberately repeated.
          case "$rng" in 11601|11605|11609|11610) ;; *) continue ;; esac
          kind=uninstrumented
        else
          kind=monitored
        fi
        dest="$OUT/DEV_CHAIN_L/rng-$rng/$family/$kind/$arm"
        mkdir -p "$dest"
        cmd="hcraf-stage1am-f3-schedule-diversified-dev --pathArm=$arm --scheduleFamily=$family --topology=DEV_CHAIN_L --selectedSlot=$slot --mode=LP_INDEPENDENT_COMPETITOR_NO_DROP --seed=17 --run=$rng --output=$dest --instrument=$instrument --lifetimeMs=2600 --requestCount=12 --intervalNs=30000000 --competitorCount=96 --competitorIntervalNs=2000000 --competitorOffsetNs=0 --targetOffsetNs=30000000 --forwardBps=50000000 --returnBps=50000000"
        printf '%s\n' "$cmd" > "$dest/command.txt"
        /usr/bin/time -f 'wall_seconds=%e\nuser_seconds=%U\nsystem_seconds=%S\nmax_rss_kib=%M' -o "$dest/resource_usage.txt" \
          python3 ./waf --run-no-build "$cmd" > "$dest/simulator.log" 2>&1
        if [ "$instrument" = 1 ]; then
          python3 "$TASK/scripts/episodes_stage1u.py" "$dest" \
            --run-id "1am_diversified_dev-DEV_CHAIN_L-$rng-$family-$arm" > "$dest/episodes.log" 2>&1
          monitored=$((monitored+1))
        else
          unmonitored=$((unmonitored+1))
        fi
        count=$((count+1))
      done
    done
  done
done
if [ "$monitored" != 72 ] || [ "$unmonitored" != 24 ] || [ "$count" != 96 ]; then
  echo "RUN_MATRIX_MISMATCH:$monitored:$unmonitored" >&2;exit 11
fi
python3 "$TASK/scripts/verify_stage1am_f3_schedule_diversified_dev.py" "$OUT" \
 --output "$REPORT" > "$ROOT/episode_output/stage1am_f3_schedule_diversified_report.log" 2>&1
