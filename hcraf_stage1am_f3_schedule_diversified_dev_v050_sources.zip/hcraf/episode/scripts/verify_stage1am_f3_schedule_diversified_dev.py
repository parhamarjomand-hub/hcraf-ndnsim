#!/usr/bin/env python3
"""F3 stage 1AM v0.50.0 DEV-only, fail-closed matched schedule audit.

This tool never creates scientific labels, fits a model, or uses Test/Validation.
RNG is the independent group. Counts are descriptive, not inferential replicates.
"""
import argparse
import collections
import csv
import importlib.util
import json
import math
import pathlib
import sys

_HERE=pathlib.Path(__file__).resolve().parent
_SPEC=importlib.util.spec_from_file_location('hcraf_v049_audit',_HERE/'verify_stage1am_f3_return_matched_dev.py')
if _SPEC is None or _SPEC.loader is None:
    raise RuntimeError('V049_AUDITOR_MISSING')
_PREV=importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(_PREV)

ARMS=_PREV.ARMS
RUNS=tuple(range(11601,11613))
FAMILIES=('A_SHIFTED_PULSES','B_INTERLEAVED_PULSES')
UNMONITORED=(11601,11605,11609,11610)
STOP=_PREV.STOP
HORIZONS=(50,75,100)
MAX_QUEUE_WAIT_NS=5_000_000
AuditFailure=_PREV.AuditFailure
require=_PREV.require
jsonl=_PREV.jsonl
json_file=_PREV.json_file
signature=_PREV.signature


def slot_for_rng(rng):
    require(rng in RUNS,'NON_PREREGISTERED_RNG')
    return (rng-11601)%3


def check_config(c,arm,family,rng,instrument):
    slot=slot_for_rng(rng)
    require(c.get('topology_id')=='DEV_CHAIN_L' and
            c.get('holdout_partition')=='DEVELOPMENT' and
            c.get('amendment_stage')=='1AM.F3_SCHEDULE_DIVERSIFIED_DEV.0' and
            c.get('purpose')=='SCHEDULE_DIVERSIFIED_DEV_NOT_HCRAF_POLICY' and
            c.get('schedule_contract')=='F3_DEV_DIVERSIFIED_PREREG_V050',
            'FORBIDDEN_HOLDOUT_OR_SCHEMA')
    require(c.get('phase_arm')==arm and c.get('schedule_family')==family and
            c.get('run')==rng and c.get('independent_rng_block')==rng and
            c.get('selected_face_slot')==slot and c.get('seed')==17 and
            c.get('instrument_enabled') is instrument,
            'WRONG_RNG_ARM_SCHEDULE_SLOT_OR_MONITOR')
    require(c.get('selected_producer_reverse_bps')==ARMS[arm] and
            c.get('selected_forward_bps')==50_000_000 and
            c.get('selected_relay_forward_bps')==50_000_000 and
            c.get('selected_mid_forward_bps')==50_000_000 and
            c.get('selected_return_bps')==50_000_000 and
            c.get('matched_rate_only_manipulated_parameter')=='selected_producer_reverse_bps',
            'RATE_OR_PHYSICAL_CONTRACT_CHANGED')
    require(c.get('planned_requests')==12 and c.get('nominal_arrival_interval_ns')==30_000_000 and
            c.get('competitor_planned_requests')==96 and c.get('competitor_interval_ns')==2_000_000 and
            c.get('target_offset_ns')==30_000_000 and c.get('competitor_offset_ns')==0 and
            c.get('interest_lifetime_ms')==2600 and c.get('queue_capacity_packets')==20 and
            c.get('mtu_bytes')==600 and c.get('payload_bytes')==4096 and
            c.get('network_node_count')==11 and c.get('network_directed_device_count')==20 and
            c.get('stop_ns')==STOP and c.get('target_schedule_rng_stream')==129 and
            c.get('competitor_schedule_rng_stream')==139 and
            c.get('candidate_negative_control_is_not_scientific_label') is True and
            c.get('future_oracle_horizon_ns_pilot')==75_000_000 and
            c.get('diagnostic_horizons_ms')==[50,75,100],
            'LOAD_OR_HORIZON_CONTRACT_CHANGED')
    require(c.get('competitor_pulse_count')==(2 if family==FAMILIES[0] else 4) and
            c.get('competitor_pulse_spacing_ns')==(145_000_000 if family==FAMILIES[0] else 110_000_000),
            'SCHEDULE_FAMILY_NOT_APPLIED')
    require(c.get('no_counterfactual_unselected_face') is True and
            c.get('future_oracle_is_final_F3') is False and
            c.get('remote_queue_online_feature') is False and
            c.get('actual_assignment_probability')==1.0,
            'INVALID_ONLINE_OR_COUNTERFACTUAL_CLAIM')
    for k in ('Congestion','FutureCongestion','congestion','future_congestion'):
        require(k in c and c[k] is None,'SCIENTIFIC_LABEL_FORBIDDEN:'+k)
    for k in ('F3_ready','GO_FREEZE','training_ready'):
        require(c.get(k) is False,'SCIENTIFIC_GATE_FORBIDDEN:'+k)
    require(c.get('selected_producer_node_id') in (8,9,10) and
            c.get('selected_mid_node_id') in (5,6,7),'INVALID_PATH_NODES')
    # All other scenario attributes must match within a paired block.
    return {k:v for k,v in c.items() if k not in
        ('phase_arm','selected_producer_reverse_bps','instrument_enabled',
         'local_NFD_queue_observed_before_send','NFD_dispatch_wall_CPU_measured')}


def validated_traffic(path,family):
    pair=_PREV.traffic(path) # raw SEND and ARRIVAL equality, unique names and 12+96 counts
    for cls,fn in (('target','consumer_events.jsonl'),('competitor','competitor_events.jsonl')):
        arr=jsonl(path/(fn+'.arrivals.jsonl'))
        require(all(x.get('schedule_family')==family and
                    x.get('schedule')=='F3_DEV_DIVERSIFIED_PREREG_V050' and
                    type(x.get('pulse_start_ns')) is int and
                    0<=x['pulse_start_ns']<=300_000_000 for x in arr),
                'UNREGISTERED_SCHEDULE_RECORD:'+str(path))
        ts=[x['time_ns'] for x in arr]
        require(all(a<b for a,b in zip(ts,ts[1:])), 'UNSORTED_SEND_TIMES:'+str(path))
        pulses={x['burst_index'] for x in arr}
        expected={0,1} if (cls=='target' and family==FAMILIES[1]) else (
            {0} if cls=='target' else ({0,1} if family==FAMILIES[0] else {0,1,2,3}))
        require(pulses==expected,'INCORRECT_SCHEDULE_PULSE_COUNT:'+str(path))
    return pair


def reverse_events(path,config):
    events=jsonl(path/'link_events.jsonl')
    p=config['selected_producer_node_id']
    chosen=[e for e in events if e.get('event_type')=='INITIAL' and e.get('node_id')==p]
    require(len(chosen)==1,'REVERSE_DEVICE_MISSING')
    d=chosen[0]['device_index']
    all_event_times=[e['time_ns'] for e in events]
    require(all(a<=b for a,b in zip(all_event_times,all_event_times[1:])),
            'LINK_EVENT_TIMESTAMP_NOT_MONOTONE')
    selected=[e for e in events if e.get('node_id')==p and e.get('device_index')==d]
    require(selected[0]['event_type']=='INITIAL' and selected[-1]['event_type']=='FINAL',
            'REVERSE_TRACE_BOUNDARY_FAILURE')
    queue=0
    for e in selected:
        typ=e['event_type']
        if typ=='QUEUE_ENQUEUE':queue+=1
        if typ=='QUEUE_DEQUEUE':queue-=1
        require(0<=queue<=20,'QUEUE_STATE_OUTSIDE_BOUND')
        if typ in ('QUEUE_ENQUEUE','QUEUE_DEQUEUE','QUEUE_DROP','INITIAL','FINAL'):
            require(e['queue_packets']==queue,'QUEUE_TRANSITION_MISMATCH')
    require(queue==selected[-1]['queue_packets'],'REVERSE_FINAL_QUEUE_MISMATCH')
    return [e for e in selected if e['event_type'] in ('QUEUE_DROP','QUEUE_DEQUEUE')]


def online_windows(path,config,reverse,family,arm,rng):
    all_decisions=jsonl(path/'events.jsonl.decisions.jsonl')
    decisions=[d for d in all_decisions if d.get('name','').startswith('/hcraf/pilot/')]
    require(len(decisions)==12 and len(all_decisions)==108,'NOT_108_TOTAL_AND_12_TARGET_DECISIONS')
    target_ids={d['decision_id'] for d in decisions}
    states=jsonl(path/'events.jsonl.states.jsonl')
    face=config['selected_face_id']
    chosen={}
    for st in states:
        if st.get('face_id')==face and st.get('decision_id') in target_ids:
            i=st.get('decision_id')
            require(i not in chosen,'DUPLICATE_SELECTED_FACE_FEATURE')
            chosen[i]=st
    require(len(chosen)==12,'MISSING_SELECTED_FACE_HISTORY')
    local=jsonl(path/'nfd_local_queue_at_decision.jsonl')
    local_selected={}
    for st in local:
        if st.get('candidate_face_id')==face and st.get('decision_id') in target_ids:
            i=st.get('decision_id')
            require(i not in local_selected,'DUPLICATE_LOCAL_ONLINE')
            local_selected[i]=st
    require(len(local_selected)==12,'MISSING_LOCAL_ONLINE')
    feature_rows=[]; windows=[]
    for ordinal,d in enumerate(decisions,1):
        key=d['decision_id']; name=f'/hcraf/pilot/{ordinal-1}'
        require(d.get('name')==name and key in chosen and key in local_selected,
                'DECISION_OR_FEATURE_MISMATCH')
        s=chosen[key]; loc=local_selected[key]; t=d['time_ns']
        require(s.get('time_ns')==t and loc.get('sim_time_ns')==t and
                loc.get('observed_before_forwarding') is True and
                loc.get('remote_node_queue_accessed') is False and
                loc.get('future_pressure_label') is None and
                loc.get('Congestion') is None and
                s.get('Congestion') is None and
                s.get('max_terminal_event_seq',10**18)<=s.get('after_event_seq',-1) and
                s.get('after_event_seq')==d.get('after_event_seq'),
                'FUTURE_LEAK_OR_CLOCK_MISMATCH')
        for feat in ('SRTT_ms','SuccessEstimate','Goodput_bps'):
            x=s.get(feat)
            require(x is None or (type(x) in (int,float) and math.isfinite(x) and x>=0),
                    'NONFINITE_OR_NEGATIVE_ONLINE_VALUE:'+feat)
        if s.get('SuccessEstimate') is not None:
            require(s['SuccessEstimate']<=1.0,'INVALID_SUCCESS_PROBABILITY')
        require(type(loc.get('queue_packets')) is int and loc['queue_packets']>=0 and
                loc.get('capacity_packets')==20, 'INVALID_LOCAL_QUEUE')
        feat={'rng_block':rng,'slot':slot_for_rng(rng),'schedule_family':family,'arm':arm,
              'target_ordinal_diagnostic_only':ordinal,
              'decision_id_audit_only':key,'decision_time_ns':t,
              'RoutingCost':s.get('RoutingCost'),
              'SRTT_ms':s['SRTT_ms'],'SuccessEstimate':s['SuccessEstimate'],
              'Goodput_bps':s.get('Goodput_bps'),
              'valid_outcomes':s.get('valid_outcomes'),
              'valid_rtt':s.get('valid_rtt'),
              'last_outcome_evidence_age_ns':s.get('last_outcome_evidence_age_ns'),
              'last_rtt_evidence_age_ns':s.get('last_rtt_evidence_age_ns'),
              'local_queue_packets':loc['queue_packets'],
              'history_is_predecision_only':True,
              'model_input_includes_schedule_or_arm':False}
        feature_rows.append(feat)
        for h in HORIZONS:
            observed=[e for e in reverse if t<=e['time_ns']<t+h*1_000_000]
            drops=sum(e['event_type']=='QUEUE_DROP' for e in observed)
            dequeues=[e for e in observed if e['event_type']=='QUEUE_DEQUEUE']
            waits=[e['queue_wait_ns'] for e in dequeues]
            require(all(type(w) is int and w>=0 for w in waits),'INVALID_FUTURE_WAIT')
            high=sum(w>MAX_QUEUE_WAIT_NS for w in waits)
            status=('PHYSICAL_PRESSURE_PROXY' if drops or high else
                    'NO_DEQUEUE_UNRESOLVED' if not dequeues else
                    'LOW_PRESSURE_CANDIDATE_NOT_SCIENTIFIC_NEGATIVE')
            windows.append({'rng_block':rng,'slot':slot_for_rng(rng),
              'schedule_family':family,'arm':arm,'target_ordinal':ordinal,
              'decision_time_ns':t,'horizon_ms':h,
              'reverse_queue_drop_fragments_in_window':drops,
              'reverse_dequeue_events_in_window':len(dequeues),
              'reverse_dequeue_wait_over_5ms_in_window':high,
              'diagnostic_state_NOT_F3':status,
              'FutureCongestion':None})
    return feature_rows,windows


def resource(path):
    f=path/'resource_usage.txt'
    require(f.is_file(),'MISSING_RESOURCE_USAGE')
    a={}
    for line in f.read_text().splitlines():
        if '=' in line:
            k,v=line.split('=',1)
            if k in ('wall_seconds','user_seconds','system_seconds','max_rss_kib'):
                a[k]=float(v)
    require(set(a)=={'wall_seconds','user_seconds','system_seconds','max_rss_kib'} and
            all(math.isfinite(v) and v>=0 for v in a.values()),'INVALID_RESOURCE_USAGE')
    return a


def write_csv(path,rows):
    require(bool(rows),'EMPTY_TABLE_FORBIDDEN')
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys()))
        w.writeheader();w.writerows(rows)


def audit(root,out):
    root=pathlib.Path(root)
    run_rows=[]; feature_rows=[]; window_rows=[]; cost_rows=[]
    fingerprint={}; schedules={}
    for rng in RUNS:
        slot=slot_for_rng(rng)
        for family in FAMILIES:
            matched=None; matched_config=None
            for arm,rate in ARMS.items():
                kinds=['monitored']+(['uninstrumented'] if rng in UNMONITORED else [])
                for kind in kinds:
                    p=root/'DEV_CHAIN_L'/f'rng-{rng}'/family/kind/arm
                    require(p.is_dir(),'MISSING_REGISTERED_RUN:'+str(p))
                    monitor=(kind=='monitored')
                    c=json_file(p/'scenario.json')
                    inv=check_config(c,arm,family,rng,monitor)
                    traffic=validated_traffic(p,family)
                    require(matched is None or matched==traffic,
                            'CROSS_RATE_OR_MONITOR_TRAFFIC_DRIFT:'+str(p))
                    require(matched_config is None or matched_config==inv,
                            'CROSS_RATE_OR_MONITOR_CONFIG_DRIFT:'+str(p))
                    if matched is None:
                        matched=traffic;matched_config=inv
                    run_row={'rng_block':rng,'slot':slot,'schedule_family':family,
                             'arm':arm,'return_bps':rate,'instrumented':monitor,
                             'target_schedule_sha256':signature(traffic['target']),
                             'competitor_schedule_sha256':signature(traffic['competitor'])}
                    cost=resource(p)
                    run_row.update(cost)
                    if monitor:
                        pressures=_PREV.pressure(p,c)
                        run_row.update(pressures)
                        selected=reverse_events(p,c)
                        feat,win=online_windows(p,c,selected,family,arm,rng)
                        feature_rows.extend(feat);window_rows.extend(win)
                        # Check rate on all nonmanipulated devices across families/capacities
                        key=rng
                        hashval=pressures['nonmanipulated_device_rates_sha256']
                        require(key not in fingerprint or fingerprint[key]==hashval,
                                'NONMANIPULATED_PHYSICAL_CONFIGURATION_CHANGED')
                        fingerprint[key]=hashval
                    run_rows.append(run_row)
                if rng in UNMONITORED:
                    m,n=run_rows[-2:]
                    require(m['instrumented'] is True and n['instrumented'] is False,
                            'PAIR_RESOURCE_MISSING')
                    cost_rows.append({'rng_block':rng,'slot':slot,'schedule_family':family,
                        'arm':arm,'monitor_wall_seconds':m['wall_seconds'],
                        'unmonitored_wall_seconds':n['wall_seconds'],
                        'monitor_user_seconds':m['user_seconds'],
                        'unmonitored_user_seconds':n['user_seconds'],
                        'monitor_max_rss_kib':m['max_rss_kib'],
                        'unmonitored_max_rss_kib':n['max_rss_kib'],
                        'cost_is_algorithm_only':False})
            require(matched is not None,'MISSING_TRAFFIC')
            schedules[(rng,family)]=(signature(matched['target']),
                                      signature(matched['competitor']))
    require(len(run_rows)==96 and sum(x['instrumented'] for x in run_rows)==72 and
            len(feature_rows)==864 and len(window_rows)==2592 and len(cost_rows)==24,
            'INCOMPLETE_DEV_MATRIX')
    for family in FAMILIES:
        for idx in (0,1):
            require(len({schedules[(rng,family)][idx] for rng in RUNS})==12,
                    'MISSING_INDEPENDENT_RNG_SCHEDULE_DIVERSITY')
    for rng in RUNS:
        require(schedules[(rng,FAMILIES[0])]!=schedules[(rng,FAMILIES[1])],
                'IDENTICAL_SCHEDULE_FAMILIES')
    by_status=collections.Counter((x['schedule_family'],x['arm'],x['horizon_ms'],
                                   x['diagnostic_state_NOT_F3']) for x in window_rows)
    summary={
        'stage':'1AM-F3-SCHEDULE-DIVERSIFIED-DEV-PILOT',
        'version':'v0.50.0',
        'result':'PASS_STRUCTURAL_DEV_PILOT_ONLY',
        'independent_rng_blocks':12,
        'schedule_families':list(FAMILIES),
        'arm_rates_bps':ARMS,
        'monitored_runs':72,
        'paired_uninstrumented_runs':24,
        'total_runs':96,
        'monitor_decisions':864,
        'diagnostic_windows':2592,
        'unknown_is_never_converted_to_sci_label':True,
        'no_scientific_F3_labels':True,
        'no_model_fit_or_validation_test':True,
        'pressure_proxy_has_not_been_scientifically_validated':True,
        'diagnostic_status_counts':[{'family':a,'arm':b,'horizon_ms':c,'status':d,'count':n}
            for (a,b,c,d),n in sorted(by_status.items())],
        'scientific_f3_status':'NO_GO_F3_CONSTRUCT_AND_PREDICTABILITY_NOT_VALIDATED',
        'Congestion':None,'FutureCongestion':None,
        'F3_ready':False,'GO_FREEZE':False,'training_ready':False,
    }
    out=pathlib.Path(out)
    require(not out.exists(),'REFUSE_TO_OVERWRITE_REPORT')
    out.mkdir(parents=True)
    write_csv(out/'run_evidence_96.csv',run_rows)
    write_csv(out/'online_predecision_864.csv',feature_rows)
    write_csv(out/'physical_window_diagnostics_2592.csv',window_rows)
    write_csv(out/'monitor_overhead_pairs_24.csv',cost_rows)
    (out/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    return summary


def main():
    p=argparse.ArgumentParser()
    p.add_argument('root',type=pathlib.Path)
    p.add_argument('--output',type=pathlib.Path,required=True)
    args=p.parse_args()
    try:
        result=audit(args.root,args.output)
        print(json.dumps(result,indent=2))
    except (AuditFailure,ValueError,KeyError,AssertionError,FileNotFoundError) as e:
        print('F3_DIVERSIFIED_DEV_AUDIT_FAILED:',e,file=sys.stderr)
        raise SystemExit(3)

if __name__=='__main__':main()
