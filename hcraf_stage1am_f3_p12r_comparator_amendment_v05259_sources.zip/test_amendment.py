import unittest,copy,json, pathlib
import amendment as a
class Guards(unittest.TestCase):
 def test_rtt_subset(self):self.assertEqual(a.RTT,['local_data_rtt_ewma_before_t','local_data_rtt_missing_at_t']);self.assertEqual(a.IDX,[10,11])
 def test_plan_change(self):
  p=json.loads(pathlib.Path('AMENDMENT_LOCK.json').read_text());q=copy.deepcopy(p);q['prediction']['primary']='changed'
  with self.assertRaises(RuntimeError):a.validate_plan(q,p)
 def test_locks(self):
  q=dict(a.LOCKS);a.locked(q);q['F3_ready']=True
  with self.assertRaises(RuntimeError):a.locked(q)
 def test_prior_equivalence(self):
  p=dict(names=['x'],weights=[1],means=[0],sds=[1],intercept=0);q=dict(names=['z','x'],weights=[0,1],means=[0,0],sds=[1,1],intercept=0)
  self.assertTrue(a.equivalent(p,q));q['weights'][0]=1;self.assertFalse(a.equivalent(p,q))
 def test_fit_repeat(self):
  x=[[0,1],[1,0],[2,0],[3,0]];y=[0,0,1,1];self.assertEqual(a.old.fit(x,y,a.RTT),a.old.fit(x,y,a.RTT))
 def test_fit_one_class(self):
  with self.assertRaises(RuntimeError):a.old.fit([[0,1],[1,0]],[1,1],a.RTT)
 def test_physical_locked(self):
  p=json.loads(pathlib.Path('AMENDMENT_LOCK.json').read_text());self.assertEqual(p['horizon_ns'],75000000);self.assertEqual(p['partition_seeds']['confirmation'],[620201,620236]);self.assertIn('27/36',p['physical_gates']['pressure']);self.assertIn('10000',p['physical_gates']['inference']);a.locked(p)
 def test_no_old_gate_erasure(self):
  p=json.loads(pathlib.Path('AMENDMENT_LOCK.json').read_text());self.assertTrue(p['prior_p12r_no_go_preserved']);self.assertIn('BLOCKED',p['prior_05254_prediction_gate']);self.assertIn('>=27 of 36',p['prediction']['primary'])
if __name__=='__main__':unittest.main()
