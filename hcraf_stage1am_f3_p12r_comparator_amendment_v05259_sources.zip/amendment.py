"""Prospective comparison amendment; DEV-only, no AP and no confirmation access."""
import json,sys,zipfile,pathlib,hashlib,math,tempfile,shutil
import freeze_dev as old
from reference_contract import LOCKS,BASE,FULL
P=pathlib.Path
PINS={'prereg':'746889957c3d91523fa937e7a888cef4e50d847c8596760f6b833ccdafe28ab2','dev':'f9fd01d7a22f03675033495b834d449d98ea35b8b4cafddb717eeadac7401992','freeze':'86aed069623b04b3c3786e0afc7fc97f7e1953313e836883b7b0265d034739e8','audit':'c2cd0984dfb63587dcd023663e9ed206afc0adb3c4b0edc6500a8d1139e7f49b'}
RTT=list(BASE[-2:]); IDX=[FULL.index(k) for k in RTT]
STATUS='PASS_P12R_COMPARATOR_AMENDMENT_RTT_FROZEN_ONLY_NO_F3_RELEASE'
def need(x,m):
 if not x:raise RuntimeError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def dig(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def put(p,o):p.write_text(json.dumps(o,indent=2,sort_keys=True,allow_nan=False)+'\n')
def locked(r):need(all(k in r and r[k]==v for k,v in LOCKS.items()),'LOCKS')
def equivalent(b0,b1):
 idx=[b1['names'].index(k) for k in b0['names']]
 return b0['intercept']==b1['intercept'] and all(b0[k]==[b1[k][i] for i in idx] for k in ('weights','means','sds')) and all(w==0 for i,w in enumerate(b1['weights']) if i not in idx)
def plan_for(parent,pr):
 return dict(protocol='P12R_NEW_CONSTRUCT_COMPARATOR_AMENDMENT_05259',parent_plan_sha256=pr['files']['PLAN.json'],parent_matrix_sha256=pr['files']['LOCKED_MATRIX.csv'],parent_schedule_sha256=pr['files']['LOCKED_PROBE_SCHEDULE.csv'],parent_zip_sha256=PINS,prior_p12r_no_go_preserved=True,prior_05254_prediction_gate='BLOCKED_IDENTICAL_B0_B1_FUNCTIONS; strict improvement mathematically impossible, not empirically tested on confirmation',scope=parent['scope'],definition=parent['definition'],horizon_ns=parent['horizon_ns'],capacity_packets=parent['capacity_packets'],arms=parent['arms'],sites=parent['sites'],engineering=parent['engineering'],partition_seeds=parent['partition_seeds'],physical_gates=parent['physical_gates'],prediction=dict(hypothesis='Fixed B0 predicts candidate future branch pressure better than fixed RTT-only and constant DEV prevalence; not a new feature-discovery or superiority claim for B1',candidate='B0 unchanged from v05257',baseline='RTT_ONLY uses the final two B0 features only; same exact SGD implementation, rows, scaling, shuffle and hyperparameters as v05257',baseline_features=RTT,constant='exact DEV positive fraction, tied score for all rows; empirical confirmation prevalence is separate reference',old_B1='preserve bytes and report equality; no additional hypothesis test',fit=parent['prediction']['fit'],causality=parent['prediction']['causality'],unit=parent['prediction']['unit'],scoring='linear logit b + sum(w*clip((x-mu)/sd,-5,5)) in frozen feature order, CPython3.13.5, no rounding, no sigmoid saturation; descending score exact tie groups; noninterpolated AP sum precision at group end * recall increment',primary='all 68040 selected episodes; AP_B0 > AP_RTT_ONLY and AP_B0 > empirical confirmation prevalence (AP_CONSTANT); strictly positive B0 minus RTT AP in >=27 of 36 seeds; lower bound of two-sided 97.5% paired whole-seed percentile type7 bootstrap CI for AP_B0-AP_RTT_ONLY > 0',bootstrap=parent['physical_gates']['inference'],invalid='any incomplete case, invalid row, one-class seed, invalid draw or mismatched seal => no release; invalid replicate => INDETERMINATE; no exclusions or replacement',no_interim='no confirmation rows before freeze; no intermediate AP or stopping; one complete-data look; no tuning/refitting; no alternate comparator on failure',multiplicity='prospective amendment after DEV inspection and prior P12R NO_GO; not original preregistered B1 claim; nominal per-contrast 97.5% intervals; all physical and predictive gates jointly required; no universal validity or power guarantee',release=parent['prediction']['release']),**LOCKS)
def validate_plan(am,expected):need(am==expected,'AMENDMENT_NOT_EXACT')
def run(prereg,dev,freeze,audit,out):
 need(sys.version_info[:3]==(3,13,5),'PYTHON_VERSION');need(not out.exists(),'NO_OVERWRITE')
 for n,p in zip(PINS,(prereg,dev,freeze,audit)):need(dig(p)==PINS[n],n+'_ZIP_SHA')
 with zipfile.ZipFile(prereg) as z:
  pr=json.loads(z.read('p12r_prereg/PREREG_RECEIPT.json'));locked(pr);parent=json.loads(z.read('p12r_prereg/PLAN.json'))
  need(pr['status']=='PASS_P12R_NEW_CONSTRUCT_PREREG_ONLY_NO_EXECUTION_NO_RELEASE','PREREG_STATUS')
  for n,h in pr['files'].items():need(sha(z.read('p12r_prereg/'+n))==h,'PREREG_MEMBER')
 with zipfile.ZipFile(audit) as z:
  ar=json.loads(z.read('AUDIT_RECEIPT.json'));locked(ar);need(ar['status']=='PASS_DEV_DEGENERACY_AUDIT_CONFIRMATION_BLOCKED' and ar['identical_frozen_functions'] and not ar['strict_superiority_possible'] and ar['confirmation_rows_read']==ar['model_fits']==0 and not ar['confirmation_execution_authorized'],'AUDIT')
 with zipfile.ZipFile(freeze) as z:
  fr=json.loads(z.read('FREEZE_RECEIPT.json'));locked(fr);need(fr['status']=='PASS_P12R_NEW_CONSTRUCT_DEV_MODELS_FROZEN_ONLY_NO_F3_RELEASE' and fr['confirmation_rows_read']==0 and fr['pilot_rows_used_for_fit']==0 and not fr['confirmation_execution_authorized'],'FREEZE')
  for n,h in fr['files'].items():need(sha(z.read(n))==h,'FROZEN_MEMBER')
  original=z.read('FROZEN_MODELS.json');m=json.loads(original);locked(m)
 need(m['B0']['names']==list(BASE) and m['B1']['names']==list(FULL) and equivalent(m['B0'],m['B1']),'OLD_MODEL_EQUIVALENCE')
 need(dig(P(old.__file__))==m['fit_code_sha256']=='ff73ecff501c668a5e7085a293b1a8e213d995f161af7156f9d7642a1eba6109','FIT_CODE')
 am=json.loads(P(__file__).with_name('AMENDMENT_LOCK.json').read_text());validate_plan(am,plan_for(parent,pr))
 # Persist the locked hypothesis before loading DEV features or fitting RTT.
 out.mkdir();put(out/'AMENDMENT_LOCK.json',am);(out/'ORIGINAL_FROZEN_MODELS.json').write_bytes(original)
 with tempfile.TemporaryDirectory() as td:
  root=P(td)
  with zipfile.ZipFile(dev) as z:
   ns=z.namelist();need(len(ns)==len(set(ns)),'DUP_ZIP')
   for n in ns:
    if n.startswith('p12r57_dev/'):
     parts=P(n).parts;need('..' not in parts and not P(n).is_absolute(),'ZIP_PATH')
     z.extract(n,root)
  d=root/'p12r57_dev';need(dig(d/'DEV_RECEIPT.json')==fr['source_dev_receipt_sha256'],'DEV_RECEIPT_SHA')
  X,y,stats,count=old.load(prereg,d)
 need(len(y)==22680 and sum(y)==1618 and count==3240 and m['training_seeds']==list(range(620101,620113)),'DEV_COUNTS')
 rtt=old.fit([[x[j] for j in IDX] for x in X],y,RTT)
 b0=m['B0'];need(rtt['means']==b0['means'][-2:] and rtt['sds']==b0['sds'][-2:],'RTT_SCALE')
 need(any(b0['weights'][j]!=0 for j in range(len(BASE)-2)),'B0_NO_NON_RTT_SIGNAL')
 # This is only a structural non-identity gate, not empirical superiority.
 result=dict(B0=b0,B1=m['B1'],RTT_ONLY=rtt,CONSTANT=dict(score=sum(y)/len(y),numerator=sum(y),denominator=len(y)),original_model_sha256=sha(original),training_rows=len(y),training_positives=sum(y),training_seeds=m['training_seeds'],source_dev_receipt_sha256=fr['source_dev_receipt_sha256'],fit_code_sha256=dig(P(old.__file__)),python_version=sys.version.split()[0],shuffle_seed=old.SHUFFLE,amendment_sha256=dig(out/'AMENDMENT_LOCK.json'),**LOCKS)
 put(out/'FROZEN_COMPARATORS.json',result)
 put(out/'AMENDMENT_RECEIPT.json',dict(status=STATUS,model_fits=1,original_model_refits=0,training_rows=len(y),training_positives=sum(y),raw_files_verified=count,confirmation_rows_read=0,confirmation_cases_executed=0,confirmation_execution_authorized=False,heldout_rows_read=0,pilot_rows_used_for_fit=0,new_AP_computed=False,new_bootstrap_computed=False,official_F3_labels_constructed=0,prior_prediction_gate_blocked=True,prior_NO_GO_preserved=True,construct_validated=False,structural_nonidentity_only=True,files={n:dig(out/n) for n in ('AMENDMENT_LOCK.json','ORIGINAL_FROZEN_MODELS.json','FROZEN_COMPARATORS.json')},**LOCKS));print(STATUS)
if __name__=='__main__':run(*map(P,sys.argv[1:]))
