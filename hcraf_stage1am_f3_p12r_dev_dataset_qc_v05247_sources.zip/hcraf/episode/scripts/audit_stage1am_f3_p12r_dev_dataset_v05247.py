#!/usr/bin/env python3
"""P12R read-only dataset QC; never fit, score or simulate."""
import argparse,bisect,collections,csv,hashlib,io,json,math,pathlib,zipfile
RAW_SHA='c5e63aa1de79774088adeba73b914e0e45574694974e55d81fb0363ec1375577'
PREREG_SHA='dbb12863ca83c26b687b243211aaf698986b8d6f2f7b8656cffb06278751ae30'
MATRIX_SHA='ede56f2242648b1ef84b6408b3755f0a61876f98de7213a0d4c3b87088c1fc1f'
PLAN_SHA='b7196b2fcca560c7e0f72596db11be750116985e5c27495759fa7caff06faf9b'
ROOT='stage1am_f3_p12r_v05246/'
LOCK=dict(F3_ready=False,GO_FREEZE=False,training_ready=False,Congestion=None,FutureCongestion=None,heldout_release_authorized=False,Stage1AO_or_NSGAIII_authorized=False)
SEEDS=set(range(24901,24907)); H=75000000

def need(x,msg):
 if not x:raise RuntimeError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def file_sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def rows(b):return [json.loads(l) for l in b.splitlines() if l.strip()]
def unique(seq,key):
 d={}
 for a in seq:
  k=key(a);need(k not in d,'DUPLICATE '+str(k));d[k]=a
 return d
def locked(a):return all(k in a and a[k] is v for k,v in LOCK.items())
def close(a,b):return math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-10)
def y_at(drops,t):return int(bisect.bisect_right(drops,t+H)>bisect.bisect_right(drops,t))
def prefix(seq,t,o,key):
 need(type(o)==int and 0<=o<=len(seq),'ORDINAL_RANGE')
 if o:need(seq[o-1][key]<=t,'FUTURE_OBSERVATION')
 if o<len(seq):need(seq[o][key]>=t,'OMITTED_PAST_OBSERVATION')
 return seq[:o]
def replay(ev,t,o,face):
 past=prefix(ev,t,o,'time_ns');win=[e for e in past if t-H<e['time_ns']<=t]
 counts=[sum(e['event']==k and (j<3 or e['face_id']==face) for e in win) for j,k in enumerate(('interest_rx','data_rx','nack_rx','interest_tx','interest_drop'))]
 rt=[e['rtt_ms'] for e in past if e['event']=='rtt'];need(all(0<x<1e9 for x in rt),'RTT_RANGE');ewma=0.
 for i,x in enumerate(rt):ewma=x if i==0 else .125*x+.875*ewma
 return counts+[ewma,int(not rt)]
def remote(t,o,rr,nodes,ev):
 latest={}
 for a in prefix(rr,t,o,'receipt_ns'):latest[a['source_node_id'],a['source_device_index']]=a
 key=lambda a:(a['source_node_id'],a['source_device_index']);e=unique(ev['feature_evidence'],key);m=unique(ev['feature_missing_sources'],key);ks={(n,0) for n in nodes};need(set(e)|set(m)==ks and not(set(e)&set(m)) and {(a['node_id'],a['device_index']) for a in ev['selected_sender_sources']}==ks,'REMOTE_COVERAGE')
 out=[]
 for n in nodes:
  k=(n,0);a=latest.get(k)
  if a is None or t-a['sample_ns']>100000000:need(k in m,'MISSING_FLAG');out.extend([0,1,0]);continue
  need(k in e and e[k]['report_id']==a['report_id'] and a['sample_ns']<=a['receipt_ns']<=t and type(a['queue_packets_now'])==int and 0<=a['queue_packets_now']<=12,'REMOTE_CAUSAL');out.extend([a['queue_packets_now'],0,(t-a['sample_ns'])/1e6])
 return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--raw-zip',required=True);ap.add_argument('--prereg-zip',required=True);ap.add_argument('--output',required=True);a=ap.parse_args();out=pathlib.Path(a.output);need(not out.exists(),'NO_OVERWRITE');out.mkdir(parents=True)
 need(file_sha(a.raw_zip)==RAW_SHA and file_sha(a.prereg_zip)==PREREG_SHA,'INPUT_SHA')
 with zipfile.ZipFile(a.prereg_zip) as p:
  mn='HCRAF_F3_P12R_SOURCE_SHA256_v05237.json';m=json.loads(p.read(mn));need(set(p.namelist())==set(m['files'])|{mn},'PREREG_MEMBERS')
  for k,v in m['files'].items():need(sha(p.read(k))==v,'PREREG_MEMBER_HASH')
  mp=next(n for n in p.namelist() if n.endswith('P12R_LOCKED_MATRIX_504_v05237.csv'));pp=next(n for n in p.namelist() if n.endswith('P12R_FAIR_COMPARATOR_PROSPECTIVE_PLAN_v05237.json'));need(sha(p.read(mp))==MATRIX_SHA and sha(p.read(pp))==PLAN_SHA,'MATRIX_PLAN_HASH');plan=json.loads(p.read(pp));need(locked(plan),'PLAN_LOCKS')
  allrows=list(csv.DictReader(io.StringIO(p.read(mp).decode())));dev=[r for r in allrows if r['partition']=='FAIR_LOCAL_DEV'];key=lambda r:(int(r['seed']),r['site'],r['load'],r['telemetry']);need(len(allrows)==504 and len(dev)==72 and set(unique(dev,key))=={(s,i,l,t) for s in SEEDS for i in ('producer_egress','transit_middle','consumer_ingress') for l in ('low_control','high_pressure') for t in ('off','on_20ms')},'MATRIX')
  schedules={}
  for r in dev:
   b=p.read(str(pathlib.PurePosixPath(mp).parent/'plans'/r['schedule_filename']));need(sha(b)==r['schedule_sha256'] and r['execution_authorized_now']==r['validation_or_heldout_released']=='false','SCHEDULE_LOCK');sr=list(csv.DictReader(io.StringIO(b.decode())));need(len(sr)==128 and all(x['split']=='FAIR_LOCAL_DEV' for x in sr),'SCHEDULE_ROWS');schedules[r['schedule_filename']]=sr
 b1=plan['feature_sets']['strengthened_local_B1_primary_control'];rf=plan['feature_sets']['remote_plus_B1_R_primary_treatment'];need(len(b1)==12 and len(rf)==21 and rf[:12]==b1,'FEATURE_ORDER')
 rec=[];times={};stats=[];raw_count=0;receipt_hashes={}
 with zipfile.ZipFile(a.raw_zip) as z:
  names=z.namelist();need(len(names)==len(set(names)),'ZIP_DUPLICATE');agg=json.loads(z.read(ROOT+'P12R_DEV_COLLECTION_RECEIPT_v05246.json'));need(locked(agg) and agg['status']=='PASS_72_P12R_DEV_RAW_COLLECTION_ONLY_NO_TRAINING' and agg['development_cases']==72 and agg['primary_arm_decisions']==4608 and agg['model_fits']==agg['confirmation_cases']==agg['diagnostic_rows_used']==0 and not agg['new_AP_computed'],'PARENT_RECEIPT')
  cases={n[len(ROOT):-len('/case_receipt.json')] for n in names if n.startswith(ROOT) and n.endswith('/case_receipt.json')};need(cases=={r['seed']+'/'+r['site']+'_'+r['load']+'_'+r['telemetry'] for r in dev},'CASE_SET')
  for r in dev:
   seed,site,load,arm=key(r);case=f'{seed}/{site}_{load}_{arm}';p=ROOT+case+'/';cb=z.read(p+'case_receipt.json');c=json.loads(cb);need(locked(c) and c['status']=='PASS_DEV_RAW_COLLECTION_QC_ONLY' and c['case']==r and c['decisions']==128 and c['model_fits']==c['confirmation_cases']==0 and not c['new_AP_computed'],'CASE_RECEIPT');receipt_hashes[case]=sha(cb)
   files=c['raw_file_sha256'];need(set(files)=={n[len(p):] for n in names if n.startswith(p) and n!=p+'case_receipt.json'},'RAW_FILES');keep={}
   for n,h in files.items():
    b=z.read(p+n);need(sha(b)==h,'RAW_HASH '+n);raw_count+=1
    if n in ('scenario.json','fault_events.jsonl','consumer_events.jsonl.arrivals.jsonl','competitor_events.jsonl.arrivals.jsonl','p12v_native_local_12_at_decision.jsonl','p12v_native_local_12_at_decision.jsonl.events.jsonl','p12t_native_local_at_decision.jsonl','nfd_local_queue_at_decision.jsonl','events.jsonl.decisions.jsonl','events.jsonl.collection.jsonl','link_events.jsonl','pathwide_witness_b.jsonl','queue_telemetry_decisions.jsonl','queue_telemetry_receipts.jsonl','queue_telemetry_sent.jsonl','queue_telemetry_requests.jsonl','observer_cost.jsonl','nfd_dispatch_cost.jsonl'):keep[n]=b
   def read(n):return rows(keep[n])
   sc=json.loads(keep['scenario.json']);need(sc['research_partition']=='FAIR_LOCAL_DEV' and sc['independent_rng_block']==sc['run']==seed and sc['schedule_csv_filename']==r['schedule_filename'] and sc['phase_arm']==r['arm'] and sc['intervention_location']==r['location'] and sc['intervention_return_bps']==12000000 and sc['queue_capacity_packets']==12 and sc['selected_face_slot']==int(r['selected_slot']) and sc['p4_prospective_load']==load and sc['telemetry_enabled']==(arm=='on_20ms') and sc['telemetry_period_ms']==20 and sc['loss_probability']==0 and not read('fault_events.jsonl'),'SCENARIO')
   for k in ('traffic','routing','telemetry'):need(sc['p4_locked_'+k+'_stream_seed']==int(r[k+'_stream_seed']),'RNG_STREAM')
   for kind,n in [('TARGET','consumer_events.jsonl.arrivals.jsonl'),('INDEPENDENT_COMPETITOR','competitor_events.jsonl.arrivals.jsonl')]:
    ex={(int(x['sequence']),int(x['time_ns'])) for x in schedules[r['schedule_filename']] if x['traffic_class']==kind};ac=read(n);need(len(ac)==len(ex) and {(x['sequence'],x['time_ns']) for x in ac}==ex,'ARRIVALS')
   face=sc['selected_face_id'];nodes=[sc['selected_relay_node_id'],sc['selected_mid_node_id'],sc['selected_producer_node_id']];need(len(set(nodes))==3 and sc['path_nodes']==[0,1]+nodes,'PATH')
   def drop_keys(seq,t):return collections.Counter((x[t],x['node_id'],x['device_index'],x['packet_uid']) for x in seq if x['event_type']=='QUEUE_DROP' and x['node_id'] in nodes and x['device_index']==0)
   da=drop_keys((json.loads(l) for l in keep['link_events.jsonl'].splitlines() if b'QUEUE_DROP' in l),'time_ns');db=drop_keys((json.loads(l) for l in keep['pathwide_witness_b.jsonl'].splitlines() if b'QUEUE_DROP' in l),'timestamp_ns');need(da==db,'WITNESS_MISMATCH '+case);drops=sorted(k[0] for k in da.elements())
   ev=read('p12v_native_local_12_at_decision.jsonl.events.jsonl');need(all(e['ordinal']==i and e['node_id']==1 and e['face_id']>0 and e['event'] in ('interest_rx','data_rx','nack_rx','interest_tx','interest_drop','rtt') and e['name'].startswith(('/hcraf/pilot/','/hcraf/competitor/')) for i,e in enumerate(ev,1)) and all(x['time_ns']<=y['time_ns'] for x,y in zip(ev,ev[1:])),'EVENT_PROVENANCE')
   native=read('p12v_native_local_12_at_decision.jsonl');idx=lambda n:unique(read(n),lambda x:x['decision_id']);first=idx('p12t_native_local_at_decision.jsonl');d=idx('events.jsonl.decisions.jsonl');col=idx('events.jsonl.collection.jsonl');q=unique(read('nfd_local_queue_at_decision.jsonl'),lambda x:(x['decision_id'],x['candidate_face_id']));need(len(native)==len(first)==len(d)==len(col)==128 and len(q)==384,'DECISION_COUNT')
   request_bytes=sent_bytes=receipt_bytes=0;request_count=sent_count=receipt_count=0
   if arm=='on_20ms':
    requests=read('queue_telemetry_requests.jsonl');request_count=len(requests);request_bytes=sum(x['interest_wire_bytes'] for x in requests);need(request_count>0 and {x['role'] for x in requests}=={'relay','mid','producer'},'POLL_ROLES')
    for role in ('relay','mid','producer'):
     pts=[x['time_ns'] for x in requests if x['role']==role];need(len(pts)>1 and all(y-x==20000000 for x,y in zip(pts,pts[1:])),'POLL_PERIOD')
    rem=idx('queue_telemetry_decisions.jsonl');rr=read('queue_telemetry_receipts.jsonl');sent=unique(read('queue_telemetry_sent.jsonl'),lambda x:x['role']+'-'+str(x['sequence']));need(len(rem)==128 and len(unique(rr,lambda x:x['report_id']))==len(rr),'REMOTE_COUNT')
    sent_count=len(sent);receipt_count=len(rr);sent_bytes=sum(x['data_wire_bytes'] for x in sent.values());receipt_bytes=sum(x['data_wire_bytes'] for x in rr)
    for x in sent.values():need(x['source_node_id']==dict(zip(('relay','mid','producer'),nodes))[x['role']] and x['source_device_index']==0,'SENDER_ROLE')
    for i,x in enumerate(rr,1):
     need(x['receipt_ordinal']==i and x['sample_ns']<=x['receipt_ns'] and (i==1 or rr[i-2]['receipt_ns']<=x['receipt_ns']),'RECEIPT_ORDER');s=sent[x['report_id']];need(all(x[k]==s[k] for k in ('source_node_id','source_device_index','sample_ns','sequence','payload_bytes','data_wire_bytes')),'SENT_MATCH')
   else:need(not any(k.startswith('queue_telemetry_') for k in keep),'OFF_TELEMETRY');rem={};rr=[]
   ts=[];ys=[];vectors=[];last=0;last_r=0;missing=0
   for i,n in enumerate(native,1):
    t=n['time_ns'];v=n['b1_all_twelve_native'];f=first[i];qq=q[i,face];dd=d[i];cc=col[i];o=n['event_ordinal'];need(n['decision_id']==i and n['node_id']==1 and n['selected_face_id']==face and n['source']=='NFD_LIVE_EVENT_SIGNALS_PLUS_NODE1_QUEUE_BEFORE_TX' and f['time_ns']==dd['time_ns']==cc['time_ns']==qq['sim_time_ns']==t and cc['selected_face_id']==face and qq['observed_before_forwarding'] and not qq['remote_node_queue_accessed'],'DECISION_ALIGN')
    need(len(v)==12 and all(math.isfinite(x) for x in v) and len(f['b1_first_five_native'])==5 and all(abs(x-y)<1e-5 for x,y in zip(v[:5],f['b1_first_five_native'])),'B1_FINITE');need([a['routing_cost'] for a in dd['candidates'] if a['face_id']==face]==[v[0]] and v[1]==qq['queue_packets'] and abs(v[2]-qq['local_queue_occupancy_fraction'])<1e-5 and close(v[2],qq['queue_packets']/qq['capacity_packets']) and v[3]==int(qq['link_up']),'LOCAL_STATE');need(o>=last and (not ts or t>=ts[-1]) and not n['model_training_authorized'] and not n['F3_ready'] and not n['GO_FREEZE'],'LOCAL_ORDER');last=o;rp=replay(ev,t,o,face);need(v[5:10]==rp[:5] and close(v[10],rp[5]) and v[11]==rp[6],'REPLAY')
    y=y_at(drops,t);ts.append(t);ys.append(y);vectors.append(tuple(v))
    if arm=='on_20ms':
     x=rem[i];ro=x['receipt_ordinal'];need(x['decision_ns']==t and ro>=last_r and x['selected_path_id']=='node1-face-'+str(face),'REMOTE_ALIGN');last_r=ro;rv=remote(t,ro,rr,nodes,x);missing+=sum(rv[j] for j in (1,4,7));rec.append(([seed,site,load,i,t],v+rv,y))
   obs=read('observer_cost.jsonl');cpu=read('nfd_dispatch_cost.jsonl');need(len(obs)==len(cpu)==128,'COST_COUNT');times[seed,site,load,arm]=ts;stats.append(dict(seed=seed,site=site,load=load,telemetry=arm,decisions=128,positive=sum(ys),selected_path_drops=len(drops),distinct_B1=len(set(vectors)),remote_missing=missing,telemetry_requests=request_count,telemetry_data_sent=sent_count,telemetry_data_received=receipt_count,telemetry_interest_wire_bytes=request_bytes,telemetry_data_sent_wire_bytes=sent_bytes,telemetry_data_received_wire_bytes=receipt_bytes,observer_wall_ns_sum=sum(x['snapshot_observer_wall_ns'] for x in obs),nfd_path_wall_ns_sum=sum(x['NFD_forwarding_path_wall_ns'] for x in cpu),nfd_path_cpu_ns_sum=sum(x['NFD_forwarding_path_cpu_ns'] for x in cpu)));print('PASS_CASE_QC',case,flush=True)
  need(agg['case_receipt_sha256']==receipt_hashes,'CASE_HASHES')
 for s,i,l,t in times:
  if t=='off':need(times[s,i,l,t]==times[s,i,l,'on_20ms'],'PAIRED_TIMES')
 need(len(rec)==4608 and len(set(tuple(k) for k,v,y in rec))==4608,'PRIMARY_COUNT');rec.sort(key=lambda a:a[0]);byseed={s:[(k,v,y) for k,v,y in rec if k[0]==s] for s in sorted(SEEDS)};distinct={str(s):len({tuple(v[:12]) for k,v,y in a}) for s,a in byseed.items()};pos={str(s):sum(y for k,v,y in a) for s,a in byseed.items()};dv=len({tuple(v[:12]) for k,v,y in rec});need(all(len(a)==768 for a in byseed.values()) and dv>1 and 0<sum(pos.values())<4608,'DEVELOPMENT_SANITY')
 def write(n,h,seq):
  with (out/n).open('w',newline='') as f:w=csv.writer(f,lineterminator='\n');w.writerow(h);w.writerows(seq)
 write('B1_development_features.csv',b1,(v[:12] for k,v,y in rec));write('R_development_features.csv',rf,(v for k,v,y in rec));write('development_research_endpoint.csv',['future_selected_path_device0_queue_drop_75ms'],([y] for k,v,y in rec));write('development_audit_keys_NOT_FEATURES.csv',['seed','site','load','decision_id','decision_time_ns'],(k for k,v,y in rec));write('case_qc.csv',list(stats[0]),([x[k] for k in stats[0]] for x in stats))
 report=dict(status='PASS_P12R_DEV_DATASET_QC_ONLY_NO_FIT_NO_CONFIRMATION',parent_run=45955373789,parent_artifact=15180634595,parent_raw_sha256=RAW_SHA,prereg_sha256=PREREG_SHA,raw_files_checked=raw_count,development_cases=72,decisions_audited=9216,primary_rows=4608,positive=sum(pos.values()),negative=4608-sum(pos.values()),positives_by_seed=pos,distinct_B1_by_seed=distinct,distinct_B1_total=dv,constant_B1_features=[b1[i] for i in range(12) if len({v[i] for k,v,y in rec})==1],remote_missing=sum(x['remote_missing'] for x in stats),selected_path_drop_events_both_arms=sum(x['selected_path_drops'] for x in stats),paired_times_match=36,model_fits=0,new_AP_computed=False,confirmation_cases=0,diagnostic_rows_used=0,development_research_endpoint_only=True,official_F3_labels_constructed=0,feature_order_B1=b1,feature_order_R=rf,output_sha256={p.name:file_sha(p) for p in sorted(out.glob('*.csv'))},**LOCK)
 (out/'P12R_DEV_DATASET_QC_RECEIPT_v05247.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print(json.dumps(report,sort_keys=True),flush=True)
if __name__=='__main__':main()
