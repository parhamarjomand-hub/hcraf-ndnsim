#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
bash "$TASK/scripts/build_stage1am_f3_queue_telemetry_smoke_v0522.sh"
cd "$ROOT/episode_sources/ns-3"
cp "$TASK/src/hcraf-stage1am-f3-p12t-native-development-v05239.cpp" scratch/hcraf-stage1am-f3-p12t-native-development-v05239.cc
cp "$TASK/src/hcraf-stage1am-f3-p12s-local-causal-meter-v05238.hpp" scratch/hcraf-stage1am-f3-p12s-local-causal-meter-v05238.hpp
cmp -s "$TASK/src/hcraf-stage1am-f3-p12t-native-development-v05239.cpp" scratch/hcraf-stage1am-f3-p12t-native-development-v05239.cc
cmp -s "$TASK/src/hcraf-stage1am-f3-p12s-local-causal-meter-v05238.hpp" scratch/hcraf-stage1am-f3-p12s-local-causal-meter-v05238.hpp
python3 ./waf -j 2
test -x build/scratch/hcraf-stage1am-f3-p12t-native-development-v05239
