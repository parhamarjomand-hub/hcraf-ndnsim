#!/usr/bin/env python3
"""P12-T: ONE native ndnSIM development instrumentation smoke, NO AP, NO FIT."""
import argparse,csv,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
DOC=ROOT/'hcraf/episode/docs/1AM/F3_P12R_FAIR_COMPARATOR_PREREG_v0.52.37'
OUT=ROOT/'episode_output/stage1am_f3_p12t_v05239/dev_seed_24901_sentinel'
BIN='hcraf-stage1am-f3-p12t-native-development-v05239'
FLAGS=dict(F3_ready=False,GO_FREEZE=False,training_ready=False,
           Congestion=None,FutureCongestion=None,heldout_release_authorized=False)
def need(cond,msg):
 if not cond:raise RuntimeError('P12T_'+msg)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def plan():
 with (DOC/'P12R_LOCKED_MATRIX_504_v05237.csv').open(newline='') as f:rows=list(csv.DictReader(f))
 need(len(rows)==504,'MATRIX_CHANGED')
 need(set(int(r['seed']) for r in rows if r['partition']=='FAIR_LOCAL_DEV')==set(range(24901,24907)),'WRONG_DEV_SEEDS')
 need(set(int(r['seed']) for r in rows if r['partition']=='FAIR_LOCAL_CONFIRM')==set(), 'BAD_CONFIRM_PARTITION')
 candidates=[r for r in rows if r['seed']=='24901' and r['site']=='producer_egress' and r['load']=='high_pressure' and r['telemetry']=='on_20ms']
 need(len(candidates)==1,'NO_UNIQUE_DEV_SENTINEL')
 r=candidates[0]
 need(r['partition']=='FAIR_LOCAL_DEV' and r['execution_authorized_now']=='false' and r['validation_or_heldout_released']=='false','PRE_REG_FLAGS_TAMPERED')
 need(int(r['selected_slot'])==0 and r['arm']=='PRODUCER_RETURN_12M','BAD_SENTINEL_SITE')
 path=DOC/'plans'/r['schedule_filename'];need(path.is_file() and sha(path)==r['schedule_sha256'],'IMMUTABLE_SCHEDULE_SHA_CHANGED')
 need(r['schedule_filename']=='p12r-v05237-fair_local_dev-seed-24901-producer_egress-slot-0-high_pressure.csv','WRONG_FILE')
 with path.open(newline='') as f:rows_csv=list(csv.DictReader(f))
 need(len(rows_csv)==128 and {x['traffic_class'] for x in rows_csv}=={'TARGET','INDEPENDENT_COMPETITOR'},'WRONG_SCHEDULE_ROWS')
 need(sum(x['traffic_class']=='TARGET' for x in rows_csv)==12 and sum(x['traffic_class']=='INDEPENDENT_COMPETITOR' for x in rows_csv)==116,'WRONG_TRAFFIC_COUNTS')
 need(all(x['family']=='P12R_NEW_FAIR_COMPARATOR_PROSPECTIVE_PREREG_ONLY' and x['split']=='FAIR_LOCAL_DEV' and x['schedule_schema']=='HCRAF_F3_P12R_FAIR_COMPARATOR_STUDY_V05237' for x in rows_csv),'WRONG_SCHEDULE_SCHEMA')
 return r,path

def cmd(r,schedule):
 return BIN+' '+' '.join([
  f"--pathArm={r['arm']}",f"--interventionLocation={r['location']}",
  '--interventionReturnBps=12000000','--lossProbability=0','--lossStream=79',
  '--lossReceiverNodeId=-1','--lossReceiverDeviceIndex=-1',
  '--scheduleFamily=P12R_NEW_FAIR_COMPARATOR_PROSPECTIVE_PREREG_ONLY',
  f'--scheduleCsv={schedule}',f"--prospectiveLoad={r['load']}",
  f"--prospectiveTrafficStreamSeed={r['traffic_stream_seed']}",
  f"--prospectiveRoutingStreamSeed={r['routing_stream_seed']}",
  f"--prospectiveTelemetryStreamSeed={r['telemetry_stream_seed']}",
  f"--selectedSlot={r['selected_slot']}",f"--run={r['seed']}",f'--output={OUT}',
  '--instrument=1','--topology=DEV_CHAIN_L','--mode=LP_INDEPENDENT_COMPETITOR_NO_DROP',
  '--seed=17','--lifetimeMs=2600','--requestCount=12','--intervalNs=330000000',
  '--competitorCount=116','--competitorIntervalNs=3600000','--competitorOffsetNs=0',
  '--targetOffsetNs=260000000','--forwardBps=50000000','--returnBps=50000000',
  '--technicalQueueMaxPackets=12','--telemetryEnabled=1','--telemetryPeriodMs=20'])

def audit_output(r):
 import collections
 file=OUT/'p12t_native_local_at_decision.jsonl'
 need(file.is_file(),'MISSING_NATIVE_DIAGNOSTIC')
 entries=[json.loads(line) for line in file.read_text().splitlines() if line.strip()]
 need(len(entries)==128 and len(set(a['decision_id'] for a in entries))==128,'WRONG_DECISIONS_OR_DUPLICATES')
 need(all(a['node_id']==1 and a['selected_face_id']>0 and a['source']=='NFD_BEGIN_DECISION_AND_LOCAL_NS3_QUEUE' for a in entries),'NONLOCAL_SOURCE')
 need(all(a['all_B1_features_valid'] is False and a['model_training_authorized'] is False for a in entries),'FALSE_READINESS_CLAIM')
 need(all(len(a['b1_first_five_native'])==5 and 0<=a['b1_first_five_native'][2]<=1 for a in entries),'INVALID_NATIVE_FIVE')
 need(all(x['time_ns']<=y['time_ns'] for x,y in zip(entries,entries[1:])),'NONMONOTONE_TIMES')
 scenario=json.loads((OUT/'scenario.json').read_text())
 need(scenario['independent_rng_block']==24901 and scenario['research_partition']=='FAIR_LOCAL_DEV','NOT_NEW_DEV')
 need(scenario['schedule_csv_filename']==r['schedule_filename'],'WRONG_RECORDED_SCHEDULE')
 # Cross-check pre-send capture against unchanged original native local queue trace.
 old=[json.loads(x) for x in (OUT/'nfd_local_queue_at_decision.jsonl').read_text().splitlines() if x.strip()]
 lookup={(x['decision_id'],x['candidate_face_id']):x for x in old}
 need(len(lookup)==3*128,'MISSING_BASELINE_SELECTED_FACE_SNAPSHOTS')
 for a in entries:
  o=lookup[(a['decision_id'],a['selected_face_id'])]
  need(a['time_ns']==o['sim_time_ns'] and a['b1_first_five_native'][1]==o['queue_packets'],'PIT_QUEUE_NATIVE_DESYNC')
  need(abs(a['b1_first_five_native'][2]-o['local_queue_occupancy_fraction'])<1e-9,'NATIVE_QUEUE_FRACTION_NOT_LOCKED')
 # No retroactively claiming training-ready B1 from a five-feature diagnostic.
 result=dict(status='PASS_P12T_ONE_DEV_SENTINEL_REAL_NDNSIM_PARTIAL_NATIVE_WIRING_ONLY',
    seed=24901,case_count=1,case_site='producer_egress',load='high_pressure',telemetry='on_20ms',
    native_decision_snapshots=128,native_local_features_valid_count=5,
    complete_B1_valid=False,missing_NFD_interest_data_nack_hooks=True,
    selected_face_packet_counter_requires_NDN_interest_filtering=True,
    locally_completed_RTT_hook_missing=True,decision_times_match_NFD_native=True,
    actual_native_queue_trace_matched=True,train_or_confirmatory_not_authorized=True,
    new_AP_computed=False,new_bootstrap_computed=False,model_fits=0,heldout_reads=0,
    confirmation_seed_reads=0,**FLAGS)
 (OUT/'P12T_NATIVE_INTEGRATION_SENTINEL_RECEIPT_v05239.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
 print(result['status'])
 return result

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--preflight-only',action='store_true');a=ap.parse_args()
 r,p=plan();print('PASS_P12T_FROZEN_DEV_SENTINEL',r['seed'],r['schedule_sha256'])
 if a.preflight_only:return
 need(not OUT.exists(),'REFUSE_OVERWRITE_AND_REPEAT')
 need((ROOT/'episode_sources/ns-3/build/scratch'/BIN).is_file(),'MISSING_PINNED_NDNSIM_BINARY')
 OUT.mkdir(parents=True)
 command=cmd(r,p);(OUT/'command.txt').write_text(command+'\n')
 with (OUT/'simulator.log').open('w') as log:
  subprocess.run(['python3','./waf','--run-no-build',command],cwd=ROOT/'episode_sources/ns-3',stdout=log,stderr=subprocess.STDOUT,check=True)
 audit_output(r)
if __name__=='__main__':main()
