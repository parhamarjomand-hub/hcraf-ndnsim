# HCRAF F3 — P12-T / v0.52.39 — فاز مقدماتی اتصال بومی به ndnSIM

این بسته تنها **یک سناریوی توسعهٔ ازپیش‌ثبت‌شده** را در ndnSIM اجرا می‌کند: بذر 24901، محل producer_egress، بار high_pressure، تله‌متری on_20ms. هیچ بذر از مجموعهٔ تأییدی 25001 تا 25036 خوانده یا اجرا نمی‌شود. هیچ مدلی آموزش داده نمی‌شود و هیچ AP محاسبه نمی‌شود.

## آنچه واقعاً متصل می‌شود
- Callback `hcrafSetDecisionObserver` بومی NFD در گره ۱، پیش از ارسال Face منتخب.
- Snapshot بومی `PointToPointNetDevice::GetQueue()` و وضعیت Link، Route cost.
- شمار PIT همان گره از `nfd::Forwarder::getPit().size()` در زمان تصمیم.
- رخدادهای واقعی Enqueue/Drop صف بومی دستگاه؛ شمار فریم‌ها **معادل شمار Interestهای Face نیست**.
- ۱۲۸ snapshot با تطبیق یک‌به‌یک با جریان تاریخی `nfd_local_queue_at_decision.jsonl` و بررسی تقدم زمانی.

## محدودهٔ اعتبار
این بسته فقط **۵ ویژگی اول B1** را در اتصال بومی گره ۱ ممیزی می‌کند و برای ۷ ویژگی بعدی اعلان عدم‌تکمیل می‌دهد. شمار Interest/Data/Nack واقعی NFD، TX Interest واقعی Face، و RTT تکمیل‌شده هنوز callbackهای دقیق NFD لازم دارند؛ برآورد آن‌ها از روی فریم‌های لایهٔ ۲ مجاز نیست. بنابراین `complete_B1_valid=false`, `model_training_authorized=false`, `F3_ready=false`, `GO_FREEZE=false` باقی می‌ماند.

مرحلهٔ بعد پس از تأیید کامپایل/اجرای این sentinel، اتصال رویدادهای native NFD به LocalCausalMeter و سپس اجرای کامل ۶ بذر توسعه خواهد بود. هیچ دستکاری در P12-R، مطالعهٔ قبلی P12-N یا Heldout مجاز نیست.
