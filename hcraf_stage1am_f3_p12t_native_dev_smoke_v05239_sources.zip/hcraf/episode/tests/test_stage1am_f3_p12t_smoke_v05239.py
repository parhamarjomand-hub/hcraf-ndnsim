import importlib.util,unittest,inspect,pathlib,sys,json
from unittest.mock import patch
ROOT=pathlib.Path(__file__).resolve().parents[3]
script=ROOT/'hcraf/episode/scripts/run_stage1am_f3_p12t_smoke_v05239.py'
spec=importlib.util.spec_from_file_location('p12t_smoke',script);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Guard(unittest.TestCase):
 def test_dev_locked(self):
  r,p=m.plan();self.assertEqual(r['seed'],'24901');self.assertEqual(r['site'],'producer_egress')
 def test_no_training(self):
  self.assertNotIn('average_precision',inspect.getsource(m));self.assertNotIn('LogisticRegression',inspect.getsource(m))
 def test_no_confirmation_case_select(self):
  self.assertIn("r['seed']=='24901'",inspect.getsource(m.plan))
 def test_no_posthoc_fallback(self):
  self.assertIn('NO_UNIQUE_DEV_SENTINEL',inspect.getsource(m.plan))
 def test_all_science_flags(self):
  self.assertIs(m.FLAGS['F3_ready'],False);self.assertIs(m.FLAGS['GO_FREEZE'],False)
 def test_single_sentinel_build(self):
  r,p=m.plan();c=m.cmd(r,p);self.assertIn('--run=24901',c);self.assertIn('--telemetryEnabled=1',c)
 def test_no_confirmation_in_binary(self):
  path=ROOT/'hcraf/episode/src/hcraf-stage1am-f3-p12t-native-development-v05239.cpp'
  t=path.read_text();self.assertIn('P12T_ONLY_P12R_DEV_SENTINEL_CASE_24901',t)
  self.assertNotIn('{{25001u',t)
 def test_native_enqueues_not_aliased(self):
  t=(ROOT/'hcraf/episode/src/hcraf-stage1am-f3-p12t-native-development-v05239.cpp').read_text()
  self.assertIn('raw_frames_not_equated_with_ndn_interest_counts',t)
 def test_incomplete_B1_explicit(self):
  t=(ROOT/'hcraf/episode/src/hcraf-stage1am-f3-p12t-native-development-v05239.cpp').read_text()
  self.assertIn('all_B1_features_valid',t)
  self.assertIn('completed_local_rtt_hook_wired',t)
 def test_bad_schedule_rejected(self):
  with patch.object(m,'MATRIX',None,create=True):
   r,p=m.plan();self.assertEqual(r['partition'],'FAIR_LOCAL_DEV')
if __name__=='__main__':unittest.main()
