// HCRAF instrumentation Stage 1B.1 (episode schema 0.2). No forwarding-policy decisions are made here.
#ifndef HCRAF_RECORDER_HPP
#define HCRAF_RECORDER_HPP
#include <cstdint>
#include <iomanip>
#include "hcraf-state.hpp"
#include <array>
#include <fstream>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>

namespace hcraf {
class Recorder {
public:
  Recorder(const std::string& path, uint32_t node, const std::string& prefix = "")
    : m_out(path), m_node(node), m_prefix(prefix), m_decisions(path + ".decisions.jsonl"), m_states(path + ".states.jsonl") {
    if (!m_states) throw std::runtime_error("Cannot open states trace");
    m_states << std::setprecision(17);
    if (!m_decisions) throw std::runtime_error("Cannot open decisions trace");
    if (!m_out) throw std::runtime_error("Cannot open HCRAF event file: " + path);
    if (!m_prefix.empty()) {
      m_background.open(path + ".background.jsonl");
      if (!m_background) throw std::runtime_error("Cannot open background trace");
    }
  }
  // ndn-cxx at the pinned revision represents Nonce as four network-order
  // bytes (Interest::Nonce publicly derives from std::array<uint8_t, 4>).
  // Explicit shifts avoid host-endian and signed-overflow dependence.
  static int64_t nonceValue(const std::array<uint8_t, 4>& bytes) noexcept {
    return (int64_t(bytes[0]) << 24) | (int64_t(bytes[1]) << 16) |
           (int64_t(bytes[2]) << 8) | int64_t(bytes[3]);
  }
  static std::string quote(const std::string& s) {
    const char* hex = "0123456789abcdef";
    std::string out = "\"";
    for (unsigned char c : s) {
      if (c == '\"' || c == '\\') { out += '\\'; out += c; }
      else if (c < 32) { out += "\\u00"; out += hex[c >> 4]; out += hex[c & 15]; }
      else out += c;
    }
    return out + '\"';
  }
  struct Candidate { uint64_t face; uint64_t routingCost; };
  bool inScope(const std::string& name) const {
    return m_prefix.empty() || name == m_prefix ||
      name.compare(0, m_prefix.size() + 1, m_prefix + "/") == 0;
  }
  uint64_t beginDecision(const void* pit, const std::string& name, int64_t now,
                         uint64_t ingress, const std::string& fibPrefix,
                         const std::vector<Candidate>& candidates) {
    if (!inScope(name)) return 0;
    if (m_activeDecision) throw std::runtime_error("Nested decision unsupported");
    auto found = m_pits.find(pit);
    if (found == m_pits.end()) found = m_pits.emplace(pit, ++m_nextPit).first;
    m_activePit = pit;
    m_activeDecision = ++m_nextDecision;
    m_decisions << "{\"schema_version\":\"1B.1\",\"decision_id\":" << m_activeDecision
      << ",\"node_id\":" << m_node << ",\"pit_instance_id\":" << found->second
      << ",\"name\":" << quote(name) << ",\"time_ns\":" << now
      << ",\"after_event_seq\":" << m_seq << ",\"ingress_face_id\":" << ingress
      << ",\"anchor\":\"BEFORE_AFTER_RECEIVE_INTEREST\",\"fib_prefix\":" << quote(fibPrefix)
      << ",\"candidate_semantics\":\"RAW_NAME_FIB_NOT_STRATEGY_ELIGIBILITY\",\"candidates\":[";
    bool first = true;
    for (const auto& c : candidates) {
      if (!first) m_decisions << ',';
      first = false;
      m_decisions << "{\"face_id\":" << c.face << ",\"routing_cost\":" << c.routingCost
        << ",\"is_ingress\":" << (c.face == ingress ? "true" : "false")
        << ",\"strategy_eligible\":null}";
    }
    m_decisions << "]}\n";
    if (!m_decisions) throw std::runtime_error("Decision trace write failed");
    for (const auto& c : candidates) {
      const auto v=m_state.sample(c.face,now);
      m_states << "{\"schema_version\":\"1I.1\",\"decision_id\":" << m_activeDecision
        << ",\"node_id\":" << m_node << ",\"face_id\":" << c.face
        << ",\"time_ns\":" << now << ",\"after_event_seq\":" << m_seq
        << ",\"context_prefix\":" << quote(m_prefix) << ",\"RoutingCost\":" << c.routingCost;
      field("SRTT_ms",v.srttMs);field("SuccessEstimate",v.successEstimate);field("Goodput_bps",v.goodputBps);
      field("last_outcome_evidence_age_ns",v.outcomeAge);field("last_rtt_evidence_age_ns",v.rttAge);
      m_states << ",\"valid_outcomes\":" << v.valid << ",\"valid_rtt\":" << v.rttCount
        << ",\"max_terminal_event_seq\":" << v.maxSeq << ",\"retained_success_records\":" << v.retained
        << ",\"Congestion\":null,\"research_training_eligible\":false}\n";
    }
    if(!m_states)throw std::runtime_error("State trace write failed");
    return m_activeDecision;
  }
  void endDecision(uint64_t id) {
    if (!id) return;
    if (id != m_activeDecision) throw std::runtime_error("Decision context mismatch");
    m_activeDecision = 0;
    m_activePit = nullptr;
  }
  void event(const char* type, const void* pit, const std::string& name,
             int64_t now, int64_t face = -1, int64_t deadline = -1,
             int64_t nonce = -1, int64_t reason = -1, int64_t bytes = -1) {
    const bool selected = m_prefix.empty() || std::string(type) == "SIMULATION_END" ||
      name == m_prefix || name.compare(0, m_prefix.size() + 1, m_prefix + "/") == 0;
    auto& out = selected ? m_out : m_background;
    auto& pits = selected ? m_pits : m_backgroundPits;
    auto& nextPit = selected ? m_nextPit : m_backgroundNextPit;
    auto& seq = selected ? m_seq : m_backgroundSeq;
    uint64_t id = 0;
    if (pit) {
      auto found = pits.find(pit);
      if (found == pits.end()) found = pits.emplace(pit, ++nextPit).first;
      id = found->second;
    }
    out << "{\"schema_version\":\"0.2\",\"event_seq\":" << ++seq
          << ",\"node_id\":" << m_node << ",\"pit_instance_id\":" << id
          << ",\"time_ns\":" << now << ",\"event_type\":" << quote(type)
          << ",\"name\":" << quote(name) << ",\"face_id\":" << face
          << ",\"deadline_ns\":" << deadline << ",\"nonce\":" << nonce
          << ",\"decision_id\":" << ((pit == m_activePit && std::string(type) == "TX_INTEREST") ? m_activeDecision : 0)
          << ",\"reason\":" << reason << ",\"payload_bytes\":" << bytes << "}\n";
    if (!out) throw std::runtime_error("HCRAF event write failed");
    if(selected)m_state.event(type,id,face,now,deadline,nonce,bytes,seq);
    if (std::string(type) == "PIT_FINALIZE") pits.erase(pit);
  }
  void finish(int64_t now) {
    event("SIMULATION_END", nullptr, "", now);
    m_states.flush();
    if(!m_states)throw std::runtime_error("State trace flush failed");
    m_decisions.flush();
    if (!m_decisions) throw std::runtime_error("Decision trace flush failed");
    m_out.flush();
    if (m_background.is_open()) {
      m_background.flush();
      if (!m_background) throw std::runtime_error("Background trace flush failed");
    }
    if (!m_out) throw std::runtime_error("HCRAF event flush failed");
  }
private:
  template<class T> void field(const char* key,const std::optional<T>& value) {
    m_states << ",\"" << key << "\":";
    if(value)m_states << *value;else m_states << "null";
  }
  std::ofstream m_out;
  uint32_t m_node;
  std::string m_prefix;
  std::ofstream m_background;
  uint64_t m_backgroundSeq = 0, m_backgroundNextPit = 0;
  std::map<const void*, uint64_t> m_backgroundPits;
  std::ofstream m_decisions;
  std::ofstream m_states;
  State m_state;
  uint64_t m_nextDecision = 0, m_activeDecision = 0;
  const void* m_activePit = nullptr;
  uint64_t m_seq = 0, m_nextPit = 0;
  std::map<const void*, uint64_t> m_pits;
};
}
#endif
