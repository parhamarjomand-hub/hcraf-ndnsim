import unittest,sys,pathlib,math,numpy as np
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'scripts'))
import analyze_stage1am_f3_p12r_confirm_v05251 as a
class Tests(unittest.TestCase):
    def test_ties(self): self.assertAlmostEqual(a.AP([.8,.8,.1],[1,0,1],[0,0,0]).value(np.array([1])),.5*.5+.5*2/3)
    def test_perfect(self): self.assertEqual(a.AP([.9,.1],[1,0],[0,0]).value(np.array([1])),1)
    def test_constant(self): self.assertAlmostEqual(a.AP([.5]*3,[1,0,0],[0,0,0]).value(np.array([1])),1/3)
    def test_zero_positive(self): self.assertIsNone(a.AP([.9,.1],[1,0],[0,1]).value(np.array([0,2])))
    def test_duplication(self):
        x=a.AP([.7,.6,.6,.2],[1,0,1,0],[0,0,1,1]).value(np.array([2,3])); y=a.AP([.7]*2+[.6]*2+[.6]*3+[.2]*3,[1]*2+[0]*2+[1]*3+[0]*3,[0]*10).value(np.array([1])); self.assertAlmostEqual(x,y)
    def test_invalid_label(self):
        with self.assertRaises(RuntimeError):a.AP([.1],[2],[0])
    def test_invalid_score(self):
        with self.assertRaises(RuntimeError):a.AP([math.nan],[0],[0])
    def test_quantile(self):self.assertAlmostEqual(a.percentile([0,1,2,3],.125),.375)
    def test_frozen_scoring(self):
        m=dict(names=['x'],means=[2],sds=[1],weights=[1],intercept=0); self.assertAlmostEqual(a.score([[100]],m)[0],a.sigmoid(5));self.assertAlmostEqual(a.score([[2]],m)[0],.5)
    def test_flags(self):self.assertTrue(a.flags(a.FLAGS));self.assertFalse(a.flags(dict(a.FLAGS,F3_ready=True)))
if __name__=='__main__':unittest.main()
