"""P12O safe tests: published existing evidence only, never new AP scoring."""
import copy
import hashlib
import importlib.util
import json
import os
import pathlib
import tempfile
import unittest

SCRIPT=pathlib.Path(__file__).resolve().parents[1]/'scripts'/'audit_stage1am_f3_p12o_postconfirmatory_v05234.py'
spec=importlib.util.spec_from_file_location('p12o_audit',SCRIPT)
audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
SNAPSHOT=pathlib.Path(__file__).resolve().parents[1]/'docs'/'1AM'/'F3_P12O_POSTCONFIRMATORY_REVIEW_v0.52.34'/'P12N_FROZEN_REPORT_FROM_RUN_45794162960.json'

class P12O(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.base=json.loads(SNAPSHOT.read_text())
        cls.plan={'seed_blocks':list(range(24801,24837))}

    def test_published_result_is_pass_but_not_authorized_go(self):
        gates=audit.audit_final_report(copy.deepcopy(self.base),self.plan)
        self.assertEqual(len(gates),6)
        self.assertTrue(all(gates.values()))
        self.assertIs(self.base['F3_ready'],False)

    def test_final_report_sha_snapshot_is_exact(self):
        self.assertEqual(hashlib.sha256(SNAPSHOT.read_bytes()).hexdigest(),'79c03d8bf686caf530c7f613d198409c6aada57e281962544108cd30e163b4af')

    def test_frozen_plan_is_exact_with_external_zip(self):
        source=pathlib.Path(os.environ.get('P12O_TEST_P12K_SOURCE','hcraf_stage1am_f3_p12k_prospective_prereg_v05225_sources.zip'))
        plan, model=audit.verify_p12k(source)
        self.assertEqual(plan['seed_blocks_count'],36)
        self.assertEqual(model['local_model']['names'],['fib_route_cost','local_selected_queue_packets','local_selected_queue_fraction','local_selected_link_up'])

    def test_refuse_changed_delta(self):
        x=copy.deepcopy(self.base);x['delta_AP_remote_minus_local']+=.01
        with self.assertRaisesRegex(ValueError,'delta arithmetic'):audit.audit_final_report(x,self.plan)

    def test_refuse_changed_CI_gate(self):
        x=copy.deepcopy(self.base);x['bootstrap_CI_97p5'][0]=-.1
        with self.assertRaisesRegex(ValueError,'gate values'):audit.audit_final_report(x,self.plan)

    def test_refuse_changed_bootstrap_count(self):
        x=copy.deepcopy(self.base);x['bootstraps_attempted']=9999
        with self.assertRaisesRegex(ValueError,'bootstrap settings'):audit.audit_final_report(x,self.plan)

    def test_refuse_automatic_go(self):
        x=copy.deepcopy(self.base);x['F3_ready']=True
        with self.assertRaisesRegex(ValueError,'science-lock'):audit.audit_final_report(x,self.plan)

    def test_refuse_heldout_release(self):
        x=copy.deepcopy(self.base);x['heldout_release_authorized']=True
        with self.assertRaisesRegex(ValueError,'science-lock'):audit.audit_final_report(x,self.plan)

    def test_refuse_changed_seed_count(self):
        x=copy.deepcopy(self.base);x['positive_seed_count']-=1
        with self.assertRaisesRegex(ValueError,'positive seed gate count'):audit.audit_final_report(x,self.plan)

    def test_zero_positive_seed_AP_null(self):
        x=copy.deepcopy(self.base);x['per_seed_AP'][0]['AP_local']=0.0
        with self.assertRaisesRegex(ValueError,'zero-positive seed'):audit.audit_final_report(x,self.plan)

    def test_refuse_nonzero_model_fits(self):
        x=copy.deepcopy(self.base);x['model_fits']=1
        with self.assertRaisesRegex(ValueError,'forbidden work'):audit.audit_final_report(x,self.plan)

    def test_refuse_modified_frozen_model_sha(self):
        x=copy.deepcopy(self.base);x['frozen_model_sha256']='0'*64
        with self.assertRaisesRegex(ValueError,'model report hash mismatch'):audit.audit_final_report(x,self.plan)

    def test_refuse_missing_batch_CSV(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaisesRegex(ValueError,'exactly one'):audit.audit_rows(tmp,self.base,{'local_model':{'names':['fib_route_cost','local_selected_queue_packets','local_selected_queue_fraction','local_selected_link_up']},'remote_model':{'names':['fib_route_cost','local_selected_queue_packets','local_selected_queue_fraction','local_selected_link_up','relay_queue_packets','relay_telemetry_missing','relay_telemetry_age_ms','mid_queue_packets','mid_telemetry_missing','mid_telemetry_age_ms','producer_queue_packets','producer_telemetry_missing','producer_telemetry_age_ms']}})

if __name__=='__main__': unittest.main()
