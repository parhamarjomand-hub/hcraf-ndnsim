#!/usr/bin/env python3
"""P12O post-confirmation READ-ONLY construct audit, no AP/model scoring.

Authenticates the immutable P12N report and P12K preregistration, then verifies
all 36 existing P12N feature/label extracts without refitting, resampling, or
computing any new AP. Post-hoc diagnostics are descriptive, never GO gates.
"""
import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import io
import json
import pathlib
import zipfile

P12K_SOURCE_SHA = '13ff992e6be059e0ba8f92bb1cf97f76d5c3ed78fe259cfe43b78f47c01ce287'
P12K_PLAN_SHA = '27000d312d3c282e7aa574f70eb6a77c17989166612db88807d389b4bb70823a'
FROZEN_MODEL_SHA = 'de46e2f5fcb052f96e920729664084ad0edd029cc4af88b2c5480209976a35d1'
P12N_ARTIFACT_SHA = '73cac16ddd6a0db8a8e647da966cf02f7070a8e3eee7c7cf88ce5e215b9cd6c8'
P12M_ARTIFACT_SHA = '5d9a96be23a672532f0278dadf344c96e2ad3d8b47a32cdc25128ffccc7b8ca2'
P12N_BATCH_ARTIFACT_SHA = {
    1:'b324c9e86cabcd6e9e22e664a465d17088229e004e6c10b8538f8e1fced22e29',
    2:'3e340be948411eec829ee361747c0d77748b34c5ca134cac53648616ff0609b9',
    3:'4acaed614a7f87402fc2e00f5299b9222ee08e172b6381bb0492e4f067af4026',
    4:'7a1ebbd9c260398616a18e7f0cca17afa9feab12d2bc3734890099c89025986d',
    5:'6790e27648c69600de780b6117a660ef3127ed251b8fafdd998c4919bf6747d7',
    6:'899d11a0aacb5cb75bd055e7ea5f278c100c318dbe0256b351a7f619202384f6'
}
EXPECTED_SEEDS = tuple(range(24801,24837))
ALLOWED_SITES = {'producer_egress','transit_middle','consumer_ingress'}
ALLOWED_LOADS = {'low_control','high_pressure'}
SCIENCE_LOCKS = {
    'Congestion':None,'FutureCongestion':None,'F3_ready':False,
    'GO_FREEZE':False,'training_ready':False,
    'heldout_release_authorized':False,'Stage1AO_or_NSGAIII_authorized':False,
}


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def demand(condition, message):
    if not condition:
        raise ValueError('P12O_AUDIT_REFUSED: '+message)


def sole(directory, pattern):
    matches = list(pathlib.Path(directory).rglob(pattern))
    demand(len(matches)==1, f'expected exactly one {pattern} under {directory}, found {len(matches)}')
    return matches[0]


def verify_p12k(source_file):
    source_file=pathlib.Path(source_file)
    demand(sha_bytes(source_file.read_bytes())==P12K_SOURCE_SHA,'prereg source ZIP changed')
    prefix='hcraf/episode/docs/1AM/F3_P12K_PROSPECTIVE_REPLICATION_PREREG_v0.52.25/'
    with zipfile.ZipFile(source_file) as z:
        demand(z.testzip() is None,'P12K source ZIP corrupted')
        p=z.read(prefix+'P12K_ANALYSIS_PLAN_FROZEN_v05225.json')
        m=z.read(prefix+'P12K_PINNED_P12H_FROZEN_MODELS.json')
        demand(sha_bytes(p)==P12K_PLAN_SHA,'P12K frozen prereg changed')
        demand(sha_bytes(m)==FROZEN_MODEL_SHA,'frozen P12H models changed')
        plan=json.loads(p)
        model=json.loads(m)
        demand(plan['seed_blocks']==list(EXPECTED_SEEDS),'prereg 36 seed identifiers changed')
        demand(plan['bootstrap']['replicates']==10000 and plan['bootstrap']['rng_seed']==525250,'prereg bootstrap changed')
        demand(plan['bootstrap']['two_sided_CI_coverage']==0.975,'prereg CI changed')
        demand(plan['primary_episodes_planned']==27648 and plan['physical_case_count']==432,'prereg totals changed')
        demand(plan['frozen_model_sha256']==FROZEN_MODEL_SHA,'prereg model hash mismatch')
        demand(model['frozen_model_sha256']==FROZEN_MODEL_SHA if 'frozen_model_sha256' in model else True,'model mismatch')
    return plan,model


def audit_final_report(report,plan):
    demand(report['status']=='PASS_P12N_REPLICATION_EVIDENCE_ONLY','P12N final status')
    demand(report['stage']=='P12N_v0.52.33','P12N stage')
    demand(report['P12M_run']==45788559718 and report['P12M_parent_artifact']==15102130997,'P12M parent mismatch')
    demand(report['P12M_parent_digest']=='sha256:'+P12M_ARTIFACT_SHA,'P12M digest mismatch')
    demand(report['prereg_plan_sha256']==P12K_PLAN_SHA and report['frozen_model_sha256']==FROZEN_MODEL_SHA,'P12K/model report hash mismatch')
    demand(report['scored_episodes']==27648 and report['scored_active_cases']==216,'scoring sample changed')
    demand(report['physical_cases_authenticated_from_P12M']==432,'physical case count changed')
    demand(report['model_fits']==0 and report['heldout_rows_read']==0 and report['new_simulations']==0,'forbidden work reported')
    demand(report['no_interim_AP_peeks'] is True,'interim scoring')
    demand(report['bootstraps_attempted']==10000 and report['bootstrap_rng_seed']==525250,'bootstrap settings mismatch')
    demand(report['bootstrap_invalid_resamples']==0,'bootstrap invalid resamples')
    demand(report['bootstrap_interval_coverage']==0.975,'CI coverage mismatch')
    demand(report['bootstrap_resampling_unit']=='paired whole seed block','bootstrap cluster unit mismatch')
    for k,v in SCIENCE_LOCKS.items():
        demand(report.get(k,'MISSING')==v,f'science-lock mismatch: {k}')
    demand(report['positives']+report['negatives']==report['scored_episodes'],'event-class totals invalid')
    demand(abs(report['observed_prevalence']-report['positives']/report['scored_episodes'])<1e-14,'prevalence calculation mismatch')
    demand(abs(report['delta_AP_remote_minus_local']-(report['AP_remote']-report['AP_local']))<1e-14,'primary AP delta arithmetic mismatch')
    seedrows=report['per_seed_AP']
    demand(len(seedrows)==36 and [r['seed'] for r in seedrows]==list(EXPECTED_SEEDS),'per-seed rows changed')
    positive=0
    for r in seedrows:
        if r['positives']==0:
            demand(r['AP_local'] is None and r['AP_remote'] is None and r['delta_AP_remote_minus_local'] is None and r['strictly_positive_seed_gate'] is False,'zero-positive seed AP imputation')
        else:
            demand(r['AP_local'] is not None and r['AP_remote'] is not None,'unexpected null AP in positive seed')
            demand(abs(r['delta_AP_remote_minus_local']-(r['AP_remote']-r['AP_local']))<1e-14,'per-seed delta arithmetic mismatch')
            is_positive = r['delta_AP_remote_minus_local'] > 0
            demand(r['strictly_positive_seed_gate'] is is_positive,'per-seed gate mismatch')
            positive+=int(is_positive)
    demand(sum(r['positives'] for r in seedrows)==report['positives'],'per-seed positive counts mismatch')
    demand(positive==report['positive_seed_count'],'positive seed gate count mismatch')
    gates={
        'all_432_exact_cases_and_causal_provenance': report['physical_cases_authenticated_from_P12M']==432,
        'at_least_27_of_36_seed_blocks_positive': positive>=27,
        'both_event_classes_present': 0<report['positives']<report['scored_episodes'],
        'lower_97p5_bootstrap_limit_strictly_positive': report['bootstrap_CI_97p5'][0]>0,
        'remote_AP_above_local': report['AP_remote']>report['AP_local'],
        'remote_AP_above_prevalence': report['AP_remote']>report['observed_prevalence'],
    }
    demand(gates==report['replication_gates'],'locked gate values do not reconcile')
    demand(report['replication_success'] is all(gates.values()),'replication_success does not reconcile')
    demand(report['scientific_decision']=='REPLICATION_SUPPORTS_REVIEW_ONLY_NOT_AUTOMATIC_F3_GO','automatic GO requested')
    demand(report['seed_blocks']==list(EXPECTED_SEEDS),'seed block list mismatch')
    demand(set(report['data_row_sha256_by_batch'])==set(map(str,range(1,7))),'batch hashes missing')
    return gates


def audit_rows(batch_directory,final_report,model):
    local_features=list(model['local_model']['names'])
    remote_features=list(model['remote_model']['names'])
    demand(set(local_features).issubset(set(remote_features)),'feature definitions inconsistent')
    demand(len(local_features)==4 and len(remote_features)==13,'frozen feature schema unexpected')
    seen_keys=set()
    per_seed_counts=Counter()
    per_seed_positives=Counter()
    per_seed_local={s:{f:set() for f in local_features} for s in EXPECTED_SEEDS}
    per_seed_remote={s:{f:set() for f in ['relay_queue_packets','mid_queue_packets','producer_queue_packets']} for s in EXPECTED_SEEDS}
    case_counter=Counter()
    nonzero_queue=0
    total_rows=0
    batch_evidence={}
    for batch in range(1,7):
        root=pathlib.Path(batch_directory)
        fn=sole(root,f'P12N_BATCH_{batch}_RAW_FEATURES_LABELS_ONLY.csv')
        receiptpath=sole(root,f'P12N_BATCH_{batch}_EXTRACT_ONLY_RECEIPT.json')
        qcp=sole(root,f'P12N_BATCH_{batch}_ORIGINAL_QC_REPLAY.json')
        data=fn.read_bytes()
        d=sha_bytes(data)
        demand(d==final_report['data_row_sha256_by_batch'][str(batch)],f'batch {batch} extract hash mismatch')
        receipt=json.loads(receiptpath.read_text())
        qc=json.loads(qcp.read_text())
        expected=list(range(24801+(batch-1)*6,24807+(batch-1)*6))
        demand(receipt['batch']==batch and receipt['seeds']==expected and receipt['rows']==4608,'batch receipt mismatch')
        demand(receipt['primary_rows_csv_sha256']==d,'batch receipt CSV mismatch')
        demand(receipt['model_sha256']==FROZEN_MODEL_SHA and receipt['model_fits']==0 and receipt['no_AP_or_model_scoring_this_job'] is True,'batch scoring/fit unexpectedly occurred')
        demand(qc['seed_blocks']==expected and qc['physical_cases']==72 and qc['model_fits']==0,'original batch QC mismatch')
        demand(len(qc['raw_archives'])==6 and qc['expected_episodes']==9216,'batch physical receipt mismatch')
        expected_archive_hashes=[x['raw_archive_sha256'] for x in qc['raw_archives']]
        demand(receipt['raw_zip_sha256']==expected_archive_hashes,'raw archive hash chain inconsistent')
        for k,v in SCIENCE_LOCKS.items():
            if k in receipt:demand(receipt[k]==v,f'batch {batch} science-lock {k}')
        count=0
        reader=csv.DictReader(io.StringIO(data.decode('utf-8')))
        cols=set(reader.fieldnames or ())
        demand(set(remote_features).issubset(cols) and {'row_key','seed','site','load','telemetry','y'}.issubset(cols),'CSV feature schema altered')
        demand('decision_ns' not in model['remote_model']['names'] and 'y' not in model['remote_model']['names'],'future feature leakage in model schema')
        for row in reader:
            count+=1
            sd=int(row['seed'])
            demand(sd in expected,f'batch {batch} has out-of-batch seed {sd}')
            demand(row['site'] in ALLOWED_SITES and row['load'] in ALLOWED_LOADS and row['telemetry']=='on_20ms','active-arm/site/load changed')
            demand(row['y'] in ('0','1'),'label not binary')
            key=row['row_key']
            demand(key not in seen_keys,'duplicate episode identity')
            seen_keys.add(key)
            demand(key.startswith(f"{sd}:{row['site']}:{row['load']}:on_20ms:"),'episode identifier origin mismatch')
            count_case=(sd,row['site'],row['load'])
            case_counter[count_case]+=1
            per_seed_counts[sd]+=1
            per_seed_positives[sd]+=(row['y']=='1')
            for feat in local_features:
                per_seed_local[sd][feat].add(row[feat])
            for feat in per_seed_remote[sd]:
                per_seed_remote[sd][feat].add(row[feat])
            queue=float(row['local_selected_queue_packets'])
            demand(queue>=0,'negative local queue')
            nonzero_queue+=(queue!=0)
            for node in ('relay','mid','producer'):
                age=row[node+'_telemetry_age_ms']
                missing=row[node+'_telemetry_missing']
                packet=row[node+'_queue_packets']
                demand(missing in ('True','False'),'invalid telemetry missingness flag')
                if missing=='True':
                    demand(age=='' and packet=='','missing telemetry incorrectly filled')
                else:
                    demand(age!='' and packet!='','telemetry omitted without missing flag')
                    demand(float(age)>=0,'negative telemetry age')
                    demand(float(packet)>=0,'negative remote queue')
        demand(count==4608,f'batch {batch} expected 4608 rows; got {count}')
        total_rows+=count
        batch_evidence[str(batch)]={'extracted_rows':count,'row_sha256':d,'seeds':expected,'original_QC_status':qc['status']}
    demand(total_rows==27648 and len(seen_keys)==27648,'global scored row totals or uniqueness invalid')
    demand(set(per_seed_counts)==set(EXPECTED_SEEDS),'missing or extra seed')
    demand(all(v==768 for v in per_seed_counts.values()),'per-seed 768 row balance violated')
    demand(len(case_counter)==216 and set(case_counter.values())=={128},'case counts differ from prereg')
    for item in final_report['per_seed_AP']:
        sd=item['seed'];demand(item['positives']==per_seed_positives[sd],f'original outcome label count differs for seed {sd}')
    demand(sum(per_seed_positives.values())==final_report['positives'],'global event label mismatch')
    all_local_constant=[]
    remote_queue_varies=[]
    detail=[]
    for s in EXPECTED_SEEDS:
        local_card={f:len(per_seed_local[s][f]) for f in local_features}
        remote_card={f:len(per_seed_remote[s][f]) for f in per_seed_remote[s]}
        if all(v==1 for v in local_card.values()):all_local_constant.append(s)
        if any(v>1 for v in remote_card.values()):remote_queue_varies.append(s)
        detail.append({'seed':s,'positives':per_seed_positives[s],
                       'local_feature_cardinalities':local_card,
                       'remote_queue_cardinalities':remote_card,
                       'all_local_features_constant':all(v==1 for v in local_card.values())})
    return {'batch_evidence':batch_evidence,'raw_rows_authenticated':total_rows,
            'unique_episode_keys':len(seen_keys),
            'positive_labels_authenticated':sum(per_seed_positives.values()),
            'active_cases_authenticated':len(case_counter),
            'local_queue_nonzero_rows':nonzero_queue,
            'local_queue_zero_rows':total_rows-nonzero_queue,
            'local_features_constant_seed_count':len(all_local_constant),
            'local_features_constant_seeds':all_local_constant,
            'remote_queue_varies_seed_count':len(remote_queue_varies),
            'per_seed_construct_diagnostics':detail}


def run(final_input,batches_input,p12k_source,output):
    final_path=sole(final_input,'P12N_36_SEED_ONCE_ONLY_CONFIRMATORY_P12K_REPORT.json')
    report=json.loads(final_path.read_text())
    plan,model=verify_p12k(p12k_source)
    gates=audit_final_report(report,plan)
    info=audit_rows(batches_input,report,model)
    out={'stage':'P12O_v0.52.34_READ_ONLY_POSTCONFIRMATORY_REVIEW',
         'status':'PASS_P12O_SOURCE_ROWS_INTEGRITY_CONSTRUCT_REVIEW_REQUIRED',
         'P12K_prereg_sha256':P12K_PLAN_SHA,'frozen_model_sha256':FROZEN_MODEL_SHA,
         'P12N_confirmatory_run':45794162960,
         'P12N_original_artifact_sha256':P12N_ARTIFACT_SHA,
         'P12N_original_report_status':report['status'],
         'P12N_success_gates_reconciled':gates,
         'P12N_replication_success_reconciled':report['replication_success'],
         'historical_P12H_first_validation':'NO_GO',
         'no_new_AP_computed':True,'no_new_bootstrap_or_model_fitting':True,
         'no_new_simulations':True,'heldout_rows_read':0,
         'noncausal_inference_cannot_be_proven_from_csv_alone':True,
         'construct_review_required':True,
         'statistical_replication_pass_is_not_formal_global_F3_GO':True,
         'protocol_multiplicity_caveat':plan['multiplicity_note'],
         'scientific_decision':'REPLICATION_POSITIVE_CONSTRUCT_VALIDITY_REVIEW_PENDING_NO_GO_RELEASE',
         **SCIENCE_LOCKS,
         **info}
    target=pathlib.Path(output)
    target.write_text(json.dumps(out,indent=2,sort_keys=True,ensure_ascii=False)+'\n',encoding='utf-8')
    print(out['status'])
    print('rows',out['raw_rows_authenticated'],'positive',out['positive_labels_authenticated'],
          'constant_local_seeds',out['local_features_constant_seed_count'],
          'nonzero_local_queue',out['local_queue_nonzero_rows'])
    return out


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--final',required=True)
    p.add_argument('--batches',required=True)
    p.add_argument('--p12k-source',required=True)
    p.add_argument('--output',required=True)
    a=p.parse_args()
    run(a.final,a.batches,a.p12k_source,a.output)
