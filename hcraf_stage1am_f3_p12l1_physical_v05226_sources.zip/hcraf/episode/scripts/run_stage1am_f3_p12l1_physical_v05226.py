#!/usr/bin/env python3
"""P12L1: exact 12 physical cases per seed, six fresh seeds, no interim AP."""
import argparse,csv,hashlib,json,shutil,subprocess,zipfile
from pathlib import Path
import generate_stage1am_f3_p12k_prereg_v05225 as k
ROOT=Path(__file__).resolve().parents[3]
DEST=ROOT/'episode_output/stage1am_f3_p12l1_physical_v05226'
BIN='hcraf-stage1am-f3-p12l1-physical-v05226'
SEEDS=tuple(range(24801,24807))
MODEL_SHA='de46e2f5fcb052f96e920729664084ad0edd029cc4af88b2c5480209976a35d1'
LOCKS=dict(Congestion=None,FutureCongestion=None,F3_ready=False,GO_FREEZE=False,training_ready=False,heldout_release_authorized=False)
def need(x,why):
    if not x:raise RuntimeError('P12L1_'+why)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def plan(seed):
    need(seed in SEEDS,'OUTSIDE_SIX_NEW_SEED_BLOCKS')
    from audit_stage1am_f3_p12k_prereg_v05225 import audit
    audit()
    doc=k.DOC
    frozen=json.loads((doc/'P12K_ANALYSIS_PLAN_FROZEN_v05225.json').read_text())
    need(frozen['seed_blocks']==list(range(24801,24837)) and frozen['physical_case_count']==432,'P12K_MATRIX_CHANGED')
    need(frozen['frozen_model_sha256']==MODEL_SHA and sha(doc/'P12K_PINNED_P12H_FROZEN_MODELS.json')==MODEL_SHA,'FROZEN_MODEL_SHA_CHANGED')
    need(frozen['bootstrap']['replicates']==10000 and frozen['bootstrap']['lower_percentile']==0.0125 and frozen['bootstrap']['rng_seed']==525250,'BOOTSTRAP_LOCK_CHANGED')
    need(len(frozen['replication_success_gates_all_required'])==4 and frozen['stop_rule'].startswith('no interim AP'), 'STATISTICAL_GATES_CHANGED')
    with (doc/'P12K_LOCKED_MATRIX_432_v05225.csv').open(newline='') as f:allrows=list(csv.DictReader(f))
    need(len(allrows)==432,'CASE_COUNT_CHANGED')
    rows=[dict(x,seed=int(x['seed']),selected_slot=int(x['selected_slot'])) for x in allrows if int(x['seed'])==seed]
    need(len(rows)==12 and {(x['site'],x['load'],x['telemetry']) for x in rows}==
         {(site,load,t) for site in k.SITES for load in k.LOADS for t in k.TELEMETRIES},'NOT_TWELVE_LOCKED_CASES')
    for x in rows:
        need(x['partition']=='PROSPECTIVE_REPLICATION' and x['execution_authorized_now']=='false' and x['validation_or_heldout_released']=='false','PREREG_HISTORICAL_FLAGS_TAMPERED')
        need(x['schedule_filename']==k.filename(seed,x['site'],x['load']) and sha(k.PLANS/x['schedule_filename'])==x['schedule_sha256'] and x['schedule_sha256']==hashlib.sha256(k.render_schedule(seed,x['site'],x['load'])).hexdigest(),'SCHEDULE_SHA_CHANGED')
        a=k.allocation()[seed,x['site']]
        need(all(int(x[field])==a[field] for field in ('traffic_stream_seed','routing_stream_seed','telemetry_stream_seed')),'RNG_CHANGED')
    return rows

def command(x,dest):
    return BIN+' '+' '.join([
      f"--pathArm={x['arm']}",f"--interventionLocation={x['location']}",
      '--interventionReturnBps=12000000','--lossProbability=0','--lossStream=79',
      '--lossReceiverNodeId=-1','--lossReceiverDeviceIndex=-1',
      f'--scheduleFamily={k.FAMILY}',f"--scheduleCsv={k.PLANS/x['schedule_filename']}",
      f"--prospectiveLoad={x['load']}",
      *[f'--prospective{label}StreamSeed={x[field]}' for label,field in [('Traffic','traffic_stream_seed'),('Routing','routing_stream_seed'),('Telemetry','telemetry_stream_seed')]],
      f"--selectedSlot={x['selected_slot']}",f"--run={x['seed']}",f'--output={dest}',
      '--instrument=1','--topology=DEV_CHAIN_L','--mode=LP_INDEPENDENT_COMPETITOR_NO_DROP',
      '--seed=17','--lifetimeMs=2600','--requestCount=12','--intervalNs=330000000',
      '--competitorCount=116','--competitorIntervalNs=3600000','--competitorOffsetNs=0',
      '--targetOffsetNs=260000000','--forwardBps=50000000','--returnBps=50000000',
      '--technicalQueueMaxPackets=12',f"--telemetryEnabled={int(x['telemetry']=='on_20ms')}",
      '--telemetryPeriodMs=20'])

def one(x,work):
    from run_stage1am_f3_p12_development_v05220 import physical_witness,check_decisions_128,verify_telemetry_128,load_jsonl
    dest=work/x['site']/x['load']/x['telemetry']
    dest.mkdir(parents=True,exist_ok=False)
    cmd=command(x,dest)
    (dest/'command.txt').write_text(cmd+'\n')
    (dest/'P12L1_LOCKED_REPLICATION_CASE.json').write_text(json.dumps({**x,'P12K_parent_run':45195251299,'frozen_model_sha256':MODEL_SHA,'P12L1_execution_authorized_after_P12K_success':True,**LOCKS},sort_keys=True,indent=2)+'\n')
    with (dest/'simulator.log').open('w') as log:
        subprocess.run(['/usr/bin/time','-f','wall_seconds=%e\nmax_rss_kib=%M','-o',str(dest/'resource_usage.txt'),
                        'python3','./waf','--run-no-build',cmd],cwd=ROOT/'episode_sources/ns-3',stdout=log,stderr=subprocess.STDOUT,check=True)
    scenario=json.loads((dest/'scenario.json').read_text()); a=k.allocation()[x['seed'],x['site']]
    checks={
      'research_partition':'PROSPECTIVE_REPLICATION',
      'p12l1_replication_authorized_after_p12k_prereg_run':True,
      'p12k_replication_site':x['site'],
      'amendment_stage':'1AM.F3.P12L1.PROSPECTIVE_REPLICATION_V05226.0',
      'independent_rng_block':x['seed'],
      'schedule_family':k.FAMILY,
      'schedule_contract':'P12K_V05225_PROSPECTIVE_REPLICATION_PREREG_LOCKED_CSV',
      'schedule_csv_filename':x['schedule_filename'],
      'selected_face_slot':x['selected_slot'],'selected_face_id':258+x['selected_slot'],
      'p4_locked_traffic_stream_seed':a['traffic_stream_seed'],
      'p4_locked_routing_stream_seed':a['routing_stream_seed'],
      'p4_locked_telemetry_stream_seed':a['telemetry_stream_seed'],
      'p4_prospective_load':x['load'],'phase_arm':x['arm'],
      'intervention_location':x['location'],'technical_queue_max_packets':12,
      'telemetry_enabled':x['telemetry']=='on_20ms',
      'competitor_planned_requests':116,'planned_requests':12,
      'future_oracle_horizon_ns_pilot':75000000,
      'official_F3_labels_constructed':0,'F3_PR_AUC_computed':False,**LOCKS}
    need(all(field in scenario and scenario[field]==value for field,value in checks.items()),'FROZEN_SIMULATOR_CONTRACT')
    events=k.events(x['seed'],x['site'],x['load'])
    for cls,file in [('TARGET','consumer_events.jsonl'),('INDEPENDENT_COMPETITOR','competitor_events.jsonl')]:
        expected={int(r['sequence']):int(r['time_ns']) for r in events if r['traffic_class']==cls}
        sends={int(r['name'].rsplit('/',1)[-1]):int(r['time_ns']) for r in load_jsonl(dest/file) if r['event']=='SEND'}
        observed=load_jsonl(dest/(file+'.arrivals.jsonl'))
        arrivals={int(r['sequence']):int(r['time_ns']) for r in observed}
        need(len(observed)==len(expected) and expected==sends==arrivals,'SEND_TIMING_NOT_P12K')
        need({r['schedule'] for r in observed}=={'F3_P12K_V05225_PROSPECTIVE_REPLICATION_LOCKED_CSV'},'NOT_P12K_SCHEDULE_PROVENANCE')
    physical=physical_witness(dest,scenario,x['target_role'])
    decisions=check_decisions_128(dest,scenario)
    telemetry=verify_telemetry_128(dest,scenario,x['telemetry']=='on_20ms')
    (dest/'P12L1_PHYSICAL_QC_ONLY.json').write_text(json.dumps({**x,'physical':physical,'decisions':decisions,
       'telemetry_transport':telemetry,'official_F3_labels_constructed':0,'official_F3_PR_AUC_computed':False,**LOCKS},indent=2,sort_keys=True)+'\n')

def run(seed):
    rows=plan(seed)
    dest=DEST/f'seed_{seed}'
    work=ROOT/'episode_output'/f'v05226_p12l1_seed_{seed}_raw_work'
    need(not dest.exists() and not work.exists(),'REFUSE_REEXECUTE_OR_OVERWRITE')
    need((ROOT/'episode_sources/ns-3/build/scratch'/BIN).is_file(),'CPP_NOT_BUILT')
    dest.mkdir(parents=True); work.mkdir(parents=True)
    for i,x in enumerate(rows,1):
        one(x,work)
        print('PASS_PHYSICAL_QC',seed,i,'of',len(rows),x['site'],x['load'],x['telemetry'],flush=True)
    # Exactly one per-seed QC index, mirroring the historical P12H raw
    # archive structure (480 per-case raw files + this seed index = 481).
    (work/'P12L1_SEED_CASE_QC_INDEX.json').write_text(json.dumps({
       'seed':seed,'expected_case_count':12,'completed_case_count':len(rows),
       'case_keys':[[x['site'],x['load'],x['telemetry']] for x in rows],
       'primary_metric_not_computed':True,'model_fits':0,**LOCKS},
       indent=2,sort_keys=True)+'\n')
    files=sorted(p for p in work.rglob('*') if p.is_file())
    need(len(files)==481,'NOT_481_EXPECTED_RAW_FILES')
    file_hashes={p.relative_to(work).as_posix():sha(p) for p in files}
    archive=dest/f'P12L1_RAW_SEED_{seed}.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files:z.write(p,p.relative_to(work).as_posix())
        z.writestr('P12L1_RAW_FILE_SHA256.json',json.dumps(file_hashes,indent=2,sort_keys=True)+'\n')
    with zipfile.ZipFile(archive) as z:
        need(z.testzip() is None and set(z.namelist())==set(file_hashes)|{'P12L1_RAW_FILE_SHA256.json'},'ZIP_CRC_OR_MEMBERS')
        for path,digest in file_hashes.items():need(hashlib.sha256(z.read(path)).hexdigest()==digest,'ZIP_SHA_FILE_'+path)
    receipt={'seed':seed,'cases':12,'raw_file_count':481,'expected_episodes':1536,
      'telemetry_on_episodes':768,'raw_archive_name':archive.name,
      'raw_archive_sha256':sha(archive),'P12K_parent_run':45195251299,
      'P12K_parent_commit':'e9819bb1aeb9c786fe68061a97f02308a110c56d',
      'frozen_model_sha256':MODEL_SHA,'prior_P12H_validation':'NO_GO',
      'interim_AP_computed':False,'model_fits':0,'validation_reads':0,
      'heldout_reads':0,'official_F3_labels_constructed':0,**LOCKS}
    (dest/f'P12L1_SEED_{seed}_RECEIPT.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
    shutil.rmtree(work)
    print('PASS_SEED_ARCHIVE_SHA_481_RAW_FILES_NO_AP',seed,flush=True)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--seed',type=int,required=True)
    parser.add_argument('--preflight-only',action='store_true')
    args=parser.parse_args(); rows=plan(args.seed)
    if args.preflight_only:print(json.dumps({'seed':args.seed,'case_count':len(rows),'episodes':1536,'simulations':0,
       'stage':'P12L1_PREFLIGHT_ONLY','model_sha256':MODEL_SHA,**LOCKS},sort_keys=True))
    else:run(args.seed)
if __name__=='__main__':main()
