#!/usr/bin/env python3
"""P12-E prospective preregistration science gates; no simulator or model."""
import csv
from collections import Counter
from hashlib import sha256
import io
import json
from pathlib import Path
import tempfile
import unittest

import generate_stage1am_f3_p12e_independent_prereg_v05219 as e


class P12EProspectiveLockTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.matrix = e.matrix_rows()
        cls.lock = e.commitments()

    def test_01_p12d_forensic_parent_and_locks(self):
        evidence = json.loads((e.DOC/'P12E_P12D_PARENT_INDEPENDENT_AUDIT_RECEIPT.json').read_text())
        self.assertEqual(evidence['parent_run_id'],44729383064)
        self.assertEqual(evidence['parent_commit'],'eabb00156fc5a0f421ed9e7505afe6f1087d8b2d')
        self.assertEqual(evidence['parent_artifact_sha256'],
                         'd4e4540c8fcd0074725180666ac9f66e397f93f5bc5a5801cc5b0bbbee7ea3a1')
        self.assertEqual(evidence['raw_files_sha256_verified'],962)
        self.assertEqual((evidence['retrospective_75ms_positive_count'],
                          evidence['retrospective_75ms_negative_count']),(219,2853))
        self.assertEqual(evidence['causal_received_telemetry_features_replayed'],4608)
        self.assertEqual(self.lock['P12D_parent_artifact_sha256'],
                         evidence['parent_artifact_sha256'])
        for k,v in e.LOCKS.items():
            self.assertIs(self.lock[k],v)
            self.assertIs(evidence[k],v)

    def test_02_all_new_seed_groups_disjoint_and_pilot_excluded(self):
        seeds=[x for group in e.SEED_SPLITS.values() for x in group]
        self.assertEqual(len(seeds),len(set(seeds)))
        self.assertTrue(set(seeds).isdisjoint(e.PILOT_EXCLUDED))
        self.assertEqual(len(seeds),14)
        self.assertEqual(list(e.SEED_SPLITS),
                         ['DEVELOPMENT','VALIDATION_RESERVED','HELDOUT_RESERVED'])
        for seed in seeds:
            self.assertEqual(sum(seed in group for group in e.SEED_SPLITS.values()),1)

    def test_03_exact_168_case_partition_and_no_row_split(self):
        self.assertEqual(len(self.matrix),168)
        self.assertEqual(Counter(x['partition'] for x in self.matrix),
            {'DEVELOPMENT':72,'VALIDATION_RESERVED':48,'HELDOUT_RESERVED':48})
        self.assertEqual(len({(x['seed'],x['site'],x['load'],x['telemetry'])
                              for x in self.matrix}),168)
        self.assertTrue(all(x['partition']==e.partition_of(x['seed'])
                            for x in self.matrix))
        self.assertTrue(self.lock['no_random_row_split'])
        self.assertEqual(self.lock['split_atomic_group'],
                         'RNG_SEED_AND_ENTIRE_SIMULATION_EPISODE_BUNDLE')

    def test_04_all_84_csv_bytes_are_immutable_and_hashed(self):
        schedules=self.lock['schedule_hashes']
        self.assertEqual(len(schedules),84)
        self.assertEqual(len(list(e.PLANS.glob('*.csv'))),84)
        self.assertEqual(sha256(e.MATRIX.read_bytes()).hexdigest(),
                         self.lock['matrix_sha256'])
        self.assertEqual(e.MATRIX.read_bytes(),e.render_matrix())
        saved=json.loads(e.COMMITMENTS.read_text())
        self.assertEqual(saved,self.lock)
        for name,h in schedules.items():
            self.assertEqual(sha256((e.PLANS/name).read_bytes()).hexdigest(),h)
            self.assertEqual(len(list(csv.DictReader(io.StringIO(
                (e.PLANS/name).read_text())))),128)

    def test_05_each_physical_case_128_episodes_and_frozen_timing(self):
        self.assertEqual(e.EPISODES_PER_CASE,128)
        for seed in e.SEED_SPLITS['DEVELOPMENT']:
            for site in e.SITES:
                for load in e.LOADS:
                    rows=e.events(seed,site,load)
                    self.assertEqual(len(rows),128)
                    self.assertEqual(Counter(x['traffic_class'] for x in rows),
                                     {'TARGET':12,'INDEPENDENT_COMPETITOR':116})
                    self.assertEqual(len([x for x in rows
                                          if x['phase_label'].endswith('_TAIL_PROBE')]),20)
                    self.assertTrue(all(x['split']=='DEVELOPMENT' and
                                        x['rng_block']==seed for x in rows))

    def test_06_matched_controls_tail_and_target_exactly_paired(self):
        for group in e.SEED_SPLITS.values():
            for seed in group:
                for site in e.SITES:
                    lo=e.events(seed,site,'low_control')
                    hi=e.events(seed,site,'high_pressure')
                    kept=lambda xs,selector: {(r['traffic_class'],r['sequence']):r['time_ns']
                        for r in xs if selector(r)}
                    self.assertEqual(kept(lo,lambda r:r['traffic_class']=='TARGET'),
                                     kept(hi,lambda r:r['traffic_class']=='TARGET'))
                    self.assertEqual(kept(lo,lambda r:r['phase_label'].endswith('_TAIL_PROBE')),
                                     kept(hi,lambda r:r['phase_label'].endswith('_TAIL_PROBE')))
                    self.assertNotEqual(kept(lo,lambda r:r['phase_label'].startswith('C')),
                                        kept(hi,lambda r:r['phase_label'].startswith('C')))

    def test_07_latin_anchors_counterbalance_within_each_partition(self):
        all_cells=e.allocation()
        for part,seeds in e.SEED_SPLITS.items():
            cells=[all_cells[s,site] for s in seeds for site in e.SITES]
            self.assertEqual(len(cells),len(seeds)*3)
            for p,base,step in [('A',2_190_000_000,210_000_000),
                                ('B',4_350_000_000,250_000_000)]:
                counts=Counter(round((c[f'phase_{p}_anchor_ns']-base)/step)
                               for c in cells)
                self.assertEqual(counts,{i:len(cells)//6 for i in range(6)})

    def test_08_route_slots_counterbalanced_and_streams_unique(self):
        alloc=e.allocation()
        self.assertEqual(len(alloc),42)
        for site in e.SITES:
            dev=[alloc[seed,site]['selected_slot']
                 for seed in e.SEED_SPLITS['DEVELOPMENT']]
            self.assertEqual(Counter(dev),{0:2,1:2,2:2})
        rng=[row[k] for row in alloc.values() for k in (
            'traffic_stream_seed','routing_stream_seed','telemetry_stream_seed')]
        self.assertEqual(len(rng),len(set(rng)))
        self.assertTrue(all(0<k<=0x7fffffff for k in rng))

    def test_09_all_executor_and_protected_data_release_locks_false(self):
        for name in ('development_executor_authorized_now',
                     'validation_data_authorized_now','heldout_data_authorized_now',
                     'all_executors_authorized_now','scientific_freeze_authorized_now',
                     'model_training_preregistered_now','F3_PR_AUC_computed',
                     'training_executed'):
            self.assertIs(self.lock[name],False)
        self.assertEqual(self.lock['new_simulations'],0)
        self.assertEqual(self.lock['official_F3_labels_constructed'],0)
        self.assertTrue(all(x['execution_authorized_now']=='false' and
                            x['validation_or_heldout_released']=='false'
                            for x in self.matrix))

    def test_10_causal_label_future_feature_whitelist_separation(self):
        self.assertEqual(self.lock['diagnostic_horizon_ns'],75_000_000)
        self.assertEqual(self.lock['causal_remote_sample_ttl_ns'],100_000_000)
        self.assertEqual(self.lock['temporal_purging_embargo_ns'],75_000_000)
        self.assertEqual(self.lock['future_label_event'],
                         'REAL_SELECTED_PATH_DEVICE0_QUEUE_DROP_ONLY')
        self.assertTrue(set(self.lock['prohibited_predictors']).isdisjoint(
            self.lock['allowed_predictor_features']))
        self.assertNotIn('pathwide_witness_b',self.lock['allowed_predictor_features'])
        self.assertNotIn('future_queue_drop',self.lock['allowed_predictor_features'])
        self.assertTrue(self.lock['no_pilot_data_reuse_in_formal_dataset'])

    def test_11_quality_gate_predeclares_three_independent_seed_requirement(self):
        gates=self.lock['development_QC_preregistered']
        self.assertTrue(gates['per_site_min_3_of_6_seeds_with_real_target_QUEUE_DROP_both_high_telemetry_arms'])
        self.assertTrue(gates['per_site_min_3_of_6_seeds_with_positive_negative_and_on_time_bin_pairs'])
        self.assertTrue(gates['all_9216_expected_forwarding_episodes_verified'])
        self.assertTrue(gates['no_QC_filter_by_future_label'])

    def test_12_immutable_writer_rejects_existing_changed_plan(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'frozen.csv'
            e.write_immutable(p,b'committed')
            e.write_immutable(p,b'committed')
            with self.assertRaisesRegex(AssertionError,'REFUSE_MUTATE'):
                e.write_immutable(p,b'mutated')

    def test_13_nonpreregistered_seed_rejected(self):
        for seed in (22001,23401,23402,23501,23502,24507,99999):
            with self.assertRaisesRegex(AssertionError,'FOREIGN_SEED'):
                e.partition_of(seed)
            with self.assertRaises(AssertionError):
                e.events(seed,'producer_egress','high_pressure')

    def test_14_no_future_leakage_or_training_code_in_generator(self):
        source=Path(e.__file__).read_text()
        self.assertNotIn('from sklearn',source)
        self.assertNotIn('fit_predict',source)
        self.assertNotIn('average_precision_score(',source)
        self.assertNotIn('QUEUE_DROP"',source)
        self.assertTrue(self.lock['prior_registered_v0520_unchanged'])


if __name__=='__main__':
    unittest.main()
