#ifndef HCRAF_STAGE1W_LP_HPP
#define HCRAF_STAGE1W_LP_HPP
// Defensive evidence-only reader for NDNLPv2 headers on bounded ns-3 P2P packets.
// Never invents Name, Nonce, or PIT. Fragment payload is not a network packet until reassembly.
#include "hcraf-wire-decode.hpp"
#include <vector>
#include <cstdint>
#include <string>
namespace hcraf { namespace lp1w {
struct Fragment {
  std::string status="NOT_LP";
  bool hasSeq=false, hasIndex=false, hasCount=false, hasPayload=false;
  uint64_t seq=0, index=0, count=0, group=0;
  std::vector<uint8_t> payload;
  int offset=-1;
};
inline bool number(const std::vector<uint8_t>& d, const wire::Tlv& x, uint64_t& value) {
  size_t n=x.end-x.value;
  if(n<1 || n>8)return false; // Sequence may be encoded in fixed-width 8 octets.
  value=0;for(size_t i=x.value;i<x.end;++i)value=(value<<8)|d[i];
  return true;
}
inline Fragment at(const std::vector<uint8_t>& d,size_t off) {
  Fragment r;
  if(off>=d.size())return r;
  size_t p=off;wire::Tlv root;
  if(!wire::tlv(d,p,d.size(),root)||p!=d.size()||root.type!=100)return r;
  r.status="INVALID_LP";r.offset=static_cast<int>(off);
  size_t q=root.value;
  while(q<root.end) {
    wire::Tlv x;if(!wire::tlv(d,q,root.end,x))return r;
    if(x.type==80) {if(r.hasPayload)return r;r.hasPayload=true;r.payload.assign(d.begin()+x.value,d.begin()+x.end);}
    if(x.type==81) {if(r.hasSeq||!number(d,x,r.seq))return r;r.hasSeq=true;}
    if(x.type==82) {if(r.hasIndex||!number(d,x,r.index))return r;r.hasIndex=true;}
    if(x.type==83) {if(r.hasCount||!number(d,x,r.count))return r;r.hasCount=true;}
  }
  if(!r.hasPayload)return r;
  if(r.hasIndex != r.hasCount)return r;
  if(r.hasCount) {
    if(r.count<2||r.index>=r.count||!r.hasSeq||r.seq<r.index)return r;
    r.group=r.seq-r.index;r.status="FRAGMENT";
  }
  else r.status="SINGLE_LP";
  return r;
}
inline Fragment decode(const std::vector<uint8_t>& bytes) {
  Fragment a=at(bytes,0);
  if(a.status!="NOT_LP")return a;
  if(bytes.size()>2) return at(bytes,2);
  return a;
}
inline std::string hex(const std::vector<uint8_t>& d) {
  const char* h="0123456789abcdef";std::string s;s.reserve(d.size()*2);
  for(uint8_t v:d){s.push_back(h[v>>4]);s.push_back(h[v&15]);}
  return s;
}
}}
#endif
