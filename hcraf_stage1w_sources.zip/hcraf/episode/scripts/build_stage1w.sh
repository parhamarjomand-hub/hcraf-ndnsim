#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK_DIR="$PROJECT_DIR/hcraf/episode"
SOURCE_DIR="$PROJECT_DIR/episode_sources/ns-3"
# Reuse exactly pinned NFD and prior Stage1U instrumentation: no HCRAF forwarding changes.
bash "$TASK_DIR/scripts/build_stage1u.sh"
cp "$TASK_DIR/src/hcraf-stage1w-pilot.cpp" "$SOURCE_DIR/scratch/hcraf-stage1w-pilot.cc"
cd "$SOURCE_DIR"
python3 ./waf -j 2
test -x build/scratch/hcraf-stage1w-pilot
