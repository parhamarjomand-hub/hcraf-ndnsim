#!/usr/bin/env python3
"""Conservative aggregation. Claims only actually observed forms of contention."""
import json
import sys
from pathlib import Path
from collections import Counter

from verify_stage1u import MODES


def summarize(folder):
    folder=Path(folder)
    rows=[]
    for mode in MODES:
        for rng in (1001,1002):
            p=folder/mode/('run-'+str(rng))/'stage1u_verification.json'
            if not p.exists():raise ValueError('Missing real verified simulation: '+str(p))
            s=json.loads(p.read_text(encoding='utf8'))
            if s['mode']!=mode or s['run']!=rng or not s['verified_nfd_binding']:
                raise ValueError('Invalid verification manifest: '+str(p))
            rows.append(s)
    status=Counter()
    for r in rows:status.update(r['physical_status_counts'])
    # The title of an experiment does not prove the intended event occurred.
    # Require actual measured coverage across the two seeds per named scenario.
    requirements={
       'burst-identical': ('repeated_name_arrivals', 1),
       'overlap-prefix': ('many_pit_arrivals', 1),
       'duplicate-data': ('no_pit_arrivals', 1),
       'interleaved-retransmission': ('repeated_name_arrivals', 1),
       'multi-hop-overlap': ('many_pit_arrivals', 1),
       'dual-source-overlap': ('no_pit_arrivals', 1),
    }
    coverage={}
    for mode,(field,minimum) in requirements.items():
        observed=sum(r[field] for r in rows if r['mode']==mode)
        coverage[mode]={'metric':field,'observed':observed,'minimum':minimum,
                        'tested':observed>=minimum}
    total={
       'schema':'1U.1','runs':len(rows),'scenarios':list(MODES),
       'nfd_data_ingress_events':sum(r['ingress_count'] for r in rows),
       'explicit_nfd_data_pit_bindings':sum(r['pit_bind_count'] for r in rows),
       'multi_pit_data_arrivals_observed':sum(r['many_pit_arrivals'] for r in rows),
       'data_arrivals_without_active_pit_observed':sum(r['no_pit_arrivals'] for r in rows),
       'same_time_face_name_collisions_observed':sum(r['same_time_face_name_groups'] for r in rows),
       'physical_attribution_status_counts':dict(sorted(status.items())),
       'full_physical_attribution_verified':all(r['full_physical_attribution_verified'] for r in rows),
       'experiment_coverage':coverage,
       'coverage_acceptance':'PASS' if all(v['tested'] for v in coverage.values()) else 'INCOMPLETE',
       'simulation_coverage_note':'Observed counts only; a scenario name does not prove a collision occurred.',
       'Congestion':None,'FutureCongestion':None,'training_ready':False,
       'runs_detail':rows
    }
    (folder/'stage1u_summary.json').write_text(json.dumps(total,indent=2,sort_keys=True)+'\n')
    if total['coverage_acceptance'] != 'PASS':
        raise ValueError('At least one targeted contention event was not observed; inspect stage1u_summary.json')
    return total

if __name__=='__main__':
    try:
        result=summarize(sys.argv[1]);print(json.dumps(result,sort_keys=True))
    except Exception as exc:
        print('Stage1U summary invalid:',str(exc),file=sys.stderr)
        sys.exit(1)
