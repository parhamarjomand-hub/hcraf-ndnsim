#!/usr/bin/env python3
"""Reconcile one v0.52.0 CALIBRATION arm shard; never evaluate heldout or promote F3."""
import collections,csv,hashlib,json,pathlib,sys
from run_stage1am_f3_future_path_queue_calibration_v0521 import (
 shard_rows,ARMS,CONTRACT,OUT,REPORT,LOCKS,check,assert_send_plan,locked_plan,ROOT)

EVENTS={'QUEUE_ENQUEUE','QUEUE_DEQUEUE','QUEUE_DROP','PHY_TX_BEGIN','PHY_TX_END'}
PARENT=ROOT/'hcraf/episode/docs/1AM/F3_PATHWIDE_WITNESS_DEV_v0.51.5/PATH_MAP_LOCKED_24.csv'

def events(path):
 check(path.is_file(),'MISSING_TRACE:'+str(path))
 with path.open() as f:
  for lineno,line in enumerate(f,1):
   check(bool(line.strip()),'BLANK_TRACE_LINE:'+str(lineno))
   try: yield json.loads(line)
   except json.JSONDecodeError as exc: raise RuntimeError('BAD_JSON_LINE:'+str(lineno)) from exc

def reconcile(a,b):
 """Hash canonical shared physical events in exact file order, independent of recorder sequence and heartbeat."""
 def scan(path,is_b):
  digest=hashlib.sha256();total=0;initial={};final={};last_seq=0;last_ts=-1
  counts=collections.Counter();snapshots=collections.Counter();drops=collections.Counter()
  bad_age=0
  for event in events(path):
   seq=int(event['sequence'] if is_b else event['link_event_seq'])
   ts=int(event['timestamp_ns'] if is_b else event['time_ns'])
   check(seq==last_seq+1 and ts>=last_ts,'TRACE_ORDER_OR_TIMESTAMP_BROKEN')
   last_seq=seq;last_ts=ts
   kind=event['event_type'];node=int(event['node_id']);device=int(event['device_index']);key=(node,device)
   if is_b:check(event.get('monitor_id')=='B' and event.get('schema_version')=='PATHWIDE_WITNESS_B.1','WITNESS_B_SCHEMA')
   if kind=='INITIAL':
    check(key not in initial and ts==0,'BAD_INITIAL');initial[key]=event
   if kind=='FINAL':
    check(key not in final and ts==20000000000,'BAD_FINAL');final[key]=event
   if kind=='QUEUE_SNAPSHOT':
    check(is_b,'A_HAS_UNEXPECTED_B_SNAPSHOT')
    tick=int(event['sample_tick']);check(ts==tick*1000000,'BROKEN_SNAPSHOT_CLOCK')
    snapshots[key]+=1
    if not event.get('pending_age_verified'):bad_age+=1
   if kind in EVENTS:
    count=(kind,ts,node,device,event.get('packet_uid'),int(event['queue_packets']),int(event['queue_bytes']),
      int(event.get('queue_wait_ns') or 0))
    digest.update(json.dumps(count,separators=(',',':')).encode()+b'\n')
    total+=1;counts[(key,kind)]+=1
    if kind=='QUEUE_DROP':drops[key]+=1
  check(len(initial)==len(final)==20 and set(initial)==set(final),'INCOMPLETE_TWENTY_DEVICE_MONITOR')
  if is_b:
   check(all(snapshots[k]>=1999 for k in initial),'B_HEARTBEAT_COVERAGE_MISSING')
   check(bad_age==0,'UNVERIFIED_QUEUE_AGE')
  for key in initial:
   check(int(initial[key]['face_id'])==int(final[key]['face_id']),'FACE_ID_CHANGED')
   check(int(initial[key]['data_rate_bps'])>0 if not is_b else True,'RATE_MISSING')
  return dict(digest=digest.hexdigest(),events=total,initial=initial,final=final,counts=counts,drops=drops,
              snapshots=sum(snapshots.values()),bad_age=bad_age)
 a=scan(a,False);b=scan(b,True)
 check(a['digest']==b['digest'] and a['events']==b['events'],'RECORDER_AB_EVENT_LEVEL_MISMATCH')
 check(set(a['initial'])==set(b['initial']),'A_B_DEVICE_SET_MISMATCH')
 for key in a['initial']:
  check(a['initial'][key]['face_id']==b['initial'][key]['face_id'],'A_B_FACE_ID_MISMATCH')
  check(int(a['final'][key]['queue_drop_packets_total'])==int(b['final'][key]['drop_packets_cumulative']),'DROP_FINAL_MISMATCH')
  check(int(a['final'][key]['phy_tx_started_bytes_total'])==int(b['final'][key]['tx_bytes_cumulative']),'TX_FINAL_MISMATCH')
 return a,b

def audit(shard):
 rows,sites=shard_rows(shard)
 with PARENT.open(newline='') as f:oldmap=list(csv.DictReader(f))
 check(len(oldmap)==24,'PARENT_EIGHT_DEVICE_MAP_MISSING')
 report=REPORT/f'shard_{shard:02d}'
 check(not report.exists(),'REFUSE_OVERWRITE_REPORT')
 results=[]
 for row in rows:
  rng=row['rng_block'];fam=row['family'];arm=row['arm'];instrument=int(row['instrumented']);slot=int(row['selected_slot'])
  d=OUT/f'shard_{shard:02d}'/f'rng-{rng}'/fam/('monitored' if instrument else 'unmonitored')/arm
  check(d.is_dir(),'MISSING_SIMULATION:'+row['run_id'])
  c=json.loads((d/'scenario.json').read_text())
  check(c['amendment_stage']=='1AM.F3_FUTURE_PATH_QUEUE_PRESSURE_CALIBRATION.0','SCENARIO_STAGE_CHANGED')
  check(c['schedule_contract']=='F3_FUTURE_PATH_QUEUE_PRESSURE_PREREG_V0520_CALIBRATION_LOCKED_CSV','CONTRACT_CHANGED')
  check(c['holdout_partition']=='CALIBRATION' and c['topology_id']=='DEV_CHAIN_L','NON_DEV_SCENARIO')
  check(c['run']==int(rng) and c['selected_face_slot']==slot and c['schedule_family']==fam,'SCENARIO_CONTEXT_CHANGED')
  check(c['instrument_enabled']==bool(instrument),'MONITORING_FLAG_MISMATCH')
  check(c['intervention_location']==row['intervention_location'] and c['intervention_return_bps']==int(row['intervention_return_bps']),'INTERVENTION_CHANGED')
  check(c['loss_kind']==row['loss_kind'] and float(c['loss_probability'])==float(row['loss_probability']),'LOSS_INTERVENTION_CHANGED')
  check(int(c['loss_stream'])==int(row['loss_stream']) and int(c['loss_receiver_node_id'])==int(row['loss_receiver_node_id']) and int(c['loss_receiver_device_index'])==int(row['loss_receiver_device_index']),'LOSS_DESTINATION_CHANGED')
  for k,v in LOCKS.items():check(k in c and c[k] is v,'SCIENCE_LOCK_OPENED:'+k)
  check(c.get('future_oracle_is_final_F3') is False,'FORMAL_F3_LABELS_FORBIDDEN')
  assert_send_plan(d,locked_plan(row))
  rec={'run_id':row['run_id'],'rng_block':rng,'arm':arm,'family':fam,'instrumented':instrument,
       'status':'PASS_CALIBRATION_STRUCTURAL_ONLY','loss_rx_drop_count':0}
  for x in events(d/'fault_events.jsonl'):
   check(x['event']=='PHY_RX_DROP' and int(x['node_id'])==1 and int(x['device_index'])==slot+1,'WRONG_PHY_RX_DROP_IDENTITY')
   rec['loss_rx_drop_count']+=1
  if instrument:
   a,b=reconcile(d/'link_events.jsonl',d/'pathwide_witness_b.jsonl')
   path={(int(x['sender_node_id']),int(x['device_index'])) for x in oldmap if int(x['slot'])==slot}
   check(len(path)==8 and path.issubset(a['initial']),'EIGHT_DIRECTIONAL_PATH_MISSING')
   rev={('PRODUCER_RETURN'):(8,9,10)[slot],('MID_RETURN'):(7,6,5)[slot],('RELAY_RETURN'):1}
   # Instrumentation intervention matches exactly one return net device.
   expected={(rev['PRODUCER_RETURN'],0):50000000,(rev['MID_RETURN'],0):50000000,
             (2+slot,0):50000000}
   loc=row['intervention_location']
   if loc=='PRODUCER_RETURN':expected[(rev['PRODUCER_RETURN'],0)]=int(row['intervention_return_bps'])
   if loc=='MID_RETURN':expected[(rev['MID_RETURN'],0)]=int(row['intervention_return_bps'])
   if loc=='RELAY_RETURN':expected[(2+slot,0)]=int(row['intervention_return_bps'])
   for key,bps in expected.items():check(a['initial'][key]['data_rate_bps']==bps,'ACTUAL_BOTTLENECK_RATE_OR_NODE_WRONG:'+str(key))
   rec.update(a_b_agreement='PASS_EVENT_LEVEL',physical_events=a['events'],path_queue_drops=sum(a['drops'][p] for p in path),
              total_queue_drops=sum(a['drops'].values()),devices=20,path_devices=8,recorder_b_snapshots=b['snapshots'])
  else:
   check(not (d/'link_events.jsonl').exists() and not (d/'pathwide_witness_b.jsonl').exists(),'UNMONITORED_TRACE_PRESENT')
  check((d/'resource_usage.txt').is_file(),'RESOURCE_MEASUREMENT_MISSING')
  results.append(rec)
 check(len(results)==27 and sum(r['instrumented'] for r in results)==24,'WRONG_COMPLETED_SHARD_COUNT')
 report.mkdir(parents=True)
 with (report/'shard_reconciliation.csv').open('w',newline='') as f:
  cols=sorted(set().union(*(x.keys() for x in results)));w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(results)
 summary=dict(status='PASS_V0521_FUTURE_PATH_QUEUE_CALIBRATION_SHARD_STRUCTURAL_ONLY',shard_id=shard,arm=ARMS[shard],
      runs=27,monitored_runs=24,unmonitored_runs=3,whole_matrix_completed=False,
      split='CALIBRATION',final_F3_validated=False,scientific_construct_validated=False,heldout_runs_executed=0,
      historical_stage1s_full_regression_verified=False,**LOCKS)
 (report/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
 return summary

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--shard-id',type=int,required=True);a=p.parse_args()
 print(json.dumps(audit(a.shard_id),indent=2))
