#!/usr/bin/env python3
"""Only v0.52.0 locked CALIBRATION rows, eight 27-run shards; never heldout."""
import argparse,csv,hashlib,json,os,pathlib,subprocess
ROOT=pathlib.Path(__file__).resolve().parents[3]
CONTRACT=ROOT/'hcraf/episode/docs/1AM/F3_FUTURE_PATH_QUEUE_PRESSURE_PREREG_v0.52.0'
OUT=ROOT/'episode_output/stage1am_f3_future_queue_calibration_v0521'
REPORT=ROOT/'episode_output/stage1am_f3_future_queue_calibration_report_v0521'
ARMS=('PRODUCER_RETURN_6M','PRODUCER_RETURN_12M','MID_RETURN_6M','MID_RETURN_12M',
      'RELAY_RETURN_6M','RELAY_RETURN_12M','ALL_RETURN_50M','NONQUEUE_RX_LOSS_50M')
LOCKS={'Congestion':None,'FutureCongestion':None,'F3_ready':False,'GO_FREEZE':False,'training_ready':False}
HASHES={'RUN_MATRIX_LOCKED_648.csv': '920c190702526ad11efc10781ce23c629e7918932b4c52159fbfb96234600bd3', 'SCHEDULE_INDEX_LOCKED_72.csv': '6a35930586c4891fe4fc4a9425b9a6f56857f8a6297685be6f1c2cdfd58d97cc', 'INTERVENTION_SITES_LOCKED_12.csv': '2a1d0ced27b91f7ac0d5f2b19be16d8e1219a5320d12d461d75bba34d1e82964', 'RNG_SPLIT_LOCKED_36.csv': 'f6f80c479ddb77c7c71f9481ce2cffc12365557e86aabba083aaf317aacb1693', 'SCIENTIFIC_PROTOCOL_FA.md': '6996b2e17fa72916b383c3406f8f8d0150b5b597d3b890553906311a28291e5d', 'label_rules.py': '1cadf975285fe7327915deb6d3b4d9f7d9e238b0a842c550ad4f70b9a73198a4'}

def check(ok,why):
 if not ok:raise RuntimeError(why)
def sha(path):return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
def readcsv(path):
 with pathlib.Path(path).open(newline='') as f:return list(csv.DictReader(f))
def locked_plan(row):
 p=(CONTRACT/row['plan_filename']).resolve();root=CONTRACT.resolve()
 check(os.path.commonpath((str(p),str(root)))==str(root),'UNSAFE_PLAN_PATH')
 check(p.is_file() and sha(p)==row['schedule_sha256'],'LOCKED_PLAN_CHANGED')
 return p
def matrix():
 for name,h in HASHES.items():check(sha(CONTRACT/name)==h,'LOCKED_FILE_CHANGED:'+name)
 rows=readcsv(CONTRACT/'RUN_MATRIX_LOCKED_648.csv')
 check(len(rows)==648 and len({r['run_id'] for r in rows})==648,'BAD_MATRIX_CARDINALITY')
 check(sum(r['split']=='CALIBRATION' for r in rows)==216 and sum(r['split']=='HELDOUT_CONFIRMATORY' for r in rows)==432,'SPLIT_COUNTS_CHANGED')
 rows=[r for r in rows if r['split']=='CALIBRATION']
 check(sum(int(r['instrumented']) for r in rows)==192,'WRONG_MONITORED_COUNT')
 check({int(r['rng_block']) for r in rows}==set(range(22001,22013)),'WRONG_RNG_SET')
 check({r['status'] for r in rows}=={'PREREG_PLANNED_ZERO_EXECUTED'},'LABELS_PREMATURELY_ASSIGNED')
 check(all(r['plan_filename'].startswith('plans/calibration/') for r in rows),'HELDOUT_PLAN_ACCESS_DENIED')
 sites=readcsv(CONTRACT/'INTERVENTION_SITES_LOCKED_12.csv')
 check(len(sites)==12,'BAD_INTERVENTION_MAP')
 for r in rows:
  check(r['arm'] in ARMS and r['seed']=='17' and int(r['selected_slot'])==(int(r['rng_block'])-22001)%3,'BAD_ROW_CONTEXT')
  check(r['load_level']==('LIGHT' if (int(r['rng_block'])-22001)%6<3 else 'HEAVY'),'LOAD_LEVEL_PHASE_MISMATCH')
  check(r['other_path_return_bps']==r['forward_bps']=='50000000','OTHER_LINK_RATE_CHANGED')
  check(r['loss_stream']=='79','LOSS_STREAM_CHANGED')
  check((r['loss_kind']=='RATE_ERROR_MODEL_RX')==(r['arm']=='NONQUEUE_RX_LOSS_50M'),'LOSS_CONTROL_CHANGED')
  locked_plan(r)
 return rows,sites
def shard_rows(shard):
 check(shard in range(8),'SHARD_ID_OUT_OF_RANGE')
 rows,sites=matrix();out=[r for r in rows if r['arm']==ARMS[shard] and r['split']=='CALIBRATION']
 check(len(out)==27 and sum(int(r['instrumented']) for r in out)==24,'SHARD_CARDINALITY_CHANGED')
 return out,sites

def assert_send_plan(run_dir,plan):
 rows=readcsv(plan);check(len(rows)==108,'WRONG_PLAN_ROWS')
 for traffic,filename,prefix,expected_count in [('TARGET','consumer_events.jsonl','/hcraf/pilot/',12),
       ('INDEPENDENT_COMPETITOR','competitor_events.jsonl','/hcraf/competitor/',96)]:
  expected={int(r['sequence']):int(r['time_ns']) for r in rows if r['traffic_class']==traffic}
  arrivals=[json.loads(x) for x in (run_dir/(filename+'.arrivals.jsonl')).read_text().splitlines() if x]
  sends=[json.loads(x) for x in (run_dir/filename).read_text().splitlines() if x]
  sends=[x for x in sends if x.get('event')=='SEND']
  check(len(expected)==len(arrivals)==len(sends)==expected_count,'SEND_COUNT_MISMATCH')
  check({int(a['sequence']):int(a['time_ns']) for a in arrivals}==expected,'ARRIVAL_PLAN_MISMATCH')
  check({int(s['name'].split('/')[-1]):int(s['time_ns']) for s in sends if s['name'].startswith(prefix)}==expected,'SEND_PLAN_MISMATCH')
  check({a['schedule'] for a in arrivals}=={'F3_FUTURE_PATH_QUEUE_PRESSURE_PREREG_V0520_CALIBRATION_LOCKED_CSV'},'SCHEDULE_NOT_LOCKED')

def simulation_args(row,dest):
 fam=row['family'];rng=row['rng_block'];arm=row['arm']
 p=locked_plan(row)
 args=[f'--pathArm={arm}',f'--interventionLocation={row["intervention_location"]}',
 f'--interventionReturnBps={row["intervention_return_bps"]}',f'--lossProbability={row["loss_probability"]}',
 f'--lossStream={row["loss_stream"]}',f'--lossReceiverNodeId={row["loss_receiver_node_id"]}',
 f'--lossReceiverDeviceIndex={row["loss_receiver_device_index"]}',f'--scheduleFamily={fam}',
 f'--scheduleCsv={p}',f'--selectedSlot={row["selected_slot"]}',f'--run={rng}',
 f'--output={dest}',f'--instrument={row["instrumented"]}','--topology=DEV_CHAIN_L',
 '--mode=LP_INDEPENDENT_COMPETITOR_NO_DROP','--seed=17','--lifetimeMs=2600',
 '--requestCount=12','--intervalNs=30000000','--competitorCount=96',
 '--competitorIntervalNs=2000000','--competitorOffsetNs=0','--targetOffsetNs=30000000',
 '--forwardBps=50000000','--returnBps=50000000']
 return 'hcraf-stage1am-f3-future-path-queue-calibration-v0521 '+' '.join(args)
def execute(shard):
 rows,sites=shard_rows(shard)
 check((ROOT/'episode_sources/ns-3/build/scratch/hcraf-stage1am-f3-future-path-queue-calibration-v0521').is_file(),'NEW_CPP_NOT_BUILT')
 check(not (OUT/f'shard_{shard:02d}').exists() and not (REPORT/f'shard_{shard:02d}').exists(),'SHARD_EXISTS_REFUSE_OVERWRITE')
 for i,row in enumerate(rows,1):
  rng=row['rng_block'];arm=row['arm'];fam=row['family'];kind='monitored' if int(row['instrumented']) else 'unmonitored'
  dest=OUT/f'shard_{shard:02d}'/f'rng-{rng}'/fam/kind/arm
  dest.mkdir(parents=True,exist_ok=False)
  spec=simulation_args(row,dest)
  (dest/'command.txt').write_text(spec+'\n')
  (dest/'locked_row.json').write_text(json.dumps(row,indent=2,sort_keys=True)+'\n')
  with (dest/'simulator.log').open('w') as log:
   subprocess.run(['/usr/bin/time','-f','wall_seconds=%e\nuser_seconds=%U\nsystem_seconds=%S\nmax_rss_kib=%M',
       '-o',str(dest/'resource_usage.txt'),'python3','./waf','--run-no-build',spec],
       cwd=ROOT/'episode_sources/ns-3',stdout=log,stderr=subprocess.STDOUT,check=True)
  assert_send_plan(dest,locked_plan(row))
  if int(row['instrumented']):
   with (dest/'episodes.log').open('w') as log:
    subprocess.run(['python3',str(ROOT/'hcraf/episode/scripts/episodes_stage1u.py'),str(dest),
      '--run-id','1am_future_queue-CALIBRATION-v0521-'+rng+'-'+fam+'-'+arm],
      cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
  print('RUN_OK',i,'of',len(rows),row['run_id'],flush=True)
 from verify_stage1am_f3_future_path_queue_calibration_v0521 import audit
 print(json.dumps(audit(shard),indent=2),flush=True)

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--shard-id',type=int,required=True)
 parser.add_argument('--preflight-only',action='store_true');args=parser.parse_args()
 if args.preflight_only:
  rows,sites=shard_rows(args.shard_id)
  print(json.dumps({'status':'PASS_SHARD_PREREG_PREFLIGHT_NO_SIMULATIONS','shard_id':args.shard_id,
      'arm':ARMS[args.shard_id],'rows':len(rows),'locks':LOCKS},indent=2))
 else:execute(args.shard_id)
