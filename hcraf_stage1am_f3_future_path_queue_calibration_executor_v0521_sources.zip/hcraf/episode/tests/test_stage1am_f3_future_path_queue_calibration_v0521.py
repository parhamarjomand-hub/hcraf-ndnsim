"""Tests calibrator safety fences and immutable v0.52.0 schedule semantics. No simulator required."""
import csv,hashlib,importlib.util,json,pathlib,sys,unittest,unittest.mock
ROOT=pathlib.Path(__file__).resolve().parents[3]
SCRIPT=ROOT/'hcraf/episode/scripts'
sys.path.insert(0,str(SCRIPT))
import run_stage1am_f3_future_path_queue_calibration_v0521 as x

class CalibratorV0521(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.rows,cls.sites=x.matrix()
 def test_01_parent_lock(self):
  self.assertEqual(x.HASHES['RUN_MATRIX_LOCKED_648.csv'],'920c190702526ad11efc10781ce23c629e7918932b4c52159fbfb96234600bd3')
 def test_02_calibration_only(self):
  self.assertEqual(len(self.rows),216);self.assertEqual({r['split'] for r in self.rows},{'CALIBRATION'})
 def test_03_plan_path_calibration(self):
  self.assertTrue(all('/calibration/' in '/'+r['plan_filename'] for r in self.rows))
 def test_04_rng(self):
  self.assertEqual({int(r['rng_block']) for r in self.rows},set(range(22001,22013)))
 def test_05_no_holdout_ids(self):
  self.assertFalse(any('23001' in r['run_id'] or r['split']!='CALIBRATION' for r in self.rows))
 def test_06_all_shards(self):
  for shard in range(8):
   rows,_=x.shard_rows(shard)
   self.assertEqual(len(rows),27)
   self.assertEqual(sum(int(r['instrumented']) for r in rows),24)
 def test_07_no_unregistered_shards(self):
  for shard in [-1,8,10]:
   with self.assertRaises(RuntimeError):x.shard_rows(shard)
 def test_08_metadata_new_family(self):
  self.assertEqual({r['family'] for r in self.rows},{'C_STAGGERED_BURSTS','D_RAMPED_PULSES'})
 def test_09_paired_plan_identity(self):
  from collections import defaultdict
  groups=defaultdict(set)
  for r in self.rows:groups[(r['rng_block'],r['family'])].add(r['schedule_sha256'])
  self.assertEqual(len(groups),24)
  self.assertTrue(all(len(v)==1 for v in groups.values()))
 def test_10_exact_plan_size(self):
  for r in self.rows[::9]:
   with x.locked_plan(r).open(newline='') as f:
    a=list(csv.DictReader(f))
   self.assertEqual(len(a),108)
   self.assertEqual(sum(z['traffic_class']=='TARGET' for z in a),12)
   self.assertEqual(sum(z['traffic_class']=='INDEPENDENT_COMPETITOR' for z in a),96)
 def test_11_arms_and_loss(self):
  self.assertEqual(sum(r['loss_kind']=='RATE_ERROR_MODEL_RX' for r in self.rows),27)
 def test_12_science_locks(self):
  self.assertEqual(x.LOCKS,{'Congestion':None,'FutureCongestion':None,'F3_ready':False,'GO_FREEZE':False,'training_ready':False})
 def test_13_tampered_matrix_denied(self):
  with unittest.mock.patch.object(x,'sha',side_effect=lambda p: 'bad' if str(p).endswith('RUN_MATRIX_LOCKED_648.csv') else hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()):
   with self.assertRaisesRegex(RuntimeError,'LOCKED_FILE_CHANGED'): x.matrix()
 def test_14_holdout_plan_denied(self):
  r=dict(self.rows[0]);r['plan_filename']='plans/heldout_confirmatory/rng-23001_C_STAGGERED_BURSTS.csv'
  with self.assertRaisesRegex(RuntimeError,'LOCKED_PLAN_CHANGED'):x.locked_plan(r)
 def test_15_traversal_denied(self):
  r=dict(self.rows[0]);r['plan_filename']='../../../tmp/unsafe.csv'
  with self.assertRaisesRegex(RuntimeError,'UNSAFE_PLAN_PATH'): x.locked_plan(r)
 def test_16_binary_is_new(self):
  self.assertIn('future-path-queue-calibration-v0521',x.simulation_args(self.rows[0],pathlib.Path('/tmp/calibration')))
 def test_17_cpp_never_accepts_old_families(self):
  s=(ROOT/'hcraf/episode/src/hcraf-stage1am-f3-future-path-queue-calibration-v0521.cpp').read_text()
  for token in ['C_STAGGERED_BURSTS','D_RAMPED_PULSES','run<22001','run>22012','cols[5]!="CALIBRATION"','cols.size()!=12']:
   self.assertIn(token,s)
  for token in ['A_SHIFTED_PULSES','B_INTERLEAVED_PULSES','run<11901','run>11912']:
   self.assertNotIn(token,s)
 def test_18_build_is_unique(self):
  b=(SCRIPT/'build_stage1am_f3_future_path_queue_calibration_v0521.sh').read_text()
  self.assertIn('hcraf-stage1am-f3-future-path-queue-calibration-v0521.cpp',b)
 def test_19_no_model_training(self):
  s=(ROOT/'hcraf/episode/docs/1AM/F3_FUTURE_PATH_QUEUE_CALIBRATION_EXECUTOR_v0.52.1/SCIENCE_LOCKS.json').read_text()
  j=json.loads(s);self.assertFalse(j['heldout_release_authorized']);self.assertIsNone(j['FutureCongestion'])
 def test_20_old_mapping_schema(self):
  s=(SCRIPT/'verify_stage1am_f3_future_path_queue_calibration_v0521.py').read_text()
  self.assertIn("x['sender_node_id']",s);self.assertIn("x['device_index']",s)
 def test_21_monitor_path_assertions(self):
  s=(SCRIPT/'verify_stage1am_f3_future_path_queue_calibration_v0521.py').read_text()
  self.assertIn('RECORDER_AB_EVENT_LEVEL_MISMATCH',s);self.assertIn('EIGHT_DIRECTIONAL_PATH_MISSING',s)
 def test_22_no_heldout_selector(self):
  s=(SCRIPT/'run_stage1am_f3_future_path_queue_calibration_v0521.py').read_text()
  self.assertNotIn("add_argument('--split'",s)
 def test_23_immutable_rules_version(self):
  spec=json.loads((x.CONTRACT/'CONSTRUCT_SPEC_LOCKED.json').read_text())
  self.assertEqual(spec['horizon_ns'],75000000);self.assertFalse(spec['is_official_F3_label'])
 def test_25_load_level_is_phase_balanced(self):
  from collections import Counter
  self.assertEqual(Counter(r['load_level'] for r in self.rows),{'LIGHT':108,'HEAVY':108})
  self.assertTrue(all(r['load_level']==('LIGHT' if (int(r['rng_block'])-22001)%6<3 else 'HEAVY') for r in self.rows))
 def test_24_no_simulated_data_in_artifact(self):
  p=ROOT/'hcraf/episode/docs/1AM/F3_FUTURE_PATH_QUEUE_CALIBRATION_EXECUTOR_v0.52.1/SCIENCE_LOCKS.json'
  self.assertEqual(json.loads(p.read_text())['heldout_runs_executed'],0)

if __name__=='__main__':unittest.main()
