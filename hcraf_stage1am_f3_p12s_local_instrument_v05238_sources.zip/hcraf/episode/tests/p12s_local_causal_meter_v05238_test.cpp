#include "hcraf-stage1am-f3-p12s-local-causal-meter-v05238.hpp"
#include <iostream>
#include <stdexcept>
#include <cmath>
using namespace hcraf_p12s;
static void require(bool x,const char* msg){if(!x)throw std::runtime_error(msg);}
template <typename F>static void fails(F f){bool caught=false;try{f();}catch(const std::exception&){caught=true;}require(caught,"EXPECTED_FAIL_CLOSED");}
static BeforeDecisionLocalState d(std::uint64_t t,std::uint64_t seq,std::uint64_t face=7){return {t,seq,1,face,1,2,10,true,9};}
static LocalEvent e(Kind k,std::uint64_t t,std::uint64_t ord,std::uint64_t face=7,double rtt=0){return{k,t,ord,face,1,true,rtt};}
int main(){
 {
  LocalCausalMeter m;
  auto a=m.capture(d(100000000ULL,1));
  require(a.values[0]==1 && a.values[1]==2 && a.values[2]==0.2 && a.values[3]==1 && a.values[4]==9,"BASE_FEATURES");
  require(a.values[10]==0 && a.values[11]==1,"RTT_MISSING_DEFAULT");
  std::cout<<"PASS_P12S_INITIAL_STATE_AND_MISSING_RTT\n";
 }
 {
  LocalCausalMeter m;
  m.observe(e(Kind::InterestRx,25000000ULL,1)); // exactly t-75ms excluded
  m.observe(e(Kind::InterestRx,25000001ULL,2)); // within
  m.observe(e(Kind::DataRx,30000000ULL,3));
  m.observe(e(Kind::NackRx,40000000ULL,4));
  m.observe(e(Kind::SelectedFaceTx,50000000ULL,5,7));
  m.observe(e(Kind::SelectedFaceTx,60000000ULL,6,8)); // different face rejected from selected count
  m.observe(e(Kind::SelectedFaceDrop,70000000ULL,7,7));
  m.observe(e(Kind::SelectedFaceDrop,80000000ULL,8,8));
  m.observe(e(Kind::CompletedLocalDataRtt,90000000ULL,9,7,10.0));
  m.observe(e(Kind::CompletedLocalDataRtt,90000000ULL,10,7,18.0));
  m.observe(e(Kind::InterestRx,100000000ULL,11)); // same-tick-before-decision
  auto a=m.capture(d(100000000ULL,12));
  require(a.values[5]==2 && a.values[6]==1 && a.values[7]==1,"INTEREST_DATA_NACK_WINDOWS");
  require(a.values[8]==1 && a.values[9]==1,"FACE_SPECIFIC_COUNTS");
  require(std::abs(a.values[10]-11.0)<1e-9 && a.values[11]==0,"LOCAL_RTT_EWMA");
  require(a.same_tick_events_included,"SAME_TICK_EVENT_ORDERING");
  require(m.decisionCount()==1 && m.localCompletedRttCount()==2,"COUNTER_COUNTS");
  auto b=m.capture(d(200000000ULL,13));
  require(b.values[5]==0 && b.values[6]==0 && b.values[7]==0 && b.values[8]==0,"PRUNED_75MS_WINDOW");
  std::cout<<"PASS_P12S_CAUSAL_OPEN_WINDOW_SELECTED_FACE_AND_COMPLETED_RTT\n";
 }
 {
  LocalCausalMeter m;
  LocalEvent bad=e(Kind::InterestRx,1,1);bad.node_id=2;
  fails([&](){m.observe(bad);});
  bad=e(Kind::InterestRx,1,1);bad.observed_before_decision=false;
  fails([&](){m.observe(bad);});
  fails([&](){m.observe(e(Kind::CompletedLocalDataRtt,1,1,7,-10));});
  m.observe(e(Kind::DataRx,500,1));
  fails([&](){m.observe(e(Kind::DataRx,500,1));});
  fails([&](){m.capture(d(400,2));});
  auto wrong=d(1000,2);wrong.node_id=5;
  fails([&](){m.capture(wrong);});
  wrong=d(1000,2);wrong.selected_queue_capacity_packets=0;
  fails([&](){m.capture(wrong);});
  wrong=d(1000,2);wrong.selected_queue_packets=11;
  fails([&](){m.capture(wrong);});
  auto first=m.capture(d(1000,2));
  require(first.values[6]==1,"VALID_AFTER_REJECTION");
  fails([&](){m.capture(d(1000,2));});
  fails([&](){m.observe(e(Kind::InterestRx,900,3));});
  std::cout<<"PASS_P12S_FAIL_CLOSED_LOCAL_ORDER_CAUSALITY_AND_QUEUE\n";
 }
 require(B1_FEATURES.size()==12,"EXACT_12_B1_FEATURES");
 std::cout<<"PASS_P12S_CXX17_LOCAL_METER_COMPILE_AND_EXECUTION_ONLY_NO_SIM\n";
}
