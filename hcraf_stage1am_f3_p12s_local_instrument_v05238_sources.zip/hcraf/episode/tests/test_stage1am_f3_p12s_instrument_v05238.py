import importlib.util,json,pathlib,tempfile,unittest
P=pathlib.Path('hcraf/episode/scripts/audit_stage1am_f3_p12s_instrument_v05238.py')
spec=importlib.util.spec_from_file_location('p12s_audit',P);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class P12S(unittest.TestCase):
 def test_static_gates(self):
  self.assertEqual(m.PR_SHA,'dbb12863ca83c26b687b243211aaf698986b8d6f2f7b8656cffb06278751ae30')
 def test_legacy_sha_locked(self):self.assertEqual(len(m.L6_SHA),64)
 def test_plan_sha_locked(self):self.assertEqual(len(m.PLAN_SHA),64)
 def test_snapshot_node_restricted(self):self.assertIn('P12S_SNAPSHOT_NOT_LOCAL_NODE_1',m.S_H.read_text())
 def test_decision_order_restricted(self):self.assertIn('P12S_NONMONOTONE_DECISION',m.S_H.read_text())
 def test_lookback_fixed(self):self.assertIn('LOOKBACK_NS = 75000000ULL',m.S_H.read_text())
 def test_missing_feature_not_fitted(self):self.assertIn('local_data_rtt_missing_at_t',m.S_H.read_text())
 def test_no_remote_features_in_B1(self):
  s=m.S_H.read_text();self.assertNotIn('relay_queue_packets',s);self.assertNotIn('mid_queue_packets',s)
 def test_no_ap_code(self):
  s=P.read_text();self.assertNotIn('average_precision(',s);self.assertNotIn('bootstrap(',s)
 def test_locked_fail_closed(self):
  with self.assertRaisesRegex(RuntimeError,'FAIL_CLOSED_P12S'):
   m.require(False,'F3_FLAG_NOT_ALLOWED')
 def test_scientific_flags_false(self):
  self.assertIn("'F3_ready':False",P.read_text());self.assertIn("'GO_FREEZE':False",P.read_text())
 def test_independent_study_not_simulated(self):
  self.assertIn("'physical_scenarios_run':0",P.read_text())
 def test_real_sources_required(self):
  with self.assertRaises(Exception):m.audit('/path/that/does/not/exist','x','x',m.S_H)
 def test_named_source_paths(self):
  self.assertTrue(m.PR.endswith('_sources.zip') and m.L6.endswith('_sources.zip'))
if __name__=='__main__':unittest.main()
