#!/usr/bin/env python3
"""P12S compile/source provenance audit ONLY. No sim, scoring, confirm, training."""
import argparse, hashlib, json, pathlib, re, zipfile
S_H=pathlib.Path('hcraf/episode/src/hcraf-stage1am-f3-p12s-local-causal-meter-v05238.hpp')
PR='hcraf_stage1am_f3_p12r_fair_comparator_prereg_v05237_sources.zip'
L6='hcraf_stage1am_f3_p12l6_physical_v05231_cpp_initializer_hotfix_sources.zip'
PR_SHA='dbb12863ca83c26b687b243211aaf698986b8d6f2f7b8656cffb06278751ae30'
L6_SHA='f45e1e1b9dfa276568e9c3b6989dfec6496e8fc7e3d86e1b30d53963b549a265'
P12R_RECEIPT_SHA='79dc4317cfe76643ad12b7d431ff5f734ff9d143b578fbfc1ac50dab87ca12ff'
PLAN_SHA='b7196b2fcca560c7e0f72596db11be750116985e5c27495759fa7caff06faf9b'
CONTRACT='PASS_P12S_LOCAL_INSTRUMENT_CXX17_KERNEL_AND_CAUSAL_GUARDS_ONLY'
def sha(raw): return hashlib.sha256(raw).hexdigest()
def require(v,msg):
 if not v:raise RuntimeError('FAIL_CLOSED_P12S_'+str(msg))
def audit(pr,legacy,receipt,header):
 p=pathlib.Path(pr).read_bytes(); require(sha(p)==PR_SHA,'P12R_SOURCE_SHA')
 with zipfile.ZipFile(pr) as z:
  plan_name=next(n for n in z.namelist() if n.endswith('P12R_FAIR_COMPARATOR_PROSPECTIVE_PLAN_v05237.json'))
  plan_bytes=z.read(plan_name);require(sha(plan_bytes)==PLAN_SHA,'P12R_PLAN_SHA')
  plan=json.loads(plan_bytes)
  b1=plan['feature_sets']['strengthened_local_B1_primary_control'];treat=plan['feature_sets']['remote_plus_B1_R_primary_treatment']
  require(len(b1)==12 and len(treat)==21 and treat[:12]==b1,'EXACT_NESTED_FEATURES')
  require(plan['causal_instrumentation_rules']['local_sampler'].startswith('node 1'),'NODE1_RULE')
  require(plan['causal_instrumentation_rules']['local_rolling_window'].startswith('(t-75ms,t]'),'CAUSAL_WINDOW')
  require(plan['current_step_only']['independent_study_execution_authorized'] is False,'SIM_AUTH')
  require(plan['F3_ready'] is False and plan['GO_FREEZE'] is False,'F3_FENCE')
 l=pathlib.Path(legacy).read_bytes();require(sha(l)==L6_SHA,'L6_SOURCE_SHA')
 with zipfile.ZipFile(legacy) as z:
  cpp=z.read(next(n for n in z.namelist() if n.endswith('.cpp'))).decode()
  for anchor in ['hcrafSetDecisionObserver','ObserveBeforeForwarding(id)','HcrafStage1amLocalSnapshot','GetObject<ns3::ndn::L3Protocol>()','TraceConnectWithoutContext("PhyRxDrop"']:
   require(anchor in cpp,'FROZEN_NATIVE_CODE_ANCHOR_'+anchor)
  require('nodes.Get(1)' in cpp,'NODE1_SOURCE')
 rbytes=pathlib.Path(receipt).read_bytes();require(sha(rbytes)==P12R_RECEIPT_SHA,'P12R_GITHUB_RECEIPT_SHA')
 r=json.loads(rbytes)
 require(r['status']=='PASS_P12R_NEW_FAIR_COMPARATOR_STUDY_PROSPECTIVELY_PREREGISTERED_ONLY','P12R_PARENT')
 require(r['case_count']==504 and r['schedule_count']==252,'P12R_MATRIX')
 require(r['new_models_fit']==0 and r['physical_cases_run']==0 and r['new_AP_computed'] is False,'P12R_ZERO_SIM')
 require(r['matrix_sha256']==plan['prospective_design']['matrix_sha256'],'P12R_PLAN_RECEIPT_CONSISTENT')
 raw=pathlib.Path(header).read_text();names=re.findall(r'^\s*"([a-z0-9_]+)"\s*,?$',raw,re.M)
 require(names==b1,'HEADER_EXACT_B1_ORDER')
 for t in ['LOOKBACK_NS = 75000000ULL','RTT_EWMA_ALPHA = 0.125','P12S_FUTURE_EVENT_IN_OBSERVER','P12S_EVENT_NOT_CAUSALLY_OBSERVED','P12S_SNAPSHOT_NOT_LOCAL_NODE_1','P12S_NONMONOTONE_DECISION','P12S_INVALID_SELECTED_LOCAL_FACE_QUEUE']:
  require(t in raw,'NO_GUARD_'+t)
 return {'status':CONTRACT,'stage':'P12S_v0.52.38',
  'p12r_success_run':45833974569,'p12r_source_sha256':PR_SHA,'p12r_receipt_json_sha256':P12R_RECEIPT_SHA,
  'p12r_plan_sha256':PLAN_SHA,'legacy_source_sha256':L6_SHA,
  'local_feature_names':b1,'remote_extension_feature_count':len(treat)-len(b1),
  'compiled_core_only':True,'ndnsim_integration_compiled':False,'native_traces_wired':False,
  'physical_scenarios_run':0,'development_seeds_consumed':0,'confirmatory_seeds_consumed':0,
  'model_fits':0,'new_AP_computed':False,'new_bootstrap_computed':False,'Validation_read':False,'Heldout_read':False,
  'F3_ready':False,'GO_FREEZE':False,'training_ready':False,'Stage1AO_or_NSGAIII_authorized':False,
  'scientific_decision':'NO_F3_GO_IMPLEMENTATION_KERNEL_ONLY_PENDING_REAL_NDNSIM_WIRING_AND_DEV_QC'}
def main():
 a=argparse.ArgumentParser();a.add_argument('--p12r',default=PR);a.add_argument('--legacy',default=L6);a.add_argument('--receipt',required=True);a.add_argument('--output',required=True);args=a.parse_args()
 result=audit(args.p12r,args.legacy,args.receipt,S_H)
 pathlib.Path(args.output).write_text(json.dumps(result,indent=2,ensure_ascii=False,sort_keys=True)+'\n')
 print(CONTRACT)
if __name__=='__main__':main()
