#pragma once
// P12S v0.52.38: local-only causal instrumentation KERNEL for node 1.
// NOT yet integrated into ndnSIM; do not infer physical readiness or F3 GO.
// Contract anchored to P12R v0.52.37 before development/confirmation.
#include <array>
#include <cstdint>
#include <deque>
#include <stdexcept>
#include <string>
#include <utility>

namespace hcraf_p12s {
constexpr std::uint64_t LOOKBACK_NS = 75000000ULL;
constexpr double RTT_EWMA_ALPHA = 0.125; // Fixed implementation detail before development.
constexpr std::array<const char*, 12> B1_FEATURES = {{
 "fib_route_cost",
 "local_selected_queue_packets",
 "local_selected_queue_fraction",
 "local_selected_link_up",
 "local_pit_occupancy_at_t",
 "local_interest_rx_count_previous_75ms",
 "local_data_rx_count_previous_75ms",
 "local_nack_rx_count_previous_75ms",
 "local_selected_face_tx_count_previous_75ms",
 "local_selected_face_drop_count_previous_75ms",
 "local_data_rtt_ewma_before_t",
 "local_data_rtt_missing_at_t"
}};

enum class Kind { InterestRx, DataRx, NackRx, SelectedFaceTx, SelectedFaceDrop, CompletedLocalDataRtt };
struct LocalEvent {
  Kind kind;
  std::uint64_t time_ns;
  std::uint64_t ordinal;
  std::uint64_t face_id;
  std::uint32_t node_id;
  bool observed_before_decision;
  double rtt_ms;
};
struct BeforeDecisionLocalState {
  std::uint64_t time_ns;
  std::uint64_t ordinal; // observer's causal ordering within same tick
  std::uint32_t node_id;
  std::uint64_t selected_face_id;
  std::uint64_t route_cost;
  std::uint64_t selected_queue_packets;
  std::uint64_t selected_queue_capacity_packets;
  bool selected_link_up;
  std::uint64_t local_pit_occupancy;
};
struct B1Snapshot {
  std::array<double,12> values;
  std::uint64_t decision_time_ns, decision_ordinal, selected_face_id;
  std::uint32_t node_id;
  bool same_tick_events_included;
};

class LocalCausalMeter {
 public:
  LocalCausalMeter() = default;
  static bool earlier(std::uint64_t time_a, std::uint64_t ordinal_a,
                      std::uint64_t time_b, std::uint64_t ordinal_b) {
    return time_a < time_b || (time_a==time_b && ordinal_a<ordinal_b);
  }
  void observe(const LocalEvent& e) {
    if (e.node_id!=1) throw std::runtime_error("P12S_NOT_LOCAL_NODE_1");
    if (!e.observed_before_decision) throw std::runtime_error("P12S_EVENT_NOT_CAUSALLY_OBSERVED");
    if (m_started && !earlier(m_last_time,m_last_order,e.time_ns,e.ordinal))
      throw std::runtime_error("P12S_NONMONOTONE_OR_DUPLICATED_EVENT");
    if (m_decisions && !earlier(m_decision_time,m_decision_order,e.time_ns,e.ordinal))
      throw std::runtime_error("P12S_LATE_EVENT_AFTER_DECISION");
    if (e.kind==Kind::CompletedLocalDataRtt && !(e.rtt_ms>0.0 && e.rtt_ms<1.0e9))
      throw std::runtime_error("P12S_INVALID_LOCAL_COMPLETED_RTT");
    m_last_time=e.time_ns;m_last_order=e.ordinal;m_started=true;
    // Only locally completed RTT may update the running value.
    if (e.kind==Kind::CompletedLocalDataRtt) {
      m_rtt_ewma=m_rtt_count ? (RTT_EWMA_ALPHA*e.rtt_ms+(1.0-RTT_EWMA_ALPHA)*m_rtt_ewma) : e.rtt_ms;
      ++m_rtt_count;
    } else {
      m_events.push_back(e);
    }
  }
  B1Snapshot capture(const BeforeDecisionLocalState& d) {
    if (d.node_id!=1)throw std::runtime_error("P12S_SNAPSHOT_NOT_LOCAL_NODE_1");
    if (!d.selected_face_id || !d.selected_queue_capacity_packets ||
        d.selected_queue_packets>d.selected_queue_capacity_packets)
      throw std::runtime_error("P12S_INVALID_SELECTED_LOCAL_FACE_QUEUE");
    if (m_started && !earlier(m_last_time,m_last_order,d.time_ns,d.ordinal))
      throw std::runtime_error("P12S_SNAPSHOT_BEFORE_OBSERVED_EVENT");
    if (m_decisions && !earlier(m_decision_time,m_decision_order,d.time_ns,d.ordinal))
      throw std::runtime_error("P12S_NONMONOTONE_DECISION");
    // Bound memory by pruning observations outside the strictly open lookback.
    while(!m_events.empty() &&
         (d.time_ns>=LOOKBACK_NS && m_events.front().time_ns<=d.time_ns-LOOKBACK_NS))
      m_events.pop_front();
    std::array<double,12> v{};
    v[0]=static_cast<double>(d.route_cost);
    v[1]=static_cast<double>(d.selected_queue_packets);
    v[2]=static_cast<double>(d.selected_queue_packets)/static_cast<double>(d.selected_queue_capacity_packets);
    v[3]=d.selected_link_up ? 1.0 : 0.0;
    v[4]=static_cast<double>(d.local_pit_occupancy);
    bool same_tick=false;
    for (const LocalEvent& e: m_events) {
      if (!earlier(e.time_ns,e.ordinal,d.time_ns,d.ordinal))
        throw std::runtime_error("P12S_FUTURE_EVENT_IN_OBSERVER");
      if (d.time_ns>=LOOKBACK_NS && e.time_ns<=d.time_ns-LOOKBACK_NS)continue;
      if (e.time_ns==d.time_ns)same_tick=true;
      switch(e.kind){
        case Kind::InterestRx: ++v[5];break;
        case Kind::DataRx: ++v[6];break;
        case Kind::NackRx: ++v[7];break;
        case Kind::SelectedFaceTx: if(e.face_id==d.selected_face_id)++v[8];break;
        case Kind::SelectedFaceDrop: if(e.face_id==d.selected_face_id)++v[9];break;
        case Kind::CompletedLocalDataRtt: throw std::runtime_error("P12S_RTT_NOT_A_WINDOW_COUNT");
      }
    }
    v[10]=m_rtt_ewma;
    v[11]=m_rtt_count ? 0.0 : 1.0;
    m_decisions++;m_decision_time=d.time_ns;m_decision_order=d.ordinal;
    return B1Snapshot{v,d.time_ns,d.ordinal,d.selected_face_id,d.node_id,same_tick};
  }
  std::uint64_t decisionCount() const {return m_decisions;}
  std::uint64_t localCompletedRttCount() const {return m_rtt_count;}
 private:
  std::deque<LocalEvent> m_events;
  std::uint64_t m_last_time=0,m_last_order=0,m_decision_time=0,m_decision_order=0;
  std::uint64_t m_decisions=0,m_rtt_count=0;
  double m_rtt_ewma=0.0;
  bool m_started=false;
};
} // namespace hcraf_p12s
