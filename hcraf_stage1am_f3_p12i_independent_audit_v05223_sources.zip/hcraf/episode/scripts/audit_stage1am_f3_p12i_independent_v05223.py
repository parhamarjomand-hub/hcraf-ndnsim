#!/usr/bin/env python3
"""P12-I independent read-only forensic audit of P12-H (no simulations/training)."""
import csv,hashlib,json,math,random,sys,zipfile
from collections import Counter
from pathlib import Path

EXPECTED_RUN=44787046706
EXPECTED_COMMIT='5ebf69dfe2adf9ced5b09b12fe6691ebe626b9a4'
SEEDS=(24601,24602,24603,24604)
SITES=('producer_egress','transit_middle','consumer_ingress')
SCIENCE={'Congestion':None,'FutureCongestion':None,'F3_ready':False,
'GO_FREEZE':False,'training_ready':False,'heldout_release_authorized':False}

def must(cond, msg):
 if not cond:raise RuntimeError('P12I_AUDIT_FAIL_'+msg)
def digest(x):return hashlib.sha256(x).hexdigest()
def file_sha(x):return digest(x.read_bytes())
def ap(rows,key):
 pairs=sorted(((float(r[key]),int(r['y'])) for r in rows),reverse=True)
 p=sum(y for _,y in pairs)
 if not p:return None
 num=den=0;v=0.;i=0
 while i<len(pairs):
  j=i;pp=0
  while j<len(pairs) and pairs[j][0]==pairs[i][0]:
   pp+=pairs[j][1];j+=1
  den+=j-i;num+=pp;v+=(num/den)*(pp/p);i=j
 return min(1.,v)
def calculate(rows):
 pos=sum(int(r['y']) for r in rows);must(0<pos<len(rows),'CLASS_BALANCE')
 for r in rows:
  for k in ('score_local','score_remote'):must(math.isfinite(float(r[k])),'FINITE_SCORES')
 loc=ap(rows,'score_local');rem=ap(rows,'score_remote');imp=[];folds=[]
 for seed in SEEDS:
  group=[r for r in rows if int(r['seed'])==seed]
  a=ap(group,'score_local');b=ap(group,'score_remote')
  folds.append({'seed':seed,'rows':len(group),'positive':sum(int(r['y']) for r in group),'AP_local':a,'AP_remote':b})
  if a is not None and b is not None and b>a:imp.append(seed)
 rng=random.Random(522522);groups={s:[r for r in rows if int(r['seed'])==s] for s in SEEDS};draws=[]
 for i in range(1000):
  sample=[r for s in (rng.choice(SEEDS) for _ in SEEDS) for r in groups[s]]
  a=ap(sample,'score_remote');b=ap(sample,'score_local')
  if a is not None and b is not None:draws.append(a-b)
 ci=([sorted(draws)[int(.025*len(draws))],sorted(draws)[min(len(draws)-1,int(.975*len(draws)))]] if len(draws)>=950 else None)
 return {'validation_telemetry_on_rows':len(rows),'positive':pos,'negative':len(rows)-pos,'prevalence_reference':pos/len(rows),'AP_local':loc,'AP_remote':rem,'delta_AP_remote_minus_local':rem-loc,'validation_seed_block_bootstrap_95pct_delta_AP':ci,'improving_validation_seeds':imp,'folds':folds,'predictability_gate':{'at_least_3_of_4_seeds_remote_strictly_better':len(imp)>=3,'remote_AP_above_validation_positive_prevalence':rem>pos/len(rows),'remote_AP_strictly_above_local_AP':rem>loc,'seed_block_bootstrap_delta_lower_strictly_positive':ci is not None and ci[0]>0}}
def same(a,b,where):
 if isinstance(a,float) or isinstance(b,float):must(a is not None and b is not None and abs(a-b)<1e-11,where)
 else:must(a==b,where)
def compare(actual,claimed,where='metrics'):
 if isinstance(actual,dict):
  must(isinstance(claimed,dict),where)
  for k,v in actual.items():must(k in claimed,where+'.missing_'+k);compare(v,claimed[k],where+'.'+k)
 elif isinstance(actual,list):
  must(isinstance(claimed,list) and len(actual)==len(claimed),where+'.len')
  for i,(a,b) in enumerate(zip(actual,claimed)):compare(a,b,where+'.'+str(i))
 else:same(actual,claimed,where)
def main(source,out):
 source=Path(source);out=Path(out);out.mkdir(parents=True,exist_ok=True)
 evidence=source/'P12H_VALIDATION_EVIDENCE_AND_PR_AUC_REPORT.json'
 must(evidence.is_file(),'MISSING_REPORT')
 report=json.loads(evidence.read_text())
 must(report.get('validation_runs')==48 and report.get('heldout_runs')==0,'VALIDATION_ONLY')
 must(report.get('physical_cases')==48 and report.get('episodes')==6144,'EXPECTED_48_CASES')
 must(report.get('validation_model_refits_or_tuning')==0,'NO_VALIDATION_REFIT')
 must(report.get('frozen_model_training_rows')==4608,'DEV_ONLY_TRAINING_ROWS')
 must(report.get('development_train_seed_blocks')==[24501,24502,24503,24504,24505,24506],'DEV_SEEDS')
 for key,value in SCIENCE.items():must(report.get(key,'__missing__')==value,'SCIENCE_LOCK_'+key)
 checksums={}
 manifest=source/'P12H_OUTPUT_SHA256SUMS.txt';must(manifest.is_file(),'OUTPUT_MANIFEST_MISSING')
 for line in manifest.read_text().splitlines():
  h,name=line.split('  ',1);must(name not in checksums and len(h)==64 and Path(name).name==name,'BAD_SHA_MANIFEST');checksums[name]=h
 must(set(checksums)=={x.name for x in source.iterdir() if x.is_file() and x.name!=manifest.name},'SHA_MANIFEST_FILES_MATCH')
 for name,h in checksums.items():must(file_sha(source/name)==h,'SHA_'+name)
 archives=report['validation_seed_archives']
 must(len(archives)==4,'FOUR_SEED_ARCHIVES')
 raw_audit=[]
 for a in archives:
  seed=int(a['seed']);must(seed in SEEDS,'SEED_IDENTITIES')
  filename=a['raw_archive_name'];p=source/filename
  must(p.is_file() and file_sha(p)==a['sha256'],'RAW_ZIP_SHA_'+str(seed))
  with zipfile.ZipFile(p) as z:
   must(z.testzip() is None,'RAW_ZIP_CRC_'+str(seed))
   m=json.loads(z.read('P12H_VALIDATION_RAW_FILE_SHA256.json'))
   must(len(m)==481 and a['raw_file_count']==481,'RAW_481_'+str(seed))
   must(set(z.namelist())==set(m)|{'P12H_VALIDATION_RAW_FILE_SHA256.json'},'RAW_ZIP_NAMES_'+str(seed))
   for name,h in m.items():
    must(name.startswith('') and not name.startswith('/') and '..' not in Path(name).parts,'UNSAFE_RAW_PATH')
    must(digest(z.read(name))==h,'RAW_MEMBER_'+str(seed)+'_'+name)
  raw_audit.append({'seed':seed,'raw_file_count':len(m),'archive_sha256':a['sha256']})
 must({r['seed'] for r in raw_audit}==set(SEEDS),'EXACT_SEED_SPLIT')
 pred=source/'P12H_VALIDATION_ONCE_ONLY_FROZEN_MODEL_PREDICTIONS.csv'
 with pred.open(newline='') as f:rows=list(csv.DictReader(f))
 must(len(rows)==3072,'EXACT_3072_PREDICTIONS')
 must(len({r['row_key'] for r in rows})==3072,'UNIQUE_PREDICTION_KEYS')
 must(Counter(int(r['seed']) for r in rows)=={s:768 for s in SEEDS},'SPLIT_COUNTS')
 must(all(r['telemetry']=='on_20ms' for r in rows),'NO_OFF_PREDICTIONS')
 must(all(r['site'] in SITES and r['load'] in ('low_control','high_pressure') and int(r['y']) in (0,1) for r in rows),'ROWS_DOMAIN')
 features={};labels={}
 for filename,table,idkey in (('P12H_VALIDATION_FEATURES_ONLY_v05222.jsonl',features,'metadata_NOT_A_PREDICTOR'),('P12H_VALIDATION_DIAGNOSTIC_FUTURE_ONLY_v05222.jsonl',labels,'row_key')):
  with (source/filename).open() as f:
   for line in f:
    v=json.loads(line)
    key=v[idkey]['row_key'] if idkey!='row_key' else v['row_key']
    must(key not in table,'DUPLICATE_TABLE_ROW');table[key]=v
 must(len(features)==len(labels)==6144 and set(features)==set(labels),'FEATURE_LABEL_KEYS')
 must(all(r['row_key'] in features and int(labels[r['row_key']]['retrospective_future_selected_path_QUEUE_DROP_75ms'])==int(r['y']) for r in rows),'PREDICTIONS_LABEL_JOIN')
 must(all('retrospective_future_selected_path_QUEUE_DROP_75ms' not in features[k]['allowed_decision_time_features'] for k in features),'NO_LABEL_IN_FEATURES')
 receipt=source/'P12H_FROZEN_MODEL_SHA256_BEFORE_VALIDATION.txt'
 frozen=source/'P12H_FROZEN_FULL_DEV_MODELS_BEFORE_VALIDATION.json'
 must(receipt.is_file() and frozen.is_file(),'FROZEN_MODELS_MISSING')
 frozen_bytes=frozen.read_bytes()
 must(digest(frozen_bytes) in receipt.read_text(),'FROZEN_MODEL_HASH_RECEIPT')
 must(report['frozen_model_sha256_before_validation']==digest(frozen_bytes),'REPORT_FROZEN_SHA')
 metrics=calculate(rows);compare(metrics,report['metrics'])
 physical=report['physical_results'];must(len(physical)==48,'PHYSICAL_ROWS')
 viable={};qc=[]
 for site in SITES:
  good_seeds=[]
  for seed in SEEDS:
   pair={r['telemetry']:r for r in physical if r['site']==site and int(r['seed'])==seed and r['load']=='high_pressure'}
   must(set(pair)=={'off','on_20ms'},'PHYSICAL_MATCHED_CASES')
   def okay(r):
    d=r['within_100ms'];return r['physical']['physical_drops_by_role'][r['target_role']]>0 and 0<d['positive_75ms']<128 and d['negative_75ms']>0
   if okay(pair['off']) and okay(pair['on_20ms']) and pair['on_20ms']['within_100ms']['matched_pos_neg_pairs_same_100ms']>0:good_seeds.append(seed)
  viable[site]=good_seeds
  if len(good_seeds)<2:qc.append({'site':site,'reason':'FEWER_THAN_2_OF_4_VALIDATION_SEEDS_PHYSICAL_MATCHED_CLASSES','viable_seed_blocks':good_seeds})
 compare(viable,report['physical_viable_seed_blocks_by_site'],'PHYSICAL_VIABLE')
 compare(qc,report['physical_QC_failures'],'PHYSICAL_QC')
 scientific_pass=not qc and all(metrics['predictability_gate'].values())
 status='PASS_P12H_VALIDATION_SIGNAL_REQUIRES_HELDOUT_CONFIRMATION' if scientific_pass else 'NO_GO_P12H_VALIDATION_EVIDENCE_OR_PREDICTABILITY'
 must(report['status']==status,'P12H_STATUS_REPRODUCIBLE')
 decision={'stage':'P12I_v0.52.23_INDEPENDENT_READ_ONLY_AUDIT','parent_run':EXPECTED_RUN,'parent_commit':EXPECTED_COMMIT,'evidence_verified':True,'raw_archive_sha_crc_members_verified':True,'physical_QC_failures':qc,'recomputed_metrics':metrics,'p12h_status_recomputed':status,'may_release_heldout':False,'requires_new_development_only_protocol_if_NO_GO':not scientific_pass,'no_simulations':True,'no_training':True,'no_validation_reoptimization':True,**SCIENCE}
 (out/'P12I_INDEPENDENT_AUDIT_DECISION.json').write_text(json.dumps(decision,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
 (out/'P12I_INDEPENDENT_RAW_ARCHIVE_AUDIT.json').write_text(json.dumps(raw_audit,indent=2)+'\n')
 print('P12I_FINAL',json.dumps({'status':status,'delta_AP':metrics['delta_AP_remote_minus_local'],'bootstrap_CI':metrics['validation_seed_block_bootstrap_95pct_delta_AP'],'gates':metrics['predictability_gate'],'raw_archives':4},sort_keys=True))
if __name__=='__main__':
 must(len(sys.argv)==3,'USAGE_source_dir_output_dir')
 main(sys.argv[1],sys.argv[2])
