import hashlib,importlib.util,json,pathlib,tempfile,unittest
from unittest.mock import patch
P=pathlib.Path(__file__).resolve().parents[1]/'scripts'/'audit_stage1am_f3_p12q_all_seed_direction_v05236.py'
modspec=importlib.util.spec_from_file_location('p12q',P);m=importlib.util.module_from_spec(modspec);modspec.loader.exec_module(m)
class Contract(unittest.TestCase):
 def test_grid(self):self.assertEqual(len(m.SITES)*len(m.LOADS)*len(m.ARMS),12)
 def test_banned_functions(self):
  t=P.read_text()
  for x in ('average_precision_score','bootstrap_ci(','fit_predict(','train_test_split('): self.assertNotIn(x,t)
 def test_fail_closed(self):
  with self.assertRaisesRegex(ValueError,'P12Q_FAIL_CLOSED'):m.demand(False,'BAD')
 def test_lock_sha(self):
  p=pathlib.Path(__file__).resolve().parents[1]/'docs'/'1AM'/'F3_P12Q_DIRECTIONAL_PROVENANCE_v0.52.36'/'P12Q_LOCKED_RAW_ORIGINS.json'
  self.assertEqual(hashlib.sha256(p.read_bytes()).hexdigest(),m.LOCK_SHA)
  d=m.lock_data(p);self.assertEqual(len(d['original_36_archives']),36)
 def test_no_tampered_lock(self):
  with tempfile.TemporaryDirectory() as t:
   p=pathlib.Path(t)/'bad.json';p.write_text('{}')
   with self.assertRaises(ValueError):m.lock_data(p)
 def test_source_explicit_guards(self):
  t=P.read_text()
  for x in ('remote_node_queue_accessed','future_pressure_label','sample_ns','receipt_ns','selected_sender_sources','device_index','model_fits','GO_FREEZE','construct_comparator_fairness_proven'):
   self.assertIn(x,t)
 def test_refuse_wrong_local_grid(self):
  with self.assertRaises(ValueError):m.local_selected_index([],[])
 def test_refuse_missing_batch_archive(self):
  with tempfile.TemporaryDirectory() as t:
   lock=pathlib.Path(__file__).resolve().parents[1]/'docs'/'1AM'/'F3_P12Q_DIRECTIONAL_PROVENANCE_v0.52.36'/'P12Q_LOCKED_RAW_ORIGINS.json'
   class A:pass
   a=A();a.batch=1;a.lock=lock;a.input=t;a.output=str(pathlib.Path(t)/'out.json')
   with self.assertRaises(ValueError):m.batch_mode(a)
 def test_no_go_in_aggregate(self):
  t=P.read_text();self.assertIn("'F3_ready':False",t);self.assertIn("'heldout_reads':0",t)
if __name__=='__main__':unittest.main()
