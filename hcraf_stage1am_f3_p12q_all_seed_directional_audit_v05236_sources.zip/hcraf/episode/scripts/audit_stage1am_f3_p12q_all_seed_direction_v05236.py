#!/usr/bin/env python3
"""Independent P12Q read-only directional-provenance audit; NEVER score, fit, or release heldout.

Checks source/causal devices across all original physical seed archives.  Full-cohort
architecture evidence is NOT a proof that the comparator is fair or F3 is GO.
"""
import argparse, collections, hashlib, io, json, pathlib, zipfile

LOCK_SHA='7b8f62920ac72f36b465456fdb701ca9dd82a83aa676303c651d4c68b333e488'
SITES=('producer_egress','transit_middle','consumer_ingress')
LOADS=('low_control','high_pressure')
ARMS=('off','on_20ms')


def demand(ok, msg):
    if not ok:raise ValueError('P12Q_FAIL_CLOSED_'+msg)

def sha(b):return hashlib.sha256(b).hexdigest()

def jlines(z,name):return [json.loads(s) for s in z.read(name).splitlines() if s.strip()]

def lock_data(path):
    raw=pathlib.Path(path).read_bytes()
    demand(sha(raw)==LOCK_SHA,'ORIGIN_PLAN_SHA')
    obj=json.loads(raw)
    rows=obj['original_36_archives']
    demand([x['seed'] for x in rows]==list(range(24801,24837)),'SEED_GRID')
    demand(len(set(x['zip_sha256'] for x in rows))==36,'ORIGIN_SHA_GRID')
    demand(all(x['batch']==(x['seed']-24801)//6+1 for x in rows),'BATCH_TO_SEED')
    return obj

def local_selected_index(decisions, snaps):
    demand(len(decisions)==128 and len(snaps)==384,'DECISION_SNAP_COUNTS')
    smap={(x['decision_id'],x['candidate_face_id']):x for x in snaps}
    demand(len(smap)==384,'UNIQUE_LOCAL_SNAP_KEYS')
    n_nonzero=0
    for i,d in enumerate(decisions,1):
        demand(d['decision_id']==i and d['node_id']==1,'DECISION_ID_AND_ORIGIN')
        cand=d['candidates'];demand(len(cand)==3,'CANDIDATE_COUNT')
        selected=min(cand,key=lambda c:c['routing_cost'])
        demand(selected['routing_cost']==1,'FIB_SELECTED_COST')
        x=smap[(i,selected['face_id'])]
        demand(x['node_id']==1 and x['observed_before_forwarding'] is True,'LOCAL_BEFORE_FORWARD')
        demand(x['remote_node_queue_accessed'] is False and x['future_pressure_label'] is None,'LOCAL_NO_REMOTE_FUTURE')
        demand(x['sim_time_ns']==d['time_ns'] and x['link_up'] is True,'LOCAL_DECISION_CLOCK')
        demand(x['device_index'] in (1,2,3) and x['capacity_packets']==12,'LOCAL_FORWARD_DEVICE')
        n_nonzero+=int(x['queue_packets']>0)
    return n_nonzero

def inspect_case(z,p,site,load,arm,seed):
    qc=json.loads(z.read(p+'P12L'+str((seed-24801)//6+1)+'_PHYSICAL_QC_ONLY.json'))
    demand(qc['seed']==seed and qc['site']==site,'CASE_SITE_SEED')
    demand(qc['load']==load and qc['telemetry']==arm,'CASE_LOAD_ARM')
    sr=qc['physical']['selected_role_sender_node_ids']
    demand(set(sr)=={'relay','mid','producer'},'REMOTE_ROLES')
    demand(len(set(sr.values()))==3 and all(k!=1 for k in sr.values()),'REMOTE_NODES_DISTINCT_FROM_1')
    demand(qc['physical']['selected_device_index']==0,'REVERSE_DEVICE_ZERO')
    decisions=jlines(z,p+'events.jsonl.decisions.jsonl')
    local=jlines(z,p+'nfd_local_queue_at_decision.jsonl')
    nonzero=local_selected_index(decisions,local)
    receipts_used=0
    delay_positive=0
    missing=0
    if arm=='on_20ms':
        telem=jlines(z,p+'queue_telemetry_decisions.jsonl')
        rec=jlines(z,p+'queue_telemetry_receipts.jsonl')
        recmap={x['report_id']:x for x in rec}
        demand(len(recmap)==len(rec),'TELEM_RECEIPT_DUPLICATE')
        demand(len(telem)==128,'TELEM_DECISION_LENGTH')
        for i,t in enumerate(telem,1):
            demand(t['decision_id']==i and t['decision_ns']==decisions[i-1]['time_ns'],'TELEM_DECISION_TIME')
            sources={(x['node_id'],x['device_index']) for x in t['selected_sender_sources']}
            demand(sources=={(x,0) for x in sr.values()},'SELECTED_PATH_REMOTE_ORIGIN')
            for e in t['feature_evidence']:
                rr=recmap.get(e['report_id'])
                demand(rr is not None,'TELEM_EVIDENCE_RECEIPT_MISSING')
                demand((rr['source_node_id'],rr['source_device_index']) in sources,'TELEM_RECEIPT_WRONG_SOURCE')
                demand((rr['source_node_id'],rr['source_device_index'])==(e['source_node_id'],e['source_device_index']),'TELEM_EVIDENCE_WRONG_SOURCE')
                demand(0<=rr['sample_ns']<=rr['receipt_ns']<=t['decision_ns'],'CAUSAL_SAMPLE_RECEIPT_DECISION')
                receipts_used+=1
                delay_positive+=int(rr['receipt_ns']>rr['sample_ns'])
            missing+=len(t['feature_missing_sources'])
        demand(receipts_used+missing==384,'TELEM_REQUIRED_SOURCE_COVERAGE')
    drops=qc['physical']['physical_drops_by_role']
    demand(set(drops)=={'relay','mid','producer'},'DROPS_BY_ROLE')
    dropcount=sum(drops.values())
    demand(dropcount==qc['physical']['all_devices_physical_queue_drops'],'PHYSICAL_DROP_SUM')
    return {'cases':1,'decisions':len(decisions),'active_decisions':len(decisions) if arm=='on_20ms' else 0,
      'local_nonzero_all':nonzero,'local_nonzero_active':nonzero if arm=='on_20ms' else 0,
      'causal_evidence_receipts':receipts_used,'evidence_positive_latency':delay_positive,'telemetry_missing_reports':missing,
      'physical_reverse_queue_drops_qc':dropcount,'role_device_distinct_pairs':3,
      'source_node_sets':dict(sr)}

def batch_mode(args):
    lock=lock_data(args.lock)
    b=args.batch;demand(b in range(1,7),'BATCH_NUMBER')
    entries=[x for x in lock['original_36_archives'] if x['batch']==b]
    top=pathlib.Path(args.input)
    seeds=[];totals=collections.Counter();case_counts=collections.Counter();per_seed=[]
    for info in entries:
        seed=info['seed']
        archives=list(top.rglob(f'P12L{b}_RAW_SEED_{seed}.zip'))
        receipts=list(top.rglob(f'P12L{b}_SEED_{seed}_RECEIPT.json'))
        demand(len(archives)==len(receipts)==1,'ARCHIVE_AND_RECEIPT_COUNT_'+str(seed))
        raw=archives[0].read_bytes()
        demand(sha(raw)==info['zip_sha256'],'RAW_ARCHIVE_SHA_'+str(seed))
        rc=json.loads(receipts[0].read_bytes())
        demand(rc['seed']==seed and rc['cases']==12 and rc['expected_episodes']==1536,'RECEIPT_GRID_'+str(seed))
        demand(rc['raw_archive_sha256']==info['zip_sha256'],'RECEIPT_SHA_'+str(seed))
        demand(rc['model_fits']==0 and rc['interim_AP_computed'] is False,'RECEIPT_NO_AP_'+str(seed))
        local_nonzero_active=0
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            demand(z.testzip() is None and len(z.namelist())==482,'ZIP_CRC_FILES_'+str(seed))
            for site in SITES:
                for load in LOADS:
                    for arm in ARMS:
                        p=f'{site}/{load}/{arm}/'
                        record=inspect_case(z,p,site,load,arm,seed)
                        totals.update({k:v for k,v in record.items() if isinstance(v,int)})
                        local_nonzero_active+=record['local_nonzero_active']
                        case_counts[(site,load,arm)]+=1
        per_seed.append({'seed':seed,'raw_archive_sha256':info['zip_sha256'],
            'local_selected_nonzero_active':local_nonzero_active})
        seeds.append(seed)
        print('PASS_P12Q_RAW_DIRECTIONAL_CAUSAL_PROVENANCE_SEED',seed,flush=True)
    demand(len(seeds)==6 and totals['cases']==72 and totals['decisions']==9216,'BATCH_GRID')
    demand(totals['active_decisions']==4608,'BATCH_ACTIVE_DECISIONS')
    demand(sum(case_counts.values())==72 and len(case_counts)==12 and all(x==6 for x in case_counts.values()),'BATCH_CASE_BALANCE')
    status='PASS_P12Q_ALL_SIX_SEEDS_CAUSAL_SOURCE_NO_F3_GO'
    report={'stage':'P12Q_v0.52.36','status':status,'batch':b,'source_run_id':entries[0]['run_id'],
            'seeds':seeds,'counts':dict(totals),'seed_ledger':per_seed,
            'all_cases_balanced':True,'model_fits':0,'new_AP_computed':False,'heldout_reads':0,
            'construct_comparator_fairness_proven':False,'F3_ready':False,'GO_FREEZE':False,
            'training_ready':False,'heldout_release_authorized':False}
    pathlib.Path(args.output).write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
    print(status,flush=True)
    return report

def aggregate_mode(args):
    lock=lock_data(args.lock)
    base=pathlib.Path(args.input)
    rows=[];totals=collections.Counter()
    for b in range(1,7):
        hits=list(base.rglob(f'P12Q_BATCH_{b}_DIRECTIONAL_QC_v05236.json'))
        demand(len(hits)==1,'BATCH_REPORT_COUNT_'+str(b))
        r=json.loads(hits[0].read_bytes())
        demand(r['batch']==b and r['status']=='PASS_P12Q_ALL_SIX_SEEDS_CAUSAL_SOURCE_NO_F3_GO','BATCH_STATUS_'+str(b))
        demand(r['seeds']==list(range(24801+(b-1)*6,24807+(b-1)*6)),'BATCH_SEEDS_'+str(b))
        demand(r['model_fits']==0 and r['new_AP_computed'] is False,'BATCH_NO_FITTING_AP')
        demand(r['F3_ready'] is False and r['GO_FREEZE'] is False,'BATCH_NO_GO')
        demand([x['raw_archive_sha256'] for x in r['seed_ledger']]==[x['zip_sha256'] for x in lock['original_36_archives'] if x['batch']==b],'BATCH_LEDGER')
        rows.extend(r['seed_ledger'])
        totals.update(r['counts'])
    demand([x['seed'] for x in rows]==list(range(24801,24837)),'ALL_36_SEEDS')
    demand(totals['cases']==432 and totals['decisions']==55296 and totals['active_decisions']==27648,'FULL_CASE_GRID')
    demand(totals['local_nonzero_active']==16,'P12O_IMMUTABLE_LOCAL_QUEUE_NONZERO')
    constant=sum(x['local_selected_nonzero_active']==0 for x in rows)
    # Zero-occupancy is sufficient for local feature constancy in this frozen model;
    # expected 25 as seen in original P12O audit. A seed may have 1+ nonzero obs.
    demand(constant==25,'P12O_LOCAL_CONST_SEEDS')
    demand(totals['causal_evidence_receipts']+totals['telemetry_missing_reports']==82944,'ALL_TELEM_SOURCES_COVERED')
    o={'stage':'P12Q_v0.52.36_ALL_36_ORIGINAL_SEED_DIRECTIONAL_CAUSAL_AUDIT',
       'status':'PASS_P12Q_SOURCE_DIRECTIONAL_CAUSAL_PROVENANCE_ALL_36_SEEDS_FAIRNESS_UNRESOLVED',
       'seeds':list(range(24801,24837)), 'counts':dict(totals),
       'local_queue_zero_only_seed_count':constant,'P12O_local_constant_seed_count':25,
       'P12N_primary_AP_not_recomputed':True,'new_AP_computed':False,'new_bootstrap_computed':False,
       'model_fits':0,'heldout_reads':0,'new_simulations':0,
       'source_directional_observation_verified':True,
       'construct_comparator_fairness_proven':False,
       'scientific_decision':'REPLICATION_POSITIVE_DIRECTIONAL_SOURCE_AUDITED_FAIR_COMPARATOR_INDEPENDENT_VALIDATION_REQUIRED',
       'limits':'Observation origin, temporal causality, and topology do not demonstrate equivalence of information sets or fairness. P12N positive replication is unchanged; historical P12H NO_GO retained.',
       'Congestion':None,'FutureCongestion':None,'F3_ready':False,'GO_FREEZE':False,
       'training_ready':False,'heldout_release_authorized':False,
       'Stage1AO_or_NSGAIII_authorized':False}
    pathlib.Path(args.output).write_text(json.dumps(o,indent=2,ensure_ascii=False)+'\n')
    print(o['status'],flush=True)
    return o

def main():
    a=argparse.ArgumentParser()
    sub=a.add_subparsers(dest='mode',required=True)
    for kind in ('batch','aggregate'):
        p=sub.add_parser(kind);p.add_argument('--input',required=True);p.add_argument('--lock',required=True);p.add_argument('--output',required=True)
        if kind=='batch':p.add_argument('--batch',type=int,required=True)
    args=a.parse_args()
    if args.mode=='batch':batch_mode(args)
    else:aggregate_mode(args)
if __name__=='__main__':main()
