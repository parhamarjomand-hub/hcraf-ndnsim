#!/usr/bin/env python3
"""P12-D new seed/CSV/traffic/causality/physical STOP and raw SHA checks."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import run_stage1am_f3_p12_tailprobe_v05218 as p
from generate_stage1am_f3_p12_tail_probe_prereg_v05217 import (
    SEEDS,SITES,LOADS,FAMILY,allocation,matrix_rows,events,filename,
)


class PilotOnlyP12DTests(unittest.TestCase):
    def test_01_p12c_parent_immutable(self):
        p.check_locked()
        cases=p.plan()
        self.assertEqual(len(cases),24)
        self.assertEqual({r['seed'] for r in cases},{23501,23502})
        self.assertEqual(len({(r['seed'],r['site'],r['load'],r['telemetry']) for r in cases}),24)
        self.assertEqual({r['scientific_partition'] for r in cases},{'PILOT_EXCLUDED'})
        self.assertTrue(all(r['validation_or_heldout']=='false' for r in cases))
        self.assertEqual(p.preflight()['simulations_in_preflight'],0)
        self.assertEqual(p.preflight()['parent_p12c_run'],44722370722)

    def test_02_each_command_matches_sha_frozen_case(self):
        for row in p.plan():
            cmd=p.command(row,Path('/tmp/p12d-isolated-pilot'))
            seed_site=allocation()[row['seed'],row['site']]
            self.assertIn('--scheduleFamily='+FAMILY,cmd)
            self.assertIn(filename(row['seed'],row['site'],row['load']),cmd)
            for flag in ('--technicalQueueMaxPackets=12','--intervalNs=330000000',
                         '--targetOffsetNs=260000000','--competitorCount=116',
                         '--competitorIntervalNs=3600000','--telemetryPeriodMs=20'):
                self.assertIn(flag,cmd)
            self.assertIn('--prospectiveTrafficStreamSeed='+str(seed_site['traffic_stream_seed']),cmd)
            self.assertIn('--selectedSlot='+str(seed_site['selected_slot']),cmd)
            for forbidden in ('--run=23401','--run=23402','--run=23301'):
                self.assertNotIn(forbidden,cmd)

    def test_03_cpp_refuses_old_seeds_and_allows_exact_new_streams(self):
        source=Path(__file__).resolve().parents[1]/'src/hcraf-stage1am-f3-p12-tailprobe-v05218.cpp'
        content=source.read_text()
        for v in ('P12D_WRONG_PILOT_ONLY_SEED_SITE_STREAM_OR_ROUTE',
                  'P12D_SITE_SPECIFIC_PILOT_CSV_FILENAME_CHANGED',
                  'P12C_V05217_INDEPENDENT_TAIL_PROBE_PILOT_LOCKED_CSV',
                  'PILOT_EXCLUDED','P0_TAIL_PROBE','P1_TAIL_PROBE',
                  'allLines!=128u','requests!=116u'):
            self.assertIn(v,content)
        for (seed,site),a in allocation().items():
            marker='{{'+str(seed)+'u,"'+site+'"},{'+str(a['traffic_stream_seed'])+'u,'+\
                str(a['routing_stream_seed'])+'u,'+str(a['telemetry_stream_seed'])+'u,'+\
                str(a['selected_slot'])+'u}}'
            self.assertIn(marker,content)
        for seed in (23301,23308,23401,23402,24501,25501):
            self.assertNotIn('{{'+str(seed)+'u,',content)

    def test_04_real_target_competitor_send_byte_consistent(self):
        row=p.plan()[0]
        with tempfile.TemporaryDirectory() as td:
            dest=Path(td)
            for kind,name in (('TARGET','consumer_events.jsonl'),
                              ('INDEPENDENT_COMPETITOR','competitor_events.jsonl')):
                expected=[x for x in events(row['seed'],row['site'],row['load'])
                          if x['traffic_class']==kind]
                (dest/name).write_text(''.join(json.dumps({'event':'SEND',
                    'name':('/hcraf/pilot/' if kind=='TARGET' else '/hcraf/competitor/')+
                         str(e['sequence']),'time_ns':e['time_ns']})+'\n' for e in expected))
                (dest/(name+'.arrivals.jsonl')).write_text(''.join(json.dumps({
                    'sequence':e['sequence'],'time_ns':e['time_ns'],
                    'schedule':'F3_P12C_V05217_PILOT_EXCLUDED_LOCKED_CSV'})+'\n'
                    for e in expected))
            p.verify_sends(dest,row)
            target=dest/'consumer_events.jsonl'
            target.write_text(target.read_text().replace('"time_ns": ', '"time_ns": 1',1))
            with self.assertRaisesRegex(RuntimeError,'ACTUAL_NDNSIM_SEND'):
                p.verify_sends(dest,row)

    def test_05_real_queue_drop_vs_receiver_loss_in_future_75ms(self):
        with tempfile.TemporaryDirectory() as td:
            dest=Path(td)
            (dest/'pathwide_witness_b.jsonl').write_text(json.dumps({
                'event_type':'QUEUE_DROP','timestamp_ns':2_080_000_000,
                'node_id':2,'device_index':0})+'\n'+json.dumps({
                'event_type':'RX_DROP','timestamp_ns':2_050_000_000,
                'node_id':2,'device_index':0})+'\n')
            (dest/'events.jsonl.decisions.jsonl').write_text(''.join(json.dumps({
                'time_ns':2_000_000_000+i*1_000_000})+'\n' for i in range(128)))
            a=p.matched_time_pairs(dest,{'selected_relay_node_id':2,
                   'selected_mid_node_id':5,'selected_producer_node_id':8})
            self.assertEqual(a['positive_75ms'],75)
            self.assertEqual(a['negative_75ms'],53)
            self.assertGreater(a['matched_pos_neg_pairs_same_100ms'],0)

    def test_06_gate_only_after_two_seeds_and_site_matched_pair(self):
        allcases=[]
        for seed in SEEDS:
            for site in SITES:
                role={'producer_egress':'producer','transit_middle':'mid',
                      'consumer_ingress':'relay'}[site]
                for load in LOADS:
                    for telemetry in ('off','on_20ms'):
                        allcases.append({'seed':seed,'site':site,'load':load,
                           'telemetry':telemetry,'target_role':role,
                           'physical':{'physical_drops_by_role':{role:2}},
                           'within_100ms':{'positive_75ms':21,'negative_75ms':107,
                                          'matched_pos_neg_pairs_same_100ms':20}})
        self.assertEqual(p.science_gate_across_both_seeds(allcases),[])
        # A single seed may fail in the pilot without erasing the other seed.
        for row in allcases:
            if row['seed']==23501 and row['load']=='high_pressure':
                row['within_100ms']['positive_75ms']=0
        self.assertEqual(p.science_gate_across_both_seeds(allcases),[])
        for row in allcases:
            if row['site']=='transit_middle' and row['load']=='high_pressure':
                row['within_100ms']['matched_pos_neg_pairs_same_100ms']=0
        failures=p.science_gate_across_both_seeds(allcases)
        self.assertEqual(len(failures),1)
        self.assertEqual(failures[0]['site'],'transit_middle')
        with self.assertRaisesRegex(RuntimeError,'AGGREGATE_GATE'):
            p.science_gate_across_both_seeds(allcases[:12])

    def test_07_telemetry_off_explicit_and_no_future_leakage_in_source(self):
        with tempfile.TemporaryDirectory() as td:
            off=p.verify_telemetry_128(Path(td),{},False)
            self.assertEqual(off['real_received'],0)
        source=Path(__file__).resolve().parents[1]/'scripts/build_stage1am_f3_p12_tailprobe_tables_v05218.py'
        text=source.read_text()
        self.assertIn('rr["sample_ns"]<=rr["receipt_ns"]<=t',text)
        self.assertIn('allowed_decision_time_features',text)
        self.assertIn('DIAGNOSTIC_ONLY_not_official_F3',text)
        self.assertIn('t+75000000',text)

    def test_08_all_raw_files_sha_and_crc_before_temporary_cleanup(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);raw=root/'raw';raw.mkdir()
            for n in range(101):
                (raw/f'physical_{n}.jsonl').write_text('QUEUE_DROP '+str(n)+'\n')
            dest=root/'artifact';dest.mkdir()
            with patch.object(p,'DEST',dest):
                audit=p.archive_seed(23501,raw)
            self.assertFalse(raw.exists())
            blob=dest/audit['raw_archive_name']
            self.assertEqual(hashlib.sha256(blob.read_bytes()).hexdigest(),audit['sha256'])
            with zipfile.ZipFile(blob) as z:
                self.assertIsNone(z.testzip())
                sums=json.loads(z.read('P12D_PILOT_RAW_FILE_SHA256.json'))
                self.assertEqual(len(sums),101)
                self.assertTrue(all(hashlib.sha256(z.read(n)).hexdigest()==h
                                    for n,h in sums.items()))

    def test_09_no_deletion_when_archive_incomplete(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);raw=root/'raw';raw.mkdir()
            (raw/'important.jsonl').write_text('keep\n')
            target=root/'archive';target.mkdir()
            with patch.object(p,'DEST',target):
                with self.assertRaisesRegex(RuntimeError,'INCOMPLETE_RAW'):
                    p.archive_seed(23501,raw)
            self.assertTrue((raw/'important.jsonl').exists())

    def test_10_no_legacy_108_or_extra_training(self):
        for file in ('run_stage1am_f3_p12_tailprobe_v05218.py',
                     'build_stage1am_f3_p12_tailprobe_tables_v05218.py'):
            source=(Path(__file__).resolve().parents[1]/'scripts'/file).read_text()
            self.assertNotIn('scikit-learn',source)
            self.assertNotIn('average_precision_score',source)
            self.assertNotIn('len(decisions)==108',source)
        self.assertEqual(p.SCIENCE['F3_ready'],False)
        self.assertIsNone(p.SCIENCE['FutureCongestion'])
        self.assertEqual(p.preflight()['parent_p12c_run'],44722370722)


if __name__=='__main__':unittest.main()
