#!/usr/bin/env python3
"""P12-D: execute exactly 24 P12-C SHA-frozen, permanently excluded PILOT cases.

No Development/Validation/Heldout simulation, model, official F3 labels or AP.
Each 12-case seed is archived with full per-file CRC/SHA before aggregate GO/NO_GO.
"""
import argparse
from bisect import bisect_right
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

from generate_stage1am_f3_p12_tail_probe_prereg_v05217 import (
    PARTITION, SEEDS, SITES, LOADS, TELEMETRIES, FAMILY, SCHEMA,
    PLANS, MATRIX, COMMITMENTS, allocation, matrix_rows, events, filename,
    render_schedule, render_matrix, commitments,
)
from build_stage1am_f3_p12_tailprobe_tables_v05218 import process_one


ROOT=Path(__file__).resolve().parents[3]
DEST=ROOT/'episode_output/stage1am_f3_p12_tailprobe_v05218'
WORK=ROOT/'episode_output/v05218_temporary_raw_seed_work'
BIN='hcraf-stage1am-f3-p12-tailprobe-v05218'
SCIENCE={'Congestion':None,'FutureCongestion':None,'F3_ready':False,
         'GO_FREEZE':False,'training_ready':False,
         'heldout_release_authorized':False}
EXPECTED_PARENT=dict(parent_p12b_run=44692358819,
       parent_p12b_commit='07ae01f773b1273faddad96aa260bd0052994f6a',
       parent_p12b_artifact_id=14610069765,
       parent_p12b_artifact_sha256='b8626f15f2ba295fcaac5c22b953daf5a3d1fcf702102d0ac2413e931da19177')


def check(ok,why):
    if not ok:raise RuntimeError('P12D_'+why)


def sha256_file(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for part in iter(lambda:f.read(1<<20),b''):h.update(part)
    return h.hexdigest()


def load_jsonl(path):
    with Path(path).open() as f:
        return [json.loads(line) for line in f if line.strip()]


def physical_witness(dest,scenario,target_role):
    """Unchanged B.1 physical-drop invariants from the proven P12-B path audit."""
    role_keys={int(scenario['selected_'+role+'_node_id']):role
               for role in ('relay','mid','producer')}
    check(len(role_keys)==3,'DUPLICATE_SELECTED_PHYSICAL_NODES')
    path=dest/'pathwide_witness_b.jsonl'
    check(path.is_file(),'MISSING_INDEPENDENT_PHYSICAL_WITNESS_B')
    by_role=Counter();enqueues=Counter();maximum=Counter()
    cumulative={};total=events=0
    with path.open() as trace:
        for line in trace:
            x=json.loads(line);events+=1
            check(x['schema_version']=='PATHWIDE_WITNESS_B.1' and x['monitor_id']=='B',
                  'PHYSICAL_WITNESS_SCHEMA_UNTRUSTED')
            node,device=int(x['node_id']),int(x['device_index'])
            event=x['event_type'];new=int(x['drop_packets_cumulative'])
            before=cumulative.get((node,device),0)
            check(new>=before and new-before==int(event=='QUEUE_DROP'),
                  'RAW_PHYSICAL_DROP_CUMULATIVE_OR_KIND_DISAGREES')
            cumulative[node,device]=new
            if event=='QUEUE_DROP':total+=1
            if node in role_keys and device==0:
                role=role_keys[node]
                maximum[role]=max(maximum[role],int(x['queue_packets']))
                if event=='QUEUE_ENQUEUE':enqueues[role]+=1
                if event=='QUEUE_DROP':by_role[role]+=1
    check(events>0,'EMPTY_PHYSICAL_WITNESS')
    counts={r:by_role[r] for r in ('relay','mid','producer')}
    for node,role in role_keys.items():
        check(counts[role]==cumulative.get((node,0),0),
              'PHYSICAL_TARGET_ROLE_CUMULATIVE_DISAGREEMENT')
    n=counts[target_role];other=sum(counts.values())-n
    return {
        'physical_independent_source':'PATHWIDE_WITNESS_B.1',
        'selected_role_sender_node_ids':{r:node for node,r in role_keys.items()},
        'selected_device_index':0,'witness_events_read':events,
        'target_role':target_role,'physical_drops_by_role':counts,
        'enqueues_by_role':{r:enqueues[r] for r in counts},
        'max_queue_packets_by_role':{r:maximum[r] for r in counts},
        'all_devices_physical_queue_drops':total,
        'strict_exclusive_real_queue_drop':n>0 and other==0 and total==n,
        'nonqueue_receive_failures_excluded':True,
    }


def check_locked():
    check(SEEDS==(23501,23502) and PARTITION=='PILOT_EXCLUDED',
          'ONLY_TWO_NEW_PERMANENTLY_EXCLUDED_PILOT_SEEDS')
    check(MATRIX.read_bytes()==render_matrix(),'P12C_MATRIX_24_BYTE_PREIMAGE_CHANGED')
    record=json.loads(COMMITMENTS.read_text())
    check(record==commitments(),'P12C_SCHEDULE_COMMITMENTS_CHANGED')
    check(all(record[k]==v for k,v in EXPECTED_PARENT.items()),
          'P12C_PARENT_PROVENANCE_CHANGED')
    check(record['pilot_executor_authorized_now'] is False and
          record['new_simulations']==0 and
          record['executed_new_simulations']==0 and
          record['proposed_pilot_simulations']==24 and
          record['validation_runs']==record['heldout_runs']==0,
          'P12C_DESIGN_LOCK_UNSEALED')
    check(all(record[k] is v for k,v in SCIENCE.items()),
          'P12C_SCIENCE_FENCE_CHANGED')
    expected=set()
    for seed in SEEDS:
        for site in SITES:
            for load in LOADS:
                name=filename(seed,site,load)
                path=PLANS/name
                blob=render_schedule(seed,site,load)
                check(path.is_file() and path.read_bytes()==blob,
                      'P12C_PILOT_CSV_CHANGED:'+name)
                check(hashlib.sha256(blob).hexdigest()==record['schedule_hashes'][name],
                      'P12C_PILOT_CSV_SHA_CHANGED:'+name)
                expected.add(name)
            l={r['sequence']:r['time_ns'] for r in events(seed,site,'low_control')
               if r['traffic_class']=='TARGET'}
            h={r['sequence']:r['time_ns'] for r in events(seed,site,'high_pressure')
               if r['traffic_class']=='TARGET'}
            check(l==h and len(l)==12,'P12C_PAIRED_TARGET_SEND_CHANGED')
            for pulse in ('P0_TAIL_PROBE','P1_TAIL_PROBE'):
                lo={r['sequence']:r['time_ns'] for r in events(seed,site,'low_control')
                    if r['phase_label']==pulse}
                hi={r['sequence']:r['time_ns'] for r in events(seed,site,'high_pressure')
                    if r['phase_label']==pulse}
                check(lo==hi and len(lo)==10,'P12C_PAIRED_REAL_TAIL_PROBES_CHANGED')
    check({p.name for p in PLANS.glob('*.csv')}==expected and len(expected)==12,
          'P12C_UNAUTHORIZED_SCHEDULE_ADDED_OR_REMOVED')


def plan():
    current=matrix_rows()
    check(len(current)==24 and {r['seed'] for r in current}==set(SEEDS),
          'NOT_EXACTLY_24_PILOT_CASES')
    check(len({(r['seed'],r['site'],r['load'],r['telemetry'])
               for r in current})==24,'DUPLICATE_PILOT_CELL')
    check(all(r['scientific_partition']==PARTITION and
              r['validation_or_heldout']=='false' and
              r['candidate_queue_capacity_packets']==12 and
              r['target_requests']==12 and r['competitor_requests']==116 and
              r['tail_probe_requests_per_pulse']==10 for r in current),
          'FORMAL_F3_PARTITION_OR_P12C_LOCK_ESCAPED')
    return current


def command(row,dest):
    a=allocation()[(row['seed'],row['site'])]
    values=[f"--pathArm={row['arm']}",f"--interventionLocation={row['location']}",
            '--interventionReturnBps=12000000','--lossProbability=0',
            '--lossStream=79','--lossReceiverNodeId=-1',
            '--lossReceiverDeviceIndex=-1',
            f'--scheduleFamily={FAMILY}',
            f"--scheduleCsv={PLANS/row['schedule_filename']}",
            f"--prospectiveLoad={row['load']}",
            f"--prospectiveTrafficStreamSeed={a['traffic_stream_seed']}",
            f"--prospectiveRoutingStreamSeed={a['routing_stream_seed']}",
            f"--prospectiveTelemetryStreamSeed={a['telemetry_stream_seed']}",
            f"--selectedSlot={row['selected_slot']}",f"--run={row['seed']}",
            f'--output={dest}','--instrument=1','--topology=DEV_CHAIN_L',
            '--mode=LP_INDEPENDENT_COMPETITOR_NO_DROP','--seed=17',
            '--lifetimeMs=2600','--requestCount=12','--intervalNs=330000000',
            '--competitorCount=116','--competitorIntervalNs=3600000',
            '--competitorOffsetNs=0','--targetOffsetNs=260000000',
            '--forwardBps=50000000','--returnBps=50000000',
            '--technicalQueueMaxPackets=12',
            f"--telemetryEnabled={int(row['telemetry']=='on_20ms')}",
            '--telemetryPeriodMs=20']
    return BIN+' '+' '.join(values)


def verify_sends(dest,row):
    locked=events(row['seed'],row['site'],row['load'])
    for traffic,file in (('TARGET','consumer_events.jsonl'),
                         ('INDEPENDENT_COMPETITOR','competitor_events.jsonl')):
        expected={r['sequence']:r['time_ns'] for r in locked
                  if r['traffic_class']==traffic}
        sent={int(e['name'].rsplit('/',1)[-1]):e['time_ns']
              for e in load_jsonl(dest/file) if e['event']=='SEND'}
        arrivals=load_jsonl(dest/(file+'.arrivals.jsonl'))
        observed={int(e['sequence']):int(e['time_ns']) for e in arrivals}
        check(expected==sent==observed,
              'ACTUAL_NDNSIM_SEND_NOT_EQUAL_FROZEN_P12C_CSV')
        check({e['schedule'] for e in arrivals}==
              {'F3_P12C_V05217_PILOT_EXCLUDED_LOCKED_CSV'},
              'ACTUAL_SEND_HAS_WRONG_PILOT_PROVENANCE')


def check_decisions_128(dest,scenario):
    decisions=load_jsonl(dest/'events.jsonl.decisions.jsonl')
    seen=set()
    for d in decisions:
        check(d['node_id']==1 and
              d['name'].startswith(('/hcraf/pilot/','/hcraf/competitor/')),
              'FOREIGN_OR_TELEMETRY_INTEREST_IN_RESEARCH_EPISODES')
        selected=[c for c in d['candidates'] if c['routing_cost']==1]
        check(len(selected)==1 and selected[0]['face_id']==scenario['selected_face_id'],
              'SELECTED_FACE_VIOLATES_REAL_FIB_MAPPING')
        check(d['decision_id'] not in seen,'DUPLICATE_DECISION_ID')
        seen.add(d['decision_id'])
    check(len(decisions)==128 and len(seen)==128,
          'NOT_ALL_128_REAL_FORWARDING_EPISODES')
    return len(decisions)


def verify_telemetry_128(dest,scenario,enabled):
    if not enabled:
        check(not (dest/'queue_telemetry_receipts.jsonl').exists() and
              not (dest/'queue_telemetry_decisions.jsonl').exists(),
              'TELEMETRY_OFF_WAS_CONTAMINATED')
        return {'enabled':False,'real_received':0,'unavailable_features':0}
    sent=load_jsonl(dest/'queue_telemetry_sent.jsonl')
    requested=load_jsonl(dest/'queue_telemetry_requests.jsonl')
    receipts=load_jsonl(dest/'queue_telemetry_receipts.jsonl')
    decisions=load_jsonl(dest/'queue_telemetry_decisions.jsonl')
    roles={int(scenario['selected_'+r+'_node_id']) for r in ('relay','mid','producer')}
    check(len(requested)>=2600 and len(sent)>=2600 and len(receipts)>=2500,
          'REAL_NDN_TELEMETRY_TRANSPORT_INSUFFICIENT')
    check({r['source_node_id'] for r in receipts}==roles,
          'UNEXPECTED_TELEMETRY_REPORT_SOURCES')
    check(len(decisions)==128,'NOT_128_ONLINE_TELEMETRY_DECISIONS')
    index={(r['source_node_id'],r['report_id']):r for r in receipts}
    check(len(index)==len(receipts),'RECEIVED_DUPLICATE_TELEMETRY_REPORT')
    for r in receipts:
        check(0<=r['sample_ns']<=r['receipt_ns'],'SAMPLE_AFTER_RECEIPT')
    valid=missing=stale=0
    for d in decisions:
        got=set();missed=set()
        for ref in d['feature_evidence']:
            src=ref['source_node_id']
            check(src in roles and src not in got,'DUPLICATE_FEATURE_SOURCE')
            report=index.get((src,ref['report_id']))
            check(report is not None and
                  report['sample_ns']<=report['receipt_ns']<=d['decision_ns'] and
                  d['decision_ns']-report['sample_ns']<=100000000,
                  'FUTURE_LEAKAGE_OR_STALE_REMOTE_FEATURE')
            got.add(src);valid+=1
        for ref in d['feature_missing_sources']:
            src=ref['source_node_id']
            check(src in roles and src not in missed and
                  ref['reason'] in ('STALE_GT_100MS','UNRECEIVED'),
                  'DUPLICATE_OR_UNREASONED_MISSINGNESS')
            missed.add(src);missing+=1
            stale+=int(ref['reason']=='STALE_GT_100MS')
        check(not got&missed and got|missed==roles,
              'REPORT_SOURCE_DID_NOT_PARTITION_INTO_OBSERVED_OR_MISSING')
    check(valid+missing==128*3,'NOT_ALL_CAUSAL_SOURCE_FEATURES_ACCOUNTED_FOR')
    return dict(enabled=True,requested=len(requested),sent=len(sent),
                real_received=len(receipts),observed_features=valid,
                unavailable_features=missing,stale_features=stale,
                causal_feature_leakage=False)


def matched_time_pairs(dest,scenario):
    selected={int(scenario['selected_'+r+'_node_id'])
              for r in ('relay','mid','producer')}
    drops=sorted(int(e['timestamp_ns']) for e in load_jsonl(dest/'pathwide_witness_b.jsonl')
                 if e['event_type']=='QUEUE_DROP' and
                 e['node_id'] in selected and e['device_index']==0)
    bins=defaultdict(lambda:[0,0])
    positives=0
    for d in load_jsonl(dest/'events.jsonl.decisions.jsonl'):
        t=int(d['time_ns'])
        future=bisect_right(drops,t+75_000_000)-bisect_right(drops,t)
        lab=int(future>0)
        positives+=lab;bins[t//100_000_000][lab]+=1
    check(sum(sum(x) for x in bins.values())==128,
          'PILOT_MATCHED_DECISION_STREAM_INCOMPLETE')
    return {'matched_pos_neg_pairs_same_100ms':sum(a*b for a,b in bins.values()),
            'time_bins_with_both_classes':sum(a>0 and b>0 for a,b in bins.values()),
            'positive_75ms':positives,'negative_75ms':128-positives}


def simulate_one(row,seed_work,feature_writer,label_writer):
    dest=seed_work/row['site']/row['load']/row['telemetry']
    dest.mkdir(parents=True,exist_ok=False)
    a=allocation()[(row['seed'],row['site'])]
    cmd=command(row,dest)
    (dest/'command.txt').write_text(cmd+'\n')
    (dest/'P12D_LOCKED_CASE.json').write_text(json.dumps({**row,**SCIENCE},indent=2)+'\n')
    with (dest/'simulator.log').open('w') as log:
        subprocess.run(['/usr/bin/time','-f','wall_seconds=%e\nmax_rss_kib=%M',
                        '-o',str(dest/'resource_usage.txt'),
                        'python3','./waf','--run-no-build',cmd],
                       cwd=ROOT/'episode_sources/ns-3',
                       stdout=log,stderr=subprocess.STDOUT,check=True)
    scenario=json.loads((dest/'scenario.json').read_text())
    check(scenario['holdout_partition']==PARTITION and
          scenario['p12_pilot_excluded_from_formal_F3_partitions'] is True and
          scenario['p12_pilot_site']==row['site'] and
          scenario['independent_rng_block']==row['seed'] and
          scenario['selected_face_slot']==row['selected_slot'] and
          scenario['selected_face_id']==258+row['selected_slot'] and
          scenario['schedule_family']==FAMILY and
          scenario['schedule_contract']==
              'P12C_V05217_INDEPENDENT_TAIL_PROBE_PILOT_LOCKED_CSV' and
          scenario['schedule_csv_filename']==row['schedule_filename'] and
          scenario['p4_locked_traffic_stream_seed']==a['traffic_stream_seed'] and
          scenario['p4_locked_routing_stream_seed']==a['routing_stream_seed'] and
          scenario['p4_locked_telemetry_stream_seed']==a['telemetry_stream_seed'] and
          scenario['p4_prospective_load']==row['load'] and
          scenario['phase_arm']==row['arm'] and
          scenario['intervention_location']==row['location'] and
          scenario['technical_queue_max_packets']==12 and
          scenario['telemetry_enabled']==(row['telemetry']=='on_20ms') and
          scenario['official_F3_labels_constructed']==0 and
          all(scenario[k] is v for k,v in SCIENCE.items()),
          scenario['competitor_planned_requests']==116 and
          scenario['planned_requests']==12 and
          scenario['future_oracle_horizon_ns_pilot']==75000000 and
          'REAL_SIMULATION_BROKE_P12C_FROZEN_PILOT_OR_SCIENCE_FENCE')
    verify_sends(dest,row)
    physical=physical_witness(dest,scenario,row['target_role'])
    decision_count=check_decisions_128(dest,scenario)
    transport=verify_telemetry_128(dest,scenario,row['telemetry']=='on_20ms')
    audit={**row,'physical':physical,'decisions':decision_count,
           'telemetry_transport':transport,
           'off_target_real_queue_drops_retained':True,
           'nonqueue_receiver_losses_excluded':True,
           'official_F3_labels_constructed':0,'F3_PR_AUC_computed':False,
           **SCIENCE}
    (dest/'P12D_PILOT_PHYSICAL_AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n')
    diagnostic=process_one(row,dest,feature_writer,label_writer)
    matched=matched_time_pairs(dest,scenario)
    check(matched['positive_75ms']==diagnostic['positive_75ms'],
          'INDEPENDENT_MATCHED_AND_TABLE_LABELS_DISAGREE')
    return {**audit,'diagnostic':diagnostic,'within_100ms':matched}


def archive_seed(seed,seed_work):
    target=DEST/('P12D_PILOT_RAW_SEED_'+str(seed)+'.zip')
    check(not target.exists(),'REFUSE_OVERWRITE_RAW_SEED_ARCHIVE')
    files=sorted(p for p in seed_work.rglob('*') if p.is_file())
    check(len(files)>100,'INCOMPLETE_RAW_PHYSICAL_EVIDENCE')
    digests={str(p.relative_to(seed_work)):sha256_file(p) for p in files}
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files:z.write(p,str(p.relative_to(seed_work)))
        z.writestr('P12D_PILOT_RAW_FILE_SHA256.json',
                   json.dumps(digests,sort_keys=True,indent=2)+'\n')
    with zipfile.ZipFile(target) as z:
        check(z.testzip() is None and
              set(z.namelist())==set(digests)|{'P12D_PILOT_RAW_FILE_SHA256.json'},
              'ARCHIVE_CRC_OR_MANIFEST_MISMATCH')
        for name,digest in digests.items():
            check(hashlib.sha256(z.read(name)).hexdigest()==digest,
                  'RAW_ARCHIVED_FILE_SHA_MISMATCH:'+name)
    sha=sha256_file(target)
    size=target.stat().st_size
    shutil.rmtree(seed_work)
    return {'seed':seed,'raw_archive_name':target.name,'sha256':sha,
            'raw_archive_bytes':size,'raw_file_count':len(digests),
            'transient_removed_only_after_full_recoverable_crc_sha':True}


def science_gate_across_both_seeds(all_rows):
    """Immutable P12-C rule: evaluate paired same-seed high cases after both seeds."""
    check(len(all_rows)==24 and
          {x['seed'] for x in all_rows}==set(SEEDS),
          'AGGREGATE_GATE_CANNOT_RUN_BEFORE_ALL_24_CASES')
    failures=[]
    for site in SITES:
        viable=[]
        for seed in SEEDS:
            paired={r['telemetry']:r for r in all_rows
                    if r['seed']==seed and r['site']==site and r['load']=='high_pressure'}
            check(set(paired)==set(TELEMETRIES),'MISSING_HIGH_TELEMETRY_PAIR')
            def mixed_real(case):
                d=case['within_100ms']
                return (case['physical']['physical_drops_by_role'][case['target_role']]>0
                        and 0<d['positive_75ms']<128 and d['negative_75ms']>0)
            if (mixed_real(paired['off']) and mixed_real(paired['on_20ms']) and
                paired['on_20ms']['within_100ms']['matched_pos_neg_pairs_same_100ms']>0):
                viable.append(seed)
        if not viable:
            failures.append({'site':site,
                 'reason':'NO_PAIRED_SEED_WITH_REAL_QUEUE_DROPS_TWO_CLASSES_AND_TIME_BIN_PAIRS'})
    return failures


def preflight():
    check_locked()
    return {'stage':'v0.52.18_P12_D_FROZEN_TAIL_PROBE_24_CASE_EXECUTOR_PREFLIGHT',
            'parent_p12c_run':44722370722,'pilot_seed_blocks':list(SEEDS),
            'planned_pilot_conditions':24,'simulations_in_preflight':0,
            'official_F3_label_count':0,'training_executed':False,**SCIENCE}


def run():
    check_locked();cases=plan()
    check((ROOT/'episode_sources/ns-3/build/scratch'/BIN).is_file(),
          'P12D_CPP_BINARY_NOT_BUILT')
    check(not DEST.exists() and not WORK.exists(),
          'REFUSE_OVERWRITE_PREVIOUS_P12D_SIMULATION')
    DEST.mkdir(parents=True,exist_ok=False)
    WORK.mkdir(parents=True,exist_ok=False)
    audited=[];archives=[];failed=[]
    features=DEST/'P12D_PILOT_FEATURES_ONLY_v05218.jsonl'
    labels=DEST/'P12D_PILOT_DIAGNOSTIC_FUTURE_ONLY_v05218.jsonl'
    with features.open('w') as f,labels.open('w') as l:
        for seed in SEEDS:
            work=WORK/str(seed)
            work.mkdir(parents=True,exist_ok=False)
            batch=[]
            for row in cases:
                if row['seed']!=seed:continue
                res=simulate_one(row,work,f,l)
                audited.append(res);batch.append(res)
                print('P12D_PILOT_PHYSICAL',len(audited),'/24',seed,row['site'],
                      row['load'],row['telemetry'],
                      'queue_drops',res['physical']['physical_drops_by_role'],
                      'matched_pairs',res['within_100ms']['matched_pos_neg_pairs_same_100ms'],
                      flush=True)
            f.flush();l.flush()
            check(len(batch)==12,'ONE_SEED_NOT_EXACTLY_12_CASES')
            (work/'P12D_PILOT_SEED_AUDIT.json').write_text(json.dumps(batch,indent=2)+'\n')
            archives.append(archive_seed(seed,work))
            (DEST/'P12D_ARCHIVED_SEED_INDEX.json').write_text(json.dumps(archives,indent=2)+'\n')
    complete=len(audited)==24 and len(archives)==2
    failed=science_gate_across_both_seeds(audited) if complete else [
        {'reason':'INCOMPLETE_LOCKED_24_CASES'}]
    status=('PASS_P12D_PILOT_PHYSICAL_TIME_BIN_FEASIBILITY_ONLY'
            if complete and not failed else
            'NO_GO_P12D_PILOT_PHYSICAL_OR_TIME_BIN_FEASIBILITY')
    report={'status':status,'scientific_scope':'PILOT_EXCLUDED_NEVER_OFFICIAL_F3',
            'planned_simulations':24,'completed_simulations':len(audited),
            'pilot_seed_blocks_completed':len(archives),
            'selected_face_forwarding_episodes':128*len(audited),
            'total_positive_75ms':sum(r['diagnostic']['positive_75ms'] for r in audited),
            'total_negative_75ms':sum(r['diagnostic']['negative_75ms'] for r in audited),
            'science_gate_failures':failed,'seed_archives':archives,'results':audited,
            'validation_runs':0,'heldout_runs':0,'formal_development_runs':0,
            'official_F3_labels_constructed':0,'F3_PR_AUC_computed':False,
            'training_executed':False,**SCIENCE}
    (DEST/'P12D_PILOT_FEASIBILITY_SUMMARY.json').write_text(json.dumps(report,indent=2)+'\n')
    (DEST/'P12D_OUTPUT_SHA256SUMS.txt').write_text(''.join(
         sha256_file(p)+'  '+p.name+'\n' for p in sorted(DEST.iterdir())
         if p.is_file() and p.name!='P12D_OUTPUT_SHA256SUMS.txt'))
    print('P12D_FINAL',json.dumps({k:report[k] for k in ('status','completed_simulations',
           'selected_face_forwarding_episodes','total_positive_75ms',
           'total_negative_75ms','science_gate_failures')},sort_keys=True),flush=True)


def main():
    p=argparse.ArgumentParser();p.add_argument('--preflight-only',action='store_true')
    if p.parse_args().preflight_only:
        print(json.dumps(preflight(),indent=2))
    else:run()


if __name__=='__main__':main()
