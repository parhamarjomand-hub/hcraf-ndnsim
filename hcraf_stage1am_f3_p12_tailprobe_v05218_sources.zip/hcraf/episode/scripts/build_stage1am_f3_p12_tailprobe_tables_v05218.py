#!/usr/bin/env python3
"""Separate causal features and retrospective diagnostic labels for P12-D PILOT.

The output is NOT the official F3 label/model data, even when generated from
fresh development seeds. Never release Validation/Test, train or compute PR-AUC.
"""
from bisect import bisect_right
from collections import Counter
import json
from pathlib import Path

SCIENCE=dict(Congestion=None,FutureCongestion=None,F3_ready=False,
             GO_FREEZE=False,training_ready=False,
             heldout_release_authorized=False)

def check(ok,reason):
    if not ok:raise RuntimeError(reason)


def lines(path):
    with path.open() as f:
        for line in f:
            if line.strip():yield json.loads(line)


def audited_drops(directory, scenario, audit):
    # The physical audit independently read the witness and proved the global
    # cumulative count. Read only actual QUEUE_DROP events for diagnostic labels.
    raw = directory / "pathwide_witness_b.jsonl"
    assert raw.is_file()
    selected = {int(scenario[k]) for k in (
        "selected_relay_node_id", "selected_mid_node_id",
        "selected_producer_node_id")}
    if audit["physical"]["all_devices_physical_queue_drops"]==0:
        return []
    drops=[]
    with raw.open() as f:
        for line in f:
            if 'QUEUE_DROP' not in line:continue
            e=json.loads(line)
            if e["event_type"]=="QUEUE_DROP" and e["node_id"] in selected and e["device_index"]==0:
                drops.append(int(e["timestamp_ns"]))
    drops.sort()
    check(len(drops)==sum(audit["physical"]["physical_drops_by_role"].values()),
          "P4P6_PATH_SELECTED_QUEUE_DROP_COUNT_DISAGREES_WITH_INDEPENDENT_AUDIT")
    return drops


def process_one(row,directory,features,labels):
    scenario=json.loads((directory/"scenario.json").read_text())
    audit=json.loads((directory/"P12D_PILOT_PHYSICAL_AUDIT.json").read_text())
    check(audit["seed"]==row["seed"] and audit["site"]==row["site"] and
          audit["load"]==row["load"] and audit["telemetry"]==row["telemetry"],
          "P4P6_AUDIT_ROW_PROVENANCE_MISMATCH")
    decisions=list(lines(directory/"events.jsonl.decisions.jsonl"))
    check(len(decisions)==128,"P12D_NO_128_REAL_RESEARCH_DECISIONS")
    local={}
    for e in lines(directory/"nfd_local_queue_at_decision.jsonl"):
        if e["candidate_face_id"]==scenario["selected_face_id"]:
            check(e["observed_before_forwarding"] is True and
                  e["remote_node_queue_accessed"] is False and
                  e["future_pressure_label"] is None,
                  "P4P6_LOCAL_QUEUE_NOT_ONLINE_SAFE")
            check(e["decision_id"] not in local,"P4P6_DUPLICATED_LOCAL_DECISION")
            local[e["decision_id"]]=e
    check(len(local)==128,"P12D_INCOMPLETE_LOCAL_BEFORE_DECISION_DATA")
    received={}
    telemetry={}
    if row["telemetry"]=="on_20ms":
        for r in lines(directory/"queue_telemetry_receipts.jsonl"):
            key=(r["source_node_id"],r["report_id"])
            check(key not in received,"P4P6_DUPLICATE_RECEIVED_REPORT")
            received[key]=r
        for d in lines(directory/"queue_telemetry_decisions.jsonl"):
            check(d["decision_id"] not in telemetry,"P4P6_DUPLICATE_TELEMETRY_DECISION")
            telemetry[d["decision_id"]]=d
        check(len(telemetry)==128,"P12D_NO_ONLINE_TELEMETRY_DECISION_STREAM")
    else:
        check(not (directory/"queue_telemetry_receipts.jsonl").exists(),
              "P4P6_OFF_TELEMETRY_DID_RECEIVE_REPORTS")
    drops=audited_drops(directory,scenario,audit)
    key_prefix=f"{row['seed']}:{row['site']}:{row['load']}:{row['telemetry']}"
    role_nodes={r:scenario["selected_"+r+"_node_id"] for r in ("relay","mid","producer")}
    positives=0;num_features=0;num_missing=0
    for d in decisions:
        t=d["time_ns"]
        identity=key_prefix+":"+str(d["decision_id"])
        nearest=[c for c in d["candidates"] if c["routing_cost"]==1]
        check(len(nearest)==1 and nearest[0]["face_id"]==scenario["selected_face_id"],
              "P4P6_DECISION_SELECTED_FACE_CHANGED")
        q=local[d["decision_id"]]
        check(q["sim_time_ns"]==t,"P4P6_LOCAL_FEATURE_AFTER_DECISION")
        predictors={"fib_route_cost":1,
                    "local_selected_queue_packets":q["queue_packets"],
                    "local_selected_queue_fraction":q["local_queue_occupancy_fraction"],
                    "local_selected_link_up":q["link_up"]}
        # Features are built ONLY from receipts cited by the C++ online
        # callback. They cannot access pathwide_witness_b or future labels.
        evidence={}
        missed=set()
        if row["telemetry"]=="on_20ms":
            td=telemetry[d["decision_id"]]
            check(td["decision_ns"]==t,"P4P6_TELEMETRY_DECISION_TIME_MISMATCH")
            for ref in td["feature_evidence"]:
                src=ref["source_node_id"]
                check(src not in evidence,"P4P6_DUPLICATE_REMOTE_SOURCE_FEATURE")
                rr=received.get((src,ref["report_id"]))
                check(rr is not None and rr["sample_ns"]<=rr["receipt_ns"]<=t
                      and t-rr["sample_ns"]<=100000000,
                      "P4P6_ILLEGAL_FUTURE_OR_EXPIRED_FEATURE")
                evidence[src]=rr
            missed={e["source_node_id"] for e in td["feature_missing_sources"]}
            check(missed|set(evidence)==set(role_nodes.values()) and
                  not (missed&set(evidence)),
                  "P4P6_MISSING_REPORT_NOT_EXPLICITLY_ENCODED")
        for role,src in role_nodes.items():
            rr=evidence.get(src)
            predictors[role+"_queue_packets"]=None if rr is None else rr["queue_packets_now"]
            predictors[role+"_queue_drops_observed_total"]=None if rr is None else rr["queue_drop_packets_total"]
            predictors[role+"_telemetry_age_ms"]=None if rr is None else (t-rr["sample_ns"])/1e6
            predictors[role+"_telemetry_missing"]=rr is None
            num_features+=int(rr is not None);num_missing+=int(rr is None)
        metadata={"row_key":identity,"seed":row["seed"],"site":row["site"],
                  "load":row["load"],"telemetry":row["telemetry"],
                  "pit_instance_id":d["pit_instance_id"],
                  "decision_id":d["decision_id"],"decision_ns":t,
                  "selected_face_id":scenario["selected_face_id"],
                  "traffic_type":"target" if d["name"].startswith("/hcraf/pilot/") else "competitor"}
        features.write(json.dumps({"metadata_NOT_A_PREDICTOR":metadata,
                                   "allowed_decision_time_features":predictors},sort_keys=True)+"\n")
        n=bisect_right(drops,t+75000000)-bisect_right(drops,t)
        label=int(n>0)
        positives+=label
        labels.write(json.dumps({"row_key":identity,
                                 "DIAGNOSTIC_ONLY_not_official_F3":True,
                                 "retrospective_future_selected_path_QUEUE_DROP_75ms":label,
                                 "retrospective_future_drop_event_count":n},sort_keys=True)+"\n")
    return dict(seed=row["seed"],site=row["site"],load=row["load"],
                telemetry=row["telemetry"],decisions=128,positive_75ms=positives,
                negative_75ms=128-positives,valid_remote_features=num_features,
                missing_remote_features=num_missing,
                physical_queue_drop_events=len(drops))
