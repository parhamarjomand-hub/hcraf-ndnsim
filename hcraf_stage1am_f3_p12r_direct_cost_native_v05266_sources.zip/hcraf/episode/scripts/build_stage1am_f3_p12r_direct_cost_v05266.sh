#!/usr/bin/env bash
set -euo pipefail
ROOT="$(pwd)"
TASK="$ROOT/hcraf/episode"
bash "$TASK/scripts/build_stage1am_f3_p12v_native_v05241.sh"
cd "$ROOT/episode_sources/ns-3"
# Exact instrumented NFD source from the authenticated v05265 build receipt.
printf '%s\n' 'fe207f507a108117bebba6200fc70a8a7e42ee61f5caf71633fa01eea47743eb  src/ndnSIM/NFD/daemon/fw/forwarder.hpp' 'ef69f884de21997111beca27c3eb61a9ca347a81109a839c46c9e9d9f1b2b2e4  src/ndnSIM/NFD/daemon/fw/forwarder.cpp' | sha256sum -c -
echo PASS_EXACT_HISTORICAL_NFD_RECORDER_PRESERVED
cp "$TASK/src/hcraf-stage1am-f3-p12r-direct-cost-v05266.cpp" scratch/hcraf-stage1am-f3-p12r-direct-cost-v05266.cc
cmp -s "$TASK/src/hcraf-stage1am-f3-p12r-direct-cost-v05266.cpp" scratch/hcraf-stage1am-f3-p12r-direct-cost-v05266.cc
python3 ./waf -j 2
test -x build/scratch/hcraf-stage1am-f3-p12r-direct-cost-v05266
sha256sum build/scratch/hcraf-stage1am-f3-p12r-direct-cost-v05266
