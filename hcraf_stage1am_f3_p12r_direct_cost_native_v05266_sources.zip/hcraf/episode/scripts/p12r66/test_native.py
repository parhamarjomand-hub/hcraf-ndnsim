import unittest,os,pathlib,tempfile,collections
from fractions import Fraction
import audit as a
import provenance as p
class TestNative(unittest.TestCase):
 def test_partitions(self):
  for part,n in [('pilot',30),('development',120)]:
   cases,sch,h=a.read_prereg(pathlib.Path(os.environ['P12R66_PREREG']),part);self.assertEqual(len(cases),n);self.assertEqual(len(sch),n//5)
 def test_confirm_blocked(self):
  with self.assertRaises(RuntimeError):a.read_prereg(pathlib.Path(os.environ['P12R66_PREREG']),'confirmation')
 def test_namespace(self):self.assertEqual(len(p.SEEDS),51);self.assertEqual(len(p.STREAMS),1020);self.assertEqual(p.matches(b'seed=640001; stream=2000101; seed=620001'),[640001,2000101])
 def test_range(self):self.assertEqual(p.matches(b'for seed in range(640101,640103):'),[640101,640102,640103])
 def test_srttround(self):self.assertEqual([a.round5(i) for i in range(5)],[0,0,0,1,1]);self.assertEqual(a.round5(4*100+105),101)
 def test_percentile(self):self.assertEqual(a.quantile7([0,100],1,100),1);self.assertEqual(a.quantile7([0,50,100],99,100),99);self.assertEqual(a.quantile7([2,3],1,100),Fraction(201,100))
 def test_exact_area(self):
  b=[dict(event='CHANGE',time_ns='10',new='4'),dict(event='CHANGE',time_ns='20',new='8'),dict(event='CHANGE',time_ns='20',new='3'),dict(event='CHANGE',time_ns='30',new='0')];q=a.IndependentArea(b);self.assertEqual(q.area(10,20),40);self.assertEqual(q.area(20,30),30);self.assertEqual(q.area(15,25),35);self.assertEqual(a.window_area([(0,0,0),(10,1,4),(20,2,8),(20,3,3),(30,4,0)],15,25),35)
 def test_witness_bounds(self):
  with self.assertRaises(RuntimeError):a.queue_audit([],[])
 def test_offered(self):self.assertEqual(len(a.background_times(3)),18*157);self.assertEqual(len(a.background_times(18)),18*938)
 def test_pilot_required(self):
  from types import SimpleNamespace
  with self.assertRaises(RuntimeError):a.run(SimpleNamespace(partition='development',pilot=None))
 def test_gate(self):
  rc=[];rows=[]
  for seed in range(640001,640004):
   for site in a.SITES:
    for arm in 'ABCDE':
     rc.append(dict(case=dict(seed=str(seed),site=site,arm=arm),srtt_nonmissing=120,all_positive=25 if arm in 'BE' else 0,g_positive=20 if site=='local_forward' and arm in 'BE' else 0,receiver_errors=20 if arm in 'CE' else 0,eligible_receiver_packets=1000));rows.extend(dict(rc=[10,20,30][i%3]) for i in range(126))
  self.assertEqual(a.gate(rc,rows,'pilot')['cases'],30);rc[1]['all_positive']=0
  with self.assertRaises(RuntimeError):a.gate(rc,rows,'pilot')
 def test_invalid_q(self):
  with self.assertRaises(RuntimeError):a.window_area([(0,0,0),(10,1,0)],-1,5)
if __name__=='__main__':unittest.main()
