import os,unittest,pathlib,json,zipfile,tempfile
import recovery as r
import audit as a
import provenance as p
P=pathlib.Path
class TestRecovery(unittest.TestCase):
 def test_actual_failed_artifact(self):
  x=r.verify(P(os.environ['P12R66_FAILED_ZIP']));self.assertEqual(x['scheduled_matches'],42);self.assertEqual(x['accepted_cases'],0);self.assertFalse(x['failed_data_training_authorized'])
 def test_reject_wrong_archive(self):
  with tempfile.TemporaryDirectory() as d:
   q=P(d)/'wrong.zip';q.write_bytes(b'bad')
   with self.assertRaises(RuntimeError):r.verify(q)
 def test_no_legacy_dispatch(self):
  s=(P(__file__).resolve().parents[2]/'src'/(a.BIN+'.cpp')).read_text();self.assertNotIn('->hcrafEnableCoverage(',s);self.assertNotIn('->hcrafEnableProbing(',s);self.assertIn('fw->hcrafEnable(output+"/events.jsonl",1)',s);self.assertIn('NATIVE_STRATEGY_TX_MISMATCH',s);self.assertIn('THREE_ELIGIBLE_NATIVE_FACES',s);self.assertIn('sendInterest(interest,face,pitEntry)!=nullptr',s)
 def test_pinned_failed_ancestry(self):self.assertEqual(p.PRIOR[p.FAILED],p.FAILED_COMMIT);self.assertEqual(p.FAILED,46116798501)
if __name__=='__main__':unittest.main()
