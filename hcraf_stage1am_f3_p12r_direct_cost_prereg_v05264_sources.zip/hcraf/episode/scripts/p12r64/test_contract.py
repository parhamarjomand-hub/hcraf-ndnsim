import unittest,json,copy
from fractions import Fraction as F
from contract import *
class Tests(unittest.TestCase):
 def test_matrix(self): self.assertEqual(lock_inputs(None)['cases'],510)
 def test_threshold(self): self.assertEqual([qlabel(599999999),qlabel(600000000)],[0,1])
 def test_invalid_area(self):
  with self.assertRaises(ValueError):qlabel(-1)
 def test_quantile(self): self.assertEqual(quantile7([10,20,30,40],F(1,100)),F(103,10))
 def test_rtt(self): self.assertEqual(srtt_update(100,150),110);self.assertEqual(srtt_update(None,100),100)
 def test_score_ties(self):
  self.assertEqual(score(20,50,0,F(0),F(100)),(1000000,1000000));self.assertEqual(score(10,100,0,F(0),F(100)),(1000000,1000000))
 def test_score_missing(self):self.assertEqual(score(30,None,1,F(0),F(100)),(2000000,3000000))
 def test_ap_ties(self):self.assertEqual(ap([10,10,0],[1,0,1]),F(7,12))
 def test_ap_single_class(self):
  for y in ([0,0],[1,1]):
   with self.assertRaises(ValueError):ap([1,2],y)
 def test_bad_lock(self):
  p=json.loads((P/'PLAN.json').read_text());m,s=rows(p);p['locks']['F3_ready']=True
  with self.assertRaises(ValueError):validate(p,m,s)
 def test_bad_schedule(self):
  p=json.loads((P/'PLAN.json').read_text());m,s=rows(p);s[0]=s[1]
  with self.assertRaises(ValueError):validate(p,m,s)
 def test_bad_weights(self):
  p=json.loads((P/'PLAN.json').read_text());m,s=rows(p);p['weights']['full']=[1,1,2]
  with self.assertRaises(ValueError):validate(p,m,s)
 def test_bad_arms(self):
  p=json.loads((P/'PLAN.json').read_text());m,s=rows(p);p['confirmation']['primary_arms']=['B']
  with self.assertRaises(ValueError):validate(p,m,s)
if __name__=='__main__':unittest.main()
