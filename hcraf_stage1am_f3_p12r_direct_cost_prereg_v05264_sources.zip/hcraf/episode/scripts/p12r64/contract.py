"""Pre-execution contract utilities. No reading historical score rows, no fitting or simulation."""
import csv, hashlib, io, json, random
from fractions import Fraction
from pathlib import Path
P=Path(__file__).resolve().parent
LOCKS=dict(F3_ready=False,GO_FREEZE=False,training_ready=False,Congestion=None,FutureCongestion=None,construct_validated=False,heldout_release_authorized=False,Stage1AO_or_NSGAIII_authorized=False)
M=1000000

def need(x,msg):
    if not x: raise ValueError(msg)
def sha(b): return hashlib.sha256(b).hexdigest()
def key(*args): return hashlib.sha256(('P12R64|'+'|'.join(map(str,args))).encode()).digest()
def rows(plan):
    matrix=[]; probes=[]
    for part in ('pilot','development','confirmation'):
        v=plan['partitions'][part]
        start=v['start']
        for seed in range(start,start+v['count']):
            for si,site in enumerate(plan['physical']['sites']):
                target=(seed-start+si)%3; stream=2000000+(seed-640000)*100+si*10
                for arm in sorted(plan['physical']['arms']):
                    rate,loss,delay=plan['physical']['arms'][arm]
                    matrix.append((part,seed,site,arm,target,rate,loss,delay,stream,stream+1,stream+2))
                for b in range(14):
                    pairs=sorted(((s,r) for s in range(3) for r in range(3)),key=lambda pair:key('pair',seed,site,b,*pair))
                    for j,(slot,rank) in enumerate(pairs):
                        i=9*b+j; other=sorted([s for s in range(3) if s!=slot],key=lambda s:key('other',seed,site,i,s)); costs=[0,0,0];costs[slot]=10*(rank+1)
                        for s,r in zip(other,[r for r in range(3) if r!=rank]):costs[s]=10*(r+1)
                        t=2000000000+i*125000000+int.from_bytes(key('jitter',seed,site,i)[:8],'big')%20000001-10000000
                        probes.append((part,seed,site,i,t,slot,*costs))
    return matrix,probes
MH='partition,seed,site,arm,target_slot,background_mbps,error_ppm,extra_propagation_ms,traffic_stream,error_stream,stream_base'.split(',')
SH='partition,seed,site,decision_index,decision_ns,selected_slot,cost_slot0,cost_slot1,cost_slot2'.split(',')
def csvbytes(header,rr):
    f=io.StringIO(newline='');w=csv.writer(f,lineterminator='\n');w.writerow(header);w.writerows(rr);return f.getvalue().encode()
def qlabel(area,h=75000000,cap=32):
    need(isinstance(area,int) and 0<=area<=h*cap and h>0 and cap>0,'AREA');return int(4*area>=h*cap)
def quantile7(vals,q):
    need(len(vals)>0 and 0<=q<=1,'QUANTILE');v=sorted(map(Fraction,vals));x=(len(v)-1)*Fraction(q);i=x.numerator//x.denominator;return v[i]+(x-i)*(v[min(i+1,len(v)-1)]-v[i])
def srtt_update(prev,sample):
    need(isinstance(sample,int) and sample>0 and (prev is None or isinstance(prev,int) and prev>0),'RTT');return sample if prev is None else round(Fraction(4*prev+sample,5))
def score(rc,rtt,g,L,U):
    need(rc in (10,20,30) and g in (0,1) and U>L and (rtt is None or isinstance(rtt,int) and rtt>0),'SCORE_INPUT')
    r=(rc-10)*M//20;s=M if rtt is None else round(M*min(Fraction(1),max(Fraction(0),(Fraction(rtt)-L)/(U-L))))
    return r+s,r+s+M*g

def ap(keys,labels):
    need(len(keys)==len(labels)>0 and all(isinstance(x,int) for x in keys) and set(labels)=={0,1},'PRIMARY_RUN_SINGLE_CLASS_OR_INVALID')
    npos=sum(labels);cum=tp=0;ans=Fraction(0);pairs=sorted(zip(keys,labels),reverse=True);i=0
    while i<len(pairs):
        j=i+1
        while j<len(pairs) and pairs[j][0]==pairs[i][0]:j+=1
        p=sum(y for _,y in pairs[i:j]);cum+=j-i;tp+=p;ans+=Fraction(p,npos)*Fraction(tp,cum);i=j
    return ans

def validate(plan,matrix,probes):
    need(plan['protocol']=='P12R64_DIRECT_COST_PROSPECTIVE_DESIGN' and plan['status']=='DESIGN_LOCK_ONLY_NO_EXECUTION','PROTOCOL')
    need(plan['locks']==LOCKS and all(x==0 for x in plan['authorized'].values()) and plan['prior_NO_GO_preserved'],'LOCKS')
    need(plan['partitions']=={'pilot':{'start':640001,'count':3},'development':{'start':640101,'count':12},'confirmation':{'start':640201,'count':36}},'PARTITIONS')
    need(plan['physical']['sites']==['local_forward','producer_return'] and plan['physical']['arms']=={'A':[3,0,0],'B':[18,0,0],'C':[3,20000,0],'D':[3,0,20],'E':[18,20000,0]},'ARMS')
    need(plan['physical']['horizon_ns']==75000000 and plan['physical']['capacity_packets']==32 and plan['physical']['threshold_numerator']==1 and plan['physical']['threshold_denominator']==4,'PHYSICAL')
    need(plan['weights']['base']==[1,1,0] and plan['weights']['full']==[1,1,1] and plan['weights']['base_denominator']==2 and plan['weights']['full_denominator']==3,'WEIGHTS')
    need(plan['confirmation']['primary_arms']==['B','E'] and plan['confirmation']['control_arms']==['A','C','D'] and plan['confirmation']['cases']==360 and plan['confirmation']['selected_rows']==45360 and plan['confirmation']['primary_cases']==144,'ESTIMAND')
    need(len(matrix)==510 and len({r[:4] for r in matrix})==510 and len(probes)==12852 and len({r[:4] for r in probes})==12852,'CARDINALITY')
    from collections import Counter,defaultdict
    need(Counter(r[0] for r in matrix)=={'pilot':30,'development':120,'confirmation':360},'CASE_COUNTS')
    groups=defaultdict(list)
    for r in probes:groups[r[:3]].append(r)
    need(len(groups)==102,'SCHEDULE_GROUPS')
    streams={}
    for r in matrix:
        need(r[:3] in groups and r[4] in range(3),'MATRIX_MAPPING'); streams[r[:3]]=r[8]
    need(len(set(streams.values()))==102 and all(b-a>=10 for a,b in zip(sorted(streams.values()),sorted(streams.values())[1:])),'STREAM_COLLISION')
    for group,rr in groups.items():
        need(len(rr)==126 and [r[3] for r in rr]==list(range(126)),'DECISION_COUNT')
        need(all(1990000000<=r[4]<18000000000 and sorted(r[6:])==[10,20,30] for r in rr),'COST_TIME')
        need(all(b[4]-a[4]>=105000000 for a,b in zip(rr,rr[1:])),'DECISION_SPACING')
        for i in range(0,126,9):need({(r[5],r[6+r[5]]) for r in rr[i:i+9]}=={(s,c) for s in range(3) for c in (10,20,30)},'BALANCE')
    return {'cases':510,'pilot_cases':30,'development_cases':120,'confirmation_cases':360,'primary_confirmation_cases':144,'control_confirmation_cases':216,'schedule_rows':12852,'unique_seed_site_schedules':102,'decisions_per_case':126,'selected_confirmation_rows':45360,'all_selected_rows':64260}

def lock_inputs(out,generate=False):
    plan=json.loads((P/'PLAN.json').read_text());matrix,probes=rows(plan);counts=validate(plan,matrix,probes)
    for name,b in [('LOCKED_MATRIX.csv',csvbytes(MH,matrix)),('LOCKED_SCHEDULE.csv',csvbytes(SH,probes))]:
        if generate:(P/name).write_bytes(b)
        else:need((P/name).read_bytes()==b,'LOCKED_MATRIX_OR_SCHEDULE_CHANGED')
    return counts
if __name__=='__main__':
    import sys
    print(lock_inputs(None,'--generate' in sys.argv))
