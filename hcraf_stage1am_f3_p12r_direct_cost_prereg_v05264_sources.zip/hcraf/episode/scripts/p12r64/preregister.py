"""Verify historical receipts and emit a design-only receipt. Never read scored rows."""
import json,sys,zipfile
from pathlib import Path
from contract import P,LOCKS,need,sha,lock_inputs
PARENTS={
 15221940873:('746889957c3d91523fa937e7a888cef4e50d847c8596760f6b833ccdafe28ab2','p12r_prereg/PREREG_RECEIPT.json','PASS_P12R_NEW_CONSTRUCT_PREREG_ONLY_NO_EXECUTION_NO_RELEASE'),
 15251036596:('46a9efb4e47277fd45a0bbe63dc32df411abdf9323bd615feb4be75d0a48d869','analysis_result/ANALYSIS_RECEIPT.json','NO_GO_P12R62_CONJUNCTIVE_GATES_NOT_MET'),
 15251340757:('5199ecc7c84e85deac3530a05c06134384821c85195482cc111f3745f1d17f0b','mapping_result/MAPPING_RECEIPT.json','PASS_ARCHITECTURE_MAPPING_AUDIT_F3_RELEASE_BLOCKED')}
def verify(inputs,out):
    parents={};receipts={}
    for aid,(digest,member,status) in PARENTS.items():
        raw=(inputs/f'github-actions-artifact-{aid}.zip').read_bytes();need(sha(raw)==digest,'PARENT_HASH')
        with zipfile.ZipFile(inputs/f'github-actions-artifact-{aid}.zip') as z:
            need(len(z.namelist())==len(set(z.namelist())) and member in z.namelist(),'PARENT_MEMBERS')
            b=z.read(member);r=json.loads(b)
        need(r['status']==status,'PARENT_STATUS');need(all(r.get(k)==v and k in r for k,v in LOCKS.items()),'PARENT_LOCKS');receipts[aid]=r
        parents[str(aid)]={'archive_sha256':digest,'receipt_sha256':sha(b),'status':status}
    a=receipts[15251036596];m=receipts[15251340757]
    need(len(a['physical_gates'])==13 and all(a['physical_gates'].values()) and sum(a['prediction_gates'].values())==1,'PRIOR_SCIENTIFIC_GATES')
    need(m['cases']==540 and m['mixed_runs']==216 and m['negative_only_runs']==324 and m['prior_scientific_decision']==a['status'],'MAPPING')
    need(not m['new_AP_computed'] and not m['new_confirmation_authorized'],'MAPPING_LOCK')
    counts=lock_inputs(None)
    files={n:sha((P/n).read_bytes()) for n in ('PLAN.json','LOCKED_MATRIX.csv','LOCKED_SCHEDULE.csv','contract.py','preregister.py','test_contract.py')}
    r={'status':'PASS_P12R64_DIRECT_COST_DESIGN_LOCK_ONLY_NO_EXECUTION','protocol':'P12R64_DIRECT_COST_PROSPECTIVE_DESIGN','files':files,'parents':parents,'planned':counts,'prior_NO_GO_preserved':True,'native_implementation_verified':False,'historical_seed_namespace_verified':False,'native_pilot_authorized':False,'confirmation_authorized':False,'model_fits':0,'simulations':0,'confirmation_rows_read':0,'new_AP_computed':False,'new_bootstrap_computed':False,'official_F3_labels_constructed':0,'review_required':'Implementation and scope/estimand review and historical seed/stream audit before pilot; new hypothesis after previous NO_GO. No formal power claim.',**LOCKS}
    out.mkdir(parents=True,exist_ok=True);(out/'PREREG_RECEIPT.json').write_text(json.dumps(r,sort_keys=True,indent=2)+'\n');print(r['status']);return r
if __name__=='__main__':verify(Path(sys.argv[1]),Path(sys.argv[2]))
