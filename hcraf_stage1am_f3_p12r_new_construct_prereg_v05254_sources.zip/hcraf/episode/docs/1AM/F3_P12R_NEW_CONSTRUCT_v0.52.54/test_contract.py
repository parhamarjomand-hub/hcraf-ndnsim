import unittest,collections, tempfile,pathlib,json
from contract import *
class ContractTests(unittest.TestCase):
    def test_matrix(self):
        m,s=matrix();self.assertEqual(len(m),765);self.assertEqual(len(s),19278);self.assertEqual(len(set(m)),765);self.assertEqual(len(set(s)),19278)
        self.assertEqual(collections.Counter(r[0] for r in m),{'pilot':45,'development':180,'confirmation':540});self.assertEqual(len({r[1] for r in m}),51)
    def test_paired_arms(self):
        m,_=matrix();g=collections.defaultdict(list)
        for r in m:g[r[:3]].append(r)
        for v in g.values():
            self.assertEqual({r[3] for r in v},set(ARMS));self.assertEqual(len({(r[4],*r[8:]) for r in v}),1)
            for r in v:self.assertEqual(r[5:8],ARMS[r[3]])
        self.assertEqual(len({n for v in g.values() for n in v[0][10:13]}),3*len(g))
    def test_schedule(self):
        _,s=matrix();g=collections.defaultdict(list)
        for r in s:g[r[:3]].append(r[3:])
        for v in g.values():
            self.assertEqual(collections.Counter(r[2] for r in v),{0:42,1:42,2:42});self.assertTrue(all(set(r[2] for r in v[i:i+3])=={0,1,2} for i in range(0,126,3)));self.assertTrue(all(a[1]<b[1] for a,b in zip(v,v[1:])));self.assertTrue(all(H<r[1]<20_000_000_000-H for r in v))
    def test_target_balance(self):
        m,_=matrix()
        for part,(a,b) in PARTS.items():
            for site in SITES:self.assertEqual(collections.Counter(r[4] for r in m if r[0]==part and r[2]==site and r[3]=='A'),{i:(b-a+1)//3 for i in range(3)})
    def test_empty(self):self.assertEqual(reference([[(0,0,0)]]*3,H,0,2*H),(0,0,0))
    def test_exact_threshold(self):self.assertEqual(reference([[(0,0,0),(H,1,8)]]+ [[(0,0,0)]]*2,H,0,2*H),(0,Fraction(1,4),1))
    def test_just_below(self):self.assertEqual(reference([[(0,0,0),(H+1,1,8)]]+ [[(0,0,0)]]*2,H,0,2*H)[2],0)
    def test_max_not_sum(self):self.assertEqual(reference([[(0,0,4)]]*3,H,0,2*H),(Fraction(1,8),Fraction(1,8),0))
    def test_boundary(self):self.assertEqual(reference([[(0,0,16),(H,1,0),(H,2,8),(2*H,3,32)]]+ [[(0,0,0)]]*2,H,0,2*H),(Fraction(1,2),Fraction(1,4),1))
    def test_invalid(self):
        for events,cover in [([(1,0,0)],2*H), ([(0,0,33)],2*H), ([(0,0,0),(0,0,1)],2*H), ([(0,0,0)],2*H-1), ([(0,0,0),(H,1,-1)],2*H)]:
            with self.assertRaises(ValueError):reference([events]*3,H,0,cover)
        with self.assertRaises(ValueError):reference([[(0,0,0)]]*2,H,0,2*H)
    def test_parent_reject(self):
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d)/'wrong.zip';p.write_bytes(b'wrong')
            with self.assertRaises(ValueError):validate_parent(p)
    def test_plan(self):
        p=json.loads(pathlib.Path(__file__).with_name('PLAN.json').read_bytes());self.assertEqual(p['locks'],LOCKS);self.assertEqual(p['feature_order_full'],list(FULL));self.assertEqual(p['feature_order_baseline'],list(BASE));self.assertTrue(set(BASE)<set(FULL));self.assertEqual(p['horizon_ns'],H)
if __name__=='__main__':unittest.main()
