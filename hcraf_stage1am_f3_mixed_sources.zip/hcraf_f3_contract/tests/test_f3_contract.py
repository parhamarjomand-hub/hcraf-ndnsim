"""Fail-closed adversarial tests for 1AM F3 candidate contract preflight."""
import contextlib, hashlib, io, json, os, pathlib, tempfile, unittest, zipfile
from hcraf_f3_contract.scripts.audit import audit, load_ref, assert_no_promotion, EvidenceError, HORIZON_NS, validate_scenario

REF=pathlib.Path(os.environ.get('F3_EVIDENCE_ZIP','hcraf_stage1am_f3_evidence_reference.zip'))

class F3ContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        assert REF.is_file(),f'MISSING_REFERENCE:{REF}'
        with zipfile.ZipFile(REF) as z:
            cls.parts={n:z.read(n) for n in z.namelist()}
        cls.first_path=next(x for x in cls.parts if x.startswith('evidence/pathwide/') and x.endswith('stage1am_pathwide_oracle.json') and '/LOCAL_FORWARD/' in x)
        cls.first_lp=next(x for x in cls.parts if x.startswith('evidence/lp_return/') and x.endswith('stage1am_lp_return_oracle.json') and '/RETURN_DATA/' in x)
        cls.first_scenario=next(x for x in cls.parts if x.startswith('evidence/pathwide/') and x.endswith('/scenario.json'))

    def make_zip(self, mutation=None, recompute=True, add_extra=None, remove=None):
        parts=dict(self.parts)
        if remove:parts.pop(remove)
        if mutation:
            n,fn=mutation
            d=json.loads(parts[n]);fn(d);parts[n]=(json.dumps(d,ensure_ascii=False)+'\n').encode()
        if recompute:
            p=json.loads(parts['REFERENCE_PROVENANCE.json'])
            p['files_sha256']={n:hashlib.sha256(b).hexdigest() for n,b in parts.items() if n!='REFERENCE_PROVENANCE.json'}
            parts['REFERENCE_PROVENANCE.json']=json.dumps(p).encode()
        if add_extra:parts[add_extra]=b'extra'
        data=io.BytesIO()
        with zipfile.ZipFile(data,'w',zipfile.ZIP_DEFLATED) as z:
            for n,b in parts.items():z.writestr(n,b)
        data.seek(0)
        return data

    def run_bad(self,which,edit):
        zbuf=self.make_zip((which,edit))
        with zipfile.ZipFile(zbuf) as z:
            with self.assertRaises(EvidenceError):audit(z)

    def test_01_complete_audit(self):
        with zipfile.ZipFile(REF) as z:r=audit(z)
        d=json.loads(r['output/contract_summary.json'])
        self.assertEqual(d['status'],'NO_GO_F3_CONTRACT_CANDIDATES_NOT_VALIDATED')
        self.assertEqual(d['pathwide_v0411']['windows'],720)
        self.assertEqual(d['lp_return_v0420']['windows'],288)
        self.assertEqual(d['notable_disagreement']['target_only_drop_windows'],74)
        self.assertFalse(d['GO_FREEZE'])
        self.assertFalse(d['F3_ready'])
        self.assertIsNone(d['FutureCongestion'])
        self.assertEqual(len(r),5)

    def test_02_gate_blocked(self):
        with zipfile.ZipFile(REF) as z:r=audit(z)
        d=json.loads(r['output/gate_matrix.json'])
        self.assertFalse(d['approved_for_1AN_freeze'])
        self.assertGreaterEqual(sum(x['status']=='BLOCKED' for x in d['gates']),6)

    def test_03_no_promotion_bool(self):
        for flag in ('GO_FREEZE','F3_ready','training_ready'):
            with self.assertRaises(EvidenceError):assert_no_promotion({flag:True,**{x:False for x in ('GO_FREEZE','F3_ready','training_ready') if x!=flag},'Congestion':None,'FutureCongestion':None},'TEST')

    def test_04_no_promotion_label(self):
        for flag in ('Congestion','FutureCongestion'):
            x=dict(GO_FREEZE=False,F3_ready=False,training_ready=False,Congestion=None,FutureCongestion=None)
            x[flag]=0
            with self.assertRaises(EvidenceError):assert_no_promotion(x,'TEST')

    def test_05_reject_past_horizon(self):
        self.run_bad(self.first_lp,lambda d:d['target_windows'][0].__setitem__('horizon_end_ns',d['target_windows'][0]['decision_ns']+HORIZON_NS+1))

    def test_06_reject_corrupt_face(self):
        self.run_bad(self.first_lp,lambda d:d['target_windows'][0].__setitem__('selected_face_id',900))

    def test_07_reject_new_F3_label(self):
        self.run_bad(self.first_lp,lambda d:d['target_windows'][0].__setitem__('FutureCongestion',1))

    def test_08_reject_erase_unknown_historical(self):
        self.run_bad(self.first_lp,lambda d:d['target_windows'][0].__setitem__('old_oracle_class',0))

    def test_09_reject_fake_competitor(self):
        self.run_bad(self.first_lp,lambda d:d['target_windows'][0].__setitem__('known_competitor_DATA_drops',0))

    def test_10_reject_event_repeat(self):
        self.run_bad(self.first_lp,lambda d:d['target_windows'][0]['drop_event_seqs'].__setitem__(1,d['target_windows'][0]['drop_event_seqs'][0]))

    def test_11_reject_wrong_oracle_witness(self):
        self.run_bad(self.first_path,lambda d:d['target_rows'][0].__setitem__('witness_count',0))

    def test_12_reject_bad_oracle_time(self):
        self.run_bad(self.first_path,lambda d:d['target_rows'][0].__setitem__('t_decision_ns',-7))

    def test_13_reject_offpath_face(self):
        self.run_bad(self.first_path,lambda d:d['target_rows'][0].__setitem__('selected_path_nodes',[0,1,3,5]))

    def test_14_reject_remote_feature(self):
        self.run_bad(self.first_scenario,lambda d:d.__setitem__('remote_queue_online_feature',True))

    def test_15_reject_false_HCRAF_latency(self):
        self.run_bad(self.first_scenario,lambda d:d.__setitem__('decision_time_us_real_HCRAF',133))

    def test_16_reject_unpinned_evidence_member(self):
        b=self.make_zip((self.first_lp,lambda d:d.__setitem__('GO_FREEZE',True)),recompute=False)
        with zipfile.ZipFile(b) as z:
            with self.assertRaises(EvidenceError) as ctx:load_ref(z)
            self.assertIn('SHA_MISMATCH',str(ctx.exception))

    def test_17_reject_missing_member(self):
        b=self.make_zip(remove=self.first_lp,recompute=False)
        with zipfile.ZipFile(b) as z:
            with self.assertRaises(EvidenceError):load_ref(z)

    def test_18_reject_extraneous_member(self):
        b=self.make_zip(add_extra='evidence/evil.json')
        with zipfile.ZipFile(b) as z:
            with self.assertRaises(EvidenceError):load_ref(z)

    def test_19_reject_invalid_provenance(self):
        b=self.make_zip(('REFERENCE_PROVENANCE.json',lambda d:d['upstream_verified_artifacts']['lp_return'].__setitem__('sha256','00'*32)))
        with zipfile.ZipFile(b) as z:
            with self.assertRaises(EvidenceError):load_ref(z)

    def test_20_unchanged_expected_flags(self):
        with zipfile.ZipFile(REF) as z:r=audit(z)
        self.assertIn(b'NO_GO_F3_CONTRACT_CANDIDATES_NOT_VALIDATED',r['output/contract_summary.json'])
        self.assertNotIn(b'"F3_ready": true',r['output/contract_summary.json'])

if __name__=='__main__':unittest.main()
