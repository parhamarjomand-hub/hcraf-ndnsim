# HCRAF — 1AM F3 Contract Candidate Preflight v0.43.0

پیش‌ممیزی **آفلاین** شواهد تأییدشده v0.41.1 و v0.42.0؛ شبیه‌سازی تازه ندارد. دو Artifact رسمی قبلاً به‌صورت مستقل بر پایه Trace خام ممیزی شده‌اند. Capsule مرجع فقط `scenario`, `oracle`, `verification` مربوط به ۸۴ اجرای monitored را نگه می‌دارد، نه Trace فیزیکی کامل. هش اصل Artifactها در `REFERENCE_PROVENANCE.json` موجود است.

برای GitHub فقط این سه فایل را در مسیر دقیق قرار دهید:

- `hcraf_stage1am_f3_contract_sources.zip` در ریشه مخزن؛ **استخراج نکنید**.
- `hcraf_stage1am_f3_evidence_reference.zip` در ریشه مخزن؛ **استخراج نکنید**.
- `.github/workflows/hcraf-stage1am-f3-contract.yml` در همان مسیر پوشه workflows.

با Actions -> `HCRAF - Stage 1AM F3 Scientific Contract Candidate Audit (v0.43.0)` -> Run workflow اجرای آفلاین را آغاز کنید. Artifact `hcraf-stage1am-f3-contract-...` را ارسال کنید.

خروجی‌های مهم: `contract_summary.json`، `gate_matrix.json`، `legacy_pathwide_720.csv`، `lp_return_diagnostics_288.csv` و هش آنها. **مقدار طبیعی و درست نتیجه `NO_GO_F3_CONTRACT_CANDIDATES_NOT_VALIDATED` است؛ موفقیت GitHub هرگز برابر GO_FREEZE نیست.**

اگر خروجی با Manifest ثبت‌شده فرق داشته باشد Workflow باید Fail شود؛ هیچ داده‌ای به ستون رسمی FutureCongestion منتقل نمی‌شود.
