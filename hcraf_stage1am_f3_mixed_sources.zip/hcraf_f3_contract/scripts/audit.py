#!/usr/bin/env python3
"""Offline F3 *candidate* contract audit using pinned, previously audited oracle snapshots.

It does not generate labels, run ndnSIM, validate remote online features, or allow Freeze.
Only Python stdlib.  Evidence capsule was extracted from approved GitHub artifacts.
"""
import argparse, collections, csv, hashlib, io, json, pathlib, zipfile

HORIZON_NS = 50_000_000
TOPOLOGIES = ('DEV_CHAIN_A', 'DEV_CHAIN_B')
SLOTS = (0, 1, 2)
RUNS = (9601, 9602)
PW_ARMS = ('OFF_BASELINE', 'LOCAL_FORWARD', 'RELAY_FORWARD', 'RETURN_DATA', 'LATE_COMPETITOR')
LP_ARMS = ('OFF_BASELINE', 'RETURN_DATA')
FALSE_FLAGS = ('GO_FREEZE', 'F3_ready', 'training_ready')
NULL_FLAGS = ('Congestion', 'FutureCongestion')
STATUS = 'NO_GO_F3_CONTRACT_CANDIDATES_NOT_VALIDATED'

class EvidenceError(ValueError):
    pass

def need(cond, msg):
    if not cond:
        raise EvidenceError(msg)

def sha(b):
    return hashlib.sha256(b).hexdigest()

def jdump(obj):
    return (json.dumps(obj, indent=2, ensure_ascii=False, sort_keys=True) + '\n').encode('utf-8')

def assert_no_promotion(obj, scope):
    for k in FALSE_FLAGS:
        need(obj.get(k) is False, f'{scope}: forbidden {k}={obj.get(k)!r}')
    for k in NULL_FLAGS:
        need(k in obj and obj[k] is None, f'{scope}: forbidden {k}={obj.get(k)!r}')

def load_ref(z):
    need(z.testzip() is None, 'ZIP CRC_FAIL')
    names=z.namelist()
    need(len(names)==len(set(names)), 'DUPLICATE_MEMBER')
    need(all(n and not n.startswith('/') and '\\' not in n and '..' not in pathlib.PurePosixPath(n).parts for n in names), 'UNSAFE_MEMBER')
    need('REFERENCE_PROVENANCE.json' in names,'MISSING_PROVENANCE')
    manifest=json.loads(z.read('REFERENCE_PROVENANCE.json'))
    need(manifest['schema']=='F3_CONTRACT_REF_V1','BAD_PROVENANCE_SCHEMA')
    expected=manifest['files_sha256']
    need(set(names)==set(expected)|{'REFERENCE_PROVENANCE.json'}, 'EXTRA_OR_MISSING_EVIDENCE')
    for n,h in expected.items():
        need(sha(z.read(n))==h, f'SHA_MISMATCH:{n}')
    need(len(expected)==(60*3+24*4),'WRONG_FILE_COUNT')
    need(manifest['upstream_verified_artifacts']['pathwide']['sha256']=='521ec2e8ac3c4aa5a39ff3c1aad547d4b79d7ce4c825a38df95117caaa052762','UNEXPECTED_PATHWIDE_ARTIFACT')
    need(manifest['upstream_verified_artifacts']['lp_return']['sha256']=='2e8a1c432514b8f9619326cc40e334dc98156b284b3a151224c624583dc3d730','UNEXPECTED_LP_ARTIFACT')
    return manifest

def getj(z, source, topology, slot, arm, run, name):
    path=f'evidence/{source}/{topology}/slot-{slot}/monitored/{arm}/run-{run}/{name}'
    try: return json.loads(z.read(path))
    except KeyError as e: raise EvidenceError(f'MISSING:{path}') from e

def validate_scenario(s, topology, slot, arm, run, stage):
    need(s['topology_id']==topology and s['selected_face_slot']==slot and s['run']==run,'SCENARIO_IDENTITY')
    need(s['selected_face_id']==258+slot, 'FACE_MISMATCH')
    need(s['phase_arm']==arm, 'ARM_MISMATCH')
    need(s['path_nodes'][0]==0 and s['path_nodes'][1]==1 and len(s['path_nodes'])==4,'PATH_LENGTH_OR_ORIGIN')
    need(s['future_oracle_horizon_ns_pilot']==HORIZON_NS,'HORIZON_CONFIG')
    need(s['actual_assignment_probability']==1.0 and s['no_counterfactual_unselected_face'] is True,'BAD_PROPENSITY_CLAIM')
    need(s['remote_queue_online_feature'] is False, 'REMOTE_QUEUE_LEAK')
    need(s['future_oracle_is_final_F3'] is False, 'FALSE_FINAL_ORACLE')
    need(s['decision_time_us_real_HCRAF'] is None, 'FALSE_HCRAF_COST')
    need(s['instrument_enabled'] is True, 'UNINSTRUMENTED_CONFOUNDED')
    need(s['congestion'] is None and s['future_congestion'] is None,'FALSE_LABEL_SCENARIO')
    for f in ('F3_ready','training_ready'):
        need(s[f] is False,'FALSE_READINESS_SCENARIO')
    return s['path_nodes']

def validate_pathwide(z, topology, slot, arm, run):
    s=getj(z,'pathwide',topology,slot,arm,run,'scenario.json')
    path=validate_scenario(s,topology,slot,arm,run,'pathwide')
    o=getj(z,'pathwide',topology,slot,arm,run,'stage1am_pathwide_oracle.json')
    v=getj(z,'pathwide',topology,slot,arm,run,'stage1am_pathwide_verification.json')
    assert_no_promotion(o,'PATHWIDE_ORACLE');assert_no_promotion(v,'PATHWIDE_VERIFICATION')
    need(v['status']=='PASS_PATHWIDE_PHYSICS_AUDIT_ONLY','PW_VERIFY_STATUS')
    need(v['topology']==topology and v['slot']==slot and v['arm']==arm and v['rng_run']==run,'PW_VERIFY_IDENTITY')
    need(o['all_14_directed_interfaces_recorded'] is True, 'PW_PHYSICAL_NOT_COMPLETE')
    need(len(o['forward_tx_devices'])==3 and len(o['return_tx_devices'])==3,'PATH_DEVICES')
    need(o['selected_face_slot']==slot and o['topology']==topology,'PW_ORACLE_IDENTITY')
    rows=o['target_rows'];need(len(rows)==12,'PW_EXPECTED_TWELVE_WINDOWS')
    ctr=collections.Counter();out=[];seen=set()
    for r in rows:
        assert_no_promotion(r,'PW_ROW')
        lab=r['pilot_path_future_competitor_interest_drop_50ms']
        need(lab in (0,1,'UNKNOWN') and type(lab) in (int,str),'PW_BAD_LABEL')
        need(r['horizon_end_ns']-r['t_decision_ns']==HORIZON_NS,'PW_WRONG_HORIZON')
        need(r['t_decision_ns']>0 and r['selected_face_id']==258+slot and r['selected_face_slot']==slot,'PW_DECISION_FACE')
        need(r['selected_path_nodes']==path,'PW_PATH_MISMATCH')
        need(r['oracle_is_offline_only'] is True and r['online_remote_queue_feature'] is False,'PW_FUTURE_LEAK')
        need(r['target_name'].startswith('/hcraf/pilot/'),'PW_NAME')
        need(r['decision_id'] not in seen,'PW_DUPLICATE_DECISION'); seen.add(r['decision_id'])
        witness=r['witness_count'];unknown=r['unknown_drop_count']
        need(isinstance(witness,int) and witness>=0 and isinstance(unknown,int) and unknown>=0,'PW_BAD_COUNTS')
        if lab==1:
            need(witness>0 and unknown==0 and r['oracle_reason']=='VERIFIED_COMPETITOR_INTEREST_DROP_ON_SELECTED_PATH','PW_FALSE_POSITIVE')
        elif lab==0:
            need(witness==0 and unknown==0 and r['oracle_reason']=='COMPLETE_PHYSICAL_WINDOW_NO_VERIFIED_COMPETITOR_DROP','PW_FALSE_NEGATIVE')
        else:
            need(unknown>0 and r['oracle_reason']=='UNKNOWN_UNCLASSIFIABLE_DROP_ON_SELECTED_PATH','PW_UNKNOWN_ERASED')
        ctr[str(lab)]+=1
        out.append(dict(corpus='PATHWIDE_0411',topology=topology,slot=slot,face_id=258+slot,arm=arm,run=run,decision_id=r['decision_id'],decision_ns=r['t_decision_ns'],horizon_end_ns=r['horizon_end_ns'],legacy_pilot_interest_drop=lab,witness_count=witness,unknown_count=unknown,local_queue_at_decision=r['selected_local_queue_packets_at_decision'],is_final_F3=False))
    need(ctr['1']==o['pilot_positive']==v['pilot_positive'] and ctr['0']==o['pilot_negative']==v['pilot_negative'] and ctr['UNKNOWN']==o['pilot_unknown']==v['pilot_unknown'],'PW_COUNT_MISMATCH')
    if arm=='RETURN_DATA':need(ctr['UNKNOWN']==12, 'HISTORICAL_UNKNOWN_MUST_REMAIN')
    return out

def validate_lp(z, topology, slot, arm, run):
    s=getj(z,'lp_return',topology,slot,arm,run,'scenario.json')
    validate_scenario(s,topology,slot,arm,run,'lp_return')
    o=getj(z,'lp_return',topology,slot,arm,run,'stage1am_lp_return_oracle.json')
    v=getj(z,'lp_return',topology,slot,arm,run,'stage1am_lp_return_verification.json')
    pw=getj(z,'lp_return',topology,slot,arm,run,'stage1am_pathwide_oracle.json')
    for k,obj in [('LP_ORACLE',o),('LP_VERIFY',v),('LP_OLD_ORACLE',pw)]:assert_no_promotion(obj,k)
    need(o['status']=='DIAGNOSTIC_ONLY_NO_F3_PROMOTION' and v['status']=='PASS_GROUP_TRACE_AUDIT_ONLY','LP_STATUS')
    need(o['official_F3_labels']==v['official_F3_labels']==0,'OFFICIAL_LABEL_PROMOTED')
    need(v['topology']==topology and v['slot']==slot and v['arm']==arm and v['rng_run']==run,'LP_VERIFY_IDENTITY')
    need(o['sender_lp_groups_unresolved']==v['sender_lp_groups_unresolved']==0,'LP_UNRESOLVED_GROUP')
    need(o['sender_lp_groups_complete_attributed']==o['sender_lp_groups_observed'],'LP_GROUP_INCOMPLETE')
    need(o['selected_return_fragment_drop_count']==v['selected_return_fragment_drops'],'LP_DROP_CROSSCHECK')
    need(o['selected_return_fragment_drop_count']==sum(o['drop_by_class'].values()),'LP_DROP_CLASS_SUM')
    need(pw['pilot_unknown']==(12 if arm=='RETURN_DATA' else 0),'LP_HISTORICAL_UNKNOWN')
    rows=o['target_windows'];need(len(rows)==12,'LP_EXPECTED_TWELVE_WINDOWS')
    seen=set(); out=[];ctr=collections.Counter()
    for r in rows:
        for f in ('F3_ready','GO_FREEZE','training_ready'):need(r[f] is False,'LP_ROW_FALSE_READINESS')
        need(r['FutureCongestion'] is None,'LP_ROW_FALSE_LABEL')
        need(r['horizon_end_ns']-r['decision_ns']==HORIZON_NS,'LP_WRONG_HORIZON')
        need(r['selected_face_id']==258+slot,'LP_WRONG_FACE')
        need(r['decision_id'] not in seen,'LP_DUPLICATE_DECISION');seen.add(r['decision_id'])
        need(r['is_retrospective'] is True,'LP_FUTURE_FEATURE_LEAK')
        c,t,u=(r[k] for k in ('known_competitor_DATA_drops','known_target_DATA_drops','unresolved_return_drops'))
        need(all(isinstance(x,int) and x>=0 for x in (c,t,u)),'LP_BAD_COUNTS')
        need(len(r['drop_event_seqs'])==c+t+u,'LP_EVENT_COUNT_CONTRADICTION')
        need(len(set(r['drop_event_seqs']))==len(r['drop_event_seqs']),'LP_DUPLICATE_EVENT_SEQ')
        diag=r['new_return_data_diagnostic']
        if u>0: need(diag=='UNKNOWN' or diag.startswith('UNKNOWN_'),'LP_UNKNOWN_ERASED')
        elif c>0: need(diag=='OBSERVED_COMPETITOR_DATA_FRAGMENT_DROP','LP_COMP_DIAGNOSTIC')
        elif t>0: need(diag=='OBSERVED_TARGET_DATA_FRAGMENT_DROP_ONLY','LP_TARGET_DIAGNOSTIC')
        else: need(diag=='COMPLETE_WINDOW_NO_RETURN_FRAGMENT_DROP','LP_NO_DROP_DIAGNOSTIC')
        old=r['old_oracle_class'];need(old==('UNKNOWN' if arm=='RETURN_DATA' else 0),'LP_HISTORICAL_REWRITE')
        need(old==next(x['pilot_path_future_competitor_interest_drop_50ms'] for x in pw['target_rows'] if x['decision_id']==r['decision_id']),'LP_OLD_ORACLE_MISMATCH')
        ctr[diag]+=1
        out.append(dict(corpus='LP_RETURN_0420',topology=topology,slot=slot,face_id=258+slot,arm=arm,run=run,decision_id=r['decision_id'],decision_ns=r['decision_ns'],horizon_end_ns=r['horizon_end_ns'],prior_interest_oracle=old,competitor_data_fragment_drops=c,target_data_fragment_drops=t,unresolved_return_drops=u,diagnostic=diag,any_return_fragment_drop_pilot=(1 if c+t>0 else (None if u>0 else 0)),comp_data_drop_only_pilot=(1 if c>0 else (None if u>0 else 0)),is_final_F3=False))
    need(sum(ctr.values())==12,'LP_BAD_WINDOW_COUNT')
    need(dict(sorted(ctr.items()))==dict(sorted(v['windows_new_return_diagnostic'].items())),'LP_WINDOW_DIAGNOSTIC_COUNTS')
    adjacent_overlap=sum(bool(set(a['drop_event_seqs']) & set(b['drop_event_seqs'])) for a,b in zip(rows,rows[1:])) if arm=='RETURN_DATA' else 0
    return out, (o['selected_return_fragment_drop_count'],o['drop_by_class'].get('COMPETITOR_DATA',0),o['drop_by_class'].get('TARGET_DATA',0)), adjacent_overlap

def csv_bytes(rows,columns):
    sio=io.StringIO(newline='');w=csv.DictWriter(sio,fieldnames=columns,lineterminator='\n');w.writeheader();w.writerows(rows);return sio.getvalue().encode('utf8')

def audit(z):
    provenance=load_ref(z)
    path_rows=[];lp_rows=[];lp_run_counts=[];neighbor_overlap=0
    for topo in TOPOLOGIES:
        for slot in SLOTS:
            for arm in PW_ARMS:
                for run in RUNS:path_rows.extend(validate_pathwide(z,topo,slot,arm,run))
            for arm in LP_ARMS:
                for run in RUNS:
                    rows,cnt,adj=validate_lp(z,topo,slot,arm,run);lp_rows.extend(rows);lp_run_counts.append(cnt);neighbor_overlap+=adj
    need(len(path_rows)==720 and len(lp_rows)==288,'MATRIX_SIZE')
    cc=collections.Counter((r['arm'],str(r['legacy_pilot_interest_drop'])) for r in path_rows)
    need(cc[('RETURN_DATA','UNKNOWN')]==144,'PW_HISTORICAL_RETURN_UNKNOWN')
    need(sum(r['legacy_pilot_interest_drop']==1 for r in path_rows)==124,'PATHWIDE_POSITIVE_MISMATCH')
    need(sum(r['legacy_pilot_interest_drop']==0 for r in path_rows)==452,'PATHWIDE_NEGATIVE_MISMATCH')
    countlp=collections.Counter(r['diagnostic'] for r in lp_rows)
    need(countlp['COMPLETE_WINDOW_NO_RETURN_FRAGMENT_DROP']==144,'LP_OFF_COUNT')
    need(countlp['OBSERVED_COMPETITOR_DATA_FRAGMENT_DROP']==70,'LP_COMP_COUNT')
    need(countlp['OBSERVED_TARGET_DATA_FRAGMENT_DROP_ONLY']==74,'LP_TARGET_ONLY_COUNT')
    need(sum(x[0] for x in lp_run_counts)==16224,'LP_DROP_TOTAL')
    need(sum(x[1] for x in lp_run_counts)==15096 and sum(x[2] for x in lp_run_counts)==1128,'LP_CLASS_TOTAL')
    need(neighbor_overlap==118, 'LP_OVERLAP_DIAGNOSTIC')
    # Repeat fragments in overlapping windows: count only within each *run*; never treat as independent.
    observed=collections.Counter()
    for r in lp_rows:
        if r['arm']=='RETURN_DATA':
            for threshold in (1,8,16,32,64):
                if r['target_data_fragment_drops']>=threshold:observed[f'target_ge_{threshold}']+=1
                if r['competitor_data_fragment_drops']>=threshold:observed[f'competitor_ge_{threshold}']+=1
    for klass in ('competitor','target'):
        for cutoff in (1,8,16,32,64): observed.setdefault(f'{klass}_ge_{cutoff}',0)
    aggregate={
        'status': STATUS, 'stage':'1AM.F3_CANDIDATE_CONTRACT_PREFLIGHT.0','version':'0.43.0',
        'source_artifact_sha256':{k:v['sha256'] for k,v in provenance['upstream_verified_artifacts'].items()},
        'uses_previously_audited_oracles_not_raw_physical_replay':True,
        'new_ndnsim_runs':0, 'official_F3_labels':0,
        'Congestion':None, 'FutureCongestion':None, 'F3_ready':False,'GO_FREEZE':False,'training_ready':False,
        'pathwide_v0411':{'runs':60,'windows':720,'competitor_interest_drop_positive_pilot':124,'negative_pilot':452,'historical_unknown':144},
        'lp_return_v0420':{'runs':24,'windows':288,'off_no_return_fragment_drop':144,'return_competitor_and_target_drop':70,'return_target_only_drop':74,'return_any_drop':144,'adjacent_return_window_pairs_sharing_at_least_one_drop_event':neighbor_overlap,'adjacent_return_window_pairs_total':132,'total_unique_physical_fragment_drop_events_across_runs':16224,'competitor_fragment_drops':15096,'target_fragment_drops':1128,'threshold_sweep_fragment_counts_not_independent_events':dict(sorted(observed.items()))},
        'do_not_pool_or_backfill_across_different_runs':True,
        'notable_disagreement':{'target_only_drop_windows':74,'denominator_return_data_windows':144,'meaning':'competitor-only definition would omit 74 proven target-Data loss windows; not a final classification decision'},
        'why_no_F3': ['no validated construct combining queue/delay/Interest/Data under one criterion','50ms and thresholds are DEV-only, held-out not preregistered','remote physical trace is unavailable to forwarding decision','post-decision data attribution is an offline label witness only','windows and fragments overlap, not i.i.d.','forced selected face is not HCRAF behavior and unchosen face counterfactual is absent','instrumentation overhead for LP sender payload not fully assessed','missing negative adjudication when no drop but sustained queue or delay; absence-of-drop is not absence-of-congestion']
    }
    gates=[
        ('EVIDENCE_INTEGRITY','PASS','Pinned capsule SHA and per-file provenance manifests verified'),
        ('TEMPORAL_50MS','PASS_DEV_ONLY','Pre-audited oracles have identical 50ms closed-right interval'),
        ('RETURN_LP_PROVENANCE','PASS_DEV_ONLY','Previously audited complete sender LP group evidence'),
        ('CROSS_FACE_TWO_DEV_TOPOLOGIES','PASS_DEV_ONLY','Six topology x Face cells, forced selection'),
        ('POSITIVE_CLASS_CONSTRUCT','BLOCKED','Drop target vs competitor and Interest/Data conflict, no final criterion'),
        ('TRUE_NEGATIVE_CONSTRUCT','BLOCKED','No verified drop does not prove uncongested queue/delay'),
        ('HORIZON_THRESHOLD_JUSTIFICATION','BLOCKED','Single 50ms regime; threshold sweep descriptive only'),
        ('HELDOUt_GENERALIZATION','BLOCKED','Two development topologies and two correlated seeds, no independent held-out'),
        ('CENSORING_AND_UNKNOWN','BLOCKED','Need complete global and adversarial censoring contract across all regimes'),
        ('PREDICTION_FROM_ONLINE_FEATURES','BLOCKED','Remote queue not observed online; current Congestion null'),
        ('OVERHEAD_COST_AND_PERTURBATION','BLOCKED','LP sender payload instrumentation telemetry and gate cost not isolated'),
        ('F3_PR_AUC_EVALUATION','BLOCKED','Final F3 classes, grouped partitions and model predictions absent'),
        ('OFF_POLICY_UNSELECTED_FACES','BLOCKED','No causal/counterfactual support for unselected actions'),
    ]
    gate_data={'status':STATUS,'gates':[{'id':name,'status':st,'reason':reason} for name,st,reason in gates], 'approved_for_1AN_freeze':False}
    files={
        'output/contract_summary.json':jdump(aggregate),
        'output/gate_matrix.json':jdump(gate_data),
        'output/legacy_pathwide_720.csv':csv_bytes(path_rows,list(path_rows[0])),
        'output/lp_return_diagnostics_288.csv':csv_bytes(lp_rows,list(lp_rows[0])),
    }
    files['output/output_sha256.json']=jdump({k:sha(v) for k,v in sorted(files.items())})
    return files

def main():
    a=argparse.ArgumentParser();a.add_argument('--evidence',required=True);a.add_argument('--output',required=True)
    args=a.parse_args();out=pathlib.Path(args.output);out.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(args.evidence) as z:results=audit(z)
    for n,b in results.items():
        p=out/n; p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
    print(STATUS, 'output_files',len(results),'SHA',sha(results['output/contract_summary.json']))

if __name__=='__main__':main()
