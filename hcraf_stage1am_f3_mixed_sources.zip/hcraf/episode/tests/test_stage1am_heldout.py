"""Fail-closed Stage1AM held-out protocol unit/negative tests; not simulator results."""
import json,pathlib,sys,tempfile,unittest
SCRIPT=pathlib.Path(__file__).resolve().parents[1]/'scripts'
sys.path.insert(0,str(SCRIPT))
from heldout_f3_v044 import (HeldoutError,TOPOLOGIES,ARMS,selected_path,check_plan,
                            adjudicate_window,class_drop,PRIMARY_HORIZON_NS,PRIMARY_WAIT_NS)
from summarize_stage1am_heldout import ap_score,main

T=2_000_000_000

def evt(kind,t,device=(1,1),**kw):
    row={'event_type':kind,'time_ns':t,'node_id':device[0],'device_index':device[1],'queue_packets':0}
    row.update(kw);return row

class HeldoutContracts(unittest.TestCase):
    def setUp(self):
        self.paths={(0,0),(1,1),(2,1),(5,1),(8,0),(5,0),(2,0),(1,0)}
        self.reverse={(8,0),(5,0),(2,0),(1,0)}
        self.sent={'/hcraf/competitor/1':11002,'/hcraf/pilot/1':1002}
        self.known=evt('QUEUE_DROP',T+1,ndn_packet_type='INTEREST',lp_status='SINGLE_LP',
                       ndn_name='/hcraf/competitor/1',ndn_nonce=11002)
    def decide(self,items,h=PRIMARY_HORIZON_NS,w=PRIMARY_WAIT_NS,inv=None):
        return adjudicate_window(T,h,w,items,self.paths,self.reverse,inv or {},self.sent)
    def test_positive_authenticated_interest(self):self.assertEqual(self.decide([self.known])[0],1)
    def test_positive_target_interest(self):
        row=dict(self.known,ndn_name='/hcraf/pilot/1',ndn_nonce=1002)
        self.assertEqual(self.decide([row])[0],1)
    def test_no_drop_low_wait_is_control_negative(self):
        self.assertEqual(self.decide([evt('QUEUE_DEQUEUE',T+2,queue_wait_ns=1_000_000)])[0],0)
    def test_no_drop_no_dequeue_is_candidate_only_negative(self):self.assertEqual(self.decide([])[0],0)
    def test_wrong_nonce_unknown(self):
        self.assertEqual(self.decide([dict(self.known,ndn_nonce=900000)])[0],'UNKNOWN')
    def test_wrong_prefix_unknown(self):
        self.assertEqual(self.decide([dict(self.known,ndn_name='/hijack')])[0],'UNKNOWN')
    def test_missing_nonce_unknown(self):
        self.assertEqual(self.decide([dict(self.known,ndn_nonce=None)])[0],'UNKNOWN')
    def test_future_outside_50ms(self):
        self.assertEqual(self.decide([dict(self.known,time_ns=T+50_000_001)])[0],0)
    def test_future_exactly_50ms(self):
        self.assertEqual(self.decide([dict(self.known,time_ns=T+50_000_000)])[0],1)
    def test_same_decision_time_not_future(self):
        self.assertEqual(self.decide([dict(self.known,time_ns=T)])[0],0)
    def test_other_path_not_future(self):
        self.assertEqual(self.decide([dict(self.known,node_id=7,device_index=1)])[0],0)
    def test_ambiguous_drop_overrides_positive(self):
        row=dict(self.known,ndn_name='/bad')
        self.assertEqual(self.decide([self.known,row])[0],'UNKNOWN')
    def test_unknown_data_fragment(self):
        frag=evt('QUEUE_DROP',T+1,device=(8,0),lp_status='FRAGMENT',lp_group_start_seq=77)
        self.assertEqual(self.decide([frag])[0],'UNKNOWN')
    def test_authenticated_lp_data_fragment(self):
        frag=evt('QUEUE_DROP',T+1,device=(8,0),lp_status='FRAGMENT',lp_group_start_seq=77)
        inventory={(8,0,77):{'class':'TARGET_DATA'}}
        self.assertEqual(self.decide([frag],inv=inventory)[0],1)
    def test_unclassified_lp_data_fragment(self):
        frag=evt('QUEUE_DROP',T+1,device=(8,0),lp_status='FRAGMENT',lp_group_start_seq=77)
        inventory={(8,0,77):{'class':'UNKNOWN_INCOMPLETE_SENDER_GROUP'}}
        self.assertEqual(self.decide([frag],inv=inventory)[0],'UNKNOWN')
    def test_high_queue_wait_is_not_fake_zero(self):
        self.assertEqual(self.decide([evt('QUEUE_DEQUEUE',T+1,queue_wait_ns=6_000_000)])[0],'UNKNOWN')
    def test_high_queue_wait_is_not_fake_one(self):
        self.assertEqual(self.decide([evt('QUEUE_DEQUEUE',T+1,queue_wait_ns=6_000_000)])[0]!='1',True)
    def test_wait_equal_threshold_censored(self):
        self.assertEqual(self.decide([evt('QUEUE_DEQUEUE',T+1,queue_wait_ns=5_000_000)])[0],'UNKNOWN')
    def test_invalid_queue_wait_censored(self):
        self.assertEqual(self.decide([evt('QUEUE_DEQUEUE',T+1,queue_wait_ns=None)])[0],'UNKNOWN')
    def test_threshold_sensitivity_not_primary_change(self):
        row=evt('QUEUE_DEQUEUE',T+1,queue_wait_ns=4_000_000)
        self.assertEqual(self.decide([row],w=2_000_000)[0],'UNKNOWN')
        self.assertEqual(self.decide([row],w=5_000_000)[0],0)
    def test_short_horizon_protects_post_window(self):
        self.assertEqual(self.decide([dict(self.known,time_ns=T+40_000_000)],h=25_000_000)[0],0)
    def test_censored_horizon(self):
        val=adjudicate_window(19_990_000_000,50_000_000,5_000_000,[],self.paths,self.reverse,{},self.sent)
        self.assertEqual(val[0],'UNKNOWN')
    def test_unknown_horizon_rejected(self):
        with self.assertRaises(HeldoutError):self.decide([],h=31_000_000)
    def test_unknown_threshold_rejected(self):
        with self.assertRaises(HeldoutError):self.decide([],w=3_000_000)
    def test_not_interest_data_without_sender_group(self):
        self.assertEqual(class_drop(dict(self.known,ndn_packet_type='DATA'),self.sent,self.reverse,{}),'UNKNOWN')
    def test_paths_have_eight_unique_directional_devices(self):
        cfg={'topology_id':'VAL_CHAIN_C','selected_face_slot':0,'path_nodes':[0,1,2,5,8],
             'selected_mid_node_id':5,'selected_relay_node_id':2,'selected_producer_node_id':8,'selected_face_id':258}
        init={k:{'face_id':258 if k==(1,1) else 300} for k in self.paths}
        f,r=selected_path(cfg,init)
        self.assertEqual(len(f+r),8)
    def test_legacy_three_hop_rejected(self):
        cfg={'topology_id':'VAL_CHAIN_C','selected_face_slot':0,'path_nodes':[0,1,2,8],
             'selected_mid_node_id':5,'selected_relay_node_id':2,'selected_producer_node_id':8,'selected_face_id':258}
        init={k:{'face_id':258 if k==(1,1) else 300} for k in self.paths}
        with self.assertRaises(HeldoutError):selected_path(cfg,init)
    def test_val_test_disjoint_run_numbers(self):
        self.assertTrue(set(TOPOLOGIES['VAL_CHAIN_C']['runs']).isdisjoint(TOPOLOGIES['TEST_CHAIN_D']['runs']))
    def test_heldout_topos_not_dev(self):
        self.assertTrue(set(TOPOLOGIES).isdisjoint({'DEV_CHAIN_A','DEV_CHAIN_B'}))
    def test_exactly_six_arms(self):self.assertEqual(len(ARMS),6)
    def test_synthetic_AP_perfect(self):self.assertEqual(ap_score([0,1,1],[0,1,2]),1)
    def test_AP_prevalence_on_all_tied(self):self.assertAlmostEqual(ap_score([1,0,0,1],[0,0,0,0]),.5)
    def test_AP_requires_both_classes(self):self.assertIsNone(ap_score([1,1],[0,1]))
    def test_summary_fails_closed_no_runs(self):
        with tempfile.TemporaryDirectory() as td:
            result=main(td)
            self.assertFalse(result)
            j=json.loads((pathlib.Path(td)/'summary'/'summary.json').read_text())
            self.assertEqual(j['status'],'INCOMPLETE_HELDOUT_EVIDENCE')
            self.assertFalse(j['F3_ready'])
            self.assertIsNone(j['FutureCongestion'])
    def test_high_future_backlog_is_unknown(self):
        e=evt('QUEUE_ENQUEUE',T+1,queue_packets=3)
        self.assertEqual(self.decide([e])[0],'UNKNOWN')
    def test_below_backlog_threshold_still_negative(self):
        e=evt('QUEUE_ENQUEUE',T+1,queue_packets=2)
        self.assertEqual(self.decide([e])[0],0)
    def test_corrupt_backlog_negative_forbidden(self):
        e=evt('QUEUE_ENQUEUE',T+1,queue_packets=21)
        self.assertEqual(self.decide([e])[0],'UNKNOWN')
    def test_verified_drop_with_high_queue_is_candidate_positive(self):
        e=dict(self.known,queue_packets=20)
        self.assertEqual(self.decide([e])[0],1)
    def test_valid_path_rate_plan(self):
        # Literal preregistration schema; no test evidence is read.
        c={'amendment_stage':'1AM.F3_HELDOUT_FOUR_HOP_PILOT.0','collector_stage':'1AM.NFD_LOCAL_QUEUE.0',
           'topology_id':'VAL_CHAIN_C','holdout_partition':'VALIDATION','selected_face_slot':0,
           'phase_arm':'OFF_BASELINE','seed':17,'run':9721,'network_node_count':11,
           'network_directed_device_count':20,'path_nodes':[0,1,2,5,8],
           'planned_requests':12,'nominal_arrival_interval_ns':30_000_000,'interest_lifetime_ms':2600,
           'stop_ns':20_000_000_000,'queue_capacity_packets':20,'mtu_bytes':600,
           'future_oracle_horizon_ns_pilot':50_000_000,'instrument_enabled':True,
           'future_oracle_scope':'EIGHT_DIRECTED_DEVICES_FOUR_HOP_DIAGNOSTIC_WITH_CENSORING',
           'future_oracle_is_final_F3':False,'remote_queue_online_feature':False,
           'no_counterfactual_unselected_face':True,'actual_assignment_probability':1.0,
           'F3_ready':False,'training_ready':False,'future_congestion':None,'congestion':None,
           'decision_time_us_real_HCRAF':None,'competitor_planned_requests':0,
           'competitor_interval_ns':0,'competitor_offset_ns':0,'selected_forward_bps':5_000_000,
           'selected_return_bps':5_000_000,'selected_relay_forward_bps':6_000_000,
           'selected_mid_forward_bps':6_000_000,'selected_producer_reverse_bps':6_000_000,
           'eligible_face_ids':[258,259,260],'selected_face_id':258}
        check_plan(c,'VAL_CHAIN_C',0,'OFF_BASELINE',9721)
        with self.assertRaises(HeldoutError):check_plan(dict(c,run=9821),'VAL_CHAIN_C',0,'OFF_BASELINE',9821)
        with self.assertRaises(HeldoutError):check_plan(dict(c,remote_queue_online_feature=True),'VAL_CHAIN_C',0,'OFF_BASELINE',9721)
        with self.assertRaises(HeldoutError):check_plan(dict(c,future_congestion=0),'VAL_CHAIN_C',0,'OFF_BASELINE',9721)
        with self.assertRaises(HeldoutError):check_plan(dict(c,selected_mid_forward_bps=50_000),'VAL_CHAIN_C',0,'OFF_BASELINE',9721)
        with self.assertRaises(HeldoutError):check_plan(dict(c,holdout_partition='TEST'),'VAL_CHAIN_C',0,'OFF_BASELINE',9721)
        with self.assertRaises(HeldoutError):check_plan(dict(c,path_nodes=[0,1,2,8]),'VAL_CHAIN_C',0,'OFF_BASELINE',9721)
    def test_source_does_not_claim_gate_cost(self):
        src=(SCRIPT.parent/'src'/'hcraf-stage1am-heldout-pilot.cpp').read_text()
        self.assertIn('is_HCRAF_Gate_only_cost',src)
    def test_cpp_registers_new_mid_forward(self):
        src=(SCRIPT.parent/'src'/'hcraf-stage1am-heldout-pilot.cpp').read_text()
        self.assertIn('pathArm=="MID_FORWARD"',src)
    def test_cpp_builds_11_nodes(self):
        src=(SCRIPT.parent/'src'/'hcraf-stage1am-heldout-pilot.cpp').read_text()
        self.assertIn('nodes.Create(11u)',src)

if __name__=='__main__':unittest.main()
