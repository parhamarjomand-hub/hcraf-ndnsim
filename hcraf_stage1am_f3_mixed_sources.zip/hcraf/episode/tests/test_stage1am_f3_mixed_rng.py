"""Stage1AM v0.47 preregistered contracts. Synthetic tests do not prove real congestion."""
import json,pathlib,sys,tempfile,unittest
S=pathlib.Path(__file__).resolve().parents[1]/'scripts'
sys.path.insert(0,str(S))
from f3_mixed_rng_v047 import (TOPOLOGIES,ARMS,CONTROL_ARMS,PRESSURE_ARMS,STATUS,
    HeldoutError,check_plan,inspect_competitor_pulses,adjudicate_window,PRIMARY_HORIZON_NS,PRIMARY_WAIT_NS)
from seal_stage1am_f3_mixed_validation import seal
from summarize_stage1am_f3_mixed import main

T=2_030_000_000
PATH={(0,0),(1,1),(2,1),(5,1),(10,0),(5,0),(2,0),(1,0)}
RETURN={(10,0),(5,0),(2,0),(1,0)}
SENT={'/hcraf/pilot/0':1001,'/hcraf/competitor/0':11001}

class MixedRngContracts(unittest.TestCase):
    def scenario(self,arm='MIXED_LOCAL',topology='VAL_CHAIN_I',run=11221,slot=0):
        spec=TOPOLOGIES[topology];relay=2+slot;mid=spec['mid'][slot];prod=spec['producer'][slot]
        rate=50_000_000;nc=0 if arm=='QUIET_CLEAN' else 96
        return {'amendment_stage':'1AM.F3_MIXED_RNG_PRESSURE_FOUR_HOP.0',
          'collector_stage':'1AM.NFD_LOCAL_QUEUE.0','topology_id':topology,
          'holdout_partition':spec['partition'],'selected_face_slot':slot,'phase_arm':arm,
          'run':run,'seed':17,'path_nodes':[0,1,relay,mid,prod],
          'selected_mid_node_id':mid,'selected_relay_node_id':relay,'selected_producer_node_id':prod,
          'network_node_count':11,'network_directed_device_count':20,
          'planned_requests':12,'nominal_arrival_interval_ns':30_000_000,
          'interest_lifetime_ms':2600,'stop_ns':20_000_000_000,
          'queue_capacity_packets':20,'mtu_bytes':600,'future_oracle_horizon_ns_pilot':50_000_000,
          'instrument_enabled':True,
          'future_oracle_scope':'EIGHT_DEVICES_FOUR_HOP_FRAGMENT_AWARE_WITH_CENSORING',
          'future_oracle_is_final_F3':False,'remote_queue_online_feature':False,
          'no_counterfactual_unselected_face':True,'actual_assignment_probability':1.0,
          'F3_ready':False,'training_ready':False,
          'future_congestion':None,'congestion':None,'decision_time_us_real_HCRAF':None,
          'competitor_planned_requests':nc,
          'competitor_interval_ns':0 if nc==0 else 2_000_000,
          'competitor_offset_ns':0,
          'selected_forward_bps':120_000 if arm=='MIXED_LOCAL' else rate,
          'selected_return_bps':rate,
          'selected_relay_forward_bps':120_000 if arm=='MIXED_RELAY' else rate,
          'selected_mid_forward_bps':120_000 if arm=='MIXED_MID' else rate,
          'selected_producer_reverse_bps':6_000_000 if arm=='MIXED_RETURN' else rate,
          'competitor_pulse_schedule':'TWO_BURSTS_48_EACH_2MS_WITH_RNG_START_0_300MS',
          'competitor_burst_start_rng_stream':139,'competitor_burst_gap_ns':49_000_000,
          'competitor_pulse_count':0 if nc==0 else 2,
          'selected_face_id':259+slot,'eligible_face_ids':[259,260,261]}
    def event(self,t,kind='QUEUE_DEQUEUE',**kw):
        obj={'event_type':kind,'node_id':1,'device_index':1,'time_ns':t,
             'queue_packets':0,'queue_bytes':0,'queue_wait_ns':0}
        obj.update(kw);return obj
    def write_schedule(self,root,start=100_000_000):
        arrivals=[];sends=[]
        for i in range(96):
            jitter=i%7;time=2_000_000_000+start+(i//48)*145_000_000+(i%48)*2_000_000+jitter
            arrivals.append({'sequence':i,'time_ns':time,'jitter_ns':jitter,'pulse_start_ns':start,
                             'burst_index':i//48,'stream':139,'traffic_class':'INDEPENDENT_COMPETITOR'})
            sends.append({'event':'SEND','name':f'/hcraf/competitor/{i}','time_ns':time,'nonce':11001+i})
        for file,arr in [('competitor_events.jsonl.arrivals.jsonl',arrivals),('competitor_events.jsonl',sends)]:
            (root/file).write_text(''.join(json.dumps(x)+'\n' for x in arr))
        return arrivals,sends
    def test_registered_topologies(self):
        self.assertEqual(set(TOPOLOGIES),{'VAL_CHAIN_I','TEST_CHAIN_J'})
        self.assertTrue(set(TOPOLOGIES).isdisjoint({'VAL_CHAIN_G','TEST_CHAIN_H','VAL_CHAIN_E','TEST_CHAIN_F'}))
    def test_new_rng_runs_disjoint(self):
        a=set(TOPOLOGIES['VAL_CHAIN_I']['runs']);b=set(TOPOLOGIES['TEST_CHAIN_J']['runs'])
        self.assertEqual(len(a),6);self.assertEqual(len(b),6);self.assertTrue(a.isdisjoint(b))
        self.assertTrue((a|b).isdisjoint({10021,10022,10023,10024,10121,10122,10123,10124}))
    def test_five_arms(self):self.assertEqual(len(ARMS),5)
    def test_four_pressure_arms_same_offered_load(self):self.assertEqual(len(PRESSURE_ARMS),4)
    def test_only_one_quiet_control(self):self.assertEqual(CONTROL_ARMS,('QUIET_CLEAN',))
    def test_expected_360_simulations(self):self.assertEqual(2*3*5*6*2,360)
    def test_window_count_2160(self):self.assertEqual(2*3*5*6*12,2160)
    def test_plan_for_every_registered_cell(self):
        for topo,spec in TOPOLOGIES.items():
            for arm in ARMS:
                c=self.scenario(arm,topo,spec['runs'][0],2)
                check_plan(c,topo,2,arm,spec['runs'][0])
    def test_bad_seed_rejected(self):
        c=self.scenario();c['run']=10121
        with self.assertRaises(HeldoutError):check_plan(c,'VAL_CHAIN_I',0,'MIXED_LOCAL',10121)
    def test_test_run_cannot_enter_validation(self):
        with self.assertRaises(HeldoutError):check_plan(self.scenario(),'TEST_CHAIN_J',0,'MIXED_LOCAL',11321)
    def test_offered_load_tamper_rejected(self):
        c=self.scenario();c['competitor_planned_requests']=95
        with self.assertRaises(HeldoutError):check_plan(c,'VAL_CHAIN_I',0,'MIXED_LOCAL',11221)
    def test_rate_tamper_rejected(self):
        c=self.scenario();c['selected_forward_bps']=50_000_000
        with self.assertRaises(HeldoutError):check_plan(c,'VAL_CHAIN_I',0,'MIXED_LOCAL',11221)
    def test_receiver_link_tamper_rejected(self):
        c=self.scenario('MIXED_RETURN');c['selected_producer_reverse_bps']=1
        with self.assertRaises(HeldoutError):check_plan(c,'VAL_CHAIN_I',0,'MIXED_RETURN',11221)
    def test_pulse_gap_tamper_rejected(self):
        c=self.scenario();c['competitor_burst_gap_ns']=1
        with self.assertRaises(HeldoutError):check_plan(c,'VAL_CHAIN_I',0,'MIXED_LOCAL',11221)
    def test_future_label_field_must_be_null(self):
        c=self.scenario();c['future_congestion']=0
        with self.assertRaises(HeldoutError):check_plan(c,'VAL_CHAIN_I',0,'MIXED_LOCAL',11221)
    def test_readiness_false(self):
        c=self.scenario();c['F3_ready']=True
        with self.assertRaises(HeldoutError):check_plan(c,'VAL_CHAIN_I',0,'MIXED_LOCAL',11221)
    def test_congestion_online_remote_false(self):
        c=self.scenario();c['remote_queue_online_feature']=True
        with self.assertRaises(HeldoutError):check_plan(c,'VAL_CHAIN_I',0,'MIXED_LOCAL',11221)
    def test_valid_pulses(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);self.write_schedule(root)
            self.assertEqual(inspect_competitor_pulses(root,'MIXED_LOCAL'),100_000_000)
    def test_pulse_start_max(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);self.write_schedule(root,300_000_000)
            self.assertEqual(inspect_competitor_pulses(root,'MIXED_RELAY'),300_000_000)
    def test_pulse_start_negative_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);self.write_schedule(root,-1)
            with self.assertRaises(HeldoutError):inspect_competitor_pulses(root,'MIXED_LOCAL')
    def test_pulse_start_too_late_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);self.write_schedule(root,300_000_001)
            with self.assertRaises(HeldoutError):inspect_competitor_pulses(root,'MIXED_LOCAL')
    def test_burst_index_modified_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);a,b=self.write_schedule(root);a[48]['burst_index']=0
            (root/'competitor_events.jsonl.arrivals.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in a))
            with self.assertRaises(HeldoutError):inspect_competitor_pulses(root,'MIXED_LOCAL')
    def test_wrong_send_time_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);a,b=self.write_schedule(root);b[50]['time_ns']+=1
            (root/'competitor_events.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in b))
            with self.assertRaises(HeldoutError):inspect_competitor_pulses(root,'MIXED_LOCAL')
    def test_wrong_competitor_name_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);a,b=self.write_schedule(root);b[80]['name']='/hcraf/pilot/80'
            (root/'competitor_events.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in b))
            with self.assertRaises(HeldoutError):inspect_competitor_pulses(root,'MIXED_LOCAL')
    def test_missing_pulse_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);a,b=self.write_schedule(root);a.pop()
            (root/'competitor_events.jsonl.arrivals.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in a))
            with self.assertRaises(HeldoutError):inspect_competitor_pulses(root,'MIXED_LOCAL')
    def test_quiet_no_competitor(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertIsNone(inspect_competitor_pulses(pathlib.Path(d),'QUIET_CLEAN'))
    def test_quiet_with_competitor_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);self.write_schedule(root)
            with self.assertRaises(HeldoutError):inspect_competitor_pulses(root,'QUIET_CLEAN')
    def test_short_wait_no_drop_negative_candidate(self):
        self.assertEqual(adjudicate_window(T,PRIMARY_HORIZON_NS,PRIMARY_WAIT_NS,
            [self.event(T+1,queue_wait_ns=1_000_000)],PATH,RETURN,{},SENT)[0],0)
    def test_high_wait_no_drop_unknown(self):
        self.assertEqual(adjudicate_window(T,PRIMARY_HORIZON_NS,PRIMARY_WAIT_NS,
            [self.event(T+1,queue_wait_ns=6_000_000)],PATH,RETURN,{},SENT)[0],'UNKNOWN')
    def test_target_drop_positive_candidate(self):
        x=self.event(T+1,'QUEUE_DROP',ndn_packet_type='INTEREST',lp_status='SINGLE_LP',
                     ndn_name='/hcraf/pilot/0',ndn_nonce=1001)
        self.assertEqual(adjudicate_window(T,PRIMARY_HORIZON_NS,PRIMARY_WAIT_NS,
            [x],PATH,RETURN,{},SENT)[0],1)
    def test_bad_drop_unknown_even_with_positive(self):
        x=self.event(T+1,'QUEUE_DROP',ndn_packet_type='INTEREST',lp_status='SINGLE_LP',
                     ndn_name='/hcraf/pilot/0',ndn_nonce=1001)
        self.assertEqual(adjudicate_window(T,PRIMARY_HORIZON_NS,PRIMARY_WAIT_NS,
            [x,self.event(T+2,'QUEUE_DROP')],PATH,RETURN,{},SENT)[0],'UNKNOWN')
    def test_stale_drop_outside_future(self):
        x=self.event(T-1,'QUEUE_DROP',ndn_packet_type='INTEREST',lp_status='SINGLE_LP',
                     ndn_name='/hcraf/pilot/0',ndn_nonce=1001)
        self.assertEqual(adjudicate_window(T,PRIMARY_HORIZON_NS,PRIMARY_WAIT_NS,
            [x],PATH,RETURN,{},SENT)[0],0)
    def test_future_drop_outside_horizon(self):
        x=self.event(T+PRIMARY_HORIZON_NS+1,'QUEUE_DROP',ndn_packet_type='INTEREST',lp_status='SINGLE_LP',
                     ndn_name='/hcraf/pilot/0',ndn_nonce=1001)
        self.assertEqual(adjudicate_window(T,PRIMARY_HORIZON_NS,PRIMARY_WAIT_NS,
            [x],PATH,RETURN,{},SENT)[0],0)
    def test_cpp_uses_2_bursts_and_ns3_rng(self):
        cpp=(S.parent/'src/hcraf-stage1am-f3-mixed-pilot.cpp').read_text()
        for v in ('SetStream(m_stream)','pulse_start_ns','burst_index','GetInteger(0, 300000000u)',
                  'MIXED_RETURN','VAL_CHAIN_I','TEST_CHAIN_J'):
            self.assertIn(v,cpp)
    def test_build_pinned_source_not_modified(self):
        self.assertTrue((S/'f3_fragment_aware_v046.py').exists())
        self.assertTrue((S.parent/'src/hcraf-stage1am-f3-fragment-aware-pilot.cpp').exists())
    def test_run_script_seals_before_test(self):
        txt=(S/'run_stage1am_f3_mixed.sh').read_text()
        self.assertIn('for topology in VAL_CHAIN_I TEST_CHAIN_J',txt)
        self.assertIn('seal_stage1am_f3_mixed_validation.py',txt)
        self.assertIn('NEW_VALIDATION_NOT_SEALED_TEST_MUST_NOT_OPEN',txt)
    def test_seal_must_reject_early_test_dir(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);(root/'TEST_CHAIN_J').mkdir()
            with self.assertRaises(HeldoutError):seal(root)
    def test_empty_summary_must_no_go(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertFalse(main(d))
            x=json.loads((pathlib.Path(d)/'summary'/'summary.json').read_text())
            self.assertEqual(x['status'],'INCOMPLETE_F3_MIXED_RNG_AND_SAME_LOAD_EVIDENCE')
            self.assertFalse(x['GO_FREEZE']);self.assertFalse(x['F3_ready'])
            self.assertIsNone(x['FutureCongestion'])
    def test_20_device_nononline_remote(self):
        txt=(S/'f3_mixed_rng_v047.py').read_text()
        self.assertIn('remote_node_queue_accessed',txt)
        self.assertIn('MISSING_OR_REORDERED_PHYSICAL_EVENTS',txt)
    def test_partitions_rename_and_are_disjoint(self):
        self.assertEqual({v['partition'] for v in TOPOLOGIES.values()},{'VALIDATION','TEST'})

if __name__=='__main__':unittest.main()
