// Standalone C++11 regression for the actual Stage1AM producer nonce rendering.
// Live ndn-cxx compilation is only possible in the GitHub ndnSIM build.
#include <cassert>
#include <cstdint>
#include <iomanip>
#include <sstream>
#include <stdexcept>
#include <string>
#include <iostream>

uint32_t toDecimal(const std::string& nonceHex) {
  if (nonceHex.size()!=8 ||
      nonceHex.find_first_not_of("0123456789abcdefABCDEF") != std::string::npos)
    throw std::runtime_error("Producer receipt Nonce is not eight hex digits");
  return static_cast<uint32_t>(std::stoul(nonceHex, nullptr, 16));
}
int main() {
  assert(toDecimal("00002af9") == 11001u);
  assert(toDecimal("FFFFFFFF") == UINT32_MAX);
  assert(toDecimal("00000000") == 0u);
  for (const std::string bad : {"0002af9", "00002ag9", "00002af9garbage"}) {
    try { (void)toDecimal(bad); return 2; }
    catch (const std::runtime_error&) {}
  }
  std::ostringstream out;
  out << "{\"nonce\":" << toDecimal("00002af9") << "}";
  if (out.str() != "{\"nonce\":11001}") return 3;
  std::cout << "PASS_STAGE1AM_PRODUCER_NONCE_CXX11" << std::endl;
  return 0;
}
