"""Stage 1AM v0.45 fresh E/F coverage contracts; synthetic tests are not experimental evidence."""
import json,pathlib,sys,tempfile,unittest
S=pathlib.Path(__file__).resolve().parents[1]/'scripts'
sys.path.insert(0,str(S))
from f3_coverage_v045 import (TOPOLOGIES,ARMS,CONTROL_ARMS,PRESSURE_ARMS,STATUS,need,
    HeldoutError,check_plan,selected_path,adjudicate_window,class_drop,PRIMARY_HORIZON_NS,PRIMARY_WAIT_NS)
from summarize_stage1am_f3_coverage import (main,ap_score,target_outcomes,paired_completion_rows)

T=2_030_000_000

def cfg(topology='VAL_CHAIN_E',slot=0,arm='QUIET_CLEAN',run=9921,monitored=True):
    spec=TOPOLOGIES[topology]
    nc=0 if arm=='QUIET_CLEAN' else 24 if arm=='SPARSE_CLEAN' else 160
    return {'amendment_stage':'1AM.F3_COVERAGE_REMEDIATION_FOUR_HOP.0',
      'collector_stage':'1AM.NFD_LOCAL_QUEUE.0','topology_id':topology,
      'holdout_partition':spec['partition'],'selected_face_slot':slot,'phase_arm':arm,
      'seed':17,'run':run,'network_node_count':11,'network_directed_device_count':20,
      'path_nodes':[0,1,2+slot,spec['mid'][slot],spec['producer'][slot]],
      'planned_requests':12,'nominal_arrival_interval_ns':30_000_000,
      'interest_lifetime_ms':2600,'stop_ns':20_000_000_000,'queue_capacity_packets':20,
      'mtu_bytes':600,'future_oracle_horizon_ns_pilot':50_000_000,
      'instrument_enabled':monitored,
      'future_oracle_scope':'EIGHT_DEVICES_FOUR_HOP_COVERAGE_REMEDIATION_WITH_CENSORING',
      'future_oracle_is_final_F3':False,'remote_queue_online_feature':False,
      'no_counterfactual_unselected_face':True,'actual_assignment_probability':1.0,
      'F3_ready':False,'training_ready':False,'future_congestion':None,'congestion':None,
      'decision_time_us_real_HCRAF':None,'competitor_planned_requests':nc,
      'competitor_interval_ns':0 if nc==0 else 50_000_000 if arm=='SPARSE_CLEAN' else 1_000_000,
      'competitor_offset_ns':900_000_000 if arm=='LATE_CLEAN' else 0,
      'selected_forward_bps':50_000 if arm=='LOCAL_OVERFLOW' else 50_000_000,
      'selected_return_bps':50_000_000,
      'selected_relay_forward_bps':50_000 if arm=='RELAY_OVERFLOW' else spec['rate'],
      'selected_mid_forward_bps':50_000 if arm=='MID_OVERFLOW' else spec['rate'],
      'selected_producer_reverse_bps':50_000 if arm=='RETURN_OVERFLOW' else spec['rate'],
      'eligible_face_ids':[258,259,260],'selected_face_id':[258,259,260][slot],
      'selected_mid_node_id':spec['mid'][slot], 'selected_relay_node_id':2+slot,
      'selected_producer_node_id':spec['producer'][slot]}

def event(kind,dt,dev=(1,1),**kw):
    z={'event_type':kind,'time_ns':T+dt,'node_id':dev[0],'device_index':dev[1],
       'queue_packets':0};z.update(kw);return z

class F3CoverageProtocol(unittest.TestCase):
    def setUp(self):
        self.forward={(0,0),(1,1),(2,1),(6,1)}
        self.reverse={(9,0),(6,0),(2,0),(1,0)}
        self.paths=self.forward|self.reverse
        self.sent={'/hcraf/pilot/0':1001,'/hcraf/competitor/0':11001}
        self.drop=event('QUEUE_DROP',10_000_000,ndn_packet_type='INTEREST',lp_status='SINGLE_LP',
                        ndn_name='/hcraf/competitor/0',ndn_nonce=11001)
    def verdict(self,events,h=50_000_000,w=5_000_000,inv=None):
        return adjudicate_window(T,h,w,events,self.paths,self.reverse,inv or {},self.sent)[0]
    def test_two_new_topologies_not_seen_old(self):
        self.assertEqual(set(TOPOLOGIES),{'VAL_CHAIN_E','TEST_CHAIN_F'})
        self.assertTrue(set(TOPOLOGIES).isdisjoint({'VAL_CHAIN_C','TEST_CHAIN_D','DEV_CHAIN_A','DEV_CHAIN_B'}))
    def test_four_new_independent_runs_each(self):
        self.assertEqual([len(x['runs']) for x in TOPOLOGIES.values()],[4,4])
        self.assertTrue(set(TOPOLOGIES['VAL_CHAIN_E']['runs']).isdisjoint(TOPOLOGIES['TEST_CHAIN_F']['runs']))
    def test_not_old_rng_runs(self):
        self.assertTrue(all(set(x['runs']).isdisjoint({9721,9722,9821,9822,9101,9102,9103}) for x in TOPOLOGIES.values()))
    def test_seven_predefined_arms(self):self.assertEqual(len(ARMS),7)
    def test_three_clean_controls(self):self.assertEqual(len(CONTROL_ARMS),3)
    def test_four_pressure_interventions(self):self.assertEqual(len(PRESSURE_ARMS),4)
    def test_arms_exhaustive_and_disjoint(self):self.assertEqual(set(ARMS),set(CONTROL_ARMS)|set(PRESSURE_ARMS))
    def test_full_matrix_count(self):self.assertEqual(2*3*7*4*2,336)
    def test_total_target_windows(self):self.assertEqual(2*3*7*4*12,2016)
    def test_all_new_cells_pass_config_contract(self):
        for topo,spec in TOPOLOGIES.items():
            for slot in range(3):
                for arm in ARMS:
                    for run in spec['runs']:
                        check_plan(cfg(topo,slot,arm,run),topo,slot,arm,run)
    def test_reject_tampered_run_partition(self):
        c=cfg();c['run']=9981
        with self.assertRaises(HeldoutError):check_plan(c,'VAL_CHAIN_E',0,'QUIET_CLEAN',9981)
    def test_reject_old_topology(self):
        c=cfg();c['topology_id']='VAL_CHAIN_C'
        with self.assertRaises(HeldoutError):check_plan(c,'VAL_CHAIN_C',0,'QUIET_CLEAN',9921)
    def test_reject_target_interval_change(self):
        c=cfg();c['nominal_arrival_interval_ns']=40_000_000
        with self.assertRaises(HeldoutError):check_plan(c,'VAL_CHAIN_E',0,'QUIET_CLEAN',9921)
    def test_reject_positive_promotion(self):
        c=cfg();c['F3_ready']=True
        with self.assertRaises(HeldoutError):check_plan(c,'VAL_CHAIN_E',0,'QUIET_CLEAN',9921)
    def test_reject_final_future_label(self):
        c=cfg();c['future_congestion']=0
        with self.assertRaises(HeldoutError):check_plan(c,'VAL_CHAIN_E',0,'QUIET_CLEAN',9921)
    def test_reject_remote_online_telemetry(self):
        c=cfg();c['remote_queue_online_feature']=True
        with self.assertRaises(HeldoutError):check_plan(c,'VAL_CHAIN_E',0,'QUIET_CLEAN',9921)
    def test_reject_misdeclared_forward_bottleneck(self):
        c=cfg(arm='LOCAL_OVERFLOW');c['selected_forward_bps']=50_000_000
        with self.assertRaises(HeldoutError):check_plan(c,'VAL_CHAIN_E',0,'LOCAL_OVERFLOW',9921)
    def test_reject_spurious_sparse_count(self):
        c=cfg(arm='SPARSE_CLEAN');c['competitor_planned_requests']=160
        with self.assertRaises(HeldoutError):check_plan(c,'VAL_CHAIN_E',0,'SPARSE_CLEAN',9921)
    def test_reject_spurious_sparse_interval(self):
        c=cfg(arm='SPARSE_CLEAN');c['competitor_interval_ns']=1_000_000
        with self.assertRaises(HeldoutError):check_plan(c,'VAL_CHAIN_E',0,'SPARSE_CLEAN',9921)
    def test_reject_late_competitor_overlap(self):
        c=cfg(arm='LATE_CLEAN');c['competitor_offset_ns']=0
        with self.assertRaises(HeldoutError):check_plan(c,'VAL_CHAIN_E',0,'LATE_CLEAN',9921)
    def test_reject_wrong_return_capacity(self):
        c=cfg();c['selected_return_bps']=5_000_000
        with self.assertRaises(HeldoutError):check_plan(c,'VAL_CHAIN_E',0,'QUIET_CLEAN',9921)
    def test_reject_unmonitored_claim(self):
        c=cfg(monitored=False)
        with self.assertRaises(HeldoutError):check_plan(c,'VAL_CHAIN_E',0,'QUIET_CLEAN',9921)
    def test_two_different_new_topology_routes(self):
        self.assertNotEqual(TOPOLOGIES['VAL_CHAIN_E']['mid'],TOPOLOGIES['TEST_CHAIN_F']['mid'])
    def test_all_six_physical_paths_unique(self):
        for topo,spec in TOPOLOGIES.items():
            for slot in range(3):
                c=cfg(topo,slot,run=spec['runs'][0]);keys={(0,0),(1,slot+1),(2+slot,1),
                       (spec['mid'][slot],1),(spec['producer'][slot],0),
                       (spec['mid'][slot],0),(2+slot,0),(1,0)}
                inits={k:{'face_id':c['selected_face_id'] if k==(1,slot+1) else 300} for k in keys}
                f,r=selected_path(c,inits)
                self.assertEqual(set(f+r),keys)
    def test_authenticated_interest_drop_positive(self):self.assertEqual(self.verdict([self.drop]),1)
    def test_high_wait_not_negative(self):
        self.assertEqual(self.verdict([event('QUEUE_DEQUEUE',5,queue_wait_ns=6_000_000)]),'UNKNOWN')
    def test_high_backlog_not_negative(self):
        self.assertEqual(self.verdict([event('QUEUE_ENQUEUE',5,queue_packets=3)]),'UNKNOWN')
    def test_ambiguous_drop_overrides_positive(self):
        self.assertEqual(self.verdict([self.drop,dict(self.drop,ndn_name='/other')]),'UNKNOWN')
    def test_missing_fragment_group_unknown(self):
        x=event('QUEUE_DROP',2,dev=(9,0),lp_status='FRAGMENT',lp_group_start_seq=1)
        self.assertEqual(self.verdict([x]),'UNKNOWN')
    def test_complete_fragment_authenticated_positive(self):
        x=event('QUEUE_DROP',2,dev=(9,0),lp_status='FRAGMENT',lp_group_start_seq=1)
        self.assertEqual(self.verdict([x],inv={(9,0,1):{'class':'TARGET_DATA'}}),1)
    def test_exact_horizon_inclusive(self):
        self.assertEqual(self.verdict([dict(self.drop,time_ns=T+50_000_000)]),1)
    def test_outside_horizon_not_positive(self):
        self.assertEqual(self.verdict([dict(self.drop,time_ns=T+50_000_001)]),0)
    def test_before_decision_not_future(self):
        self.assertEqual(self.verdict([dict(self.drop,time_ns=T)]),0)
    def test_low_wait_genuine_candidate_zero(self):
        self.assertEqual(self.verdict([event('QUEUE_DEQUEUE',5,queue_wait_ns=500_000)]),0)
    def test_no_drop_no_wait_is_candidate_not_final(self):self.assertEqual(self.verdict([]),0)
    def test_positive_drop_different_physical_device_not_counted(self):
        self.assertEqual(self.verdict([dict(self.drop,node_id=4,device_index=2)]),0)
    def test_null_final_labels_in_empty_summary(self):
        with tempfile.TemporaryDirectory() as td:
            self.assertFalse(main(td))
            z=json.loads((pathlib.Path(td)/'summary'/'summary.json').read_text())
            self.assertFalse(z['GO_FREEZE']);self.assertIsNone(z['FutureCongestion'])
            self.assertEqual(z['status'],'INCOMPLETE_F3_COVERAGE_REMEDIATION_EVIDENCE')
    def test_scenario_has_fresh_real_four_hop(self):
        s=(S.parent/'src'/'hcraf-stage1am-f3-coverage-pilot.cpp').read_text()
        self.assertIn('nodes.Create(11u)',s)
        self.assertIn('new independent',s.lower())
    def test_scenario_no_change_to_gate(self):
        s=(S.parent/'src'/'hcraf-stage1am-f3-coverage-pilot.cpp').read_text()
        self.assertIn('is_HCRAF_Gate_only_cost',s)
    def test_scenario_high_capacity_entry_link(self):
        s=(S.parent/'src'/'hcraf-stage1am-f3-coverage-pilot.cpp').read_text()
        self.assertIn('StringValue("50Mbps")',s)
    def test_ap_tied_all_prevalence(self):self.assertAlmostEqual(ap_score([0,1,1,0],[0,0,0,0]),.5)
    def test_ap_no_false_class_promoted(self):self.assertIsNone(ap_score([1,1,1],[0,0,1]))
    def test_target_outcomes_protects_missing_as_unknown(self):
        with tempfile.TemporaryDirectory() as td:
            d=pathlib.Path(td)
            events=[{'event':'SEND','time_ns':T+i*30_000_000,'name':f'/hcraf/pilot/{i}'} for i in range(12)]
            events.append({'event':'DATA','time_ns':T+120_000_000,'name':'/hcraf/pilot/0'})
            (d/'consumer_events.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in events))
            x=target_outcomes(d)
            self.assertEqual(x['/hcraf/pilot/0'],120_000_000)
            self.assertIsNone(x['/hcraf/pilot/1'])
    def test_target_outcomes_rejects_duplicate_sends(self):
        with tempfile.TemporaryDirectory() as td:
            d=pathlib.Path(td)
            events=[{'event':'SEND','time_ns':T,'name':'/hcraf/pilot/0'}]*2
            (d/'consumer_events.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in events))
            with self.assertRaises(HeldoutError):target_outcomes(d)

if __name__=='__main__':unittest.main()
