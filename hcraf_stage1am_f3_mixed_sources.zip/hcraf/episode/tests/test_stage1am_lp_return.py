"""Stage 1AM v0.42 group-aware return DropTail physical attribution contracts."""
import copy
import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from oracle_stage1am_lp_return import (
    parse_network_data, parse_evidence_fragment, group_inventory, oracle_group,
    GroupEvidenceError, MAX_NS, UINT64
)

def vn(n):
    return bytes((n,)) if n < 253 else b'\xfd' + n.to_bytes(2,'big')

def tlv(t,v):
    return vn(t)+vn(len(v))+v

def make_data(name):
    named=b''.join(tlv(8,c.encode()) for c in name.split('/')[1:])
    return tlv(6,tlv(7,named)+tlv(20,tlv(25,b'\x03\xe8'))+tlv(21,b'\x00'*4096)+tlv(22,tlv(27,b'\xff'))+tlv(23,b'\x00'))

class LPReturnTests(unittest.TestCase):
    def setUp(self):
        self.path=[(0,0),(1,1),(2,1),(5,0),(2,0),(1,0)]
        self.devices=self.path+[(20+i,0) for i in range(8)]
        self.cfg={'topology_id':'DEV_CHAIN_A','selected_face_slot':0,
                  'selected_face_id':258,'selected_ingress_face_id':257,
                  'path_nodes':[0,1,2,5], 'future_oracle_horizon_ns_pilot':50_000_000,
                  'future_oracle_is_final_F3':False,'remote_queue_online_feature':False,
                  'F3_ready':False,'training_ready':False,'congestion':None,'future_congestion':None}
        self.decisions=[{'decision_id':i+1,'name':f'/hcraf/pilot/{i}',
                         'pit_instance_id':str(i+1),'time_ns':2_000_000_000+i*30_000_000}
                        for i in range(12)]
        self.old=[{'decision_id':i+1,'pilot_path_future_competitor_interest_drop_50ms':'UNKNOWN',
                   'oracle_reason':'UNKNOWN_UNCLASSIFIABLE_DROP_ON_SELECTED_PATH'} for i in range(12)]
        self.name='/hcraf/competitor/0'
        self.receipts=[{'name':self.name,'nonce':11001,'time_ns':2_010_000_000}]
        self.ev=[{'event_type':'INITIAL','link_event_seq':i+1,'time_ns':0,
                  'node_id':a,'device_index':b,
                  'face_id':258 if (a,b)==(1,1) else 257} for i,(a,b) in enumerate(self.devices)]

    def add_group(self,name=None,drop_idx=1,missing_idx=None,start=UINT64-2,
                  dev=(5,0), time_ns=2_025_000_000):
        data=make_data(name or self.name)
        parts=[data[i:i+550] for i in range(0,len(data),550)]
        for i,part in enumerate(parts):
            if i==missing_idx:
                continue
            self.ev.append({'event_type':'QUEUE_DROP' if i==drop_idx else 'QUEUE_ENQUEUE',
                'link_event_seq':len(self.ev)+1,'time_ns':time_ns+i,
                'node_id':dev[0],'device_index':dev[1],
                'lp_status':'FRAGMENT','lp_frag_count':len(parts),
                'lp_frag_index':i,'lp_seq':(start+i)%UINT64,
                'lp_group_start_seq':start,'lp_fragment_hex':part.hex()})
        return parts

    def finalized(self):
        records=copy.deepcopy(self.ev)
        for a,b in self.devices:
            records.append({'event_type':'FINAL','link_event_seq':len(records)+1,
              'time_ns':MAX_NS,'node_id':a,'device_index':b,'face_id':258 if (a,b)==(1,1) else 257})
        return records

    def oracle(self):
        return oracle_group(self.cfg,self.decisions,self.finalized(),self.receipts,self.old)

    def test_parse_valid_data(self):
        self.assertEqual(parse_network_data(make_data(self.name))[0],self.name)

    def test_parse_invalid_not_data(self):
        self.assertIsNone(parse_network_data(tlv(5,tlv(7,tlv(8,b'x'))))[0])

    def test_parse_truncated(self):
        self.assertIsNone(parse_network_data(make_data(self.name)[:-1])[0])

    def test_parse_unsupported_name(self):
        self.assertIsNone(parse_network_data(tlv(6,tlv(7,tlv(9,b'x'))))[0])

    def test_parse_duplicate_names(self):
        val=tlv(7,tlv(8,b'x'))
        self.assertIsNone(parse_network_data(tlv(6,val+val))[0])

    def test_parse_name_with_pct(self):
        self.assertEqual(parse_network_data(make_data('/hcraf/competitor/%'))[0],'/hcraf/competitor/%25')

    def test_sender_group_competitor_data(self):
        self.add_group()
        x=self.oracle()
        self.assertEqual(x['selected_return_fragment_drop_count'],1)
        self.assertEqual(x['drop_by_class']['COMPETITOR_DATA'],1)
        self.assertEqual(x['target_windows'][0]['new_return_data_diagnostic'],
                         'OBSERVED_COMPETITOR_DATA_FRAGMENT_DROP')
        self.assertTrue(all(r['FutureCongestion'] is None for r in x['target_windows']))

    def test_sender_group_wraparound(self):
        self.add_group(start=UINT64-1)
        self.assertEqual(self.oracle()['drop_by_class']['COMPETITOR_DATA'],1)

    def test_group_missing_index_unknown(self):
        self.add_group(missing_idx=0)
        self.assertEqual(self.oracle()['drop_by_class']['UNKNOWN_INCOMPLETE_SENDER_GROUP'],1)

    def test_group_null_payload_unknown(self):
        self.add_group()
        self.ev[-1]['lp_fragment_hex']=None
        self.assertEqual(self.oracle()['drop_by_class']['UNKNOWN_INCOMPLETE_SENDER_GROUP'],1)

    def test_group_unattested_name_unknown(self):
        self.add_group('/hcraf/competitor/999')
        self.assertEqual(self.oracle()['drop_by_class']['UNKNOWN_NAME_NOT_ATTESTED_BY_PRODUCER'],1)

    def test_group_corrupted_content_unknown(self):
        self.add_group();self.ev[-1]['lp_fragment_hex']='00'*10
        self.assertNotEqual(self.oracle()['drop_by_class'].get('COMPETITOR_DATA'),1)

    def test_group_conflicting_duplicate_rejected(self):
        self.add_group()
        x=copy.deepcopy(self.ev[-1]);x['link_event_seq']=len(self.ev)+1
        x['lp_fragment_hex']='00';self.ev.append(x)
        with self.assertRaisesRegex(GroupEvidenceError,'contradictory'):
            self.oracle()

    def test_group_wrong_seq_rejected(self):
        self.add_group();self.ev[-1]['lp_seq']=8
        with self.assertRaisesRegex(GroupEvidenceError,'Sequence'):
            self.oracle()

    def test_group_wrong_count_rejected(self):
        self.add_group();self.ev[-1]['lp_frag_count']=0
        with self.assertRaisesRegex(GroupEvidenceError,'Sequence'):
            self.oracle()

    def test_group_bad_hex_rejected(self):
        self.add_group();self.ev[-1]['lp_fragment_hex']='0z'
        with self.assertRaisesRegex(GroupEvidenceError,'hex'):
            self.oracle()

    def test_target_data_different_from_competitor(self):
        self.receipts=[{'name':'/hcraf/pilot/1','nonce':99,'time_ns':2_010_000_000}]
        self.add_group('/hcraf/pilot/1')
        r=self.oracle()['target_windows'][0]
        self.assertEqual(r['known_target_DATA_drops'],1)
        self.assertEqual(r['known_competitor_DATA_drops'],0)
        self.assertEqual(r['new_return_data_diagnostic'],'OBSERVED_TARGET_DATA_FRAGMENT_DROP_ONLY')

    def test_prior_drop_not_future(self):
        self.add_group(time_ns=1_800_000_000)
        self.assertEqual(self.oracle()['target_windows'][0]['new_return_data_diagnostic'],
                         'COMPLETE_WINDOW_NO_RETURN_FRAGMENT_DROP')

    def test_horizon_end_exclusive_beg_inclusive_end(self):
        self.add_group(time_ns=2_049_999_999)
        self.assertEqual(self.oracle()['target_windows'][0]['known_competitor_DATA_drops'],1)

    def test_horizon_outside(self):
        self.add_group(time_ns=2_500_000_000)
        self.assertEqual(self.oracle()['target_windows'][0]['known_competitor_DATA_drops'],0)

    def test_offpath_drop_ignored(self):
        self.add_group(dev=(20,0))
        self.assertEqual(self.oracle()['selected_return_fragment_drop_count'],0)

    def test_forward_only_drop_ignored(self):
        self.add_group(dev=(1,1))
        self.assertEqual(self.oracle()['selected_return_fragment_drop_count'],0)

    def test_unknown_does_not_turn_into_negative(self):
        self.add_group(missing_idx=0)
        self.assertEqual(self.oracle()['target_windows'][0]['new_return_data_diagnostic'],
                         'UNKNOWN_CONCURRENT_UNRESOLVED_GROUP')

    def test_no_events_is_not_F3_zero(self):
        x=self.oracle()
        self.assertEqual(x['official_F3_labels'],0)
        self.assertIsNone(x['FutureCongestion'])
        self.assertEqual(x['target_windows'][0]['new_return_data_diagnostic'],
                         'COMPLETE_WINDOW_NO_RETURN_FRAGMENT_DROP')

    def test_attempt_promote_F3_rejected(self):
        self.cfg['F3_ready']=True
        with self.assertRaisesRegex(GroupEvidenceError,'NO-GO'):
            self.oracle()

    def test_attempt_online_remote_queue_rejected(self):
        self.cfg['remote_queue_online_feature']=True
        with self.assertRaisesRegex(GroupEvidenceError,'NO-GO'):
            self.oracle()

    def test_missing_final_rejected(self):
        self.add_group();rows=self.finalized()[:-1]
        with self.assertRaisesRegex(GroupEvidenceError,'coverage'):
            oracle_group(self.cfg,self.decisions,rows,self.receipts,self.old)

    def test_duplicate_link_sequence_rejected(self):
        self.add_group();rows=self.finalized()
        rows[14]['link_event_seq']=14
        with self.assertRaisesRegex(GroupEvidenceError,'event seq'):
            oracle_group(self.cfg,self.decisions,rows,self.receipts,self.old)

    def test_duplicate_receipt_rejected(self):
        self.add_group();self.receipts.append(self.receipts[0].copy())
        with self.assertRaisesRegex(GroupEvidenceError,'duplicate producer'):
            self.oracle()

    def test_wrong_producer_receipt_nonce_rejected(self):
        self.add_group();self.receipts[0]['nonce']='11001'
        with self.assertRaisesRegex(GroupEvidenceError,'producer receipt'):
            self.oracle()

if __name__=='__main__':unittest.main()
