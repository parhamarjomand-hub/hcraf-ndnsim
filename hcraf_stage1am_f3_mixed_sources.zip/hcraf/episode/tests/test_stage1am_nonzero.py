"""Synthetic negative/positive test fixtures ONLY; NOT experimental outcomes.

Actual pilot results must come from real cloud-run ndnSIM physical Trace.
"""
import unittest
import sys
import copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from oracle_stage1am_nonzero import oracle,OracleError


def fixture():
    devs=[(0,0,257),(1,0,257),(1,1,258),(1,2,259),(1,3,260),
          (2,0,257),(2,1,258),(3,0,257),(3,1,258),
          (4,0,257),(4,1,258),(5,0,257),(6,0,257),(7,0,257)]
    def e(t,kind,node,device,face):
        return {'time_ns':t,'event_type':kind,'node_id':node,'device_index':device,'face_id':face,
                'wire_status':'NO_PACKET','ndn_packet_type':None,'ndn_name':None,'lp_status':'NO_PACKET'}
    physical=[e(0,'INITIAL',*d) for d in devs]
    physical+=[e(20_000_000_000,'FINAL',*d) for d in devs]
    for i,x in enumerate(physical):x['link_event_seq']=i+1
    decisions=[{'decision_id':i+1,'time_ns':2_100_000_000+i*30_000_000,
                'name':f'/hcraf/pilot/{i}','pit_instance_id':100+i} for i in range(12)]
    local=[{'decision_id':d['decision_id'],'sim_time_ns':d['time_ns'],
            'candidate_face_id':258,'queue_packets':0} for d in decisions]
    cfg={'future_oracle_horizon_ns_pilot':50_000_000,'future_oracle_is_final_F3':False,
         'F3_ready':False,'training_ready':False,'future_congestion':None,'selected_face_id':258}
    return cfg,decisions,local,physical

def add_drop(physical,t,name='/hcraf/competitor/1',kind='INTEREST',status='NON_PILOT',lp='SINGLE_LP',face=258,device=1,node=1):
    x={'time_ns':t,'event_type':'QUEUE_DROP','node_id':node,'device_index':device,'face_id':face,
       'wire_status':status,'ndn_packet_type':kind,'ndn_name':name,'lp_status':lp}
    physical.insert(14,x)
    for i,e in enumerate(physical):e['link_event_seq']=i+1

class Stage1AMNonzeroOracleTests(unittest.TestCase):
    def test_complete_control_negative(self):
        c,d,l,p=fixture();res=oracle(c,d,l,p)
        self.assertEqual(len(res['target_rows']),12)
        self.assertTrue(all(x['pilot_future_competitor_drop_50ms']==0 for x in res['target_rows']))
        self.assertTrue(all(x['FutureCongestion'] is None and x['F3_ready'] is False for x in res['target_rows']))
    def test_valid_future_independent_competitor_drop_positive(self):
        c,d,l,p=fixture();t=d[0]['time_ns'];add_drop(p,t+1)
        r=oracle(c,d,l,p)['target_rows'][0]
        self.assertEqual(r['pilot_future_competitor_drop_50ms'],1)
        self.assertEqual(r['oracle_witness_link_event_seq'],[15])
    def test_before_decision_not_future(self):
        c,d,l,p=fixture();add_drop(p,d[0]['time_ns']-1)
        self.assertEqual(oracle(c,d,l,p)['target_rows'][0]['pilot_future_competitor_drop_50ms'],0)
    def test_exact_decision_time_not_future(self):
        c,d,l,p=fixture();add_drop(p,d[0]['time_ns'])
        self.assertEqual(oracle(c,d,l,p)['target_rows'][0]['pilot_future_competitor_drop_50ms'],0)
    def test_after_horizon_not_future(self):
        c,d,l,p=fixture();add_drop(p,d[0]['time_ns']+50_000_001)
        self.assertEqual(oracle(c,d,l,p)['target_rows'][0]['pilot_future_competitor_drop_50ms'],0)
    def test_horizon_right_boundary_inclusive(self):
        c,d,l,p=fixture();add_drop(p,d[0]['time_ns']+50_000_000)
        self.assertEqual(oracle(c,d,l,p)['target_rows'][0]['pilot_future_competitor_drop_50ms'],1)
    def test_target_drop_not_competitor(self):
        c,d,l,p=fixture();add_drop(p,d[0]['time_ns']+1,name='/hcraf/pilot/4',status='PILOT')
        self.assertEqual(oracle(c,d,l,p)['target_rows'][0]['pilot_future_competitor_drop_50ms'],0)
    def test_unknown_fragment_never_mapped_to_zero(self):
        c,d,l,p=fixture();add_drop(p,d[0]['time_ns']+1,name=None,kind=None,status='INVALID',lp='FRAGMENT')
        self.assertEqual(oracle(c,d,l,p)['target_rows'][0]['pilot_future_competitor_drop_50ms'],'UNKNOWN')
    def test_unknown_management_never_zero(self):
        c,d,l,p=fixture();add_drop(p,d[0]['time_ns']+1,name='/localhop/mgmt',kind='INTEREST')
        self.assertEqual(oracle(c,d,l,p)['target_rows'][0]['pilot_future_competitor_drop_50ms'],'UNKNOWN')
    def test_positive_witness_overrides_unknown_drop(self):
        c,d,l,p=fixture();add_drop(p,d[0]['time_ns']+10,name=None,kind=None,status='INVALID')
        add_drop(p,d[0]['time_ns']+12)
        self.assertEqual(oracle(c,d,l,p)['target_rows'][0]['pilot_future_competitor_drop_50ms'],1)
    def test_wrong_pilot_wire_status_for_competitor_unknown(self):
        c,d,l,p=fixture();add_drop(p,d[0]['time_ns']+1,status='PILOT')
        r=oracle(c,d,l,p)['target_rows'][0]
        self.assertEqual(r['pilot_future_competitor_drop_50ms'],'UNKNOWN')
        self.assertEqual(r['ambiguous_drop_count'],1)
    def test_wrong_nonpilot_wire_status_for_target_unknown(self):
        c,d,l,p=fixture();add_drop(p,d[0]['time_ns']+1,
            name='/hcraf/pilot/4',status='NON_PILOT')
        self.assertEqual(oracle(c,d,l,p)['target_rows'][0]['pilot_future_competitor_drop_50ms'],'UNKNOWN')
    def test_competitor_fragment_remains_unknown(self):
        c,d,l,p=fixture();add_drop(p,d[0]['time_ns']+1,lp='FRAGMENT')
        self.assertEqual(oracle(c,d,l,p)['target_rows'][0]['pilot_future_competitor_drop_50ms'],'UNKNOWN')
    def test_competitor_noninterest_remains_unknown(self):
        c,d,l,p=fixture();add_drop(p,d[0]['time_ns']+1,kind='DATA')
        self.assertEqual(oracle(c,d,l,p)['target_rows'][0]['pilot_future_competitor_drop_50ms'],'UNKNOWN')
    def test_pilot_target_drop_plus_nonpilot_competitor_drop_positive(self):
        c,d,l,p=fixture()
        add_drop(p,d[0]['time_ns']+1,name='/hcraf/pilot/3',status='PILOT')
        add_drop(p,d[0]['time_ns']+2,status='NON_PILOT')
        r=oracle(c,d,l,p)['target_rows'][0]
        self.assertEqual(r['pilot_future_competitor_drop_50ms'],1)
        self.assertEqual(r['verified_competitor_drop_count'],1)
        self.assertEqual(r['ambiguous_drop_count'],0)
    def test_missing_final_fails(self):
        c,d,l,p=fixture();p.pop()
        with self.assertRaises(OracleError):oracle(c,d,l,p)
    def test_missing_seq_fails(self):
        c,d,l,p=fixture();p[15]['link_event_seq']=99
        with self.assertRaises(OracleError):oracle(c,d,l,p)
    def test_wrong_device_face_fails(self):
        c,d,l,p=fixture();p[0]['face_id']=900
        with self.assertRaises(OracleError):oracle(c,d,l,p)
    def test_future_lookahead_not_promoted(self):
        c,d,l,p=fixture();c['F3_ready']=True
        with self.assertRaises(OracleError):oracle(c,d,l,p)
    def test_no_remote_witness_as_local(self):
        c,d,l,p=fixture();add_drop(p,d[0]['time_ns']+1,device=0,face=257,node=2)
        self.assertEqual(oracle(c,d,l,p)['target_rows'][0]['pilot_future_competitor_drop_50ms'],0)
    def test_missing_local_snapshot_rejected(self):
        c,d,l,p=fixture();l.pop()
        with self.assertRaises(OracleError):oracle(c,d,l,p)
    def test_duplicate_decision_rejected(self):
        c,d,l,p=fixture();d[1]['decision_id']=d[0]['decision_id']
        with self.assertRaises(OracleError):oracle(c,d,l,p)
    def test_invalid_horizon_rejected(self):
        c,d,l,p=fixture();c['future_oracle_horizon_ns_pilot']=200_000_000
        with self.assertRaises(OracleError):oracle(c,d,l,p)
    def test_nan_queue_not_accepted(self):
        c,d,l,p=fixture();l[0]['queue_packets']=float('nan')
        with self.assertRaises(OracleError):oracle(c,d,l,p)
    def test_censored_end_horizon_unknown(self):
        c,d,l,p=fixture();d[0]['time_ns']=19_980_000_000;l[0]['sim_time_ns']=19_980_000_000
        self.assertEqual(oracle(c,d,l,p)['target_rows'][0]['pilot_future_competitor_drop_50ms'],'UNKNOWN')
    def test_invalid_post_decision_local_evidence_rejected(self):
        c,d,l,p=fixture();l[0]['sim_time_ns']+=1
        with self.assertRaises(OracleError):oracle(c,d,l,p)
    def test_label_not_ready(self):
        c,d,l,p=fixture();add_drop(p,d[0]['time_ns']+1)
        r=oracle(c,d,l,p)
        self.assertIsNone(r['FutureCongestion']);self.assertFalse(r['training_ready'])
        self.assertTrue(r['pilot_outcome_not_final_F3'])

if __name__=='__main__':unittest.main()
