import json,sys,unittest,copy,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from verify_stage1ah_a1 import validate_config_and_arrivals,ARMS,STAGE
from summarize_stage1ah_a1 import summarize

class AmendmentContractTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.p=Path(self.tmp.name)
        self.c={'amendment_stage':STAGE,'phase_arm':'RATE5M_TARGET_LAG_6MS',
          'target_offset_ns':6_000_000,'competitor_offset_ns':0,
          'selected_return_bps':5_000_000,
          'collector_stage':'1AH.GROUP_AWARE.0',
          'mode':'LP_INDEPENDENT_COMPETITOR_NO_DROP','topology_id':'DEV_CHAIN_B',
          'selected_face_slot':0,'selected_face_id':258,'eligible_face_ids':[258,259,260],'run':9101,'seed':17,
          'interest_lifetime_ms':2600,'planned_requests':12,'competitor_planned_requests':12,
          'nominal_arrival_interval_ns':250_000_000,'competitor_interval_ns':250_000_000,
          'actual_assignment_probability':1.0,'no_counterfactual_unselected_face':True}
        self._write_valid()
    def tearDown(self):self.tmp.cleanup()
    def _write_valid(self):
        (self.p/'scenario.json').write_text(json.dumps(self.c))
        for filename,klass,off,stream in [('consumer_events.jsonl','TARGET',self.c['target_offset_ns'],129),
                ('competitor_events.jsonl','INDEPENDENT_COMPETITOR',self.c['competitor_offset_ns'],139)]:
            arrivals=[];sends=[]
            for i in range(12):
                jitter=29+i
                time=2_000_000_000+off+i*250_000_000+jitter
                arrivals.append(dict(sequence=i,jitter_ns=jitter,time_ns=time,traffic_class=klass,stream=stream))
                sends.append(dict(event='SEND',time_ns=time,traffic_class=klass))
            for postfix,rows in [('.arrivals.jsonl',arrivals),('',sends)]:
                (self.p/(filename+postfix)).write_text(''.join(json.dumps(r)+'\n' for r in rows))
    def test_all_preregistered_arms(self):
        for arm,(to,co,bps) in ARMS.items():
            self.c.update(phase_arm=arm,target_offset_ns=to,competitor_offset_ns=co,selected_return_bps=bps)
            self._write_valid()
            self.assertEqual(validate_config_and_arrivals(self.p,arm)[0],arm)
    def test_reject_wrong_stage(self):
        self.c['amendment_stage']='1AH.GROUP_AWARE.0';self._write_valid()
        with self.assertRaises(Exception):validate_config_and_arrivals(self.p)
    def test_reject_wrong_topology(self):
        self.c['topology_id']='DEV_CHAIN_A';self._write_valid()
        with self.assertRaises(Exception):validate_config_and_arrivals(self.p)
    def test_reject_wrong_slot(self):
        self.c['selected_face_slot']=1;self._write_valid()
        with self.assertRaises(Exception):validate_config_and_arrivals(self.p)
    def test_reject_arm_offset_mismatch(self):
        self.c['target_offset_ns']=0;self._write_valid()
        with self.assertRaises(Exception):validate_config_and_arrivals(self.p)
    def test_reject_nonce_schedule_jitter_tamper(self):
        filename=self.p/'consumer_events.jsonl.arrivals.jsonl'
        data=filename.read_text().splitlines();obj=json.loads(data[0]);obj['jitter_ns']=100001
        data[0]=json.dumps(obj);filename.write_text('\n'.join(data)+'\n')
        with self.assertRaises(Exception):validate_config_and_arrivals(self.p)
    def test_reject_wrong_actual_send_time(self):
        filename=self.p/'competitor_events.jsonl'
        data=filename.read_text().splitlines();obj=json.loads(data[0]);obj['time_ns']+=1
        data[0]=json.dumps(obj);filename.write_text('\n'.join(data)+'\n')
        with self.assertRaises(Exception):validate_config_and_arrivals(self.p)
    def test_reject_unselected_counterfactual(self):
        self.c['no_counterfactual_unselected_face']=False;self._write_valid()
        with self.assertRaises(Exception):validate_config_and_arrivals(self.p)
    def test_all_missing_is_incomplete(self):
        root=self.p/'empty';root.mkdir()
        self.assertEqual(summarize(root),3)
        self.assertEqual(json.loads((root/'stage1aha1_summary.json').read_text())['status'],
                         'INCOMPLETE_TARGETED_A1_FEASIBILITY')
    def test_source_is_additive_not_relaxed(self):
        src=Path(__file__).resolve().parents[1]
        c=(src/'src/hcraf-stage1ah-a1-pilot.cpp').read_text()
        base=(src/'src/hcraf-stage1ah-pilot.cpp').read_text()
        self.assertIn('if (topology!="DEV_CHAIN_B" || selectedSlot!=0',c)
        self.assertIn('targetOffsetNs==6000000ULL',c)
        self.assertIn('competitorOffsetNs==2000000ULL',c)
        self.assertIn('returnBps ? returnBps : 10000000u',c)
        self.assertIn('m_offsetNs',c)
        self.assertNotIn('targetOffsetNs',base)
        v=(src/'scripts/verify_stage1ah_a1.py').read_text()
        self.assertIn('verify_original(root)',v)
        self.assertIn("verified_competitor_service_overlap_count",(src/'scripts/verify_stage1ah.py').read_text())
if __name__=='__main__':unittest.main()
