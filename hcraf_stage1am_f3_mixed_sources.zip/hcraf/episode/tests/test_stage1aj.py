import copy,json,sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from verify_stage1aj import load_config,exogenous_physical_busy,ARMS,RUNS,STAGE
from summarize_stage1aj import summarize,PAIRS

class AJContractTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
  self.cfg={'amendment_stage':STAGE,'collector_stage':'1AJ.PHYSICAL_PRESSURE.0',
    'phase_arm':'ON_5M_TARGET_LAG_6MS','topology_id':'DEV_CHAIN_B',
    'selected_face_slot':0,'selected_face_id':258,'eligible_face_ids':[258,259,260],
    'path_nodes':[0,1,2,7],'selected_relay_node_id':2,'run':9201,'seed':17,
    'mode':'LP_INDEPENDENT_COMPETITOR_NO_DROP','selected_return_bps':5000000,
    'competitor_planned_requests':12,'competitor_injection_enabled':True,
    'competitor_interval_ns':250000000,'target_offset_ns':6000000,'competitor_offset_ns':0,
    'planned_requests':12,'nominal_arrival_interval_ns':250000000,
    'interest_lifetime_ms':2600,'mtu_bytes':600,'payload_bytes':4096,
    'selected_forward_bps':10000000,'stop_ns':20000000000,'cache_enabled':False,
    'multi_hop_enabled':True,'instrument_enabled':True,
    'actual_assignment_probability':1.0,'no_counterfactual_unselected_face':True,
    'independent_physical_pressure_test':True,'paired_target_arrivals_must_match':True,
    'congestion':None,'future_congestion':None,'F3_ready':False,'training_ready':False,
    'decision_time_us_real_HCRAF':None,'observer_cost_is_decision_time':False}
  self.write()
 def tearDown(self):self.tmp.cleanup()
 def write(self):
  (self.root/'scenario.json').write_text(json.dumps(self.cfg))
  for filename,typ,offset,stream,n in (
    ('consumer_events.jsonl','TARGET',self.cfg['target_offset_ns'],129,12),
    ('competitor_events.jsonl','INDEPENDENT_COMPETITOR',self.cfg['competitor_offset_ns'],139,self.cfg['competitor_planned_requests'])):
   if n==0:
    for name in (filename,filename+'.arrivals.jsonl'):
     (self.root/name).unlink(missing_ok=True)
    continue
   prefix='/hcraf/pilot/' if typ=='TARGET' else '/hcraf/competitor/'
   arr=[];snd=[]
   for i in range(n):
    t=2000000000+offset+250000000*i+33+i
    arr.append({'sequence':i,'time_ns':t,'jitter_ns':33+i,'traffic_class':typ,'stream':stream})
    snd.append({'event':'SEND','time_ns':t,'traffic_class':typ,'name':prefix+str(i)})
   (self.root/filename).write_text(''.join(json.dumps(x)+'\n' for x in snd))
   (self.root/(filename+'.arrivals.jsonl')).write_text(''.join(json.dumps(x)+'\n' for x in arr))
 def test_every_registered_arm(self):
  for arm,(rate,n,to,co) in ARMS.items():
   with self.subTest(arm=arm):
    self.cfg.update(phase_arm=arm,selected_return_bps=rate,
      competitor_planned_requests=n,competitor_injection_enabled=bool(n),
      competitor_interval_ns=250000000 if n else 0,target_offset_ns=to,
      competitor_offset_ns=co)
    self.write();self.assertEqual(load_config(self.root,arm)[0],arm)
 def test_bad_stage_rejected(self):
  self.cfg['amendment_stage']='1AH-A1.PHASE_SWEEP.0';self.write()
  with self.assertRaises(Exception):load_config(self.root)
 def test_unselected_face_claim_rejected(self):
  self.cfg['no_counterfactual_unselected_face']=False;self.write()
  with self.assertRaises(Exception):load_config(self.root)
 def test_nonunit_propensity_rejected(self):
  self.cfg['actual_assignment_probability']=.33333;self.write()
  with self.assertRaises(Exception):load_config(self.root)
 def test_wrong_rate_rejected(self):
  self.cfg['selected_return_bps']=10000000;self.write()
  with self.assertRaises(Exception):load_config(self.root)
 def test_wrong_seed_rejected(self):
  self.cfg['run']=9101;self.write()
  with self.assertRaises(Exception):load_config(self.root)
 def test_extra_competitor_in_off_rejected(self):
  self.cfg.update(phase_arm='OFF_5M',competitor_planned_requests=0,
     competitor_injection_enabled=False,competitor_interval_ns=0,target_offset_ns=0)
  self.write();(self.root/'competitor_events.jsonl').write_text('')
  with self.assertRaises(Exception):load_config(self.root)
 def test_tampered_target_arrival_rejected(self):
  f=self.root/'consumer_events.jsonl.arrivals.jsonl';v=f.read_text().splitlines()
  z=json.loads(v[0]);z['jitter_ns']=100000;v[0]=json.dumps(z);f.write_text('\n'.join(v)+'\n')
  with self.assertRaises(Exception):load_config(self.root)
 def test_tampered_competitor_identity_rejected(self):
  f=self.root/'competitor_events.jsonl';v=f.read_text().splitlines()
  z=json.loads(v[0]);z['name']='/hcraf/pilot/0';v[0]=json.dumps(z);f.write_text('\n'.join(v)+'\n')
  with self.assertRaises(Exception):load_config(self.root)
 def test_stale_training_state_rejected(self):
  self.cfg['F3_ready']=True;self.write()
  with self.assertRaises(Exception):load_config(self.root)
 def test_missing_coverage_incomplete(self):
  r=self.root/'missing';r.mkdir();self.assertEqual(summarize(r),3)
  d=json.loads((r/'stage1aj_summary.json').read_text())
  self.assertEqual(d['status'],'INCOMPLETE_DIAGNOSTIC_COVERAGE')
  self.assertIsNone(d['FutureCongestion'])
 def test_workflow_references_new_stage(self):
  folder=Path(__file__).resolve().parents[1]
  pilot=(folder/'src/hcraf-stage1aj-pilot.cpp').read_text()
  self.assertIn('OFF_5M_TARGET_LAG_6MS',pilot)
  self.assertIn('1AJ.PAIRED_INTERVENTION.0',pilot)
  self.assertIn('const bool hasCompetitor=(competitorCount!=0);',pilot)
  assert 'GO_FREEZE' not in pilot or 'F3_ready' in pilot
  assert (folder/'scripts/build_stage1aj.sh').is_file()

class WaitBusyTests(unittest.TestCase):
 def setup_example(self):
  q={'packet_uid':100,'time_ns':30};enq={'time_ns':10};tb={'time_ns':30};te={'time_ns':36}
  return [(q,enq,tb,te)]
 def test_true_competitor_blocks(self):
  a,u=exogenous_physical_busy(self.setup_example(),[(16,22,None,101)],{101:'INDEPENDENT_COMPETITOR'})
  self.assertEqual((a,u),(6,0))
 def test_self_group_does_not_block(self):
  a,u=exogenous_physical_busy(self.setup_example(),[(16,22,None,101)],{101:'TARGET'})
  self.assertEqual((a,u),(0,0))
 def test_group_epoch_m3_not_wait(self):
  a,u=exogenous_physical_busy(self.setup_example(),[(32,35,None,101)],{101:'INDEPENDENT_COMPETITOR'})
  self.assertEqual((a,u),(0,0))
 def test_sender_unknown_not_imputed(self):
  a,u=exogenous_physical_busy(self.setup_example(),[(16,22,None,101)],{})
  self.assertEqual((a,u),(0,1))
 def test_union_no_double_count(self):
  a,u=exogenous_physical_busy(self.setup_example(),[(15,25,None,101),(20,28,None,102)],
    {101:'INDEPENDENT_COMPETITOR',102:'INDEPENDENT_COMPETITOR'})
  self.assertEqual((a,u),(13,0))
 def test_partial_overlap_bounded(self):
  a,u=exogenous_physical_busy(self.setup_example(),[(0,14,None,101),(28,34,None,102)],
    {101:'INDEPENDENT_COMPETITOR',102:'INDEPENDENT_COMPETITOR'})
  self.assertEqual((a,u),(6,0))
 def test_no_overlap_is_not_label_negative(self):
  a,u=exogenous_physical_busy(self.setup_example(),[],{})
  self.assertEqual((a,u),(0,0))
 def test_bad_lifecycle_rejected(self):
  q={'packet_uid':100,'time_ns':8};enq={'time_ns':10};tb={'time_ns':30};te={'time_ns':36}
  with self.assertRaises(Exception):exogenous_physical_busy([(q,enq,tb,te)],[],{})

if __name__=='__main__':unittest.main()
