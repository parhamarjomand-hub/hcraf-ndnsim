"""v0.46 synthetic contract tests. These do not constitute fresh-test evidence."""
import json, pathlib, sys, tempfile, unittest
S=pathlib.Path(__file__).resolve().parents[1]/'scripts'
sys.path.insert(0,str(S))
from f3_fragment_aware_v046 import (TOPOLOGIES, ARMS, CONTROL_ARMS,PRESSURE_ARMS,
   MAX_DIAGNOSTIC_QUEUE_PACKETS_V045, PRIMARY_WAIT_NS, PRIMARY_HORIZON_NS,
   HeldoutError,adjudicate_window,target_receipt_guard,queue_drain_diagnostic_ns,
   check_plan,STATUS)
from summarize_stage1am_f3_fragment_aware import main
T=2_030_000_000
PATH={(0,0),(1,1),(2,1),(7,1),(8,0),(7,0),(2,0),(1,0)}
RETURN={(8,0),(7,0),(2,0),(1,0)}
SENT={'/hcraf/pilot/0':1000,'/hcraf/competitor/0':11000}

def event(kind, delta, node=1, device=1, **kw):
    d={'event_type':kind,'node_id':node,'device_index':device,'time_ns':T+delta,
       'queue_packets':0,'queue_bytes':0}
    d.update(kw)
    return d

class FragmentAware(unittest.TestCase):
    def verdict(self,events,inv=None):
        return adjudicate_window(T,PRIMARY_HORIZON_NS,PRIMARY_WAIT_NS,events,PATH,RETURN,inv or {},SENT)[0]
    def test_new_independent_topologies(self):
        self.assertEqual(set(TOPOLOGIES),{'VAL_CHAIN_G','TEST_CHAIN_H'})
        self.assertTrue(set(TOPOLOGIES).isdisjoint({'VAL_CHAIN_E','TEST_CHAIN_F'}))
    def test_new_seed_disjoint(self):
        seeds=set().union(*(set(x['runs']) for x in TOPOLOGIES.values()))
        self.assertEqual(len(seeds),8)
        self.assertTrue(seeds.isdisjoint({9921,9922,9923,9924,9981,9982,9983,9984}))
    def test_matrix(self):self.assertEqual(2*3*len(ARMS)*4*2,336)
    def test_seven_arms(self):self.assertEqual((len(CONTROL_ARMS),len(PRESSURE_ARMS)),(3,4))
    def test_fragment_burst_above_two_not_automatically_unknown(self):
        self.assertEqual(MAX_DIAGNOSTIC_QUEUE_PACKETS_V045,2)
        self.assertEqual(self.verdict([event('QUEUE_ENQUEUE',100,queue_packets=7,queue_bytes=3786),
                                      event('QUEUE_DEQUEUE',200,queue_wait_ns=631680)]),0)
    def test_actual_wait_at_threshold_unknown(self):
        self.assertEqual(self.verdict([event('QUEUE_DEQUEUE',3,queue_wait_ns=5_000_000)]),'UNKNOWN')
    def test_short_wait_no_drop_negative_candidate(self):
        self.assertEqual(self.verdict([event('QUEUE_DEQUEUE',3,queue_wait_ns=4_999_999)]),0)
    def test_verified_competitor_interest_drop_positive(self):
        x=event('QUEUE_DROP',3,ndn_packet_type='INTEREST',lp_status='SINGLE_LP',
            ndn_name='/hcraf/competitor/0',ndn_nonce=11000)
        self.assertEqual(self.verdict([x]),1)
    def test_verified_target_interest_drop_positive(self):
        x=event('QUEUE_DROP',3,ndn_packet_type='INTEREST',lp_status='SINGLE_LP',
            ndn_name='/hcraf/pilot/0',ndn_nonce=1000)
        self.assertEqual(self.verdict([x]),1)
    def test_unknown_drop_overrides_verified_positive(self):
        good=event('QUEUE_DROP',3,ndn_packet_type='INTEREST',lp_status='SINGLE_LP',
           ndn_name='/hcraf/pilot/0',ndn_nonce=1000)
        self.assertEqual(self.verdict([good,event('QUEUE_DROP',4)]),'UNKNOWN')
    def test_missing_lp_group_unknown(self):
        self.assertEqual(self.verdict([event('QUEUE_DROP',3,node=8,device=0,lp_status='FRAGMENT',lp_group_start_seq=5)]),'UNKNOWN')
    def test_authenticated_lp_group_positive(self):
        self.assertEqual(self.verdict([event('QUEUE_DROP',3,node=8,device=0,lp_status='FRAGMENT',lp_group_start_seq=5)],
                                 {(8,0,5):{'class':'TARGET_DATA'}}),1)
    def test_offpath_drop_ignored(self):
        self.assertEqual(self.verdict([event('QUEUE_DROP',3,node=4,device=1)]),0)
    def test_before_decision_drop_not_future(self):
        self.assertEqual(self.verdict([event('QUEUE_DROP',0)]),0)
    def test_outside_horizon_drop_not_future(self):
        self.assertEqual(self.verdict([event('QUEUE_DROP',50_000_001)]),0)
    def test_queue_byte_proxy_rate_normalizes(self):
        initials={(1,1):{'data_rate_bps':50_000_000}}
        x=event('QUEUE_ENQUEUE',3,queue_bytes=3786,queue_packets=7)
        n,b=queue_drain_diagnostic_ns([x],{(1,1)},initials,T,50_000_000)
        self.assertEqual((n,b),(605760,3786))
    def test_queue_byte_proxy_low_speed(self):
        initials={(1,1):{'data_rate_bps':50_000}}
        x=event('QUEUE_ENQUEUE',3,queue_bytes=3786)
        self.assertEqual(queue_drain_diagnostic_ns([x],{(1,1)},initials,T,50_000_000)[0],605760000)
    def test_queue_byte_tamper_fails(self):
        with self.assertRaises(HeldoutError):
            queue_drain_diagnostic_ns([event('QUEUE_DROP',3,queue_bytes=-1)],{(1,1)},
                                     {(1,1):{'data_rate_bps':50_000_000}},T,50_000_000)
    def test_invalid_link_rate_fails(self):
        with self.assertRaises(HeldoutError):
            queue_drain_diagnostic_ns([event('QUEUE_ENQUEUE',3)],{(1,1)},
                                     {(1,1):{'data_rate_bps':0}},T,50_000_000)
    def consumer(self,root,with_receipt=True,with_nack=False):
        events=[]
        for i in range(12):
            name=f'/hcraf/pilot/{i}'
            events.append({'event':'SEND','name':name,'nonce':1001+i,'time_ns':T+i*30_000_000})
            if with_receipt:events.append({'event':'DATA','name':name,'time_ns':T+i*30_000_000+90_000_000})
            if with_nack and i==0:events.append({'event':'NACK','name':name,'time_ns':T+20_000_000})
        (root/'consumer_events.jsonl').write_text(''.join(json.dumps(e)+'\n' for e in events))
    def test_target_receipt_confirms(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);self.consumer(root)
            v=target_receipt_guard(root)
            self.assertTrue(v['/hcraf/pilot/0']['receipt_confirmed_within_lifetime'])
            self.assertEqual(v['/hcraf/pilot/0']['receipt_delay_ns'],90_000_000)
    def test_missing_target_receipt_is_not_negative(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);self.consumer(root,False)
            self.assertFalse(target_receipt_guard(root)['/hcraf/pilot/0']['receipt_confirmed_within_lifetime'])
    def test_target_nack_prevents_negative(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);self.consumer(root,True,True)
            self.assertFalse(target_receipt_guard(root)['/hcraf/pilot/0']['receipt_confirmed_within_lifetime'])
    def test_duplicate_target_sends_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);self.consumer(root)
            with (root/'consumer_events.jsonl').open('a') as f:
                f.write(json.dumps({'event':'SEND','name':'/hcraf/pilot/0','nonce':1001,'time_ns':T})+'\n')
            with self.assertRaises(HeldoutError):target_receipt_guard(root)
    def test_negative_guard_is_in_correct_place(self):
        text=(S/'f3_fragment_aware_v046.py').read_text()
        self.assertIn('LOW_WAIT_BUT_PAIRED_TARGET_DELAY_GE_5MS',text)
        self.assertIn('TARGET_SCHEDULE_OR_NONCE_NOT_MATCHED_TO_QUIET',text)
    def test_negative_guard_is_postdecision_not_online(self):
        text=(S/'f3_fragment_aware_v046.py').read_text()
        self.assertIn('target_guard=target_receipt_guard(p)',text)
        self.assertIn('remote_node_queue_accessed',text)
    def test_final_labels_never_promoted(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertFalse(main(d))
            s=json.loads((pathlib.Path(d)/'summary'/'summary.json').read_text())
            self.assertEqual(s['status'],'INCOMPLETE_F3_FRAGMENT_AWARE_CANDIDATE_EVIDENCE')
            self.assertFalse(s['GO_FREEZE']);self.assertIsNone(s['FutureCongestion'])
    def test_cpp_new_native_not_old_topologies(self):
        s=(S.parent/'src'/'hcraf-stage1am-f3-fragment-aware-pilot.cpp').read_text()
        self.assertIn('VAL_CHAIN_G',s);self.assertIn('TEST_CHAIN_H',s)
        self.assertNotIn('VAL_CHAIN_E',s);self.assertNotIn('TEST_CHAIN_F',s)
    def test_script_validation_before_test(self):
        s=(S/'run_stage1am_f3_fragment_aware.sh').read_text()
        self.assertLess(s.index('for topology in VAL_CHAIN_G TEST_CHAIN_H'),s.index('seal_stage1am_f3_fragment_validation.py'))
        self.assertIn('NEW_VALIDATION_NOT_SEALED_TEST_MUST_NOT_OPEN',s)
    def test_old_verifier_unchanged(self):
        self.assertTrue((S/'f3_coverage_v045.py').exists())
    def test_two_distinct_partitions(self):
        self.assertEqual({k:v['partition'] for k,v in TOPOLOGIES.items()},
          {'VAL_CHAIN_G':'VALIDATION','TEST_CHAIN_H':'TEST'})

if __name__=='__main__':unittest.main()
