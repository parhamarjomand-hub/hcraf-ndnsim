"""Synthetic unit fixtures; not experimental output or model-training labels."""
import copy,json,sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from patch_nfd_stage1am_technical import substitute_once,patch_text
from verify_stage1am_technical import audit,EvidenceError,ARMS,one_index
from summarize_stage1am_technical import summarize

class Fixture(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.r=Path(self.tmp.name)
  self.cfg=dict(phase_arm='OFF_5M',collector_stage='1AM.NFD_LOCAL_QUEUE.0',
    amendment_stage='1AM.TECHNICAL.ONLINE_PILOT.0',topology_id='DEV_CHAIN_B',
    selected_face_slot=0,selected_face_id=258,eligible_face_ids=[258,259,260],
    seed=17,run=9401,planned_requests=12,interest_lifetime_ms=2600,
    nominal_arrival_interval_ns=250000000,selected_return_bps=5000000,
    competitor_planned_requests=0,target_offset_ns=0,competitor_offset_ns=0,
    instrument_enabled=True,actual_assignment_probability=1.0,
    local_NFD_queue_observed_before_send=True,
    NFD_dispatch_wall_CPU_measured=True,remote_queue_online_feature=False,
    NFD_cost_includes_recorder=True,no_counterfactual_unselected_face=True,
    congestion=None,future_congestion=None,decision_time_us_real_HCRAF=None,
    F3_ready=False,training_ready=False)
  self.decisions=[];self.states=[];self.events=[];self.physical=[];self.local=[];self.cost=[]
  for i in range(14):
   node,dev,face=((1,i,257+i) if 0<=i<=3 else (7+i,i,400+i))
   self.physical.append(dict(node_id=node,device_index=dev,face_id=face,event_type='INITIAL',
      time_ns=0,queue_packets=0,queue_bytes=0,data_rate_bps=10000000))
  # Fix exact node1 physical mapping and 5Mbps selected link.
  for x in self.physical:
   if x['node_id']==1 and x['face_id']==258:x['data_rate_bps']=10000000
  for k in range(12):
   id_=k+1; t=2_000_000_000+k*250000000;name=f'/hcraf/pilot/{k}'
   self.decisions.append(dict(decision_id=id_,node_id=1,name=name,time_ns=t,after_event_seq=2*k+1,
      anchor='BEFORE_AFTER_RECEIVE_INTEREST',pit_instance_id=id_,candidates=[dict(face_id=f) for f in [258,259,260]]))
   self.events.append(dict(event_type='TX_INTEREST',name=name,face_id=258,time_ns=t,
      event_seq=2*k+2,pit_instance_id=id_))
   self.cost.append(dict(decision_id=id_,NFD_forwarding_path_wall_ns=15000,
       NFD_forwarding_path_cpu_ns=9000,includes_telemetry_and_recorder=True,is_HCRAF_Gate_only_cost=False))
   for dev,f in enumerate([258,259,260],1):
    self.states.append(dict(decision_id=id_,face_id=f,time_ns=t,after_event_seq=2*k+1,
       max_terminal_event_seq=2*k,Congestion=None))
    self.local.append(dict(schema='1AM.TECHNICAL.LOCAL_ONLY.0',decision_id=id_,node_id=1,
       observed_before_forwarding=True,sim_time_ns=t,candidate_face_id=f,device_index=dev,
       link_up=True,capacity_packets=20,queue_packets=0,queue_bytes=0,local_queue_occupancy_fraction=0.0,
       data_rate_bps=10000000,remote_node_queue_accessed=False,future_pressure_label=None,Congestion=None))
   # Every NFD decision triggers a physical snapshot across ALL 14 link devices,
   # not only the 3 local candidate Faces. The ingress Face=257 at node 1 is not a
   # candidate and must not count as a fourth local queue observation.
   for original in self.physical[:14]:
    self.physical.append(dict(event_type='DECISION_SNAPSHOT',node_id=original['node_id'],
       device_index=original['device_index'],face_id=original['face_id'],
       decision_node_id=1,decision_id=id_,time_ns=t,
       data_rate_bps=original['data_rate_bps'],queue_packets=0,queue_bytes=0))
  self.flush()
 def tearDown(self):self.tmp.cleanup()
 def flush(self):
  (self.r/'scenario.json').write_text(json.dumps(self.cfg))
  for name,contents in [('events.jsonl.decisions.jsonl',self.decisions),
      ('events.jsonl.states.jsonl',self.states),('events.jsonl',self.events),
      ('link_events.jsonl',self.physical),('nfd_local_queue_at_decision.jsonl',self.local),
      ('nfd_dispatch_cost.jsonl',self.cost)]:
   (self.r/name).write_text(''.join(json.dumps(x)+'\n' for x in contents))
 def runaudit(self):self.flush();return audit(self.r,'OFF_5M')
 def test_accept_valid_synthetic(self):
  s=self.runaudit();self.assertEqual(s['NFD_decisions'],12);self.assertIsNone(s['FutureCongestion'])
 def test_future_local_snapshot_rejected(self):
  self.local[0]['sim_time_ns']+=1
  with self.assertRaises(EvidenceError):self.runaudit()
 def test_unexpected_remote_queue_rejected(self):
  self.local[0]['remote_node_queue_accessed']=True
  with self.assertRaises(EvidenceError):self.runaudit()
 def test_leaked_congestion_rejected(self):
  self.local[0]['Congestion']=0
  with self.assertRaises(EvidenceError):self.runaudit()
 def test_wrong_face_rejected(self):
  self.local[0]['candidate_face_id']=999
  with self.assertRaises(EvidenceError):self.runaudit()
 def test_wrong_device_rejected(self):
  self.local[0]['device_index']=2
  with self.assertRaises(EvidenceError):self.runaudit()
 def test_wrong_queue_observation_rejected(self):
  self.local[0]['queue_packets']=3;self.local[0]['local_queue_occupancy_fraction']=3/20
  with self.assertRaises(EvidenceError):self.runaudit()
 def test_null_snapshot_rejected(self):
  self.local.pop()
  with self.assertRaises(EvidenceError):self.runaudit()
 def test_duplicate_candidate_rejected(self):
  self.local[0]['candidate_face_id']=259
  with self.assertRaises(EvidenceError):self.runaudit()
 def test_future_state_rejected(self):
  self.states[0]['max_terminal_event_seq']=1000
  with self.assertRaises(EvidenceError):self.runaudit()
 def test_state_wrong_timestamp_rejected(self):
  self.states[0]['time_ns']+=100
  with self.assertRaises(EvidenceError):self.runaudit()
 def test_tx_wrong_face_rejected(self):
  self.events[0]['face_id']=260
  with self.assertRaises(EvidenceError):self.runaudit()
 def test_tx_before_decision_rejected(self):
  self.events[0]['event_seq']=1
  with self.assertRaises(EvidenceError):self.runaudit()
 def test_unmeasured_cost_rejected(self):
  self.cost[0]['NFD_forwarding_path_wall_ns']=0
  with self.assertRaises(EvidenceError):self.runaudit()
 def test_false_HCRAF_gate_cost_rejected(self):
  self.cost[0]['is_HCRAF_Gate_only_cost']=True
  with self.assertRaises(EvidenceError):self.runaudit()
 def test_null_cost_rejected(self):
  self.cost[0]['NFD_forwarding_path_cpu_ns']=None
  with self.assertRaises(EvidenceError):self.runaudit()
 def test_missing_cost_rejected(self):
  self.cost.pop()
  with self.assertRaises(EvidenceError):self.runaudit()
 def test_wrong_seed_rejected(self):
  self.cfg['run']=9101
  with self.assertRaises(EvidenceError):self.runaudit()
 def test_future_F3_label_rejected(self):
  self.cfg['future_congestion']=0
  with self.assertRaises(EvidenceError):self.runaudit()
 def test_wrong_propensity_rejected(self):
  self.cfg['actual_assignment_probability']=1/3
  with self.assertRaises(EvidenceError):self.runaudit()
 def test_missing_phys_snapshot_rejected(self):
  self.physical.pop()
  with self.assertRaises(EvidenceError):self.runaudit()
 def test_duplicate_decision_rejected(self):
  self.decisions[1]['decision_id']=1
  with self.assertRaises(EvidenceError):self.runaudit()
 def test_unmatched_pit_rejected(self):
  self.events[0]['pit_instance_id']=999
  with self.assertRaises(EvidenceError):self.runaudit()
 def test_unregistered_arm_rejected(self):
  self.cfg['phase_arm']='BAD'
  with self.assertRaises(EvidenceError):self.runaudit()
 def test_drop_not_accepted_as_complete(self):
  self.physical.append(dict(event_type='QUEUE_DROP',node_id=7,device_index=0))
  self.assertEqual(self.runaudit()['status'],'UNKNOWN_DROPS_REQUIRES_CLASS_ATTRIBUTION')
 def test_wrong_local_clock_rejected(self):
  self.local[0]['observed_before_forwarding']=False
  with self.assertRaises(EvidenceError):self.runaudit()
 def test_invalid_counterfactual_rejected(self):
  self.cfg['no_counterfactual_unselected_face']=False
  with self.assertRaises(EvidenceError):self.runaudit()
 def test_wrong_training_flag_rejected(self):
  self.cfg['training_ready']=True
  with self.assertRaises(EvidenceError):self.runaudit()


 def test_full_recorder_universe_including_ingress_is_accepted(self):
  # 14 devices per decision, including the unrelated ingress Face 257 at node 1
  self.assertEqual(sum(x['event_type']=='DECISION_SNAPSHOT' for x in self.physical),14*12)
  self.assertEqual(sum(x['node_id']==1 and x['face_id']==257 and x['event_type']=='DECISION_SNAPSHOT'
                       for x in self.physical),12)
  result=self.runaudit()
  self.assertEqual(result['NFD_local_queue_candidate_rows'],36)

 def test_non_candidate_snapshot_missing_rejected(self):
  self.physical.pop(next(i for i,x in enumerate(self.physical) if x['event_type']=='DECISION_SNAPSHOT'
        and x['node_id']!=1))
  with self.assertRaises(EvidenceError):self.runaudit()

 def test_non_candidate_duplicate_rejected(self):
  self.physical.append(copy.deepcopy(next(x for x in self.physical if x['event_type']=='DECISION_SNAPSHOT'
         and x['node_id']!=1)))
  with self.assertRaises(EvidenceError):self.runaudit()

 def test_non_candidate_future_time_rejected(self):
  next(x for x in self.physical if x['event_type']=='DECISION_SNAPSHOT'
       and x['node_id']!=1)['time_ns']+=1
  with self.assertRaises(EvidenceError):self.runaudit()

 def test_physical_snapshot_wrong_decision_id_rejected(self):
  next(x for x in self.physical if x['event_type']=='DECISION_SNAPSHOT')['decision_id']=999
  with self.assertRaises(EvidenceError):self.runaudit()

 def test_local_ingress_not_counted_as_candidate(self):
  # Exactly four snapshots on node1 (ingress + three candidates), not three.
  n=sum(x['event_type']=='DECISION_SNAPSHOT' and x['node_id']==1
        and x['decision_id']==1 for x in self.physical)
  self.assertEqual(n,4)
  self.assertEqual(self.runaudit()['NFD_decisions'],12)

 def test_candidate_physical_duplicate_face_rejected(self):
  x=next(x for x in self.physical if x['event_type']=='DECISION_SNAPSHOT'
         and x['node_id']==1 and x['face_id']==259)
  x['face_id']=258
  with self.assertRaises(EvidenceError):self.runaudit()


 def test_non_candidate_forged_device_rejected(self):
  r=next(x for x in self.physical if x['event_type']=='DECISION_SNAPSHOT' and x['node_id']!=1)
  r['device_index']=999
  with self.assertRaises(EvidenceError):self.runaudit()

 def test_non_candidate_forged_face_rejected(self):
  r=next(x for x in self.physical if x['event_type']=='DECISION_SNAPSHOT' and x['node_id']!=1)
  r['face_id']=999
  with self.assertRaises(EvidenceError):self.runaudit()

 def test_non_candidate_forged_rate_rejected(self):
  r=next(x for x in self.physical if x['event_type']=='DECISION_SNAPSHOT' and x['node_id']!=1)
  r['data_rate_bps']+=1
  with self.assertRaises(EvidenceError):self.runaudit()

class PatchAndSummaryContracts(unittest.TestCase):
 def test_substitution_exact(self):
  self.assertEqual(substitute_once('abc123','b','z','fixture'),'azc123')
 def test_double_anchor_rejected(self):
  with self.assertRaises(ValueError):substitute_once('aba','a','c','fixture')
 def test_missing_anchor_rejected(self):
  with self.assertRaises(ValueError):substitute_once('hello','x','c','fixture')
 def test_summary_missing_runs_fail_closed(self):
  with tempfile.TemporaryDirectory() as t:
   self.assertEqual(summarize(Path(t)),3)
   j=json.loads((Path(t)/'stage1am_technical_summary.json').read_text())
   self.assertEqual(j['status'],'INCOMPLETE_TECHNICAL_EVIDENCE')
   self.assertFalse(j['GO_FREEZE'])
 def test_no_final_label_arms(self):
  self.assertEqual(len(ARMS),4)
  self.assertEqual(set(ARMS),{'OFF_5M','ON_5M_SYNC','OFF_5M_TARGET_LAG_6MS','ON_5M_TARGET_LAG_6MS'})
 def test_source_no_remote_callback(self):
  src=Path(__file__).resolve().parents[1]/'src/hcraf-stage1am-local-snapshot.hpp'
  s=src.read_text();self.assertIn('node_id\\\":1',s)
  self.assertIn('remote_node_queue_accessed\\\":false',s)
 def test_patch_authorized_preimage(self):
  import patch_nfd_stage1am_technical as p
  self.assertEqual(len(p.PINNED_PREIMAGE),2)
  self.assertEqual(p.PINNED_PREIMAGE['forwarder.cpp'],'229ead0fcf35c151c1e9d75d74cc8427cb25ee735558693925882c5a3ecb1cc7')

if __name__=='__main__':unittest.main()
