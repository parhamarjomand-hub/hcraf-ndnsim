#!/usr/bin/env python3
"""Aggregate pilot acceptance without promoting physical drop diagnostic to F3."""
import json,sys
from pathlib import Path
from collections import Counter

ARMS=('OFF_BASELINE','ON_BURST_OVERLAP','ON_BURST_AFTER_TARGET','ON_BURST_TAIL')
SEEDS=(9501,9502,9503)

def summarize(root):
    root=Path(root); rows=[]; errors=[]
    for arm in ARMS:
        for seed in SEEDS:
            p=root/'monitored'/arm/f'run-{seed}'/'stage1am_nonzero_verification.json'
            if not p.exists(): errors.append('missing:'+str(p));continue
            try:
                j=json.loads(p.read_text())
                if j['arm']!=arm or j['rng_run']!=seed or j['status']!='PASS_NONZERO_LOCAL_AND_INDEPENDENT_LOCAL_DROP_PILOT_ONLY':
                    raise ValueError('failed/contradictory run')
                if j['GO_FREEZE'] is not False or j['F3_ready'] is not False or j['training_ready'] is not False or j['FutureCongestion'] is not None:
                    raise ValueError('invalid readiness promotion')
                rows.append(j)
            except Exception as e:errors.append(f'{p}:{e}')
    by_arm={a:{'monitored_runs':sum(x['arm']==a for x in rows),
                'target_nonzero_queue':sum(x['nonzero_target_local_decisions'] for x in rows if x['arm']==a),
                'pilot_pos':sum(x['pilot_positive'] for x in rows if x['arm']==a),
                'pilot_neg':sum(x['pilot_negative'] for x in rows if x['arm']==a),
                'pilot_unknown':sum(x['pilot_unknown'] for x in rows if x['arm']==a)} for a in ARMS}
    if len(rows)!=12:errors.append(f'run coverage: {len(rows)} !=12')
    for a in ('OFF_BASELINE','ON_BURST_AFTER_TARGET'):
        if by_arm[a]['target_nonzero_queue'] or by_arm[a]['pilot_pos']:errors.append('control failure '+a)
    for a in ('ON_BURST_OVERLAP','ON_BURST_TAIL'):
        if by_arm[a]['target_nonzero_queue']<=0 or by_arm[a]['pilot_pos']<=0:errors.append('no real positive '+a)
    # Input-pair stability check MUST inspect original .arrivals.jsonl, not summary statistics.
    for arm in ARMS:
        for seed in SEEDS:
            path=root/'monitored'/arm/f'run-{seed}'
            other=root/'uninstrumented'/arm/f'run-{seed}'
            for name in ('consumer_events.jsonl.arrivals.jsonl','scenario.json'):
                if not (path/name).exists() or not (other/name).exists():
                    errors.append('missing paired '+str(path/name));continue
                if name.endswith('arrivals.jsonl') and (path/name).read_bytes()!=(other/name).read_bytes():
                    errors.append('different target schedule '+arm+str(seed))
            for kind in ('monitored','uninstrumented'):
                if not (root/kind/arm/f'run-{seed}'/'resource_usage.txt').exists():
                    errors.append('missing process runtime '+kind+arm+str(seed))
    for seed in SEEDS:
        try:
            paths=[root/'monitored'/a/f'run-{seed}'/'consumer_events.jsonl.arrivals.jsonl'
                   for a in ('OFF_BASELINE','ON_BURST_OVERLAP','ON_BURST_AFTER_TARGET')]
            if all(p.exists() for p in paths) and len({p.read_bytes() for p in paths})!=1:
                errors.append('Target input schedule not matched across negative/positive controls '+str(seed))
        except Exception as e:errors.append('Cross-arm schedule '+str(seed)+':'+str(e))
    out={'stage':'1AM.NONZERO_PHYSICAL_QUEUE.ORACLE_PILOT.0',
         'status':'PASS_LOCAL_QUEUE_AND_PILOT_DROP_ORACLE_ONLY' if not errors else 'INCOMPLETE_EVIDENCE',
         'by_arm':by_arm,'monitored_pass':len(rows),'paired_total_expected':24,'errors':errors,
         'independent_future_oracle_scoped_to_local_link':True,
         'official_F3_label_count':0,'GO_FREEZE':False,'Congestion':None,
         'FutureCongestion':None,'F3_ready':False,'training_ready':False,
         'ready_for_1AN_freeze':False}
    (root/'summary_stage1am_nonzero.json').write_text(json.dumps(out,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    print(json.dumps(out,sort_keys=True))
    return out

if __name__=='__main__':
    j=summarize(sys.argv[1])
    if j['errors']:raise SystemExit(1)
