#!/usr/bin/env python3
"""Fail-closed full matrix audit. Summary never produces F3 training labels."""
import csv,json,sys
from pathlib import Path
from collections import defaultdict
from verify_stage1am_pathwide import ARMS,SEEDS

TOPO=('DEV_CHAIN_A','DEV_CHAIN_B')
SLOTS=(0,1,2)

def summarize(root):
    root=Path(root);root.mkdir(parents=True,exist_ok=True);errors=[];rows=[]
    for topo in TOPO:
        for slot in SLOTS:
            for arm in ARMS:
                for run in SEEDS:
                    base=root/topo/f'slot-{slot}'
                    m=base/'monitored'/arm/f'run-{run}'
                    u=base/'uninstrumented'/arm/f'run-{run}'
                    p=m/'stage1am_pathwide_verification.json'
                    try:
                        r=json.loads(p.read_text())
                        if (r['topology'],r['slot'],r['arm'],r['rng_run']) != (topo,slot,arm,run):
                            raise ValueError('mismatch run identity')
                        if r['status']!='PASS_PATHWIDE_PHYSICS_AUDIT_ONLY' or any(r[k] is not False for k in
                             ('GO_FREEZE','F3_ready','training_ready')) or r['FutureCongestion'] is not None:
                            raise ValueError('failed/incorrect readiness status')
                        if r['target_decisions']!=12 or sum(r[k] for k in
                            ('pilot_positive','pilot_negative','pilot_unknown'))!=12:
                            raise ValueError('incomplete or fabricated target windows')
                        for kind,path in (('monitored',m),('uninstrumented',u)):
                            sc=json.loads((path/'scenario.json').read_text())
                            if (sc['topology_id'],sc['selected_face_slot'],sc['phase_arm'],sc['run']) != (topo,slot,arm,run):
                                raise ValueError('mismatched paired simulation config')
                            if sc['instrument_enabled'] is not (kind=='monitored'):
                                raise ValueError('incorrect instrument flag')
                            receipts=[json.loads(q) for q in (path/'producer_receipts.jsonl').read_text().splitlines() if q.strip()]
                            if not receipts or any(x['producer_node_id']!=sc['selected_producer_node_id'] for x in receipts):
                                raise ValueError('actual producer receipt leakage across selected Face')
                            if not (path/'resource_usage.txt').is_file():
                                raise ValueError('missing run resource cost')
                        if (m/'consumer_events.jsonl.arrivals.jsonl').read_bytes()!=\
                           (u/'consumer_events.jsonl.arrivals.jsonl').read_bytes():
                            raise ValueError('paired target schedules not exactly equal')
                        if arm in ('OFF_BASELINE','LATE_COMPETITOR') and r['pilot_positive']!=0:
                            raise ValueError('future physical drop false positive in negative control')
                        rows.append(r)
                    except Exception as ex:
                        errors.append(f'{topo}/slot{slot}/{arm}/run{run}: {type(ex).__name__}: {ex}')
                # Same target schedule across all five arms for same topo, slot, run.
            for run in SEEDS:
                paths=[root/topo/f'slot-{slot}'/'monitored'/arm/f'run-{run}'/
                       'consumer_events.jsonl.arrivals.jsonl' for arm in ARMS]
                if all(p.is_file() for p in paths) and len({p.read_bytes() for p in paths})!=1:
                    errors.append(f'matched input changed across arms {topo} slot{slot} run{run}')
    for topo in TOPO:
        for slot in SLOTS:
            def group(arm):return [r for r in rows if r['topology']==topo and r['slot']==slot and r['arm']==arm]
            if len(group('OFF_BASELINE'))!=len(SEEDS):
                errors.append(f'baseline incomplete {topo} slot{slot}')
            if sum(r['target_nonzero_local_queue'] for r in group('LOCAL_FORWARD'))<=0:
                errors.append(f'no nonzero decision-local queue {topo} slot{slot}')
            if sum(r['target_windows_local_link_witness'] for r in group('LOCAL_FORWARD'))<=0:
                errors.append(f'no verified LOCAL-link future Interest drop {topo} slot{slot}')
            if sum(r['selected_relay_forward_drops'] for r in group('RELAY_FORWARD'))<=0:
                errors.append(f'no real remote forward queue drop {topo} slot{slot}')
            if sum(r['target_windows_remote_link_witness'] for r in group('RELAY_FORWARD'))<=0:
                errors.append(f'no verified RELAY-link future Interest drop {topo} slot{slot}')
            if sum(r['selected_reverse_fragment_drops'] for r in group('RETURN_DATA'))<=0:
                errors.append(f'no actual return-path DATA FRAGMENT drop {topo} slot{slot}')
    # No per-decision positives need be independent: overlapping horizons.
    status='PASS_PATHWIDE_PHYSICAL_PILOT_ONLY' if not errors and len(rows)==60 else 'INCOMPLETE_PATHWIDE_EVIDENCE'
    if len(rows)!=60:errors.append(f'run count {len(rows)} expected 60 monitored / 120 all')
    by_cell=[]
    for topo in TOPO:
        for slot in SLOTS:
            for arm in ARMS:
                g=[r for r in rows if (r['topology'],r['slot'],r['arm'])==(topo,slot,arm)]
                by_cell.append({'topology':topo,'slot':slot,'arm':arm,'monitored_pass':len(g),
                    'target_windows':sum(r['target_decisions'] for r in g),
                    'positive':sum(r['pilot_positive'] for r in g),
                    'negative':sum(r['pilot_negative'] for r in g),
                    'unknown':sum(r['pilot_unknown'] for r in g),
                    'nonzero_local_queue':sum(r['target_nonzero_local_queue'] for r in g),
                    'local_forward_drops':sum(r['selected_local_forward_drops'] for r in g),
                    'remote_forward_drops':sum(r['selected_relay_forward_drops'] for r in g),
                    'return_drops':sum(r['selected_reverse_drops'] for r in g),
                    'return_fragment_drops':sum(r['selected_reverse_fragment_drops'] for r in g),
                    'future_local_witness_windows':sum(r['target_windows_local_link_witness'] for r in g),
                    'future_relay_witness_windows':sum(r['target_windows_remote_link_witness'] for r in g),
                    'future_return_unknown_windows':sum(r['target_windows_return_unknown'] for r in g)})
    with (root/'pathwide_matrix_30_cells.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(by_cell[0]));w.writeheader();w.writerows(by_cell)
    out={'stage':'1AM.PATHWIDE_PHYSICAL_ORACLE_PILOT.0','status':status,
        'topologies':list(TOPO),'candidate_faces':3,'monitored_pass':len(rows),
        'paired_run_total_expected':120,'matrix_cells':len(by_cell),
        'targets_total':sum(r['target_decisions'] for r in rows),
        'pilot_positive':sum(r['pilot_positive'] for r in rows),
        'pilot_negative':sum(r['pilot_negative'] for r in rows),
        'pilot_unknown':sum(r['pilot_unknown'] for r in rows),
        'errors':errors,'by_cell':by_cell,
        'no_independent_samples_claim':True,'remote_queue_online_feature':False,
        'label_scope':'DEV only, selected physical path, 50ms verified competitor Interest drop',
        'official_F3_labels':0,'Congestion':None,'FutureCongestion':None,
        'GO_FREEZE':False,'F3_ready':False,'training_ready':False,
        'ready_for_final_1AN':False}
    (root/'summary_stage1am_pathwide.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='by_cell'},sort_keys=True))
    return out

if __name__=='__main__':
    j=summarize(sys.argv[1]);sys.exit(0 if j['status']=='PASS_PATHWIDE_PHYSICAL_PILOT_ONLY' else 1)
