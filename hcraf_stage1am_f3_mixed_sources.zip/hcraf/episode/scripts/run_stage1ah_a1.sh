#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
OUT="$ROOT/episode_output/stage1aha1/DEV_CHAIN_B"
mkdir -p "$OUT"
cd "$ROOT/episode_sources/ns-3"
failed=0
for arm in BASELINE_10M RATE5M_NO_SHIFT RATE5M_TARGET_LAG_6MS RATE5M_COMPETITOR_LAG_2MS; do
  case "$arm" in
    BASELINE_10M) target=0;competitor=0;rate=10000000;;
    RATE5M_NO_SHIFT) target=0;competitor=0;rate=5000000;;
    RATE5M_TARGET_LAG_6MS) target=6000000;competitor=0;rate=5000000;;
    RATE5M_COMPETITOR_LAG_2MS) target=0;competitor=2000000;rate=5000000;;
  esac
  for run in 9101 9102 9103; do
    for monitor in 1 0; do
      if [ "$monitor" -eq 1 ];then kind=monitored;else kind=uninstrumented;fi
      dest="$OUT/$kind/$arm/run-$run"
      mkdir -p "$dest"
      command="hcraf-stage1ah-a1-pilot --mode=LP_INDEPENDENT_COMPETITOR_NO_DROP --topology=DEV_CHAIN_B --selectedSlot=0 --output=$dest --seed=17 --run=$run --instrument=$monitor --lifetimeMs=2600 --requestCount=12 --intervalNs=250000000 --competitorCount=12 --competitorIntervalNs=250000000 --competitorOffsetNs=$competitor --targetOffsetNs=$target --returnBps=$rate"
      printf '%s\n' "$command" > "$dest/command.txt"
      if ! /usr/bin/time -f 'wall_seconds=%e\nuser_seconds=%U\nsystem_seconds=%S\nmax_rss_kib=%M' -o "$dest/resource_usage.txt" \
         python3 ./waf --run-no-build "$command" > "$dest/simulator.log" 2>&1;then
         echo "SIM_FAIL arm=$arm run=$run instrument=$monitor";failed=1;continue
      fi
      if [ "$monitor" -eq 1 ];then
        if ! python3 "$TASK/scripts/episodes_stage1u.py" "$dest" --run-id "1aha1-B-0-$arm-17-$run" > "$dest/episodes.log" 2>&1;then
           echo "EPISODE_FAIL arm=$arm run=$run";failed=1;continue
        fi
        # Baseline is EXPECTED to retain INCOMPLETE target-event; do not soften the original verifier.
        if ! python3 "$TASK/scripts/verify_stage1ah_a1.py" "$dest" --arm "$arm" > "$dest/verify.log" 2>&1;then
           echo "VERIFIER_FAIL arm=$arm run=$run";failed=1
        fi
      fi
    done
  done
done
if ! python3 "$TASK/scripts/summarize_stage1ah_a1.py" "$OUT";then failed=1;fi
exit "$failed"
