#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
OUT="$ROOT/episode_output/stage1am_f3_fragment_aware"
mkdir -p "$OUT"
cd "$ROOT/episode_sources/ns-3"
failed=0
# PRE-REGISTERED fresh E/F split; TEST never used to choose policy/threshold.
for topology in VAL_CHAIN_G TEST_CHAIN_H; do
  if [ "$topology" = VAL_CHAIN_G ];then runs="10021 10022 10023 10024";else runs="10121 10122 10123 10124";fi
  for slot in 0 1 2;do
    for arm in QUIET_CLEAN SPARSE_CLEAN LATE_CLEAN LOCAL_OVERFLOW RELAY_OVERFLOW MID_OVERFLOW RETURN_OVERFLOW;do
      case "$arm" in
        QUIET_CLEAN) count=0;interval=0;offset=0;;
        SPARSE_CLEAN) count=24;interval=50000000;offset=0;;
        LATE_CLEAN) count=160;interval=1000000;offset=900000000;;
        LOCAL_OVERFLOW|RELAY_OVERFLOW|MID_OVERFLOW|RETURN_OVERFLOW)
          count=160;interval=1000000;offset=0;;
        *) echo "BAD_ARM $arm" >&2;exit 4;;
      esac
      forwardrate=50000000
      [ "$arm" != LOCAL_OVERFLOW ] || forwardrate=50000
      for rng in $runs;do
        for instrument in 1 0;do
          if [ "$instrument" = 1 ];then kind=monitored;else kind=uninstrumented;fi
          dest="$OUT/$topology/slot-$slot/$kind/$arm/run-$rng"
          mkdir -p "$dest"
          cmd="hcraf-stage1am-f3-fragment-aware-pilot --pathArm=$arm --topology=$topology --selectedSlot=$slot --mode=LP_INDEPENDENT_COMPETITOR_NO_DROP --seed=17 --run=$rng --output=$dest --instrument=$instrument --lifetimeMs=2600 --requestCount=12 --intervalNs=30000000 --competitorCount=$count --competitorIntervalNs=$interval --competitorOffsetNs=$offset --targetOffsetNs=30000000 --forwardBps=$forwardrate --returnBps=50000000"
          printf '%s\n' "$cmd" > "$dest/command.txt"
          if ! /usr/bin/time -f 'wall_seconds=%e\nuser_seconds=%U\nsystem_seconds=%S\nmax_rss_kib=%M' -o "$dest/resource_usage.txt" \
              python3 ./waf --run-no-build "$cmd" > "$dest/simulator.log" 2>&1;then
            echo "SIM_FAIL $topology/$slot/$arm/$rng/$kind";failed=1;continue
          fi
          if [ "$instrument" = 1 ];then
            if ! python3 "$TASK/scripts/episodes_stage1u.py" "$dest" \
                --run-id "1am_coverage-$topology-$slot-$arm-17-$rng" > "$dest/episodes.log" 2>&1;then
              echo "EPISODE_FAIL $topology/$slot/$arm/$rng";failed=1;continue
            fi
            if ! python3 "$TASK/scripts/f3_fragment_aware_v046.py" "$dest" --topology "$topology" \
                --slot "$slot" --arm "$arm" --run "$rng" > "$dest/verify.log" 2>&1;then
              echo "COVERAGE_VERIFY_FAIL $topology/$slot/$arm/$rng";failed=1
            fi
          fi
        done
      done
    done
  done
  if [ "$topology" = VAL_CHAIN_G ];then
    # Seal scientific design; no Test-driven tuning. Status is not approval.
    if ! python3 "$TASK/scripts/seal_stage1am_f3_fragment_validation.py" "$OUT";then
      echo "NEW_VALIDATION_NOT_SEALED_TEST_MUST_NOT_OPEN";exit 5
    fi
  fi
done
if ! python3 "$TASK/scripts/summarize_stage1am_f3_fragment_aware.py" "$OUT";then failed=1;fi
exit "$failed"
