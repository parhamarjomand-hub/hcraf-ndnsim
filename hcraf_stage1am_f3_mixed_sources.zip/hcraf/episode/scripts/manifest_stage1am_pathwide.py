#!/usr/bin/env python3
"""Always record all raw evidence, including failures, without F3 promotion."""
import hashlib,json,os,platform,sys
from pathlib import Path
from datetime import datetime,timezone
root=Path(sys.argv[1]).resolve();out=root/'episode_output';out.mkdir(exist_ok=True,parents=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files={str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='manifest.json'}
meta={'stage':'1AM.PATHWIDE_PHYSICAL_ORACLE_PILOT.0','created_utc':datetime.now(timezone.utc).isoformat(),
      'github_run_id':os.getenv('GITHUB_RUN_ID'),'github_commit':os.getenv('GITHUB_SHA'),
      'source_zip_sha256':sha(root/'hcraf_stage1am_pathwide_sources.zip') if (root/'hcraf_stage1am_pathwide_sources.zip').exists() else None,
      'reference_zip_sha256':sha(root/'hcraf_stage1s_approved_reference.zip') if (root/'hcraf_stage1s_approved_reference.zip').exists() else None,
      'workflow_sha256':sha(root/'.github/workflows/hcraf-stage1am-pathwide.yml') if (root/'.github/workflows/hcraf-stage1am-pathwide.yml').exists() else None,
      'output_file_sha256':files,'python_version':platform.python_version(),
      'container_image':'ubuntu:20.04 tag; not digest','fully_pinned_environment':False,
      'source_code_scope':'new scratch+python auditors only; 1AM approved lineage unchanged',
      'experiment_unit':'one topology x slot x arm x RNG run; overlapping decision windows correlated',
      'positive_path_drop_not_final_F3':True,'GO_FREEZE':False,
      'Congestion':None,'FutureCongestion':None,'F3_ready':False,
      'training_ready':False,'dataset_generated':False}
(out/'manifest.json').write_text(json.dumps(meta,sort_keys=True,indent=2)+'\n')
