#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
OUT="$ROOT/episode_output/stage1am_technical/DEV_CHAIN_B"
mkdir -p "$OUT"
cd "$ROOT/episode_sources/ns-3"
failed=0
for arm in OFF_5M ON_5M_SYNC OFF_5M_TARGET_LAG_6MS ON_5M_TARGET_LAG_6MS; do
  case "$arm" in
    OFF_5M) comp=0;target=0;;
    ON_5M_SYNC) comp=12;target=0;;
    OFF_5M_TARGET_LAG_6MS) comp=0;target=6000000;;
    ON_5M_TARGET_LAG_6MS) comp=12;target=6000000;;
    *) exit 8;;
  esac
  cint=0;[ "$comp" -eq 0 ] || cint=250000000
  for seed in 9401 9402 9403; do
    for monitor in 1 0; do
      if [ "$monitor" = 1 ];then kind=monitored;else kind=uninstrumented;fi
      dest="$OUT/$kind/$arm/run-$seed"
      mkdir -p "$dest"
      cmd="hcraf-stage1am-online-pilot --topology=DEV_CHAIN_B --selectedSlot=0 --mode=LP_INDEPENDENT_COMPETITOR_NO_DROP --seed=17 --run=$seed --output=$dest --instrument=$monitor --lifetimeMs=2600 --requestCount=12 --intervalNs=250000000 --competitorCount=$comp --competitorIntervalNs=$cint --competitorOffsetNs=0 --targetOffsetNs=$target --returnBps=5000000"
      printf '%s\n' "$cmd" > "$dest/command.txt"
      if ! /usr/bin/time -f 'wall_seconds=%e\nuser_seconds=%U\nsystem_seconds=%S\nmax_rss_kib=%M' -o "$dest/resource_usage.txt" \
        python3 ./waf --run-no-build "$cmd" > "$dest/simulator.log" 2>&1;then
        echo "SIMULATION_FAIL: $arm $seed $monitor";failed=1;continue
      fi
      if [ "$monitor" = 1 ];then
        if ! python3 "$TASK/scripts/episodes_stage1u.py" "$dest" --run-id "1amtech-B-0-$arm-17-$seed" > "$dest/episodes.log" 2>&1;then
          echo "EPISODE_FAIL: $arm $seed";failed=1;continue
        fi
        if ! python3 "$TASK/scripts/verify_stage1am_technical.py" "$dest" --arm "$arm" > "$dest/verify.log" 2>&1;then
          echo "VERIFICATION_FAIL: $arm $seed";failed=1
        fi
      fi
    done
  done
done
if ! python3 "$TASK/scripts/summarize_stage1am_technical.py" "$OUT";then failed=1;fi
exit "$failed"
