#!/usr/bin/env python3
"""Strict retrospective path-wide PHYSICAL drop diagnostic for Stage 1AM.

NOT FutureCongestion, NOT an online Feature, NOT an F3 binary label. A decision
covers 6 physical outgoing TX devices on its selected 3-hop NDN path:
  0 -> 1 -> relay -> producer -> relay -> 1 -> 0.
A positive is a safely decoded independent competitor Interest Queue::Drop
strictly in (decision_t, decision_t+50ms] on ANY of those TX devices. A
negative requires complete recording AND no unclassifiable drop on the path.
Fragmented Data drop with unknown class => UNKNOWN, never guessed by name.
"""
from collections import defaultdict, Counter

HORIZON_NS = 50_000_000
MAX_NS = 20_000_000_000
TOPOLOGIES = {'DEV_CHAIN_A': (5, 6, 7), 'DEV_CHAIN_B': (7, 5, 6)}

class PathOracleError(ValueError):
    pass

def require(ok, msg):
    if not ok: raise PathOracleError(msg)

def physical_path(cfg, inits):
    topo=cfg.get('topology_id');slot=cfg.get('selected_face_slot')
    require(topo in TOPOLOGIES and type(slot) is int and slot in (0,1,2), 'invalid topology/slot')
    relay=2+slot;producer=TOPOLOGIES[topo][slot]
    require(cfg.get('path_nodes')==[0,1,relay,producer], 'path not selected relay/producer')
    # Every key refers to the local physical device transmitting a packet.
    forward=((0,0),(1,slot+1),(relay,1))
    reverse=((producer,0),(relay,0),(1,0))
    require(set(forward).isdisjoint(reverse) and len(set(forward+reverse))==6,'invalid path devices')
    for key in forward+reverse:require(key in inits,'missing selected-path physical device '+str(key))
    require(inits[(1,slot+1)]['face_id']==cfg.get('selected_face_id'), 'selected Face not real TX device')
    require(inits[(1,0)]['face_id']==cfg.get('selected_ingress_face_id',inits[(1,0)]['face_id']),
            'wrong inbound Face')
    return forward,reverse

def oracle(cfg, decisions, locals_, physical):
    require(cfg.get('future_oracle_horizon_ns_pilot')==HORIZON_NS, 'unregistered horizon')
    require(cfg.get('future_oracle_is_final_F3') is False and cfg.get('F3_ready') is False and
            cfg.get('training_ready') is False and cfg.get('future_congestion') is None and
            cfg.get('congestion') is None, 'attempt to promote diagnostic to F3 or leak future')
    seq=[e.get('link_event_seq') for e in physical]
    require(seq==list(range(1,len(seq)+1)), 'missing, duplicated, or rearranged physical event seq')
    inits=[e for e in physical if e.get('event_type')=='INITIAL']
    finals=[e for e in physical if e.get('event_type')=='FINAL']
    def key(e):return e['node_id'],e['device_index']
    init_map={key(e):e for e in inits};final_map={key(e):e for e in finals}
    require(len(inits)==len(finals)==len(init_map)==len(final_map)==14 and
            set(init_map)==set(final_map), 'physical device coverage incomplete')
    require(all(e['time_ns']==0 for e in inits) and
            all(e['time_ns']==MAX_NS for e in finals), 'physical recorder temporal coverage incomplete')
    for e in physical:
        k=key(e)
        require(k in init_map and e.get('face_id')==init_map[k]['face_id'],
                'unregistered or remapped physical Face')
        t=e.get('time_ns')
        require(type(t) is int and 0<=t<=MAX_NS,'invalid physical timestamp')
    forward,reverse=physical_path(cfg,init_map)
    selected={*forward,*reverse}
    paths={'FORWARD':set(forward),'RETURN':set(reverse)}
    selected_drops=[e for e in physical if e['event_type']=='QUEUE_DROP' and key(e) in selected]
    offpath_drops=[e for e in physical if e['event_type']=='QUEUE_DROP' and key(e) not in selected]
    snaps=defaultdict(list)
    for q in locals_:
        require(q.get('remote_node_queue_accessed') is False and
                q.get('future_pressure_label') is None and q.get('Congestion') is None and
                q.get('observed_before_forwarding') is True, 'lookahead/remote feature pollution')
        snaps[q['decision_id']].append(q)
    require(len(decisions)==len({d['decision_id'] for d in decisions}), 'duplicated decision')
    rows=[]
    for d in decisions:
        if not d['name'].startswith('/hcraf/pilot/'):
            continue
        t=d['time_ns'];did=d['decision_id']
        require(type(t) is int and 0<t<MAX_NS,'invalid decision time')
        queue=[q for q in snaps[did] if q['candidate_face_id']==cfg['selected_face_id']]
        require(len(queue)==1 and queue[0]['sim_time_ns']==t,
                'missing or post-decision local selected Face snapshot')
        require(len(snaps[did])==3 and len({q['candidate_face_id'] for q in snaps[did]})==3,
                'incomplete candidate-only online local snapshots')
        q=queue[0]['queue_packets']
        require(type(q) is int and 0<=q<=20,'invalid local queue packets')
        window=[e for e in selected_drops if t<e['time_ns']<=t+HORIZON_NS]
        witnesses=[];unknown=[];target=[];witness_by_link=Counter();unk_by_link=Counter()
        for e in window:
            is_comp=(e.get('wire_status')=='NON_PILOT' and
                e.get('ndn_packet_type')=='INTEREST' and
                e.get('lp_status')=='SINGLE_LP' and
                isinstance(e.get('ndn_name'),str) and
                e['ndn_name'].startswith('/hcraf/competitor/') and
                type(e.get('ndn_nonce')) is int)
            is_target=(e.get('wire_status')=='PILOT' and
                e.get('ndn_packet_type')=='INTEREST' and
                e.get('lp_status')=='SINGLE_LP' and
                isinstance(e.get('ndn_name'),str) and
                e['ndn_name'].startswith('/hcraf/pilot/') and
                type(e.get('ndn_nonce')) is int)
            direction='FORWARD' if key(e) in paths['FORWARD'] else 'RETURN'
            if is_comp:
                witnesses.append(e);witness_by_link[f'{direction}:{e["node_id"]}:{e["device_index"]}']+=1
            elif is_target:
                target.append(e)
            else:
                # Class/corrupted LP/status and partial Data fragment groups
                # are unknown, even if they look like target or competitor.
                unknown.append(e);unk_by_link[f'{direction}:{e["node_id"]}:{e["device_index"]}']+=1
        if t+HORIZON_NS>MAX_NS:
            val='UNKNOWN';why='UNKNOWN_CENSORED_FUTURE_WINDOW'
        elif witnesses:
            val=1;why='VERIFIED_COMPETITOR_INTEREST_DROP_ON_SELECTED_PATH'
        elif unknown:
            val='UNKNOWN';why='UNKNOWN_UNCLASSIFIABLE_DROP_ON_SELECTED_PATH'
        else:
            val=0;why='COMPLETE_PHYSICAL_WINDOW_NO_VERIFIED_COMPETITOR_DROP'
        rows.append({
            'decision_id':did,'pit_instance_id':d['pit_instance_id'],'target_name':d['name'],
            't_decision_ns':t,'horizon_end_ns':t+HORIZON_NS,
            'selected_face_id':cfg['selected_face_id'],'selected_face_slot':cfg['selected_face_slot'],
            'selected_path_nodes':cfg['path_nodes'],
            'selected_local_queue_packets_at_decision':q,
            'pilot_path_future_competitor_interest_drop_50ms':val,'oracle_reason':why,
            'witness_count':len(witnesses),'unknown_drop_count':len(unknown),
            'independent_target_drop_count':len(target),
            'witness_event_seq':[e['link_event_seq'] for e in witnesses],
            'unknown_event_seq':[e['link_event_seq'] for e in unknown],
            'witness_by_direction_device':dict(sorted(witness_by_link.items())),
            'unknown_by_direction_device':dict(sorted(unk_by_link.items())),
            'oracle_is_offline_only':True,'online_remote_queue_feature':False,
            'Congestion':None,'FutureCongestion':None,'F3_ready':False,
            'GO_FREEZE':False,'training_ready':False})
    require(len(rows)==cfg['planned_requests']==12 and
            len({r['target_name'] for r in rows})==12, 'missing/duplicate TARGET decisions')
    def sum_val(k):return sum(r['pilot_path_future_competitor_interest_drop_50ms']==k for r in rows)
    all_types=Counter((e['node_id'],e['device_index']) for e in selected_drops)
    path_tx=Counter((e['node_id'],e['device_index']) for e in physical
                    if e.get('event_type')=='PHY_TX_BEGIN' and key(e) in selected)
    reverse_fragment_drops=sum(key(e) in paths['RETURN'] and
                               e.get('lp_status')=='FRAGMENT' for e in selected_drops)
    return {'stage':'1AM.PATHWIDE_PHYSICAL_ORACLE_PILOT.0',
            'scope':'six selected-path TX interfaces, physical post-decision competitor Interest drop; return Data fragments UNKNOWN',
            'topology':cfg['topology_id'],'selected_face_slot':cfg['selected_face_slot'],
            'forward_tx_devices':[list(k) for k in forward],
            'return_tx_devices':[list(k) for k in reverse],
            'all_14_directed_interfaces_recorded':True,
            'offpath_drop_count':len(offpath_drops),
            'selected_path_tx_begin_by_device':{f'{a}:{b}':v for (a,b),v in sorted(path_tx.items())},
            'reverse_fragment_drop_count':reverse_fragment_drops,
            'selected_path_drop_by_device':{f'{a}:{b}':v for (a,b),v in sorted(all_types.items())},
            'pilot_positive':sum_val(1),'pilot_negative':sum_val(0),'pilot_unknown':sum_val('UNKNOWN'),
            'official_F3_labels':0,'Congestion':None,'FutureCongestion':None,
            'GO_FREEZE':False,'F3_ready':False,'training_ready':False,
            'target_rows':rows}
