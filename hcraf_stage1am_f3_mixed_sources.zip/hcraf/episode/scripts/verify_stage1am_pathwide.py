#!/usr/bin/env python3
"""Registered path-wide NFD and physics audit; NEVER promotes pilot to F3."""
import argparse,json
from collections import defaultdict,Counter
from pathlib import Path
from oracle_stage1am_pathwide import oracle,PathOracleError,TOPOLOGIES

ARMS=('OFF_BASELINE','LOCAL_FORWARD','RELAY_FORWARD','RETURN_DATA','LATE_COMPETITOR')
SEEDS=(9601,9602)

class EvidenceError(ValueError):pass

def require(cond,why):
    if not cond:raise EvidenceError(why)

def read_jsonl(p):
    require(p.is_file(),'required file missing: '+str(p))
    return [json.loads(q) for q in p.read_text().splitlines() if q.strip()]

def singleton(rows,key):
    keys=[r[key] for r in rows]
    require(len(set(keys))==len(keys),'duplicate '+key)
    return {r[key]:r for r in rows}

def check_receipt_nonce_alignment(receipts, sender_files, expected_producer):
    """Numeric receipt nonces must match a transmitted Interest; fail closed."""
    sent={}
    for file in sender_files:
        if not file.is_file():
            continue
        for row in read_jsonl(file):
            if row.get('event')!='SEND':
                continue
            name=row.get('name');nonce=row.get('nonce')
            require(isinstance(name,str) and type(nonce) is int and 0<=nonce<2**32,
                    'invalid Interest SEND identity')
            require(name not in sent or sent[name]==nonce,
                    'contradictory sender nonces for one Interest')
            sent[name]=nonce
    require(bool(sent), 'missing sender SEND evidence for producer receipt')
    require(bool(receipts), 'missing real producer receipts')
    for row in receipts:
        name=row.get('name');nonce=row.get('nonce')
        require(type(nonce) is int and 0<=nonce<2**32,
                'invalid producer receipt nonce: JSON must carry decimal integer')
        require(row.get('producer_node_id')==expected_producer and
                isinstance(name,str) and
                name.startswith(('/hcraf/pilot/','/hcraf/competitor/')) and
                name in sent and sent[name]==nonce,
                'producer receipt does not match actual transmitted Name/Nonce/producer')
        require(type(row.get('time_ns')) is int and row['time_ns']>0,
                'producer receipt timestamp invalid')

def audit(root,topology,slot,arm,seed):
    p=Path(root)
    cfg=json.loads((p/'scenario.json').read_text())
    require(topology in TOPOLOGIES and slot in (0,1,2) and arm in ARMS and seed in SEEDS,
            'wrong registered matrix parameters')
    require(cfg.get('amendment_stage')=='1AM.PATHWIDE_PHYSICAL_ORACLE_PILOT.0' and
            cfg.get('collector_stage')=='1AM.NFD_LOCAL_QUEUE.0', 'wrong source schema')
    require(cfg.get('topology_id')==topology and cfg.get('selected_face_slot')==slot and
            cfg.get('phase_arm')==arm and cfg.get('seed')==17 and cfg.get('run')==seed,
            'wrong source plan')
    faces=cfg.get('eligible_face_ids')
    require(type(faces) is list and len(set(faces))==3 and len(faces)==3 and
            cfg['selected_face_id']==faces[slot] and cfg['path_nodes']==[0,1,2+slot,TOPOLOGIES[topology][slot]],
            'wrong face/path map')
    require(cfg.get('planned_requests')==12 and cfg.get('interest_lifetime_ms')==2600 and
            cfg.get('nominal_arrival_interval_ns')==30_000_000 and
            cfg.get('target_offset_ns')==30_000_000 and cfg.get('stop_ns')==20_000_000_000 and
            cfg.get('queue_capacity_packets')==20 and cfg.get('mtu_bytes')==600,
            'wrong target/queue plan')
    expected_comp=0 if arm=='OFF_BASELINE' else 160
    expected_coff=800_000_000 if arm=='LATE_COMPETITOR' else 0
    expected_local=50_000 if arm=='LOCAL_FORWARD' else 5_000_000
    expected_remote=50_000 if arm=='RELAY_FORWARD' else (10_000_000 if topology=='DEV_CHAIN_A' else 8_000_000)
    expected_reverse=50_000 if arm=='RETURN_DATA' else (10_000_000 if topology=='DEV_CHAIN_A' else 8_000_000)
    require(cfg.get('competitor_planned_requests')==expected_comp and
            cfg.get('competitor_interval_ns')==(0 if not expected_comp else 1_000_000) and
            cfg.get('competitor_offset_ns')==expected_coff and
            cfg.get('selected_forward_bps')==expected_local and
            cfg.get('selected_return_bps')==5_000_000 and
            cfg.get('selected_relay_forward_bps')==expected_remote and
            cfg.get('selected_producer_reverse_bps')==expected_reverse,
            'traffic or bottleneck not preregistered')
    require(cfg.get('future_oracle_scope')==
            'SIX_DIRECTED_DEVICES_SELECTED_PATH_FUTURE_COMPETITOR_INTEREST_DROP_WITH_CENSORING',
            'registered physical oracle coverage changed')
    require(cfg.get('future_oracle_horizon_ns_pilot')==50_000_000 and
            cfg.get('future_oracle_is_final_F3') is False and
            cfg.get('whole_path_oracle_is_retrospective') is True and
            cfg.get('path_reverse_fragment_unclassifiable_means_UNKNOWN') is True and
            cfg.get('path_first_face_is_fib_cost_1') is True,
            'wrong oracle scope or future claims')
    require(cfg.get('instrument_enabled') is True and
            cfg.get('local_NFD_queue_observed_before_send') is True and
            cfg.get('remote_queue_online_feature') is False and
            cfg.get('no_counterfactual_unselected_face') is True and
            cfg.get('actual_assignment_probability')==1.0 and
            cfg.get('F3_ready') is False and cfg.get('training_ready') is False and
            cfg.get('congestion') is None and cfg.get('future_congestion') is None,
            'forbidden readiness/online counterfactual claim')
    dec=read_jsonl(p/'events.jsonl.decisions.jsonl')
    states=read_jsonl(p/'events.jsonl.states.jsonl')
    events=read_jsonl(p/'events.jsonl')
    physical=read_jsonl(p/'link_events.jsonl')
    local=read_jsonl(p/'nfd_local_queue_at_decision.jsonl')
    costs=read_jsonl(p/'nfd_dispatch_cost.jsonl')
    receipts=read_jsonl(p/'producer_receipts.jsonl')
    check_receipt_nonce_alignment(
        receipts, (p/'consumer_events.jsonl', p/'competitor_events.jsonl'),
        cfg['selected_producer_node_id'])
    n=12+expected_comp
    require(len(dec)==len(costs)==n and len(states)==len(local)==3*n,
            'missing NFD decisions, candidate states or CPU timings')
    di=singleton(dec,'decision_id');ci=singleton(costs,'decision_id')
    require(set(di)==set(ci),'NFD timing not attached to decisions')
    inits={(e['node_id'],e['device_index']):e for e in physical if e['event_type']=='INITIAL'}
    require(len(inits)==14,'14 physical devices not initialized')
    phys_shots=[e for e in physical if e['event_type']=='DECISION_SNAPSHOT']
    require(len(phys_shots)==14*n,'14-device per-decision physical snapshots missing')
    pk={(e['decision_id'],e['node_id'],e['device_index']):e for e in phys_shots}
    require(len(pk)==len(phys_shots),'duplicate physical snapshots')
    states_by=defaultdict(list);local_by=defaultdict(list)
    for x in states:states_by[x['decision_id']].append(x)
    for x in local:local_by[x['decision_id']].append(x)
    tx=defaultdict(list)
    for e in events:
        if e.get('event_type')=='TX_INTEREST':tx[e['name']].append(e)
    selected=cfg['selected_face_id']
    for d in dec:
        did=d['decision_id'];t=d['time_ns']
        require(d['node_id']==1 and d.get('anchor')=='BEFORE_AFTER_RECEIVE_INTEREST' and
                d['name'].startswith(('/hcraf/pilot/','/hcraf/competitor/')) and
                {x['face_id'] for x in d['candidates']}==set(faces) and
                next(x['routing_cost'] for x in d['candidates'] if x['face_id']==selected)==1,
                'decision anchor, FIB or selected primary cost changed')
        require(len(local_by[did])==len(states_by[did])==3 and
                {x['candidate_face_id'] for x in local_by[did]}==set(faces) and
                {x['face_id'] for x in states_by[did]}==set(faces),
                'missing/duplicate per-decision Face')
        for x in local_by[did]:
            face=x['candidate_face_id']
            require(x['node_id']==1 and x['sim_time_ns']==t and
                    x['observed_before_forwarding'] is True and
                    x['remote_node_queue_accessed'] is False and
                    x['future_pressure_label'] is None and x['Congestion'] is None and
                    type(x['queue_packets']) is int and 0<=x['queue_packets']<=20,
                    'invalid or future local snapshot')
            k=(1,x['device_index']);initial=inits.get(k)
            phys=pk.get((did,1,x['device_index']))
            require(initial is not None and phys is not None and
                    initial['face_id']==face==phys['face_id'] and
                    initial['data_rate_bps']==x['data_rate_bps']==phys['data_rate_bps'] and
                    phys['time_ns']==t and x['queue_packets']==phys['queue_packets'] and
                    x['queue_bytes']==phys['queue_bytes'],
                    'independent local queue/Face physics mismatch')
        for s in states_by[did]:
            require(s['time_ns']==t and s['after_event_seq']==d['after_event_seq'] and
                    s['max_terminal_event_seq']<=d['after_event_seq'] and
                    s['Congestion'] is None,'future NFD state entered decision')
        for k,init in inits.items():
            row=pk.get((did,*k))
            require(row is not None and row['time_ns']==t and
                    row['face_id']==init['face_id'] and row['data_rate_bps']==init['data_rate_bps'],
                    'missing/forged one of the 14 physical snapshots')
        require(len(tx[d['name']])==1 and tx[d['name']][0]['face_id']==selected and
                tx[d['name']][0]['pit_instance_id']==d['pit_instance_id'] and
                tx[d['name']][0]['time_ns']>=t and
                tx[d['name']][0]['event_seq']>d['after_event_seq'],
                'wrong selected Face or no actual post-decision forwarding')
        c=ci[did]
        require(type(c['NFD_forwarding_path_wall_ns']) is int and
                c['NFD_forwarding_path_wall_ns']>0 and
                type(c['NFD_forwarding_path_cpu_ns']) is int and
                c['NFD_forwarding_path_cpu_ns']>=0 and
                c.get('includes_telemetry_and_recorder') is True and
                c.get('is_HCRAF_Gate_only_cost') is False,
                'false C++ Gate latency or malformed dispatch timing')
    details=oracle(cfg,dec,local,physical)
    r=details['target_rows']
    nonzero=sum(x['selected_local_queue_packets_at_decision']>0 for x in r)
    selected=Counter()
    for k,v in details['selected_path_drop_by_device'].items():selected[k]=v
    forward=details['forward_tx_devices'];reverse=details['return_tx_devices']
    def drops(keys):return sum(selected[f'{a}:{b}'] for a,b in keys)
    local_forward=drops(forward[1:2])
    relay_forward=drops(forward[2:3])
    return_drops=drops(reverse)
    local_witness=sum(x['witness_by_direction_device'].get(f'FORWARD:1:{slot+1}',0)>0 for x in r)
    relay_witness=sum(x['witness_by_direction_device'].get(f'FORWARD:{2+slot}:1',0)>0 for x in r)
    return_unknown=sum(any(k.startswith('RETURN:') for k in x['unknown_by_direction_device']) for x in r)
    if arm=='OFF_BASELINE':
        require(all(details['selected_path_tx_begin_by_device'].get(f'{a}:{b}',0)>0
                    for a,b in forward+reverse),
                'baseline has no physically transmitted packet on one selected-path direction')
    # Control must not manufacture competitor-drop positives.
    if arm in ('OFF_BASELINE','LATE_COMPETITOR'):
        require(details['pilot_positive']==0,'false control positives')
    result={'stage':'1AM.PATHWIDE_PHYSICAL_ORACLE_PILOT.0','status':'PASS_PATHWIDE_PHYSICS_AUDIT_ONLY',
        'topology':topology,'slot':slot,'arm':arm,'rng_run':seed,
        'NFD_decisions':n,'NFD_candidate_snapshot_rows':3*n,
        'physical_snapshot_rows':14*n,'target_decisions':12,
        'target_nonzero_local_queue':nonzero,
        'actual_selected_producer_receipts':len(receipts),
        'selected_local_forward_drops':local_forward,
        'selected_relay_forward_drops':relay_forward,
        'selected_reverse_drops':return_drops,
        'selected_reverse_fragment_drops':details['reverse_fragment_drop_count'],
        'target_windows_local_link_witness':local_witness,
        'target_windows_remote_link_witness':relay_witness,
        'target_windows_return_unknown':return_unknown,
        'pilot_positive':details['pilot_positive'],
        'pilot_negative':details['pilot_negative'],
        'pilot_unknown':details['pilot_unknown'],
        'GO_FREEZE':False,'Congestion':None,'FutureCongestion':None,
        'F3_ready':False,'training_ready':False,
        'measured_latency_scope':'NFD dispatch incl telemetry, NOT HCRAF Gate',
        'limitations':['physical retrospective selected path only','fragment class censoring',
                       'forced action probability 1','no generalization beyond dev matrix']}
    (p/'stage1am_pathwide_oracle.json').write_text(json.dumps(details,sort_keys=True,indent=2)+'\n')
    (p/'stage1am_pathwide_verification.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    return result

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('run_directory');a.add_argument('--topology',required=True)
    a.add_argument('--slot',type=int,required=True);a.add_argument('--arm',required=True)
    a.add_argument('--seed',type=int,required=True);q=a.parse_args()
    print(json.dumps(audit(q.run_directory,q.topology,q.slot,q.arm,q.seed),sort_keys=True))
