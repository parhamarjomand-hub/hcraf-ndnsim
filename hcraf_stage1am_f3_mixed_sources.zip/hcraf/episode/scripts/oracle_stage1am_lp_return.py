#!/usr/bin/env python3
"""Stage 1AM v0.42.0: fail-closed, retrospective, sender-side LP DATA drop identity.

This tool is deliberately NOT FutureCongestion, F3, an online feature or a
training-label generator. Source evidence: QUEUE_ENQUEUE and QUEUE_DROP only.
MAC_RX is insufficient for a dropped fragment, and historical v0.41.1 traces
lack sender-side fragment payloads. Return path is identified from the real
selected topology/Face; other interfaces never contribute to a label.
"""
from collections import Counter, defaultdict
import hashlib
import re

from oracle_stage1am_pathwide import HORIZON_NS, MAX_NS, physical_path

MAX_FRAGMENT_BYTES = 8192
MAX_GROUP_FRAGMENTS = 32
MAX_NETWORK_BYTES = 262144
UINT64 = 1 << 64
PREFIXES = ('/hcraf/pilot/', '/hcraf/competitor/')
HEX = re.compile(r'^(?:[0-9a-f]{2})*$')

class GroupEvidenceError(ValueError):
    pass

def require(cond, message):
    if not cond:
        raise GroupEvidenceError(message)

def varnum(data, offset, end):
    require(offset < end, 'truncated TLV varnum')
    a = data[offset]
    offset += 1
    if a < 253:
        return a, offset
    width = {253: 2, 254: 4, 255: 8}[a]
    require(offset + width <= end, 'truncated TLV varnum payload')
    value = int.from_bytes(data[offset:offset + width], 'big')
    require((width == 2 and value >= 253) or
            (width == 4 and value > 65535) or
            (width == 8 and value > 4294967295), 'noncanonical TLV varnum')
    return value, offset + width

def tlv(data, offset, end):
    typ, offset = varnum(data, offset, end)
    length, offset = varnum(data, offset, end)
    require(length <= end - offset, 'TLV length exceeds buffer')
    return typ, offset, offset + length

def pct(c):
    if (65 <= c <= 90 or 97 <= c <= 122 or 48 <= c <= 57 or
            c in b'-._~'):
        return chr(c)
    return '%%%02X' % c

def parse_network_data(data):
    """Return Name only for one entirely decoded canonical NDN DATA TLV."""
    if not isinstance(data, bytes) or not (5 <= len(data) <= MAX_NETWORK_BYTES):
        return None, 'INVALID_NETWORK_BYTES'
    try:
        typ, start, end = tlv(data, 0, len(data))
        require(typ == 6 and end == len(data), 'not exactly one DATA TLV')
        pos = start
        names = []
        expected_fields = {7: 0, 20: 0, 21: 0, 22: 0, 23: 0}
        content_length = None
        while pos < end:
            k, s, e = tlv(data, pos, end)
            if k in expected_fields:
                expected_fields[k] += 1
                require(expected_fields[k] == 1, 'duplicate registered Data TLV field')
            if k == 21:
                content_length = e - s
            if k == 7:
                components = []
                p = s
                while p < e:
                    ct, cs, ce = tlv(data, p, e)
                    require(ct == 8 and ce - cs <= 4096, 'unsupported Name component')
                    components.append(''.join(pct(x) for x in data[cs:ce]))
                    p = ce
                require(0 < len(components) <= 64, 'invalid NDN Name')
                names.append('/' + '/'.join(components))
            pos = e
        require(len(names) == 1 and all(n == 1 for n in expected_fields.values()) and
                content_length == 4096, 'missing Data field or wrong controlled payload size')
        return names[0], None
    except (GroupEvidenceError, IndexError, KeyError, ValueError):
        return None, 'INVALID_OR_UNSUPPORTED_DATA_TLV'

def event_key(e):
    return e['node_id'], e['device_index']

def group_key(e):
    return (e['node_id'], e['device_index'], e['lp_group_start_seq'])

def parse_evidence_fragment(e):
    require(e.get('lp_status') == 'FRAGMENT', 'not a grouped LP fragment')
    cnt = e.get('lp_frag_count'); idx = e.get('lp_frag_index')
    start = e.get('lp_group_start_seq'); seq = e.get('lp_seq')
    require(type(cnt) is int and 2 <= cnt <= MAX_GROUP_FRAGMENTS and
            type(idx) is int and 0 <= idx < cnt and
            type(start) is int and 0 <= start < UINT64 and
            type(seq) is int and 0 <= seq < UINT64 and
            seq == (start + idx) % UINT64, 'inconsistent LP group Sequence/Index/Count')
    raw = e.get('lp_fragment_hex')
    if raw is None:
        return None
    require(isinstance(raw, str) and len(raw) <= 2 * MAX_FRAGMENT_BYTES and
            HEX.fullmatch(raw) is not None, 'invalid sender-side fragment hex')
    return bytes.fromhex(raw)

def classify_name(name, receipt_names):
    if name not in receipt_names:
        return 'UNKNOWN_NAME_NOT_ATTESTED_BY_PRODUCER'
    if name.startswith(PREFIXES[0]) and len(name) > len(PREFIXES[0]):
        return 'TARGET_DATA'
    if name.startswith(PREFIXES[1]) and len(name) > len(PREFIXES[1]):
        return 'COMPETITOR_DATA'
    return 'UNKNOWN_NAME_OUTSIDE_REGISTERED_CLASSES'

def group_inventory(events, return_devices, receipts):
    """Build per-sender groups using source QUEUE_ENQUEUE + QUEUE_DROP.

    Missing index/hex means UNKNOWN. Conflicting seq/count/payload is a
    fatal integrity error, never zero. Data Name must be in a real producer
    receipt. The Data packet has no Interest Nonce; receipts bind the request.
    """
    receipt_names = set()
    for r in receipts:
        name = r.get('name')
        require(isinstance(name, str) and
                type(r.get('nonce')) is int and 0 <= r['nonce'] < (1<<32) and
                type(r.get('time_ns')) is int and r['time_ns'] > 0,
                'bad producer receipt identity')
        require(name not in receipt_names, 'duplicate producer receipt Name')
        receipt_names.add(name)
    groups = {}
    for e in events:
        if (e.get('event_type') not in ('QUEUE_ENQUEUE', 'QUEUE_DROP') or
                event_key(e) not in return_devices or
                e.get('lp_status') != 'FRAGMENT'):
            continue
        key = group_key(e)
        cnt = e.get('lp_frag_count');idx = e.get('lp_frag_index')
        part = parse_evidence_fragment(e)
        entry = groups.setdefault(key, {'count': cnt, 'parts': {}, 'missing': set(),
                                        'events': [], 'dropped_events': []})
        require(entry['count'] == cnt, 'conflicting fragment-count for group identity')
        entry['events'].append(e['link_event_seq'])
        if e['event_type'] == 'QUEUE_DROP':
            entry['dropped_events'].append(e['link_event_seq'])
        if part is None:
            entry['missing'].add(idx)
        else:
            prev = entry['parts'].get(idx)
            require(prev is None or prev == part, 'contradictory LP content for one fragment index')
            entry['parts'][idx] = part
    result = {}
    for key, e in groups.items():
        if e['missing'] or len(e['parts']) != e['count']:
            kind = 'UNKNOWN_INCOMPLETE_SENDER_GROUP'
            name = None
            digest = None
        else:
            raw = b''.join(e['parts'][i] for i in range(e['count']))
            require(len(raw) <= MAX_NETWORK_BYTES, 'reassembled packet exceeds registered bounds')
            name, reason = parse_network_data(raw)
            kind = classify_name(name, receipt_names) if name else (reason or 'UNKNOWN_INVALID_DATA')
            digest = hashlib.sha256(raw).hexdigest()
        result[key] = {'class': kind, 'name': name, 'sha256': digest,
                       'frag_count': e['count'], 'fragment_indices': sorted(e['parts']),
                       'missing_indices': sorted(set(range(e['count'])) - set(e['parts']) | e['missing']),
                       'dropped_event_seqs': e['dropped_events']}
    return result

def oracle_group(cfg, decisions, physical, receipts, legacy_rows):
    """Retrospective independent diagnostic; NEVER overwrite 1AM legacy rows."""
    require(cfg.get('future_oracle_is_final_F3') is False and
            cfg.get('F3_ready') is False and cfg.get('training_ready') is False and
            cfg.get('congestion') is None and cfg.get('future_congestion') is None and
            cfg.get('remote_queue_online_feature') is False and
            cfg.get('future_oracle_horizon_ns_pilot') == HORIZON_NS,
            'missing pilot-NO-GO or attempted online data leakage')
    inits = {(e['node_id'], e['device_index']):e for e in physical
             if e.get('event_type') == 'INITIAL'}
    forward, reverse = physical_path(cfg, inits)
    selected_returns = set(reverse)
    seqs = [e.get('link_event_seq') for e in physical]
    require(seqs == list(range(1,len(seqs)+1)), 'missing/reordered physical event seq')
    final = {(e['node_id'],e['device_index']): e for e in physical
             if e.get('event_type') == 'FINAL'}
    require(len(inits) == len(final) == 14 and set(inits) == set(final) and
            all(x.get('time_ns') == MAX_NS for x in final.values()),
            'incomplete physical horizon or device coverage')
    group_info = group_inventory(physical, selected_returns, receipts)
    returns = [e for e in physical if e.get('event_type') == 'QUEUE_DROP' and
               event_key(e) in selected_returns]
    drows = [d for d in decisions if d.get('name','').startswith(PREFIXES[0])]
    require(len(drows) == 12 and len(legacy_rows)==12 and
            set(d['decision_id'] for d in drows) == set(r['decision_id'] for r in legacy_rows),
            'wrong decision/pilot windows')
    legacy_by_id={r['decision_id']:r for r in legacy_rows}
    drop_classes = {}
    for e in returns:
        seq = e['link_event_seq']
        if e.get('lp_status') == 'FRAGMENT':
            g = group_info.get(group_key(e))
            kind = g['class'] if g else 'UNKNOWN_NO_SENDER_GROUP'
        else:
            # A fully decodable nonfragmented Data could be added later, but
            # must never be falsely accepted by this FRAGMENT-only contract.
            kind='UNKNOWN_NONFRAGMENT_RETURN_DROP'
        drop_classes[seq] = kind
    rows=[]
    for d in drows:
        t=d['time_ns']
        require(type(t) is int and 0 < t < MAX_NS, 'bad decision timestamp')
        future = [e for e in returns if t < e['time_ns'] <= t + HORIZON_NS]
        classified = Counter(drop_classes[e['link_event_seq']] for e in future)
        competitor = sum(n for k,n in classified.items() if k=='COMPETITOR_DATA')
        target = sum(n for k,n in classified.items() if k=='TARGET_DATA')
        unknown = sum(n for k,n in classified.items() if k not in ('COMPETITOR_DATA','TARGET_DATA'))
        if t + HORIZON_NS > MAX_NS:
            status = 'UNKNOWN_CENSORED_FUTURE_WINDOW'
        elif unknown:
            status = 'UNKNOWN_CONCURRENT_UNRESOLVED_GROUP'
        elif competitor:
            status = 'OBSERVED_COMPETITOR_DATA_FRAGMENT_DROP'
        elif target:
            status = 'OBSERVED_TARGET_DATA_FRAGMENT_DROP_ONLY'
        else:
            status = 'COMPLETE_WINDOW_NO_RETURN_FRAGMENT_DROP'
        old=legacy_by_id[d['decision_id']]
        rows.append({'decision_id': d['decision_id'], 'name': d['name'],
            'decision_ns': t, 'horizon_end_ns': t+HORIZON_NS,
            'selected_face_id':cfg['selected_face_id'],
            'old_oracle_class':old['pilot_path_future_competitor_interest_drop_50ms'],
            'old_oracle_reason':old['oracle_reason'],
            'new_return_data_diagnostic':status,
            'known_competitor_DATA_drops':competitor,
            'known_target_DATA_drops':target,
            'unresolved_return_drops':unknown,
            'drop_event_seqs':[e['link_event_seq'] for e in future],
            'is_retrospective':True, 'FutureCongestion':None, 'F3_ready':False,
            'GO_FREEZE':False, 'training_ready':False})
    require(len(rows) == 12, 'wrong target row count')
    return {'stage':'1AM.LP_RETURN_GROUP_PROVENANCE_PILOT.0',
            'status':'DIAGNOSTIC_ONLY_NO_F3_PROMOTION',
            'source':'sender QUEUE_ENQUEUE and QUEUE_DROP LP payload, independent producer receipt Names',
            'physical_return_selected_devices':[list(k) for k in reverse],
            'physical_forward_selected_devices':[list(k) for k in forward],
            'selected_return_drop_count':len(returns),
            'selected_return_fragment_drop_count':sum(x.get('lp_status')=='FRAGMENT' for x in returns),
            'sender_lp_groups_observed':len(group_info),
            'sender_lp_groups_complete_attributed':sum(v['class'] in ('COMPETITOR_DATA','TARGET_DATA') for v in group_info.values()),
            'sender_lp_groups_unresolved':sum(v['class'] not in ('COMPETITOR_DATA','TARGET_DATA') for v in group_info.values()),
            'drop_by_class':dict(sorted(Counter(drop_classes.values()).items())),
            'target_windows':rows,
            'official_F3_labels':0, 'Congestion':None, 'FutureCongestion':None,
            'GO_FREEZE':False, 'F3_ready':False, 'training_ready':False,
            'no_statistical_independence_claim':True,
            'no_online_remote_queue_claim':True,
            'no_held_out_generalization_claim':True}
