#!/usr/bin/env python3
"""Stage 1AJ: physically attributed service-pressure audit, DEVELOPMENT ONLY.

Observed sender PHY busy intervals must overlap the TARGET FRAGMENT queue WAIT interval
(not merely the target group's wide [first enqueue,last PHY_END] epoch).
Only complete reassembled NDN Data, true PIT matches and same-device physical service
may provide a class attribution; otherwise it is UNKNOWN, never 'no congestion'.
"""
import argparse
import json
from collections import defaultdict, Counter
from pathlib import Path
from verify_stage1af import require
from verify_stage1ah import (read, recovered_groups, build_sender_index,
     queue_group_metrics, lifecycle, overlap, union_length, traffic_class)

STAGE='1AJ.PAIRED_INTERVENTION.0'
ARMS={
 'OFF_10M':(10_000_000,0,0,0),
 'ON_10M':(10_000_000,12,0,0),
 'OFF_5M':(5_000_000,0,0,0),
 'ON_5M_SYNC':(5_000_000,12,0,0),
 'OFF_5M_TARGET_LAG_6MS':(5_000_000,0,6_000_000,0),
 'ON_5M_TARGET_LAG_6MS':(5_000_000,12,6_000_000,0),
 'ON_5M_COMPETITOR_LAG_2MS':(5_000_000,12,0,2_000_000),
}
RUNS=(9201,9202,9203)

def load_config(root,expected_arm=None):
    root=Path(root);cfg=json.loads((root/'scenario.json').read_text())
    a=cfg.get('phase_arm')
    require(a in ARMS and (expected_arm is None or a==expected_arm),'Wrong preregistered arm')
    rate,ncomp,to,co=ARMS[a]
    require(cfg.get('amendment_stage')==STAGE and
            cfg.get('collector_stage')=='1AJ.PHYSICAL_PRESSURE.0', 'Wrong provenance')
    require(cfg.get('topology_id')=='DEV_CHAIN_B' and
            cfg.get('selected_face_slot')==0 and
            cfg.get('selected_face_id')==cfg.get('eligible_face_ids',[None])[0] and
            len(set(cfg.get('eligible_face_ids',[])))==3 and
            cfg.get('path_nodes')==[0,1,2,7] and cfg.get('selected_relay_node_id')==2,
            'Wrong real topology / Face mapping')
    require(cfg.get('run') in RUNS and cfg.get('seed')==17 and
            cfg.get('mode')=='LP_INDEPENDENT_COMPETITOR_NO_DROP' and
            cfg.get('selected_return_bps')==rate and
            cfg.get('competitor_planned_requests')==ncomp and
            cfg.get('competitor_injection_enabled') is bool(ncomp) and
            cfg.get('competitor_interval_ns')==(250_000_000 if ncomp else 0) and
            cfg.get('target_offset_ns')==to and cfg.get('competitor_offset_ns')==co and
            cfg.get('planned_requests')==12 and
            cfg.get('nominal_arrival_interval_ns')==250_000_000 and
            cfg.get('interest_lifetime_ms')==2600 and
            cfg.get('mtu_bytes')==600 and cfg.get('payload_bytes')==4096 and
            cfg.get('selected_forward_bps')==10_000_000 and cfg.get('stop_ns')==20_000_000_000 and
            cfg.get('cache_enabled') is False and cfg.get('multi_hop_enabled') is True,
            'Wrong pinned traffic, rate or monitoring contract')
    require(cfg.get('instrument_enabled') is True and
            cfg.get('actual_assignment_probability')==1.0 and
            cfg.get('no_counterfactual_unselected_face') is True and
            cfg.get('independent_physical_pressure_test') is True and
            cfg.get('paired_target_arrivals_must_match') is True,
            'Physical experiment not traceable as controlled nonpolicy intervention')
    require(cfg.get('congestion') is None and cfg.get('future_congestion') is None and
            cfg.get('F3_ready') is False and cfg.get('training_ready') is False and
            cfg.get('decision_time_us_real_HCRAF') is None and
            cfg.get('observer_cost_is_decision_time') is False,
            'Forbidden training labels or online/future leakage')
    for filename,prefix,klass,count,offset,stream in (
       ('consumer_events.jsonl','/hcraf/pilot/','TARGET',12,to,129),
       ('competitor_events.jsonl','/hcraf/competitor/','INDEPENDENT_COMPETITOR',ncomp,co,139)):
        if count==0:
            require(not (root/filename).exists() and not (root/(filename+'.arrivals.jsonl')).exists(),
                    'OFF arm must not secretly inject competitor')
            continue
        events=read(root/filename);arrivals=read(root/(filename+'.arrivals.jsonl'))
        sends=[x for x in events if x.get('event')=='SEND']
        require(len(sends)==len(arrivals)==count, 'Missing planned sends or arrival records')
        for i,(a0,e) in enumerate(zip(arrivals,sends)):
            t=2_000_000_000+offset+i*250_000_000+a0.get('jitter_ns',-1)
            require(a0.get('sequence')==i and
                    isinstance(a0.get('jitter_ns'),int) and 0<=a0['jitter_ns']<100000 and
                    a0.get('stream')==stream and a0.get('traffic_class')==klass and
                    a0.get('time_ns')==t and e.get('time_ns')==t and
                    e.get('traffic_class')==klass and
                    e.get('name')==prefix+str(i),
                    'Wrong actual target/competitor schedule/Nonce provenance')
    return a,cfg


def exogenous_physical_busy(target_queues, all_service, known_class):
    """For each target queue WAIT interval, union physically verified foreign TX busy.

    No overlap with TARGET's own service epoch is required; this is independent
    of broad-group M3.  Class is known ONLY if foreign packet belongs to a fully
    reconstructed NDN Data group with an unambiguous NFD PIT binding.
    """
    intervals=[];unknown=0
    for q,enq,tb,te in target_queues:
        t0,t1=enq['time_ns'],q['time_ns']
        require(t0<=t1<=tb['time_ns']<=te['time_ns'], 'Bad physical wait boundary')
        for s,e,k,uid in all_service:
            if overlap(t0,t1,s,e)<=0:continue
            if uid==q['packet_uid']:continue
            cls=known_class.get(uid)
            if cls=='INDEPENDENT_COMPETITOR':
                intervals.append((max(t0,s),min(t1,e)))
            elif cls is None:unknown+=1
            # TARGET traffic is not the injected competitor, even if from other group
    return union_length(intervals),unknown


def audit(root,expected_arm=None):
    root=Path(root)
    arm,cfg=load_config(root,expected_arm)
    face=cfg['selected_face_id'];ncomp=cfg['competitor_planned_requests']
    targets=read(root/'consumer_events.jsonl')
    competitors=read(root/'competitor_events.jsonl') if ncomp else []
    link=read(root/'link_events.jsonl'); nfd=read(root/'events.jsonl')
    require(all(x.get('schema_version')=='1W.0' and x.get('link_event_seq')==i
                for i,x in enumerate(link,1)), 'Link sequence/schema corruption')
    init={(x['node_id'],x['device_index']) for x in link if x['event_type']=='INITIAL'}
    final={(x['node_id'],x['device_index']) for x in link if x['event_type']=='FINAL'}
    require(len(init)==14 and init==final,'Missing complete 14-direction physical trace')
    sends=[x for x in targets+competitors if x.get('event')=='SEND']
    observed=[x for x in nfd if x.get('event_type')=='TX_INTEREST']
    require(len(observed)==len(sends) and {x['name'] for x in observed}=={x['name'] for x in sends}
            and all(x.get('face_id')==face for x in observed),
            'Missing NFD send on actual selected Face (both classes)')
    eps=read(root/'episodes.jsonl');byname={x['name']:x for x in eps}
    require(len(eps)==len(byname)==len(sends) and set(byname)=={x['name'] for x in sends},
            'Incomplete or duplicated PIT Episode ledger')
    require(all(x.get('outcome') in ('SUCCESS','TIMEOUT','NACK','CANCELLED') for x in eps),
            'Unclosed Episode')
    sender_node=2
    rx,invalid=recovered_groups(link,1,face)
    by_uid=build_sender_index(link)
    # A received group's sender must be uniquely identifiable on the actual return path.
    ret_devs={x['device_index'] for x in link if x['event_type']=='INITIAL' and
              x['node_id']==sender_node and x.get('face_id') is not None}
    require(ret_devs,'Missing actual relay device')
    group_sources={}
    for g in rx:
        matches=[]
        for dev in ret_devs:
            qs=[x for x in link if x['event_type']=='QUEUE_DEQUEUE' and
                x['node_id']==sender_node and x['device_index']==dev and
                x.get('lp_status')=='FRAGMENT' and x.get('lp_group_start_seq')==g['start_seq']]
            if len(qs)==len(g['rx']):matches.append((dev,qs))
        require(len(matches)==1,'Ambiguous complete fragment return source')
        group_sources[g['start_seq']]=matches[0]
    # Sender-side fragmented groups without a complete receiver/NFD join are NOT zero.
    sender_groups={(x['node_id'],x['device_index'],x['lp_group_start_seq']) for x in link
       if x.get('node_id')==sender_node and x.get('event_type') in ('QUEUE_ENQUEUE','QUEUE_DROP')
       and x.get('lp_status')=='FRAGMENT' and type(x.get('lp_group_start_seq'))==int}
    confirmed_sender_groups={(sender_node,dev,seq) for seq,(dev,qs) in group_sources.items()}
    sender_orphans=sorted(sender_groups-confirmed_sender_groups)
    # Compute fully attributed physical service set (class only from received Data + PIT).
    known_bydev=defaultdict(dict);group_records=[]
    for g in rx:
        dev,qs=group_sources[g['start_seq']]
        matches=[x for x in nfd if x.get('event_type')=='DATA_PIT_BIND_1U' and
                 x.get('name')==g['name'] and x.get('time_ns')==g['recv_time_ns'] and
                 x.get('face_id')==face]
        if len(matches)!=1:continue
        for q in qs:
            uid=q['packet_uid']
            require(uid not in known_bydev[dev],'Packet UID class collision')
            known_bydev[dev][uid]=g['traffic_class']
    serviced=defaultdict(list)
    for (node,dev,uid),events in by_uid.items():
        if node!=sender_node or dev not in ret_devs:continue
        if len(events['PHY_TX_BEGIN'])==len(events['PHY_TX_END'])==1:
            a,b=events['PHY_TX_BEGIN'][0],events['PHY_TX_END'][0]
            require(a['time_ns']<=b['time_ns'],'Negative physical service duration')
            serviced[dev].append((a['time_ns'],b['time_ns'],(node,dev),uid))
    for g in rx:
        dev,qs=group_sources[g['start_seq']]
        g['receiver_face']=face
        gm=queue_group_metrics(g,link,sender_node,dev,by_uid,nfd,
             {(sender_node,dev,uid):cls for uid,cls in known_bydev[dev].items()})
        target_queues=[]
        for q in sorted(qs,key=lambda x:x['lp_frag_index']):
            enq,tb,te=lifecycle(q,by_uid)
            target_queues.append((q,enq,tb,te))
        foreign_ns,unk=exogenous_physical_busy(target_queues,serviced[dev],known_bydev[dev])
        ep=byname.get(g['name']);require(ep is not None,'Complete group without PIT Episode')
        valid=bool(unk==0 and gm['matched_nfd_pit'] and ep['outcome']=='SUCCESS' and
                   ep.get('delay_valid') and len(target_queues)==len(g['rx']) and
                   ep['start_ns']<=gm['first_enqueue_ns'] and
                   gm['last_phy_tx_end_ns']<=ep['end_ns'])
        group_records.append({'name':g['name'],'traffic_class':g['traffic_class'],
          'evidence_complete':valid,'sender_node':sender_node,'sender_device':dev,
          'queue_drops_attributable':0,'physical_competitor_busy_during_target_wait_ns':
             foreign_ns if valid and unk==0 else None,'unattributed_busy_intervals_count':unk,
          'raw_max_wait_ns':gm['raw_max_queue_wait_ns'] if valid else None,
          'first_fragment_wait_ns':gm['first_fragment_wait_ns'] if valid else None,
          'M3_group_epoch_overlap':gm['M3_observed_exogenous_service'] if valid else None,
          'M3_confirmed_competitor_service_overlap_count':
               gm['verified_competitor_service_overlap_count'] if valid else None,
          'episode_delay_ns':ep.get('delay_ns') if valid else None,
          'start_ns':ep['start_ns'],'end_ns':ep['end_ns'],
          'congestion':None,'future_congestion':None,'F3_ready':False,'training_ready':False})
    # Unreassembled fragments, class unknown drops and incomplete PIT NEVER become negative.
    recovered={x['name'] for x in group_records if x['evidence_complete']}
    unknown=[x['name'] for x in eps if x['name'] not in recovered]
    drop=[x for x in link if x['event_type']=='QUEUE_DROP' and x.get('node_id')==sender_node and
          x.get('device_index') in ret_devs and x.get('lp_status')=='FRAGMENT']
    target_gr=[x for x in group_records if x['traffic_class']=='TARGET' and x['evidence_complete']]
    complete = (not invalid and not sender_orphans and not unknown and not drop and
                len(target_gr)==12 and len(group_records)==12+ncomp)
    status = 'COMPLETE_PHYSICAL_OBSERVATION' if complete else 'INCOMPLETE_PHYSICAL_OBSERVATION'
    result={'stage':STAGE,'arm':arm,'rng_run':cfg['run'],'status':status,
      'n_target':12,'n_competitor':ncomp,'observed_episodes':len(eps),
      'observed_completed_groups':len(group_records),'verified_target_groups':len(target_gr),
      'unknown_episode_names':unknown,'incomplete_fragment_groups':len(invalid),
      'sender_fragment_groups_without_complete_rx':len(sender_orphans),
      'unattributed_return_queue_drops':len(drop),
      'target_M3_overlap_groups':sum(x['M3_group_epoch_overlap'] is True for x in target_gr),
      'target_foreign_busy_positive_groups':sum(x['physical_competitor_busy_during_target_wait_ns']>0
         for x in target_gr if x['physical_competitor_busy_during_target_wait_ns'] is not None),
      'target_total_foreign_busy_ns':sum(x['physical_competitor_busy_during_target_wait_ns'] or 0
         for x in target_gr),'outcomes':dict(Counter(x['outcome'] for x in eps)),
      'GO_FREEZE':False,'Congestion':None,'FutureCongestion':None,
      'F3_ready':False,'training_ready':False,
      'interpretation':'Development-only controlled physical service pressure, not final F3 label or causal proof'}
    (root/'stage1aj_groups.jsonl').write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in group_records))
    (root/'stage1aj_verification.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    return result

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('run_dir');ap.add_argument('--arm',choices=sorted(ARMS),required=True)
    args=ap.parse_args()
    print(json.dumps(audit(args.run_dir,args.arm),sort_keys=True))
