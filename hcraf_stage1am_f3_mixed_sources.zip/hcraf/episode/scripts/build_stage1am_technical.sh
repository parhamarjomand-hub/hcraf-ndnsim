#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
# This rebuilds the exact pinned native NFD/ndnSIM chain WITHOUT editing a prior source.
bash "$TASK/scripts/build_stage1aj.sh"
NFD="$ROOT/episode_sources/ns-3/src/ndnSIM/NFD"
python3 "$TASK/scripts/patch_nfd_stage1am_technical.py" \
  "$NFD/daemon/fw" > "$ROOT/episode_output/patched_stage1am_nfd_hashes.json"
git -C "$NFD" diff -- daemon/fw/forwarder.cpp daemon/fw/forwarder.hpp \
  > "$ROOT/episode_output/nfd_stage1am_technical_instrumentation.patch"
test -s "$ROOT/episode_output/nfd_stage1am_technical_instrumentation.patch"
cd "$ROOT/episode_sources/ns-3"
cp "$TASK/src/hcraf-stage1am-local-snapshot.hpp" scratch/hcraf-stage1am-local-snapshot.hpp
cp "$TASK/src/hcraf-stage1am-online-pilot.cpp" scratch/hcraf-stage1am-online-pilot.cc
cmp -s "$TASK/src/hcraf-stage1am-local-snapshot.hpp" scratch/hcraf-stage1am-local-snapshot.hpp
cmp -s "$TASK/src/hcraf-stage1am-online-pilot.cpp" scratch/hcraf-stage1am-online-pilot.cc
python3 ./waf -j 2
test -x build/scratch/hcraf-stage1am-online-pilot
