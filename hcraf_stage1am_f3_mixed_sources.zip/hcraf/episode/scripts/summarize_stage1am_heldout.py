#!/usr/bin/env python3
"""Split-preserving, strictly paired Stage1AM v0.44 held-out diagnostic summary.

Never computes a final F3 score or confidence interval from correlated windows.
"""
import collections,csv,hashlib,io,json,math,pathlib,statistics,sys
from heldout_f3_v044 import TOPOLOGIES,ARMS,STATUS,json_bytes,to_csv,need


def parse_resource(p):
    lines=p.read_text().splitlines()
    obj={k:float(v) for line in lines if '=' in line for k,v in [line.strip().split('=',1)]}
    need(all(k in obj for k in ('wall_seconds','user_seconds','system_seconds','max_rss_kib')),'MISSING_PAIR_RESOURCE_METRICS')
    need(all(math.isfinite(x) and x>=0 for x in obj.values()),'INVALID_RESOURCE_METRIC')
    return obj


def find_sends(root):
    p=root/'consumer_events.jsonl'
    need(p.is_file(),'MISSING_PAIRED_TARGET_SEND')
    data=[json.loads(l) for l in p.read_text().splitlines() if l.strip()]
    sends=[(x['name'],x['nonce'],x['time_ns']) for x in data if x['event']=='SEND']
    need(len(sends)==12 and len(set(sends))==12,'WRONG_TARGET_SENDS')
    arrivals=root/'consumer_events.jsonl.arrivals.jsonl'
    need(arrivals.exists(),'MISSING_TARGET_SCHEDULE')
    return sends,arrivals.read_bytes()


def ap_score(y,s):
    """Non-interpolated average precision; ties grouped, not arbitrary order."""
    if not y or 1 not in y or 0 not in y:return None
    groups=collections.defaultdict(lambda:[0,0])
    for v,x in zip(y,s):
        need(v in (0,1) and type(x) in (int,float) and math.isfinite(x),'INVALID_AP_INPUT')
        groups[x][int(v)]+=1
    tp=fp=0;prev_recall=0.0;ans=0.0; positives=sum(y)
    for score in sorted(groups,reverse=True):
        negatives,positives_at=groups[score]
        tp+=positives_at;fp+=negatives
        recall=tp/positives
        ans+=(recall-prev_recall)*tp/(tp+fp)
        prev_recall=recall
    return ans


def main(root):
    root=pathlib.Path(root);rows=[];pairs=[];missing=[]
    for topo,spec in TOPOLOGIES.items():
        for slot in range(3):
            for arm in ARMS:
                for run in spec['runs']:
                    base=root/topo/f'slot-{slot}'
                    m=base/'monitored'/arm/f'run-{run}'
                    u=base/'uninstrumented'/arm/f'run-{run}'
                    try:
                        ver=json.loads((m/'stage1am_heldout_verification.json').read_text())
                        wr=json.loads((m/'stage1am_heldout_windows.json').read_text())
                        cfg_m=json.loads((m/'scenario.json').read_text())
                        cfg_u=json.loads((u/'scenario.json').read_text())
                        need(ver['status']==STATUS and ver['candidate_positive']+ver['candidate_negative']+ver['candidate_unknown']==12,
                            'INCOMPLETE_MONITORED_AUDIT')
                        need(len(wr)==12 and all(x['FutureCongestion'] is None and x['F3_ready'] is False and
                             x['GO_FREEZE'] is False and x['training_ready'] is False for x in wr),
                             'FORBIDDEN_FINAL_F3_PROMOTION')
                        need(cfg_m['instrument_enabled'] is True and cfg_u['instrument_enabled'] is False and
                             all(cfg_m[k]==cfg_u[k] for k in ('path_nodes','selected_face_slot','selected_face_id',
                                 'selected_forward_bps','selected_relay_forward_bps','selected_mid_forward_bps',
                                 'selected_producer_reverse_bps','selected_return_bps','phase_arm','run','seed')),
                             'PAIRED_SCENARIO_MISMATCH')
                        tm,am=find_sends(m);tu,au=find_sends(u)
                        need(tm==tu and am==au,'TARGET_SEND_SCHEDULE_PERTURBED')
                        rm=parse_resource(m/'resource_usage.txt');ru=parse_resource(u/'resource_usage.txt')
                        for x in wr:
                            need(x['partition']==spec['partition'] and x['topology']==topo and x['slot']==slot and
                                x['run']==run and x['arm']==arm,'WRONG_SPLIT_IN_WINDOWS')
                        rows+=wr
                        pairs.append({'partition':spec['partition'],'topology':topo,'slot':slot,'arm':arm,'run':run,
                              'monitored_wall_seconds':rm['wall_seconds'],'control_wall_seconds':ru['wall_seconds'],
                              'paired_wall_delta_seconds':rm['wall_seconds']-ru['wall_seconds'],
                              'monitored_rss_kib':rm['max_rss_kib'],'control_rss_kib':ru['max_rss_kib'],
                              'paired_rss_delta_kib':rm['max_rss_kib']-ru['max_rss_kib'],
                              'candidate_positive':ver['candidate_positive'],'candidate_negative':ver['candidate_negative'],
                              'candidate_unknown':ver['candidate_unknown']})
                    except (OSError,ValueError,KeyError,TypeError) as e:
                        missing.append({'topology':topo,'slot':slot,'arm':arm,'run':run,'error':str(e)})
    expected=2*3*len(ARMS)*2
    complete=len(pairs)==expected and len(rows)==expected*12
    stats={}
    for topo,spec in TOPOLOGIES.items():
        sub=[x for x in rows if x['topology']==topo]
        valid=[x for x in sub if x['candidate_label'] in (0,1)]
        y=[x['candidate_label'] for x in valid]
        scores=[x['online_local_queue_packets'] for x in valid]
        pos=y.count(1);neg=y.count(0);unk=len(sub)-len(valid)
        stats[spec['partition']]={'topology':topo,'n_monitored_runs':len([p for p in pairs if p['topology']==topo]),
         'target_windows':len(sub),'candidate_positive':pos,'candidate_negative':neg,'candidate_unknown':unk,
         'valid_only_prevalence':pos/len(y) if y else None,
         'online_local_queue_proxy_AP_exploratory':ap_score(y,scores),
         'AP_definition':'Noninterpolated AP of online selected-local-queue occupancy; NOT HCRAF score',
         'independent_rng_stream_groups':2,
         'group_aware_ci':'NOT_ESTIMABLE: only 2 RNG runs per split, shared across arms/faces',
         'selection_bias':'Valid-only AP excludes UNKNOWN; not representative without missingness analysis'}
    has_class_both=all(stats[k]['candidate_positive']>0 and stats[k]['candidate_negative']>0 for k in ('VALIDATION','TEST'))
    has_controls=all(any(p['arm']=='OFF_BASELINE' and p['candidate_positive']==0 and p['topology']==t
                         for p in pairs) for t in TOPOLOGIES)
    verdict=STATUS if complete and has_class_both and has_controls else 'INCOMPLETE_HELDOUT_EVIDENCE'
    result={'stage':'1AM.F3_PRE_REGISTERED_HELDOUT_PILOT.0','version':'0.44.0','status':verdict,
       'expected_monitored_runs':expected,'expected_total_simulations':expected*2,
       'observed_monitored_runs':len(pairs),'observed_target_windows':len(rows),
       'missing_runs_or_errors':missing,'results_by_partition':stats,
       'paired_schedule_verified':complete,'heldout_test_not_used_to_tune_horizon_or_threshold':True,
       'primary_horizon_ns_locked':50_000_000,'primary_wait_ns_locked':5_000_000,
       'official_F3_labels':0,'Congestion':None,'FutureCongestion':None,
       'GO_FREEZE':False,'F3_ready':False,'training_ready':False,
       'scope':'4-hop distinct topology, diagnostic selected-Face forced, score proxy only',
       'why_not_final_F3':['unvalidated construct: queue-drop or queue-wait candidate, not full harm','2 RNG groups per partition insufficient for CI','no learned offline HCRAF model or Gate scores','unknown selection bias','forced action non-counterfactual','observer/recorder costs not HCRAF Gate']}
    out=root/'summary';out.mkdir(exist_ok=True)
    (out/'summary.json').write_bytes(json_bytes(result))
    (out/'paired_resources.csv').write_bytes(to_csv(pairs,list(pairs[0]) if pairs else
           ['partition','topology','slot','arm','run','candidate_positive']))
    (out/'candidate_windows.csv').write_bytes(to_csv(rows,list(rows[0]) if rows else
           ['partition','topology','slot','arm','run','candidate_label']))
    print(verdict,'pairs',len(pairs),'windows',len(rows))
    return verdict==STATUS

if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('usage: summarize_stage1am_heldout.py OUT_ROOT')
    raise SystemExit(0 if main(sys.argv[1]) else 3)
