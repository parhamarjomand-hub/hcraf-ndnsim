#!/usr/bin/env python3
"""Always-on evidence SHA manifest; does not approve F3."""
import hashlib,json,os,pathlib,sys

def main(root):
    root=pathlib.Path(root)
    output=root/'episode_output'
    output.mkdir(exist_ok=True)
    obj={}
    for f in sorted(output.rglob('*')):
        if f.is_file() and f.name!='full_evidence_manifest.json':
            obj[f.relative_to(output).as_posix()]={'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),
                                                    'bytes':f.stat().st_size}
    result={'stage':'1AM.F3_FRAGMENT_AWARE_HARM_DIAGNOSTIC_FOUR_HOP.0','status':'EVIDENCE_FILES_RECORDED_NOT_SCIENTIFIC_PASS',
      'file_count':len(obj),'file_hashes':obj,
      'git_run_id':os.getenv('GITHUB_RUN_ID'),'git_sha':os.getenv('GITHUB_SHA'),
      'Congestion':None,'FutureCongestion':None,'GO_FREEZE':False,'F3_ready':False,'training_ready':False}
    (output/'full_evidence_manifest.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print('EVIDENCE_MANIFEST_FILES',len(obj))

if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('usage: manifest_stage1am_heldout.py repo-root')
    main(sys.argv[1])
