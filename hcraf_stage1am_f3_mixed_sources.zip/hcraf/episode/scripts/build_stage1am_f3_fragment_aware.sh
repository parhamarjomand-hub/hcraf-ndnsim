#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
# Reuse the approved NFD patch chain; only new scratch scenario is additive.
bash "$TASK/scripts/build_stage1am_pathwide.sh"
cd "$ROOT/episode_sources/ns-3"
cp "$TASK/src/hcraf-stage1am-f3-fragment-aware-pilot.cpp" scratch/hcraf-stage1am-f3-fragment-aware-pilot.cc
cmp -s "$TASK/src/hcraf-stage1am-f3-fragment-aware-pilot.cpp" scratch/hcraf-stage1am-f3-fragment-aware-pilot.cc
python3 ./waf -j 2
test -x build/scratch/hcraf-stage1am-f3-fragment-aware-pilot
