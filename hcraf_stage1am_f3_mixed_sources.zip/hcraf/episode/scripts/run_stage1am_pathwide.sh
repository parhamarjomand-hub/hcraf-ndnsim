#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
OUT="$ROOT/episode_output/stage1am_pathwide"
mkdir -p "$OUT"
cd "$ROOT/episode_sources/ns-3"
failed=0
for topo in DEV_CHAIN_A DEV_CHAIN_B; do
  for slot in 0 1 2; do
    for arm in OFF_BASELINE LOCAL_FORWARD RELAY_FORWARD RETURN_DATA LATE_COMPETITOR; do
      comp=160; compoffset=0; localrate=5000000
      case "$arm" in
        OFF_BASELINE) comp=0;;
        LOCAL_FORWARD) localrate=50000;;
        RELAY_FORWARD|RETURN_DATA) :;;
        LATE_COMPETITOR) compoffset=800000000;;
        *) echo "UNKNOWN_ARM=$arm" >&2;exit 3;;
      esac
      cint=0; [ "$comp" -eq 0 ] || cint=1000000
      for run in 9601 9602; do
        for instrument in 1 0; do
          if [ "$instrument" = 1 ];then kind=monitored;else kind=uninstrumented;fi
          dest="$OUT/$topo/slot-$slot/$kind/$arm/run-$run"
          mkdir -p "$dest"
          cmd="hcraf-stage1am-pathwide-pilot --pathArm=$arm --topology=$topo --selectedSlot=$slot --mode=LP_INDEPENDENT_COMPETITOR_NO_DROP --seed=17 --run=$run --output=$dest --instrument=$instrument --lifetimeMs=2600 --requestCount=12 --intervalNs=30000000 --competitorCount=$comp --competitorIntervalNs=$cint --competitorOffsetNs=$compoffset --targetOffsetNs=30000000 --forwardBps=$localrate --returnBps=5000000"
          printf '%s\n' "$cmd" > "$dest/command.txt"
          if ! /usr/bin/time -f 'wall_seconds=%e\nuser_seconds=%U\nsystem_seconds=%S\nmax_rss_kib=%M' -o "$dest/resource_usage.txt" \
              python3 ./waf --run-no-build "$cmd" > "$dest/simulator.log" 2>&1; then
            echo "SIMULATION_FAIL $topo $slot $arm $run $instrument"; failed=1; continue
          fi
          if [ "$instrument" = 1 ];then
            if ! python3 "$TASK/scripts/episodes_stage1u.py" "$dest" \
                --run-id "1am_pathwide-$topo-$slot-$arm-17-$run" \
                > "$dest/episodes.log" 2>&1;then
              echo "EPISODE_FAIL $topo $slot $arm $run";failed=1;continue
            fi
            if ! python3 "$TASK/scripts/verify_stage1am_pathwide.py" "$dest" \
                --topology "$topo" --slot "$slot" --arm "$arm" --seed "$run" \
                > "$dest/verify.log" 2>&1;then
              echo "VERIFICATION_FAIL $topo $slot $arm $run";failed=1
            fi
          fi
        done
      done
    done
  done
done
if ! python3 "$TASK/scripts/summarize_stage1am_pathwide.py" "$OUT";then failed=1;fi
exit "$failed"
