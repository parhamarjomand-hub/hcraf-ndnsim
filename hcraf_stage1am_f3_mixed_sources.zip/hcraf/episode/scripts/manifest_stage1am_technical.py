#!/usr/bin/env python3
"""Manifest includes partial-failure files, exact original source, NFD patch and host provenance."""
import hashlib,json,os,platform,subprocess,sys
from datetime import datetime,timezone
from pathlib import Path
r=Path(sys.argv[1]).resolve();out=r/'episode_output';out.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files={str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='manifest.json'}
workflow=r/'.github/workflows/hcraf-stage1am-technical.yml'
source=r/'hcraf_stage1am_technical_sources.zip'
reference=r/'hcraf_stage1s_approved_reference.zip'
meta={'stage':'1AM.TECHNICAL.ONLINE_PILOT.0','created_utc':datetime.now(timezone.utc).isoformat(),
  'github_run_id':os.getenv('GITHUB_RUN_ID'),'github_commit':os.getenv('GITHUB_SHA'),
  'source_zip_sha256':sha(source) if source.is_file() else None,
  'reference_zip_sha256':sha(reference) if reference.is_file() else None,
  'workflow_sha256':sha(workflow) if workflow.is_file() else None,
  'output_file_sha256':files,'python_version':platform.python_version(),
  'container_image':'ubuntu:20.04 (tag not OCI digest)','fully_pinned_environment':False,
  'GO_FREEZE':False,'Congestion':None,'FutureCongestion':None,
  'F3_ready':False,'training_ready':False,'dataset_generated':False}
(out/'manifest.json').write_text(json.dumps(meta,sort_keys=True,ensure_ascii=False,indent=2)+'\n')
