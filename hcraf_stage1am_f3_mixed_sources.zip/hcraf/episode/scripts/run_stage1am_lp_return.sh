#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
OUT="$ROOT/episode_output/stage1am_lp_return"
mkdir -p "$OUT"
cd "$ROOT/episode_sources/ns-3"
failed=0
# 2 DEV topologies x 3 physical selected Faces x 2 arms x 2 RngRuns
# x 2 matched monitored/non-monitored = 48 real runs, not 48 labels.
for topo in DEV_CHAIN_A DEV_CHAIN_B; do
  for slot in 0 1 2; do
    for arm in OFF_BASELINE RETURN_DATA; do
      comp=160
      if [ "$arm" = OFF_BASELINE ]; then comp=0;fi
      cint=1000000
      if [ "$comp" = 0 ];then cint=0;fi
      for run in 9601 9602; do
        for instrument in 1 0; do
          if [ "$instrument" = 1 ];then kind=monitored;else kind=uninstrumented;fi
          dest="$OUT/$topo/slot-$slot/$kind/$arm/run-$run"
          mkdir -p "$dest"
          cmd="hcraf-stage1am-pathwide-pilot --pathArm=$arm --topology=$topo --selectedSlot=$slot --mode=LP_INDEPENDENT_COMPETITOR_NO_DROP --seed=17 --run=$run --output=$dest --instrument=$instrument --lifetimeMs=2600 --requestCount=12 --intervalNs=30000000 --competitorCount=$comp --competitorIntervalNs=$cint --competitorOffsetNs=0 --targetOffsetNs=30000000 --forwardBps=5000000 --returnBps=5000000"
          printf '%s\n' "$cmd" > "$dest/command.txt"
          if ! /usr/bin/time -f 'wall_seconds=%e\nuser_seconds=%U\nsystem_seconds=%S\nmax_rss_kib=%M' -o "$dest/resource_usage.txt" \
            python3 ./waf --run-no-build "$cmd" > "$dest/simulator.log" 2>&1;then
            echo "SIMULATION_FAIL $topo/$slot/$arm/$run/$kind";failed=1;continue
          fi
          if [ "$instrument" = 1 ]; then
            if ! python3 "$TASK/scripts/episodes_stage1u.py" "$dest" \
               --run-id "1am_lp_return-$topo-$slot-$arm-17-$run" \
               > "$dest/episodes.log" 2>&1; then
              echo "EPISODE_FAIL $topo/$slot/$arm/$run";failed=1;continue
            fi
            if ! python3 "$TASK/scripts/verify_stage1am_lp_return.py" "$dest" \
               --topology "$topo" --slot "$slot" --arm "$arm" --seed "$run" \
               > "$dest/verify.log" 2>&1;then
              echo "LP_VERIFICATION_FAIL $topo/$slot/$arm/$run";failed=1
            fi
          fi
        done
      done
    done
  done
done
if ! python3 "$TASK/scripts/summarize_stage1am_lp_return.py" "$OUT";then failed=1;fi
exit "$failed"
