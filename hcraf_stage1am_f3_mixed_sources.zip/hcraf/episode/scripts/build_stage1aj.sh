#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
# Exact approved pinned ndnSIM and two-class NFD recorder instrumentation.
bash "$TASK/scripts/build_stage1ah_a1.sh"
cd "$ROOT/episode_sources/ns-3"
cp "$TASK/src/hcraf-stage1aj-pilot.cpp" scratch/hcraf-stage1aj-pilot.cc
cmp -s "$TASK/src/hcraf-stage1aj-pilot.cpp" scratch/hcraf-stage1aj-pilot.cc
python3 ./waf -j 2
test -x build/scratch/hcraf-stage1aj-pilot
