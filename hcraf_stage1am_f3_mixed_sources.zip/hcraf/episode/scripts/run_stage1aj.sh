#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
OUT="$ROOT/episode_output/stage1aj/DEV_CHAIN_B"
mkdir -p "$OUT"
cd "$ROOT/episode_sources/ns-3"
failed=0
for arm in OFF_10M ON_10M OFF_5M ON_5M_SYNC OFF_5M_TARGET_LAG_6MS ON_5M_TARGET_LAG_6MS ON_5M_COMPETITOR_LAG_2MS;do
  case "$arm" in
    OFF_10M) rate=10000000; count=0; target=0; competitor=0;;
    ON_10M) rate=10000000;count=12;target=0;competitor=0;;
    OFF_5M) rate=5000000;count=0;target=0;competitor=0;;
    ON_5M_SYNC) rate=5000000;count=12;target=0;competitor=0;;
    OFF_5M_TARGET_LAG_6MS) rate=5000000;count=0;target=6000000;competitor=0;;
    ON_5M_TARGET_LAG_6MS) rate=5000000;count=12;target=6000000;competitor=0;;
    ON_5M_COMPETITOR_LAG_2MS) rate=5000000;count=12;target=0;competitor=2000000;;
    *) exit 4;;
  esac
  cint=0;[ "$count" -eq 0 ] || cint=250000000
  for run in 9201 9202 9203;do
    for monitor in 1 0;do
      if [ "$monitor" -eq 1 ];then kind=monitored;else kind=uninstrumented;fi
      dest="$OUT/$kind/$arm/run-$run";mkdir -p "$dest"
      command="hcraf-stage1aj-pilot --mode=LP_INDEPENDENT_COMPETITOR_NO_DROP --topology=DEV_CHAIN_B --selectedSlot=0 --output=$dest --seed=17 --run=$run --instrument=$monitor --lifetimeMs=2600 --requestCount=12 --intervalNs=250000000 --competitorCount=$count --competitorIntervalNs=$cint --competitorOffsetNs=$competitor --targetOffsetNs=$target --returnBps=$rate"
      printf '%s\n' "$command" > "$dest/command.txt"
      if ! /usr/bin/time -f 'wall_seconds=%e\nuser_seconds=%U\nsystem_seconds=%S\nmax_rss_kib=%M' -o "$dest/resource_usage.txt" \
        python3 ./waf --run-no-build "$command" > "$dest/simulator.log" 2>&1;then
          echo "SIM_FAIL $arm $run $monitor";failed=1;continue
      fi
      if [ "$monitor" -eq 1 ];then
        if ! python3 "$TASK/scripts/episodes_stage1u.py" "$dest" --run-id "1aj-B-0-$arm-17-$run" > "$dest/episodes.log" 2>&1;then
          echo "EPISODE_FAIL $arm $run";failed=1;continue
        fi
        if ! python3 "$TASK/scripts/verify_stage1aj.py" "$dest" --arm "$arm" > "$dest/verify.log" 2>&1;then
          echo "VERIFY_FAIL $arm $run";failed=1
        fi
      fi
    done
  done
done
if ! python3 "$TASK/scripts/summarize_stage1aj.py" "$OUT";then failed=1;fi
exit "$failed"
