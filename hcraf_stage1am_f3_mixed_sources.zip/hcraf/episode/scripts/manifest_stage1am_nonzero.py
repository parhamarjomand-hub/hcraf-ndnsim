#!/usr/bin/env python3
"""Hash all output files, fail-closed readiness metadata; works on failed CI runs."""
import hashlib,json,os,sys,platform
from pathlib import Path
from datetime import datetime,timezone
r=Path(sys.argv[1]).resolve();out=r/'episode_output';out.mkdir(exist_ok=True,parents=True)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
files={str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='manifest.json'}
meta={'stage':'1AM.NONZERO_PHYSICAL_QUEUE.ORACLE_PILOT.0',
      'created_utc':datetime.now(timezone.utc).isoformat(),
      'github_run_id':os.getenv('GITHUB_RUN_ID'),'github_commit':os.getenv('GITHUB_SHA'),
      'source_zip_sha256':sha(r/'hcraf_stage1am_nonzero_sources.zip') if (r/'hcraf_stage1am_nonzero_sources.zip').exists() else None,
      'reference_zip_sha256':sha(r/'hcraf_stage1s_approved_reference.zip') if (r/'hcraf_stage1s_approved_reference.zip').exists() else None,
      'workflow_sha256':sha(r/'.github/workflows/hcraf-stage1am-nonzero.yml') if (r/'.github/workflows/hcraf-stage1am-nonzero.yml').exists() else None,
      'output_file_sha256':files,'python_version':platform.python_version(),
      'container_image':'ubuntu:20.04 tag only, not digest','fully_pinned_environment':False,
      'positive_pilot_diagnostic_is_not_final_F3':True,
      'GO_FREEZE':False,'Congestion':None,'FutureCongestion':None,
      'F3_ready':False,'training_ready':False,'dataset_generated':False}
(out/'manifest.json').write_text(json.dumps(meta,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
