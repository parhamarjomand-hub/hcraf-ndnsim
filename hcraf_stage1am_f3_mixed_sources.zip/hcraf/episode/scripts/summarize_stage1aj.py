#!/usr/bin/env python3
"""Paired OFF/ON intervention: fixed TARGET streams, cluster by RngRun.

Do not treat group-level or repeated-seed pair differences as independent trials.
Unobserved outcome or physical group -> null delta, not zero or imputed SUCCESS.
"""
import hashlib,json,sys
from pathlib import Path
from verify_stage1aj import ARMS,RUNS
PAIRS={
 'ON_10M':'OFF_10M',
 'ON_5M_SYNC':'OFF_5M',
 'ON_5M_TARGET_LAG_6MS':'OFF_5M_TARGET_LAG_6MS',
 'ON_5M_COMPETITOR_LAG_2MS':'OFF_5M',
}

def digest(f):return hashlib.sha256(f.read_bytes()).hexdigest() if f.is_file() else None

def jload(p):return json.loads(p.read_text()) if p.is_file() else None

def group_index(path):
    if not path.is_file():return {}
    data=[json.loads(s) for s in path.read_text().splitlines() if s.strip()]
    return {x['name']:x for x in data if x['traffic_class']=='TARGET'}

def summarize(root):
    root=Path(root);runs=[];pairs=[];changes=[];coverage=[]
    for arm in ARMS:
      for run in RUNS:
        m=root/'monitored'/arm/('run-'+str(run))
        u=root/'uninstrumented'/arm/('run-'+str(run))
        v=jload(m/'stage1aj_verification.json')
        if v is None:v=dict(status='NO_VERIFIER_RESULT',arm=arm,rng_run=run)
        runs.append(v)
        # Pair monitoring overhead, not HCRAF decision overhead.
        names=('consumer_events.jsonl', 'consumer_events.jsonl.arrivals.jsonl')
        if ARMS[arm][1]:names+=('competitor_events.jsonl','competitor_events.jsonl.arrivals.jsonl')
        equal=all(digest(m/f) is not None and digest(m/f)==digest(u/f) for f in names)
        coverage.append(dict(arm=arm,rng_run=run,monitored_unmonitored_schedule_equal=equal,
          is_HCRAF_decision_latency=False))
    bykey={(r['arm'],r['rng_run']):r for r in runs}
    for arm,off in PAIRS.items():
      for run in RUNS:
        a=root/'monitored'/arm/('run-'+str(run));b=root/'monitored'/off/('run-'+str(run))
        match=all(digest(a/f)==digest(b/f) and digest(a/f) is not None
            for f in ('consumer_events.jsonl.arrivals.jsonl',))
        # Target SEND identical, DATA naturally different.
        def send_digest(d):
            p=d/'consumer_events.jsonl'
            if not p.is_file():return None
            sends=[json.loads(s) for s in p.read_text().splitlines() if s.strip() and json.loads(s).get('event')=='SEND']
            return hashlib.sha256(json.dumps(sends,sort_keys=True).encode()).hexdigest()
        match=bool(match and send_digest(a)==send_digest(b) and send_digest(a))
        on=group_index(a/'stage1aj_groups.jsonl');offgroups=group_index(b/'stage1aj_groups.jsonl')
        for i in range(12):
            name='/hcraf/pilot/'+str(i);x=on.get(name);y=offgroups.get(name)
            valid=bool(match and x and y and x['evidence_complete'] and y['evidence_complete']
                and x['episode_delay_ns'] is not None and y['episode_delay_ns'] is not None)
            changes.append(dict(arm_on=arm,arm_off=off,rng_run=run,name=name,
                comparable=valid, target_schedule_equal=match,
                episode_delay_delta_ns=(x['episode_delay_ns']-y['episode_delay_ns']) if valid else None,
                first_fragment_wait_delta_ns=(x['first_fragment_wait_ns']-y['first_fragment_wait_ns']) if valid else None,
                physically_attributed_foreign_wait_on_ns=x['physical_competitor_busy_during_target_wait_ns'] if valid else None,
                M3_on=x['M3_group_epoch_overlap'] if valid else None,
                unknown_or_censored=not valid,
                FutureCongestion=None,Congestion=None,F3_ready=False))
        pairs.append(dict(arm_on=arm,arm_off=off,rng_run=run,
            target_schedule_equal=match,comparable_episodes=sum(x['comparable'] for x in changes[-12:]),
            on_status=bykey[(arm,run)]['status'],off_status=bykey[(off,run)]['status'],
            is_randomized_hcraf_policy_comparison=False))
    status='PASS_TECHNICAL_PAIR_COVERAGE_ONLY' if all(x['status']=='COMPLETE_PHYSICAL_OBSERVATION' for x in runs) and\
        all(x['monitored_unmonitored_schedule_equal'] for x in coverage) and\
        all(x['target_schedule_equal'] and x['comparable_episodes']==12 for x in pairs) else\
        'INCOMPLETE_DIAGNOSTIC_COVERAGE'
    # Effect interpretation is separate and NEVER claimed merely because pairs are complete.
    summary=dict(stage='1AJ.PAIRED_INTERVENTION.0',status=status,
      planned_monitored=21,planned_uninstrumented=21,recorded_runs=len(runs),
      scheduled_paired_comparisons=12,paired_target_episode_comparisons=len(changes),
      verified_complete_comparisons=sum(x['comparable'] for x in changes),
      scientifically_confirmed_congestion=False,GO_FREEZE=False,F3_ready=False,
      training_ready=False,Congestion=None,FutureCongestion=None,
      selected_face_only=True,not_training_dataset=True,
      caveat='Physical blocking + paired delay, not proof of F3 predictivity or final threshold')
    for name,obj in [('stage1aj_runs.json',runs),('stage1aj_pairs.json',pairs),
                     ('stage1aj_monitor_pairs.json',coverage),('stage1aj_summary.json',summary)]:
        (root/name).write_text(json.dumps(obj,sort_keys=True,indent=2)+'\n')
    with (root/'stage1aj_paired_episode_deltas.jsonl').open('w') as f:
        for x in changes:f.write(json.dumps(x,sort_keys=True)+'\n')
    print(json.dumps(summary,sort_keys=True))
    return 0 if status=='PASS_TECHNICAL_PAIR_COVERAGE_ONLY' else 3
if __name__=='__main__':raise SystemExit(summarize(sys.argv[1]))
