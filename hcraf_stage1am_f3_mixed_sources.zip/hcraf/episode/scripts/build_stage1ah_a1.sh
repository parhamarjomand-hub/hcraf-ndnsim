#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
# Reuse approved pinned dependency/build and /hcraf NFD instrumentation.
bash "$TASK/scripts/build_stage1ah.sh"
cd "$ROOT/episode_sources/ns-3"
cp "$TASK/src/hcraf-stage1ah-a1-pilot.cpp" scratch/hcraf-stage1ah-a1-pilot.cc
cmp -s "$TASK/src/hcraf-stage1ah-a1-pilot.cpp" scratch/hcraf-stage1ah-a1-pilot.cc
python3 ./waf -j 2
test -x build/scratch/hcraf-stage1ah-a1-pilot
