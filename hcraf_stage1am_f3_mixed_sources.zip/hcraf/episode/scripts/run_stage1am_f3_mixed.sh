#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
OUT="$ROOT/episode_output/stage1am_f3_mixed"
mkdir -p "$OUT"
cd "$ROOT/episode_sources/ns-3"
failed=0
# Pre-register BEFORE Test: Validation I must be sealed while Test J absent.
for topology in VAL_CHAIN_I TEST_CHAIN_J;do
  if [ "$topology" = VAL_CHAIN_I ];then runs="11221 11222 11223 11224 11225 11226"
  else runs="11321 11322 11323 11324 11325 11326";fi
  for slot in 0 1 2;do
    for arm in QUIET_CLEAN MIXED_LOCAL MIXED_RELAY MIXED_MID MIXED_RETURN;do
      if [ "$arm" = QUIET_CLEAN ];then count=0;interval=0;else count=96;interval=2000000;fi
      forwardrate=50000000
      [ "$arm" != MIXED_LOCAL ] || forwardrate=120000
      for rng in $runs;do
        for instrument in 1 0;do
          if [ "$instrument" = 1 ];then kind=monitored;else kind=uninstrumented;fi
          dest="$OUT/$topology/slot-$slot/$kind/$arm/run-$rng"
          mkdir -p "$dest"
          cmd="hcraf-stage1am-f3-mixed-pilot --pathArm=$arm --topology=$topology --selectedSlot=$slot --mode=LP_INDEPENDENT_COMPETITOR_NO_DROP --seed=17 --run=$rng --output=$dest --instrument=$instrument --lifetimeMs=2600 --requestCount=12 --intervalNs=30000000 --competitorCount=$count --competitorIntervalNs=$interval --competitorOffsetNs=0 --targetOffsetNs=30000000 --forwardBps=$forwardrate --returnBps=50000000"
          printf '%s\n' "$cmd" > "$dest/command.txt"
          if ! /usr/bin/time -f 'wall_seconds=%e\nuser_seconds=%U\nsystem_seconds=%S\nmax_rss_kib=%M' -o "$dest/resource_usage.txt" \
            python3 ./waf --run-no-build "$cmd" > "$dest/simulator.log" 2>&1;then
            echo "SIM_FAIL $topology/$slot/$arm/$rng/$kind";failed=1;continue
          fi
          if [ "$instrument" = 1 ];then
            if ! python3 "$TASK/scripts/episodes_stage1u.py" "$dest" \
                --run-id "1am_mixed-$topology-$slot-$arm-17-$rng" > "$dest/episodes.log" 2>&1;then
              echo "EPISODE_FAIL $topology/$slot/$arm/$rng";failed=1;continue
            fi
            if ! python3 "$TASK/scripts/f3_mixed_rng_v047.py" "$dest" --topology "$topology" \
                --slot "$slot" --arm "$arm" --run "$rng" > "$dest/verify.log" 2>&1;then
              echo "MIXED_VERIFY_FAIL $topology/$slot/$arm/$rng";failed=1
            fi
          fi
        done
      done
    done
  done
  if [ "$topology" = VAL_CHAIN_I ];then
    if ! python3 "$TASK/scripts/seal_stage1am_f3_mixed_validation.py" "$OUT";then
      echo "NEW_VALIDATION_NOT_SEALED_TEST_MUST_NOT_OPEN";exit 5
    fi
  fi
done
if ! python3 "$TASK/scripts/summarize_stage1am_f3_mixed.py" "$OUT";then failed=1;fi
exit "$failed"
