#!/usr/bin/env python3
"""Pre-registered three-arm / three-RNG comparison; never select only favorable runs."""
import json,hashlib,sys
from pathlib import Path
ARMS=('BASELINE_10M','RATE5M_NO_SHIFT','RATE5M_TARGET_LAG_6MS','RATE5M_COMPETITOR_LAG_2MS')
RUNS=(9101,9102,9103)
FILES=('consumer_events.jsonl','consumer_events.jsonl.arrivals.jsonl',
       'competitor_events.jsonl','competitor_events.jsonl.arrivals.jsonl')

def digest(f):return hashlib.sha256(f.read_bytes()).hexdigest() if f.is_file() else None

def summarize(root):
    root=Path(root);rows=[];pairs=[];missing=[]
    for arm in ARMS:
        for rng in RUNS:
            m=root/'monitored'/arm/f'run-{rng}';u=root/'uninstrumented'/arm/f'run-{rng}'
            result=m/'stage1aha1_verification.json'
            if result.is_file():
                data=json.loads(result.read_text())
            else:
                data={'status':'NO_VERIFIER_RESULT','phase_arm':arm,'rng_run':rng}
                missing.append(f'{arm}/{rng}')
            rows.append(data)
            match={f:(digest(m/f) is not None and digest(m/f)==digest(u/f)) for f in FILES}
            pairs.append({'phase_arm':arm,'rng_run':rng,'matched_files':match,'paired_equal':all(match.values()),
                          'is_HCRAF_policy_decision_latency':False})
    byrun={str(rng):{arm:next(x for x in rows if x['rng_run']==rng and x['phase_arm']==arm)['status'] for arm in ARMS}
           for rng in RUNS}
    predeclared_criterion=all(
      byrun[str(rng)]['BASELINE_10M']=='NO_CONFIRMED_COMPETITION' and
      any(byrun[str(rng)][arm]=='OBSERVED_COMPETITION' for arm in ARMS[2:])
      for rng in RUNS)
    complete_pairs=all(p['paired_equal'] for p in pairs)
    status='PASS_TARGETED_A1_FEASIBILITY' if predeclared_criterion and complete_pairs and not missing else 'INCOMPLETE_TARGETED_A1_FEASIBILITY'
    summary={'stage':'1AH-A1.PHASE_SWEEP.0','topology_id':'DEV_CHAIN_B','slot':0,
             'planned_monitored':12,'planned_uninstrumented':12,'recorded_monitored':len(rows),
             'recorded_pairs':len(pairs),'baseline_rate_control_and_both_shifts_reported':True,
             'predeclared_per_seed_criterion_met':predeclared_criterion,'pairs_matched':complete_pairs,
             'missing':missing,'status':status,'per_seed_status':byrun,
             'F3_ready':False,'training_ready':False,'GO_FREEZE':False,
             'Congestion':None,'FutureCongestion':None,'not_main_dataset':True}
    for file,obj in [('stage1aha1_runs.json',rows),('stage1aha1_pairs.json',pairs),('stage1aha1_summary.json',summary)]:
        (root/file).write_text(json.dumps(obj,sort_keys=True,indent=2)+'\n')
    print(json.dumps(summary,sort_keys=True))
    return 0 if status=='PASS_TARGETED_A1_FEASIBILITY' else 3
if __name__=='__main__':raise SystemExit(summarize(sys.argv[1]))
