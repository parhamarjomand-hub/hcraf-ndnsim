#!/usr/bin/env python3
"""Independent phase-amendment gate; wraps the UNMODIFIED strict 1AH verifier.
Never turns traffic success or unassigned fragments into congestion labels.
"""
import argparse,json
from pathlib import Path
from verify_stage1ah import verify as verify_original, read, require

ARMS={'BASELINE_10M':(0,0,10_000_000),
      'RATE5M_NO_SHIFT':(0,0,5_000_000),
      'RATE5M_TARGET_LAG_6MS':(6_000_000,0,5_000_000),
      'RATE5M_COMPETITOR_LAG_2MS':(0,2_000_000,5_000_000)}
STAGE='1AH-A1.PHASE_SWEEP.0'

def validate_config_and_arrivals(root, expected_arm=None):
    p=Path(root)
    c=json.loads((p/'scenario.json').read_text())
    require(c.get('amendment_stage')==STAGE,'Wrong amendment provenance')
    arm=c.get('phase_arm')
    require(arm in ARMS and (expected_arm is None or arm==expected_arm),'Unexpected phase arm')
    to,co,bps=ARMS[arm]
    require(c.get('target_offset_ns')==to and c.get('competitor_offset_ns')==co and
            c.get('selected_return_bps')==bps,
            'Phase offsets not bound to pre-registered arm')
    require(c.get('collector_stage')=='1AH.GROUP_AWARE.0' and
            c.get('mode')=='LP_INDEPENDENT_COMPETITOR_NO_DROP' and
            c.get('topology_id')=='DEV_CHAIN_B' and c.get('selected_face_slot')==0 and
            type(c.get('eligible_face_ids'))==list and len(c['eligible_face_ids'])==3 and
            len(set(c['eligible_face_ids']))==3 and c.get('selected_face_id')==c['eligible_face_ids'][0] and
            c.get('run') in (9101,9102,9103) and
            c.get('seed')==17 and c.get('interest_lifetime_ms')==2600 and
            c.get('planned_requests')==12 and c.get('competitor_planned_requests')==12 and
            c.get('nominal_arrival_interval_ns')==250_000_000 and
            c.get('competitor_interval_ns')==250_000_000,
            'Wrong B/slot0/NO_DROP experimental contract')
    require(c.get('actual_assignment_probability')==1.0 and
            c.get('no_counterfactual_unselected_face') is True,
            'Missing actual controlled Face assignment declaration')
    for filename,klass,off,stream in (
       ('consumer_events.jsonl','TARGET',to,129),
       ('competitor_events.jsonl','INDEPENDENT_COMPETITOR',co,139)):
        arrivals=read(p/(filename+'.arrivals.jsonl'))
        sends=[e for e in read(p/filename) if e.get('event')=='SEND']
        require(len(arrivals)==len(sends)==12,'Wrong actual schedule cardinality')
        for i,(a,e) in enumerate(zip(arrivals,sends)):
            expected=2_000_000_000+off+i*250_000_000+a['jitter_ns']
            require(a.get('sequence')==i and a.get('traffic_class')==klass and
                    a.get('stream')==stream and isinstance(a['jitter_ns'],int) and
                    0<=a['jitter_ns']<=99999 and
                    a.get('time_ns')==expected and e.get('time_ns')==expected and
                    e.get('traffic_class')==klass,
                    'Observed SEND/arrival deviates from the phase protocol')
    return arm,c

def audit_run(root,expected_arm=None):
    arm,c=validate_config_and_arrivals(root,expected_arm)
    # The scientific gate remains the original 1AH verifier, without modifications.
    base=verify_original(root)
    require(base['regime']=='LP_INDEPENDENT_COMPETITOR_NO_DROP' and
            base['topology_id']=='DEV_CHAIN_B' and base['face_slot']==0 and
            base['target_episodes']==12 and base['competitor_episodes']==12 and
            base['verified_target_groups']==12 and base['verified_competitor_groups']==12 and
            base['complete_return_fragment_groups']==24 and
            base['observed_return_fragment_queue_drops']==0 and
            base['sender_fragment_groups_without_complete_rx']==0 and
            base['incomplete_return_fragment_groups']==0 and
            base['outcomes']=={'SUCCESS':24},
            'Missing complete loss-free actual two-class / PIT / queue observation')
    overlap=base['target_groups_with_verified_competitor_overlap']
    require(isinstance(overlap,int) and 0<=overlap<=12,'Invalid direct class overlap')
    status='OBSERVED_COMPETITION' if overlap>0 else 'NO_CONFIRMED_COMPETITION'
    result={'amendment_stage':STAGE,'phase_arm':arm,'topology_id':'DEV_CHAIN_B',
        'selected_face_slot':0,'rng_run':c['run'],'target_offset_ns':c['target_offset_ns'],
        'competitor_offset_ns':c['competitor_offset_ns'],
        'selected_return_bps':c['selected_return_bps'],
        'unchanged_1AH_verifier_status':base['status'],
        'target_groups_with_verified_competitor_overlap':overlap,
        'target_groups':12,'competitor_groups':12,'queue_drops':0,
        'status':status,'GO_FREEZE':False,'Congestion':None,'FutureCongestion':None,
        'F3_ready':False,'training_ready':False,'HCRAF_policy_test':False}
    (Path(root)/'stage1aha1_verification.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('run_dir')
    parser.add_argument('--arm',choices=sorted(ARMS),required=True)
    args=parser.parse_args()
    print(json.dumps(audit_run(args.run_dir,args.arm),sort_keys=True))
