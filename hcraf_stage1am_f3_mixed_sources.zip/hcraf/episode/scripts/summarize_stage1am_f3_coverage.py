#!/usr/bin/env python3
"""Stage1AM v0.45 locked fresh E/F coverage with prospective low-pressure controls.

Never computes a final F3 score or confidence interval from correlated windows.
"""
import collections,csv,hashlib,io,json,math,pathlib,statistics,sys
from f3_coverage_v045 import TOPOLOGIES,ARMS,CONTROL_ARMS,PRESSURE_ARMS,STATUS,json_bytes,to_csv,need


def parse_resource(p):
    lines=p.read_text().splitlines()
    obj={k:float(v) for line in lines if '=' in line for k,v in [line.strip().split('=',1)]}
    need(all(k in obj for k in ('wall_seconds','user_seconds','system_seconds','max_rss_kib')),'MISSING_PAIR_RESOURCE_METRICS')
    need(all(math.isfinite(x) and x>=0 for x in obj.values()),'INVALID_RESOURCE_METRIC')
    return obj


def find_sends(root):
    p=root/'consumer_events.jsonl'
    need(p.is_file(),'MISSING_PAIRED_TARGET_SEND')
    data=[json.loads(l) for l in p.read_text().splitlines() if l.strip()]
    sends=[(x['name'],x['nonce'],x['time_ns']) for x in data if x['event']=='SEND']
    need(len(sends)==12 and len(set(sends))==12,'WRONG_TARGET_SENDS')
    arrivals=root/'consumer_events.jsonl.arrivals.jsonl'
    need(arrivals.exists(),'MISSING_TARGET_SCHEDULE')
    return sends,arrivals.read_bytes()


def ap_score(y,s):
    """Non-interpolated average precision; ties grouped, not arbitrary order."""
    if not y or 1 not in y or 0 not in y:return None
    groups=collections.defaultdict(lambda:[0,0])
    for v,x in zip(y,s):
        need(v in (0,1) and type(x) in (int,float) and math.isfinite(x),'INVALID_AP_INPUT')
        groups[x][int(v)]+=1
    tp=fp=0;prev_recall=0.0;ans=0.0; positives=sum(y)
    for score in sorted(groups,reverse=True):
        negatives,positives_at=groups[score]
        tp+=positives_at;fp+=negatives
        recall=tp/positives
        ans+=(recall-prev_recall)*tp/(tp+fp)
        prev_recall=recall
    return ans



def target_outcomes(root):
    """Return sent-name -> time-to-first-data or None. Does NOT infer timeout labels."""
    p=pathlib.Path(root)/'consumer_events.jsonl'
    events=[json.loads(l) for l in p.read_text().splitlines() if l.strip()]
    sends={}
    data={}
    for e in events:
        if e.get('event')=='SEND':
            need(e.get('name') not in sends, 'DUPLICATE_TARGET_SEND')
            sends[e['name']]=e['time_ns']
        elif e.get('event')=='DATA':
            n=e.get('name')
            if n in sends and e.get('time_ns',-1)>=sends[n]:
                data[n]=min(data.get(n,e['time_ns']),e['time_ns'])
    need(len(sends)==12,'WRONG_TARGET_SENDS_FOR_COMPLETION')
    return {n:None if n not in data else data[n]-t for n,t in sends.items()}


def paired_completion_rows(root):
    """Protocol comparability to QUIET_CLEAN, NOT causal or policy-counterfactual labels."""
    rows=[]
    for topo,spec in TOPOLOGIES.items():
        for slot in range(3):
            for rng in spec['runs']:
                base=root/topo/f'slot-{slot}'/'monitored'
                anchor=target_outcomes(base/'QUIET_CLEAN'/f'run-{rng}')
                for arm in ARMS:
                    current=target_outcomes(base/arm/f'run-{rng}')
                    need(set(current)==set(anchor), 'PAIRED_TARGET_NAME_MISMATCH')
                    for name in sorted(anchor):
                        a,b=anchor[name],current[name]
                        rows.append({'partition':spec['partition'],'topology':topo,'slot':slot,
                           'run':rng,'arm':arm,'name':name,
                           'quiet_data_delay_ns':a,'arm_data_delay_ns':b,
                           'paired_delta_ns_if_both_received':b-a if a is not None and b is not None else None,
                           'quiet_receipt_observed':a is not None,'arm_receipt_observed':b is not None,
                           'is_FutureCongestion_label':False,
                           'interpretation':'DESCRIPTIVE_PAIRED_SCENARIO_ONLY_NOT_CAUSAL_GATE'})
    return rows

def main(root):
    root=pathlib.Path(root);rows=[];pairs=[];missing=[]
    for topo,spec in TOPOLOGIES.items():
        for slot in range(3):
            for arm in ARMS:
                for run in spec['runs']:
                    base=root/topo/f'slot-{slot}'
                    m=base/'monitored'/arm/f'run-{run}'
                    u=base/'uninstrumented'/arm/f'run-{run}'
                    try:
                        ver=json.loads((m/'stage1am_f3_coverage_verification.json').read_text())
                        wr=json.loads((m/'stage1am_f3_coverage_windows.json').read_text())
                        cfg_m=json.loads((m/'scenario.json').read_text())
                        cfg_u=json.loads((u/'scenario.json').read_text())
                        need(ver['status']==STATUS and ver['candidate_positive']+ver['candidate_negative']+ver['candidate_unknown']==12,
                            'INCOMPLETE_MONITORED_AUDIT')
                        need(len(wr)==12 and all(x['FutureCongestion'] is None and x['F3_ready'] is False and
                             x['GO_FREEZE'] is False and x['training_ready'] is False for x in wr),
                             'FORBIDDEN_FINAL_F3_PROMOTION')
                        need(cfg_m['instrument_enabled'] is True and cfg_u['instrument_enabled'] is False and
                             all(cfg_m[k]==cfg_u[k] for k in ('path_nodes','selected_face_slot','selected_face_id',
                                 'selected_forward_bps','selected_relay_forward_bps','selected_mid_forward_bps',
                                 'selected_producer_reverse_bps','selected_return_bps','phase_arm','run','seed')),
                             'PAIRED_SCENARIO_MISMATCH')
                        tm,am=find_sends(m);tu,au=find_sends(u)
                        need(tm==tu and am==au,'TARGET_SEND_SCHEDULE_PERTURBED')
                        rm=parse_resource(m/'resource_usage.txt');ru=parse_resource(u/'resource_usage.txt')
                        for x in wr:
                            need(x['partition']==spec['partition'] and x['topology']==topo and x['slot']==slot and
                                x['run']==run and x['arm']==arm,'WRONG_SPLIT_IN_WINDOWS')
                        rows+=wr
                        pairs.append({'partition':spec['partition'],'topology':topo,'slot':slot,'arm':arm,'run':run,
                              'monitored_wall_seconds':rm['wall_seconds'],'control_wall_seconds':ru['wall_seconds'],
                              'paired_wall_delta_seconds':rm['wall_seconds']-ru['wall_seconds'],
                              'monitored_rss_kib':rm['max_rss_kib'],'control_rss_kib':ru['max_rss_kib'],
                              'paired_rss_delta_kib':rm['max_rss_kib']-ru['max_rss_kib'],
                              'candidate_positive':ver['candidate_positive'],'candidate_negative':ver['candidate_negative'],
                              'candidate_unknown':ver['candidate_unknown']})
                    except (OSError,ValueError,KeyError,TypeError) as e:
                        missing.append({'topology':topo,'slot':slot,'arm':arm,'run':run,'error':str(e)})
    expected=2*3*len(ARMS)*2
    complete=len(pairs)==expected and len(rows)==expected*12
    stats={}
    for topo,spec in TOPOLOGIES.items():
        sub=[x for x in rows if x['topology']==topo]
        valid=[x for x in sub if x['candidate_label'] in (0,1)]
        y=[x['candidate_label'] for x in valid]
        scores=[x['online_local_queue_packets'] for x in valid]
        pos=y.count(1);neg=y.count(0);unk=len(sub)-len(valid)
        stats[spec['partition']]={'topology':topo,'n_monitored_runs':len([p for p in pairs if p['topology']==topo]),
         'target_windows':len(sub),'candidate_positive':pos,'candidate_negative':neg,'candidate_unknown':unk,
         'valid_only_prevalence':pos/len(y) if y else None,
         'online_local_queue_proxy_AP_exploratory':ap_score(y,scores),
         'AP_definition':'Noninterpolated AP of online selected-local-queue occupancy; NOT HCRAF score',
         'independent_rng_stream_groups':4,
         'group_aware_ci':'FOUR RNG run clusters per partition: descriptive only; no defensible precise CI',
         'selection_bias':'Valid-only AP excludes UNKNOWN; not representative without missingness analysis'}
    # All acceptance gates pre-registered; a FAIL does not permit post-hoc Test tuning.
    control_count={};control_negative={};pressure_positive={};missingness={};by_arm={}
    for topo,spec in TOPOLOGIES.items():
        sub=[x for x in rows if x['topology']==topo]
        ctrl=[x for x in sub if x['arm'] in CONTROL_ARMS]
        press=[x for x in sub if x['arm'] in PRESSURE_ARMS]
        control_count[spec['partition']]=len(ctrl)
        control_negative[spec['partition']]=sum(x['candidate_label']==0 for x in ctrl)
        pressure_positive[spec['partition']]=sum(x['candidate_label']==1 for x in press)
        missingness[spec['partition']]=(sum(x['candidate_label']=='UNKNOWN' for x in sub)/len(sub)) if sub else None
        by_arm[spec['partition']]={a:{'positive':sum(x['candidate_label']==1 for x in sub if x['arm']==a),
              'negative':sum(x['candidate_label']==0 for x in sub if x['arm']==a),
              'unknown':sum(x['candidate_label']=='UNKNOWN' for x in sub if x['arm']==a)} for a in ARMS}
    has_class_both=all(stats[k]['candidate_positive']>0 and stats[k]['candidate_negative']>0 for k in ('VALIDATION','TEST'))
    # At least HALF of prospective control windows must have physically grounded low queues.
    robust_negative=all(control_count.get(k)==432 and control_negative.get(k,0)>=216 for k in ('VALIDATION','TEST'))
    robust_pressure=all(pressure_positive.get(k,0)>=24 and all(
        by_arm[k][a]['positive']>0 for a in PRESSURE_ARMS) for k in ('VALIDATION','TEST'))
    improved_missingness=all(missingness.get(k) is not None and missingness[k]<=0.40 for k in ('VALIDATION','TEST'))
    clean_controls=all(by_arm[k]['QUIET_CLEAN']['positive']==0 for k in ('VALIDATION','TEST'))
    # Comparison with quiet baseline is diagnostic only, not part of the F3 classification rule.
    impact=[]
    try:
        if complete:impact=paired_completion_rows(root)
    except (OSError,ValueError,KeyError,TypeError) as e:
        missing.append({'paired_completion_diagnostic_error':str(e)})
    impact_complete=len(impact)==len(rows) if complete else False
    passed=(complete and has_class_both and robust_negative and robust_pressure and
            improved_missingness and clean_controls and impact_complete and not missing)
    verdict=STATUS if passed else 'INCOMPLETE_F3_COVERAGE_REMEDIATION_EVIDENCE'
    result={'stage':'1AM.F3_COVERAGE_REMEDIATION_FOUR_HOP.0','version':'0.45.0','status':verdict,
       'expected_monitored_runs':expected,'expected_total_simulations':expected*2,
       'observed_monitored_runs':len(pairs),'observed_target_windows':len(rows),
       'missing_runs_or_errors':missing,'results_by_partition':stats,
       'by_partition_arm':by_arm,
       'control_negative_windows':control_negative,'pressure_positive_windows':pressure_positive,
       'unknown_fraction_all_arms':missingness,
       'coverage_gates':{'integrity_all_168_pairs':complete,'both_classes_in_each_partition':has_class_both,
         'at_least_half_control_windows_negative':robust_negative,
         'at_least_24_positive_in_each_partition_and_each_pressure_arm':robust_pressure,
         'unknown_rate_at_most_40_percent_in_each_partition':improved_missingness,
         'quiet_controls_have_no_positive':clean_controls,
         'paired_completion_diagnostics_complete':impact_complete},
       'paired_schedule_verified':complete,'old_TEST_CHAIN_D_is_already_observed':True,
       'NEW_TEST_CHAIN_F_used_only_after_E_validation_integrity_seal':True,
       'primary_horizon_ns_locked':50_000_000,'primary_wait_ns_locked':5_000_000,
       'primary_max_queue_packets_locked':2,
       'official_F3_labels':0,'Congestion':None,'FutureCongestion':None,
       'GO_FREEZE':False,'F3_ready':False,'training_ready':False,
       'science_status':'NO_GO_F3_CONSTRUCT_AND_PREDICTABILITY_NOT_VALIDATED',
       'why_not_final_F3':['candidate drop-based endpoint not validated as target harm',
            'only 4 RNG groups per partition, shared over arms/faces',
            'candidate 0 based on telemetry completeness, not a globally healthy network',
            'forced Face selection probability 1, no alternate Face counterfactual',
            'no actual HCRAF Gate prediction, no F3 PR-AUC or NSGA-III model',
            'observer timing includes NFD recorder, not Gate-only cost',
            'TEST must never be used for tuning after results are seen']}
    out=root/'summary';out.mkdir(exist_ok=True)
    (out/'summary.json').write_bytes(json_bytes(result))
    (out/'paired_resources.csv').write_bytes(to_csv(pairs,list(pairs[0]) if pairs else
           ['partition','topology','slot','arm','run','candidate_positive']))
    (out/'candidate_windows.csv').write_bytes(to_csv(rows,list(rows[0]) if rows else
           ['partition','topology','slot','arm','run','candidate_label']))
    (out/'paired_target_completion_diagnostics.csv').write_bytes(to_csv(impact,list(impact[0]) if impact else
           ['partition','topology','slot','run','arm','name','arm_data_delay_ns']))
    print(verdict,'pairs',len(pairs),'windows',len(rows),'control_negative',control_negative,'unknown_rates',missingness)
    return verdict==STATUS

if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('usage: summarize_stage1am_heldout.py OUT_ROOT')
    raise SystemExit(0 if main(sys.argv[1]) else 3)
