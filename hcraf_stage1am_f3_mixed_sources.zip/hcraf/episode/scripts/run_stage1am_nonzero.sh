#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
OUT="$ROOT/episode_output/stage1am_nonzero/DEV_CHAIN_B"
mkdir -p "$OUT"
cd "$ROOT/episode_sources/ns-3"
failed=0
for arm in OFF_BASELINE ON_BURST_OVERLAP ON_BURST_AFTER_TARGET ON_BURST_TAIL; do
  case "$arm" in
    OFF_BASELINE) comp=0;target=30000000;comp_offset=0;;
    ON_BURST_OVERLAP) comp=160;target=30000000;comp_offset=0;;
    ON_BURST_AFTER_TARGET) comp=160;target=30000000;comp_offset=800000000;;
    ON_BURST_TAIL) comp=160;target=120000000;comp_offset=0;;
    *) exit 8;;
  esac
  cint=0;[ "$comp" -eq 0 ] || cint=1000000
  for seed in 9501 9502 9503; do
    for monitor in 1 0; do
      if [ "$monitor" = 1 ];then kind=monitored;else kind=uninstrumented;fi
      dest="$OUT/$kind/$arm/run-$seed"
      mkdir -p "$dest"
      cmd="hcraf-stage1am-nonzero-pilot --topology=DEV_CHAIN_B --selectedSlot=0 --mode=LP_INDEPENDENT_COMPETITOR_NO_DROP --seed=17 --run=$seed --output=$dest --instrument=$monitor --lifetimeMs=2600 --requestCount=12 --intervalNs=30000000 --competitorCount=$comp --competitorIntervalNs=$cint --competitorOffsetNs=$comp_offset --targetOffsetNs=$target --forwardBps=50000 --returnBps=5000000"
      printf '%s\n' "$cmd" > "$dest/command.txt"
      if ! /usr/bin/time -f 'wall_seconds=%e\nuser_seconds=%U\nsystem_seconds=%S\nmax_rss_kib=%M' -o "$dest/resource_usage.txt" \
        python3 ./waf --run-no-build "$cmd" > "$dest/simulator.log" 2>&1; then
        echo "SIMULATION_FAIL: $arm $seed $monitor";failed=1;continue
      fi
      if [ "$monitor" = 1 ]; then
        if ! python3 "$TASK/scripts/episodes_stage1u.py" "$dest" --run-id "1am_nonzero-B-0-$arm-17-$seed" > "$dest/episodes.log" 2>&1; then
          echo "EPISODE_FAIL: $arm $seed";failed=1;continue
        fi
        if ! python3 "$TASK/scripts/verify_stage1am_nonzero.py" "$dest" --arm "$arm" > "$dest/verify.log" 2>&1; then
          echo "VERIFICATION_FAIL: $arm $seed";failed=1
        fi
      fi
    done
  done
done
if ! python3 "$TASK/scripts/summarize_stage1am_nonzero.py" "$OUT"; then failed=1;fi
exit "$failed"
