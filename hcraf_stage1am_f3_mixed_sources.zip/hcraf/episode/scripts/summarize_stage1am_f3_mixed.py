#!/usr/bin/env python3
"""Stage1AM v0.47 mixed RNG I/J held-out candidate evaluation with prospective low-pressure controls.

Never computes a final F3 score or confidence interval from correlated windows.
"""
import collections,csv,hashlib,io,json,math,pathlib,statistics,sys
from f3_mixed_rng_v047 import TOPOLOGIES,ARMS,CONTROL_ARMS,PRESSURE_ARMS,STATUS,json_bytes,to_csv,need


def parse_resource(p):
    lines=p.read_text().splitlines()
    obj={k:float(v) for line in lines if '=' in line for k,v in [line.strip().split('=',1)]}
    need(all(k in obj for k in ('wall_seconds','user_seconds','system_seconds','max_rss_kib')),'MISSING_PAIR_RESOURCE_METRICS')
    need(all(math.isfinite(x) and x>=0 for x in obj.values()),'INVALID_RESOURCE_METRIC')
    return obj


def find_sends(root):
    p=root/'consumer_events.jsonl'
    need(p.is_file(),'MISSING_PAIRED_TARGET_SEND')
    data=[json.loads(l) for l in p.read_text().splitlines() if l.strip()]
    sends=[(x['name'],x['nonce'],x['time_ns']) for x in data if x['event']=='SEND']
    need(len(sends)==12 and len(set(sends))==12,'WRONG_TARGET_SENDS')
    arrivals=root/'consumer_events.jsonl.arrivals.jsonl'
    need(arrivals.exists(),'MISSING_TARGET_SCHEDULE')
    return sends,arrivals.read_bytes()


def ap_score(y,s):
    """Non-interpolated average precision; ties grouped, not arbitrary order."""
    if not y or 1 not in y or 0 not in y:return None
    groups=collections.defaultdict(lambda:[0,0])
    for v,x in zip(y,s):
        need(v in (0,1) and type(x) in (int,float) and math.isfinite(x),'INVALID_AP_INPUT')
        groups[x][int(v)]+=1
    tp=fp=0;prev_recall=0.0;ans=0.0; positives=sum(y)
    for score in sorted(groups,reverse=True):
        negatives,positives_at=groups[score]
        tp+=positives_at;fp+=negatives
        recall=tp/positives
        ans+=(recall-prev_recall)*tp/(tp+fp)
        prev_recall=recall
    return ans



def target_outcomes(root):
    """Return sent-name -> time-to-first-data or None. Does NOT infer timeout labels."""
    p=pathlib.Path(root)/'consumer_events.jsonl'
    events=[json.loads(l) for l in p.read_text().splitlines() if l.strip()]
    sends={}
    data={}
    for e in events:
        if e.get('event')=='SEND':
            need(e.get('name') not in sends, 'DUPLICATE_TARGET_SEND')
            sends[e['name']]=e['time_ns']
        elif e.get('event')=='DATA':
            n=e.get('name')
            if n in sends and e.get('time_ns',-1)>=sends[n]:
                data[n]=min(data.get(n,e['time_ns']),e['time_ns'])
    need(len(sends)==12,'WRONG_TARGET_SENDS_FOR_COMPLETION')
    return {n:None if n not in data else data[n]-t for n,t in sends.items()}


def paired_completion_rows(root):
    """Protocol comparability to QUIET_CLEAN, NOT causal or policy-counterfactual labels."""
    rows=[]
    for topo,spec in TOPOLOGIES.items():
        for slot in range(3):
            for rng in spec['runs']:
                base=root/topo/f'slot-{slot}'/'monitored'
                anchor=target_outcomes(base/'QUIET_CLEAN'/f'run-{rng}')
                for arm in ARMS:
                    current=target_outcomes(base/arm/f'run-{rng}')
                    need(set(current)==set(anchor), 'PAIRED_TARGET_NAME_MISMATCH')
                    for name in sorted(anchor):
                        a,b=anchor[name],current[name]
                        rows.append({'partition':spec['partition'],'topology':topo,'slot':slot,
                           'run':rng,'arm':arm,'name':name,
                           'quiet_data_delay_ns':a,'arm_data_delay_ns':b,
                           'paired_delta_ns_if_both_received':b-a if a is not None and b is not None else None,
                           'quiet_receipt_observed':a is not None,'arm_receipt_observed':b is not None,
                           'is_FutureCongestion_label':False,
                           'interpretation':'DESCRIPTIVE_PAIRED_SCENARIO_ONLY_NOT_CAUSAL_GATE'})
    return rows

def main(root):
    root=pathlib.Path(root);rows=[];pairs=[];missing=[]
    for topo,spec in TOPOLOGIES.items():
        for slot in range(3):
            for arm in ARMS:
                for run in spec['runs']:
                    base=root/topo/f'slot-{slot}'
                    m=base/'monitored'/arm/f'run-{run}'
                    u=base/'uninstrumented'/arm/f'run-{run}'
                    try:
                        ver=json.loads((m/'stage1am_f3_mixed_verification.json').read_text())
                        wr=json.loads((m/'stage1am_f3_mixed_windows.json').read_text())
                        cfg_m=json.loads((m/'scenario.json').read_text())
                        cfg_u=json.loads((u/'scenario.json').read_text())
                        need(ver['status']==STATUS and ver['candidate_positive']+ver['candidate_negative']+ver['candidate_unknown']==12,
                            'INCOMPLETE_MONITORED_AUDIT')
                        need(len(wr)==12 and all(x['FutureCongestion'] is None and x['F3_ready'] is False and
                             x['GO_FREEZE'] is False and x['training_ready'] is False for x in wr),
                             'FORBIDDEN_FINAL_F3_PROMOTION')
                        need(cfg_m['instrument_enabled'] is True and cfg_u['instrument_enabled'] is False and
                             all(cfg_m[k]==cfg_u[k] for k in ('path_nodes','selected_face_slot','selected_face_id',
                                 'selected_forward_bps','selected_relay_forward_bps','selected_mid_forward_bps',
                                 'selected_producer_reverse_bps','selected_return_bps','phase_arm','run','seed')),
                             'PAIRED_SCENARIO_MISMATCH')
                        tm,am=find_sends(m);tu,au=find_sends(u)
                        need(tm==tu and am==au,'TARGET_SEND_SCHEDULE_PERTURBED')
                        rm=parse_resource(m/'resource_usage.txt');ru=parse_resource(u/'resource_usage.txt')
                        for x in wr:
                            need(x['partition']==spec['partition'] and x['topology']==topo and x['slot']==slot and
                                x['run']==run and x['arm']==arm,'WRONG_SPLIT_IN_WINDOWS')
                        rows+=wr
                        pairs.append({'partition':spec['partition'],'topology':topo,'slot':slot,'arm':arm,'run':run,
                              'monitored_wall_seconds':rm['wall_seconds'],'control_wall_seconds':ru['wall_seconds'],
                              'paired_wall_delta_seconds':rm['wall_seconds']-ru['wall_seconds'],
                              'monitored_rss_kib':rm['max_rss_kib'],'control_rss_kib':ru['max_rss_kib'],
                              'paired_rss_delta_kib':rm['max_rss_kib']-ru['max_rss_kib'],
                              'candidate_positive':ver['candidate_positive'],'candidate_negative':ver['candidate_negative'],
                              'candidate_unknown':ver['candidate_unknown']})
                    except (OSError,ValueError,KeyError,TypeError) as e:
                        missing.append({'topology':topo,'slot':slot,'arm':arm,'run':run,'error':str(e)})
    expected=sum(3*len(ARMS)*len(spec['runs']) for spec in TOPOLOGIES.values())
    complete=len(pairs)==expected and len(rows)==expected*12
    stats={}
    for topo,spec in TOPOLOGIES.items():
        sub=[x for x in rows if x['topology']==topo]
        valid=[x for x in sub if x['candidate_label'] in (0,1)]
        y=[x['candidate_label'] for x in valid]
        scores=[x['online_local_queue_packets'] for x in valid]
        pos=y.count(1);neg=y.count(0);unk=len(sub)-len(valid)
        stats[spec['partition']]={'topology':topo,'n_monitored_runs':len([p for p in pairs if p['topology']==topo]),
         'target_windows':len(sub),'candidate_positive':pos,'candidate_negative':neg,'candidate_unknown':unk,
         'valid_only_prevalence':pos/len(y) if y else None,
         'online_local_queue_proxy_AP_exploratory':ap_score(y,scores),
         'AP_definition':'Noninterpolated AP of online selected-local-queue occupancy; NOT HCRAF score',
         'independent_rng_stream_groups':6,
         'group_aware_ci':'SIX independent ns-3 RngRun clusters per partition: diagnostic only; no defensible precise CI from correlated windows',
         'selection_bias':'Valid-only AP excludes UNKNOWN; not representative without missingness analysis'}
    # v0.47 acceptance is not just a number of seed names: verify actual pulse
    # timestamps differ and are matched across monitoring modes and all arms.
    stress_mix_by_arm={};by_arm={};rng_diagnostics={};pulse_gates={}
    for topology,spec in TOPOLOGIES.items():
        partition=spec['partition']
        ts=[x for x in rows if x['topology']==topology]
        by_arm[partition]={arm:{'positive':sum(x['candidate_label']==1 for x in ts if x['arm']==arm),
           'negative':sum(x['candidate_label']==0 for x in ts if x['arm']==arm),
           'unknown':sum(x['candidate_label']=='UNKNOWN' for x in ts if x['arm']==arm)} for arm in ARMS}
        arm_cross={};mixed_runs_by_arm={};mean_start_by_seed=[];pulse_matched=True
        hashes_by_run={}
        for slot in range(3):
            for run in spec['runs']:
                signatures=[];starts=[]
                for arm in PRESSURE_ARMS:
                    base=root/topology/f'slot-{slot}'
                    mon=base/'monitored'/arm/f'run-{run}'
                    un=base/'uninstrumented'/arm/f'run-{run}'
                    ma=mon/'competitor_events.jsonl.arrivals.jsonl'
                    ua=un/'competitor_events.jsonl.arrivals.jsonl'
                    try:
                        need(ma.exists() and ua.exists(),'MISSING_COMPETITOR_SCHEDULE')
                        md=ma.read_bytes();ud=ua.read_bytes()
                        need(md==ud,'PAIR_COMPETITOR_PULSE_SCHEDULE_DIFFERS')
                        signatures.append(hashlib.sha256(md).hexdigest())
                        v=[x for x in rows if x['topology']==topology and x['slot']==slot and
                           x['run']==run and x['arm']==arm]
                        need(len(v)==12,'PULSE_RUN_WRONG_WINDOW_COUNT')
                        first={x['competitor_pulse_start_ns_diagnostic_only'] for x in v}
                        need(len(first)==1 and type(next(iter(first))) is int,'PULSE_START_MISMATCH')
                        starts.append(next(iter(first)))
                    except (OSError,ValueError) as e:
                        missing.append({'pulse_signature_error':str(e),'topology':topology,'slot':slot,'run':run,'arm':arm})
                        pulse_matched=False
                if signatures:
                    if len(set(signatures))!=1 or len(set(starts))!=1:
                        pulse_matched=False
                    hashes_by_run[(slot,run)]=signatures[0]
                    if slot==0:mean_start_by_seed.append({'run':run,'pulse_start_ns':starts[0], 'sha256':signatures[0]})
        unique_per_slot=all(len({hashes_by_run.get((slot,run)) for run in spec['runs']})==6
                            and None not in {hashes_by_run.get((slot,run)) for run in spec['runs']}
                            for slot in range(3))
        different_start_ns=len({x['pulse_start_ns'] for x in mean_start_by_seed})==6
        pulse_gates[partition]={'paired_and_across_arm_competitor_schedule_equal':pulse_matched,
              'six_distinct_real_schedule_hashes_per_face':unique_per_slot,
              'six_distinct_first_pulse_starts':different_start_ns}
        rng_diagnostics[partition]=mean_start_by_seed
        for arm in PRESSURE_ARMS:
            x=[v for v in ts if v['arm']==arm]
            mixed_runs=[(slot,run) for slot in range(3) for run in spec['runs']
               if any(v['candidate_label']==1 for v in x if v['slot']==slot and v['run']==run)
               and any(v['candidate_label']==0 for v in x if v['slot']==slot and v['run']==run)]
            mixed_runs_by_arm[arm]=len(mixed_runs)
        stress_mix_by_arm[partition]=mixed_runs_by_arm
    control_negative={};pressure_positive={};pressure_negative={};unknown_fraction={}
    for topo,spec in TOPOLOGIES.items():
        part=spec['partition'];sub=[x for x in rows if x['topology']==topo]
        control_negative[part]=sum(x['candidate_label']==0 for x in sub if x['arm']=='QUIET_CLEAN')
        pressure_positive[part]=sum(x['candidate_label']==1 for x in sub if x['arm'] in PRESSURE_ARMS)
        pressure_negative[part]=sum(x['candidate_label']==0 for x in sub if x['arm'] in PRESSURE_ARMS)
        unknown_fraction[part]=sum(x['candidate_label']=='UNKNOWN' for x in sub)/len(sub) if sub else None
    have_classes=all(stats[p]['candidate_positive']>0 and stats[p]['candidate_negative']>0 for p in ('VALIDATION','TEST'))
    healthy_controls=all(control_negative[p]>=144 and by_arm[p]['QUIET_CLEAN']['positive']==0 for p in ('VALIDATION','TEST'))
    under_load_both=all(pressure_negative[p]>=12 and pressure_positive[p]>=24 and
          sum(by_arm[p][a]['positive']>0 and by_arm[p][a]['negative']>0 for a in PRESSURE_ARMS)>=2 and
          sum(stress_mix_by_arm[p][a]>=1 for a in PRESSURE_ARMS)>=2
          for p in ('VALIDATION','TEST'))
    unknown_acceptable=all(unknown_fraction[p] is not None and unknown_fraction[p]<=0.40 for p in ('VALIDATION','TEST'))
    real_rng_diversity=all(all(pulse_gates[p].values()) for p in ('VALIDATION','TEST'))
    no_missing=not missing
    impact=[]
    try:
        if complete:impact=paired_completion_rows(root)
    except (OSError,ValueError,KeyError,TypeError) as e:
        missing.append({'paired_completion_diagnostic_error':str(e)})
    impact_complete=len(impact)==len(rows)
    # Verify G/I validation evidence could not be silently altered after the seal.
    seal_path=root/'validation_sealed_before_new_test.json'
    try:
        seal=json.loads(seal_path.read_text())
        hashes=seal.get('validation_file_sha256',{})
        need(seal.get('status')=='I_VALIDATION_INTEGRITY_SEALED_J_TEST_NOT_USED' and
             len(hashes)==270,'VALIDATION_SEAL_MISSING_OR_INCOMPLETE')
        need(all(hashlib.sha256((root/k).read_bytes()).hexdigest()==v for k,v in hashes.items()),
             'VALIDATION_SEAL_TAMPERING_AFTER_TEST')
        seal_pass=True
    except (OSError,ValueError,TypeError) as e:
        missing.append({'validation_seal_error':str(e)})
        seal_pass=False
    passed=(complete and have_classes and healthy_controls and under_load_both and
            unknown_acceptable and real_rng_diversity and impact_complete and seal_pass and no_missing)
    verdict=STATUS if passed else 'INCOMPLETE_F3_MIXED_RNG_AND_SAME_LOAD_EVIDENCE'
    # Crucial: the F3 Gate is NOT trained here; even PASS is a candidate pilot.
    result={'stage':'1AM.F3_MIXED_RNG_PRESSURE_FOUR_HOP.0','version':'0.47.0','status':verdict,
       'expected_monitored_runs':180,'expected_total_simulations':360,
       'observed_monitored_runs':len(pairs),'observed_target_windows':len(rows),
       'missing_runs_or_errors':missing,'results_by_partition':stats,
       'by_partition_arm':by_arm,'pressure_mixed_runs_by_arm':stress_mix_by_arm,
       'competitor_pulse_seeds':rng_diagnostics,'competitor_pulse_gates':pulse_gates,
       'control_negative_windows':control_negative,'pressure_positive_windows':pressure_positive,
       'pressure_negative_windows':pressure_negative,'unknown_fraction_all_arms':unknown_fraction,
       'pilot_gates':{'all_180_matched_pairs':complete,'both_classes':have_classes,
          'healthy_low_pressure_reference':healthy_controls,
          'both_classes_under_similar_offered_load_within_same_pressure_arms':under_load_both,
          'unknown_at_most_40_percent':unknown_acceptable,
          'six_genuine_distinct_rng_input_schedules':real_rng_diversity,
          'paired_harm_diagnostics_complete':impact_complete,
          'I_validation_pre_test_seal_intact':seal_pass,'all_input_traces_valid':no_missing},
       'mixed_classes_are_observational_pilot_not_balanced_causal_intervention':True,
       'candidate_endpoints_not_equivalent_to_target_harm':True,
       'new_TEST_CHAIN_J_has_never_been_used_for_tuning':True,
       'previous_TEST_CHAIN_H_already_observed':True,
       'primary_horizon_ns_locked':50_000_000,'primary_wait_ns_locked':5_000_000,
       'posthoc_target_harm_delta_ns_diagnostic_only':5_000_000,
       'official_F3_labels':0,'Congestion':None,'FutureCongestion':None,
       'GO_FREEZE':False,'F3_ready':False,'training_ready':False,
       'science_status':'NO_GO_F3_CONSTRUCT_AND_PREDICTABILITY_NOT_VALIDATED',
       'limitations':['Candidate labels depend on future physical evidence and Target receipt; NOT usable online',
                      'RNG diversifies competitor input, not automatically statistically independent windows',
                      'All Face choices forced; no counterfactual across alternate Faces',
                      'No HCRAF gate training or F3 model PR-AUC',
                      'Test J cannot be reused for subsequent metric tuning',
                      'Observer timing includes recorder not HCRAF Gate-only time']}
    out=root/'summary';out.mkdir(exist_ok=True)
    (out/'summary.json').write_bytes(json_bytes(result))
    (out/'paired_resources.csv').write_bytes(to_csv(pairs,list(pairs[0]) if pairs else
           ['partition','topology','slot','arm','run','candidate_positive']))
    (out/'candidate_windows.csv').write_bytes(to_csv(rows,list(rows[0]) if rows else
           ['partition','topology','slot','arm','run','candidate_label']))
    (out/'paired_target_completion_diagnostics.csv').write_bytes(to_csv(impact,list(impact[0]) if impact else
           ['partition','topology','slot','run','arm','name','arm_data_delay_ns']))
    print(verdict,'pairs',len(pairs),'windows',len(rows),'pressure_negative',pressure_negative,'unknown_rates',unknown_fraction)
    return verdict==STATUS

if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('usage: summarize_stage1am_f3_mixed.py OUT_ROOT')
    raise SystemExit(0 if main(sys.argv[1]) else 3)
