#!/usr/bin/env python3
"""Four-hop held-out F3 *candidate* evidence. Fail-closed, never emits official labels.

Actual physical QUEUE_DROP, QUEUE_DEQUEUE queue wait and reconstructed LP groups
are label-only, NEVER available to HCRAF at decision time. Selected Face forced.
"""
import argparse, collections, csv, hashlib, io, json, math, pathlib, random
import sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from oracle_stage1am_lp_return import group_inventory
from verify_stage1am_pathwide import check_receipt_nonce_alignment, read_jsonl

SCHEMA='1AM.F3_HELDOUT_FOUR_HOP_PILOT.0'
TOPOLOGIES={
    'VAL_CHAIN_C': {'partition':'VALIDATION','mid':(5,6,7),'producer':(8,9,10),'runs':(9721,9722),'rate':6_000_000},
    'TEST_CHAIN_D': {'partition':'TEST','mid':(7,5,6),'producer':(10,8,9),'runs':(9821,9822),'rate':9_000_000},
}
ARMS=('OFF_BASELINE','LOCAL_FORWARD','RELAY_FORWARD','MID_FORWARD','RETURN_DATA','LATE_COMPETITOR')
PRIMARY_HORIZON_NS=50_000_000
PRIMARY_WAIT_NS=5_000_000
MAX_PRIMARY_QUEUE_PACKETS=2  # 3+ queued packets prevents a negative claim
HORIZONS_NS=(25_000_000,50_000_000,100_000_000)
WAIT_NS=(2_000_000,5_000_000,10_000_000)
STOP_NS=20_000_000_000
WINDOWS_PER_RUN=12
PATH_DEVICES=8
ALL_DEVICES=20
STATUS='PASS_HELDOUT_EVIDENCE_PILOT_ONLY'

class HeldoutError(ValueError): pass

def need(ok,msg):
    if not ok: raise HeldoutError(msg)

def load_json(path):
    return json.loads(pathlib.Path(path).read_text())

def json_bytes(o):
    return (json.dumps(o,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()

def to_csv(rows,keys):
    buf=io.StringIO(newline='');w=csv.DictWriter(buf,fieldnames=keys,lineterminator='\n');w.writeheader();w.writerows(rows)
    return buf.getvalue().encode()

def selected_path(cfg, initials):
    topo=cfg.get('topology_id');slot=cfg.get('selected_face_slot')
    need(topo in TOPOLOGIES and type(slot) is int and slot in (0,1,2),'TOPO_SLOT_INVALID')
    spec=TOPOLOGIES[topo]
    relay=2+slot;mid=spec['mid'][slot];producer=spec['producer'][slot]
    need(cfg.get('path_nodes')==[0,1,relay,mid,producer] and
         cfg.get('selected_mid_node_id')==mid and cfg.get('selected_relay_node_id')==relay and
         cfg.get('selected_producer_node_id')==producer,'NOT_GENUINE_FOUR_HOP_PATH')
    forward=((0,0),(1,slot+1),(relay,1),(mid,1))
    reverse=((producer,0),(mid,0),(relay,0),(1,0))
    need(len(set(forward+reverse))==8 and set(forward+reverse)<=set(initials),'MISSING_PATH_DEVICE')
    need(initials[(1,slot+1)]['face_id']==cfg['selected_face_id'],'SELECTED_FACE_NOT_PHYSICAL')
    return forward,reverse

def check_plan(cfg,topology,slot,arm,run,monitored=True):
    need(topology in TOPOLOGIES and slot in (0,1,2) and arm in ARMS,'UNREGISTERED_TEST_CELL')
    spec=TOPOLOGIES[topology]
    need(run in spec['runs'],'RUN_CROSSES_PARTITION')
    need(cfg.get('amendment_stage')==SCHEMA and cfg.get('collector_stage')=='1AM.NFD_LOCAL_QUEUE.0','WRONG_SOURCE_VERSION')
    need(cfg.get('topology_id')==topology and cfg.get('holdout_partition')==spec['partition'] and
         cfg.get('selected_face_slot')==slot and cfg.get('phase_arm')==arm and cfg.get('run')==run and cfg.get('seed')==17,
         'UNREGISTERED_METADATA')
    need(cfg.get('network_node_count')==11 and cfg.get('network_directed_device_count')==20 and
         cfg.get('path_nodes')==[0,1,2+slot,spec['mid'][slot],spec['producer'][slot]],'NOT_FOUR_HOP')
    need(cfg.get('planned_requests')==12 and cfg.get('nominal_arrival_interval_ns')==30_000_000 and
         cfg.get('interest_lifetime_ms')==2600 and cfg.get('stop_ns')==STOP_NS and
         cfg.get('queue_capacity_packets')==20 and cfg.get('mtu_bytes')==600 and
         cfg.get('future_oracle_horizon_ns_pilot')==PRIMARY_HORIZON_NS,
         'TARGET_OR_QUEUE_PLAN_CHANGED')
    need(cfg.get('instrument_enabled') is monitored and
         cfg.get('future_oracle_scope')=='EIGHT_DIRECTED_DEVICES_FOUR_HOP_DIAGNOSTIC_WITH_CENSORING' and
         cfg.get('future_oracle_is_final_F3') is False and cfg.get('remote_queue_online_feature') is False and
         cfg.get('no_counterfactual_unselected_face') is True and cfg.get('actual_assignment_probability')==1.0,
         'INVALID_ONLINE_OR_POLICY_CLAIM')
    for k in ('F3_ready','training_ready'):
        need(cfg.get(k) is False,'FORBIDDEN_READINESS_'+k)
    for k in ('future_congestion','congestion','decision_time_us_real_HCRAF'):
        need(k in cfg and cfg[k] is None,'FORBIDDEN_PROMOTED_FIELD_'+k)
    nc=0 if arm=='OFF_BASELINE' else 160
    need(cfg.get('competitor_planned_requests')==nc and
         cfg.get('competitor_interval_ns')==(0 if nc==0 else 1_000_000) and
         cfg.get('competitor_offset_ns')==(800_000_000 if arm=='LATE_COMPETITOR' else 0) and
         cfg.get('selected_forward_bps')==(50_000 if arm=='LOCAL_FORWARD' else 5_000_000) and
         cfg.get('selected_return_bps')==5_000_000 and
         cfg.get('selected_relay_forward_bps')==(50_000 if arm=='RELAY_FORWARD' else spec['rate']) and
         cfg.get('selected_mid_forward_bps')==(50_000 if arm=='MID_FORWARD' else spec['rate']) and
         cfg.get('selected_producer_reverse_bps')==(50_000 if arm=='RETURN_DATA' else spec['rate']),
         'BOTTLENECK_PLAN_CHANGED')
    faces=cfg.get('eligible_face_ids')
    need(isinstance(faces,list) and len(faces)==3 and len(set(faces))==3 and
         cfg['selected_face_id']==faces[slot],'INVALID_CANDIDATE_FACE_MAP')


def sender_interest_index(root):
    sent={}
    for name in ('consumer_events.jsonl','competitor_events.jsonl'):
        path=root/name
        if path.exists():
            for x in read_jsonl(path):
                if x.get('event')!='SEND':continue
                n=x.get('name');k=x.get('nonce')
                need(isinstance(n,str) and type(k) is int and 0<=k<2**32,'BAD_SENDER_ID')
                need(n not in sent,'DUPLICATE_INTEREST_NAME')
                sent[n]=k
    need(len([n for n in sent if n.startswith('/hcraf/pilot/')])==12,'MISSING_TARGET_SENDS')
    return sent


def class_drop(e,sent,reverse,lp_inventory):
    """Authenticated packet drop class; no ambiguous loss promoted to negative."""
    ptype=e.get('ndn_packet_type');lp=e.get('lp_status')
    name=e.get('ndn_name');nonce=e.get('ndn_nonce')
    if ptype=='INTEREST' and lp=='SINGLE_LP' and type(nonce) is int and \
       isinstance(name,str) and sent.get(name)==nonce:
        if name.startswith('/hcraf/pilot/'):return 'TARGET_INTEREST'
        if name.startswith('/hcraf/competitor/'):return 'COMPETITOR_INTEREST'
    if (e.get('node_id'),e.get('device_index')) in reverse and lp=='FRAGMENT':
        start=e.get('lp_group_start_seq')
        key=(e.get('node_id'),e.get('device_index'),start)
        group=lp_inventory.get(key)
        if group is not None and group['class'] in ('TARGET_DATA','COMPETITOR_DATA'):
            return group['class']
    return 'UNKNOWN'


def adjudicate_window(t, horizon_ns, wait_ns, phys, path_keys, return_keys, inventory, sent):
    """Candidate only: verified path drop is evidence, no-drop + high wait -> UNKNOWN."""
    need(type(t) is int and 0<t<STOP_NS and horizon_ns in HORIZONS_NS and wait_ns in WAIT_NS,'BAD_WINDOW')
    if t+horizon_ns>STOP_NS:
        return ('UNKNOWN','CENSORED_HORIZON',0,0,0,0,0)
    drops=[e for e in phys if e.get('event_type')=='QUEUE_DROP' and
           (e.get('node_id'),e.get('device_index')) in path_keys and
           t<e['time_ns']<=t+horizon_ns]
    waits=[e.get('queue_wait_ns') for e in phys if e.get('event_type')=='QUEUE_DEQUEUE' and
           (e.get('node_id'),e.get('device_index')) in path_keys and
           t<e['time_ns']<=t+horizon_ns]
    if any(type(x) is not int or x<0 for x in waits):
        return ('UNKNOWN','BAD_QUEUE_WAIT_TELEMETRY',0,len(drops),0,0,0)
    occupancies=[e.get('queue_packets') for e in phys if
        (e.get('node_id'),e.get('device_index')) in path_keys and
        t<=e.get('time_ns',-1)<=t+horizon_ns]
    if any(type(x) is not int or x<0 or x>20 for x in occupancies):
        return ('UNKNOWN','INVALID_BACKLOG_TELEMETRY',0,len(drops),0,0,0)
    max_queue=max(occupancies,default=0)
    classes=[class_drop(e,sent,return_keys,inventory) for e in drops]
    unknown=classes.count('UNKNOWN');verified=len(classes)-unknown
    max_wait=max(waits,default=0)
    if unknown:return ('UNKNOWN','UNRESOLVED_DROP_CLASS',verified,len(drops),unknown,max_wait,max_queue)
    if verified:return (1,'VERIFIED_SELECTED_PATH_QUEUE_DROP_CANDIDATE',verified,len(drops),0,max_wait,max_queue)
    if max_wait>=wait_ns:return ('UNKNOWN','HIGH_QUEUE_WAIT_NO_VALIDATED_HARM',0,0,0,max_wait,max_queue)
    if max_queue>MAX_PRIMARY_QUEUE_PACKETS:
        return ('UNKNOWN','HIGH_PATH_QUEUE_BACKLOG_NO_DROP',0,0,0,max_wait,max_queue)
    return (0,'FULLY_OBSERVED_LOW_QUEUE_WAIT_AND_BACKLOG_NO_DROP_CANDIDATE',0,0,0,max_wait,max_queue)


def run_audit(root,topology,slot,arm,run):
    p=pathlib.Path(root)
    cfg=load_json(p/'scenario.json')
    check_plan(cfg,topology,slot,arm,run)
    phys=read_jsonl(p/'link_events.jsonl')
    need(len(phys)>ALL_DEVICES*2 and [e.get('link_event_seq') for e in phys]==list(range(1,len(phys)+1)),
         'MISSING_OR_REORDERED_PHYSICAL_EVENTS')
    inits={(e['node_id'],e['device_index']):e for e in phys if e.get('event_type')=='INITIAL'}
    finals={(e['node_id'],e['device_index']):e for e in phys if e.get('event_type')=='FINAL'}
    need(len(inits)==len(finals)==ALL_DEVICES and set(inits)==set(finals),'INCOMPLETE_TWENTY_DEVICE_COVERAGE')
    need(all(e['time_ns']==0 for e in inits.values()) and
         all(e['time_ns']==STOP_NS for e in finals.values()),'INCOMPLETE_20S_RECORDING')
    for e in phys:
        k=(e.get('node_id'),e.get('device_index'))
        need(k in inits and e.get('face_id')==inits[k]['face_id'] and
             type(e.get('time_ns')) is int and 0<=e['time_ns']<=STOP_NS,
             'PHYSICAL_DEVICE_OR_TIME_TAMPERING')
    forward,reverse=selected_path(cfg,inits)
    path_keys=set(forward+reverse);rev_keys=set(reverse)
    need(inits[(1,slot+1)]['data_rate_bps']==cfg['selected_forward_bps'] and
         inits[(2+slot,1)]['data_rate_bps']==cfg['selected_relay_forward_bps'] and
         inits[(cfg['selected_mid_node_id'],1)]['data_rate_bps']==cfg['selected_mid_forward_bps'] and
         inits[(cfg['selected_producer_node_id'],0)]['data_rate_bps']==cfg['selected_producer_reverse_bps'] and
         inits[(2+slot,0)]['data_rate_bps']==cfg['selected_return_bps'],
         'PHYSICAL_LINK_RATE_NOT_MATCHING_SCENARIO')
    dec=read_jsonl(p/'events.jsonl.decisions.jsonl')
    states=read_jsonl(p/'events.jsonl.states.jsonl')
    events=read_jsonl(p/'events.jsonl')
    local=read_jsonl(p/'nfd_local_queue_at_decision.jsonl')
    costs=read_jsonl(p/'nfd_dispatch_cost.jsonl')
    receipts=read_jsonl(p/'producer_receipts.jsonl')
    sent=sender_interest_index(p)
    check_receipt_nonce_alignment(receipts,(p/'consumer_events.jsonl',p/'competitor_events.jsonl'),cfg['selected_producer_node_id'])
    n=12+cfg['competitor_planned_requests']
    need(len(dec)==len(costs)==n and len(local)==len(states)==3*n,'NFD_DECISION_OR_LOCAL_SNAPSHOT_COUNT')
    dids={d['decision_id'] for d in dec}
    need(len(dids)==n and len({c['decision_id'] for c in costs})==n and
         len({(x['decision_id'],x['candidate_face_id']) for x in local})==3*n,
         'DUPLICATE_DECISION_LOCAL_OR_COST')
    localmap=collections.defaultdict(list);statemap=collections.defaultdict(list)
    for x in local:localmap[x['decision_id']].append(x)
    for x in states:statemap[x['decision_id']].append(x)
    snap=[e for e in phys if e['event_type']=='DECISION_SNAPSHOT']
    need(len(snap)==ALL_DEVICES*n and
         len({(x['decision_id'],x['node_id'],x['device_index']) for x in snap})==len(snap),
         'PHYSICAL_DECISION_SNAPSHOT_NOT_20_PER_DECISION')
    snapmap={(x['decision_id'],x['node_id'],x['device_index']):x for x in snap}
    tx=collections.defaultdict(list)
    for e in events:
        if e.get('event_type')=='TX_INTEREST':tx[e.get('name')].append(e)
    costmap={c['decision_id']:c for c in costs}
    out=[]
    inventory=group_inventory(phys,rev_keys,receipts)
    for d in dec:
        did=d['decision_id'];t=d['time_ns']
        need(d.get('node_id')==1 and d.get('anchor')=='BEFORE_AFTER_RECEIVE_INTEREST' and
             len(localmap[did])==len(statemap[did])==3 and
             {x['candidate_face_id'] for x in localmap[did]}==set(cfg['eligible_face_ids']) and
             {x['face_id'] for x in statemap[did]}==set(cfg['eligible_face_ids']),
             'DECISION_OR_CANDIDATE_FACE_CORRUPTION')
        for k,ini in inits.items():
            q=snapmap.get((did,*k))
            need(q is not None and q['time_ns']==t and q['face_id']==ini['face_id'] and
                 q['data_rate_bps']==ini['data_rate_bps'],'MISSING_20_SIMULTANEOUS_PHYSICAL_SNAPSHOTS')
        for x in localmap[did]:
            ini=inits.get((1,x['device_index']))
            ps=snapmap.get((did,1,x['device_index']))
            need(ini is not None and ps is not None and
                 x['sim_time_ns']==t and x['observed_before_forwarding'] is True and
                 x['remote_node_queue_accessed'] is False and x['Congestion'] is None and
                 x['future_pressure_label'] is None and
                 ini['face_id']==x['candidate_face_id']==ps['face_id'] and
                 x['queue_packets']==ps['queue_packets'] and
                 x['queue_bytes']==ps['queue_bytes'],'ONLINE_SNAPSHOT_MISMATCH')
        for x in statemap[did]:
            need(x['time_ns']==t and x['max_terminal_event_seq']<=d['after_event_seq'] and
                 x['after_event_seq']==d['after_event_seq'] and x['Congestion'] is None,
                 'FUTURE_NFD_FEATURE_LEAKAGE')
        need(len(tx.get(d['name'],[]))==1 and tx[d['name']][0]['face_id']==cfg['selected_face_id'] and
             tx[d['name']][0]['pit_instance_id']==d['pit_instance_id'] and
             tx[d['name']][0]['event_seq']>d['after_event_seq'] and
             tx[d['name']][0]['time_ns']>=t,'ACTUAL_SELECTED_TX_NOT_PROVEN')
        c=costmap[did]
        need(type(c.get('NFD_forwarding_path_wall_ns')) is int and c['NFD_forwarding_path_wall_ns']>0 and
             type(c.get('NFD_forwarding_path_cpu_ns')) is int and c['NFD_forwarding_path_cpu_ns']>=0 and
             c.get('is_HCRAF_Gate_only_cost') is False,'UNSUPPORTED_HCRAF_GATE_COST_CLAIM')
        if not d['name'].startswith('/hcraf/pilot/'):continue
        q=next(x for x in localmap[did] if x['candidate_face_id']==cfg['selected_face_id'])
        val,why,good,total,unknown,wait,backlog=adjudicate_window(t,PRIMARY_HORIZON_NS,PRIMARY_WAIT_NS,phys,path_keys,rev_keys,inventory,sent)
        row={'partition':TOPOLOGIES[topology]['partition'],'topology':topology,'slot':slot,'run':run,'arm':arm,
             'decision_id':did,'pit_instance_id':d['pit_instance_id'],'name':d['name'],
             't_decision_ns':t,'selected_face_id':cfg['selected_face_id'],'online_local_queue_packets':q['queue_packets'],
             'candidate_label':val,'candidate_reason':why,
             'verified_queue_drop_events_window':good,'all_queue_drop_events_window':total,
             'unknown_drop_events_window':unknown,'max_path_queue_wait_ns_window':wait,
             'max_path_queue_packets_window':backlog,
             'FutureCongestion':None,'F3_ready':False,'GO_FREEZE':False,'training_ready':False}
        out.append(row)
    need(len(out)==WINDOWS_PER_RUN and len({r['name'] for r in out})==WINDOWS_PER_RUN,'WRONG_TARGET_WINDOWS')
    if arm=='OFF_BASELINE':
        need(all(sum(1 for e in phys if e.get('event_type')=='PHY_TX_BEGIN' and
                     (e.get('node_id'),e.get('device_index'))==k)>0 for k in forward+reverse),
             'SELECTED_LONG_PATH_NOT_PHYSICALLY_USED')
        need(all(r['candidate_label']!=1 for r in out),'BASELINE_UNEXPECTED_QUEUE_HARM')
    sensitivity={}
    for horizon in HORIZONS_NS:
        for threshold in WAIT_NS:
            labels=[adjudicate_window(d['time_ns'],horizon,threshold,phys,path_keys,rev_keys,inventory,sent)[0]
                    for d in dec if d['name'].startswith('/hcraf/pilot/')]
            sensitivity[f'horizon_{horizon}_wait_{threshold}']={
               'positive':labels.count(1),'negative':labels.count(0),'UNKNOWN':labels.count('UNKNOWN')}
    return {'status':STATUS,'sensitivity_not_for_test_tuning':sensitivity,'topology':topology,'partition':TOPOLOGIES[topology]['partition'],
            'arm':arm,'slot':slot,'run':run,'NFD_decisions':n,'target_windows':out,
            'queue_drop_total_selected':sum(e['event_type']=='QUEUE_DROP' and
                            (e['node_id'],e['device_index']) in path_keys for e in phys),
            'lp_groups_complete':sum(v['class'] in ('TARGET_DATA','COMPETITOR_DATA') for v in inventory.values()),
            'lp_groups_unknown':sum(v['class'] not in ('TARGET_DATA','COMPETITOR_DATA') for v in inventory.values()),
            'candidate_positive':sum(r['candidate_label']==1 for r in out),
            'candidate_negative':sum(r['candidate_label']==0 for r in out),
            'candidate_unknown':sum(r['candidate_label']=='UNKNOWN' for r in out),
            'official_F3_labels':0,'Congestion':None,'FutureCongestion':None,
            'GO_FREEZE':False,'F3_ready':False,'training_ready':False}


def cmd_run(argv=None):
    a=argparse.ArgumentParser()
    a.add_argument('directory');a.add_argument('--topology',required=True);a.add_argument('--slot',type=int,required=True)
    a.add_argument('--arm',required=True);a.add_argument('--run',type=int,required=True)
    z=a.parse_args(argv)
    result=run_audit(z.directory,z.topology,z.slot,z.arm,z.run)
    p=pathlib.Path(z.directory)
    (p/'stage1am_heldout_verification.json').write_bytes(json_bytes({k:v for k,v in result.items() if k!='target_windows'}))
    (p/'stage1am_heldout_windows.json').write_bytes(json_bytes(result['target_windows']))
    print(STATUS,z.topology,z.slot,z.arm,z.run, result['candidate_positive'],result['candidate_negative'],result['candidate_unknown'])

if __name__=='__main__':cmd_run()
