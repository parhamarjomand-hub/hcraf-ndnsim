#!/usr/bin/env python3
"""Fail-closed 48-run DEV-only LP group sender attribution pilot."""
import csv,json,sys
from pathlib import Path
from collections import defaultdict
TOPO=('DEV_CHAIN_A','DEV_CHAIN_B')
SLOTS=(0,1,2)
ARMS=('OFF_BASELINE','RETURN_DATA')
SEEDS=(9601,9602)

def summarize(root):
    root=Path(root)
    rows=[]; errors=[]
    for topo in TOPO:
        for slot in SLOTS:
            for arm in ARMS:
                for seed in SEEDS:
                    b=root/topo/f'slot-{slot}'
                    m=b/'monitored'/arm/f'run-{seed}'
                    u=b/'uninstrumented'/arm/f'run-{seed}'
                    try:
                        r=json.loads((m/'stage1am_lp_return_verification.json').read_text())
                        if (r['topology'],r['slot'],r['arm'],r['rng_run'])!=(topo,slot,arm,seed) or \
                           r['status']!='PASS_GROUP_TRACE_AUDIT_ONLY' or r['GO_FREEZE'] is not False or \
                           r['F3_ready'] is not False or r['training_ready'] is not False or r['FutureCongestion'] is not None:
                            raise ValueError('bad run verification identity/readiness')
                        if sum(r['windows_new_return_diagnostic'].values())!=12:
                            raise ValueError('missing target windows')
                        for k,p in [('monitored',m),('uninstrumented',u)]:
                            s=json.loads((p/'scenario.json').read_text())
                            if (s['topology_id'],s['selected_face_slot'],s['phase_arm'],s['run'],s['instrument_enabled']) != \
                               (topo,slot,arm,seed,k=='monitored'):
                                raise ValueError('paired run configuration mismatch')
                            if not (p/'producer_receipts.jsonl').is_file() or not (p/'resource_usage.txt').is_file():
                                raise ValueError('missing paired producer or cost evidence')
                        if (m/'consumer_events.jsonl.arrivals.jsonl').read_bytes()!= \
                           (u/'consumer_events.jsonl.arrivals.jsonl').read_bytes():
                            raise ValueError('paired TARGET generation changed')
                        rows.append(r)
                    except Exception as exc:
                        errors.append(f'{topo}/{slot}/{arm}/{seed}: {type(exc).__name__}: {exc}')
            for seed in SEEDS:
                a=[root/topo/f'slot-{slot}'/'monitored'/arm/f'run-{seed}'/'consumer_events.jsonl.arrivals.jsonl' for arm in ARMS]
                if all(p.is_file() for p in a) and a[0].read_bytes()!=a[1].read_bytes():
                    errors.append(f'TARGET across arms inconsistent: {topo} face={slot} run={seed}')
    for topo in TOPO:
        for slot in SLOTS:
            ret=[r for r in rows if (r['topology'],r['slot'],r['arm'])==(topo,slot,'RETURN_DATA')]
            ctrl=[r for r in rows if (r['topology'],r['slot'],r['arm'])==(topo,slot,'OFF_BASELINE')]
            if len(ret)!=2 or len(ctrl)!=2:
                errors.append(f'missing topo/Face repetitions: {topo}/{slot}')
                continue
            if sum(r['selected_return_fragment_drops'] for r in ret)<=0:
                errors.append(f'no real reverse fragment drops: {topo}/{slot}')
            if sum(r['return_drop_competitor_data']+r['return_drop_target_data'] for r in ret)<=0:
                errors.append(f'no directly reassembled LP DATA drop: {topo}/{slot}')
            if any(r['selected_return_fragment_drops']!=0 or r['return_drop_competitor_data'] for r in ctrl):
                errors.append(f'false reverse drop in no-competitor baseline: {topo}/{slot}')
    bycell=[]
    for topo in TOPO:
        for slot in SLOTS:
            for arm in ARMS:
                subset=[r for r in rows if (r['topology'],r['slot'],r['arm'])==(topo,slot,arm)]
                bycell.append({'topology':topo,'slot':slot,'arm':arm,'runs_passed':len(subset),
                    'return_fragment_drops':sum(r['selected_return_fragment_drops'] for r in subset),
                    'class_competitor_data_drops':sum(r['return_drop_competitor_data'] for r in subset),
                    'class_target_data_drops':sum(r['return_drop_target_data'] for r in subset),
                    'unknown_return_drops':sum(r['return_drop_unknown'] for r in subset),
                    'old_pilot_unknown_windows':sum(r['original_pilot_unknown'] for r in subset)})
    root.mkdir(parents=True,exist_ok=True)
    with (root/'lp_return_matrix_12_cells.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(bycell[0]));w.writeheader();w.writerows(bycell)
    status='PASS_RETROSPECTIVE_LP_RETURN_DATA_ATTRIBUTION_PILOT_ONLY' if len(rows)==24 and not errors else 'INCOMPLETE_LP_GROUP_EVIDENCE'
    out={'stage':'1AM.LP_RETURN_GROUP_PROVENANCE_PILOT.0','status':status,
        'monitored_runs_pass':len(rows),'total_expected_runs':48,
        'target_windows':12*len(rows),'return_fragment_drops':sum(r['selected_return_fragment_drops'] for r in rows),
        'comp_data_fragment_drops':sum(r['return_drop_competitor_data'] for r in rows),
        'target_data_fragment_drops':sum(r['return_drop_target_data'] for r in rows),
        'unknown_return_drops':sum(r['return_drop_unknown'] for r in rows),
        'errors':errors,'cells':bycell,
        'label_definition_is_final_F3':False,'official_F3_labels':0,
        'Congestion':None,'FutureCongestion':None,'F3_ready':False,
        'GO_FREEZE':False,'training_ready':False,'ready_for_1AN_final':False,
        'caution':'reconstructed sender Data identity is a post-decision diagnostic, not final future-congestion label; controls and windows correlated'}
    (root/'summary_stage1am_lp_return.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='cells'},sort_keys=True))
    return out

if __name__=='__main__':
    x=summarize(sys.argv[1]);sys.exit(0 if x['status'].startswith('PASS_') else 1)
