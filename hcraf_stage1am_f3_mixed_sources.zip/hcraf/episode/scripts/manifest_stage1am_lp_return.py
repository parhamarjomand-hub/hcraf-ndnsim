#!/usr/bin/env python3
"""Always preserve pass/fail raw records and cryptographic file listing."""
import hashlib,json,os,platform,sys
from pathlib import Path
from datetime import datetime,timezone
root=Path(sys.argv[1]).resolve();out=root/'episode_output';out.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
items={str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='manifest.json'}
data={'stage':'1AM.LP_RETURN_GROUP_PROVENANCE_PILOT.0','created_utc':datetime.now(timezone.utc).isoformat(),
      'github_run_id':os.getenv('GITHUB_RUN_ID'),'github_commit':os.getenv('GITHUB_SHA'),
      'source_zip_sha256':sha(root/'hcraf_stage1am_lp_return_sources.zip') if (root/'hcraf_stage1am_lp_return_sources.zip').exists() else None,
      'reference_zip_sha256':sha(root/'hcraf_stage1s_approved_reference.zip') if (root/'hcraf_stage1s_approved_reference.zip').exists() else None,
      'workflow_sha256':sha(root/'.github/workflows/hcraf-stage1am-lp-return.yml') if (root/'.github/workflows/hcraf-stage1am-lp-return.yml').exists() else None,
      'output_file_sha256':items,'python_version':platform.python_version(),
      'container_image':'ubuntu:20.04 tag; NOT pinned digest','fully_pinned_environment':False,
      'complete_experiment_matrix':'48 controlled paired DEV runs; 24 monitored',
      'new_instrumentation_scope':'sender LP Fragment payload only on QUEUE_ENQUEUE/QUEUE_DROP',
      'does_not_inject_post_decision_data_online':True,
      'does_not_override_historical_oracle':True,
      'Congestion':None,'FutureCongestion':None,'GO_FREEZE':False,'F3_ready':False,
      'training_ready':False,'official_F3_labels':0,'dataset_generated':False}
(out/'manifest.json').write_text(json.dumps(data,sort_keys=True,indent=2)+'\n')
