#!/usr/bin/env python3
"""Seal E Validation before F Test. Completeness only, never tune using labels."""
import hashlib,json,pathlib,sys
from f3_coverage_v045 import ARMS,STATUS,TOPOLOGIES,need

def seal(root):
    root=pathlib.Path(root);topo='VAL_CHAIN_E';n=0;files={}
    for slot in range(3):
        for arm in ARMS:
            for rng in TOPOLOGIES[topo]['runs']:
                base=root/topo/f'slot-{slot}'
                m=base/'monitored'/arm/f'run-{rng}'
                u=base/'uninstrumented'/arm/f'run-{rng}'
                for file in (u/'scenario.json',u/'resource_usage.txt',m/'stage1am_f3_coverage_verification.json'):
                    need(file.is_file(),'VALIDATION_INCOMPLETE:'+str(file))
                    files[file.relative_to(root).as_posix()]=hashlib.sha256(file.read_bytes()).hexdigest()
                d=json.loads((m/'stage1am_f3_coverage_verification.json').read_text())
                need(d.get('status')==STATUS and sum(d.get(k,-1) for k in
                      ('candidate_positive','candidate_negative','candidate_unknown'))==12,
                      'VALIDATION_BAD_RUN')
                n+=1
    need(n==84,'VALIDATION_NOT_84_MONITORED')
    record={'stage':'1AM.F3_COVERAGE_REMEDIATION_FOUR_HOP.0','status':'E_VALIDATION_INTEGRITY_SEALED_TEST_NOT_USED',
         'validation_pairs':n,'validation_file_sha256':files,'fixed_horizon_ns':50_000_000,
         'fixed_wait_ns':5_000_000,'fixed_low_queue_packets':2,
         'old_v044_test_is_exploratory_not_final_test':True,
         'new_TEST_CHAIN_F_not_observed_at_seal':True,
         'F3_ready':False,'GO_FREEZE':False,'training_ready':False,'FutureCongestion':None}
    root.joinpath('validation_sealed_before_new_test.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
    print('VALIDATION_SEALED',n)
if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('usage: seal_stage1am_f3_coverage_validation.py ROOT')
    seal(sys.argv[1])
