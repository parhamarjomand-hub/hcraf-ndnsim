#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
# Preserve approved 1AM v0.40.1 NFD/ndnSIM patch chain; new scratch only.
bash "$TASK/scripts/build_stage1am_nonzero.sh"
cd "$ROOT/episode_sources/ns-3"
cp "$TASK/src/hcraf-stage1am-pathwide-pilot.cpp" scratch/hcraf-stage1am-pathwide-pilot.cc
cmp -s "$TASK/src/hcraf-stage1am-pathwide-pilot.cpp" scratch/hcraf-stage1am-pathwide-pilot.cc
python3 ./waf -j 2
test -x build/scratch/hcraf-stage1am-pathwide-pilot
