#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
# Exact approved 1AM v0.39.1 NFD lineage + additive new scratch scenario only.
bash "$TASK/scripts/build_stage1am_technical.sh"
cd "$ROOT/episode_sources/ns-3"
cp "$TASK/src/hcraf-stage1am-nonzero-pilot.cpp" scratch/hcraf-stage1am-nonzero-pilot.cc
cmp -s "$TASK/src/hcraf-stage1am-nonzero-pilot.cpp" scratch/hcraf-stage1am-nonzero-pilot.cc
python3 ./waf -j 2
test -x build/scratch/hcraf-stage1am-nonzero-pilot
