#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
OUT="$ROOT/episode_output/stage1am_f3_heldout"
mkdir -p "$OUT"
cd "$ROOT/episode_sources/ns-3"
failed=0
# Immutable preregistration: VALIDATION first, then untouched TEST partition.
# Each is a different four-hop network from DEV, with disjoint RngRuns.
for topology in VAL_CHAIN_C TEST_CHAIN_D; do
  if [ "$topology" = VAL_CHAIN_C ];then runs="9721 9722";else runs="9821 9822";fi
  for slot in 0 1 2; do
    for arm in OFF_BASELINE LOCAL_FORWARD RELAY_FORWARD MID_FORWARD RETURN_DATA LATE_COMPETITOR; do
      comp=160; compoff=0; localrate=5000000
      case "$arm" in
        OFF_BASELINE) comp=0;;
        LOCAL_FORWARD) localrate=50000;;
        RELAY_FORWARD|MID_FORWARD|RETURN_DATA) :;;
        LATE_COMPETITOR) compoff=800000000;;
        *) echo "BAD_ARM $arm" >&2; exit 4;;
      esac
      cint=1000000;[ "$comp" -ne 0 ] || cint=0
      for rng in $runs;do
        for instrument in 1 0;do
          if [ "$instrument" = 1 ];then kind=monitored;else kind=uninstrumented;fi
          dest="$OUT/$topology/slot-$slot/$kind/$arm/run-$rng"
          mkdir -p "$dest"
          cmd="hcraf-stage1am-heldout-pilot --pathArm=$arm --topology=$topology --selectedSlot=$slot --mode=LP_INDEPENDENT_COMPETITOR_NO_DROP --seed=17 --run=$rng --output=$dest --instrument=$instrument --lifetimeMs=2600 --requestCount=12 --intervalNs=30000000 --competitorCount=$comp --competitorIntervalNs=$cint --competitorOffsetNs=$compoff --targetOffsetNs=30000000 --forwardBps=$localrate --returnBps=5000000"
          printf '%s\n' "$cmd" > "$dest/command.txt"
          if ! /usr/bin/time -f 'wall_seconds=%e\nuser_seconds=%U\nsystem_seconds=%S\nmax_rss_kib=%M' -o "$dest/resource_usage.txt" \
            python3 ./waf --run-no-build "$cmd" > "$dest/simulator.log" 2>&1; then
            echo "SIM_FAIL $topology/$slot/$arm/$rng/$kind";failed=1;continue
          fi
          if [ "$instrument" = 1 ];then
            if ! python3 "$TASK/scripts/episodes_stage1u.py" "$dest" \
                --run-id "1am_heldout-$topology-$slot-$arm-17-$rng" > "$dest/episodes.log" 2>&1;then
              echo "EPISODE_FAIL $topology/$slot/$arm/$rng";failed=1;continue
            fi
            if ! python3 "$TASK/scripts/heldout_f3_v044.py" "$dest" --topology "$topology" \
                --slot "$slot" --arm "$arm" --run "$rng" > "$dest/verify.log" 2>&1;then
              echo "HELDOUT_VERIFY_FAIL $topology/$slot/$arm/$rng";failed=1
            fi
          fi
        done
      done
    done
  done
  if [ "$topology" = VAL_CHAIN_C ];then
    # No scientific threshold choice is permitted here. Gate only integrity.
    if ! python3 "$TASK/scripts/seal_stage1am_heldout_validation.py" "$OUT";then
      echo "VALIDATION_NOT_SEALED_TEST_MUST_NOT_BE_OPENED";exit 5
    fi
  fi
done
if ! python3 "$TASK/scripts/summarize_stage1am_heldout.py" "$OUT";then failed=1;fi
exit "$failed"
