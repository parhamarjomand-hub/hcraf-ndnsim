#!/usr/bin/env python3
"""Independent sender-LP attribution after approved path-wide physical verifier.

Never updates or replaces the historic path-wide Interest-drop oracle output.
"""
import argparse
import json
from pathlib import Path
from oracle_stage1am_lp_return import oracle_group
from verify_stage1am_pathwide import audit as pathwide_audit, read_jsonl


def audit(root, topo, slot, arm, run):
    p=Path(root)
    if arm not in ('OFF_BASELINE', 'RETURN_DATA'):
        raise ValueError('not a registered LP return audit arm')
    # Existing NFD/Face/Producer/physical contracts MUST pass first.
    original=pathwide_audit(p,topo,slot,arm,run)
    if original['status']!='PASS_PATHWIDE_PHYSICS_AUDIT_ONLY':
        raise ValueError('original pathwide audit did not pass')
    cfg=json.loads((p/'scenario.json').read_text())
    old=json.loads((p/'stage1am_pathwide_oracle.json').read_text())
    data=oracle_group(cfg,read_jsonl(p/'events.jsonl.decisions.jsonl'),
                      read_jsonl(p/'link_events.jsonl'),
                      read_jsonl(p/'producer_receipts.jsonl'),old['target_rows'])
    assert original['pilot_positive']==old['pilot_positive'] and original['pilot_unknown']==old['pilot_unknown']
    if arm=='OFF_BASELINE' and data['selected_return_drop_count']:
        raise ValueError('baseline selected reverse drop unexpectedly observed')
    # In RETURN, missing GROUP data cannot be accepted as a successful group
    # audit. Across both RngRuns each topology/Face must later demonstrate it.
    if arm=='RETURN_DATA' and data['selected_return_fragment_drop_count']==0:
        raise ValueError('missing actual selected reverse fragment drop')
    result={
        'stage':'1AM.LP_RETURN_GROUP_PROVENANCE_PILOT.0',
        'status':'PASS_GROUP_TRACE_AUDIT_ONLY',
        'topology':topo,'slot':slot,'arm':arm,'rng_run':run,
        'original_pathwide_status':original['status'],
        'original_pilot_positive':old['pilot_positive'],
        'original_pilot_negative':old['pilot_negative'],
        'original_pilot_unknown':old['pilot_unknown'],
        'selected_return_fragment_drops':data['selected_return_fragment_drop_count'],
        'sender_lp_groups_attributed':data['sender_lp_groups_complete_attributed'],
        'sender_lp_groups_unresolved':data['sender_lp_groups_unresolved'],
        'return_drop_competitor_data':data['drop_by_class'].get('COMPETITOR_DATA',0),
        'return_drop_target_data':data['drop_by_class'].get('TARGET_DATA',0),
        'return_drop_unknown':sum(v for k,v in data['drop_by_class'].items()
                                  if k not in ('COMPETITOR_DATA','TARGET_DATA')),
        'windows_new_return_diagnostic':{
            state:sum(r['new_return_data_diagnostic']==state for r in data['target_windows'])
            for state in sorted(set(r['new_return_data_diagnostic'] for r in data['target_windows']))
        },
        'Congestion':None,'FutureCongestion':None,
        'GO_FREEZE':False,'F3_ready':False,'training_ready':False,
        'ready_for_1AN_final':False, 'official_F3_labels':0}
    (p/'stage1am_lp_return_oracle.json').write_text(json.dumps(data,sort_keys=True,indent=2)+'\n')
    (p/'stage1am_lp_return_verification.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    return result

if __name__=='__main__':
    a=argparse.ArgumentParser()
    a.add_argument('run_directory')
    a.add_argument('--topology',required=True)
    a.add_argument('--slot',required=True,type=int)
    a.add_argument('--arm',required=True)
    a.add_argument('--seed',required=True,type=int)
    v=a.parse_args()
    print(json.dumps(audit(v.run_directory,v.topology,v.slot,v.arm,v.seed),sort_keys=True))
