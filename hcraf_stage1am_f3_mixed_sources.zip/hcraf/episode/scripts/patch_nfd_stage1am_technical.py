#!/usr/bin/env python3
"""Additive, fail-closed NFD *actual forwarding-path* timing for 1AM technical pilot.

Pinned post-1AH patched NFD code only. Measures whole dispatch including recorder and
queue observer, NOT HCRAF Gate time. The sole change to forwarding behavior is
an opt-in, no-scheduling timing callback. Existing HCRAF Cost/Reward/Gate untouched.
"""
import hashlib
import json
import sys
from pathlib import Path

PINNED_PREIMAGE = {
    'forwarder.cpp': '229ead0fcf35c151c1e9d75d74cc8427cb25ee735558693925882c5a3ecb1cc7',
    'forwarder.hpp': '0d91ce7148e6aeb58b8937fc08fe378ac8cda028ff0f5232b0f71715b38d91dc',
}


def substitute_once(text, old, new, where):
    if text.count(old) != 1:
        raise ValueError(f'NFD live preflight rejected {where}; occurrences={text.count(old)}')
    return text.replace(old, new, 1)


def patch_text(cpp, header):
    header = substitute_once(header,
        '  void hcrafSetDecisionObserver(std::function<void(uint64_t)> observer) {\n'
        '    m_hcrafDecisionObserver = std::move(observer);\n'
        '  }',
        '  void hcrafSetDecisionObserver(std::function<void(uint64_t)> observer) {\n'
        '    m_hcrafDecisionObserver = std::move(observer);\n'
        '  }\n'
        '  // Opt-in, measured at NFD before and after the real forwarding dispatch.\n'
        '  // Includes recorder and callback instrumentation: NOT HCRAF Gate-only time.\n'
        '  void hcrafSetDispatchTimingObserver(\n'
        '      std::function<void(uint64_t, uint64_t, uint64_t)> observer) {\n'
        '    m_hcrafDispatchTimingObserver = std::move(observer);\n'
        '  }', 'public NFD timing observer')
    header = substitute_once(header,
        '  std::function<void(uint64_t)> m_hcrafDecisionObserver;\n',
        '  std::function<void(uint64_t)> m_hcrafDecisionObserver;\n'
        '  std::function<void(uint64_t, uint64_t, uint64_t)> m_hcrafDispatchTimingObserver;\n',
        'private NFD timing observer')
    cpp = substitute_once(cpp, '#include "ns3/simulator.h"',
        '#include "ns3/simulator.h"\n#include <chrono>\n#include <ctime>', 'C++ headers')
    cpp = substitute_once(cpp,
        '  uint64_t hcrafDecision = 0;\n  Face* hcrafProbe = nullptr;',
        '  // Sample before snapshot and actual NFD forwarding. Wall = steady_clock,\n'
        '  // CPU = std::clock, both host timings, never ns3::Simulator::Now().\n'
        '  const auto hcrafDispatchWallStart = std::chrono::steady_clock::now();\n'
        '  const auto hcrafDispatchCpuStart = std::clock();\n'
        '  uint64_t hcrafDecision = 0;\n'
        '  const auto hcrafReportDispatchTiming = [&]() {\n'
        '    if (hcrafDecision == 0 || !m_hcrafDispatchTimingObserver) return;\n'
        '    const auto wall = std::chrono::duration_cast<std::chrono::nanoseconds>(\n'
        '      std::chrono::steady_clock::now() - hcrafDispatchWallStart).count();\n'
        '    const auto ticks = std::clock() - hcrafDispatchCpuStart;\n'
        '    if (wall < 0 || ticks < 0) throw std::runtime_error("Nonmonotonic NFD dispatch timing");\n'
        '    const auto cpu = static_cast<uint64_t>(static_cast<double>(ticks) *\n'
        '      (1000000000.0 / static_cast<double>(CLOCKS_PER_SEC)));\n'
        '    m_hcrafDispatchTimingObserver(hcrafDecision, static_cast<uint64_t>(wall), cpu);\n'
        '  };\n'
        '  Face* hcrafProbe = nullptr;', 'NFD decision entry')
    cpp = substitute_once(cpp,
        '      m_hcrafRecorder->endDecision(hcrafDecision);\n      return;\n    }\n    if (m_hcrafDraw)',
        '      m_hcrafRecorder->endDecision(hcrafDecision);\n'
        '      hcrafReportDispatchTiming();\n      return;\n    }\n    if (m_hcrafDraw)',
        'NFD forced coverage return')
    cpp = substitute_once(cpp,
        '    m_hcrafRecorder->endDecision(hcrafDecision);\n    return;\n  }\n'
        '  // dispatch to strategy: after receive Interest',
        '    m_hcrafRecorder->endDecision(hcrafDecision);\n'
        '    hcrafReportDispatchTiming();\n    return;\n  }\n'
        '  // dispatch to strategy: after receive Interest', 'NFD exclusive return')
    cpp = substitute_once(cpp,
        '  if (m_hcrafRecorder) m_hcrafRecorder->endDecision(hcrafDecision);\n}',
        '  if (m_hcrafRecorder) m_hcrafRecorder->endDecision(hcrafDecision);\n'
        '  hcrafReportDispatchTiming();\n}', 'NFD native strategy end')
    return cpp, header


def patch(nfd_dir):
    nfd_dir = Path(nfd_dir)
    inputs = {}
    for n, expected in PINNED_PREIMAGE.items():
        b = (nfd_dir/n).read_bytes()
        if hashlib.sha256(b).hexdigest() != expected:
            raise ValueError(f'Unapproved NFD state {n}: {hashlib.sha256(b).hexdigest()}')
        inputs[n] = b.decode('utf8')
    cpp, header = patch_text(inputs['forwarder.cpp'],inputs['forwarder.hpp'])
    # All assertions precede writes; no partial file mutation on failure.
    (nfd_dir/'forwarder.cpp').write_text(cpp,encoding='utf8')
    (nfd_dir/'forwarder.hpp').write_text(header,encoding='utf8')
    return {n:hashlib.sha256((nfd_dir/n).read_bytes()).hexdigest() for n in PINNED_PREIMAGE}

if __name__ == '__main__':
    if len(sys.argv)!=2: raise SystemExit('Usage: patch_nfd_stage1am_technical.py /path/to/NFD/daemon/fw')
    print(json.dumps(patch(sys.argv[1]),sort_keys=True,indent=2))
