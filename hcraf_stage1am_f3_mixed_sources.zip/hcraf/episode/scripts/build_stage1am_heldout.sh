#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
# Approved original NFD patch chain reused unmodified; new scratch is additive.
bash "$TASK/scripts/build_stage1am_pathwide.sh"
cd "$ROOT/episode_sources/ns-3"
cp "$TASK/src/hcraf-stage1am-heldout-pilot.cpp" scratch/hcraf-stage1am-heldout-pilot.cc
cmp -s "$TASK/src/hcraf-stage1am-heldout-pilot.cpp" scratch/hcraf-stage1am-heldout-pilot.cc
python3 ./waf -j 2
test -x build/scratch/hcraf-stage1am-heldout-pilot
