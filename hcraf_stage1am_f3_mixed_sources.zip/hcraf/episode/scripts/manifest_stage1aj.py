#!/usr/bin/env python3
"""Fail-closed complete/partial provenance for stage 1AJ."""
import hashlib,json,os,platform,subprocess,sys
from pathlib import Path
from datetime import datetime,timezone
root=Path(sys.argv[1]).resolve();out=root/'episode_output';out.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
try:git=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True,stderr=subprocess.DEVNULL).strip()
except (OSError,subprocess.CalledProcessError):git=os.getenv('GITHUB_SHA','UNKNOWN')
files={str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='manifest.json'}
code={str(p.relative_to(root)):sha(p) for p in sorted((root/'hcraf/episode').rglob('*'))
  if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
wf=root/'.github/workflows/hcraf-stage1aj.yml'
if wf.is_file():code[str(wf.relative_to(root))]=sha(wf)
z=root/'hcraf_stage1aj_sources.zip'
manifest={'schema_version':'1AJ.PAIRED_INTERVENTION.0','created_utc':datetime.now(timezone.utc).isoformat(),
 'github_commit':git,'github_run_id':os.getenv('GITHUB_RUN_ID'),
 'source_zip_sha256':sha(z) if z.is_file() else None,
 'python_version':platform.python_version(),'file_sha256':files,'code_sha256':code,
 'container_image':'ubuntu:20.04 (tag, not OCI digest)','fully_pinned_environment':False,
 'GO_FREEZE':False,'Congestion':None,'FutureCongestion':None,'F3_ready':False,'training_ready':False}
(out/'manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
