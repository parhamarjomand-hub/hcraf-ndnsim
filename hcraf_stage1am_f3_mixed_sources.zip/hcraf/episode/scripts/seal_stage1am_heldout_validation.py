#!/usr/bin/env python3
"""Do not run TEST unless every preregistered validation pair has valid raw provenance."""
import json,pathlib,sys
from heldout_f3_v044 import ARMS,STATUS,TOPOLOGIES,need

def seal(root):
    root=pathlib.Path(root)
    topo='VAL_CHAIN_C';n=0
    for slot in range(3):
        for arm in ARMS:
            for rng in TOPOLOGIES[topo]['runs']:
                p=root/topo/f'slot-{slot}'/'monitored'/arm/f'run-{rng}'
                q=root/topo/f'slot-{slot}'/'uninstrumented'/arm/f'run-{rng}'
                need(q.joinpath('scenario.json').exists() and q.joinpath('resource_usage.txt').exists(),
                     'VALIDATION_UNMONITORED_PAIR_MISSING')
                need((p/'stage1am_heldout_verification.json').exists(),'VALIDATION_MISSING_VERIFICATION')
                j=json.loads((p/'stage1am_heldout_verification.json').read_text())
                need(j.get('status')==STATUS and j.get('candidate_positive',-1)+
                     j.get('candidate_negative',-1)+j.get('candidate_unknown',-1)==12,
                     'VALIDATION_INCOMPLETE')
                n+=1
    need(n==36,'WRONG_VALIDATION_MATRIX')
    output=root/'validation_sealed_before_test.json'
    output.write_text(json.dumps({'status':'VALIDATION_COVERAGE_SEALED_NO_TUNING','n_pairs':36,
         'horizon_ns':50_000_000,'wait_ns':5_000_000,'max_low_queue_packets':2,
         'Test_opened_after_validation_integrity_only':True,
         'F3_ready':False,'GO_FREEZE':False,'FutureCongestion':None},sort_keys=True,indent=2)+'\n')
    print('VALIDATION_SEALED',n)

if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('usage: seal_stage1am_heldout_validation.py OUT_ROOT')
    seal(sys.argv[1])
