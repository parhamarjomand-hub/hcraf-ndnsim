#!/usr/bin/env python3
"""Full 4-arm × 3-seed× monitor-pair coverage; preserves scientific NO-GO."""
import hashlib,json,sys
from pathlib import Path
from verify_stage1am_technical import ARMS, SEEDS
PAIRS=[('ON_5M_SYNC','OFF_5M'),('ON_5M_TARGET_LAG_6MS','OFF_5M_TARGET_LAG_6MS')]

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None

def read_resources(file):
    if not file.is_file(): return None
    try:
        items=dict(x.split('=',1) for x in file.read_text().splitlines() if '=' in x)
        result={k:float(items[k]) for k in ('wall_seconds','user_seconds','system_seconds','max_rss_kib')}
        if any(v<0 for v in result.values()):return None
        return result
    except (ValueError,KeyError):return None


def summarize(root):
    root=Path(root); runs=[]; controls=[];interventions=[];resource_pairs=[]
    for arm in ARMS:
        for seed in SEEDS:
            m=root/'monitored'/arm/f'run-{seed}'
            u=root/'uninstrumented'/arm/f'run-{seed}'
            report_path=m/'stage1am_technical_verification.json'
            r=json.loads(report_path.read_text()) if report_path.is_file() else dict(
                arm=arm,rng_run=seed,status='MISSING_VERIFIER_RESULT')
            runs.append(r)
            files=['consumer_events.jsonl','consumer_events.jsonl.arrivals.jsonl']
            if arm.startswith('ON_'):
                files+=['competitor_events.jsonl','competitor_events.jsonl.arrivals.jsonl']
            controls.append(dict(arm=arm,rng_run=seed,
                matched_monitored_uninstrumented_schedule=all(sha(m/f) and sha(m/f)==sha(u/f) for f in files)))
            monitored=read_resources(m/'resource_usage.txt')
            uninstrumented=read_resources(u/'resource_usage.txt')
            record={'arm':arm,'rng_run':seed,'measurement_scope':'whole_process_instrumentation_overhead_NOT_HCRAF_Gate'}
            for key in ('wall_seconds','user_seconds','system_seconds','max_rss_kib'):
                record[key+'_monitored']=monitored.get(key) if monitored else None
                record[key+'_uninstrumented']=uninstrumented.get(key) if uninstrumented else None
                record[key+'_delta']=(monitored[key]-uninstrumented[key]) if monitored and uninstrumented else None
            resource_pairs.append(record)
    for on,off in PAIRS:
        for seed in SEEDS:
            a=root/'monitored'/on/f'run-{seed}'
            b=root/'monitored'/off/f'run-{seed}'
            def sends(p):
                q=p/'consumer_events.jsonl'
                if not q.is_file():return []
                return [json.loads(s) for s in q.read_text().splitlines() if s and json.loads(s).get('event')=='SEND']
            interventions.append(dict(arm_on=on,arm_off=off,rng_run=seed,
                identical_target_arrival_plan=sha(a/'consumer_events.jsonl.arrivals.jsonl')==sha(b/'consumer_events.jsonl.arrivals.jsonl') and sends(a)==sends(b)))
    valid=(all(r['status']=='PASS_NFD_LOCAL_SNAPSHOT_AND_DISPATCH_MEASUREMENT' for r in runs)
           and all(r['matched_monitored_uninstrumented_schedule'] for r in controls)
           and all(r['max_rss_kib_delta'] is not None for r in resource_pairs)
           and all(r['identical_target_arrival_plan'] for r in interventions))
    summary={'stage':'1AM.TECHNICAL.ONLINE_PILOT.0','status':'PASS_TECHNICAL_NFD_PILOT_ONLY' if valid else 'INCOMPLETE_TECHNICAL_EVIDENCE',
        'monitored_runs':len(runs),'uninstrumented_runs_planned':12,
        'total_NFD_decisions_verified':sum(r.get('NFD_decisions',0) for r in runs),
        'paired_intervention_comparisons':len(interventions),
        'resource_overhead_pairs':len(resource_pairs),
        'real_HCRAF_Gate_executed':False,'remote_telemetry_live':False,
        'validated_F3_adjudicator':False,'GO_FREEZE':False,
        'Congestion':None,'FutureCongestion':None,'F3_ready':False,'training_ready':False}
    for name, obj in [('stage1am_technical_runs.json',runs),('stage1am_technical_monitor_pairs.json',controls),
                      ('stage1am_technical_intervention_pairs.json',interventions),
                      ('stage1am_technical_resource_pairs.json',resource_pairs),('stage1am_technical_summary.json',summary)]:
        (root/name).write_text(json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    print(json.dumps(summary,sort_keys=True))
    return 0 if valid else 3
if __name__=='__main__':raise SystemExit(summarize(sys.argv[1]))
