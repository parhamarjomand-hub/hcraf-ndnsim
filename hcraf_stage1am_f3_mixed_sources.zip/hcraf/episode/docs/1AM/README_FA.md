# مرحله 1AM — اجرای آزمایشی v0.40.0

ترتیب نصب: `hcraf_stage1am_nonzero_sources.zip` در ریشه مخزن و `.github/workflows/hcraf-stage1am-nonzero.yml` در مسیر دقیق آن. مرجع `hcraf_stage1s_approved_reference.zip` همان فایل تأییدشده قبلی است و باید در ریشه مخزن باقی بماند. ZIP منابع را در GitHub **استخراج نکنید**.

Workflow: `HCRAF - Stage 1AM Nonzero Local Queue and Physical Future-Drop Pilot (v0.40.0)`.

پس از اجرا حتی در صورت FAILURE، Artifact `hcraf-stage1am-nonzero-*` را برای ممیزی مستقل ارسال کنید. هیچ مدلی آموزش داده نمی‌شود و `GO_FREEZE=false` است. این مطالعه روی ndnSIM داخل GitHub اجرا می‌شود؛ تست محلی Python جایگزین اجرای فیزیکی نیست.
