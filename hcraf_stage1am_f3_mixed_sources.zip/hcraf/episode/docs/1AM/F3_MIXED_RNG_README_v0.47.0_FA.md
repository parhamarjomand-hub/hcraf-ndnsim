# راهنمای فنی Stage1AM F3 Mixed RNG v0.47.0

**هیچ فایل نسخه قبلی را تغییر ندهید.** فقط سناریوی C++، داور v047، خلاصه‌ساز گروه‌آگاه، مهر Validation، Runner، Manifest و تست‌های جدید افزوده شده‌اند. از زنجیره NFD/ndnSIM تأییدشده در 1S و نسخه‌های تا 0.46 استفاده می‌شود.

سناریوی native: `src/hcraf-stage1am-f3-mixed-pilot.cpp`؛ خروجی بررسی: `stage1am_f3_mixed_verification.json` و `stage1am_f3_mixed_windows.json` در کنار هر Trace.

اجرا: `scripts/build_stage1am_f3_mixed.sh` سپس `scripts/run_stage1am_f3_mixed.sh`. خروجی `episode_output/stage1am_f3_mixed` شامل Validation I و Test J، منابع مستقل، `summary/summary.json`, `summary/candidate_windows.csv`, `summary/paired_resources.csv`, `summary/paired_target_completion_diagnostics.csv`, `validation_sealed_before_new_test.json` است.

**گیت مهم:** خروجی یک پایلوت محدود است و هرگز F3 یا آموزش را آماده اعلام نمی‌کند. روی Test J هیچ آستانه و برچسبی را تنظیم نکنید.
