# HCRAF — راهنمای اجرای مرحله 1AM، پایلوت held-out v0.44.0

**هدف:** آزمون قرارداد تشخیصی کاندید F3 بر شبیه‌سازی‌های تازه با **توپولوژی طولانی‌تر** و پارتیشن‌های Validation/Test جدا. این نه ساخت دیتاست نهایی است و نه تأیید F3.

1. بسته `HCRAF_Stage1AM_F3_Heldout_GitHub_ready_v0.44.0.zip` را روی لپ‌تاپ استخراج کنید.
2. `hcraf_stage1am_heldout_sources.zip` را **بدون استخراج** در ریشه مخزن خصوصی `hcraf-ndnsim/` قرار دهید.
3. `.github/workflows/hcraf-stage1am-f3-heldout.yml` را در همین مسیر دقیق مخزن بارگذاری کنید.
4. فایل از قبل موجود `hcraf_stage1s_approved_reference.zip` باید در ریشه مخزن باقی بماند. ZIPهای قدیمی، نتایج مراحل پیشین و Workflowهای دیگر را حذف نکنید.
5. Commit/Push کنید. در Actions گردش‌کار `HCRAF - Stage 1AM Pre-registered Four-Hop F3 Held-out Pilot (v0.44.0)` را با `Run workflow` اجرا کنید.
6. Artifact با پیشوند `hcraf-stage1am-f3-heldout-` را **حتی در صورت Failure** ارسال کنید.

Workflow پس از تست‌های محلی، ۱۴۴ آزمایش مستقل شبیه‌سازی جفتی انجام می‌دهد، ۲۰ رابط فیزیکی و سنجش NFD را ثبت می‌کند، فقط پس از کامل‌بودن شواهد Validation بخش Test را باز می‌کند، و معیارهای `0/1/UNKNOWN` را فقط در **ستون کاندید** ذخیره می‌کند. هیچ فایل رسمی training با `FutureCongestion` غیر-NULL ساخته نمی‌شود.

**محدودیت:** v0.44.0 نخستین اجرای واقعی این سناریو است و قابلیت کامپایل ndnSIM در محیط GitHub باید اثبات شود؛ آزمون‌های محلی فقط Python و کنترل C++ مستقل هستند. هر شکست باید با همان Artifact بررسی شود، نه با ادعای PASS پیشینی.
