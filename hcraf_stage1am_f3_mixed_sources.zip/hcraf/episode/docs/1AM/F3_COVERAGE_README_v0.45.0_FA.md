# HCRAF Stage 1AM v0.45.0 — راهنمای اجرای ممیزی پوشش برچسب F3

**حکم فعلی:** فقط `READY_FOR_GITHUB_EXECUTION`، نه PASS تجربی.

فایل ZIP منابع باید در ریشه مخزن با نام `hcraf_stage1am_f3_coverage_sources.zip` بماند؛ Workflow در `.github/workflows/hcraf-stage1am-f3-coverage.yml` قرار می‌گیرد. مرجع قدیمی `hcraf_stage1s_approved_reference.zip` باید حفظ شود. از بسته آماده GitHub فقط این دو فایل را بارگذاری کنید؛ ZIP منابع را در مخزن استخراج نکنید.

Workflow، SHA-256 منابع را قبل از بازکردن کنترل می‌کند؛ هیچ فایل متفاوت قبلی را جایگزین نمی‌کند و آزمون‌های قبلی حفظ می‌شوند. سپس کد C++ جدید به scratch ndnSIM افزوده می‌شود، ۳۳۶ اجرای واقعی انجام می‌شود، Validation پیش از Test بررسی و Seal می‌گردد، شواهد فیزیکی و گروه LP بررسی می‌شوند، گزارش پوشش/مقایسه دریافت Data و Manifest نهایی تولید می‌شود. Artifact حتی در Failure بارگذاری می‌شود.

پیش‌ثبت کامل داخل `hcraf/episode/docs/1AM/F3_COVERAGE_PREREG_v0.45.0_FA.md` است. نتایج قدیمی C/D نباید به‌عنوان Test جدید معرفی شوند. وضعیت `GO_FREEZE=false` حفظ می‌شود. در صورت شکست بازبین یا عدم دستیابی به ۲۱۶ منفی معتبر در هر پارتیشن، Artifact ناموفق را برای تحلیل ارسال کنید؛ آستانه‌ها را تغییر ندهید.
