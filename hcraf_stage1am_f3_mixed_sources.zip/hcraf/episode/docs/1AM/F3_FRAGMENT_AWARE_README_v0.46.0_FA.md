# راهنمای v0.46.0

نسخه قبلی v0.45.0 و خروجی‌هایش را تغییر ندهید. فایل‌های جدید ابزارگذاری موجود C++ را در سناریوی جدید G/H به کار می‌گیرند و فقط برچسب کاندید پسینی تولید می‌کنند.

- `src/hcraf-stage1am-f3-fragment-aware-pilot.cpp`: دو توپولوژی و بذرهای جدید، بدون اجرای Gate و با Face اجباری.
- `scripts/f3_fragment_aware_v046.py`: داور ۵۰ms، افت‌های Interest/Data معتبر، حذف حد دو Fragment، محافظه‌کاری UNKNOWN، محافظت از منفی با دریافت Target و شاهد.
- `scripts/summarize_stage1am_f3_fragment_aware.py`: اصلاح شمارش ۱۶۸ جفت؛ گزارش جداگانه دریافت Target، harm-diagnostic، AP صف آنلاین و Prevalence.
- `scripts/seal_stage1am_f3_fragment_validation.py`: قفل‌کردن Validation قبل از Test و ثبت SHA.
- `scripts/run_stage1am_f3_fragment_aware.sh`, `scripts/build_stage1am_f3_fragment_aware.sh`: ۳۳۶ اجرای واقعی. حتماً از workflow مصوب اجرا شوند.
- `tests/test_stage1am_f3_fragment_aware.py`: آزمون‌های منفی و قرارداد؛ موفقیت این آزمون‌ها جایگزین اجرای واقعی ndnSIM نیست.

Artifact با prefix `hcraf-stage1am-f3-fragment-` حتی در Failure نگه‌داری می‌شود. هرگز نتیجه `PASS` را برابر `GO_FREEZE=true` نگیرید.
