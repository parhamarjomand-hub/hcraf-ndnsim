#ifndef HCRAF_STAGE1AM_LOCAL_SNAPSHOT_HPP
#define HCRAF_STAGE1AM_LOCAL_SNAPSHOT_HPP

#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include <fstream>
#include <stdexcept>
#include <vector>
#include <cstdint>

// Invoked synchronously from NFD Recorder::beginDecision, BEFORE onOutgoingInterest.
// This is a LOCAL node-1 interface/queue observation, not a network-wide pressure
// value and not a validated HCRAF online Congestion feature.
class HcrafStage1amLocalSnapshot {
  struct Candidate {
    ns3::Ptr<ns3::PointToPointNetDevice> device;
    uint64_t faceId;
  };
public:
  explicit HcrafStage1amLocalSnapshot(const std::string& path) : m_out(path) {
    if (!m_out) throw std::runtime_error("Cannot open NFD local queue snapshots");
  }
  void AddCandidate(ns3::Ptr<ns3::PointToPointNetDevice> dev, uint64_t faceId) {
    if (!dev || !dev->GetQueue() || faceId==0) throw std::runtime_error("Invalid local Face/queue mapping");
    for (const auto& c : m_candidates)
      if (c.faceId==faceId || c.device==dev) throw std::runtime_error("Duplicate local queue candidate");
    if (dev->GetQueue()->GetMaxSize().GetUnit()!=ns3::QueueSizeUnit::PACKETS ||
        dev->GetQueue()->GetMaxSize().GetValue()==0)
      throw std::runtime_error("Local queue requires finite packet capacity");
    m_candidates.push_back({dev,faceId});
  }
  void ObserveBeforeForwarding(uint64_t decisionId) {
    if (!decisionId || m_candidates.size()!=3) throw std::runtime_error("Invalid NFD decision/candidate coverage");
    const auto now=ns3::Simulator::Now().GetNanoSeconds();
    for (const auto& c : m_candidates) {
      auto q=c.device->GetQueue();
      ns3::DataRateValue rate;
      c.device->GetAttribute("DataRate",rate);
      const auto capacity=q->GetMaxSize().GetValue();
      const auto queued=q->GetNPackets();
      if (queued>capacity) throw std::runtime_error("Observed physical queue exceeds capacity");
      m_out << "{\"schema\":\"1AM.TECHNICAL.LOCAL_ONLY.0\",\"decision_id\":" << decisionId
        << ",\"node_id\":1,\"observed_before_forwarding\":true,\"sim_time_ns\":" << now
        << ",\"candidate_face_id\":" << c.faceId
        << ",\"device_index\":" << c.device->GetIfIndex()
        << ",\"link_up\":" << (c.device->IsLinkUp()?"true":"false")
        << ",\"capacity_packets\":" << capacity << ",\"queue_packets\":" << queued
        << ",\"queue_bytes\":" << q->GetNBytes()
        << ",\"local_queue_occupancy_fraction\":" << (static_cast<double>(queued)/capacity)
        << ",\"data_rate_bps\":" << rate.Get().GetBitRate()
        << ",\"remote_node_queue_accessed\":false,\"future_pressure_label\":null,\"Congestion\":null}\n";
      if (!m_out) throw std::runtime_error("Cannot write local NFD queue observation");
    }
  }
  void Finish() {
    m_out.flush();
    if (!m_out) throw std::runtime_error("Local queue snapshot log flush failed");
  }
private:
  std::ofstream m_out;
  std::vector<Candidate> m_candidates;
};
#endif
