// Stage 1AM v0.47 pre-registered variable load & two-pulse RNG pilot, never final F3.
// Selected physical Face is fixed. Matched TARGET arrivals across competitor OFF/ON
// allow controlled queue-service, backlog and completion-delay comparisons.
// No HCRAF policy evaluation, no labels, no use of post-decision events online.
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/ndnSIM-module.h"
#include "ns3/ndnSIM/apps/ndn-app.hpp"
#include "ns3/ndnSIM/model/ndn-l3-protocol.hpp"
#include "ns3/ndnSIM/NFD/daemon/fw/forwarder.hpp"
#include <fstream>
#include "hcraf-collection-policy.hpp"
#include "hcraf-stage1w-monitor.hpp"
#include "hcraf-stage1am-local-snapshot.hpp"
#include <set>
#include "ns3/error-model.h"
#include <stdexcept>
#include <sstream>
#include <memory>
#include <chrono>

namespace ns3 {
class HcrafRequester : public ns3::ndn::App {
public:
  static TypeId GetTypeId() {
    static TypeId tid = TypeId("ns3::HcrafRequester").SetParent<ns3::ndn::App>()
      .AddConstructor<HcrafRequester>();
    return tid;
  }
  void Configure(const std::string& mode, const std::string& output, uint32_t sourceId,
                 uint32_t requestOverride, uint64_t intervalOverrideNs, uint32_t lifetimeMs,
                 const std::string& prefix, const std::string& trafficClass,
                 int stream, uint64_t offsetNs) {
    m_prefix=prefix; m_trafficClass=trafficClass; m_stream=stream; m_offsetNs=offsetNs;
    m_requestOverride = requestOverride; m_intervalOverrideNs = intervalOverrideNs; m_lifetimeMs = lifetimeMs;
    m_mode = mode;
    m_sourceId = sourceId;
    m_nonce = 1000 + 10000 * sourceId;
    m_out.open(output);
    m_arrivals.open(output + ".arrivals.jsonl");
    if(!m_arrivals)throw std::runtime_error("Cannot open arrival schedule");
    m_arrivals << std::setprecision(17);
    if (!m_out) throw std::runtime_error("Cannot open consumer event file");
  }
  void OnData(std::shared_ptr<const ::ndn::Data> data) override {
    ns3::ndn::App::OnData(data);
    m_out << "{\"event\":\"DATA\",\"time_ns\":" << Simulator::Now().GetNanoSeconds()
          << ",\"name\":" << hcraf::Recorder::quote(data->getName().toUri())
          << ",\"payload_bytes\":" << data->getContent().value_size() << "}\n";
    m_out.flush();
  }
  void OnNack(std::shared_ptr<const ::ndn::lp::Nack> nack) override {
    ns3::ndn::App::OnNack(nack);
    m_out << "{\"event\":\"NACK\",\"time_ns\":" << Simulator::Now().GetNanoSeconds()
          << ",\"name\":" << hcraf::Recorder::quote(nack->getInterest().getName().toUri())
          << ",\"reason\":" << static_cast<int>(nack->getReason()) << "}\n";
    m_out.flush();
  }
protected:
  void StartApplication() override {
    ns3::ndn::App::StartApplication();
    // Fixed protocol; change only after registration. Jitter uses an ns-3 RNG
    // with fixed stream so changing RngRun changes actual input, not only a label.
    const bool overflow = m_mode == "forward-overflow" || m_mode == "return-overflow";
    const bool buffered = m_mode == "forward-buffered" || m_mode == "return-buffered";
    const bool mixed = m_mode == "mixed-fragmented";
    const uint32_t requests = m_requestOverride ? m_requestOverride :
                              m_mode == "idle" ? 0u : overflow ? 120u : buffered ? 18u :
                              m_mode == "receive-loss" ? 40u : mixed ? 24u : 16u;
    const int64_t interval = m_intervalOverrideNs ? static_cast<int64_t>(m_intervalOverrideNs) :
                             overflow || buffered ? 1000000LL : mixed ? 250000000LL :
                             m_mode == "receive-loss" ? 10000000LL : 100000000LL;
    auto jitter = CreateObject<UniformRandomVariable>();
    jitter->SetStream(m_stream);
    const bool pulsed = m_trafficClass == "INDEPENDENT_COMPETITOR";
    if (pulsed && (requests != 96u || interval != 2000000LL))
      throw std::runtime_error("Unregistered v0.47 two-burst competitor schedule");
    // RNG stream 139 is independent of target stream 129. RngRun makes each
    // emitted two-pulse start genuinely different; copied under both monitors.
    const uint64_t startNs = pulsed ? jitter->GetInteger(0, 300000000u) : 0u;
    for (uint32_t i=0; i<requests; ++i) {
      const int64_t jitterNs = pulsed ? int64_t(jitter->GetInteger(0, 199999)) :
                                        int64_t(jitter->GetInteger(0, 99999));
      const uint32_t burstIndex = pulsed ? i / 48u : 0u;
      const int64_t base = pulsed ? int64_t(burstIndex)*145000000LL +
                                     int64_t(i%48u)*interval : int64_t(i)*interval;
      const int64_t time = 2000000000LL + int64_t(m_offsetNs) +
                           int64_t(startNs) + base + jitterNs;
      m_arrivals << "{\"sequence\":" << i << ",\"time_ns\":" << time
        << ",\"jitter_ns\":" << jitterNs
        << ",\"pulse_start_ns\":" << startNs
        << ",\"burst_index\":" << burstIndex
        << ",\"included\":true,\"traffic_class\":" << hcraf::Recorder::quote(m_trafficClass)
        << ",\"stream\":" << m_stream << ",\"schedule\":\"STAGE1AH_INDEPENDENT_TRAFFIC_STREAMS\"}\n";
      Simulator::Schedule(NanoSeconds(time), &HcrafRequester::Send, this, i);
    }
    m_arrivals.flush();if(!m_arrivals)throw std::runtime_error("Arrival trace failed");
  }
private:
  void Send(uint32_t sequence) {
    if (!m_active) return;
    const uint32_t nameId = sequence;
    const bool prefixInterest = false;
    auto interest = std::make_shared<::ndn::Interest>(
      ::ndn::Name(prefixInterest ? m_prefix : m_prefix + "/" + std::to_string(nameId)));
    interest->setNonce(++m_nonce);
    interest->setInterestLifetime(::ndn::time::milliseconds(m_lifetimeMs));
    interest->setCanBePrefix(prefixInterest);
    interest->setMustBeFresh(true);
    m_out << "{\"event\":\"SEND\",\"time_ns\":" << Simulator::Now().GetNanoSeconds()
          << ",\"name\":" << hcraf::Recorder::quote(interest->getName().toUri())
          << ",\"nonce\":" << m_nonce << ",\"source_id\":" << m_sourceId
          << ",\"traffic_class\":" << hcraf::Recorder::quote(m_trafficClass) << "}\n";
    m_out.flush();
    m_transmittedInterests(interest, this, m_face);
    m_appLink->onReceiveInterest(*interest);
  }
  uint32_t m_nonce = 1000;
  uint32_t m_sourceId = 0;
  uint32_t m_requestOverride = 0, m_lifetimeMs = 1000;
  uint64_t m_intervalOverrideNs = 0, m_offsetNs = 0;
  int m_stream = 129;
  std::string m_prefix = "/hcraf/pilot", m_trafficClass = "TARGET";
  std::string m_mode;
  std::ofstream m_out;
  std::ofstream m_arrivals;
};
NS_OBJECT_ENSURE_REGISTERED(HcrafRequester);

class HcrafResponder : public ns3::ndn::App {
public:
  static TypeId GetTypeId() {
    static TypeId tid = TypeId("ns3::HcrafResponder").SetParent<ns3::ndn::App>()
      .AddConstructor<HcrafResponder>();
    return tid;
  }
  void Configure(bool silent, double delay, bool forceLeaf, bool doubleReply, bool spontaneous, bool bigPayload, std::ofstream* receipts) {
    m_silent = silent; m_delay = delay; m_forceLeaf = forceLeaf;
    m_doubleReply = doubleReply; m_spontaneous = spontaneous; m_bigPayload = bigPayload; m_receipts = receipts;
  }
  void OnInterest(std::shared_ptr<const ::ndn::Interest> interest) override {
    ns3::ndn::App::OnInterest(interest);
    if (!m_active || m_silent) return;
    if (!m_receipts) throw std::runtime_error("Path receipts log unavailable");
    // ndn-cxx prints Nonce as eight hexadecimal digits (e.g. 00002af9).
    // Streaming that representation directly as a JSON number is invalid.
    // Convert the verified hexadecimal text to an unsigned *decimal* number;
    // it must match the consumer's numeric nonce for the same Interest Name.
    std::ostringstream nonceHexStream;
    nonceHexStream << interest->getNonce();
    const std::string nonceHex = nonceHexStream.str();
    if (nonceHex.size() != 8 ||
        nonceHex.find_first_not_of("0123456789abcdefABCDEF") != std::string::npos) {
      throw std::runtime_error("Producer receipt Nonce is not eight hex digits");
    }
    const uint32_t nonceDecimal = static_cast<uint32_t>(std::stoul(nonceHex, nullptr, 16));
    *m_receipts << "{\"producer_node_id\":" << GetNode()->GetId()
      << ",\"time_ns\":" << Simulator::Now().GetNanoSeconds()
      << ",\"name\":" << hcraf::Recorder::quote(interest->getName().toUri())
      << ",\"nonce\":" << nonceDecimal << "}\n";
    m_receipts->flush();
    if (!*m_receipts) throw std::runtime_error("Path receipts log write failed");
    auto name = m_forceLeaf ? ::ndn::Name("/hcraf/pilot/0") : interest->getName();
    Simulator::Schedule(Seconds(m_delay), &HcrafResponder::Reply, this, name);
    if (m_doubleReply) Simulator::Schedule(Seconds(m_delay + 0.0001), &HcrafResponder::Reply, this, name);
  }
protected:
  void StartApplication() override {
    ns3::ndn::App::StartApplication();
    ns3::ndn::FibHelper::AddRoute(GetNode(), "/hcraf", m_face, 0);
    if (m_spontaneous)
      Simulator::Schedule(Seconds(2.06), &HcrafResponder::Reply, this, ::ndn::Name("/hcraf/pilot/0"));
  }
private:
  void Reply(::ndn::Name name) {
    if (!m_active) return;
    auto data = std::make_shared<::ndn::Data>(name);
    data->setFreshnessPeriod(::ndn::time::milliseconds(1000));
    data->setContent(std::make_shared<::ndn::Buffer>(m_bigPayload ? 4096 : 1024));
    // Same simulation signature convention as the official ndnSIM Producer.
    ::ndn::SignatureInfo signature(static_cast<::ndn::tlv::SignatureTypeValue>(255));
    data->setSignatureInfo(signature);
    ::ndn::EncodingEstimator estimator;
    ::ndn::EncodingBuffer encoder(estimator.appendVarNumber(0), 0);
    encoder.appendVarNumber(0);
    data->setSignatureValue(encoder.getBuffer());
    data->wireEncode();
    m_transmittedDatas(data, this, m_face);
    m_appLink->onReceiveData(*data);
  }
  std::ofstream* m_receipts = nullptr;
  bool m_silent = false, m_forceLeaf = false, m_doubleReply = false, m_spontaneous = false, m_bigPayload = false;
  double m_delay = 0;
};
NS_OBJECT_ENSURE_REGISTERED(HcrafResponder);
}

static void RecordRxDrop(std::ofstream* out, ns3::Ptr<const ns3::Packet> packet) {
  *out << "{\"event\":\"PHY_RX_DROP\",\"node_id\":2,\"time_ns\":"
       << ns3::Simulator::Now().GetNanoSeconds() << ",\"packet_uid\":" << packet->GetUid() << "}\n";
  out->flush();
}

int main(int argc, char* argv[]) {
  using namespace ns3;
  std::string mode = "LP_SELF_ONLY", output = ".";
  std::string topology = "VAL_CHAIN_I";
  std::string pathArm = "QUIET_CLEAN";
  uint32_t selectedSlot = 0;
  uint32_t seed = 17;
  uint64_t run = 9401;
  bool instrument = true;
  uint32_t requestOverride=0, lifetimeMs=1000, producerDelayMs=0;
  uint64_t intervalOverrideNs=0, forwardBps=0, returnBps=0;
  uint32_t competitorCount=0;
  uint64_t competitorIntervalNs=0, competitorOffsetNs=0, targetOffsetNs=0;
  CommandLine cmd;
  cmd.AddValue("mode", "LP_INDEPENDENT_COMPETITOR_NO_DROP (fixed 1AJ diagnostic regime)", mode);
  cmd.AddValue("pathArm", "QUIET_CLEAN, MIXED_LOCAL, MIXED_RELAY, MIXED_MID, MIXED_RETURN", pathArm);
  cmd.AddValue("competitorCount", "Distinct competitor requests (only C1/C2)", competitorCount);
  cmd.AddValue("competitorIntervalNs", "Competitor request interval", competitorIntervalNs);
  cmd.AddValue("competitorOffsetNs", "Competitor start offset from t=2s", competitorOffsetNs);
  cmd.AddValue("targetOffsetNs", "Pre-registered 1AH-A1 target start offset from t=2s", targetOffsetNs);
  cmd.AddValue("topology", "VAL_CHAIN_I or TEST_CHAIN_J (new independent four-hop topologies)", topology);
  cmd.AddValue("selectedSlot", "Controlled upstream face slot 0/1/2 (forced assignment)", selectedSlot);
  cmd.AddValue("output", "Existing output directory", output);
  cmd.AddValue("seed", "ns-3 random seed", seed);
  cmd.AddValue("run", "ns-3 random run number", run);
  cmd.AddValue("instrument", "Enable event and queue monitor (1/0)", instrument);
  cmd.AddValue("requestCount", "Override number of distinct requests (0 keeps mode defaults)", requestOverride);
  cmd.AddValue("intervalNs", "Override request separation in nanoseconds", intervalOverrideNs);
  cmd.AddValue("lifetimeMs", "Interest lifetime in milliseconds", lifetimeMs);
  cmd.AddValue("producerDelayMs", "Producer response delay in milliseconds", producerDelayMs);
  cmd.AddValue("forwardBps", "Override primary forward link bps", forwardBps);
  cmd.AddValue("returnBps", "Override primary return link bps", returnBps);

  cmd.Parse(argc, argv);
  if (std::set<std::string>{"LP_SELF_ONLY","LP_INDEPENDENT_COMPETITOR_NO_DROP","LP_INDEPENDENT_COMPETITOR_DROP","UNFRAGMENTED_MATCHED_BYTES"}.count(mode)==0)
    throw std::runtime_error("Unregistered 1AH regime");
  if ((topology!="VAL_CHAIN_I" && topology!="TEST_CHAIN_J") || selectedSlot>2)
    throw std::runtime_error("Unregistered 1AH topology or slot");

  if(lifetimeMs<100 || lifetimeMs>5000 || producerDelayMs>3000 || requestOverride>200 ||
     intervalOverrideNs>1000000000ULL) throw std::runtime_error("Invalid registered 1AD bounds");
  const bool hasCompetitor=(competitorCount!=0);
  if ((hasCompetitor && !competitorIntervalNs) ||
      (!hasCompetitor && (competitorIntervalNs || competitorOffsetNs)) ||
      competitorCount>200 || competitorIntervalNs>1000000000ULL || competitorOffsetNs>5000000000ULL)
    throw std::runtime_error("Unregistered competitor injection plan");
  if (!requestOverride || !intervalOverrideNs)
    throw std::runtime_error("1AH requires explicit target request plan");
  // Strict registered two-topology x three-face x six-arm x two-RngRun matrix.
  // Every monitored/uninstrumented pair uses the SAME true FIB primary Face.
  if (seed!=17 || ((topology=="VAL_CHAIN_I" && (run<11221 || run>11226)) ||
                    (topology=="TEST_CHAIN_J" && (run<11321 || run>11326))) ||
      mode!="LP_INDEPENDENT_COMPETITOR_NO_DROP" || lifetimeMs!=2600 ||
      producerDelayMs!=0 || requestOverride!=12 ||
      intervalOverrideNs!=30000000ULL || returnBps!=50000000ULL ||
      targetOffsetNs!=30000000ULL ||
       (pathArm!="QUIET_CLEAN" && pathArm!="MIXED_LOCAL" && pathArm!="MIXED_RELAY" &&
       pathArm!="MIXED_MID" && pathArm!="MIXED_RETURN"))
    throw std::runtime_error("Outside registered 1AM path-wide matrix");
  // Pre-registration: identical 96 competitor requests in every stressed arm,
  // with two independently observable bursts; only the selected link rate differs.
  // Non-overlapping pulse positions across RNG runs are genuine input variation.
  const bool quiet = pathArm == "QUIET_CLEAN";
  const uint32_t plannedCompetitors = quiet ? 0u : 96u;
  const uint64_t plannedInterval = quiet ? 0ULL : 2000000ULL;
  if (competitorCount != plannedCompetitors || competitorIntervalNs != plannedInterval ||
      competitorOffsetNs != 0ULL ||
      forwardBps != (pathArm=="MIXED_LOCAL" ? 120000ULL : 50000000ULL))
    throw std::runtime_error("Unregistered 1AM v0.47 competitor/rate plan");
  // High-capacity negative controls must avoid the prior 5ms LP-serialization wait.
  // This is a new experiment, not retroactive relabeling of v0.44 Test.
  const uint64_t backgroundRate = 50000000ULL;
  const uint64_t remoteForwardRate = pathArm=="MIXED_RELAY" ? 120000ULL : backgroundRate;
  const uint64_t midForwardRate = pathArm=="MIXED_MID" ? 120000ULL : backgroundRate;
  const uint64_t remoteReturnRate = pathArm=="MIXED_RETURN" ? 6000000ULL : backgroundRate;
  const std::string phaseArm = pathArm;
  RngSeedManager::SetSeed(seed); RngSeedManager::SetRun(run);
  NodeContainer nodes;
  const bool fragmented = mode != "UNFRAGMENTED_MATCHED_BYTES";
  const bool mixed = true; // Four-hop physical path; eleven nodes and ten links.
  nodes.Create(11u);
  PointToPointHelper link;
  link.SetQueue("ns3::DropTailQueue<Packet>", "MaxSize", StringValue("20p"));
  link.SetDeviceAttribute("InterframeGap", TimeValue(NanoSeconds(0)));
  link.SetDeviceAttribute("DataRate", StringValue("50Mbps"));
  link.SetChannelAttribute("Delay", StringValue(topology=="VAL_CHAIN_I" ? "13ms" : "21ms"));
  link.Install(nodes.Get(0), nodes.Get(1));
  link.SetDeviceAttribute("DataRate", StringValue("50Mbps"));
  link.SetChannelAttribute("Delay", StringValue(topology=="VAL_CHAIN_I" ? "13ms" : "21ms"));
  auto primaryDevices = link.Install(nodes.Get(1), nodes.Get(2));
  auto routerDevice = DynamicCast<PointToPointNetDevice>(primaryDevices.Get(0));
  auto producerDevice = DynamicCast<PointToPointNetDevice>(primaryDevices.Get(1));
  const uint64_t forwardRate = forwardBps ? forwardBps : 10000000;
  const uint64_t returnRate = returnBps ? returnBps : 10000000;
  routerDevice->SetDataRate(DataRate(forwardRate));
  producerDevice->SetDataRate(DataRate(returnRate));
  auto errors = CreateObject<RateErrorModel>();
  errors->SetUnit(RateErrorModel::ERROR_UNIT_PACKET);
  errors->SetRate(mode == "receive-loss" ? 0.25 : 0.0);
  errors->AssignStreams(71);
  producerDevice->SetReceiveErrorModel(errors);
  std::ofstream faults(output + "/fault_events.jsonl");
  if (!faults) throw std::runtime_error("Cannot open fault log");
  if (!producerDevice->TraceConnectWithoutContext("PhyRxDrop", MakeBoundCallback(&RecordRxDrop, &faults)))
    throw std::runtime_error("Missing PhyRxDrop trace");
  link.SetDeviceAttribute("DataRate", StringValue("512kbps"));
  link.SetChannelAttribute("Delay", StringValue("30ms"));
  auto secondaryDevices = link.Install(nodes.Get(1), nodes.Get(3));
  link.SetDeviceAttribute("DataRate", StringValue("1Mbps"));
  link.SetChannelAttribute("Delay", StringValue("20ms"));
  auto thirdDevices=link.Install(nodes.Get(1),nodes.Get(4));
  // A genuine topology split from DEV: an extra full NDN forwarding hop per branch.
  // E/F use distinct permutations with distinct delays and disjoint RNG runs.
  // Independent new Test follows sealed Validation; v0.44 C/D are already observed.
  const std::vector<uint32_t> relayToMid = topology=="VAL_CHAIN_I" ?
    std::vector<uint32_t>{5u,7u,6u} : std::vector<uint32_t>{6u,5u,7u};
  const std::vector<uint32_t> midToProducerBySlot = topology=="VAL_CHAIN_I" ?
    std::vector<uint32_t>{10u,9u,8u} : std::vector<uint32_t>{9u,10u,8u};
  link.SetDeviceAttribute("DataRate", StringValue("50Mbps"));
  link.SetChannelAttribute("Delay", StringValue(topology=="VAL_CHAIN_I" ? "14ms" : "22ms"));
  std::vector<NetDeviceContainer> relayLinks, midLinks;
  for (uint32_t s=0; s<3; ++s)
    relayLinks.push_back(link.Install(nodes.Get(2+s), nodes.Get(relayToMid[s])));
  link.SetChannelAttribute("Delay", StringValue(topology=="VAL_CHAIN_I" ? "17ms" : "25ms"));
  for (uint32_t s=0; s<3; ++s)
    midLinks.push_back(link.Install(nodes.Get(relayToMid[s]), nodes.Get(midToProducerBySlot[s])));
  // Slot-specific bottleneck controls use the actual path, not a hardcoded Face ID.

  // NFD NetDeviceTransport reads device MTU during StackHelper::InstallAll.
  // Constrain BOTH endpoints to ensure LP (not IP) fragmentation on these point-to-point faces.
  if (fragmented) {
    for (uint32_t n=0; n<nodes.GetN(); ++n) {
      auto node = nodes.Get(n);
      for (uint32_t d=0;d<node->GetNDevices();++d) {
        auto dev=DynamicCast<PointToPointNetDevice>(node->GetDevice(d));
        if (dev && !dev->SetMtu(600)) throw std::runtime_error("Cannot set test face MTU");
      }
    }
  }
  if (!fragmented) { // 4096 content bytes in a single NDN packet (not 1500 MTU).
    for (uint32_t n=0; n<nodes.GetN(); ++n)
      for (uint32_t d=0;d<nodes.Get(n)->GetNDevices();++d) {
        auto dev=DynamicCast<PointToPointNetDevice>(nodes.Get(n)->GetDevice(d));
        if (dev && !dev->SetMtu(9000)) throw std::runtime_error("Cannot set unfragmented matched-byte MTU");
      }
  }
  // Bottleneck is limited to the selected branch and direction.
  auto candidateUp = selectedSlot==0 ? primaryDevices.Get(0) :
    (selectedSlot==1 ? secondaryDevices.Get(0) : thirdDevices.Get(0));
  auto candidateDown = selectedSlot==0 ? primaryDevices.Get(1) :
    (selectedSlot==1 ? secondaryDevices.Get(1) : thirdDevices.Get(1));
  // Only selected physical branch throttled; both unmonitored and monitored
  // uses the SAME link speeds and NFD FIB-first selected Face.
  DynamicCast<PointToPointNetDevice>(candidateUp)->SetDataRate(DataRate(forwardBps));
  DynamicCast<PointToPointNetDevice>(candidateDown)->SetDataRate(DataRate(returnBps));
  auto relayUp = DynamicCast<PointToPointNetDevice>(relayLinks[selectedSlot].Get(0));
  auto midUp = DynamicCast<PointToPointNetDevice>(midLinks[selectedSlot].Get(0));
  auto producerDown = DynamicCast<PointToPointNetDevice>(midLinks[selectedSlot].Get(1));
  if (!relayUp || !midUp || !producerDown) throw std::runtime_error("Selected remote devices missing");
  relayUp->SetDataRate(DataRate(remoteForwardRate));
  midUp->SetDataRate(DataRate(midForwardRate));
  producerDown->SetDataRate(DataRate(remoteReturnRate));
  ns3::ndn::StackHelper stack;
  // Disable all content stores for the controlled queue/loss experiment.
  // Cache and retransmission remain separately evidenced in approved 1S/1U.
  stack.setCsSize(0);
  stack.InstallAll();
  ns3::ndn::StrategyChoiceHelper::InstallAll("/hcraf", "/localhost/nfd/strategy/best-route");
  // Native NFD BestRoute is used for diagnostic controls ONLY.
  // This does not implement or alter the HCRAF two-branch/Gate strategy.
  // No special forwarding policy: all controls use native NFD BestRoute.
  // An absent route is deliberately created ONLY in the no-route control.
  ns3::ndn::FibHelper::AddRoute(nodes.Get(0), "/hcraf", nodes.Get(1), 1);
  // Actual FIB cost-1 branch is the registered Face.  This guarantees
  // uninstrumented native NFD BestRoute chooses the SAME selected branch.
  // Instrumented collector also picks the first eligible (uniform draw 1/6).
  for (uint32_t s=0; s<3; ++s) {
    const uint32_t rank = (s==selectedSlot ? 1u : (s<selectedSlot ? s+2u : s+1u));
    ns3::ndn::FibHelper::AddRoute(nodes.Get(1), "/hcraf", nodes.Get(2+s), rank);
  }
  for (uint32_t s=0; s<3; ++s)
    ns3::ndn::FibHelper::AddRoute(nodes.Get(2+s), "/hcraf", nodes.Get(relayToMid[s]), 1);
  for (uint32_t s=0; s<3; ++s)
    ns3::ndn::FibHelper::AddRoute(nodes.Get(relayToMid[s]), "/hcraf", nodes.Get(midToProducerBySlot[s]), 1);
  std::ofstream producerReceipts(output + "/producer_receipts.jsonl");
  if (!producerReceipts) throw std::runtime_error("Cannot open independent producer receipts");
  const std::vector<uint32_t> producerNodes = {8u,9u,10u};
  for (uint32_t n : producerNodes) {
    auto responder = CreateObject<HcrafResponder>();
    responder->Configure(false,
      double(producerDelayMs)/1000.0,
      false, false, false, true, &producerReceipts); // identical 4096-byte Data content
    nodes.Get(n)->AddApplication(responder); responder->SetStartTime(Seconds(0));
  }
  auto requester = CreateObject<HcrafRequester>();
  requester->Configure(mode, output + "/consumer_events.jsonl", 0, requestOverride,
    intervalOverrideNs, lifetimeMs, "/hcraf/pilot", "TARGET", 129, targetOffsetNs);
  nodes.Get(0)->AddApplication(requester); requester->SetStartTime(Seconds(0));
  if (hasCompetitor) {
    auto competitor=CreateObject<HcrafRequester>();
    competitor->Configure(mode, output + "/competitor_events.jsonl", 1, competitorCount,
      competitorIntervalNs, lifetimeMs, "/hcraf/competitor", "INDEPENDENT_COMPETITOR", 139,
      competitorOffsetNs);
    nodes.Get(0)->AddApplication(competitor); competitor->SetStartTime(Seconds(0));
  }
  auto l3 = nodes.Get(1)->GetObject<ns3::ndn::L3Protocol>();
  auto primary = l3->getFaceByNetDevice(primaryDevices.Get(0));
  auto secondary = l3->getFaceByNetDevice(secondaryDevices.Get(0));
  auto third=l3->getFaceByNetDevice(thirdDevices.Get(0));
  if (!primary || !secondary || !third) throw std::runtime_error("Missing upstream Face mapping");
  auto forwarder = l3->getForwarder();
  if (instrument) {
    forwarder->hcrafEnable(output + "/events.jsonl", nodes.Get(1)->GetId());
    // Deliberately deterministic allocation; nominal Uniform prob 1/3 is NOT
    // the behavioral propensity for this forced action (which is 1).
    forwarder->hcrafEnableCoverage([]() { return 1.0/6.0; }, false);
  }
  std::vector<std::shared_ptr<nfd::Forwarder>> relayForwarders;
  for (uint32_t s=0; s<3; ++s) {
    auto relay=nodes.Get(2+s)->GetObject<ns3::ndn::L3Protocol>()->getForwarder();
    relayForwarders.push_back(relay);
    if (instrument)
      relay->hcrafEnable(output + "/events_hop2_node" + std::to_string(2+s) + ".jsonl", 2+s);
  }
  std::unique_ptr<HcrafStage1wMonitor> linkMonitor;
  std::ofstream observerCosts;
  std::ofstream nfdDispatchCosts;
  std::unique_ptr<HcrafStage1amLocalSnapshot> liveLocalQueue;
  if (instrument) {
    linkMonitor.reset(new HcrafStage1wMonitor(nodes, output + "/link_events.jsonl"));
    // Only the three LOCAL interfaces of the actual decision router are read.
    liveLocalQueue.reset(new HcrafStage1amLocalSnapshot(output + "/nfd_local_queue_at_decision.jsonl"));
    liveLocalQueue->AddCandidate(DynamicCast<PointToPointNetDevice>(primaryDevices.Get(0)),primary->getId());
    liveLocalQueue->AddCandidate(DynamicCast<PointToPointNetDevice>(secondaryDevices.Get(0)),secondary->getId());
    liveLocalQueue->AddCandidate(DynamicCast<PointToPointNetDevice>(thirdDevices.Get(0)),third->getId());
    nfdDispatchCosts.open(output + "/nfd_dispatch_cost.jsonl");
    if (!nfdDispatchCosts) throw std::runtime_error("Cannot open NFD dispatch cost log");
    forwarder->hcrafSetDispatchTimingObserver([&nfdDispatchCosts](uint64_t id, uint64_t wall, uint64_t cpu) {
      nfdDispatchCosts << "{\"decision_id\":" << id << ",\"NFD_forwarding_path_wall_ns\":" << wall
        << ",\"NFD_forwarding_path_cpu_ns\":" << cpu
        << ",\"includes_telemetry_and_recorder\":true,\"is_HCRAF_Gate_only_cost\":false}\n";
      if (!nfdDispatchCosts) throw std::runtime_error("NFD dispatch cost write failed");
    });
    observerCosts.open(output + "/observer_cost.jsonl");
    if (!observerCosts) throw std::runtime_error("Cannot open observer cost log");
    forwarder->hcrafSetDecisionObserver([&linkMonitor, &observerCosts, &liveLocalQueue](uint64_t id) {
      // Invoked from NFD beginDecision BEFORE actual selected Face TX.
      liveLocalQueue->ObserveBeforeForwarding(id);
      const auto a = std::chrono::steady_clock::now();
      linkMonitor->Snapshot(id);
      const auto b = std::chrono::steady_clock::now();
      const auto duration = std::chrono::duration_cast<std::chrono::nanoseconds>(b-a).count();
      observerCosts << "{\"decision_id\":" << id << ",\"snapshot_observer_wall_ns\":" << duration
                    << ",\"is_NFD_decision_latency\":false}\n";
      if (!observerCosts) throw std::runtime_error("Observer timing write failure");
    });
  }
  std::ofstream control(output + "/control_events.jsonl");
  if (!control) throw std::runtime_error("Cannot open control log");
  std::ofstream config(output + "/scenario.json");
  // Explicit local device validation: avoid using hardcoded Face IDs.
  const std::vector<uint64_t> actualFaces = {primary->getId(),secondary->getId(),third->getId()};
  const uint32_t selectedRelay=2+selectedSlot;
  const uint32_t selectedMid=relayToMid[selectedSlot];
  const uint32_t selectedProducer=midToProducerBySlot[selectedSlot];
  const uint64_t plannedCount = requestOverride;
  const uint64_t nominalInterval = intervalOverrideNs;
  if (!plannedCount || !nominalInterval) throw std::runtime_error("1AF requires explicit registered traffic plan");
  config << "{\"mode\":" << hcraf::Recorder::quote(mode)
    << ",\"collector_stage\":\"1AM.NFD_LOCAL_QUEUE.0\""
    << ",\"amendment_stage\":\"1AM.F3_FRAGMENT_AWARE_HARM_DIAGNOSTIC_FOUR_HOP.0\""
    << ",\"phase_arm\":" << hcraf::Recorder::quote(phaseArm)
    << ",\"target_offset_ns\":" << targetOffsetNs
    << ",\"no_counterfactual_unselected_face\":true"
    << ",\"topology_id\":" << hcraf::Recorder::quote(topology)
    << ",\"selected_face_slot\":" << selectedSlot
    << ",\"selected_face_id\":" << actualFaces[selectedSlot]
    << ",\"actual_assignment_probability\":1.0"
    << ",\"nominal_uniform_probability_NOT_behavioral_propensity\":0.33333333333333331"
    << ",\"selection_policy\":\"FORCED_DETERMINISTIC_DRAW_UNIFORM_NOMINAL\""
    << ",\"eligible_face_ids\":[" << actualFaces[0] << "," << actualFaces[1] << "," << actualFaces[2] << "]"
    << ",\"path_nodes\":[0,1," << selectedRelay << "," << selectedMid << "," << selectedProducer << "]"
    << ",\"network_node_count\":11,\"network_directed_device_count\":20"
    << ",\"holdout_partition\":" << hcraf::Recorder::quote(topology=="VAL_CHAIN_I" ? "VALIDATION" : "TEST")
    << ",\"decision_node_id\":1,\"selected_relay_node_id\":" << selectedRelay
    << ",\"selected_mid_node_id\":" << selectedMid
    << ",\"selected_producer_node_id\":" << selectedProducer
    << ",\"purpose\":\"NEW_TEST_AFTER_V045_EF_SEEN_NOT_HCRAF_POLICY\""
    << ",\"seed\":" << seed << ",\"run\":" << run
    << ",\"instrument_enabled\":" << (instrument?"true":"false")
    << ",\"traffic_class_primary\":\"TARGET\""
    << ",\"traffic_class_competitor\":\"INDEPENDENT_COMPETITOR\""
    << ",\"target_prefix\":\"/hcraf/pilot\""
    << ",\"competitor_prefix\":\"/hcraf/competitor\""
    << ",\"competitor_injection_enabled\":" << (hasCompetitor?"true":"false")
    << ",\"competitor_planned_requests\":" << competitorCount
    << ",\"competitor_interval_ns\":" << competitorIntervalNs
    << ",\"competitor_offset_ns\":" << competitorOffsetNs
    << ",\"competitor_pulse_schedule\":\"TWO_BURSTS_48_EACH_2MS_WITH_RNG_START_0_300MS\""
    << ",\"competitor_burst_start_rng_stream\":139"
    << ",\"competitor_burst_gap_ns\":49000000"
    << ",\"competitor_pulse_count\":" << (hasCompetitor ? 2 : 0)
    << ",\"target_schedule_rng_stream\":129,\"competitor_schedule_rng_stream\":139"
    << ",\"planned_requests\":" << plannedCount
    << ",\"nominal_arrival_interval_ns\":" << nominalInterval
    << ",\"randomized_arrival_jitter_stream\":129"
    << ",\"interest_lifetime_ms\":" << lifetimeMs
    << ",\"stop_ns\":20000000000,\"cache_enabled\":false,\"multi_hop_enabled\":true"
    << ",\"queue_capacity_packets\":20,\"queue_trace_schema\":\"1W.0\""
    << ",\"mtu_bytes\":" << (fragmented?600:9000)
    << ",\"payload_bytes\":4096"
    << ",\"selected_forward_bps\":" << forwardBps
    << ",\"selected_relay_forward_bps\":" << remoteForwardRate
    << ",\"selected_mid_forward_bps\":" << midForwardRate
    << ",\"selected_producer_reverse_bps\":" << remoteReturnRate
    << ",\"selected_return_bps\":" << returnBps
    << ",\"theta_pilot\":2,\"horizon_ms_pilot\":2000"
    << ",\"future_oracle_horizon_ns_pilot\":50000000"
    << ",\"whole_path_oracle_is_retrospective\":true"
    << ",\"path_reverse_fragment_unclassifiable_means_UNKNOWN\":true"
    << ",\"future_oracle_scope\":\"EIGHT_DEVICES_FOUR_HOP_FRAGMENT_AWARE_WITH_CENSORING\""
    << ",\"future_oracle_is_final_F3\":false"
    << ",\"M0_raw_wait_is_not_final_F3\":true"
    << ",\"group_aware_metric_candidates\":[\"M0\",\"M1\",\"M2\",\"M3\"]"
    << ",\"independent_physical_pressure_test\":true"
    << ",\"paired_target_arrivals_must_match\":true"
    << ",\"paired_comparison_is_same_selected_face_not_unselected_counterfactual\":true"
    << ",\"decision_time_us_real_HCRAF\":null,\"observer_cost_is_decision_time\":false"
    << ",\"local_NFD_queue_observed_before_send\":" << (instrument?"true":"false")
    << ",\"NFD_dispatch_wall_CPU_measured\":" << (instrument?"true":"false")
    << ",\"NFD_cost_includes_recorder\":true"
    << ",\"remote_queue_online_feature\":false"
    << ",\"path_first_face_is_fib_cost_1\":true"
    << ",\"congestion\":null,\"future_congestion\":null,\"F3_ready\":false,\"training_ready\":false}\n";
  config.flush();
  if (!config) throw std::runtime_error("Cannot write configuration");
  config.close();
  Simulator::Stop(Seconds(20)); Simulator::Run();
  if (instrument) {
    forwarder->hcrafFinish(); forwarder->hcrafSetDecisionObserver({});
    forwarder->hcrafSetDispatchTimingObserver({});
    liveLocalQueue->Finish();nfdDispatchCosts.flush();
    if (!nfdDispatchCosts) throw std::runtime_error("NFD cost log flush failed");
    for (auto& relay : relayForwarders) relay->hcrafFinish();
    linkMonitor->Finish();
    observerCosts.flush();
    if (!observerCosts) throw std::runtime_error("Observer cost flush failure");
  }
  Simulator::Destroy();
  return 0;
}
