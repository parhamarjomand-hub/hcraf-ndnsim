# HCRAF 1AN — ممیزی پیش از Freeze (v0.37.0-preflight)

**این بسته، مرحله 1AN را از نظر ممیزی مقدماتی اجرا می‌کند، اما به‌دلیل اجرا نشدن 1AM خروجی علمی آن عمداً `NO_GO_FREEZE_BLOCKED_1AM` است.**

این بسته کوچک نیاز به ndnSIM یا GPU ندارد. صرفاً روی دو Artifact واقعی کوچک GitHub مراحل 1AK و 1AL کار می‌کند.

### محتوای بسته GitHub و مسیرهای دقیق

| نام فایل در بسته | مسیر در مخزن `hcraf-ndnsim` |
|---|---|
| `hcraf_stage1an_sources.zip` | `hcraf_stage1an_sources.zip` (ریشه) |
| `hcraf_stage1ak_audit_reference.zip` | `hcraf_stage1ak_audit_reference.zip` (ریشه) |
| `hcraf_stage1al_audit_reference.zip` | `hcraf_stage1al_audit_reference.zip` (ریشه) |
| `hcraf-stage1an.yml` | `.github/workflows/hcraf-stage1an.yml` |

سه ZIP را در GitHub استخراج نکنید. Workflowها و فایل‌های قبلی را پاک یا جایگزین نکنید. Workflow جدید: **HCRAF - Stage 1AN Pre-Freeze Gate Audit (NO-GO Until 1AM)**.

### اجرای محلی

```bash
python scripts/prefreeze_1an.py --ak hcraf_stage1ak_audit_reference.zip --al hcraf_stage1al_audit_reference.zip --out reproduced
HCRAF_1AN_AK_PATH=hcraf_stage1ak_audit_reference.zip HCRAF_1AN_AL_PATH=hcraf_stage1al_audit_reference.zip python -m unittest discover -s tests -p 'test_*.py'
```

خروجی‌ها: `readiness_decision.json`, `gate_matrix.json`, `gate_matrix.csv`. تمام سه فایل deterministic هستند و خودشان هیچ داده خام یا برچسب آموزشی نمی‌سازند.

**دقت:** سبز شدن GitHub Actions صرفاً یعنی برنامه ممیزی به‌درستی اجرا شده است؛ به معنای GO برای Freeze نیست. پس از تکمیل واقعی 1AM باید 1AN نهایی مجدداً ممیزی شود.
