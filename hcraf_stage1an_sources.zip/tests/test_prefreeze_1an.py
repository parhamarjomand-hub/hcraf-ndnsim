import io,json,os,sys,tempfile,unittest,zipfile,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import prefreeze_1an as p

class Stage1ANContractTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.ak=Path(os.getenv('HCRAF_1AN_AK_PATH','hcraf_stage1ak_audit_reference.zip')).resolve()
  cls.al=Path(os.getenv('HCRAF_1AN_AL_PATH','hcraf_stage1al_audit_reference.zip')).resolve()
  assert cls.ak.exists() and cls.al.exists(), 'Original 1AK and 1AL reference ZIPs required'
  cls.a=p.verify_artifact(cls.ak,'ak');cls.b=p.verify_artifact(cls.al,'al')
 def test_original_ak_integrity(self):self.assertEqual(self.a['verified_files'],7)
 def test_original_al_integrity(self):self.assertEqual(self.b['verified_files'],6)
 def test_stage_contract(self):self.assertIn('1AN.',p.STAGE)
 def test_ak_scientific_scope(self):self.assertEqual(p.validate_ak(self.a)['complete_path_pressure_groups'],72)
 def test_al_unknown_432(self):self.assertEqual(p.validate_al(self.b)['target_drop_unknown'],432)
 def test_no_ak_online_telemetry(self):self.assertFalse(p.validate_ak(self.a)['remote_online_available'])
 def test_no_al_online_telemetry(self):self.assertFalse(p.validate_al(self.b)['online_telemetry_available'])
 def test_future_label_absent(self):self.assertEqual(p.validate_ak(self.a)['future_labels_produced'],0)
 def test_manifests_not_freeze(self):
  self.assertTrue(p.good_readiness(self.a['manifest']))
  self.assertTrue(p.good_readiness(self.b['manifest']))
 def test_reject_wrong_freeze(self):
  mf=dict(self.a['manifest'],GO_FREEZE=True)
  self.assertFalse(p.good_readiness(mf))
 def test_reject_f3_ready(self):self.assertFalse(p.good_readiness(dict(self.a['manifest'],F3_ready=True)))
 def test_reject_final_label(self):self.assertFalse(p.good_readiness(dict(self.a['manifest'],FutureCongestion=0)))
 def test_reject_missing_label_keys(self):
  v=dict(self.a['manifest']);v.pop('Congestion');self.assertFalse(p.good_readiness(v))
 def test_gate_decision_blocks_freeze(self):
  gates=p.make_gates(p.validate_al(self.b),p.validate_ak(self.a))
  self.assertEqual(len(gates),11)
  self.assertEqual(sum(g['status']=='BLOCKED_MISSING_1AM' for g in gates),7)
  self.assertEqual(len({g['id'] for g in gates}),11)
 def test_run_reproducible(self):
  with tempfile.TemporaryDirectory() as t:
   d1=Path(t)/'first';d2=Path(t)/'second'
   a=p.audit(self.ak,self.al,d1);b=p.audit(self.ak,self.al,d2)
   self.assertEqual(a,b)
   for n in ('readiness_decision.json','gate_matrix.json','gate_matrix.csv'):
    self.assertEqual((d1/n).read_bytes(),(d2/n).read_bytes())
   self.assertEqual(a['decision'],'NO_GO_FREEZE_BLOCKED_1AM')
   self.assertFalse(a['pilot_dataset_generation_authorized'])
 def test_reject_wrong_archive_pin(self):
  with self.assertRaises(p.AuditError):p.verify_artifact(self.ak,'ak','0'*64)
 def test_reject_wrong_stage(self):
  with self.assertRaises(p.AuditError):p.verify_artifact(self.ak,'al')
 def test_reject_corrupt_file_contents(self):
  with tempfile.TemporaryDirectory() as t:
   dest=Path(t)/'corrupt.zip'
   with zipfile.ZipFile(self.ak) as z,zipfile.ZipFile(dest,'w') as out:
    for n in z.namelist():
     d=z.read(n)
     if n=='audit_summary.json':d=d+b'\n'
     out.writestr(n,d)
   with self.assertRaises(p.AuditError):p.verify_artifact(dest,'ak')
 def test_reject_missing_entry(self):
  with tempfile.TemporaryDirectory() as t:
   dest=Path(t)/'missing.zip'
   with zipfile.ZipFile(self.al) as z,zipfile.ZipFile(dest,'w') as out:
    for n in z.namelist():
     if n!='run_scope_72.csv':out.writestr(n,z.read(n))
   with self.assertRaises(p.AuditError):p.verify_artifact(dest,'al')
 def test_reject_added_unhashed_entry(self):
  with tempfile.TemporaryDirectory() as t:
   dest=Path(t)/'extra.zip'
   with zipfile.ZipFile(self.al) as z,zipfile.ZipFile(dest,'w') as out:
    for n in z.namelist():out.writestr(n,z.read(n))
    out.writestr('extra.csv','fake')
   with self.assertRaises(p.AuditError):p.verify_artifact(dest,'al')
 def test_reject_replaced_unknown_with_zero(self):
  from copy import deepcopy
  changed=deepcopy(self.b)
  txt=changed['data']['episode_scope_2160.csv'].decode()
  changed['data']['episode_scope_2160.csv']=txt.replace('UNKNOWN_INCOMPLETE_CLASS_OR_PATH','NO_OBSERVED_COMPETITOR_BLOCKING_COMPLETE_PATH',1).encode()
  with self.assertRaises(p.AuditError):p.validate_al(changed)
 def test_reject_illicit_1ak_final_label(self):
  from copy import deepcopy
  changed=deepcopy(self.a)
  txt=changed['data']['horizon_censoring.csv'].decode()
  changed['data']['horizon_censoring.csv']=txt.replace(',,False,',',1,False,',1).encode()
  with self.assertRaises(p.AuditError):p.validate_ak(changed)
 def test_missing_path_refused(self):
  with self.assertRaises(p.AuditError):p.verify_artifact('/this-path-is-never-present.zip','ak')
 def test_immutable_freeze_flags(self):
  with tempfile.TemporaryDirectory() as t:
   v=p.audit(self.ak,self.al,t)
   self.assertIsNone(v['FutureCongestion']);self.assertIsNone(v['Congestion'])
   self.assertFalse(v['F3_ready']);self.assertFalse(v['training_ready'])
 def test_run_ids_grounded(self):
  v=p.validate_al(self.b)
  self.assertEqual(v['runs'],72)
  self.assertEqual(self.b['manifest']['github_run_id'],'42279387008')

if __name__=='__main__':unittest.main()
