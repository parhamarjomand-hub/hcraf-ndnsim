#!/usr/bin/env python3
"""HCRAF Stage 1AN: offline, fail-closed pre-freeze audit.

Inputs: genuine original 1AK/1AL GitHub audit artifacts. This does NOT claim
validation of the missing 1AM temporal/online feature/label contract.
Only standard Python; no ndnSIM, no network, no fabricated labels or training.
"""
import argparse,csv,hashlib,io,json,zipfile
from collections import Counter
from pathlib import Path

STAGE='1AN.PREFREEZE_GATE_AUDIT.0'
EXPECTED = {
 'ak': {'stage':'1AK.SELECTED_RETURN_PATH_REPLAY.0','status':'PASS_OFFLINE_SELECTED_PATH_RETURN_EVIDENCE_ONLY',
        'output_count':7},
 'al': {'stage':'1AL.CROSS_FACE_SCOPE_AND_UNKNOWN_REPLAY.0','status':'PASS_EXISTING_CROSS_FACE_AND_UNKNOWN_EVIDENCE_ONLY',
        'output_count':6},
}

class AuditError(ValueError):pass

def must(ok, msg):
    if not ok:raise AuditError(msg)

def sha(data):return hashlib.sha256(data).hexdigest()

def safe_csv(data):
    return list(csv.DictReader(io.StringIO(data.decode('utf-8-sig'))))

def good_readiness(m):
    return (all(k in m for k in ('GO_FREEZE','F3_ready','training_ready','Congestion','FutureCongestion'))
        and m.get('GO_FREEZE') is False and m.get('F3_ready') is False
        and m.get('training_ready') is False and m.get('Congestion') is None
        and m.get('FutureCongestion') is None)

def verify_artifact(path, name, expected_sha=None):
    path=Path(path)
    must(path.is_file(),name+': missing artifact')
    binary=path.read_bytes();actual=sha(binary)
    if expected_sha:must(actual==expected_sha,name+': SHA256 archive changed')
    with zipfile.ZipFile(io.BytesIO(binary)) as z:
        must(z.testzip() is None,name+': corrupted ZIP')
        names=z.namelist()
        must(len(names)==len(set(names)),name+': duplicate entries')
        must('manifest.json' in names,name+': no manifest')
        mf=json.loads(z.read('manifest.json'))
        must(mf['stage']==EXPECTED[name]['stage'],name+': wrong stage')
        checks=mf.get('output_sha256')
        must(isinstance(checks,dict) and len(checks)==EXPECTED[name]['output_count'],name+': wrong manifest size')
        must(set(names)-{'manifest.json'}==set(checks),name+': unexpected unverified entries')
        for item,digest in checks.items():
            must(len(digest)==64 and all(c in '0123456789abcdef' for c in digest),name+': malformed SHA digest')
            must(sha(z.read(item))==digest,name+': SHA mismatch '+item)
        must(good_readiness(mf),name+': unexpected Freeze or final label')
        data={key:z.read(key) for key in checks}
    return {'sha256':actual,'manifest':mf,'data':data,'verified_files':len(checks)}

def validate_ak(d):
    mf=d['manifest'];obj=json.loads(d['data']['audit_summary.json'])
    must(obj.get('stage')==mf['stage'] and obj.get('status')==EXPECTED['ak']['status'],'1AK status mismatch')
    must(good_readiness(obj),'1AK source claimed F3 readiness')
    must(obj.get('decision_feature_online_available') is False,'1AK remote online pressure wrongly accessible')
    must(obj.get('original_target_episodes')==252 and obj.get('path_observed_pressure_groups')==72
         and obj.get('node2_M3_positive_groups')==54 and obj.get('horizon_diagnostic_rows')==756,'1AK summary changed')
    rows=safe_csv(d['data']['path_target_evidence.csv']);hz=safe_csv(d['data']['horizon_censoring.csv'])
    must(len(rows)==252 and len(hz)==756,'1AK row count mismatch')
    must(sum(int(r['observed_return_path_pressure']) for r in rows)==72,'1AK physical pressure count differs')
    must(sum(r['node2_M3']=='True' for r in rows)==54,'1AK local M3 differs')
    must(all(r['Congestion']=='' and r['FutureCongestion']=='' and r['F3_ready']=='False'
           and r['training_ready']=='False' and r['online_remote_pressure_available']=='False'
           and r['all_three_hops_bound']=='True' for r in rows),'1AK invalid online/label/censor state')
    must(all(r['future_face_window_label']=='' and r['F3_ready']=='False'
           and r['decision_time_online_pressure']=='' and r['episode_terminal_before_horizon']=='True'
           for r in hz),'1AK early terminal horizon mislabelled')
    must({int(r['horizon_ms']) for r in hz}=={250,1000,2000},'1AK horizon settings changed')
    must(len({(r['arm'],r['rng_run'],r['name'],r['horizon_ms']) for r in hz})==756,'1AK duplicated horizon')
    return dict(source_stage='1AK',runs=obj['monitored_runs'],target_episodes=len(rows),
         complete_path_pressure_groups=72,local_M3_positive_groups=54,
         missed_by_local_M3=18,horizon_rows=len(hz),future_labels_produced=0,
         remote_online_available=False)

def validate_al(d):
    mf=d['manifest'];obj=json.loads(d['data']['summary.json'])
    must(obj.get('stage')==mf['stage'] and obj.get('status')==EXPECTED['al']['status'],'1AL status mismatch')
    must(good_readiness(obj),'1AL source claimed F3 readiness')
    must(obj.get('online_telemetry_available') is False,'1AL claimed online telemetry')
    must(obj.get('monitored_runs')==72 and obj.get('all_episodes')==2160 and obj.get('target_episodes')==1080
         and obj.get('target_unknown_drop')==432 and obj.get('complete_clean_target_paths')==648
         and obj.get('path_pressure_positive_clean_targets')==108,'1AL summary changed')
    e=safe_csv(d['data']['episode_scope_2160.csv']);rs=safe_csv(d['data']['run_scope_72.csv'])
    cov=safe_csv(d['data']['coverage_by_topology_face_regime.csv'])
    must(len(e)==2160 and len(rs)==72 and len(cov)==24,'1AL row counts wrong')
    must(len({(r['topology'],r['face_id'],r['regime'],r['rng_run']) for r in rs})==72,'1AL run duplicates')
    must(len({(r['topology'],r['face_id'],r['regime']) for r in cov})==24,'1AL coverage duplicates')
    must({r['topology'] for r in rs}=={'DEV_CHAIN_A','DEV_CHAIN_B'},'1AL missing topology')
    must({r['face_id'] for r in rs}=={'258','259','260'},'1AL face coverage insufficient')
    must({r['rng_run'] for r in rs}=={'9101','9102','9103'},'1AL rng coverage insufficient')
    must(sum(r['traffic_class']=='TARGET' for r in e)==1080,'1AL TARGET count wrong')
    must(sum(r['traffic_class']=='INDEPENDENT_COMPETITOR' for r in e)==1080,'1AL COMPETITOR count wrong')
    drop=[r for r in e if r['regime']=='LP_INDEPENDENT_COMPETITOR_DROP']
    target_drop=[r for r in drop if r['traffic_class']=='TARGET']
    must(len(drop)==1296 and len(target_drop)==432,'1AL incomplete-regime counts wrong')
    must(all(r['evidence_state']=='UNKNOWN_INCOMPLETE_CLASS_OR_PATH' and
             r['return_path_complete']=='False' and r['future_congestion']=='' for r in drop),
             '1AL DROP unknown converted to zero/one')
    must(all(r['future_congestion']=='' and r['congestion']=='' and
             r['F3_ready']=='False' and r['training_ready']=='False' for r in e),
             '1AL final labels leaked')
    positives=[r for r in e if r['traffic_class']=='TARGET' and r['observed_path_competitor_blocking']=='1']
    must(len(positives)==108,'1AL physical path pressure changed')
    return dict(source_stage='1AL',runs=72,all_episodes=len(e),target_episodes=1080,
        full_clean_target_paths=648,target_drop_unknown=len(target_drop),all_drop_unknown=len(drop),
        clean_target_path_pressure=108,online_telemetry_available=False)

def make_gates(al,ak):
    # A PASS means only the scope actually measured; it NEVER implies F3 label readiness.
    return [
      {'id':'G01','gate':'Provenance: trusted 1AK/1AL SHA/manifest','status':'PASS',
       'evidence':'1AK 7 hashed files; 1AL 6 hashed files; both CRC valid'},
      {'id':'G02','gate':'Cross-face and topology physical/path evidence','status':'PASS_LIMITED_DEV',
       'evidence':'1AL 72 runs, 2 DEV topologies × 3 selected Faces × 4 regimes × 3 RNG'},
      {'id':'G03','gate':'Fail-closed unknown and DROP handling','status':'PASS_LIMITED_DEV',
       'evidence':'1AL 432 target DROP UNKNOWN; no F3 class imputation'},
      {'id':'G04','gate':'Multi-hop observed physical pressure (retrospective)','status':'PASS_LIMITED_DEV',
       'evidence':'1AK 72 target path-positive vs 54 local M3; 1AL 108 path-positive clean targets'},
      {'id':'G05','gate':'t_decision semantics, temporal provenance, cutoffs','status':'BLOCKED_MISSING_1AM',
       'evidence':'No independently validated 1AM temporal contract or snapshot produced'},
      {'id':'G06','gate':'Online-only feature availability (no remote/future leakage)','status':'BLOCKED_MISSING_1AM',
       'evidence':'1AK explicitly remote online unavailable; 1AL online telemetry unavailable'},
      {'id':'G07','gate':'FutureCongestion label definition, horizon Delta, censoring','status':'BLOCKED_MISSING_1AM',
       'evidence':'1AK 756 early-terminated horizon rows, zero valid future labels'},
      {'id':'G08','gate':'theta/Delta/W DEV-only choice, pre-registration, locked split','status':'BLOCKED_MISSING_1AM',
       'evidence':'No verified 1AM choices; no unconsumed Test-ID/Test-OOD evidence'},
      {'id':'G09','gate':'CPU/RAM, monitor and real HCRAF decision/snapshot latency','status':'BLOCKED_MISSING_1AM',
       'evidence':'Offline verifier runtime is not per-decision HCRAF overhead'},
      {'id':'G10','gate':'Identifiability, propensity, selected Face only, MNAR/UNKNOWN','status':'BLOCKED_MISSING_1AM',
       'evidence':'No accepted labelability/selection-bias protocol for final collection'},
      {'id':'G11','gate':'Final independent 1AM audit and F3 freeze authorization','status':'BLOCKED_MISSING_1AM',
       'evidence':'1AM not completed; GO_FREEZE cannot be inferred from 1AK/1AL'},
    ]

def audit(ak,al,out,expected_sha_ak=None,expected_sha_al=None):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    x=verify_artifact(ak,'ak',expected_sha_ak);y=verify_artifact(al,'al',expected_sha_al)
    ax=validate_ak(x);ay=validate_al(y);gates=make_gates(ay,ax)
    for gate in gates:must(gate['status'] in ('PASS','PASS_LIMITED_DEV','BLOCKED_MISSING_1AM'),'Invalid gate state')
    must(any(g['status'].startswith('BLOCKED') for g in gates),'Pre-freeze audit unexpectedly unblocked')
    result={
       'stage':STAGE,'decision':'NO_GO_FREEZE_BLOCKED_1AM',
       'audit_execution_status':'PASS_PREFREEZE_GATE_AUDIT',
       'scientific_acceptance_status':'NOT_READY_FOR_F3_FREEZE',
       'GO_FREEZE':False,'Congestion':None,'FutureCongestion':None,
       'F3_ready':False,'training_ready':False,
       'allowed_next_action':'Complete 1AM and rerun 1AN independent audit',
       'pilot_dataset_generation_authorized':False,'main_224_run_campaign_authorized':False,
       'nsga_iii_or_gate_training_authorized':False,
       'new_ndnsim_simulations':0,'new_training_labels':0,
       'sources':[
            {'stage':'1AK','artifact':'hcraf_stage1ak_audit_reference.zip','sha256':x['sha256'],
             'verified_manifest_files':x['verified_files'],'github_run_id':x['manifest']['github_run_id']},
            {'stage':'1AL','artifact':'hcraf_stage1al_audit_reference.zip','sha256':y['sha256'],
             'verified_manifest_files':y['verified_files'],'github_run_id':y['manifest']['github_run_id']},
       ],
       'observations':{'1AK':ax,'1AL':ay},
       'gate_counts':dict(Counter(g['status'] for g in gates)),
       '1AM_evidence_state':'NOT_PROVIDED_OR_VERIFIED',
       'caveat':'No validated 1AM, no training labels, no online claim, no freeze.'
    }
    (out/'readiness_decision.json').write_text(json.dumps(result,sort_keys=True,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
    (out/'gate_matrix.json').write_text(json.dumps(gates,sort_keys=True,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
    with (out/'gate_matrix.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=('id','gate','status','evidence'));w.writeheader();w.writerows(gates)
    return result

if __name__=='__main__':
    cli=argparse.ArgumentParser()
    cli.add_argument('--ak',required=True,help='Real stage1AK offline audit artifact ZIP')
    cli.add_argument('--al',required=True,help='Real stage1AL cross-face audit artifact ZIP')
    cli.add_argument('--out',default='output')
    cli.add_argument('--expected-sha-ak',default=None)
    cli.add_argument('--expected-sha-al',default=None)
    args=cli.parse_args()
    print(json.dumps(audit(args.ak,args.al,args.out,args.expected_sha_ak,args.expected_sha_al),ensure_ascii=False,indent=2))
