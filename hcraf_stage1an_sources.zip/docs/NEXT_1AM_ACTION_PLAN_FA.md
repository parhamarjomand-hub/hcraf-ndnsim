# الزامات قابل‌آزمایش برای تکمیل 1AM و بازگشت به ممیزی 1AN

1. **تعریف Timestamp:** تعیین `t_decision` به ازای PIT Entry × Face؛ مرز دقیق زمان مشاهده در NFD؛ تضمین monotonic event ordering، Clock source و پایان Snapshot.
2. **ویژگی آنلاین:** فقط queue/Face/Prefix محلی که در زمان تصمیم واقعاً قابل خواندن‌اند. فشار گره ۷ یا ۱ در گره ۲ بدون telemetry زمان‌دار و اندازه‌گیری‌شده Feature آنلاین نیست.
3. **برچسب آفلاین جدا:** قاعده مشخص فشار فیزیکیِ قابل انتساب در بازه `(t_decision,t_decision + Delta]`، مستقل از feature snapshots؛ فقط بر Face انتخاب‌شده و با شواهد معتبر.
4. **سانسور:** پایان زودهنگام Episode، missing fragments/PIT، drop بی‌انتساب، سکوت مانیتور و Face انتخاب‌نشده -> `UNKNOWN` مگر قرارداد مشاهده کامل و اثبات منفی، از پیش تعریف شده باشد.
5. **Δ/θ/W:** دامنه و تصمیم‌های DEVELOPMENT-only پیش‌ثبت شوند؛ هیچ Test-ID/OOD یا داده کمپین اصلی به انتخاب پارامتر نشت نکند.
6. **آزمون‌های منفی:** حذف یک رویداد فیزیکی، تزریق timestamps آینده داخل snapshot، جابه‌جایی Face، جابه‌جایی Name و Nonce، قطع اتصال PIT و برگشت ناقص باید به رد یا UNKNOWN منجر شوند، نه کلاس صفر یا PASS.
7. **هزینه واقعی:** Memory، CPU، latency واقعی Snapshot/Decision و هزینه telemetry اگر وجود دارد در C++/NFD اندازه‌گیری شود؛ زمان Python verification معادل overhead لحظه تصمیم نیست.
8. **قابلیت شناسایی:** سیاست انتخاب Face و propensity حقیقی (اگر استفاده می‌شود)، حدود counterfactual، پوشش labelها و UNKNOWN به‌تفکیک Face/Topol/Regime/RNG ثبت شود.
9. **Freeze checklist:** قرارداد کامل + artifact قابل بازپخش + source SHA-256 + آزمون‌های واحد و رد شواهد دستکاری‌شده + تصمیم کتبی Gate.

فقط بعد از دریافت همه این شواهد، مرحله 1AN می‌تواند دوباره اجرا شود و درباره ورود مشروط به 1AO تصمیم بگیرد. این متن اجرای 1AM محسوب نمی‌شود.
