#!/usr/bin/env python3
"""Prospective P12C immutable schedule and scientific-fence checks."""
import csv
from hashlib import sha256
import io
import json
from pathlib import Path
import unittest

import generate_stage1am_f3_p12_tail_probe_prereg_v05217 as p


class TestP12CPrereg(unittest.TestCase):
    def test_01_old_seeds_never_reused(self):
        self.assertEqual(p.SEEDS, (23501, 23502))
        self.assertFalse(set(p.SEEDS) & {22001, 22002, 23301, 23308, 23401, 23402})
        self.assertEqual(p.PARTITION, 'PILOT_EXCLUDED')

    def test_02_counterbalance_and_sites(self):
        a = p.allocation()
        self.assertEqual(len(a), 6)
        self.assertEqual(sorted(x['selected_slot'] for x in a.values()), [0, 0, 1, 1, 2, 2])
        self.assertEqual(len({x['phase_A_anchor_ns'] for x in a.values()}), 6)
        self.assertEqual(len({x['phase_B_anchor_ns'] for x in a.values()}), 6)

    def test_03_exactly_24_frozen_cases(self):
        rows = p.matrix_rows()
        self.assertEqual(len(rows), 24)
        self.assertEqual(len({(x['seed'], x['site'], x['load'], x['telemetry']) for x in rows}), 24)
        self.assertTrue(all(x['validation_or_heldout'] == 'false' for x in rows))
        self.assertTrue(all(x['competitor_requests'] == 116 for x in rows))

    def test_04_complete_unique_requests(self):
        for seed in p.SEEDS:
            for site in p.SITES:
                for load in p.LOADS:
                    events = p.events(seed, site, load)
                    self.assertEqual(len(events), 128)
                    self.assertEqual(sum(x['traffic_class'] == 'TARGET' for x in events), 12)
                    self.assertEqual(sum(x['traffic_class'] == 'INDEPENDENT_COMPETITOR' for x in events), 116)
                    self.assertEqual(sum(x['phase_label'].endswith('_TAIL_PROBE') for x in events), 20)
                    self.assertEqual(len({(x['traffic_class'], x['sequence']) for x in events}), 128)

    def test_05_true_paired_temporal_controls(self):
        for seed in p.SEEDS:
            for site in p.SITES:
                high = p.events(seed, site, 'high_pressure')
                low = p.events(seed, site, 'low_control')
                key = lambda rows, label: sorted(x['time_ns'] for x in rows if label(x))
                # Identical target times and physical tail probe times in both arms.
                self.assertEqual(key(high, lambda x:x['traffic_class']=='TARGET'),
                                 key(low, lambda x:x['traffic_class']=='TARGET'))
                self.assertEqual(key(high, lambda x:x['phase_label'].endswith('_TAIL_PROBE')),
                                 key(low, lambda x:x['phase_label'].endswith('_TAIL_PROBE')))
                # The 96 core competitors are spread out only in low_control.
                self.assertNotEqual(key(high, lambda x:x['phase_label'] in ('C0', 'C1')),
                                    key(low, lambda x:x['phase_label'] in ('C0', 'C1')))

    def test_06_tail_offsets_precommitted(self):
        a = p.allocation()
        for seed in p.SEEDS:
            for site in p.SITES:
                rows = p.events(seed, site, 'high_pressure')
                for phase, anchor in enumerate((a[seed,site]['phase_A_anchor_ns'],
                                               a[seed,site]['phase_B_anchor_ns'])):
                    trail = [x for x in rows if x['phase_label'] == f'P{phase}_TAIL_PROBE']
                    self.assertEqual(len(trail), 10)
                    expected = [anchor + 47 * 3_600_000 + offset for offset in p.TAIL_OFFSETS_NS]
                    self.assertEqual(sorted(x['phase_nominal_ns'] for x in trail), expected)

    def test_07_immutability_and_per_file_hashes(self):
        commitments = json.loads(p.COMMITMENTS.read_bytes())
        self.assertEqual(sha256(p.MATRIX.read_bytes()).hexdigest(), commitments['matrix_sha256'])
        for filename, digest in commitments['schedule_hashes'].items():
            self.assertEqual(sha256((p.PLANS / filename).read_bytes()).hexdigest(), digest)
        self.assertEqual(commitments['schedule_hashes'], p.commitments()['schedule_hashes'])
        self.assertEqual(p.MATRIX.read_bytes(), p.render_matrix())

    def test_08_parent_digest_and_science_fences(self):
        v = p.commitments()
        self.assertEqual(v['parent_p12b_run'], 44692358819)
        self.assertEqual(v['parent_p12b_artifact_id'], 14610069765)
        self.assertEqual(v['parent_p12b_artifact_sha256'],
                         'b8626f15f2ba295fcaac5c22b953daf5a3d1fcf702102d0ac2413e931da19177')
        self.assertFalse(v['pilot_executor_authorized_now'])
        self.assertEqual(v['new_simulations'], 0)
        self.assertEqual(v['official_F3_labels_constructed'], 0)
        self.assertFalse(v['F3_PR_AUC_computed'])
        self.assertIsNone(v['Congestion'])
        self.assertIsNone(v['FutureCongestion'])
        for name in ('F3_ready', 'GO_FREEZE', 'training_ready', 'heldout_release_authorized'):
            self.assertFalse(v[name])

    def test_09_posthoc_parent_is_not_formal_dataset(self):
        report = json.loads((p.DOC / 'P12C_P12B_FORENSIC_AUDIT.json').read_bytes())
        self.assertEqual(report['scientific_status'],
                         'NO_GO_P12B_PILOT_PHYSICAL_OR_TIME_BIN_FEASIBILITY')
        self.assertEqual(report['transit_nearest_gap_ms'], 88.72)
        self.assertEqual(report['transit_misses_75ms_horizon_by_ms'], 13.72)
        self.assertTrue(report['all_481_original_raw_files_sha256_verified'])
        self.assertEqual(len(report['cases']), 12)
        self.assertEqual(sum(x['positive_75ms'] for x in report['cases']), 86)
        self.assertEqual(sum(x['negative_75ms'] for x in report['cases']), 1210)

    def test_10_invalid_seed_blocked(self):
        with self.assertRaises(AssertionError):
            p.events(23402, 'transit_middle', 'high_pressure')
        with self.assertRaises(AssertionError):
            p.events(23501, 'transit_middle', 'heldout')
        with self.assertRaises(AssertionError):
            p.events(23501, 'unknown_site', 'high_pressure')


if __name__ == '__main__':
    unittest.main()
