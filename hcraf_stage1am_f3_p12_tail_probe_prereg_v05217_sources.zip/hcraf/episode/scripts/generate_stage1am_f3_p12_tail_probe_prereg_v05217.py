#!/usr/bin/env python3
"""P12-C v0.52.17 immutable prospective, excluded-pilot schedule generator.

The fresh seeds and every schedule are committed before ANY P12-D simulation.
P12-B's near-miss can guide this new PILOT ONLY engineering protocol; neither
P12-A nor its parent evidence, diagnostic horizon, or formal partitions change.
"""
from __future__ import annotations

import csv
from hashlib import sha256
import io
import json
from pathlib import Path
import random

VERSION = 'HCRAF-STAGE1AM-F3-P12C-v0.52.17-PROSPECTIVE-TAIL-PROBE'
SCHEMA = 'HCRAF_F3_P12C_TAIL_PROBE_PREREG_V05217'
FAMILY = 'P12C_INDEPENDENT_TAIL_PROBE_PILOT_ONLY'
PARTITION = 'PILOT_EXCLUDED'
SEEDS = (23501, 23502)
SITES = ('producer_egress', 'transit_middle', 'consumer_ingress')
LOADS = ('low_control', 'high_pressure')
TELEMETRIES = ('off', 'on_20ms')
SITE_ARMS = {
    'producer_egress': ('PRODUCER_RETURN_12M', 'PRODUCER_RETURN', 'producer'),
    'transit_middle': ('MID_RETURN_12M', 'MID_RETURN', 'mid'),
    'consumer_ingress': ('RELAY_RETURN_12M', 'RELAY_RETURN', 'relay'),
}
CORE_PER_PULSE = 48
CORE_COMPETITOR = CORE_PER_PULSE * 2
TAIL_OFFSETS_NS = tuple(n * 1_000_000 for n in (20, 35, 50, 65, 80, 95, 110, 125, 140, 155))
TAIL_PER_PULSE = len(TAIL_OFFSETS_NS)
TOTAL_COMPETITOR = CORE_COMPETITOR + 2 * TAIL_PER_PULSE
TOTAL_TARGET = 12
TOTAL_EVENTS = TOTAL_TARGET + TOTAL_COMPETITOR
CSV_HEADER = ('traffic_class', 'sequence', 'time_ns', 'family', 'rng_block',
              'split', 'phase_label', 'phase_nominal_ns', 'phase_jitter_ns',
              'selected_slot', 'load_level', 'schedule_schema')
MATRIX_HEADER = ('seed', 'site', 'selected_slot', 'temporal_anchor_A_ns',
                 'temporal_anchor_B_ns', 'arm', 'location', 'target_role',
                 'load', 'telemetry', 'schedule_filename', 'schedule_sha256',
                 'target_requests', 'competitor_requests',
                 'tail_probe_requests_per_pulse', 'candidate_queue_capacity_packets',
                 'scientific_partition', 'validation_or_heldout')

ROOT = Path(__file__).resolve().parents[3]
DOC = ROOT / 'hcraf/episode/docs/1AM/F3_P12_TAIL_PROBE_PREREG_v0.52.17'
PLANS = DOC / 'plans'
MATRIX = DOC / 'P12C_PILOT_LOCKED_MATRIX_24_v05217.csv'
COMMITMENTS = DOC / 'P12C_PILOT_SCHEDULE_COMMITMENTS_12_v05217.json'


def require(cond: bool, code: str) -> None:
    if not cond:
        raise AssertionError('P12C_' + code)


def stream_seed(label: str) -> int:
    n = int.from_bytes(sha256((VERSION + ':' + label).encode()).digest()[:8], 'big')
    return n or 1


def allocation() -> dict[tuple[int, str], dict]:
    """Two independently permuted Latin anchor grids; never read future drops."""
    grid_a = [2_190_000_000 + k * 210_000_000 for k in range(6)]
    grid_b = [4_350_000_000 + k * 250_000_000 for k in range(6)]
    random.Random(stream_seed('PHASE_A_INDEPENDENT_PERMUTATION')).shuffle(grid_a)
    random.Random(stream_seed('PHASE_B_INDEPENDENT_PERMUTATION')).shuffle(grid_b)
    result = {}
    for i, (seed, site) in enumerate((s, p) for s in SEEDS for p in SITES):
        label = f'{seed}:{site}'
        jitter_a = random.Random(stream_seed(label + ':A')).randint(-8_000_000, 8_000_000)
        jitter_b = random.Random(stream_seed(label + ':B')).randint(-8_000_000, 8_000_000)
        result[seed, site] = {
            'selected_slot': (SITES.index(site) + SEEDS.index(seed)) % 3,
            'phase_A_anchor_ns': grid_a[i] + jitter_a,
            'phase_B_anchor_ns': grid_b[i] + jitter_b,
            'traffic_stream_seed': stream_seed(label + ':traffic') & 0x7fffffff,
            'routing_stream_seed': stream_seed(label + ':routing') & 0x7fffffff,
            'telemetry_stream_seed': stream_seed(label + ':telemetry') & 0x7fffffff,
        }
    require(len(result) == 6, 'SIX_CELLS')
    require(len({x['phase_A_anchor_ns']//100_000_000 for x in result.values()}) == 6,
            'ANCHOR_A_NOT_COUNTERBALANCED')
    require(len({x['phase_B_anchor_ns']//100_000_000 for x in result.values()}) == 6,
            'ANCHOR_B_NOT_COUNTERBALANCED')
    require(all(x['phase_B_anchor_ns'] > x['phase_A_anchor_ns'] + 900_000_000
                for x in result.values()), 'PULSES_OVERLAP')
    return result


def filename(seed: int, site: str, load: str) -> str:
    slot = allocation()[seed, site]['selected_slot']
    return f'p12c-v05217-pilot-seed-{seed}-{site}-slot-{slot}-{load}.csv'


def events(seed: int, site: str, load: str) -> list[dict]:
    require(seed in SEEDS and site in SITES and load in LOADS, 'FOREIGN_OR_FORMAL_SEED')
    a = allocation()[seed, site]
    label = f'{seed}:{site}'
    target_rng = random.Random(stream_seed(label + ':TARGET_JITTER_PAIRED'))
    core_rng = random.Random(stream_seed(label + ':CORE_JITTER:' + load))
    tail_rng = random.Random(stream_seed(label + ':TAIL_JITTER_PAIRED'))
    out: list[dict] = []

    def add(kind: str, seq: int, nominal: int, jitter: int, phase: str):
        out.append(dict(traffic_class=kind, sequence=seq, time_ns=nominal + jitter,
                        family=FAMILY, rng_block=seed, split=PARTITION,
                        phase_label=phase, phase_nominal_ns=nominal,
                        phase_jitter_ns=jitter, selected_slot=a['selected_slot'],
                        load_level=load, schedule_schema=SCHEMA))

    for seq in range(TOTAL_TARGET):
        add('TARGET', seq, 2_260_000_000 + 330_000_000 * seq,
            target_rng.randint(-280_000, 280_000), f'T{seq//3}')

    for seq in range(CORE_COMPETITOR):
        if load == 'low_control':
            nominal = 2_170_000_000 + seq * 163_000_000
        else:
            anchor = a['phase_A_anchor_ns'] if seq < CORE_PER_PULSE else a['phase_B_anchor_ns']
            nominal = anchor + (seq % CORE_PER_PULSE) * 3_600_000
        add('INDEPENDENT_COMPETITOR', seq, nominal,
            core_rng.randint(-180_000, 180_000), f'C{seq//CORE_PER_PULSE}')

    # Extra *real* PIT×Face episodes are generated, never synthetic features.
    # In both high and low arms their sent times are paired at each anchor.
    # Timing is set BEFORE the new seed 23501/23502 physical observations exist.
    seq = CORE_COMPETITOR
    for pulse, anchor in enumerate((a['phase_A_anchor_ns'], a['phase_B_anchor_ns'])):
        core_last_nominal = anchor + (CORE_PER_PULSE - 1) * 3_600_000
        for offset in TAIL_OFFSETS_NS:
            add('INDEPENDENT_COMPETITOR', seq, core_last_nominal + offset,
                tail_rng.randint(-150_000, 150_000), f'P{pulse}_TAIL_PROBE')
            seq += 1

    out.sort(key=lambda r: (r['time_ns'], r['traffic_class'], r['sequence']))
    require(len(out) == TOTAL_EVENTS and
            len({(e['traffic_class'], e['sequence']) for e in out}) == TOTAL_EVENTS,
            'REQUEST_COUNT_OR_DUPLICATE')
    require(all(2_000_000_000 < x['time_ns'] < 19_000_000_000 for x in out),
            'TIME_OUTSIDE_SIMULATION')
    require(len([x for x in out if x['phase_label'].endswith('_TAIL_PROBE')]) == 20,
            'MISSING_TAIL_PROBES')
    return out


def render_schedule(seed: int, site: str, load: str) -> bytes:
    stream = io.StringIO(newline='')
    w = csv.DictWriter(stream, fieldnames=CSV_HEADER, lineterminator='\n')
    w.writeheader()
    w.writerows(events(seed, site, load))
    return stream.getvalue().encode()


def matrix_rows() -> list[dict]:
    allocated = allocation()
    rows = []
    for seed in SEEDS:
        for site in SITES:
            a = allocated[seed, site]
            arm, location, role = SITE_ARMS[site]
            for load in LOADS:
                name = filename(seed, site, load)
                schedule_sha = sha256(render_schedule(seed, site, load)).hexdigest()
                for telemetry in TELEMETRIES:
                    rows.append(dict(seed=seed, site=site, selected_slot=a['selected_slot'],
                        temporal_anchor_A_ns=a['phase_A_anchor_ns'],
                        temporal_anchor_B_ns=a['phase_B_anchor_ns'], arm=arm,
                        location=location, target_role=role, load=load,
                        telemetry=telemetry, schedule_filename=name,
                        schedule_sha256=schedule_sha, target_requests=TOTAL_TARGET,
                        competitor_requests=TOTAL_COMPETITOR,
                        tail_probe_requests_per_pulse=TAIL_PER_PULSE,
                        candidate_queue_capacity_packets=12,
                        scientific_partition=PARTITION, validation_or_heldout='false'))
    require(len(rows) == 24, 'NOT_24_LOCKED_CASES')
    return rows


def render_matrix() -> bytes:
    stream = io.StringIO(newline='')
    w = csv.DictWriter(stream, fieldnames=MATRIX_HEADER, lineterminator='\n')
    w.writeheader()
    w.writerows(matrix_rows())
    return stream.getvalue().encode()


def commitments() -> dict:
    hashes = {filename(seed, site, load): sha256(render_schedule(seed, site, load)).hexdigest()
              for seed in SEEDS for site in SITES for load in LOADS}
    require(len(hashes) == 12, 'NOT_12_SCHEDULE_COMMITMENTS')
    return {
        'stage': 'v0.52.17_P12_C_PROSPECTIVE_TAIL_PROBE_PREREG_ONLY',
        'parent_p12b_run': 44692358819,
        'parent_p12b_commit': '07ae01f773b1273faddad96aa260bd0052994f6a',
        'parent_p12b_artifact_id': 14610069765,
        'parent_p12b_artifact_sha256': 'b8626f15f2ba295fcaac5c22b953daf5a3d1fcf702102d0ac2413e931da19177',
        'parent_p12b_status': 'NO_GO_P12B_PILOT_PHYSICAL_OR_TIME_BIN_FEASIBILITY',
        'parent_p12a_run': 44688603269,
        'parent_p12a_schedule_SHA256_unchanged': True,
        'previous_pilot_seed_23401_23402_not_reused': True,
        'pilot_only_seed_blocks': list(SEEDS),
        'proposed_pilot_simulations': 24,
        'new_simulations': 0,
        'executed_new_simulations': 0,
        'pilot_executor_authorized_now': False,
        'p12b_75ms_horizon_unchanged': True,
        'p12b_raw_immutable': True,
        'no_historical_relabeling': True,
        'time_counterbalance': 'INDEPENDENT_TWO_ANCHOR_LATIN_PERMUTATIONS',
        'pilot_tail_sent_offsets_ms': [n // 1_000_000 for n in TAIL_OFFSETS_NS],
        'per_pulse_core_competitors': CORE_PER_PULSE,
        'per_pulse_independent_tail_probes': TAIL_PER_PULSE,
        'total_competitor_requests': TOTAL_COMPETITOR,
        'total_target_requests': TOTAL_TARGET,
        'per_case_expected_forwarding_episodes': TOTAL_EVENTS,
        'two_class_and_within_100ms_gates': 'AGGREGATED_PER_SITE_OVER_BOTH_NEW_SEEDS_PRE_REGISTERED',
        'observed_scientific_fraction_before_execution': None,
        'schedule_hashes': hashes,
        'matrix_sha256': sha256(render_matrix()).hexdigest(),
        'validation_runs': 0,
        'heldout_runs': 0,
        'official_F3_labels_constructed': 0,
        'F3_PR_AUC_computed': False,
        'Congestion': None,
        'FutureCongestion': None,
        'F3_ready': False,
        'GO_FREEZE': False,
        'training_ready': False,
        'heldout_release_authorized': False,
    }


def write_immutable(p: Path, blob: bytes) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.exists():
        require(p.read_bytes() == blob, 'REFUSE_OVERWRITE_COMMITTED_' + p.name)
    else:
        p.write_bytes(blob)


def main() -> None:
    for seed in SEEDS:
        for site in SITES:
            for load in LOADS:
                write_immutable(PLANS / filename(seed, site, load),
                                render_schedule(seed, site, load))
    write_immutable(MATRIX, render_matrix())
    write_immutable(COMMITMENTS,
                    (json.dumps(commitments(), indent=2, sort_keys=True) + '\n').encode())
    print('PASS_P12C_12_IMMUTABLE_SCHEDULES_24_FUTURE_CASES_ZERO_SIMULATIONS')


if __name__ == '__main__':
    main()
