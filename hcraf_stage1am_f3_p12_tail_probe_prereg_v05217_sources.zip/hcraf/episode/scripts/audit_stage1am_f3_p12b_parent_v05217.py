#!/usr/bin/env python3
"""Verify actual P12-B GitHub artifact, without simulating or modifying it.

Per-file hashes, physical witness and retrospective labels are independently
checked. This is a post-hoc engineering diagnosis, NEVER F3 model training.
"""
from __future__ import annotations

import argparse
from hashlib import sha256
import io
import json
from pathlib import Path
import zipfile

EXPECTED_ARTIFACT_SHA = 'b8626f15f2ba295fcaac5c22b953daf5a3d1fcf702102d0ac2413e931da19177'
EXPECTED_RAW_SHA = 'ef732e323f03d64bf71fe1071bcedcb74d13c89c25a3c9f478c87316274a5294'
EXPECTED_STATUS = 'NO_GO_P12B_PILOT_PHYSICAL_OR_TIME_BIN_FEASIBILITY'
ROOT = 'stage1am_f3_p12_pilot_v05216/'
RAW_NAME = 'P12B_PILOT_RAW_SEED_23401.zip'


def sha(blob: bytes) -> str:
    return sha256(blob).hexdigest()


def check(ok: bool, code: str) -> None:
    if not ok:
        raise AssertionError('P12C_PARENT_FORENSIC_' + code)


def read_lines(blob: bytes) -> list[dict]:
    return [json.loads(line) for line in blob.splitlines() if line.strip()]


def audit_artifact(path: Path) -> dict:
    blob = path.read_bytes()
    check(sha(blob) == EXPECTED_ARTIFACT_SHA, 'ARTIFACT_SHA256_MISMATCH')
    with zipfile.ZipFile(io.BytesIO(blob)) as parent:
        check(parent.testzip() is None, 'PARENT_CRC')
        files = parent.namelist()
        check(len(files) == len(set(files)), 'DUPLICATE_PARENT_MEMBERS')
        report = json.loads(parent.read(ROOT + 'P12B_PILOT_FEASIBILITY_SUMMARY.json'))
        check(report['status'] == EXPECTED_STATUS, 'NO_GO_STATUS_CHANGED')
        check(report['completed_simulations'] == 12 and
              report['planned_simulations'] == 24, 'STOP_RULE_CHANGED')
        check(report['selected_face_forwarding_episodes'] == 1296, 'EPISODES_CHANGED')
        check(report['total_positive_75ms'] == 86 and
              report['total_negative_75ms'] == 1210, 'LABEL_COUNTS_CHANGED')
        check(report['validation_runs'] == report['heldout_runs'] == 0, 'HELDOUT_USED')
        check(report['official_F3_labels_constructed'] == 0 and
              report['F3_PR_AUC_computed'] is False, 'OFFICIAL_SCORE_CREATED')
        for key in ('F3_ready','GO_FREEZE','training_ready','heldout_release_authorized'):
            check(report[key] is False, 'PREMATURE_LOCK_' + key)
        check(report['Congestion'] is None and report['FutureCongestion'] is None,
              'PREMATURE_CONSTRUCT')

        sums = parent.read(ROOT + 'P12B_OUTPUT_SHA256SUMS.txt').decode()
        lines = sums.strip().splitlines()
        check(len(lines) == 5, 'PARENT_SHA_MEMBER_COUNT')
        for line in lines:
            expected, name = line.split('  ')
            check(sha(parent.read(ROOT + name)) == expected, 'PARENT_FILE_SHA_' + name)
        raw_blob = parent.read(ROOT + RAW_NAME)
        check(sha(raw_blob) == EXPECTED_RAW_SHA, 'INNER_RAW_SHA')
        check(report['seed_archives'][0]['sha256'] == EXPECTED_RAW_SHA,
              'SUMMARY_RAW_SHA_CHANGED')
        features = read_lines(parent.read(ROOT + 'P12B_PILOT_FEATURES_ONLY_v05216.jsonl'))
        labels = read_lines(parent.read(ROOT + 'P12B_PILOT_DIAGNOSTIC_FUTURE_ONLY_v05216.jsonl'))
        check(len(features) == len(labels) == 1296, 'FEATURE_LABEL_COUNT')
        label_map = {x['row_key']: x for x in labels}
        check(len(label_map) == len(labels), 'NON_UNIQUE_LABEL_KEY')
        for f in features:
            check(set(f) == {'allowed_decision_time_features','metadata_NOT_A_PREDICTOR'},
                  'LEAKAGE_FEATURE_SCHEMA')
            check('retrospective_future_selected_path_QUEUE_DROP_75ms'
                  not in f['allowed_decision_time_features'], 'FUTURE_LEAKED_TO_FEATURE')
            check(f['metadata_NOT_A_PREDICTOR']['row_key'] in label_map, 'MISSING_LABEL_JOIN')

        with zipfile.ZipFile(io.BytesIO(raw_blob)) as raw:
            check(raw.testzip() is None, 'INNER_RAW_CRC')
            raw_manifest = json.loads(raw.read('P12B_PILOT_RAW_FILE_SHA256.json'))
            actual_files = set(raw.namelist()) - {'P12B_PILOT_RAW_FILE_SHA256.json'}
            check(len(raw_manifest) == 481 and set(raw_manifest) == actual_files,
                  'RAW_FILE_COUNT_OR_NAMES')
            for name, expected in raw_manifest.items():
                check(sha(raw.read(name)) == expected, 'RAW_FILE_SHA_' + name)

            cases = []
            for outcome in report['results']:
                seed = outcome['seed']
                site, load, telemetry = (outcome[k] for k in ('site', 'load', 'telemetry'))
                check(seed == 23401 and outcome['scientific_partition'] == 'PILOT_EXCLUDED',
                      'UNKNOWN_SEED_OR_SPLIT')
                path_prefix = f'{site}/{load}/{telemetry}/'
                witness = read_lines(raw.read(path_prefix + 'pathwide_witness_b.jsonl'))
                role = outcome['physical']['target_role']
                node = outcome['physical']['selected_role_sender_node_ids'][role]
                target_drops = sorted(x['timestamp_ns'] for x in witness
                    if x['event_type'] == 'QUEUE_DROP' and x['node_id'] == node
                    and x['device_index'] == 0)
                check(len(target_drops) == outcome['physical']['physical_drops_by_role'][role],
                      'PHYSICAL_DROP_COUNT_' + site)
                selected = [x['metadata_NOT_A_PREDICTOR'] for x in features
                    if x['metadata_NOT_A_PREDICTOR']['site'] == site
                    and x['metadata_NOT_A_PREDICTOR']['load'] == load
                    and x['metadata_NOT_A_PREDICTOR']['telemetry'] == telemetry]
                check(len(selected) == outcome['decisions'] == 108, 'CASE_DECISIONS')
                positives = 0
                nearest_gaps = []
                for decision in selected:
                    t = decision['decision_ns']
                    future = sum(t < dt <= t + 75_000_000 for dt in target_drops)
                    label = label_map[decision['row_key']]
                    check(label['retrospective_future_drop_event_count'] == future,
                          'FUTURE_EVENT_REPLAY_' + decision['row_key'])
                    check(label['retrospective_future_selected_path_QUEUE_DROP_75ms'] == int(future > 0),
                          'FUTURE_BINARY_REPLAY_' + decision['row_key'])
                    positives += int(future > 0)
                for t in set(target_drops):
                    earlier = [x['decision_ns'] for x in selected if x['decision_ns'] < t]
                    if earlier:
                        nearest_gaps.append(t - max(earlier))
                check(positives == outcome['diagnostic']['positive_75ms'],
                      'POSITIVE_COUNT_REPLAY_' + site)
                cases.append({
                    'site': site, 'load': load, 'telemetry': telemetry,
                    'real_target_QUEUE_DROP_count': len(target_drops),
                    'distinct_real_drop_times_ns': sorted(set(target_drops)),
                    'nearest_pre_drop_decision_gap_ns': min(nearest_gaps) if nearest_gaps else None,
                    'positive_75ms': positives,
                    'negative_75ms': len(selected) - positives,
                    'within_100ms_same_bin_pos_neg_pairs': outcome['within_100ms']['matched_pos_neg_pairs_same_100ms'],
                })

        transit = next(x for x in cases if x['site'] == 'transit_middle'
                       and x['load'] == 'high_pressure' and x['telemetry'] == 'on_20ms')
        check(transit['nearest_pre_drop_decision_gap_ns'] == 88_720_000,
              'TRANSIT_GAP_EXPECTED_TO_BE_RECALCULATED')
        check(transit['positive_75ms'] == 0 and transit['real_target_QUEUE_DROP_count'] == 2,
              'TRANSIT_NEAR_MISS_REPLAY_CHANGED')
        return {
            'stage': 'v0.52.17_P12C_OFFLINE_PARENT_DIAGNOSTIC_NO_NEW_SIMULATION',
            'parent_p12b_github_run': 44692358819,
            'parent_p12b_commit': '07ae01f773b1273faddad96aa260bd0052994f6a',
            'parent_artifact_sha256': EXPECTED_ARTIFACT_SHA,
            'parent_raw_seed_sha256': EXPECTED_RAW_SHA,
            'all_481_original_raw_files_sha256_verified': True,
            'recomputed_1296_observational_labels_exact': True,
            'original_75ms_horizon_unchanged': True,
            'transit_nearest_gap_ms': 88.72,
            'transit_misses_75ms_horizon_by_ms': 13.72,
            'causal_features_and_future_labels_separated': True,
            'scientific_status': EXPECTED_STATUS,
            'cases': cases,
            'future_pilot_experiment_changes_old_frozen_p12a': False,
            'official_predictability_conclusion': 'NOT_DEMONSTRATED',
        }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('artifact', type=Path)
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    report = audit_artifact(args.artifact)
    blob = (json.dumps(report, indent=2, sort_keys=True) + '\n').encode()
    args.report.parent.mkdir(parents=True, exist_ok=True)
    if args.report.exists():
        check(args.report.read_bytes() == blob, 'IMMUTABLE_REPORT_MISMATCH')
    else:
        args.report.write_bytes(blob)
    print('PASS_P12C_REPLAY_PARENT_SHA_481_RAW_SHA_1296_PILOT_DIAGNOSTIC_LABELS')


if __name__ == '__main__':
    main()
