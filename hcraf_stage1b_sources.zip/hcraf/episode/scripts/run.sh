#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK_DIR="$PROJECT_DIR/hcraf/episode"
OUTPUT_DIR="$PROJECT_DIR/episode_output"
cd "$PROJECT_DIR/episode_sources/ns-3"
# Identical simulation seed/run on both repetitions. Repetitions test byte
# reproducibility, NOT independent statistical replicates.
for mode in success nack timeout cancel retransmit open; do
  for repetition in 1 2; do
    folder="$OUTPUT_DIR/$mode/repeat-$repetition"
    mkdir -p "$folder"
    command="hcraf-episode-pilot --mode=$mode --output=$folder --seed=1 --run=1"
    printf '%s\n' "python3 ./waf --run-no-build '$command'" > "$folder/command.txt"
    python3 ./waf --run-no-build "$command" 2>&1 | tee "$folder/simulator.log"
    python3 "$TASK_DIR/scripts/episodes.py" "$folder" --run-id "$mode-seed1-run1"
    python3 "$TASK_DIR/scripts/verify_pilot.py" "$folder"
    python3 "$TASK_DIR/scripts/verify_decisions.py" "$folder"
  done
done
python3 "$TASK_DIR/scripts/compare_runs.py" "$OUTPUT_DIR"
