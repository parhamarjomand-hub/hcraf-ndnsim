// Controlled ndnSIM integration tests, NOT an HCRAF performance experiment.
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/ndnSIM-module.h"
#include "ns3/ndnSIM/apps/ndn-app.hpp"
#include "ns3/ndnSIM/model/ndn-l3-protocol.hpp"
#include "ns3/ndnSIM/NFD/daemon/fw/forwarder.hpp"
#include <fstream>
#include "hcraf-link-monitor.hpp"
#include <set>
#include <stdexcept>

namespace ns3 {
class HcrafRequester : public ns3::ndn::App {
public:
  static TypeId GetTypeId() {
    static TypeId tid = TypeId("ns3::HcrafRequester").SetParent<ns3::ndn::App>()
      .AddConstructor<HcrafRequester>();
    return tid;
  }
  void Configure(const std::string& mode, const std::string& output) {
    m_mode = mode;
    m_out.open(output);
    if (!m_out) throw std::runtime_error("Cannot open consumer event file");
  }
  void OnData(std::shared_ptr<const ::ndn::Data> data) override {
    ns3::ndn::App::OnData(data);
    m_out << "{\"event\":\"DATA\",\"time_ns\":" << Simulator::Now().GetNanoSeconds()
          << ",\"name\":" << hcraf::Recorder::quote(data->getName().toUri())
          << ",\"payload_bytes\":" << data->getContent().value_size() << "}\n";
    m_out.flush();
  }
  void OnNack(std::shared_ptr<const ::ndn::lp::Nack> nack) override {
    ns3::ndn::App::OnNack(nack);
    m_out << "{\"event\":\"NACK\",\"time_ns\":" << Simulator::Now().GetNanoSeconds()
          << ",\"name\":" << hcraf::Recorder::quote(nack->getInterest().getName().toUri())
          << ",\"reason\":" << static_cast<int>(nack->getReason()) << "}\n";
    m_out.flush();
  }
protected:
  void StartApplication() override {
    ns3::ndn::App::StartApplication();
    if (m_mode == "open") Simulator::Schedule(Seconds(5.9), &HcrafRequester::Send, this, 0u);
    else {
      Simulator::Schedule(Seconds(1), &HcrafRequester::Send, this, 0u);
      Simulator::Schedule(Seconds(2.5), &HcrafRequester::Send, this, 1u);
      Simulator::Schedule(Seconds(4), &HcrafRequester::Send, this, 2u);
      if (m_mode == "retransmit") {
        Simulator::Schedule(Seconds(1.1), &HcrafRequester::Send, this, 0u);
        Simulator::Schedule(Seconds(2.6), &HcrafRequester::Send, this, 1u);
        Simulator::Schedule(Seconds(4.1), &HcrafRequester::Send, this, 2u);
      }
    }
  }
private:
  void Send(uint32_t sequence) {
    if (!m_active) return;
    auto interest = std::make_shared<::ndn::Interest>(::ndn::Name("/hcraf/pilot/" + std::to_string(sequence)));
    interest->setNonce(++m_nonce);
    interest->setInterestLifetime(::ndn::time::milliseconds(1000));
    interest->setCanBePrefix(false);
    interest->setMustBeFresh(true);
    m_out << "{\"event\":\"SEND\",\"time_ns\":" << Simulator::Now().GetNanoSeconds()
          << ",\"name\":" << hcraf::Recorder::quote(interest->getName().toUri())
          << ",\"nonce\":" << m_nonce << "}\n";
    m_out.flush();
    m_transmittedInterests(interest, this, m_face);
    m_appLink->onReceiveInterest(*interest);
  }
  uint32_t m_nonce = 1000;
  std::string m_mode;
  std::ofstream m_out;
};
NS_OBJECT_ENSURE_REGISTERED(HcrafRequester);

class HcrafResponder : public ns3::ndn::App {
public:
  static TypeId GetTypeId() {
    static TypeId tid = TypeId("ns3::HcrafResponder").SetParent<ns3::ndn::App>()
      .AddConstructor<HcrafResponder>();
    return tid;
  }
  void Configure(bool silent, double delay) { m_silent = silent; m_delay = delay; }
  void OnInterest(std::shared_ptr<const ::ndn::Interest> interest) override {
    ns3::ndn::App::OnInterest(interest);
    if (!m_active || m_silent) return;
    Simulator::Schedule(Seconds(m_delay), &HcrafResponder::Reply, this, interest->getName());
  }
protected:
  void StartApplication() override {
    ns3::ndn::App::StartApplication();
    ns3::ndn::FibHelper::AddRoute(GetNode(), "/hcraf", m_face, 0);
  }
private:
  void Reply(::ndn::Name name) {
    if (!m_active) return;
    auto data = std::make_shared<::ndn::Data>(name);
    data->setFreshnessPeriod(::ndn::time::milliseconds(1000));
    data->setContent(std::make_shared<::ndn::Buffer>(1024));
    // Same simulation signature convention as the official ndnSIM Producer.
    ::ndn::SignatureInfo signature(static_cast<::ndn::tlv::SignatureTypeValue>(255));
    data->setSignatureInfo(signature);
    ::ndn::EncodingEstimator estimator;
    ::ndn::EncodingBuffer encoder(estimator.appendVarNumber(0), 0);
    encoder.appendVarNumber(0);
    data->setSignatureValue(encoder.getBuffer());
    data->wireEncode();
    m_transmittedDatas(data, this, m_face);
    m_appLink->onReceiveData(*data);
  }
  bool m_silent = false;
  double m_delay = 0;
};
NS_OBJECT_ENSURE_REGISTERED(HcrafResponder);
}

int main(int argc, char* argv[]) {
  using namespace ns3;
  std::string mode = "success", output = ".";
  uint32_t seed = 1;
  uint64_t run = 1;
  CommandLine cmd;
  cmd.AddValue("mode", "success/nack/timeout/cancel/retransmit/open", mode);
  cmd.AddValue("output", "Existing output directory", output);
  cmd.AddValue("seed", "ns-3 random seed", seed);
  cmd.AddValue("run", "ns-3 random run number", run);
  cmd.Parse(argc, argv);
  const std::set<std::string> modes = {"success", "nack", "timeout", "cancel", "retransmit", "open"};
  if (!modes.count(mode)) throw std::runtime_error("Unknown test mode");
  RngSeedManager::SetSeed(seed);
  RngSeedManager::SetRun(run);
  NodeContainer nodes;
  nodes.Create(4);
  PointToPointHelper link;
  link.SetDeviceAttribute("DataRate", StringValue("10Mbps"));
  link.SetChannelAttribute("Delay", StringValue("10ms"));
  link.Install(nodes.Get(0), nodes.Get(1));
  link.Install(nodes.Get(1), nodes.Get(2));
  link.SetChannelAttribute("Delay", StringValue("30ms"));
  link.Install(nodes.Get(1), nodes.Get(3));
  ns3::ndn::StackHelper stack;
  stack.setCsSize(0);
  stack.InstallAll();
  ns3::ndn::StrategyChoiceHelper::InstallAll("/hcraf", "/localhost/nfd/strategy/best-route");
  if (mode == "cancel")
    ns3::ndn::StrategyChoiceHelper::Install(nodes.Get(1), "/hcraf", "/localhost/nfd/strategy/multicast");
  ns3::ndn::FibHelper::AddRoute(nodes.Get(0), "/hcraf", nodes.Get(1), 1);
  ns3::ndn::FibHelper::AddRoute(nodes.Get(1), "/hcraf", nodes.Get(2), 1);
  if (mode == "cancel") ns3::ndn::FibHelper::AddRoute(nodes.Get(1), "/hcraf", nodes.Get(3), 1);
  if (mode != "nack") {
    auto responder = CreateObject<HcrafResponder>();
    responder->Configure(mode == "timeout" || mode == "open", mode == "retransmit" ? 0.3 : 0.0);
    nodes.Get(2)->AddApplication(responder);
    responder->SetStartTime(Seconds(0));
  }
  if (mode == "cancel") {
    auto responder = CreateObject<HcrafResponder>();
    responder->Configure(false, 0.0);
    nodes.Get(3)->AddApplication(responder);
    responder->SetStartTime(Seconds(0));
  }
  auto requester = CreateObject<HcrafRequester>();
  requester->Configure(mode, output + "/consumer_events.jsonl");
  nodes.Get(0)->AddApplication(requester);
  requester->SetStartTime(Seconds(0));
  auto forwarder = nodes.Get(1)->GetObject<ns3::ndn::L3Protocol>()->getForwarder();
  forwarder->hcrafEnable(output + "/events.jsonl", nodes.Get(1)->GetId());
  HcrafLinkMonitor linkMonitor(nodes, output + "/link_events.jsonl");
  forwarder->hcrafSetDecisionObserver([&linkMonitor](uint64_t id) { linkMonitor.Snapshot(id); });
  std::ofstream config(output + "/scenario.json");
  if (!config) throw std::runtime_error("Cannot write scenario.json");
  config << "{\"mode\":" << hcraf::Recorder::quote(mode)
         << ",\"seed\":" << seed << ",\"run\":" << run
         << ",\"stop_ns\":6000000000,\"warmup_ns\":0,\"observed_node\":1,"
         << "\"purpose\":\"INSTRUMENTATION_TEST_NOT_PERFORMANCE_DATASET\","
         << "\"cs_packets\":0,\"interest_lifetime_ms\":1000,\"payload_bytes\":1024,"
         << "\"links\":[[0,1,10],[1,2,10],[1,3,30]],\"link_delay_unit\":\"ms\","
         << "\"link_rate_bps\":10000000,\"signature_validation\":false}\n";
  config.close();
  Simulator::Stop(Seconds(6));
  Simulator::Run();
  forwarder->hcrafFinish();
  forwarder->hcrafSetDecisionObserver({});
  linkMonitor.Finish();
  Simulator::Destroy();
  return 0;
}
