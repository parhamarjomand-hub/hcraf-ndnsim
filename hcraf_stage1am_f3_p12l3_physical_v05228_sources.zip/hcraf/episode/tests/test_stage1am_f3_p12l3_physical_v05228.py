import importlib.util,sys,unittest
from pathlib import Path
HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'scripts'))
import run_stage1am_f3_p12l3_physical_v05228 as p
import generate_stage1am_f3_p12k_prereg_v05225 as k

class F3P12L3(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rows=p.plan(24813)
        cls.cpp=(HERE/'src/hcraf-stage1am-f3-p12l3-physical-v05228.cpp').read_text()
    def test_exact_six_seed_blocks(self):self.assertEqual(p.SEEDS,tuple(range(24813,24819)))
    def test_first_seed_twelve_cases(self):self.assertEqual(len(self.rows),12)
    def test_final_seed_twelve_cases(self):self.assertEqual(len(p.plan(24818)),12)
    def test_refuse_old_dev_seed(self):
        with self.assertRaisesRegex(RuntimeError,'P12L3_OUTSIDE'):p.plan(24501)
    def test_refuse_consumed_validation_seed(self):
        with self.assertRaisesRegex(RuntimeError,'P12L3_OUTSIDE'):p.plan(24601)
    def test_refuse_heldout_seed(self):
        with self.assertRaisesRegex(RuntimeError,'P12L3_OUTSIDE'):p.plan(24701)
    def test_refuse_previous_replication_batch(self):
        with self.assertRaisesRegex(RuntimeError,'P12L3_OUTSIDE'):p.plan(24807)
    def test_refuse_future_replication_batch(self):
        with self.assertRaisesRegex(RuntimeError,'P12L3_OUTSIDE'):p.plan(24819)
    def test_exact_full_p12k_cpp_stream_lock(self):
        for seed in p.SEEDS:
            for site in k.SITES:
                a=k.allocation()[seed,site]
                entry=f'{{{{{seed}u,"{site}"}},{{{a["traffic_stream_seed"]}u,{a["routing_stream_seed"]}u,{a["telemetry_stream_seed"]}u,{a["selected_slot"]}u}}}}'
                self.assertIn(entry,self.cpp)
        self.assertNotIn('{{24601u,',self.cpp)
        self.assertNotIn('{{24701u,',self.cpp)
    def test_science_locks(self):self.assertEqual(p.LOCKS,dict(Congestion=None,FutureCongestion=None,F3_ready=False,GO_FREEZE=False,training_ready=False,heldout_release_authorized=False))
    def test_cpp_contract(self):
        self.assertIn('PROSPECTIVE_REPLICATION',self.cpp)
        self.assertIn(k.FAMILY,self.cpp)
        self.assertIn(k.SCHEMA,self.cpp)
        self.assertIn('P12K_V05225_PROSPECTIVE_REPLICATION_PREREG_LOCKED_CSV',self.cpp)
        self.assertNotIn('P12E_FRESH_INDEPENDENT',self.cpp)
    def test_command_exact_pair(self):
        x=[x for x in self.rows if x['telemetry']=='on_20ms'][0]
        cmd=p.command(x,Path('/tmp/test_case'))
        self.assertIn('--telemetryEnabled=1',cmd)
        self.assertIn(f"--scheduleCsv={k.PLANS/x['schedule_filename']}",cmd)
        self.assertIn('--technicalQueueMaxPackets=12',cmd)
    def test_no_interim_scoring_functions(self):
        source=(HERE/'scripts/run_stage1am_f3_p12l3_physical_v05228.py').read_text()
        for s in ('average_precision(', 'predict(', 'bootstrap(', 'fit_model(', 'evaluate_validation(', 'process_one('):self.assertNotIn(s,source)

if __name__=='__main__':unittest.main()
