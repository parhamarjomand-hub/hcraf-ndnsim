#!/usr/bin/env python3
"""Synthetic contract / mutation tests, not empirical ndnSIM success claims."""
import copy,unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from oracle_stage1am_pathwide import oracle,PathOracleError,physical_path

BASE=2_030_000_000
DT=30_000_000


def fixture(topo='DEV_CHAIN_B',slot=0):
    producer={'DEV_CHAIN_A':(5,6,7),'DEV_CHAIN_B':(7,5,6)}[topo][slot]
    cfg={'future_oracle_horizon_ns_pilot':50_000_000,'future_oracle_is_final_F3':False,
         'F3_ready':False,'GO_FREEZE':False,'training_ready':False,'future_congestion':None,
         'congestion':None,'topology_id':topo,'selected_face_slot':slot,
         'selected_face_id':258+slot,'path_nodes':[0,1,2+slot,producer],
         'planned_requests':12,'remote_queue_online_feature':False}
    edges=[(0,1),(1,2),(1,3),(1,4)]
    relay={'DEV_CHAIN_A':(5,6,7),'DEV_CHAIN_B':(7,5,6)}[topo]
    edges += [(2,relay[0]),(3,relay[1]),(4,relay[2])]
    dnums={};inits=[]
    for a,b in edges:
        for node in (a,b):
            d=dnums.get(node,0);dnums[node]=d+1
            inits.append({'event_type':'INITIAL','time_ns':0,'node_id':node,'device_index':d,
                          'face_id':257+d,'data_rate_bps':5000000})
    assert len(inits)==14
    finals=[{**e,'event_type':'FINAL','time_ns':20_000_000_000} for e in inits]
    decisions=[{'decision_id':i+1,'pit_instance_id':i+200,'name':f'/hcraf/pilot/{i}',
                'time_ns':BASE+i*DT} for i in range(12)]
    locals_=[{'decision_id':d['decision_id'],'sim_time_ns':d['time_ns'],
              'candidate_face_id':258+s,'observed_before_forwarding':True,
              'remote_node_queue_accessed':False,'future_pressure_label':None,
              'Congestion':None,'queue_packets':0} for d in decisions for s in range(3)]
    physical=inits+finals
    for i,e in enumerate(physical):e['link_event_seq']=i+1
    return cfg,decisions,locals_,physical

def new_drop(physical, node=1,device=1,time=BASE+10_000_000,cls='COMP',lp='SINGLE_LP'):
    ex=next(e for e in physical if e['event_type']=='INITIAL' and
            e['node_id']==node and e['device_index']==device)
    e={'event_type':'QUEUE_DROP','time_ns':time,'node_id':node,'device_index':device,
       'face_id':ex['face_id'],'ndn_packet_type':'INTEREST',
       'wire_status':'NON_PILOT' if cls=='COMP' else 'PILOT',
       'lp_status':lp,'ndn_name':'/hcraf/competitor/1' if cls=='COMP' else '/hcraf/pilot/1',
       'ndn_nonce':10001,'packet_uid':25,'packet_bytes':42}
    physical.insert(14,e)
    for i,x in enumerate(physical):x['link_event_seq']=i+1
    return e

class Stage1AMPathwideContract(unittest.TestCase):
    def setup(self,topo='DEV_CHAIN_B',slot=0):
        self.cfg,self.dec,self.local,self.phys=fixture(topo,slot)
    def check(self):return oracle(self.cfg,self.dec,self.local,self.phys)
    def test_empty_complete_path_is_diagnostic_negative(self):
        self.setup();j=self.check();self.assertEqual((j['pilot_positive'],j['pilot_negative'],j['pilot_unknown']),(0,12,0))
    def test_full_selected_path_both_directions_three_faces_two_topologies(self):
        for topo in ('DEV_CHAIN_A','DEV_CHAIN_B'):
            for slot in range(3):
                self.setup(topo,slot);r=self.check()
                self.assertEqual(len(r['forward_tx_devices']),3)
                self.assertEqual(len(r['return_tx_devices']),3)
                self.assertEqual(r['target_rows'][0]['selected_path_nodes'],self.cfg['path_nodes'])
    def test_selected_local_forward_positive(self):
        self.setup();new_drop(self.phys);self.assertEqual(self.check()['pilot_positive'],1)
    def test_remote_forward_positive(self):
        self.setup();new_drop(self.phys,node=2,device=1);self.assertEqual(self.check()['pilot_positive'],1)
    def test_return_direction_known_interest_positive_as_contract(self):
        self.setup();new_drop(self.phys,node=7,device=0)
        self.assertEqual(self.check()['pilot_positive'],1)
    def test_reverse_fragment_without_name_is_unknown(self):
        self.setup();e=new_drop(self.phys,node=7,device=0,lp='FRAGMENT')
        e.update({'wire_status':'INVALID','ndn_packet_type':None,'ndn_name':None,'ndn_nonce':None})
        self.assertEqual(self.check()['pilot_unknown'],1)
    def test_fragment_with_forged_name_is_still_unknown(self):
        self.setup();new_drop(self.phys,node=2,device=1,lp='FRAGMENT')
        self.assertEqual(self.check()['pilot_unknown'],1)
    def test_wrong_competitor_status_yields_unknown(self):
        self.setup();e=new_drop(self.phys);e['wire_status']='PILOT'
        self.assertEqual(self.check()['pilot_unknown'],1)
    def test_wrong_competitor_name_yields_unknown(self):
        self.setup();e=new_drop(self.phys);e['ndn_name']='/other/evil'
        self.assertEqual(self.check()['pilot_unknown'],1)
    def test_valid_target_interest_drop_does_not_count_competitor(self):
        self.setup();new_drop(self.phys,cls='TARGET')
        self.assertEqual(self.check()['pilot_negative'],12)
    def test_offpath_competitor_drop_does_not_count(self):
        self.setup();new_drop(self.phys,node=3,device=0)
        self.assertEqual(self.check()['pilot_positive'],0)
        self.assertEqual(self.check()['offpath_drop_count'],1)
    def test_event_before_decision_not_positive(self):
        self.setup();new_drop(self.phys,time=BASE-1)
        self.assertEqual(self.check()['pilot_positive'],0)
    def test_event_at_decision_not_positive(self):
        self.setup();new_drop(self.phys,time=BASE)
        self.assertEqual(self.check()['pilot_positive'],0)
    def test_event_at_horizon_endpoint_is_positive(self):
        self.setup();new_drop(self.phys,time=BASE+50_000_000)
        self.assertEqual(self.check()['pilot_positive'],2)
    def test_event_after_horizon_not_first_decision_positive(self):
        self.setup();new_drop(self.phys,time=BASE+50_000_001)
        j=self.check();self.assertEqual(j['target_rows'][0]['pilot_path_future_competitor_interest_drop_50ms'],0)
    def test_known_positive_remains_positive_with_concurrent_unknown(self):
        self.setup();new_drop(self.phys);e=new_drop(self.phys,node=7,device=0,lp='FRAGMENT')
        e.update({'wire_status':'INVALID','ndn_packet_type':None,'ndn_name':None})
        self.assertEqual(self.check()['pilot_positive'],1)
    def test_false_f3_ready_rejected(self):
        self.setup();self.cfg['F3_ready']=True
        with self.assertRaises(PathOracleError):self.check()
    def test_false_training_ready_rejected(self):
        self.setup();self.cfg['training_ready']=True
        with self.assertRaises(PathOracleError):self.check()
    def test_fake_future_congestion_rejected(self):
        self.setup();self.cfg['future_congestion']=1
        with self.assertRaises(PathOracleError):self.check()
    def test_incomplete_final_rejected(self):
        self.setup();self.phys.pop()
        with self.assertRaises(PathOracleError):self.check()
    def test_tampered_physical_face_rejected(self):
        self.setup();e=new_drop(self.phys);e['face_id']=999
        with self.assertRaises(PathOracleError):self.check()
    def test_reordered_physical_event_seq_rejected(self):
        self.setup();self.phys[5]['link_event_seq']=1
        with self.assertRaises(PathOracleError):self.check()
    def test_wrong_producer_path_rejected(self):
        self.setup();self.cfg['path_nodes'][-1]=5
        with self.assertRaises(PathOracleError):self.check()
    def test_wrong_selected_face_rejected(self):
        self.setup();self.cfg['selected_face_id']=400
        with self.assertRaises(PathOracleError):self.check()
    def test_future_local_snapshot_rejected(self):
        self.setup();self.local[0]['sim_time_ns']+=10
        with self.assertRaises(PathOracleError):self.check()
    def test_remote_telemetry_in_snapshot_rejected(self):
        self.setup();self.local[0]['remote_node_queue_accessed']=True
        with self.assertRaises(PathOracleError):self.check()
    def test_multiple_face_candidates_missing_rejected(self):
        self.setup();self.local.pop()
        with self.assertRaises(PathOracleError):self.check()
    def test_uncertain_class_must_not_be_zero(self):
        self.setup();e=new_drop(self.phys);e['ndn_packet_type']=None
        j=self.check();self.assertEqual(j['target_rows'][0]['pilot_path_future_competitor_interest_drop_50ms'],'UNKNOWN')

if __name__=='__main__':unittest.main()
