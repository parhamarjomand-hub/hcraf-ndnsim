import unittest,io,tempfile,pathlib,zipfile
import audit as a
class AuditTests(unittest.TestCase):
 def test_source_evidence(self): self.assertEqual(set(a.evidence()['slides']),{'3','5','7','8','24','25','28'})
 def test_locks(self): a.locked(a.LOCKS)
 def test_lock_release_rejected(self):
  for k in a.LOCKS:
   with self.subTest(k=k),self.assertRaises(RuntimeError):a.locked(dict(a.LOCKS,**{k:True}))
 def test_sha_rejection(self):
  with tempfile.TemporaryDirectory() as t:
   p=pathlib.Path(t)/'x';p.write_bytes(b'wrong')
   with self.assertRaisesRegex(RuntimeError,'SHA_'):a.checked(p,a.sha(b'correct'))
 def test_duplicate_row(self):
  s='seed,site,arm,decision_id,slot,candidate_class\n620201,producer_egress,A,1,0,0\n'
  with self.assertRaisesRegex(RuntimeError,'DUPLICATE'):a.class_coverage(io.StringIO(s+s.split('\n')[1]+'\n'))
 def test_unknown_seed(self):
  with self.assertRaisesRegex(RuntimeError,'ROW_DOMAIN'):a.class_coverage(io.StringIO('seed,site,arm,decision_id,slot,candidate_class\n620101,producer_egress,A,1,0,0\n'))
 def test_missing_cases(self):
  with self.assertRaisesRegex(RuntimeError,'COVERAGE'):a.class_coverage(io.StringIO('seed,site,arm,decision_id,slot,candidate_class\n620201,producer_egress,A,1,0,0\n'))
 def test_exact_coverage(self):
  s=io.StringIO('seed,site,arm,decision_id,slot,candidate_class\n') ; s.seek(0,2)
  for seed in range(620201,620237):
   for site in ('producer_egress','transit_middle','relay_return'):
    for arm in 'ABCDE':
     for i in range(1,127):s.write(f'{seed},{site},{arm},{i},{i%3},{int(arm in "BE" and i==1)}\n')
  s.seek(0);by,pos=a.class_coverage(s);self.assertEqual(pos,216);self.assertEqual(by['A']['negative_only'],108);self.assertEqual(by['B']['both'],108)
if __name__=='__main__':unittest.main()
