"""Read-only architectural mapping audit. No score computation, fit, threshold selection or new simulation."""
import csv, hashlib, io, json, pathlib, sys, zipfile, collections
P=pathlib.Path
BASE=P(__file__).resolve().parent
HASHES={15221940873:'746889957c3d91523fa937e7a888cef4e50d847c8596760f6b833ccdafe28ab2',15231539274:'cb5a67651f8342cec2883741ae59d89e606e50e23ce449c94c3e3b1002350e64',15251036596:'46a9efb4e47277fd45a0bbe63dc32df411abdf9323bd615feb4be75d0a48d869'}
SOURCE='hcraf_stage1am_f3_p12r_new_construct_confirm_v05260_sources.zip'
SOURCE_SHA='3782b7c5643fc521eed08af5977899f09fd94432f3347095e86f7b5533e50b27'
LOCKS=dict(F3_ready=False,GO_FREEZE=False,training_ready=False,Congestion=None,FutureCongestion=None,construct_validated=False,heldout_release_authorized=False,Stage1AO_or_NSGAIII_authorized=False)
def need(ok,msg):
    if not ok: raise RuntimeError('P12R63_'+msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def checked(path,h):
    b=P(path).read_bytes();need(sha(b)==h,'SHA_'+P(path).name);return b
def archive(b):
    z=zipfile.ZipFile(io.BytesIO(b));need(z.testzip() is None and len(z.namelist())==len(set(z.namelist())),'ZIP');return z
def locked(d):
    need(all(k in d and d[k]==v for k,v in LOCKS.items() if k!='construct_validated' or k in d),'LOCKS')
def class_coverage(stream):
    cases=collections.defaultdict(collections.Counter);ids=set()
    for r in csv.DictReader(stream):
        seed=int(r['seed']);site=r['site'];arm=r['arm'];i=int(r['decision_id']);slot=int(r['slot']);y=int(r['candidate_class']); k=(seed,site,arm)
        need(seed in range(620201,620237) and site in ('producer_egress','transit_middle','relay_return') and arm in 'ABCDE' and len(arm)==1 and 1<=i<=126 and 0<=slot<=2 and y in (0,1),'ROW_DOMAIN')
        need((*k,i) not in ids,'DUPLICATE');ids.add((*k,i));cases[k][y]+=1
    need(len(cases)==540 and len(ids)==68040 and all(sum(c.values())==126 for c in cases.values()),'COVERAGE')
    by={a:{'negative_only':0,'positive_only':0,'both':0} for a in 'ABCDE'}
    for (_,_,a),c in cases.items():by[a]['both' if c[0] and c[1] else 'positive_only' if c[1] else 'negative_only']+=1
    return by,sum(c[1] for c in cases.values())
def evidence(base=BASE/'evidence'):
    p=json.loads((base/'PROVENANCE.json').read_text());
    for i,s in p['slides'].items():checked(base/f'slide{i}.txt',s['text_sha256'])
    checked(base/'1AA.md',p['scope_sha256']);s24=(base/'slide24.txt').read_text();s25=(base/'slide25.txt').read_text();s28=(base/'slide28.txt').read_text();s7=(base/'slide7.txt').read_text()
    need('Congestion \n{0,1}' in s24 and 'P1–P99' in s24 and 'U_x − L_x ≤ ε_norm' in s24,'BINARY_SOURCE')
    need(all(x in s25 for x in ('w₁ RoutingCost','w₂ SRTT','w₃ Congestion','w₁+w₂+w₃=1')),'COST_SOURCE')
    need('1 − MeanRun[PR-AUC(Cost, FutureCongestion)]' in s28,'F3_SOURCE');need('No synthetic outcome' in s7,'OBSERVATION_SOURCE')
    return p
def run(inputs,source,out):
    p=evidence();z={i:archive(checked(inputs/f'github-actions-artifact-{i}.zip',h)) for i,h in HASHES.items()}
    plan=json.loads(z[15221940873].read('p12r_prereg/PLAN.json'));locked(plan['locks']);m=json.loads(z[15231539274].read('FROZEN_COMPARATORS.json'));locked(m);am=json.loads(z[15231539274].read('AMENDMENT_LOCK.json'));locked(am)
    need(plan['scope']==am['scope'] and plan['definition']==am['definition'] and plan['physical_gates']==am['physical_gates'] and plan['horizon_ns']==75000000,'PRESERVED_CONTRACT')
    need('branch-exclusive Data-return' in plan['scope'] and 'not whole path' in plan['scope'] and 'no remote telemetry' in plan['engineering']['probes'],'SCOPE')
    need(m['RTT_ONLY']['names']==['local_data_rtt_ewma_before_t','local_data_rtt_missing_at_t'] and m['RTT_ONLY']['weights'][0]>0 and m['B0']['names'][5:]==m['RTT_ONLY']['names'],'RTT_MODEL')
    need(m['RTT_ONLY']['means']==m['B0']['means'][5:] and m['RTT_ONLY']['sds']==m['B0']['sds'][5:],'RTT_SCALE')
    a=z[15251036596];r=json.loads(a.read('analysis_result/ANALYSIS_RECEIPT.json'));locked(r)
    need(r['status']=='NO_GO_P12R62_CONJUNCTIVE_GATES_NOT_MET' and r['physical_all_pass'] and not r['prediction_all_pass'] and r['prior_NO_GO_preserved'] and r['prior_B1_gate_blocked'],'PARENT_DECISION')
    need(r['cases']==540 and r['rows']==68040 and r['bootstrap_replicates']==10000 and r['invalid_replicates']==0 and all(r['physical_gates'].values()) and len(r['physical_gates'])==13 and sum(r['prediction_gates'].values())==1,'PARENT_COUNTS')
    for name,h in r['output_sha256'].items():need(sha(a.read('analysis_result/'+name))==h,'PARENT_OUTPUT_'+name)
    by,pos=class_coverage(io.TextIOWrapper(a.open('analysis_result/SCORES.csv'),encoding='utf8'));need(pos==r['positives'],'POSITIVE_COUNT')
    need(all(by[x]['negative_only']==108 for x in 'ACD') and all(by[x]['both']==108 for x in 'BE'),'CLASS_COVERAGE_EXPECTED')
    c=archive(checked(source,SOURCE_SHA));code=c.read('hcraf/episode/src/hcraf-stage1am-f3-p12r-new-construct-confirm-v05260.cpp').decode();need('unsigned rank=s==selected?1:' in code and '0.2*e.rtt+0.8*rtt' in code and 'missing=true' in code and 'now()-it->second)/1e6' in code,'EXECUTOR_MAPPING')
    findings={'architecture_cost':'w1*RC+w2*SRTT+w3*Congestion; nonnegative simplex','architecture_F3':'1-MeanRun[PR-AUC(Cost,FutureCongestion)]','online_congestion_type':'binary per slide 24','scope_gap':'branch-exclusive return only; 1AA proposed whole realized instrumented path in both directions; scope amendment needed, not universal validation','rtt_only':'causal local per-face RTT EWMA and missingness; positive slope at fixed missingness; monotone (non-strict at clipping) in RTT; not independent congestion evidence; equality to deployed SRTT state not established','rank_gap':'native confirmation rank is forced to 1 for selected slot; not a deployment-grade varying routing cost measurement','estimand_gap':'pooled AP of B0 versus RTT is not MeanRun PR-AUC of actual Cost; AP integration and run definition need prospective lock','coverage_gap':'only selected first forwarding episodes have labels; no counterfactual outcome; fixed branch allocation is not closed-loop HCRAF','binary_gap':'continuous RTT logit/probability not binary Congestion; no threshold selected','negative_only_run_policy':'undefined for original MeanRun; retain negative-only runs, no retrospective exclusion or AP convention'}
    result=dict(status='PASS_ARCHITECTURE_MAPPING_AUDIT_F3_RELEASE_BLOCKED',prior_scientific_decision=r['status'],prior_physical_gates_passed=13,prior_prediction_gates_passed=1,prior_AP_RTT_ONLY=r['AP_RTT_ONLY'],prior_AP_B0=r['AP_B0'],cases=540,rows=68040,positives=pos,class_coverage_by_arm=by,negative_only_runs=sum(x['negative_only'] for x in by.values()),mixed_runs=sum(x['both'] for x in by.values()),positive_only_runs=sum(x['positive_only'] for x in by.values()),findings=findings,source_evidence=p,official_artifact_sha256=HASHES,executor_zip_sha256=SOURCE_SHA,model_fits=0,new_AP_computed=False,new_bootstrap_computed=False,simulations=0,thresholds_selected=0,official_F3_labels_constructed=0,heldout_rows_read=0,confirmation_rows_reclassified=0,new_confirmation_authorized=False,**LOCKS)
    out.mkdir(parents=True,exist_ok=True);(out/'MAPPING_RECEIPT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True)+'\n');print(result['status'])
if __name__=='__main__':run(P(sys.argv[1]),P(sys.argv[2]),P(sys.argv[3]))
