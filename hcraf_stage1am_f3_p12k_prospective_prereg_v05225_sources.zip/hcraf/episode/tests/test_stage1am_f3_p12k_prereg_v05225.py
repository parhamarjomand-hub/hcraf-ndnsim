import unittest,sys,pathlib,json,copy
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'scripts'))
import audit_stage1am_f3_p12k_prereg_v05225 as auditor
class TestP12KScienceLock(unittest.TestCase):
    def test_complete_prereg_and_source_replay(self):
        r=auditor.audit()
        self.assertEqual(r['planned_physical_cases'],432)
        self.assertEqual(r['new_simulations'],0)
    def test_overlap_seed_block_guard(self):
        from audit_stage1am_f3_p12k_prereg_v05225 import ensure
        with self.assertRaises(AssertionError):ensure(not set([24501])&set([24501,24502]),'SEED_COLLISION')
    def test_generator_exact_seed_blocks(self):
        g=auditor.load_generator()
        self.assertEqual(len(g.SEED_SPLITS['PROSPECTIVE_REPLICATION']),36)
        with self.assertRaises(AssertionError):g.partition_of(24601)
        with self.assertRaises(AssertionError):g.partition_of(24701)
    def test_schedule_independently_reproducible(self):
        g=auditor.load_generator()
        a=g.render_schedule(24801,'producer_egress','high_pressure')
        self.assertEqual(a,g.render_schedule(24801,'producer_egress','high_pressure'))
        self.assertEqual(len(g.events(24801,'producer_egress','high_pressure')),128)
        self.assertNotEqual(a,g.render_schedule(24802,'producer_egress','high_pressure'))
    def test_paired_schedule_telemetry_only(self):
        g=auditor.load_generator()
        rows=[r for r in g.matrix_rows() if r['seed']==24804 and r['site']=='transit_middle' and r['load']=='high_pressure']
        self.assertEqual([r['telemetry'] for r in rows],['off','on_20ms'])
        self.assertEqual(len({r['schedule_sha256'] for r in rows}),1)
    def test_no_case_execution_authorized(self):
        g=auditor.load_generator()
        self.assertTrue(all(r['execution_authorized_now']=='false' for r in g.matrix_rows()))
    def test_locked_model_from_original_six_dev_seeds(self):
        doc=auditor.DOC
        m=json.loads((doc/'P12K_PINNED_P12H_FROZEN_MODELS.json').read_text())
        self.assertEqual(m['trained_on_seeds'],list(range(24501,24507)))
        self.assertEqual(auditor.D_SHA(doc/'P12K_PINNED_P12H_FROZEN_MODELS.json'),'de46e2f5fcb052f96e920729664084ad0edd029cc4af88b2c5480209976a35d1')
    def test_primary_endpoint_fixed_before_any_new_simulation(self):
        p=json.loads((auditor.DOC/'P12K_ANALYSIS_PLAN_FROZEN_v05225.json').read_text())
        self.assertEqual(p['bootstrap']['replicates'],10000)
        self.assertEqual(p['bootstrap']['lower_percentile'],.0125)
        self.assertEqual(p['bootstrap']['atomic_cluster'],'seed_block')
        self.assertEqual(len(p['replication_success_gates_all_required']),4)
        self.assertEqual(p['planning']['approx_80pct_n_using_normal_z_and_dev_seed_SD'],34)
    def test_f3_go_freeze_not_authorized(self):
        p=json.loads((auditor.DOC/'P12K_ANALYSIS_PLAN_FROZEN_v05225.json').read_text())
        self.assertTrue(all(v is False for k,v in p['scientific_locks'].items() if k not in ('Congestion','FutureCongestion')))
        self.assertIsNone(p['scientific_locks']['Congestion'])
    def test_zero_positive_subgroup_ap_not_a_number(self):
        p=json.loads((auditor.DOC/'P12K_ANALYSIS_PLAN_FROZEN_v05225.json').read_text())
        self.assertIn('AP undefined if no positives',p['AP_definition'])
if __name__=='__main__':unittest.main()
