#!/usr/bin/env python3
"""Read-only P12K prereg verification; no learning/simulation/validation reads."""
import hashlib,csv,io,importlib.util,json,pathlib,os,sys
ROOT=pathlib.Path(__file__).resolve().parents[3]
DOC=ROOT/'hcraf/episode/docs/1AM/F3_P12K_PROSPECTIVE_REPLICATION_PREREG_v0.52.25'
GEN=ROOT/'hcraf/episode/scripts/generate_stage1am_f3_p12k_prereg_v05225.py'
D_SHA=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def ensure(p,code):
    if not p:raise AssertionError('P12K_'+code)
def load_generator():
    spec=importlib.util.spec_from_file_location('p12k_schedule_engine',GEN)
    obj=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj

def audit():
    plan=json.loads((DOC/'P12K_ANALYSIS_PLAN_FROZEN_v05225.json').read_text())
    locks=plan['scientific_locks']
    for k,v in {'Congestion':None,'FutureCongestion':None,'F3_ready':False,'GO_FREEZE':False,
        'training_ready':False,'heldout_release_authorized':False,
        'Stage1AO_or_NSGAIII_authorized':False}.items():ensure(locks[k] is v,'SCIENCE_LOCK_'+k)
    ensure(plan['stage']=='P12K_v0.52.25_PROSPECTIVE_REPLICATION_FIXED_PREREG_ONLY','WRONG_STAGE')
    ensure(plan['zero_simulation_or_fit_or_heldout'] is True,'NONZERO_SIM_OR_FIT')
    ensure(plan['no_retraining_or_refitting'] is True,'RETRAIN')
    ensure(plan['seed_blocks_count']==36 and plan['seed_blocks']==list(range(24801,24837)),'SEED_MATRIX')
    used=set(plan['prior_seed_blocks_reserved_or_consumed'])
    ensure(not set(plan['seed_blocks']) & used,'LEAK_PREVIOUS_SEEDS')
    ensure(set(range(24501,24507))|set(range(24601,24605))|set(range(24701,24705))==used,'PRIOR_SEED_PROTECTION')
    ensure(plan['physical_case_count']==432 and plan['schedule_count']==216,'PLANNED_COUNTS')
    ensure(plan['episodes_per_case']==128 and plan['primary_episodes_planned']==27648,'EPISODE_COUNTS')
    ensure(plan['future_horizon_ns']==75000000,'FORECAST_HORIZON')
    ensure(plan['bootstrap']=={
        'atomic_cluster':'seed_block','replicates':10000,'rng_seed':525250,
        'ci_method':'paired-seed-bootstrap-percentile','two_sided_CI_coverage':0.975,
        'lower_percentile':0.0125,'upper_percentile':0.9875,
        'duplicate_seed_blocks_allowed':True,
        'invalid_resample_rule':'fail_and_report_indeterminate_no_selective_discard'},'BOOTSTRAP_CHANGED')
    ensure(len(plan['replication_success_gates_all_required'])==4,'GATE_COUNT')
    for short,filename in [('P12J_DEVELOPMENT_DIAGNOSTIC','P12K_AUTHENTICATED_P12J_DEV_DIAGNOSTIC_SNAPSHOT.json'),
     ('P12H_FROZEN_MODELS','P12K_PINNED_P12H_FROZEN_MODELS.json'),
     ('P12G_PROTOCOL','P12K_PINNED_P12G_DEV_PROTOCOL.json')]:
        ensure(D_SHA(DOC/filename)==plan['source_snapshot_SHA256'][short],'SOURCE_SNAPSHOT_'+short)
    ensure(plan['frozen_model_sha256']=='de46e2f5fcb052f96e920729664084ad0edd029cc4af88b2c5480209976a35d1', 'MODEL_SHA_MISMATCH')
    model=json.loads((DOC/'P12K_PINNED_P12H_FROZEN_MODELS.json').read_text())
    ensure(model['trained_on_seeds']==list(range(24501,24507)),'MODEL_USES_NONDEV_SEEDS')
    ensure(model['validation_rows_observed_before_freeze']==0,'MODEL_FROZEN_AFTER_VALIDATION')
    ensure(model['model_selection_using_validation'] is False,'MODEL_TUNED_ON_VAL')
    ensure(model['label_horizon_ns']==75000000,'MODEL_LABEL_HORIZON')
    protocol=json.loads((DOC/'P12K_PINNED_P12G_DEV_PROTOCOL.json').read_text())
    ensure(model['local_model']['names']==protocol['features_local_only'],'LOCAL_FEATURES_CHANGED')
    ensure(model['remote_model']['names']==protocol['features_remote_causal'],'REMOTE_FEATURES_CHANGED')
    report=json.loads((DOC/'P12K_AUTHENTICATED_P12J_DEV_DIAGNOSTIC_SNAPSHOT.json').read_text())
    ensure(report['confirmatory_gate']=='NO_GO' and report['no_validation_or_heldout_rows_read'] is True,'PRIOR_GATE_OR_DEV_LEAK')
    ensure(report['independent_seed_block_count']==6 and report['nominal_episode_count']==4608,'DEV_COUNT')
    ensure(report['parent_p12i_independent_audit_run']==44895950750,'P12I_PARENT')
    for name,receipt in plan['parents'].items():
        ensure(set(receipt)=={'run','commit','artifact_id','artifact_sha256'},'PARENT_KEYS_'+name)
        ensure(len(receipt['commit'])==40 and len(receipt['artifact_sha256'])==64,'PARENT_FORMAT_'+name)
    generator=load_generator()
    ensure(generator.SEED_SPLITS=={'PROSPECTIVE_REPLICATION':tuple(range(24801,24837))},'GEN_SEED_PARTITION')
    ensure(generator.SITES==tuple(plan['sites']) and generator.LOADS==tuple(plan['loads']) and generator.TELEMETRIES==tuple(plan['telemetries']), 'GEN_ARM')
    matrix_path=DOC/'P12K_LOCKED_MATRIX_432_v05225.csv'
    commits_path=DOC/'P12K_FROZEN_SCHEDULE_COMMITMENTS_216_v05225.json'
    c=json.loads(commits_path.read_text()); rows=list(csv.DictReader(io.StringIO(matrix_path.read_text())))
    ensure(len(rows)==432 and len({(v['seed'],v['site'],v['load'],v['telemetry']) for v in rows})==432,'MATRIX_UNIQUE_432')
    ensure(c['matrix_sha256']==D_SHA(matrix_path) and c['matrix_sha256']==hashlib.sha256(generator.render_matrix()).hexdigest(),'MATRIX_PREIMAGE')
    ensure(c['seeds']==plan['seed_blocks'] and c['fixed_seed_count']==36,'GEN_SEEDS_CHANGED')
    ensure(c['frozen_P12H_model_sha256']==plan['frozen_model_sha256'],'GEN_MODEL_CHANGED')
    ensure(c['new_simulations']==c['model_refits']==c['Validation_rows_authorized']==c['Heldout_rows_authorized']==0,'GEN_EXECUTOR_UNFENCED')
    ensure(c['all_executors_authorized_now'] is False,'GEN_EXECUTOR_RELEASED')
    expected=generator.matrix_rows()
    ensure(len(expected)==len(rows),'REGENERATE_MATRIX_ROWS')
    ensure(all(dict(r)=={k:str(v) for k,v in e.items()} for r,e in zip(rows,expected)),'MATRIX_TAMPER')
    ensure(len(c['schedule_hashes'])==216,'HASH_COUNT')
    for seed in plan['seed_blocks']:
        for site in plan['sites']:
            for load in plan['loads']:
                name=generator.filename(seed,site,load)
                p=DOC/'plans'/name
                ensure(p.is_file(),'MISSING_SCHEDULE_'+name)
                d=hashlib.sha256(generator.render_schedule(seed,site,load)).hexdigest()
                ensure(D_SHA(p)==d==c['schedule_hashes'][name],'SCHEDULE_TAMPER_'+name)
    for r in rows:
        ensure(int(r['seed']) in plan['seed_blocks'] and r['partition']=='PROSPECTIVE_REPLICATION','SEED_LEAK')
        ensure(r['schedule_sha256']==c['schedule_hashes'][r['schedule_filename']],'CASE_PLAN_SHA')
        ensure(r['execution_authorized_now']=='false' and r['validation_or_heldout_released']=='false','CASE_EXECUTE_IN_K')
        ensure(int(r['target_requests'])+int(r['competitor_requests'])==128,'REQUEST_COUNT')
    return {'stage':plan['stage'],'status':'PASS_P12K_PROSPECTIVE_PREREG_ONLY_ZERO_SIM',
       'GitHub_Run_ID':os.environ.get('GITHUB_RUN_ID','LOCAL_TEST_ONLY'),
       'commit':os.environ.get('GITHUB_SHA','LOCAL_BUILD'),
       'parent_runs':{k:v['run'] for k,v in plan['parents'].items()},
       'prior_P12H_and_P12I_confirmatory_result':'NO_GO_UNCHANGED',
       'frozen_model_sha256':D_SHA(DOC/'P12K_PINNED_P12H_FROZEN_MODELS.json'),
       'P12K_analysis_plan_sha256':D_SHA(DOC/'P12K_ANALYSIS_PLAN_FROZEN_v05225.json'),
       'P12K_matrix_sha256':D_SHA(matrix_path),'P12K_schedule_commitments_sha256':D_SHA(commits_path),
       'new_independent_seed_blocks':36,'sha_locked_schedules':216,
       'planned_physical_cases':432,'planned_active_telemetry_episodes':27648,
       'preregistration_completed_before_new_physical_runs':True,
       'new_simulations':0,'model_fits':0,'validation_or_heldout_rows_read':0,
       'scientific_locks':locks,'P12L_executed':False}

def main():
    output=audit()
    dest=ROOT/'episode_output/stage1am_f3_p12k_prospective_prereg_v05225'
    dest.mkdir(parents=True,exist_ok=True)
    p=dest/'P12K_PREREG_RECEIPT.json'
    if p.exists():ensure(json.loads(p.read_text())==output,'RECEIPT_OVERWRITE_REFUSED')
    else:p.write_text(json.dumps(output,indent=2,ensure_ascii=False,sort_keys=True)+'\n')
    print(json.dumps({'status':output['status'],'seed_blocks':36,'matrix':432,'schedules':216,
      'new_simulations':0,'frozen_model_sha256':output['frozen_model_sha256'],
      'P12H_decision':'NO_GO'},sort_keys=True))
if __name__=='__main__':main()
