#!/usr/bin/env python3
"""P12K immutable *new* replication schedules; ZERO physical simulations.

Adapted unchanged timing/pulse/traffic recipe from authenticated P12E v0.52.19;
new version-salted seed streams and 36 newly reserved seed blocks 24801..24836.
P12H failed confirmatory validation; it is NOT counted as new success.
"""
from __future__ import annotations

import csv
from functools import lru_cache
from hashlib import sha256
import io
import json
from pathlib import Path
import random

VERSION = 'HCRAF-STAGE1AM-F3-P12K-v0.52.25-FORMAL-PROSPECTIVE-PREREG-ONLY'
SCHEMA = 'HCRAF_F3_P12K_INDEPENDENT_PROSPECTIVE_V05219'
FAMILY = 'P12K_NEW_PROSPECTIVE_REPLICATION_LOCKED_NOT_EXECUTED'
SEED_SPLITS = {'PROSPECTIVE_REPLICATION': tuple(range(24801, 24837))}
SITES = ('producer_egress', 'transit_middle', 'consumer_ingress')
LOADS = ('low_control', 'high_pressure')
TELEMETRIES = ('off', 'on_20ms')
SITE_ARMS = {
    'producer_egress': ('PRODUCER_RETURN_12M', 'PRODUCER_RETURN', 'producer'),
    'transit_middle': ('MID_RETURN_12M', 'MID_RETURN', 'mid'),
    'consumer_ingress': ('RELAY_RETURN_12M', 'RELAY_RETURN', 'relay'),
}
CORE_PER_PULSE = 48
TAIL_OFFSETS_NS = tuple(n*1_000_000 for n in (20, 35, 50, 65, 80, 95, 110, 125, 140, 155))
TAIL_PER_PULSE = len(TAIL_OFFSETS_NS)
TARGET_REQUESTS = 12
COMPETITOR_REQUESTS = CORE_PER_PULSE*2 + TAIL_PER_PULSE*2
EPISODES_PER_CASE = TARGET_REQUESTS + COMPETITOR_REQUESTS
FUTURE_HORIZON_NS = 75_000_000
TEMPORAL_FEATURE_TTL_NS = 100_000_000
CAPACITY_CANDIDATE_PACKETS = 12
PILOT_EXCLUDED = (22001, 23401, 23402, 23501, 23502)
FEATURE_WHITELIST = (
    'fib_route_cost', 'local_selected_link_up',
    'local_selected_queue_packets', 'local_selected_queue_fraction',
    'relay_queue_packets', 'relay_queue_drops_observed_total',
    'relay_telemetry_age_ms', 'relay_telemetry_missing',
    'mid_queue_packets', 'mid_queue_drops_observed_total',
    'mid_telemetry_age_ms', 'mid_telemetry_missing',
    'producer_queue_packets', 'producer_queue_drops_observed_total',
    'producer_telemetry_age_ms', 'producer_telemetry_missing',
)
CSV_HEADER = ('traffic_class', 'sequence', 'time_ns', 'family', 'rng_block',
              'split', 'phase_label', 'phase_nominal_ns', 'phase_jitter_ns',
              'selected_slot', 'load_level', 'schedule_schema')
MATRIX_HEADER = ('seed', 'partition', 'site', 'selected_slot',
                 'temporal_anchor_A_ns', 'temporal_anchor_B_ns',
                 'traffic_stream_seed', 'routing_stream_seed',
                 'telemetry_stream_seed', 'arm', 'location', 'target_role',
                 'load', 'telemetry', 'schedule_filename', 'schedule_sha256',
                 'target_requests', 'competitor_requests',
                 'tail_probe_requests_per_pulse',
                 'candidate_queue_capacity_packets',
                 'execution_authorized_now', 'validation_or_heldout_released')

ROOT = Path(__file__).resolve().parents[3]
DOC = ROOT / 'hcraf/episode/docs/1AM/F3_P12K_PROSPECTIVE_REPLICATION_PREREG_v0.52.25'
PLANS = DOC / 'plans'
MATRIX = DOC / 'P12K_LOCKED_MATRIX_432_v05225.csv'
COMMITMENTS = DOC / 'P12K_FROZEN_SCHEDULE_COMMITMENTS_216_v05225.json'
LOCKS = dict(Congestion=None, FutureCongestion=None, F3_ready=False,
             GO_FREEZE=False, training_ready=False,
             heldout_release_authorized=False)


def require(value, code):
    if not value:
        raise AssertionError('P12K_' + code)


def digest_seed(label):
    n = int.from_bytes(sha256((VERSION + ':' + label).encode()).digest()[:8], 'big')
    return n or 1


def physical_stream_seed(label):
    return (digest_seed(label) & 0x7fffffff) or 1


def partition_of(seed):
    matches = [name for name, values in SEED_SPLITS.items() if seed in values]
    require(len(matches) == 1, 'FOREIGN_SEED_OR_AMBIGUOUS_PARTITION')
    return matches[0]


@lru_cache(maxsize=1)
def allocation():
    """Independent Latin counterbalance within each frozen partition."""
    allocated = {}
    for partition, seeds in SEED_SPLITS.items():
        count = len(seeds)*len(SITES)
        require(count%6 == 0, 'LATIN_REPETITION_NOT_WHOLE')
        a_grid = [2_190_000_000 + k*210_000_000
                  for _ in range(count//6) for k in range(6)]
        b_grid = [4_350_000_000 + k*250_000_000
                  for _ in range(count//6) for k in range(6)]
        random.Random(digest_seed(partition + ':ANCHOR_A')).shuffle(a_grid)
        random.Random(digest_seed(partition + ':ANCHOR_B')).shuffle(b_grid)
        for i, (seed, site) in enumerate((s, site) for s in seeds for site in SITES):
            identity = f'{partition}:{seed}:{site}'
            offset_a = random.Random(digest_seed(identity+':A')).randint(-8_000_000, 8_000_000)
            offset_b = random.Random(digest_seed(identity+':B')).randint(-8_000_000, 8_000_000)
            entry = dict(partition=partition,
                         selected_slot=(SITES.index(site)+seeds.index(seed))%3,
                         phase_A_anchor_ns=a_grid[i]+offset_a,
                         phase_B_anchor_ns=b_grid[i]+offset_b,
                         traffic_stream_seed=physical_stream_seed(identity+':traffic'),
                         routing_stream_seed=physical_stream_seed(identity+':routing'),
                         telemetry_stream_seed=physical_stream_seed(identity+':telemetry'))
            require(entry['phase_B_anchor_ns'] > entry['phase_A_anchor_ns']+900_000_000,
                    'PHASES_TOO_CLOSE')
            allocated[(seed, site)] = entry
    require(len(allocated) == 108, 'NOT_108_SEED_SITE_CELLS')
    streams = [row[key] for row in allocated.values()
               for key in ('traffic_stream_seed', 'routing_stream_seed',
                           'telemetry_stream_seed')]
    require(len(set(streams)) == len(streams) and all(x > 0 for x in streams),
            'PHYSICAL_STREAM_COLLISION_OR_ZERO')
    return allocated


def filename(seed, site, load):
    slot = allocation()[seed, site]['selected_slot']
    return f'p12k-v05225-{partition_of(seed).lower()}-seed-{seed}-{site}-slot-{slot}-{load}.csv'


def events(seed, site, load):
    require(seed in {s for values in SEED_SPLITS.values() for s in values} and
            site in SITES and load in LOADS, 'NONPREREGISTERED_CASE')
    a = allocation()[seed, site]
    identity = f'{partition_of(seed)}:{seed}:{site}'
    target_rng = random.Random(digest_seed(identity+':TARGET_JITTER_PAIRED'))
    core_rng = random.Random(digest_seed(identity+':CORE_JITTER:'+load))
    tail_rng = random.Random(digest_seed(identity+':TAIL_JITTER_PAIRED'))
    out = []

    def add(kind, seq, nominal, jitter, phase):
        out.append(dict(traffic_class=kind, sequence=seq, time_ns=nominal+jitter,
                        family=FAMILY, rng_block=seed, split=partition_of(seed),
                        phase_label=phase, phase_nominal_ns=nominal,
                        phase_jitter_ns=jitter, selected_slot=a['selected_slot'],
                        load_level=load, schedule_schema=SCHEMA))

    for seq in range(TARGET_REQUESTS):
        add('TARGET', seq, 2_260_000_000+330_000_000*seq,
            target_rng.randint(-280_000, 280_000), f'T{seq//3}')
    for seq in range(CORE_PER_PULSE*2):
        if load == 'low_control':
            nominal = 2_170_000_000+seq*163_000_000
        else:
            anchor = (a['phase_A_anchor_ns'] if seq < CORE_PER_PULSE
                      else a['phase_B_anchor_ns'])
            nominal = anchor+(seq%CORE_PER_PULSE)*3_600_000
        add('INDEPENDENT_COMPETITOR', seq, nominal,
            core_rng.randint(-180_000, 180_000), f'C{seq//CORE_PER_PULSE}')
    seq = CORE_PER_PULSE*2
    for pulse, anchor in enumerate((a['phase_A_anchor_ns'], a['phase_B_anchor_ns'])):
        nominal_last = anchor+(CORE_PER_PULSE-1)*3_600_000
        for offset in TAIL_OFFSETS_NS:
            add('INDEPENDENT_COMPETITOR', seq, nominal_last+offset,
                tail_rng.randint(-150_000, 150_000), f'P{pulse}_TAIL_PROBE')
            seq += 1
    out.sort(key=lambda row: (row['time_ns'], row['traffic_class'], row['sequence']))
    require(len(out) == EPISODES_PER_CASE == 128 and
            len({(e['traffic_class'], e['sequence']) for e in out}) == 128,
            'EPISODE_COUNT_OR_DUPLICATE')
    require(all(2_000_000_000 < x['time_ns'] < 19_000_000_000 for x in out),
            'EVENT_TIME_OUTSIDE_SIMULATOR')
    return out


def render_schedule(seed, site, load):
    buffer = io.StringIO(newline='')
    writer = csv.DictWriter(buffer, fieldnames=CSV_HEADER, lineterminator='\n')
    writer.writeheader()
    writer.writerows(events(seed, site, load))
    return buffer.getvalue().encode()


def matrix_rows():
    rows = []
    for partition, seeds in SEED_SPLITS.items():
        for seed in seeds:
            for site in SITES:
                a = allocation()[seed, site]
                arm, location, role = SITE_ARMS[site]
                for load in LOADS:
                    name = filename(seed, site, load)
                    digest = sha256(render_schedule(seed, site, load)).hexdigest()
                    for telemetry in TELEMETRIES:
                        rows.append(dict(seed=seed, partition=partition, site=site,
                            selected_slot=a['selected_slot'],
                            temporal_anchor_A_ns=a['phase_A_anchor_ns'],
                            temporal_anchor_B_ns=a['phase_B_anchor_ns'],
                            traffic_stream_seed=a['traffic_stream_seed'],
                            routing_stream_seed=a['routing_stream_seed'],
                            telemetry_stream_seed=a['telemetry_stream_seed'],
                            arm=arm, location=location, target_role=role,
                            load=load, telemetry=telemetry, schedule_filename=name,
                            schedule_sha256=digest, target_requests=TARGET_REQUESTS,
                            competitor_requests=COMPETITOR_REQUESTS,
                            tail_probe_requests_per_pulse=TAIL_PER_PULSE,
                            candidate_queue_capacity_packets=CAPACITY_CANDIDATE_PACKETS,
                            execution_authorized_now='false',
                            validation_or_heldout_released='false'))
    require(len(rows) == 432 and len({(r['seed'], r['site'], r['load'], r['telemetry'])
                                     for r in rows}) == 432, 'PARTITION_MATRIX_NOT_432_UNIQUE')
    return rows


def render_matrix():
    buffer = io.StringIO(newline='')
    writer = csv.DictWriter(buffer, fieldnames=MATRIX_HEADER, lineterminator='\n')
    writer.writeheader()
    writer.writerows(matrix_rows())
    return buffer.getvalue().encode()


def commitments():
    plans = {filename(seed, site, load): sha256(render_schedule(seed, site, load)).hexdigest()
             for seeds in SEED_SPLITS.values() for seed in seeds
             for site in SITES for load in LOADS}
    require(len(plans)==216,'NOT_216_FROZEN_SCHEDULES')
    return dict(stage='P12K_V05225_PROSPECTIVE_REPLICATION_PREREG_ONLY',
                partition='PROSPECTIVE_REPLICATION',
                seeds=list(SEED_SPLITS['PROSPECTIVE_REPLICATION']),
                previous_validation_attempt='P12H_44787046706_NO_GO_CONFIRMED_BY_P12I_44895950750',
                prior_heldout_seeds=[24701,24702,24703,24704],
                consumed_validation_seeds=[24601,24602,24603,24604],
                development_seeds=[24501,24502,24503,24504,24505,24506],
                frozen_P12H_model_sha256='de46e2f5fcb052f96e920729664084ad0edd029cc4af88b2c5480209976a35d1',
                fixed_seed_count=36, cases=432, frozen_schedule_files=216,
                episodes_per_case=128, active_telemetry_episodes=27648,
                total_case_episodes=55296,
                candidate_capacity_packets=CAPACITY_CANDIDATE_PACKETS,
                future_horizon_ns=FUTURE_HORIZON_NS,
                causal_telemetry_ttl_ns=TEMPORAL_FEATURE_TTL_NS,
                active_telemetry_only_for_primary_analysis=True,
                all_executors_authorized_now=False,
                new_simulations=0, model_refits=0,
                Validation_rows_authorized=0,Heldout_rows_authorized=0,
                schedule_hashes=plans,
                matrix_sha256=sha256(render_matrix()).hexdigest(),
                **LOCKS)


def write_immutable(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        require(path.read_bytes() == data, 'REFUSE_MUTATE_PRECOMMITTED_FILE:'+path.name)
    else:
        path.write_bytes(data)


def main():
    for seeds in SEED_SPLITS.values():
        for seed in seeds:
            for site in SITES:
                for load in LOADS:
                    write_immutable(PLANS/filename(seed,site,load), render_schedule(seed,site,load))
    write_immutable(MATRIX, render_matrix())
    write_immutable(COMMITMENTS,
                    (json.dumps(commitments(),ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode())
    print('PASS_P12K_216_SCHEDULE_SHA_LOCKED_CSV_432_FUTURE_CASES_ZERO_SIMULATIONS')


if __name__ == '__main__':
    main()
