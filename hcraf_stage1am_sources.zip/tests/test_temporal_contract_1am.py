"""Stage 1AM isolated negative/contract tests. No ndnSIM or dependencies."""
import copy,sys,unittest,importlib.util
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'scripts'/'temporal_contract_1am.py'
spec=importlib.util.spec_from_file_location('temporal_contract_1am',p)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

class EpisodeJoinNegativeTests(unittest.TestCase):
 def setUp(self):
  self.decision={'name':'/hcraf/pilot/0','pit_instance_id':4,'decision_id':3,'time_ns':100}
  self.scenario={'selected_face_id':258}
  self.episode={'name':'/hcraf/pilot/0','pit_instance_id':'4','face_id':258,'start_ns':100,
                'tx_times_ns':[110],'tx_nonces':[1234]}
  self.tx={'event_type':'TX_INTEREST','decision_id':3,'name':'/hcraf/pilot/0',
           'face_id':258,'time_ns':110,'nonce':1234}
 def check(self):return m.validate_episode_join(self.decision,self.episode,self.tx,self.scenario)
 def test_real_join_passes(self):self.assertTrue(self.check())
 def test_name_swap_rejected(self):
  self.episode['name']='/hcraf/pilot/1'
  with self.assertRaises(m.ContractViolation):self.check()
 def test_pit_swap_rejected(self):
  self.episode['pit_instance_id']='5'
  with self.assertRaises(m.ContractViolation):self.check()
 def test_face_swap_rejected(self):
  self.episode['face_id']=259
  with self.assertRaises(m.ContractViolation):self.check()
 def test_decision_id_swap_rejected(self):
  self.tx['decision_id']=4
  with self.assertRaises(m.ContractViolation):self.check()
 def test_nonce_swap_rejected(self):
  self.tx['nonce']=999
  with self.assertRaises(m.ContractViolation):self.check()
 def test_future_before_decision_rejected(self):
  self.tx['time_ns']=90;self.episode['tx_times_ns']=[90]
  with self.assertRaises(m.ContractViolation):self.check()
 def test_duplicate_transmission_list_rejected(self):
  self.episode['tx_times_ns']=[110,120];self.episode['tx_nonces']=[1234,1235]
  with self.assertRaises(m.ContractViolation):self.check()

class ContractTests(unittest.TestCase):
 def setUp(self):
  self.scenario={'decision_node_id':1,'selected_face_id':258,'actual_assignment_probability':1.0}
  self.dec={'schema_version':'1B.1','anchor':'BEFORE_AFTER_RECEIVE_INTEREST',
    'node_id':1,'decision_id':7,'time_ns':120,'after_event_seq':2,
    'candidates':[{'face_id':x,'routing_cost':i+1,'strategy_eligible':None} for i,x in enumerate((258,259,260))]}
  self.ev=[{'event_seq':1,'time_ns':100,'event_type':'PIT_SATISFIED'},
           {'event_seq':2,'time_ns':120,'event_type':'PIT_TIMER'},
           {'event_seq':3,'time_ns':121,'event_type':'TX_INTEREST'}]
  self.selection={'schema_version':'1M.1','decision_id':7,'time_ns':120,'after_event_seq':2,
    'selected_face_id':258,'policy':'uniform','selected_action_probability':1/3,
    'eligibility_rule':'NFD_isNextHopEligible_FRESH_PIT_THREE_FACES'}
  self.states=[]
  for i,face in enumerate((258,259,260)):
   self.states.append({'schema_version':'1I.1','decision_id':7,'node_id':1,
      'face_id':face,'time_ns':120,'after_event_seq':2,'RoutingCost':i+1,
      'SRTT_ms':None,'Goodput_bps':0,'SuccessEstimate':None,
      'valid_outcomes':1,'valid_rtt':0,'retained_success_records':0,
      'max_terminal_event_seq':1,'last_rtt_evidence_age_ns':None,
      'last_outcome_evidence_age_ns':20,'Congestion':None,'research_training_eligible':False})
 def assertRefuses(self,fn):
  with self.assertRaises(m.ContractViolation):fn()
 def check(self):return m.validate_snapshot(self.dec,self.states,self.selection,self.ev,self.scenario)
 def test_valid_snapshot(self):self.assertTrue(self.check())
 def test_tampered_future_terminal_event(self):
  self.states[0]['max_terminal_event_seq']=3;self.assertRefuses(self.check)
 def test_tampered_future_timestamp(self):
  self.states[0]['time_ns']=121;self.assertRefuses(self.check)
 def test_snapshot_from_wrong_decision(self):
  self.states[0]['decision_id']=8;self.assertRefuses(self.check)
 def test_selected_face_mismatch(self):
  self.selection['selected_face_id']=259;self.assertRefuses(self.check)
 def test_future_reference_after_cutoff(self):
  self.ev[1]['time_ns']=124;self.assertRefuses(self.check)
 def test_wrong_anchor(self):
  self.dec['anchor']='AFTER_INTEREST_REPLY';self.assertRefuses(self.check)
 def test_missing_state(self):
  self.states.pop();self.assertRefuses(self.check)
 def test_duplicate_state_face(self):
  self.states[0]['face_id']=260;self.assertRefuses(self.check)
 def test_unknown_candidate_strategy_imputed(self):
  self.dec['candidates'][0]['strategy_eligible']=True;self.assertRefuses(self.check)
 def test_unknown_congestion_marked_zero(self):
  self.states[0]['Congestion']=0;self.assertRefuses(self.check)
 def test_training_ready_fraud(self):
  self.states[0]['research_training_eligible']=True;self.assertRefuses(self.check)
 def test_behavioral_probability_fraud(self):
  self.scenario['actual_assignment_probability']=1/3;self.assertRefuses(self.check)
 def test_negative_evidence_age(self):
  self.states[0]['last_outcome_evidence_age_ns']=-1;self.assertRefuses(self.check)
 def test_negative_history_count(self):
  self.states[0]['valid_rtt']=-1;self.assertRefuses(self.check)
 def test_nonfinite_goodput(self):
  self.states[0]['Goodput_bps']=float('nan');self.assertRefuses(self.check)
 def test_wrong_routing_cost(self):
  self.states[0]['RoutingCost']=100;self.assertRefuses(self.check)
 def test_selected_action_false_nominal(self):
  self.selection['selected_action_probability']=1.0;self.assertRefuses(self.check)
 def test_bad_selection_cutoff(self):
  self.selection['after_event_seq']=3;self.assertRefuses(self.check)
 def test_bad_prefix_no_f3_leak(self):
  self.states[0]['SRTT_ms']=-1;self.assertRefuses(self.check)
 def test_valid_null_terminal(self):
  self.states[0]['max_terminal_event_seq']=0;self.assertTrue(self.check())
 def test_terminal_nonterminal_event(self):
  self.ev[0]['event_type']='TX_INTEREST';self.assertRefuses(self.check)
 def test_horizon_early_episode_unknown(self):
  state,label=m.classify_horizon(100,100+100000000,'SUCCESS',250,'DEV_DIAGNOSTIC')
  self.assertEqual(state,'EPISODE_TERMINATED_BEFORE_FULL_WINDOW');self.assertIsNone(label)
 def test_horizon_full_window_still_null(self):
  state,label=m.classify_horizon(100,100+500000000,'SUCCESS',250,'DEV_DIAGNOSTIC')
  self.assertEqual(state,'WINDOW_ELAPSED_NO_VALIDATED_F3_ADJUDICATOR');self.assertIsNone(label)
 def test_horizon_drop_unknown_even_though_window(self):
  state,label=m.classify_horizon(100,100+500000000,'TIMEOUT',250,'UNKNOWN_INCOMPLETE_CLASS_OR_PATH')
  self.assertEqual(state,'INCOMPLETE_PATH_OR_DROP_UNKNOWN');self.assertIsNone(label)
 def test_horizon_boundary_is_full_not_early(self):
  state,_=m.classify_horizon(0,250000000,'TIMEOUT',250,'DEV_DIAGNOSTIC')
  self.assertEqual(state,'WINDOW_ELAPSED_NO_VALIDATED_F3_ADJUDICATOR')
 def test_horizon_unknown_not_cured_by_early_termination(self):
  state,_=m.classify_horizon(0,1,'SUCCESS',2000,'UNKNOWN_INCOMPLETE_CLASS_OR_PATH')
  self.assertEqual(state,'INCOMPLETE_PATH_OR_DROP_UNKNOWN')
 def test_forbidden_horizon(self):self.assertRefuses(lambda:m.classify_horizon(0,250000000,'SUCCESS',501,'DEV_DIAGNOSTIC'))
 def test_invalid_episode_time(self):self.assertRefuses(lambda:m.classify_horizon(2,1,'SUCCESS',250,'DEV_DIAGNOSTIC'))
 def test_open_outcome(self):self.assertRefuses(lambda:m.classify_horizon(0,1,'OPEN',250,'DEV_DIAGNOSTIC'))
 def test_horizon_control_set(self):self.assertEqual(m.HORIZONS_MS,(250,1000,2000))
 def test_feature_whitelist_excludes_pressure(self):
  self.assertNotIn('Congestion',m.ONLINE_FEATURES);self.assertNotIn('M3',m.ONLINE_FEATURES)

if __name__=='__main__':unittest.main(verbosity=2)
