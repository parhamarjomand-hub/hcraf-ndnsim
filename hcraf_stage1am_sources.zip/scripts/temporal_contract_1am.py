#!/usr/bin/env python3
"""HCRAF Stage 1AM v0.38: audit genuine local NFD decision-time snapshots.

Read-only; traces from stage1AH (2 topologies x 3 selected faces x 4 regimes x 3 seeds)
plus independent stage1AL cross-face evidence.  This tool NEVER creates F3 labels
or claims HCRAF decision overhead; it diagnoses contractual readiness fail-closed.

All snapshot fields must be observed at or before the NFD anchor.  All retrospective
physical service evidence is stored separately, never as an online feature.
"""
import argparse,csv,hashlib,json,zipfile,collections,math
from pathlib import Path

MODES=('LP_SELF_ONLY','LP_INDEPENDENT_COMPETITOR_NO_DROP','LP_INDEPENDENT_COMPETITOR_DROP','UNFRAGMENTED_MATCHED_BYTES')
SLOTS=(0,1,2)
RUNS=(9101,9102,9103)
HORIZONS_MS=(250,1000,2000)
FACE_IDS=(258,259,260)
ONLINE_FEATURES=('RoutingCost','SRTT_ms','SuccessEstimate','Goodput_bps','last_outcome_evidence_age_ns','last_rtt_evidence_age_ns','valid_outcomes','valid_rtt','retained_success_records')
LABELS=('Congestion','FutureCongestion','F3_ready','training_ready')

class ContractViolation(ValueError):pass

def require(cond,msg):
 if not cond:raise ContractViolation(msg)
def sha(data):return hashlib.sha256(data).hexdigest()
def read(z,path):return [json.loads(x) for x in z.read(path).splitlines() if x.strip()]
def verify_archive(z,name):
 require(z.testzip() is None,name+': bad CRC')
 ns=z.namelist();require(len(set(ns))==len(ns),name+': duplicate member')
 m=json.loads(z.read('manifest.json'))
 require(set(ns)==set(m['file_sha256'])|{'manifest.json'},name+': manifest coverage')
 for n,h in m['file_sha256'].items():
  require(sha(z.read(n))==h,name+': sha256 mismatch '+n)
 require(sha(z.read('source_bundle.zip'))==m['source_zip_sha256'],name+': source mismatch')
 return {'artifact':name,'manifest_file_count':len(m['file_sha256']),
         'source_sha256':m['source_zip_sha256'],'github_run_id':m.get('github_run_id')}

def validate_snapshot(d, rows, selection, events, scenario):
 """Exact admissibility proof for one NFD decision and 3 per-Face states."""
 require(d['schema_version']=='1B.1' and d['anchor']=='BEFORE_AFTER_RECEIVE_INTEREST','wrong decision anchor')
 require(d['node_id']==scenario['decision_node_id'],'wrong local decision node')
 require(isinstance(d['time_ns'],int) and isinstance(d['after_event_seq'],int),'invalid decision time')
 require(len(rows)==len(d['candidates'])==3,'not exactly three face states')
 require(set(r['face_id'] for r in rows)==set(FACE_IDS),'wrong state face coverage')
 require(set(c['face_id'] for c in d['candidates'])==set(FACE_IDS),'wrong FIB coverage')
 require(all(c.get('strategy_eligible') is None for c in d['candidates']), 'imputed strategy eligibility')
 require(selection['schema_version']=='1M.1' and selection['decision_id']==d['decision_id'],'wrong selection')
 require(selection['time_ns']==d['time_ns'] and selection['after_event_seq']==d['after_event_seq'],'selection after cutoff')
 require(selection['selected_face_id']==scenario['selected_face_id'],'selected face changed')
 require(selection['policy']=='uniform' and selection['eligibility_rule']=='NFD_isNextHopEligible_FRESH_PIT_THREE_FACES','wrong dev selection')
 require(abs(selection['selected_action_probability']-1/3)<1e-12,'unexpected nominal propensity')
 require(scenario['actual_assignment_probability']==1.0,'actual assignment must be forced, no false propensity')
 cutoff=d['after_event_seq']; now=d['time_ns']
 event_idx={x['event_seq']:x for x in events}
 require(cutoff in event_idx,'cutoff event missing')
 require(event_idx[cutoff]['time_ns']<=now,'cutoff itself is in future')
 before=set(event_idx)
 require(all(isinstance(r['time_ns'],int) and r['time_ns']==now and r['after_event_seq']==cutoff
             and r['decision_id']==d['decision_id'] and r['node_id']==d['node_id'] for r in rows),
             'snapshot time or decision id mismatch')
 for r in rows:
  require(r.get('Congestion') is None and r.get('research_training_eligible') is False,'online congestion leakage')
  require(r.get('schema_version')=='1I.1','wrong state schema')
  require(r['max_terminal_event_seq']<=cutoff,'future terminal event leaked')
  if r['max_terminal_event_seq']:
   seq=r['max_terminal_event_seq']
   require(seq in before and event_idx[seq]['time_ns']<=now,'future evidence used')
   require(event_idx[seq]['event_type'] in ('PIT_SATISFIED','PIT_FINALIZE','NACK_ACCEPTED'), 'invalid terminal lineage')
  for key in ('last_outcome_evidence_age_ns','last_rtt_evidence_age_ns'):
   if r.get(key) is not None:require(isinstance(r[key],int) and r[key]>=0,'future/negative age')
  for key in ('valid_outcomes','valid_rtt','retained_success_records'):
   require(type(r[key])==int and r[key]>=0,'invalid history sample count')
  for key in ('RoutingCost','Goodput_bps','SRTT_ms','SuccessEstimate'):
   if r.get(key) is not None:require(isinstance(r[key],(int,float)) and math.isfinite(r[key]) and r[key]>=0, 'nonfinite/negative feature '+key)
  cand=next(c for c in d['candidates'] if c['face_id']==r['face_id'])
  require(cand['routing_cost']==r['RoutingCost'],'FIB routing cost mismatch')
 return True


def validate_episode_join(decision,episode,tx,scenario):
 """Fail-closed PIT × Face × Name × Nonce binding at the decision anchor."""
 require(episode['name']==decision['name'] and
         str(episode['pit_instance_id'])==str(decision['pit_instance_id']),
         'PIT or Name mismatch')
 require(episode['face_id']==scenario['selected_face_id'] and
         episode['start_ns']==decision['time_ns'], 'Episode Face or decision timestamp mismatch')
 require(tx.get('event_type')=='TX_INTEREST' and
         tx.get('decision_id')==decision['decision_id'] and
         tx.get('name')==decision['name'] and
         tx.get('face_id')==scenario['selected_face_id'] and
         tx.get('time_ns')>=decision['time_ns'], 'Actual transmission Face/name mismatch')
 require(len(episode['tx_times_ns'])==len(episode['tx_nonces'])==1 and
         episode['tx_times_ns'][0]==tx['time_ns'] and
         episode['tx_nonces'][0]==tx['nonce'], 'Transmission nonce/timestamp mismatch')
 return True


def classify_horizon(decision_time,end_time,outcome,delta_ms,retrospective_state):
 """Diagnostic censoring only. None is mandatory for all F3 labels at this stage.

 Episode end before full horizon prevents negative inference. Even a full horizon
 is not F3-eligible without independent adjudicated pressure and trace coverage.
 """
 require(isinstance(decision_time,int) and isinstance(end_time,int) and end_time>=decision_time,'wrong episode time')
 require(outcome in ('SUCCESS','TIMEOUT','NACK','CANCELLED'),'OPEN or invented terminal')
 require(delta_ms in HORIZONS_MS,'unregistered horizon')
 if retrospective_state.startswith('UNKNOWN_'):return 'INCOMPLETE_PATH_OR_DROP_UNKNOWN',None
 if end_time<decision_time+delta_ms*1000000:return 'EPISODE_TERMINATED_BEFORE_FULL_WINDOW',None
 return 'WINDOW_ELAPSED_NO_VALIDATED_F3_ADJUDICATOR',None

def write_csv(path,rows,fields):
 with path.open('w',newline='',encoding='utf8') as f:
  w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)
def write_json(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')

def calculate(folder,out):
 out.mkdir(parents=True,exist_ok=True)
 references={'DEV_CHAIN_A':'hcraf_stage1ah_A_reference.zip','DEV_CHAIN_B':'hcraf_stage1ah_B_reference.zip'}
 z_al=zipfile.ZipFile(folder/'hcraf_stage1al_audit_reference.zip')
 require(z_al.testzip() is None,'1AL reference CRC')
 am=json.loads(z_al.read('manifest.json'));require(set(z_al.namelist())==set(am['output_sha256'])|{'manifest.json'},'1AL manifest coverage')
 for n,h in am['output_sha256'].items(): require(sha(z_al.read(n))==h,'1AL SHA mismatch: '+n)
 scope=list(csv.DictReader(z_al.read('episode_scope_2160.csv').decode().splitlines()))
 require(len(scope)==2160,'1AL episode count')
 labels={}
 for r in scope:
  k=(r['topology'],int(r['face_slot']),r['regime'],int(r['rng_run']),r['name'])
  require(k not in labels,'duplicate 1AL episode');labels[k]=r
  require(r['future_congestion']==r['congestion']=='' and r['F3_ready']==r['training_ready']=='False','1AL must remain unlabelled')
 integrity=[];snapshot_rows=[];censor_rows=[];coverage=[];events_checked=0; decisions_checked=0; dev_actual_propensity_mismatch=0
 for topology,ref in references.items():
  with zipfile.ZipFile(folder/ref) as z:
   integ=verify_archive(z,ref);integ['topology']=topology;integ['sha256']=sha((folder/ref).read_bytes());integrity.append(integ)
   for slot in SLOTS:
    for mode in MODES:
     for run in RUNS:
      base=f'stage1ah/{topology}/monitored/slot-{slot}/{mode}/run-{run}/'
      scen=json.loads(z.read(base+'scenario.json'))
      require(scen['topology_id']==topology and scen['mode']==mode and scen['run']==run and scen['selected_face_slot']==slot, 'scenario design drift')
      require(scen['selected_face_id']==FACE_IDS[slot] and scen['selection_policy']=='FORCED_DETERMINISTIC_DRAW_UNIFORM_NOMINAL','selected face provenance changed')
      require(scen['instrument_enabled'] is True and scen['F3_ready'] is False and scen['training_ready'] is False
             and scen['congestion'] is None and scen['future_congestion'] is None and scen['decision_time_us_real_HCRAF'] is None,
             'scenario falsely claims final online label/performance')
      decisions=read(z,base+'events.jsonl.decisions.jsonl')
      states=read(z,base+'events.jsonl.states.jsonl')
      choices=read(z,base+'events.jsonl.collection.jsonl')
      ev=read(z,base+'events.jsonl')
      eps=read(z,base+'episodes.jsonl')
      require(len(decisions)==len(choices)==len(eps) and len(states)==len(decisions)*3,'decision/state/episode count')
      require([e['event_seq'] for e in ev]==list(range(1,len(ev)+1)),'router event gaps')
      require(all(ev[i]['time_ns']<=ev[i+1]['time_ns'] for i in range(len(ev)-1)),'NFD event non-monotonic')
      require(all(decisions[i]['time_ns']<=decisions[i+1]['time_ns'] for i in range(len(decisions)-1)),'decision timestamp nonmonotonic')
      state_by_dec=collections.defaultdict(list)
      for s in states:state_by_dec[s['decision_id']].append(s)
      choice_by_dec={c['decision_id']:c for c in choices}
      require(len(choice_by_dec)==len(choices),'duplicate decision selection')
      episode_by_key={(str(e['pit_instance_id']),e['name']):e for e in eps}
      require(len(episode_by_key)==len(eps),'duplicate episode PIT+name')
      targets=0;unknown=0;consumer=0
      for d in decisions:
       decisions_checked+=1
       did=d['decision_id']; ss=state_by_dec[did]; choice=choice_by_dec[did]
       validate_snapshot(d,ss,choice,ev,scen)
       ep=episode_by_key.get((str(d['pit_instance_id']),d['name']))
       require(ep is not None,'PIT episode cannot be joined to decision')
       relevant=[e for e in ev if e.get('decision_id')==did and e['event_type']=='TX_INTEREST']
       require(len(relevant)==1,'one selected TX per decision is required')
       validate_episode_join(d,ep,relevant[0],scen)
       require(ep['outcome'] in ('SUCCESS','TIMEOUT','NACK','CANCELLED'),'nonterminal episode')
       key=(topology,slot,mode,run,d['name']);al=labels.get(key)
       require(al is not None and al['outcome']==ep['outcome'] and int(al['face_id'])==ep['face_id'],'crossface outcome/Face mismatch')
       if al['traffic_class']=='TARGET':targets+=1
       require(d['name'].startswith('/hcraf/'+('pilot/' if al['traffic_class']=='TARGET' else 'competitor/')),'traffic identity mismatch')
       require(al['evidence_state'] and al['F3_ready']=='False','AL unknown contract')
       if al['evidence_state'].startswith('UNKNOWN_'):unknown+=1
       for s in ss:
        states_after_cutoff = s['max_terminal_event_seq']>d['after_event_seq']
        require(not states_after_cutoff,'future label leakage')
        snapshot_rows.append({'topology':topology,'face_slot':slot,'mode':mode,'rng_run':run,
         'node_id':d['node_id'],'pit_instance_id':d['pit_instance_id'],'name':d['name'],
         'decision_id':did,'t_decision_ns':d['time_ns'],'after_event_seq':d['after_event_seq'],
         'candidate_face_id':s['face_id'],'is_selected_face':s['face_id']==scen['selected_face_id'],
         'actual_selected_action_probability':1.0 if s['face_id']==scen['selected_face_id'] else 0.0,
         'observed_selection_policy':'FORCED_DETERMINISTIC_DRAW_UNIFORM_NOMINAL',
         **{k:s[k] for k in ONLINE_FEATURES},'max_terminal_event_seq':s['max_terminal_event_seq'],
         'terminal_evidence_at_or_before_cutoff':s['max_terminal_event_seq']<=d['after_event_seq'],
         'Congestion':None,'FutureCongestion':None,'F3_ready':False,'training_ready':False})
       for horizon in HORIZONS_MS:
        reason,fl=classify_horizon(d['time_ns'],ep['end_ns'],ep['outcome'],horizon,
           al['evidence_state'])
        censor_rows.append({'topology':topology,'face_slot':slot,'mode':mode,'rng_run':run,
         'name':d['name'],'traffic_class':al['traffic_class'],'selected_face_id':ep['face_id'],
         't_decision_ns':d['time_ns'],'episode_end_ns':ep['end_ns'],'outcome':ep['outcome'],
         'horizon_ms':horizon,'observation_status':reason,'F3_future_label':fl,
         'offline_path_blocking_diagnostic_only':al['observed_path_competitor_blocking'] if al['return_path_complete']=='True' else None,
         'return_path_complete':al['return_path_complete']=='True',
         'evidence_state':al['evidence_state'],'training_ready':False})
      coverage.append({'topology':topology,'face_slot':slot,'mode':mode,'rng_run':run,
        'decisions':len(decisions),'states':len(states),'target_decisions':targets,
        'unknown_1AL_episodes':unknown, 'selected_face_id':scen['selected_face_id'],
        'actual_assignment_prob':scen['actual_assignment_probability'],
        'nominal_uniform_prob_not_actual':scen['nominal_uniform_probability_NOT_behavioral_propensity']})
 require(len(coverage)==72 and len(snapshot_rows)==6480 and len(censor_rows)==6480 and decisions_checked==2160,
   'full design coverage lost')
 counts=collections.Counter(r['observation_status'] for r in censor_rows)
 online_summary={'stage':'1AM.TEMPORAL_ONLINE_CONTRACT_PREFLIGHT.0','version':'v0.38.0',
  'status':'PASS_RETROSPECTIVE_NFD_SNAPSHOT_AUDIT_ONLY',
  'freeze_decision':'NO_GO_PENDING_REAL_ONLINE_CONGESTION_INSTRUMENTATION_AND_F3_VALIDATION',
  'reference_integrity':integrity,'verified_runs':len(coverage),'real_decisions':decisions_checked,
  'online_candidate_state_rows':len(snapshot_rows),'target_decisions':sum(c['target_decisions'] for c in coverage),
  'retrospective_horizon_diagnostic_rows':len(censor_rows),'censor_status_counts':dict(counts),
  'real_nfd_anchor':'BEFORE_AFTER_RECEIVE_INTEREST','physical_pressure_online_at_router':False,
  'remote_link_pressure_online_telemetry':False,'measured_true_hcraf_decision_cpu_ram_latency':False,
  'theta_and_window_locked_for_F3':False,'actual_forced_selection_provenance_recorded':True,
  'dynamic_hcraf_behavioral_selection_observed':False,
  'no_future_labels_generated':True,'GO_FREEZE':False,'F3_ready':False,
  'training_ready':False,'Congestion':None,'FutureCongestion':None,
  'null_counts_in_6480_state_rows':{k:sum(r.get(k) is None for r in snapshot_rows) for k in ONLINE_FEATURES},
  'selected_face_rows':sum(r['is_selected_face'] for r in snapshot_rows),
  'dataset_generation_authorized':False,'main_224_run_campaign_authorized':False}
 write_csv(out/'online_snapshots_6480.csv',snapshot_rows,list(snapshot_rows[0]))
 write_csv(out/'horizon_censoring_6480.csv',censor_rows,list(censor_rows[0]))
 write_csv(out/'run_coverage_72.csv',coverage,list(coverage[0]))
 write_json(out/'summary.json',online_summary)
 gates=[
  {'id':'G05','domain':'NFD decision time and chronological locality',
   'status':'PASS_LIMITED_DEV','evidence':'2160 real NFD decisions; 6480 time/seq-checked snapshots'},
  {'id':'G06','domain':'Online feature admissibility',
   'status':'PASS_LOCAL_HISTORY_ONLY_REMOTE_AND_CONGESTION_BLOCKED',
   'evidence':'RoutingCost/SRTT/SuccessEstimate/Goodput local; no live Congestion or remote telemetry'},
  {'id':'G07','domain':'Future pressure target and verified censoring',
   'status':'BLOCKED_NO_VALIDATED_F3_ADJUDICATOR',
   'evidence':f"{counts.get('INCOMPLETE_PATH_OR_DROP_UNKNOWN',0)} incomplete-path horizon rows and {counts.get('EPISODE_TERMINATED_BEFORE_FULL_WINDOW',0)} early-ended horizon rows, all labels null"},
  {'id':'G08','domain':'Development-only theta/Delta/W and untouched test splits',
   'status':'BLOCKED_FINAL_PARAMETER_LOCK_AND_SPLIT',
   'evidence':'Delta exploratory 250/1000/2000ms; no fixed theta/W or untouched frozen split'},
  {'id':'G09','domain':'True in-NFD online snapshot/decision CPU/RSS/latency',
   'status':'BLOCKED_NO_CXX_PER_DECISION_MEASUREMENTS',
   'evidence':'Python retrospective audit runtime is not the HCRAF decision overhead'},
  {'id':'G10','domain':'Behavior policy propensity / MNAR coverage',
   'status':'PASS_LIMITED_DEV_FORCED_FACE_ONLY',
   'evidence':'actual selected probability 1 vs nominal 1/3, dynamic HCRAF not tested; DROP unknown'},
  {'id':'G11','domain':'Final independent pre-freeze review',
   'status':'BLOCKED_PENDING_1AM_COMPLETION_AND_FINAL_1AN',
   'evidence':'No verified F3 labels, no online congestion instrument, no real HCRAF decision cost'},
 ]
 write_json(out/'gates_1AM.json',gates)
 return online_summary

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--input-dir',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
 args=p.parse_args();print(json.dumps(calculate(args.input_dir,args.out),indent=2,ensure_ascii=False))
