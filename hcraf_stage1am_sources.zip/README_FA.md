# مرحله 1AM — ممیزی زمان تصمیم و سانسور، v0.38.0

**وضعیت:** `PASS_RETROSPECTIVE_NFD_SNAPSHOT_AUDIT_ONLY`؛ **هنوز 1AM به‌طور کامل برای Freeze پذیرفته نشده است.**

سه فایل لازم *جدید* برای GitHub:
- `hcraf_stage1am_sources.zip` در ریشه مخزن، بدون استخراج.
- `hcraf_stage1al_audit_reference.zip` در ریشه مخزن، بدون استخراج.
- `hcraf-stage1am.yml` در `.github/workflows/hcraf-stage1am.yml`.

دو مرجع قبلی که باید از مرحله 1AL در ریشه مخزن موجود باشند:
- `hcraf_stage1ah_A_reference.zip`
- `hcraf_stage1ah_B_reference.zip`

Workflow `HCRAF - Stage 1AM Temporal Snapshot & Censoring Preflight` را از GitHub Actions اجرا کنید. Artifact با پیشوند `hcraf-stage1am-temporal-audit-` را حتی در صورت شکست در این گفتگو ارسال کنید. نسخه‌ی قبلی 1AN را اجرا نکنید: این یک ممیزی مقدماتی ثابتاً NO-GO است و باید بعد از پذیرش کامل 1AM برای Artifact جدید به‌روزرسانی شود.

## بازتولید آفلاین

با قرار دادن سه Reference در یک پوشه واحد، از پوشه استخراج‌شده منابع:

```bash
python -m unittest discover -s tests -p 'test_*.py' -v
python scripts/temporal_contract_1am.py --input-dir /path/to/reference-folder --out /path/to/output
```

**خروجی**: جدول ۶٬۴۸۰ Snapshot، ۶٬۴۸۰ بررسی افق، ۷۲ وضعیت اجرا، JSON خلاصه و ماتریس هفت گیت 1AM. خروجی‌ها فقط پژوهشی/تشخیصی‌اند؛ نه دیتاست Train، نه برچسب F3 و نه مدل.
