# قرارداد علمی ـ فنی 1AM: زمان، Feature، Label، UNKNOWN

## A. تفسیر اصلی

**واحد تصمیم:** `PIT Entry × selected outgoing Face × t_decision` در گره تصمیم‌گیرنده. سه Face حاضر در FIB سه اقدام ممکن هستند؛ هرگز آنها را سه مشاهده مستقل از Outcome حساب نکنید.

**مرجع ساعت:** `ns3::Simulator::Now().GetNanoSeconds()`. `t_decision` پیش از اجرای strategy برای همان Interest ثبت شده است. `after_event_seq` مرز رخداد محلی را در timestampهای برابر مشخص می‌کند. هر ایستگاه دیگر یا telemetry باید Timestamp مشاهده، Timestamp انتشار، سن شواهد، شناسه Face و زمان *دریافت در روتر تصمیم* داشته باشد؛ `observed_time <= received_time <= t_decision`. بدون آن، `UNKNOWN`.

**Featureهای فعلی مجاز:** `RoutingCost`, `SRTT_ms`, `SuccessEstimate`, `Goodput_bps`, `valid_outcomes`, `valid_rtt`, `retained_success_records`, `last_outcome_evidence_age_ns`, `last_rtt_evidence_age_ns` با اعتبارسنجی lineages. ویژگی پیشنهادی `Congestion` فعلاً `null` است چون ابزارگذاری لحظه تصمیم ندارد.

**Featureهای ممنوع:** M3 پسینی، گروه Fragmentهای کامل که بعداً به PIT متصل شده‌اند، بسته‌های رقیب که پس از t_decision دیده شده‌اند، فیلد `FutureCongestion` و هر شاخص فشار خارج از روتر بدون telemetry واقعی زمان‌دار.

## B. برچسب آفلاین F3، هنوز برای Freeze نهایی نشده

`FutureCongestion` باید فشار قابل‌انتساب به ترافیک **مستقل از همان گروه** در جهت لینک Face انتخاب‌شده و در پنجره `(t_decision,t_decision+Δ]` باشد. نامزد شاهد مثبت: مدت انتظار Fragment واقعی پشت ارسال فیزیکی رقیب، Backlog رقیب، یا Drop انتساب‌یافته؛ فقط با تطبیق کامل Node/Device/Face/Name/LP/PIT و افق. به‌صرف `M3=1` یا `Delay` بزرگ، مثبت ساخته نشود. برای صفر، مشاهده **کامل پنجره و مسیر** همراه با نبود شواهد فشار در دامنه مصوب لازم است. Drop نامنسوب، Fragment/PIT ناقص، خروج زودهنگام Episode، نبود یک جهت یا نبود مانیتور → `UNKNOWN`.

Δهای DEV: ۲۵۰/۱۰۰۰/۲۰۰۰ms؛ `theta` و `W` برای برچسب نهایی تعیین نشده‌اند. گیت نهایی باید روی منابع واقعی با حداقل دو کلاس و نسبت UNKNOWN، با گروه‌بندی seed/topology/Face/regime و جلوگیری از استفاده از Test تأیید شود.

## C. Split و هزینه

Train/Validation/Test-ID/Test-OOD باید با block واقعی و seed/topology/run تقسیم شوند؛ ردیف‌های سه Face از یک تصمیم یا چند Fragment از یک Episode را میان Train/Test تقسیم نکنید. در این مرحله **هیچ split آموزشی نهایی، داده آموزش یا وزن مدل** ساخته نشده است.

برای هزینه آنلاین: snapshot_latency_ns، strategy_latency_ns، memory_rss_kib، CPU مصرفی NFD و overhead مانیتور، paired-uninstrumented baseline. این فیلدها در Artifactهای پیشین وجود ندارند، بنابراین صفرگذاری نمی‌شوند.
