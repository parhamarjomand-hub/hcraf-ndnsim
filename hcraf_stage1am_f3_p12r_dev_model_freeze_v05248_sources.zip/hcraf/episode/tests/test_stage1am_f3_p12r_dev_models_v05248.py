import unittest,math,sys,pathlib,tempfile
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'scripts'))
import freeze_stage1am_f3_p12r_dev_models_v05248 as f
class Guard(unittest.TestCase):
 def test_sigmoid(self):
  self.assertEqual(f.sigmoid(0),.5);self.assertEqual(f.sigmoid(1000),1);self.assertEqual(f.sigmoid(-1000),0)
 def test_one_class(self):
  with self.assertRaisesRegex(RuntimeError,'FIT_SHAPE_CLASSES'):f.fit([[1],[2]],[0,0],['x'])
 def test_wrong_shape(self):
  with self.assertRaisesRegex(RuntimeError,'FIT_SHAPE_CLASSES'):f.fit([[1],[2,3]],[0,1],['x'])
 def test_determinism(self):
  X=[[0,1],[2,1],[3,1],[4,1]]; y=[0,0,1,1];a=f.fit(X,y,['a','b']);self.assertEqual(a,f.fit(X,y,['a','b']));self.assertEqual(a['weights'][1],0);self.assertEqual(a['sds'][1],1e-10);self.assertGreater(a['weights'][0],0)
 def test_bad_qc(self):
  with tempfile.TemporaryDirectory() as t:
   p=pathlib.Path(t)/'bad';p.write_bytes(b'x')
   with self.assertRaisesRegex(RuntimeError,'QC_ZIP_HASH'):f.load(p,p)
 def test_refuse_existing(self):
  with tempfile.TemporaryDirectory() as t:
   p=pathlib.Path(t)
   with self.assertRaisesRegex(RuntimeError,'NO_OVERWRITE_REFIT'):f.freeze(p,p,p)
 def test_science(self):
  self.assertTrue(all(v is False or v is None for v in f.FLAGS.values()));self.assertEqual(f.DEV,list(range(24901,24907)));self.assertEqual(f.SHUFFLE_ID,24900)
