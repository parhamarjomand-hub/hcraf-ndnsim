#!/usr/bin/env python3
"""P12R v0.52.48: DEV-only deterministic fit and pre-confirmatory model seal."""
import argparse,collections,csv,hashlib,io,json,math,pathlib,random,sys,zipfile
QC_SHA='acb9d4891991e8425ef6ae85f0587ea192f441e47a7f54176736ae584ac61b2b'
PREREG_SHA='dbb12863ca83c26b687b243211aaf698986b8d6f2f7b8656cffb06278751ae30'
QC_RUN=45966812511
QC_ART=15182951916
QC_COMMIT='9e14efe0c721c4d31a38bad98ec5494b14ad77c4'
DEV=list(range(24901,24907))
SHUFFLE_ID=24900
FLAGS=dict(F3_ready=False,GO_FREEZE=False,training_ready=False,heldout_release_authorized=False,Stage1AO_or_NSGAIII_authorized=False,Congestion=None,FutureCongestion=None)
P=dict(epochs=24,initial_lr=.035,epoch_decay=.08,l2_per_step=.0005,intercept_prior_pseudocount=.5,shuffle_seed_offset=521000)
FILES={'B1_development_features.csv':'e92788e834a9280eb5ffb1b37596cf84d9d1aff1af74e73b9302ac86b9b24cf3','R_development_features.csv':'c16d907563d49229b6f03ddd9cf355eb737b7b43a8c9d2a3f1746daf2261a269','case_qc.csv':'9d47b25e04f53ac9709deb338a957698569e5f04f74514392a3e127a192c0c72','development_audit_keys_NOT_FEATURES.csv':'d66f8937030fa2e1dc2e6148fc73d7b13a495e558d3790128373ae0fd7eaae82','development_research_endpoint.csv':'c427140d0cd1ac601fb21dc02a5c371a3b48f382f3a135f72144b5e01b0270bd'}
POS=[31,75,66,39,83,61]
def need(x,msg):
    if not x:raise RuntimeError('P12R48_'+msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def load(qc,prereg):
    need(sha(qc.read_bytes())==QC_SHA,'QC_ZIP_HASH')
    need(sha(prereg.read_bytes())==PREREG_SHA,'PREREG_ZIP_HASH')
    with zipfile.ZipFile(prereg) as z:
        suffix='P12R_FAIR_COMPARATOR_PROSPECTIVE_PLAN_v05237.json';n=[n for n in z.namelist() if n.endswith('/'+suffix)];need(len(n)==1,'PLAN');plan=json.loads(z.read(n[0]))
    contract=plan['model_training_locked'];need(all(contract[k]==v for k,v in P.items()) and not contract['hyperparameter_search'] and not contract['post_confirm_refit'] and contract['development_rows_only']==4608 and plan['seed_partitions']['development']==DEV,'TRAINING_CONTRACT')
    need(all(plan[k] is v for k,v in FLAGS.items()),'PREREG_FENCES')
    features=plan['feature_sets'];b1=features['strengthened_local_B1_primary_control'];r=features['remote_plus_B1_R_primary_treatment'];need(len(b1)==12 and len(r)==21 and r[:12]==b1,'FEATURE_CONTRACT')
    with zipfile.ZipFile(qc) as z:
        prefix='p12r_dataset_qc/'; receipt_name='P12R_DEV_DATASET_QC_RECEIPT_v05247.json'
        need(z.testzip() is None and len(z.namelist())==len(set(z.namelist())),'QC_ZIP_STRUCTURE')
        receipt=json.loads(z.read(prefix+receipt_name));need(receipt['status']=='PASS_P12R_DEV_DATASET_QC_ONLY_NO_FIT_NO_CONFIRMATION' and all(receipt[k] is v for k,v in FLAGS.items()),'QC_STATUS')
        need(receipt['parent_run']==45955373789 and receipt['parent_artifact']==15180634595 and receipt['prereg_sha256']==PREREG_SHA and receipt['primary_rows']==4608 and receipt['development_cases']==72 and receipt['decisions_audited']==9216 and receipt['positive']==355 and receipt['negative']==4253 and receipt['confirmation_cases']==receipt['model_fits']==receipt['diagnostic_rows_used']==receipt['official_F3_labels_constructed']==0 and not receipt['new_AP_computed'],'QC_COUNTS')
        need(receipt['feature_order_B1']==b1 and receipt['feature_order_R']==r and receipt['output_sha256']==FILES,'QC_FEATURES_HASHES')
        raw={n:z.read(prefix+n) for n in FILES};need(all(sha(raw[n])==h for n,h in FILES.items()),'QC_FILE_HASH')
    def csvread(name,header):
        rows=list(csv.reader(io.StringIO(raw[name].decode('utf8'),newline='')));need(rows[0]==header and len(rows)==4609 and all(len(x)==len(header) for x in rows[1:]),'CSV_SCHEMA_'+name);return rows[1:]
    bx=csvread('B1_development_features.csv',b1);rx=csvread('R_development_features.csv',r)
    keys=csvread('development_audit_keys_NOT_FEATURES.csv',['seed','site','load','decision_id','decision_time_ns']);ys=csvread('development_research_endpoint.csv',['future_selected_path_device0_queue_drop_75ms'])
    need(all(x[0] in ('0','1') for x in ys),'LABEL');y=[int(x[0]) for x in ys]
    need(len({tuple(x[:4]) for x in keys})==4608,'DUPLICATE_KEY');counts=collections.Counter((int(k[0]),k[1],k[2]) for k in keys)
    need(counts=={(s,i,j):128 for s in DEV for i in plan['prospective_design']['sites'] for j in plan['prospective_design']['loads']},'DEV_MATRIX')
    need([sum(v for k,v in zip(keys,y) if int(k[0])==s) for s in DEV]==POS,'SEED_LABEL_COUNTS')
    X=[[float(v) for v in row] for row in bx];R=[[float(v) for v in row] for row in rx]
    need(all(all(math.isfinite(v) for v in row) for row in R+X),'NONFINITE');need(all(a==b[:12] for a,b in zip(X,R)),'PAIR_MISMATCH')
    need(all(len({tuple(x) for k,x in zip(keys,X) if int(k[0])==s})>1 for s in DEV),'CONSTANT_BASELINE')
    return b1,r,X,R,y,contract

def sigmoid(z):
    if z>=0:return 1/(1+math.exp(-z))
    e=math.exp(z);return e/(1+e)
def fit(X,y,names):
    n=len(y);d=len(names);need(n==len(X) and n>0 and all(len(x)==d for x in X) and 0<sum(y)<n,'FIT_SHAPE_CLASSES')
    means=[sum(row[j] for row in X)/n for j in range(d)]
    sds=[max(1e-10,math.sqrt(sum((row[j]-means[j])**2 for row in X)/n)) for j in range(d)]
    xx=[[max(-5.,min(5.,(v-mu)/sd)) for v,mu,sd in zip(row,means,sds)] for row in X]
    w=[0.]*d;b=math.log((sum(y)+P['intercept_prior_pseudocount'])/(n-sum(y)+P['intercept_prior_pseudocount']))
    for epoch in range(P['epochs']):
        order=list(range(n));random.Random(P['shuffle_seed_offset']+SHUFFLE_ID*100+epoch).shuffle(order)
        lr=P['initial_lr']/(1+P['epoch_decay']*epoch)
        for i in order:
            v=xx[i];error=sigmoid(b+sum(a*c for a,c in zip(w,v)))-y[i];b-=lr*error
            for j,x in enumerate(v):w[j]-=lr*(error*x+P['l2_per_step']*w[j])
    need(all(math.isfinite(x) for x in means+sds+w+[b]),'NONFINITE_MODEL')
    return dict(names=names,means=means,sds=sds,weights=w,intercept=b)
def encode(x):return (json.dumps(x,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def freeze(qc,prereg,out):
    need(not out.exists(),'NO_OVERWRITE_REFIT')
    b1,r,X,R,y,contract=load(qc,prereg)
    local=fit(X,y,b1);remote=fit(R,y,r)
    need(local['means']==remote['means'][:12] and local['sds']==remote['sds'][:12],'SCALER_MISMATCH')
    constant=[b1[j] for j in range(12) if all(row[j]==X[0][j] for row in X)]
    need(all(local['weights'][b1.index(f)]==0. and remote['weights'][b1.index(f)]==0. for f in constant),'CONSTANT_WEIGHT')
    common=dict(protocol_id='P12R_V05248_FIXED_FULL_SIX_DEV_MODELS_BEFORE_CONFIRMATION',trained_on_seeds=DEV,trained_on_rows=len(y),training_positives=sum(y),training_negatives=len(y)-sum(y),label_horizon_ns=75000000,full_development_shuffle_identifier=SHUFFLE_ID,shuffle_identifier_rule='first development seed minus one; historical P12H convention; chosen without tuning before fit',sd_floor=1e-10,fixed_model_prereg=contract,source_qc_run=QC_RUN,source_qc_artifact=QC_ART,source_qc_commit=QC_COMMIT,source_qc_zip_sha256=QC_SHA,source_prereg_zip_sha256=PREREG_SHA,source_file_hashes=FILES,confirmation_rows_read=0,confirmation_simulations_this_stage=0,diagnostic_rows_used=0,legacy_validation_rows_read=0,heldout_rows_read=0,new_AP_computed=False,new_bootstrap_computed=False,official_F3_labels_constructed=0,hyperparameter_search=False,**FLAGS)
    out.mkdir(parents=True,exist_ok=False)
    models=dict(common,local_model=local,remote_model=remote)
    name='P12R_FROZEN_FULL_DEV_MODELS_v05248.json';data=encode(models);(out/name).write_bytes(data)
    receipt=dict(common,status='PASS_P12R_TWO_DEV_MODELS_FROZEN_ONLY_NO_CONFIRMATION_NO_F3_RELEASE',model_fits=2,constant_B1_features=constant,model_sha256=sha(data),B1_model_sha256=sha(encode(local)),R_model_sha256=sha(encode(remote)),model_file=name,confirmation_execution_authorized=False,python_version=sys.version.split()[0])
    (out/'P12R_DEV_MODEL_FREEZE_RECEIPT_v05248.json').write_bytes(encode(receipt));(out/'P12R_FROZEN_MODEL_SHA256SUMS.txt').write_text(sha(data)+'  '+name+'\n')
    print(receipt['status'],receipt['model_sha256']);return receipt
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--qc-zip',type=pathlib.Path,required=True);p.add_argument('--prereg-zip',type=pathlib.Path,required=True);p.add_argument('--output',type=pathlib.Path,required=True);a=p.parse_args();freeze(a.qc_zip,a.prereg_zip,a.output)
