#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
bash "$TASK/scripts/build_stage1am_f3_queue_telemetry_smoke_v0522.sh"
cd "$ROOT/episode_sources/ns-3"
cp "$TASK/src/hcraf-stage1am-f3-p12l6-physical-v05231.cpp" scratch/hcraf-stage1am-f3-p12l6-physical-v05231.cc
cmp -s "$TASK/src/hcraf-stage1am-f3-p12l6-physical-v05231.cpp" scratch/hcraf-stage1am-f3-p12l6-physical-v05231.cc
python3 ./waf -j 2
test -x build/scratch/hcraf-stage1am-f3-p12l6-physical-v05231
