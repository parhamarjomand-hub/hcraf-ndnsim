import pathlib
import sys
import io
import json
import tempfile
import unittest

HERE=pathlib.Path(__file__).resolve()
ROOT=HERE.parents[3]
sys.path.insert(0,str(ROOT/"hcraf/episode/scripts"))

from generate_stage1am_f3_p4_revised_dev_schedules_v0529 import (
    STREAMS, SLOT, ORDER, render, schedule, filename, derive,
)
from generate_stage1am_f3_p4_revised_matrix_v0529 import rows as prereg_rows
from run_stage1am_f3_p4_revised_dev_v0529 import (
    plan, check_locked_schedules, build_command,
)
import build_stage1am_f3_p4_revised_dev_tables_v0529 as table_builder


class RevisedProspectiveDevelopment(unittest.TestCase):
    def test_only_four_development_seeds_and_three_physical_slots(self):
        self.assertEqual(set(STREAMS),(set(range(23201,23205))))
        self.assertEqual(set(SLOT.values()),{0,1,2})
        self.assertEqual(SLOT[23201],0)
        self.assertEqual(ORDER,[23201,23202,23204,23203])
        self.assertEqual(STREAMS[23201],(2110668159,799615411,63991880))
        self.assertEqual(STREAMS[23204],(1119802263,1719190708,1374297618))
        self.assertEqual(derive(23202,"traffic"),STREAMS[23202][0])

    def test_prospective_schedules_are_immutable_and_paired(self):
        check_locked_schedules()
        for seed in STREAMS:
            lo=schedule(seed,"low_control")
            hi=schedule(seed,"high_pressure")
            self.assertEqual([r["time_ns"] for r in lo if r["traffic_class"]=="TARGET"],
                             [r["time_ns"] for r in hi if r["traffic_class"]=="TARGET"])
            self.assertNotEqual([r["time_ns"] for r in lo if r["traffic_class"]=="INDEPENDENT_COMPETITOR"],
                                [r["time_ns"] for r in hi if r["traffic_class"]=="INDEPENDENT_COMPETITOR"])
            self.assertEqual(len(lo),108)
            self.assertEqual(len(hi),108)

    def test_no_validation_or_heldout_schedule_generated(self):
        for bad in (22001,23101,23102,24101,25101):
            with self.assertRaises(ValueError):schedule(bad,"high_pressure")
        for bad in ("test","heldout","calibration"):
            with self.assertRaises(ValueError):schedule(23201,bad)

    def test_four_development_seed_forty_eight_factorial_cases(self):
        rows=plan()
        self.assertEqual(len(rows),48)
        self.assertEqual({x["seed"] for x in rows},{23201,23202,23203,23204})
        self.assertEqual({x["selected_slot"] for x in rows},{0,1,2})
        self.assertEqual({x["site"] for x in rows},{"producer_egress","transit_middle","consumer_ingress"})
        self.assertEqual({x["load"] for x in rows},{"low_control","high_pressure"})
        self.assertEqual({x["telemetry"] for x in rows},{"off","on_20ms"})
        for r in rows:
            command=build_command(r,pathlib.Path("/tmp/p4-dev-fixture"))
            self.assertIn("--run="+str(r["seed"]),command)
            self.assertIn("--technicalQueueMaxPackets=12",command)
            self.assertIn("--scheduleFamily=P4_REVISED_PROSPECTIVE",command)
            self.assertNotIn("--run=23101",command)
            self.assertNotIn("25101",command)
            self.assertNotIn("24101",command)

    def test_versioned_144_case_matrix_has_96_nonexecutable_protected_rows(self):
        matrix=prereg_rows()
        self.assertEqual(len(matrix),144)
        self.assertEqual({r["seed"] for r in matrix if r["split"]=="development"},
                         {23201,23202,23203,23204})
        self.assertEqual({r["seed"] for r in matrix if r["split"]=="validation"},
                         {24101,24102,24103,24104})
        self.assertEqual({r["seed"] for r in matrix if r["split"]=="heldout"},
                         {25101,25102,25103,25104})
        self.assertEqual(sum(r["execution_authorized"]=="true" for r in matrix),48)
        self.assertEqual(sum(r["execution_authorized"]=="false" for r in matrix),96)
        self.assertTrue(all(r["schedule_filename"]=="UNRELEASED" for r in matrix
                            if r["split"]!="development"))

    def test_cpp_snapshots_exclude_future_and_mark_missing(self):
        cpp=ROOT/"hcraf/episode/src/hcraf-stage1am-f3-p4-revised-dev-v0529.cpp"
        code=cpp.read_text()
        self.assertIn("feature_missing_sources",code)
        self.assertIn("100000000ULL",code)
        self.assertIn("STALE_GT_100MS",code)
        self.assertIn("UNRECEIVED",code)
        self.assertIn('holdout_partition\\\":\\\"DEVELOPMENT',code)
        self.assertNotIn('holdout_partition\\\":\\\"CALIBRATION',code)

    def test_outcome_extraction_is_separate_from_causal_feature_source(self):
        extract=ROOT/"hcraf/episode/scripts/build_stage1am_f3_p4_revised_dev_tables_v0529.py"
        code=extract.read_text()
        self.assertIn("metadata_NOT_A_PREDICTOR",code)
        self.assertIn("allowed_decision_time_features",code)
        self.assertIn("DIAGNOSTIC_ONLY_not_official_F3",code)
        self.assertIn("bisect_right(drops,t+75000000)-bisect_right(drops,t)",code)
        self.assertIn("rr[\"sample_ns\"]<=rr[\"receipt_ns\"]<=t",code)
        self.assertNotIn("PR_AUC=",code)

    def test_independent_queue_drop_label_is_strictly_future_and_features_are_causal(self):
        row=dict(seed=23201,site="producer_egress",load="high_pressure",
                 telemetry="on_20ms",enabled=True)
        with tempfile.TemporaryDirectory() as d:
            original=table_builder.DEST
            try:
                table_builder.DEST=pathlib.Path(d)
                dest=table_builder.DEST/"23201"/row["site"]/row["load"]/row["telemetry"]
                dest.mkdir(parents=True)
                def save(name,rows):
                    (dest/name).write_text("".join(json.dumps(x)+"\n" for x in rows))
                (dest/"scenario.json").write_text(json.dumps(dict(
                    selected_face_id=258,selected_relay_node_id=2,
                    selected_mid_node_id=7,selected_producer_node_id=8)))
                (dest/"P4P6_REVISED_DEV_PHYSICAL_AUDIT.json").write_text(json.dumps(dict(
                    seed=23201,site=row["site"],load=row["load"],telemetry=row["telemetry"],
                    physical={"all_devices_physical_queue_drops":1,
                              "physical_drops_by_role":{"relay":0,"mid":0,"producer":1}})))
                base=2_500_000_000
                decisions=[];local=[];td=[]
                for i in range(1,109):
                    t=base+(i-1)*10_000_000
                    decisions.append(dict(decision_id=i,pit_instance_id=i,time_ns=t,
                          name="/hcraf/pilot/"+str(i),candidates=[{"face_id":258,"routing_cost":1}]))
                    local.append(dict(decision_id=i,candidate_face_id=258,
                          observed_before_forwarding=True,remote_node_queue_accessed=False,
                          future_pressure_label=None,sim_time_ns=t,queue_packets=0,
                          local_queue_occupancy_fraction=0,link_up=True))
                    evidence=([{"source_node_id":src,"report_id":"r"+str(src)}
                               for src in (2,7,8)] if i<=6 else [])
                    missing=([{"source_node_id":src,"reason":"STALE_GT_100MS"}
                              for src in (2,7,8)] if i>6 else [])
                    td.append(dict(decision_id=i,decision_ns=t,
                                   feature_evidence=evidence,feature_missing_sources=missing))
                receipts=[dict(source_node_id=src,report_id="r"+str(src),
                     sample_ns=2_450_000_000,receipt_ns=2_460_000_000,
                     queue_packets_now=2,queue_drop_packets_total=0) for src in (2,7,8)]
                save("events.jsonl.decisions.jsonl",decisions)
                save("nfd_local_queue_at_decision.jsonl",local)
                save("queue_telemetry_decisions.jsonl",td)
                save("queue_telemetry_receipts.jsonl",receipts)
                save("pathwide_witness_b.jsonl",[{"event_type":"QUEUE_DROP","node_id":8,
                         "device_index":0,"timestamp_ns":base+1_000_000}])
                f,l=io.StringIO(),io.StringIO()
                result=table_builder.process_one(row,f,l)
                self.assertEqual((result["positive_75ms"],result["negative_75ms"]),(1,107))
                self.assertEqual((result["valid_remote_features"],result["missing_remote_features"]),(18,306))
                fs=[json.loads(x) for x in f.getvalue().splitlines()]
                ls=[json.loads(x) for x in l.getvalue().splitlines()]
                self.assertEqual(len(fs),108)
                self.assertEqual(len(ls),108)
                self.assertNotIn("retrospective_future_selected_path_QUEUE_DROP_75ms",fs[0])
                self.assertEqual(ls[0]["retrospective_future_selected_path_QUEUE_DROP_75ms"],1)
                self.assertEqual(ls[1]["retrospective_future_selected_path_QUEUE_DROP_75ms"],0)
                self.assertIsNone(fs[6]["allowed_decision_time_features"]["relay_queue_packets"])
                self.assertTrue(fs[6]["allowed_decision_time_features"]["relay_telemetry_missing"])
            finally:
                table_builder.DEST=original


if __name__=="__main__":unittest.main()
