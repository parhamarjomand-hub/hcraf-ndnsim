#!/usr/bin/env python3
"""v0.52.9 P4 REVISED four-independent-seed 48-cell DEVELOPMENT executor.

All v0.52.8 data, including consumed pilot 23101, are excluded from this
frozen 48-cell dataset. No official F3 label, model, PR-AUC or Validation/Test.
"""
import argparse
import csv
import json
from collections import Counter
from pathlib import Path
import subprocess

from run_stage1am_f3_p4_route_diversity_dev_v0527 import (
    physical_witness, check_decisions, ROLE_KEYS,
)
from generate_stage1am_f3_p4_revised_dev_schedules_v0529 import (
    STREAMS, SLOT, render, filename, schedule,
)
from generate_stage1am_f3_p4_revised_matrix_v0529 import render as render_matrix, rows as matrix_rows

ROOT = Path(__file__).resolve().parents[3]
DEST = ROOT / "episode_output/stage1am_f3_p4_revised_dev_v0529"
PLAN = ROOT / "hcraf/episode/docs/1AM/F3_P4_REVISED_DEVELOPMENT_v0.52.9/plans"
MATRIX = ROOT / "hcraf/episode/docs/1AM/F3_P4_REVISED_DEVELOPMENT_v0.52.9/RUN_MATRIX_LOCKED_144_v0529.csv"
BIN = "hcraf-stage1am-f3-p4-revised-dev-v0529"
SEEDS = tuple(sorted(STREAMS))
ARMS = (
    ("producer_egress", "PRODUCER_RETURN_12M", "PRODUCER_RETURN", "producer"),
    ("transit_middle", "MID_RETURN_12M", "MID_RETURN", "mid"),
    ("consumer_ingress", "RELAY_RETURN_12M", "RELAY_RETURN", "relay"),
)
LOADS = ("low_control", "high_pressure")
TELEMETRIES = (("off", False), ("on_20ms", True))
SCIENCE = dict(Congestion=None, FutureCongestion=None, F3_ready=False,
               GO_FREEZE=False, training_ready=False,
               heldout_release_authorized=False)


def check(condition, reason):
    if not condition:
        raise RuntimeError(reason)


def plan():
    check(set(STREAMS)=={23201,23202,23203,23204},"P4P6_FRESH_DEV_SPLIT_MODIFIED")
    check(set(SLOT.values())=={0,1,2},"P4P6_ROUTE_DIVERSITY_NOT_PRESERVED")
    result=[]
    for seed in SEEDS:
        for site,arm,location,role in ARMS:
            for load in LOADS:
                for telemetry,enabled in TELEMETRIES:
                    result.append(dict(seed=seed, site=site, arm=arm,
                                       location=location,role=role,load=load,
                                       telemetry=telemetry,enabled=enabled,
                                       selected_slot=SLOT[seed]))
    check(len(result)==48,"P4P6_EXPECT_EXACTLY_FORTY_EIGHT_DEVELOPMENT_CELLS")
    expected={(r["seed"],r["topology_profile"],r["load_profile"],r["telemetry_profile"])
              for r in matrix_rows() if r["execution_authorized"]=="true"}
    observed={(r["seed"],r["site"],r["load"],r["telemetry"]) for r in result}
    check(observed==expected,"P4P6_EXECUTOR_MATRIX_NOT_EXACTLY_THE_LOCKED_48_ROWS")
    return result


def check_locked_schedules():
    check(MATRIX.is_file() and MATRIX.read_bytes()==render_matrix(),
          "P4P6_REVISED_144_CONDITION_LOCK_CHANGED")
    locked=matrix_rows()
    check(len(locked)==144 and sum(r["execution_authorized"]=="true" for r in locked)==48,
          "P4P6_REVISED_MATRIX_EXECUTION_SCOPE_EXPANDED")
    for seed in sorted(STREAMS):
        for load in LOADS:
            path=PLAN/filename(seed,load)
            check(path.is_file() and path.read_bytes()==render(seed,load),
                  "P4P6_PREREG_SCHEDULE_CHANGED:"+str(path))
            rows=schedule(seed,load)
            check(len(rows)==108 and sum(x["traffic_class"]=="TARGET" for x in rows)==12,
                  "P4P6_EXPECT_TWELVE_TARGET_96_COMPETITOR")
    # Conditions with the same seed must have the same target timestamps.
    for seed in STREAMS:
        lo=[r["time_ns"] for r in schedule(seed,"low_control") if r["traffic_class"]=="TARGET"]
        hi=[r["time_ns"] for r in schedule(seed,"high_pressure") if r["traffic_class"]=="TARGET"]
        check(lo==hi,"P4P6_PAIRED_TARGET_TIMES_DIFFER_BY_LOAD")


def build_command(row,dest):
    traffic,routing,telemetry=STREAMS[row["seed"]]
    args=[f"--pathArm={row['arm']}",f"--interventionLocation={row['location']}",
          "--interventionReturnBps=12000000","--lossProbability=0",
          "--lossStream=79","--lossReceiverNodeId=-1","--lossReceiverDeviceIndex=-1",
          "--scheduleFamily=P4_REVISED_PROSPECTIVE",
          f"--scheduleCsv={PLAN/filename(row['seed'],row['load'])}",
          f"--prospectiveLoad={row['load']}",
          f"--prospectiveTrafficStreamSeed={traffic}",
          f"--prospectiveRoutingStreamSeed={routing}",
          f"--prospectiveTelemetryStreamSeed={telemetry}",
          f"--selectedSlot={row['selected_slot']}",f"--run={row['seed']}",
          f"--output={dest}","--instrument=1","--topology=DEV_CHAIN_L",
          "--mode=LP_INDEPENDENT_COMPETITOR_NO_DROP","--seed=17",
          "--lifetimeMs=2600","--requestCount=12","--intervalNs=30000000",
          "--competitorCount=96","--competitorIntervalNs=2000000",
          "--competitorOffsetNs=0","--targetOffsetNs=30000000",
          "--forwardBps=50000000","--returnBps=50000000",
          "--technicalQueueMaxPackets=12",
          f"--telemetryEnabled={int(row['enabled'])}","--telemetryPeriodMs=20"]
    return BIN+" "+" ".join(args)


def verify_sends(dest,seed,load):
    expected=schedule(seed,load)
    for klass,path in (("TARGET","consumer_events.jsonl"),
                       ("INDEPENDENT_COMPETITOR","competitor_events.jsonl")):
        ref={x["sequence"]:x["time_ns"] for x in expected if x["traffic_class"]==klass}
        events=[json.loads(x) for x in (dest/path).read_text().splitlines() if x]
        sent={int(e["name"].rsplit("/",1)[-1]):int(e["time_ns"])
              for e in events if e["event"]=="SEND"}
        arrives=[json.loads(x) for x in (dest/(path+".arrivals.jsonl")).read_text().splitlines() if x]
        arrived={int(x["sequence"]):int(x["time_ns"]) for x in arrives}
        check(ref==sent==arrived,"P4P6_RUNTIME_SEND_DID_NOT_MATCH_LOCKED_TRAFFIC")
        check({x["schedule"] for x in arrives}==
              {"F3_P4_V0529_REVISED_DEVELOPMENT_LOCKED_CSV"},
              "P4P6_WRONG_REVISED_SCHEDULE_PROVENANCE")


def verify_telemetry(dest,scenario,enabled):
    if not enabled:
        check(not (dest/"queue_telemetry_receipts.jsonl").exists() and
              not (dest/"queue_telemetry_decisions.jsonl").exists(),
              "P4P5_OFF_ARM_CONTAMINATED")
        return dict(enabled=False,real_received=0,unavailable_features=0)
    load=lambda name: [json.loads(x) for x in (dest/name).read_text().splitlines() if x]
    sent=load("queue_telemetry_sent.jsonl")
    requests=load("queue_telemetry_requests.jsonl")
    receipts=load("queue_telemetry_receipts.jsonl")
    decisions=load("queue_telemetry_decisions.jsonl")
    roles={int(scenario[k]) for k,_ in ROLE_KEYS}
    check(len(requests)>=2600 and len(sent)>=2600 and len(receipts)>=2500,
          "P4P5_TELEMETRY_TRANSPORT_INSUFFICIENT")
    check({x["source_node_id"] for x in receipts}==roles,
          "P4P5_MISSING_SELECTED_ROLE_RECEIPTS")
    check(len(decisions)==108,"P4P5_DECISION_TELEMETRY_COUNT_CHANGED")
    index={(x["source_node_id"],x["report_id"]):x for x in receipts}
    check(len(index)==len(receipts),"P4P5_DUPLICATE_TELEMETRY_RECEIPT")
    for r in receipts:
        check(0<=r["sample_ns"]<=r["receipt_ns"],"P4P5_TELEMETRY_SAMPLE_AFTER_RECEIPT")
    valid=missing=stale=0
    for d in decisions:
        here=set(); seen_missing=set()
        for item in d["feature_evidence"]:
            src=item["source_node_id"]
            check(src in roles and src not in here,"P4P5_DUPLICATE_FEATURE_SOURCE")
            r=index.get((src,item["report_id"]))
            check(r is not None,"P4P5_FEATURE_UNRECEIVED_SOURCE")
            check(r["sample_ns"]<=r["receipt_ns"]<=d["decision_ns"] and
                  d["decision_ns"]-r["sample_ns"]<=100000000,
                  "P4P5_CAUSALITY_OR_STALENESS_VIOLATION")
            here.add(src);valid+=1
        for item in d["feature_missing_sources"]:
            src=item["source_node_id"]
            check(src in roles and src not in seen_missing,
                  "P4P5_DUPLICATED_MISSING_SOURCE")
            check(item["reason"] in ("STALE_GT_100MS","UNRECEIVED"),
                  "P4P5_INVALID_MISSING_REASON")
            seen_missing.add(src);missing+=1
            stale+=int(item["reason"]=="STALE_GT_100MS")
        check(not here & seen_missing and here|seen_missing==roles,
              "P4P5_MISSINGNESS_NOT_AN_EXPLICIT_PARTITION")
    check(valid+missing==324,"P4P5_DECISION_ROLE_COVERAGE_CHANGED")
    return dict(enabled=True,requested=len(requests),sent=len(sent),
                real_received=len(receipts),observed_features=valid,
                unavailable_features=missing,stale_features=stale,
                causal_feature_leakage=False)


def one(row):
    dest=DEST/str(row["seed"])/row["site"]/row["load"]/row["telemetry"]
    dest.mkdir(parents=True,exist_ok=False)
    command=build_command(row,dest)
    (dest/"command.txt").write_text(command+"\n")
    (dest/"P4P5_LOCKED_CASE.json").write_text(json.dumps({**row,**SCIENCE},indent=2)+"\n")
    with (dest/"simulator.log").open("w") as log:
        subprocess.run(["/usr/bin/time","-f","wall_seconds=%e\\nmax_rss_kib=%M",
                        "-o",str(dest/"resource_usage.txt"),"python3","./waf",
                        "--run-no-build",command],
                       cwd=ROOT/"episode_sources/ns-3",stdout=log,
                       stderr=subprocess.STDOUT,check=True)
    scenario=json.loads((dest/"scenario.json").read_text())
    check(scenario["holdout_partition"]=="DEVELOPMENT" and
          scenario["independent_rng_block"]==row["seed"] and
          scenario["selected_face_slot"]==row["selected_slot"] and
          scenario["p4_prospective_load"]==row["load"] and
          scenario["phase_arm"]==row["arm"] and
          scenario["intervention_location"]==row["location"] and
          scenario["technical_queue_max_packets"]==12 and
          scenario["telemetry_enabled"]==row["enabled"] and
          scenario["official_F3_labels_constructed"]==0 and
          scenario["heldout_release_authorized"] is False and
          all(scenario[k] is v for k,v in SCIENCE.items()),
          "P4P6_RAN_WITH_WRONG_PHYSICAL_OR_SCIENTIFIC_CONFIGURATION")
    check(scenario["selected_face_id"]==258+row["selected_slot"],
          "P4P6_UNEXPECTED_FIB_FACE_ID")
    check_locked_schedules();verify_sends(dest,row["seed"],row["load"])
    observed=physical_witness(dest,scenario,row["role"])
    decisions=check_decisions(dest,scenario)
    transport=verify_telemetry(dest,scenario,row["enabled"])
    result=dict(**row,physical=observed,decisions=decisions,
                telemetry_transport=transport,
                off_target_queue_drops_retained=True,
                nonqueue_receiver_drops_do_not_count=True,
                official_F3_labels_constructed=0,
                F3_PR_AUC_computed=False,**SCIENCE)
    (dest/"P4P6_REVISED_DEV_PHYSICAL_AUDIT.json").write_text(json.dumps(result,indent=2)+"\n")
    return result


def main():
    p=argparse.ArgumentParser();p.add_argument("--preflight-only",action="store_true")
    args=p.parse_args();rows=plan();check_locked_schedules()
    if args.preflight_only:
        print(json.dumps(dict(status="PASS_FORTY_EIGHT_REVISED_DEVELOPMENT_PREFLIGHT_ONLY",
             conditions=rows,development_seeds=list(SEEDS),
             routing_slots_by_seed=SLOT,executed_simulations=0,
             previously_consumed_seed_23101_excluded=True,
             validation_test_executable=False,official_F3_labels_constructed=0,
             **SCIENCE),indent=2))
        return
    check((ROOT/"episode_sources/ns-3/build/scratch"/BIN).is_file(),
          "P4P6_NEW_CPP_BINARY_MISSING")
    check(not DEST.exists(),"P4P6_REFUSE_OVERWRITE_PREVIOUS_DEVELOPMENT_MATRIX")
    results=[]
    for row in rows:
        r=one(row);results.append(r)
        print("P4P6_RUN",len(results),"/48",r["seed"],r["site"],r["load"],r["telemetry"],
              r["physical"]["physical_drops_by_role"],flush=True)
    high=[r for r in results if r["load"]=="high_pressure"]
    low=[r for r in results if r["load"]=="low_control"]
    high_target=all(r["physical"]["physical_drops_by_role"][r["role"]]>0 for r in high)
    low_negative=all(r["physical"]["all_devices_physical_queue_drops"]==0 for r in low)
    telemetry_ok=all(r["telemetry_transport"].get("causal_feature_leakage") is False
                     for r in results if r["enabled"])
    summary=dict(status="PASS_REVISED_DEV_FOUR_SEEDS_PHYSICAL_ONLY" if high_target and low_negative and telemetry_ok
                 else "NO_GO_REVISED_DEV_FOUR_SEEDS_PHYSICAL_OR_CONTROL_FAILURE",
         seeds=list(SEEDS),routing_slots_by_seed=SLOT,num_simulations=len(results),
         high_target_drop_positive=high_target,low_controls_have_zero_queue_drop=low_negative,
         causal_telemetry_pass=telemetry_ok,previously_consumed_seed_23101_excluded=True,
         validation_test_executable=False,official_F3_labels_constructed=0,
         F3_PR_AUC_computed=False,results=results,**SCIENCE)
    (DEST/"P4P6_REVISED_DEVELOPMENT_SUMMARY.json").write_text(json.dumps(summary,indent=2)+"\n")
    print(json.dumps({k:v for k,v in summary.items() if k!="results"},indent=2),flush=True)


if __name__=="__main__":main()
