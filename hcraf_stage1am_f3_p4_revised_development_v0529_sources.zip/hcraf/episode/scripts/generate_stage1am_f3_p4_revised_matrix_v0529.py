#!/usr/bin/env python3
"""Generate the separate 144-cell v0.52.9 matrix without executing heldout.

Only development entries have executable pre-generated traffic plans; the
unchanged v0.52.4 Validation/Test seed blocks are reserved, with no schedule
file and no authorization. Never consume the previous v0.52.8 pilot seeds.
"""
import argparse
import csv
from io import StringIO
from pathlib import Path

from generate_stage1am_f3_p4_revised_dev_schedules_v0529 import SLOT, filename

SPLITS = {
    "development":(23201,23202,23203,23204),
    "validation":(24101,24102,24103,24104),
    "heldout":(25101,25102,25103,25104),
}
SITES=("producer_egress","transit_middle","consumer_ingress")
LOADS=("low_control","high_pressure")
TELEMETRY=("off","on_20ms")
COLUMNS=("run_key","split","independence_block","seed","topology_profile",
         "load_profile","telemetry_profile","selected_slot_locked",
         "queue_capacity_packets_candidate","horizon_ms","schedule_filename",
         "execution_authorized","protected_original_v0524_design_unchanged",
         "scientific_lock_status")


def rows():
    out=[]
    for split,seeds in SPLITS.items():
        for seed in seeds:
            for site in SITES:
                for load in LOADS:
                    for telemetry in TELEMETRY:
                        allowed=split=="development"
                        out.append(dict(zip(COLUMNS,(
                          f"P4_v0529_{split}_{seed}_{site}_{load}_{telemetry}",
                          split,f"{split}-seed-{seed}",seed,site,load,telemetry,
                          SLOT[seed] if allowed else "UNRELEASED",
                          12,75,filename(seed,load) if allowed else "UNRELEASED",
                          "true" if allowed else "false","true",
                          "null_F3_ready_false_heldout_not_released"))))
    assert len(out)==144 and len({x["run_key"] for x in out})==144
    assert sum(x["execution_authorized"]=="true" for x in out)==48
    assert sum(x["execution_authorized"]=="false" for x in out)==96
    assert not any(x["execution_authorized"]=="true" and x["split"]!="development" for x in out)
    return out


def render():
    o=StringIO(newline="")
    w=csv.DictWriter(o,fieldnames=COLUMNS,lineterminator="\n")
    w.writeheader();w.writerows(rows())
    return o.getvalue().encode("ascii")


def main():
    a=argparse.ArgumentParser();a.add_argument("--output",required=True)
    path=Path(a.parse_args().output)
    if path.exists():raise SystemExit("P4P6_REFUSE_TO_OVERWRITE_LOCKED_MATRIX")
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(render())
    print("PASS_IMMUTABLE_V0529_MATRIX_144_48_DEV_AUTHORIZED_96_PROTECTED")


if __name__=="__main__":main()
