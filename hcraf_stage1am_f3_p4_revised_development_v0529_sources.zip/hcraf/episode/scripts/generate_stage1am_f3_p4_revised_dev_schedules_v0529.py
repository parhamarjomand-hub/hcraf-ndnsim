#!/usr/bin/env python3
"""Pure reproducible v0.52.9 REVISED DEVELOPMENT schedule generator.

No simulation, no P4 Validation/Test access. Four fresh development-only RNG
streams are derived by SHA-256 domain separation, wholly distinct from the
historical fixture and the v0.52.8 contaminated feasibility pilot.
"""
import argparse
import csv
from io import StringIO
import hashlib
import random
from pathlib import Path

NEW_SEEDS = (23201,23202,23203,23204)
STREAM_DOMAIN="HCRAF-STAGE1AM-F3-P4-v0.52.9:development"


def derive(seed,stream):
    if seed not in NEW_SEEDS or stream not in ("traffic","routing","telemetry"):
        raise ValueError("P4P6_OUTSIDE_NEW_DEVELOPMENT_STREAM_DOMAIN")
    digest=hashlib.sha256(f"{STREAM_DOMAIN}:{seed}:{stream}".encode("ascii")).digest()
    return int.from_bytes(digest[:4],"big")&0x7fffffff


STREAMS={seed:tuple(derive(seed,s) for s in ("traffic","routing","telemetry"))
         for seed in NEW_SEEDS}
ORDER = sorted(STREAMS, key=lambda n: STREAMS[n][1])
# A split-internal, preregistered stream-based permutation prevents the
# erroneous modular rule from omitting a physical branch altogether.
SLOT = {seed: i % 3 for i, seed in enumerate(ORDER)}
FIELDNAMES = (
    "traffic_class", "sequence", "time_ns", "family", "rng_block", "split",
    "phase_label", "phase_nominal_ns", "phase_jitter_ns", "selected_slot",
    "load_level", "schedule_schema",
)
FAMILY = "P4_REVISED_PROSPECTIVE"
SCHEMA = "HCRAF_F3_P4_REVISED_DEVELOPMENT_V0529"
NS = 1_000_000_000


def filename(seed, load):
    return f"p4-v0529-development-seed-{seed}-slot-{SLOT[seed]}-{load}.csv"


def schedule(seed, load):
    if seed not in STREAMS or load not in {"low_control", "high_pressure"}:
        raise ValueError("P4P6_UNREGISTERED_REVISED_DEVELOPMENT_SEED_OR_LOAD")
    rnd = random.Random(STREAMS[seed][0])
    result = []
    def put(kind, seq, at, phase, nominal, jitter):
        if not 2*NS <= at < 19*NS:
            raise AssertionError("P4P6_SCHEDULE_OUT_OF_BOUND")
        result.append(dict(zip(FIELDNAMES, (
            kind, seq, at, FAMILY, seed, "DEVELOPMENT", phase, nominal,
            jitter, SLOT[seed], load, SCHEMA))))
    # Historical v0.52.7 slot-2 had BOTH 75ms window classes under a single
    # ~360ms competitor pulse. Prospectively derive independent timestamps
    # from a new seed; never replay the historical CSV or seed 23101.
    # Four new development blocks each have twelve pair-matched target times.
    target = [int((2.52 + 0.03*j)*NS) + rnd.randint(-3_000_000, 3_000_000)
              for j in range(12)]
    for seq, t in enumerate(target):
        put("TARGET", seq, t, "P0", 0, 0)
    if load == "high_pressure":
        # One moderate 96-interest pulse over ~340ms (3.6ms spacing),
        # motivated ONLY by historical P3/P4-P4 physical observations.
        # The fresh seed changes individual arrival times ex ante.
        competitor = [int((2.37+0.0036*j)*NS) + rnd.randint(-300_000,300_000)
                      for j in range(96)]
    else:
        # Same 96-interest count, spread over 16 seconds: explicit load
        # control, never chosen using physical outcome observations.
        competitor = [int((2.35 + (16.10/95)*j)*NS) + rnd.randint(-10_000_000,10_000_000)
                      for j in range(96)]
    for seq, t in enumerate(competitor):
        put("INDEPENDENT_COMPETITOR",seq,t,"P0",0,0)
    assert len(result)==108
    assert len({(x["traffic_class"],x["sequence"]) for x in result})==108
    return result


def render(seed, load):
    o=StringIO(newline="")
    writer=csv.DictWriter(o,fieldnames=FIELDNAMES,lineterminator="\n")
    writer.writeheader(); writer.writerows(schedule(seed,load))
    return o.getvalue().encode("ascii")


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--output-dir",required=True)
    args=p.parse_args()
    base=Path(args.output_dir)
    if base.exists() and any(base.iterdir()):
        raise SystemExit("REFUSE_OVERWRITE_LOCKED_PROSPECTIVE_SCHEDULES")
    base.mkdir(parents=True,exist_ok=True)
    for seed in sorted(STREAMS):
        for load in ("low_control","high_pressure"):
            (base/filename(seed,load)).write_bytes(render(seed,load))
    print("PASS_EIGHT_REVISED_PROSPECTIVE_DEVELOPMENT_SCHEDULES_108_EACH",SLOT)


if __name__ == "__main__":
    main()
