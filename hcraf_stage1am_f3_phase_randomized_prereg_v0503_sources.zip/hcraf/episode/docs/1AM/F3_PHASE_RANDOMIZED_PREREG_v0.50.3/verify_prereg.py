#!/usr/bin/env python3
"""Fail-closed inspection of locked v0.50.3 experiment schedule (no ns3)."""
import argparse
import collections
import csv
import hashlib
import json
from pathlib import Path
from generate_phase_prereg import (RNGS, FAMILIES, ARMS, PHASES_MS,
                                   SCHEDULE_FIELDS, MATRIX_FIELDS, INDEX_FIELDS,
                                   verify_against_disk)


def read_csv(path):
    with path.open(newline='',encoding='utf-8') as f:
        reader=csv.DictReader(f)
        return list(reader),tuple(reader.fieldnames or ())

def verify(root: Path):
    root=root.resolve()
    gen=verify_against_disk(root)
    rows, fields=read_csv(root/'RUN_MATRIX_LOCKED_168.csv')
    assert fields == MATRIX_FIELDS, 'MATRIX_SCHEMA'
    index, fields=read_csv(root/'SCHEDULE_INDEX_LOCKED_48.csv')
    assert fields == INDEX_FIELDS, 'INDEX_SCHEMA'
    assert len(rows)==168 and len(index)==48, 'MATRIX_SIZE'
    assert len(set(r['run_id'] for r in rows)) == 168, 'DUPLICATE_RUN'
    expected = set(RNGS)
    assert {int(r['rng_block']) for r in rows} == expected, 'RNG_SET_CHANGED'
    bykey=collections.defaultdict(list)
    for r in rows:
        key=(r['rng_block'],r['family'])
        bykey[key].append(r)
        assert int(r['seed'])==17 and r['status']=='PREREG_PLANNED_NOT_RUN', 'RUN_NOT_PREREG'
        assert int(r['selected_slot'])==(int(r['rng_block'])-11701)%3, 'SLOT_MISMATCH'
        assert r['family'] in FAMILIES, 'UNREGISTERED_FAMILY'
        assert r['arm'] in dict(ARMS), 'UNREGISTERED_ARM'
        assert int(r['return_link_bps'])==dict(ARMS)[r['arm']], 'CAPACITY_MISMATCH'
        assert r['instrumented'] in {'0','1'}, 'INSTRUMENT_FIELD'
    assert len(bykey)==48, 'UNEXPECTED_RNG_FAMILY'
    unmon=[r for r in rows if r['instrumented']=='0']
    mon=[r for r in rows if r['instrumented']=='1']
    assert len(mon)==144 and len(unmon)==24, 'RUN_COUNTS'
    assert collections.Counter(r['rng_block'] for r in unmon)==collections.Counter(map(str,RNGS)), 'UNMON_RNG_NONUNIQUE'
    assert all(v==1 for v in collections.Counter((r['phase_label'],r['family'],r['arm']) for r in unmon).values()), 'UNMON_PHASE_BALANCE'
    assert len({(r['phase_label'],r['family'],r['arm']) for r in unmon})==24, 'UNMON_CELL_COVERAGE'
    phase_by_rng={}
    for (rng,family),rs in bykey.items():
        monitored=[r for r in rs if r['instrumented']=='1']
        assert len(monitored)==3, 'MISSING_MATCHED_CAPACITY'
        for field in ('schedule_sha256','target_schedule_sha256','competitor_schedule_sha256',
                      'plan_filename','phase_label','phase_nominal_ns','phase_jitter_ns'):
            assert len({r[field] for r in rs})==1, 'NOT_MATCHED:'+field
        phase_by_rng.setdefault(rng,monitored[0]['phase_label'])
        assert phase_by_rng[rng]==monitored[0]['phase_label'], 'PHASE_DIFFERS_BETWEEN_FAMILIES'
    assert collections.Counter(phase_by_rng.values())=={'P0':6,'P1':6,'P2':6,'P3':6}, 'PHASE_BALANCE'
    assert all(collections.Counter(int(rng)%3 for rng,p in phase_by_rng.items() if p==f'P{phase}')==
               collections.Counter({int(11701)%3:2,int(11702)%3:2,int(11703)%3:2})
               for phase in range(4)), 'PHASE_SLOT_BALANCE'
    byidx={(r['rng_block'],r['family']):r for r in index}
    assert len(byidx)==48, 'DUPLICATE_INDEX'
    for key,idx in byidx.items():
        assert key in bykey,'INDEX_UNKNOWN_KEY'
        for col in ('plan_filename','schedule_sha256','target_schedule_sha256',
                    'competitor_schedule_sha256','phase_label','phase_nominal_ns','phase_jitter_ns'):
            assert idx[col]==bykey[key][0][col], 'INDEX_INCONSISTENT:'+col
        plan=root/idx['plan_filename']
        assert plan.resolve().is_relative_to(root),'PLAN_PATH_ESCAPE'
        data, cols=read_csv(plan)
        assert cols==SCHEDULE_FIELDS and len(data)==108,'PLAN_LAYOUT'
        assert collections.Counter(r['traffic_class'] for r in data)=={'TARGET':12,'INDEPENDENT_COMPETITOR':96},'TRAFFIC_COUNTS'
        for cls in ('TARGET','INDEPENDENT_COMPETITOR'):
            times=sorted(int(r['time_ns']) for r in data if r['traffic_class']==cls)
            assert all(2_000_000_000 <= n < 20_000_000_000 for n in times),'OUT_OF_SIM_TIME'
            assert all(a<b for a,b in zip(times,times[1:])),'NONMONOTONE_TIMES'
        assert len({(r['rng_block'],r['family'],r['phase_label'],r['selected_slot']) for r in data})==1,'MIXED_PLAN_METADATA'
        assert hashlib.sha256(plan.read_bytes()).hexdigest()==idx['schedule_sha256'],'SCHEDULE_HASH_MISMATCH'
    locks=json.loads((root/'SCIENCE_LOCKS.json').read_text())
    assert locks['Congestion'] is None and locks['FutureCongestion'] is None
    assert locks['F3_ready'] is False and locks['GO_FREEZE'] is False and locks['training_ready'] is False
    assert locks['construct_status']=='NO_GO_F3_CONSTRUCT_AND_PREDICTABILITY_NOT_VALIDATED'
    assert locks['allowed_stage']=='PREREG_ONLY_NO_NDNSIM_RUN'
    return {'status':'PASS_PROSPECTIVE_PREREG_CONTRACT_ONLY','run_counts':{'total':168,'monitored':144,'unmonitored':24},
            'rng_blocks':24,'phase_counts':dict(collections.Counter(phase_by_rng.values())),
            'schedule_count':len(byidx),'science_locks':locks,
            'locked_schedule_manifest_sha256':hashlib.sha256((root/'SCHEDULE_INDEX_LOCKED_48.csv').read_bytes()).hexdigest(),
            'locked_run_matrix_sha256':hashlib.sha256((root/'RUN_MATRIX_LOCKED_168.csv').read_bytes()).hexdigest(),
            'generator_consistency':gen['locked_file_count']}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('contract_root',type=Path)
    ap.add_argument('--output',type=Path)
    args=ap.parse_args()
    output=verify(args.contract_root)
    content=json.dumps(output,ensure_ascii=False,indent=2,sort_keys=True)+'\n'
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(content)
    print(content)

if __name__=='__main__':
    main()
