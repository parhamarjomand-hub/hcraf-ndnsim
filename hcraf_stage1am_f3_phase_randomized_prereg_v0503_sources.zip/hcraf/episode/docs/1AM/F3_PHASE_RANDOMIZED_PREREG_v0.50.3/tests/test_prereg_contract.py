import collections
import csv
import importlib.util
import json
import pathlib
import shutil
import sys
import tempfile
import unittest

ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import generate_phase_prereg as gen
import verify_prereg as ver

class PreregContractTests(unittest.TestCase):
    def test_sanity(self):
        self.assertEqual(ver.verify(ROOT)['status'],'PASS_PROSPECTIVE_PREREG_CONTRACT_ONLY')
    def test_rng_exact_range(self):
        self.assertEqual(gen.RNGS,tuple(range(11701,11725)))
        self.assertTrue(set(gen.RNGS).isdisjoint(range(11601,11613)))
    def test_alphabet_of_conditions(self):
        self.assertEqual(len(gen.FAMILIES),2)
        self.assertEqual([bps for _,bps in gen.ARMS],[6_000_000,12_000_000,50_000_000])
    def test_new_rng_blocks_independent_of_previous(self):
        self.assertTrue(min(gen.RNGS)>11612)
    def test_phase_balance_over_rng(self):
        phases,_=gen.allocation()
        self.assertEqual(collections.Counter(phases.values()),{0:6,1:6,2:6,3:6})
    def test_phase_balanced_per_slot(self):
        phases,_=gen.allocation()
        for slot in range(3):
            self.assertEqual(collections.Counter(phases[r] for r in gen.RNGS if (r-11701)%3==slot),{0:2,1:2,2:2,3:2})
    def test_control_once_per_rng(self):
        _,controls=gen.allocation()
        self.assertEqual(len(controls),24)
        self.assertEqual(set(controls),set(gen.RNGS))
    def test_control_cells_balanced_by_phase(self):
        phases,controls=gen.allocation()
        c=collections.Counter((phases[r],*controls[r]) for r in gen.RNGS)
        self.assertEqual(len(c),24)
        self.assertEqual(set(c.values()),{1})
    def test_total_schedule_set(self):
        files=gen.build_files()
        self.assertEqual(sum(k.startswith('plans/') for k in files),48)
    def test_target_and_competitor_count(self):
        rows,_,_=gen.build_plan(11701,'A_SHIFTED_PULSES',0)
        self.assertEqual(collections.Counter(x['traffic_class'] for x in rows),{'TARGET':12,'INDEPENDENT_COMPETITOR':96})
    def test_target_intervals_positive(self):
        for r in gen.RNGS:
            for f in gen.FAMILIES:
                phase=gen.allocation()[0][r]
                rows,_,_=gen.build_plan(r,f,phase)
                for cls in ['TARGET','INDEPENDENT_COMPETITOR']:
                    times=sorted(x['time_ns'] for x in rows if x['traffic_class']==cls)
                    self.assertTrue(all(b>a for a,b in zip(times,times[1:])))
    def test_no_labels_in_matrix(self):
        self.assertFalse(any('outcome' in x.lower() or 'futurecongestion' in x.lower() or 'candidate_label' in x.lower() for x in gen.MATRIX_FIELDS))
    def test_phase_shift_changes_relative_burst(self):
        times=[]
        for p in range(4):
            _,t,c=gen.build_plan(11701,'A_SHIFTED_PULSES',p)
            times.append(c-t)
        self.assertEqual(len(set(times)),4)
        self.assertTrue(all(b>a for a,b in zip(times,times[1:])))
    def test_repeatable_generation(self):
        self.assertEqual(gen.build_files(),gen.build_files())
    def test_tamper_detection(self):
        with tempfile.TemporaryDirectory() as d:
            temp=pathlib.Path(d)
            for name,content in gen.build_files().items():
                dst=temp/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(content)
            path=temp/'plans/rng-11701_A_SHIFTED_PULSES.csv'
            path.write_bytes(path.read_bytes()+b'bad\n')
            with self.assertRaises(AssertionError):gen.verify_against_disk(temp)
    def test_missing_plan_detection(self):
        with tempfile.TemporaryDirectory() as d:
            temp=pathlib.Path(d)
            for name,content in gen.build_files().items():
                dst=temp/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(content)
            (temp/'plans/rng-11701_A_SHIFTED_PULSES.csv').unlink()
            with self.assertRaises(AssertionError):gen.verify_against_disk(temp)
    def test_scientific_locks(self):
        locks=json.loads((ROOT/'SCIENCE_LOCKS.json').read_text())
        self.assertEqual(locks['construct_status'],'NO_GO_F3_CONSTRUCT_AND_PREDICTABILITY_NOT_VALIDATED')
        for n in ('F3_ready','GO_FREEZE','training_ready'):self.assertIs(locks[n],False)
        for n in ('Congestion','FutureCongestion'):self.assertIsNone(locks[n])
    def test_no_status_run(self):
        with (ROOT/'RUN_MATRIX_LOCKED_168.csv').open(newline='') as f:
            rows=list(csv.DictReader(f))
        self.assertEqual({r['status'] for r in rows},{'PREREG_PLANNED_NOT_RUN'})

if __name__=='__main__': unittest.main()
