# تحویل HCRAF F3 v0.50.3 — فقط پیش‌ثبت، بدون اجرای ndnSIM

این پوشه حاوی پروتکل اصلی، ۴۸ جدول برنامه ارسال ثابت، جدول ۱۶۸ Run، آزمون‌های محلی و محافظ‌های علمی F3 است. کلیه زمان‌ها قبل از تولید داده جدید ایجاد و هش‌شده‌اند.

**وضعیت:** `CONTRACT_READY_AWAITING_GIT_COMMIT`, نه نتیجه آزمایش و نه تأیید F3.

برای بررسی در محیطی با Python3:

```bash
python3 generate_phase_prereg.py --verify .
python3 verify_prereg.py . --output prereg_report.json
python3 -m unittest discover -s tests -p 'test_*.py' -v
```

این دستورات باید در خود پوشه قرارداد اجرا شوند. `--verify` هیچ خروجی قفل‌شده‌ای را تغییر نمی‌دهد.

GitHub Package بیرونی شامل ZIP داخلی منابع و یک فایل `workflow/*.txt` است. ZIP داخلی باید **بدون استخراج** در ریشه مخزن خصوصی قرار گیرد، و متن workflow در YAML تازه قرار بگیرد. Workflow صرفاً hash/contract/tests را بررسی و Artifact پیش‌ثبت را ذخیره می‌کند؛ نه C++ می‌سازد و نه شبیه‌سازی انجام می‌دهد.

**توجه:** تا زمانی که فایل‌ها در Git Commit و پیش از اجرای آزمایش جدید زمان‌دار نشده باشند، پیش‌ثبت به‌صورت عملی نهایی نیست. شماره Run موفق قدیمی دوباره اجرا نشود؛ هیچ برچسب FutureCongestion تولید نشده است.
