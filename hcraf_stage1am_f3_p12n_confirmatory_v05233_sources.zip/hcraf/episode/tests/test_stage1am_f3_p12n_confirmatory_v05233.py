"""Pre-outcome, no-data-peek science regression fences for the once-only P12K analysis."""
import importlib.util,json,unittest,random
from pathlib import Path
SRC=Path('hcraf/episode/scripts/run_stage1am_f3_p12n_confirmatory_v05233.py')
spec=importlib.util.spec_from_file_location('p12n_once',SRC);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

class P12NPreregScientificFences(unittest.TestCase):
    def test_exact_p12k_snapshot_sha(self):
        p,model=m.load_frozen()
        self.assertEqual(p['physical_case_count'],432)
        self.assertEqual(p['primary_episodes_planned'],27648)
        self.assertEqual(model['trained_on_seeds'],list(range(24501,24507)))
    def test_original_full_432_case_matrix_sha(self):
        mat=m.load_matrix();self.assertEqual(len(mat),432)
        self.assertEqual(len({k[0] for k in mat}),36)
        self.assertEqual(len({(k[0],k[1],k[2]) for k in mat}),216)
    def test_heldout_validation_dev_disjoint(self):
        s=set(m.SEEDS)
        self.assertFalse(s.intersection(range(24501,24507)))
        self.assertFalse(s.intersection(range(24601,24605)))
        self.assertFalse(s.intersection(range(24701,24705)))
    def test_no_model_fitting_or_retraining_in_code(self):
        s=SRC.read_text()
        self.assertNotIn('sklearn',s)
        self.assertNotIn('LogisticRegression(',s)
        self.assertIn('no_AP_or_model_scoring_this_job',s)
        self.assertIn('bootstrap_invalid_resamples',s)
    def test_feature_order_locked(self):
        _,model=m.load_frozen()
        self.assertEqual(tuple(model['local_model']['names']),m.FEATURES[:4])
        self.assertEqual(tuple(model['remote_model']['names']),m.FEATURES)
    def test_historical_p12h_prediction_known_row(self):
        _,model=m.load_frozen()
        f={k:0.0 for k in m.FEATURES}
        f.update(fib_route_cost=1,local_selected_link_up=1,
                 relay_telemetry_missing=0,mid_telemetry_missing=0,
                 producer_telemetry_missing=0)
        # Exact historical validation first-row local score, not prospective data.
        self.assertAlmostEqual(m.score_one({k: str(v) for k,v in f.items()},model['local_model']),
                               0.06191362074288229,places=14)
    def test_grouped_AP_tied_score_not_rank_splitting(self):
        a=[(24801,1,0.4,0.4),(24801,0,0.4,0.4),(24801,0,0.1,0.1),(24801,1,0.0,0.0)]
        # First tie has precision 1/2. Recall increases one of two positives.
        # Last precision 2/4. Expected AP=(0.5+0.5)/2=0.5.
        self.assertAlmostEqual(m.ap_grouped(a,2),.5)
        self.assertEqual(m.ap_grouped([(24801,0,.2,.1)],2),None)
    def test_bootstrap_weighted_equals_literal_block_resample(self):
        a=[(24801+(i%5),int(i%11==0),float(i%17),float(i%23)) for i in range(470)]
        for ix in (2,3):
            g=m.score_tie_groups(a,ix)
            weights=[0]*36
            for i in range(5):weights[i]=i+1
            literal=[r for r in a for _ in range(weights[r[0]-24801])]
            self.assertAlmostEqual(m.ap_from_cluster_weights(g,weights),m.ap_grouped(literal,ix))
    def test_q_975_10000_linear_bounds(self):
        a=list(range(10000))
        self.assertAlmostEqual(m.quantile_linear(a,.0125),124.9875)
        self.assertAlmostEqual(m.quantile_linear(a,.9875),9874.0125)
    def test_seed_gate_count_strict(self):
        p,_=m.load_frozen()
        self.assertIn('At least 27 of 36',p['replication_success_gates_all_required'][2])
    def test_bootstrap_replicates_and_rng_locked(self):
        p,_=m.load_frozen();b=p['bootstrap']
        self.assertEqual((b['replicates'],b['rng_seed'],b['lower_percentile'],b['upper_percentile']),
                         (10000,525250,.0125,.9875))
    def test_fail_closed_on_missing_source(self):
        with self.assertRaisesRegex(RuntimeError,'P12N_FAIL_CLOSED'):
            m.require(False,'UNIT_TEST_TAMPERED_RECEIPT')
    def test_p12m_historical_no_go_fences(self):
        p,_=m.load_frozen()
        self.assertFalse(p['scientific_locks']['F3_ready'])
        self.assertFalse(p['scientific_locks']['GO_FREEZE'])
        self.assertFalse(p['scientific_locks']['Stage1AO_or_NSGAIII_authorized'])
        self.assertFalse(p['scientific_locks']['heldout_release_authorized'])
    def test_no_prospective_ap_in_extractor(self):
        import inspect
        x=inspect.getsource(m.extract)
        self.assertNotIn('ap_grouped(',x)
        self.assertNotIn('score_one(',x)
    def test_strict_horizon_bounds(self):
        t=5_000_000_000
        events=[t,t+1,t+75_000_000,t+75_000_001]
        valid=[x for x in events if t<x<=t+75_000_000]
        self.assertEqual(valid,[t+1,t+75_000_000])

if __name__=='__main__': unittest.main()
