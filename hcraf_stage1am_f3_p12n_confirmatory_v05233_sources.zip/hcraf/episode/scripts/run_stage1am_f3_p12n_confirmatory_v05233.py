#!/usr/bin/env python3
"""P12N. 36-seed, one-time, P12K-locked F3 confirmatory replication.

The EXTRACT subcommand emits only features + prospective labels (NEVER scores/AP).
The SCORE subcommand runs once after six complete verified extract artifacts.
No model fitting; historical P12H NO_GO and heldout protection stay immutable.
"""
import argparse,collections,csv,hashlib,io,json,math,random,sys,zipfile
from pathlib import Path

DOC=Path('hcraf/episode/docs/1AM/F3_P12N_CONFIRMATORY_v0.52.33')
PLAN_HASH='27000d312d3c282e7aa574f70eb6a77c17989166612db88807d389b4bb70823a'
MODEL_HASH='de46e2f5fcb052f96e920729664084ad0edd029cc4af88b2c5480209976a35d1'
MATRIX_HASH='bebf302b14bd2096e63b8915c640f2db43e069de990f3832a0a98258b6688cbc'
SCHEDULE_COMMITMENT_HASH='c99052597c0f028e3c24843dd781ce6b5cbbd8b0c30e9b7184f385e68d6d6c4b'
SEEDS=tuple(range(24801,24837)); SITES=('producer_egress','transit_middle','consumer_ingress')
LOADS=('low_control','high_pressure'); ARMS=('off','on_20ms')
LOCKS={'Congestion':None,'FutureCongestion':None,'F3_ready':False,'GO_FREEZE':False,
       'training_ready':False,'heldout_release_authorized':False,'Stage1AO_or_NSGAIII_authorized':False}
META=('row_key','seed','site','load','telemetry','decision_ns','decision_id','pit_instance_id','selected_face_id','traffic_type')
FEATURES=('fib_route_cost','local_selected_queue_packets','local_selected_queue_fraction','local_selected_link_up',
'relay_queue_packets','relay_telemetry_missing','relay_telemetry_age_ms',
'mid_queue_packets','mid_telemetry_missing','mid_telemetry_age_ms',
'producer_queue_packets','producer_telemetry_missing','producer_telemetry_age_ms')
COLUMNS=('row_key','seed','site','load','telemetry','y')+FEATURES


def require(test,msg):
    if not test:raise RuntimeError('P12N_FAIL_CLOSED_'+str(msg))

def sha(data):return hashlib.sha256(data).hexdigest()

def load_frozen():
    raw=(DOC/'P12M_prereg/P12K_ANALYSIS_PLAN_FROZEN_v05225.json').read_bytes()
    require(sha(raw)==PLAN_HASH,'PREREG_PLAN_SHA_MISMATCH');plan=json.loads(raw)
    raw=(DOC/'P12M_prereg/P12K_PINNED_P12H_FROZEN_MODELS.json').read_bytes()
    require(sha(raw)==MODEL_HASH,'FROZEN_MODEL_SHA_MISMATCH');model=json.loads(raw)
    require(plan['seed_blocks']==list(SEEDS),'PREREG_SEED_SET_CHANGED')
    require(plan['primary_episodes_planned']==27648 and plan['physical_case_count']==432,'PREREG_CASE_MATRIX_CHANGED')
    require(plan['primary_endpoint']=='pooled Average Precision of remote frozen model minus pooled Average Precision of local frozen model over complete active_20ms arm','PREREG_PRIMARY_CHANGED')
    require(plan['AP_definition'].startswith('tie-grouped non-interpolated Average Precision'),'AP_DEFINITION_CHANGED')
    require(plan['bootstrap']['replicates']==10000 and plan['bootstrap']['rng_seed']==525250,'BOOTSTRAP_LOCK_CHANGED')
    require(plan['bootstrap']['lower_percentile']==.0125 and plan['bootstrap']['upper_percentile']==.9875,'BOOTSTRAP_TAIL_CHANGED')
    require(plan['bootstrap']['atomic_cluster']=='seed_block','CLUSTER_LOCK_CHANGED')
    require(plan['future_horizon_ns']==75_000_000,'HORIZON_CHANGED')
    require(plan['no_retraining_or_refitting'] and plan['future_labels_not_features'],'MODEL_FREEZE_CHANGED')
    receipt=json.loads((DOC/'P12M_INTEGRATED_SIGNED_QC_FROM_GITHUB.json').read_text())
    require(receipt['status']=='PASS_P12M_INDEPENDENT_ALL_36_SEEDS_432_CASES_RAW_QC_ONLY','P12M_PARENT_QC_STATUS')
    require(receipt['seed_count']==36 and receipt['case_count']==432,'P12M_PARENT_QC_COUNTS')
    require(receipt['seeds']==list(SEEDS) and receipt['raw_archives_revalidated']==36,'P12M_PARENT_SEEDS')
    require(receipt['raw_files_sha_checked']==17316 and receipt['episodes']==55296,'P12M_PARENT_RAW_QC')
    require(receipt['interim_AP_computed'] is False and receipt['model_fits']==0,'P12M_PARENT_NO_PEEK')
    require(receipt['previous_P12H_validation']=='NO_GO','HISTORICAL_NO_GO_MISSING')
    require(model['trained_on_seeds']==list(range(24501,24507)),'MODEL_TRAINING_SEEDS_CHANGED')
    require(tuple(model['local_model']['names'])==FEATURES[:4],'LOCAL_FEATURES_CHANGED')
    require(tuple(model['remote_model']['names'])==FEATURES,'REMOTE_FEATURES_CHANGED')
    for k,v in LOCKS.items():require(plan['scientific_locks'].get(k) is v and model.get(k,v) is v,'SCIENCE_LOCK_'+k)
    return plan,model

def load_matrix():
    p=DOC/'P12M_prereg/P12K_LOCKED_MATRIX_432_v05225.csv'
    require(sha(p.read_bytes())==MATRIX_HASH,'PREREG_MATRIX_SHA_MISMATCH')
    schedules=DOC/'P12M_prereg/P12K_FROZEN_SCHEDULE_COMMITMENTS_216_v05225.json'
    require(sha(schedules.read_bytes())==SCHEDULE_COMMITMENT_HASH,'PREREG_SCHEDULE_SHA_MISMATCH')
    with p.open(newline='') as f:rows=list(csv.DictReader(f))
    require(len(rows)==432,'MATRIX_ROW_COUNT')
    matrix={(int(r['seed']),r['site'],r['load'],r['telemetry']):r for r in rows}
    require(len(matrix)==432,'MATRIX_DUPLICATE_KEY')
    require(set(matrix)=={(seed,site,load,arm) for seed in SEEDS for site in SITES for load in LOADS for arm in ARMS},'MATRIX_NOT_FULL_FACTORIAL')
    return matrix

def jsonlines(z,name):
    with z.open(name) as f:
        for line in f:
            if line.strip():yield json.loads(line)

def case_rows(z,prefix,seed,site,load,arm,batch,matrix_row=None):
    """Replays P12H feature/label creation; historical P12H exact replay: 0 mismatches."""
    root=f'{site}/{load}/{arm}/';pre=prefix+root
    if matrix_row is not None:
        locked=json.loads(z.read(pre+f'P12L{batch}_LOCKED_REPLICATION_CASE.json'))
        for key in ('seed','site','load','telemetry','partition','location','arm','target_role',
                    'selected_slot','temporal_anchor_A_ns','temporal_anchor_B_ns',
                    'traffic_stream_seed','routing_stream_seed','telemetry_stream_seed',
                    'schedule_filename','schedule_sha256','target_requests','competitor_requests',
                    'tail_probe_requests_per_pulse','candidate_queue_capacity_packets',
                    'execution_authorized_now','validation_or_heldout_released'):
            require(str(locked[key]).lower()==str(matrix_row[key]).lower(),
                    'LOCKED_MATRIX_MISMATCH_'+key+'_'+str(seed))
        require(locked['frozen_model_sha256']==MODEL_HASH,'CASE_MODEL_SHA_CHANGED')
        require(all(locked.get(k) is v for k,v in LOCKS.items() if k in locked),'CASE_SCIENCE_LOCK')
    decisions=list(jsonlines(z,pre+'events.jsonl.decisions.jsonl'))
    require(len(decisions)==128,'DECISION_COUNT_'+root)
    loc={}
    for x in jsonlines(z,pre+'nfd_local_queue_at_decision.jsonl'):
        require(x['observed_before_forwarding'] is True and x['remote_node_queue_accessed'] is False,'LOCAL_CAUSALITY')
        loc[(x['decision_id'],x['candidate_face_id'])]=x
    evidence={x['decision_id']:x for x in jsonlines(z,pre+'queue_telemetry_decisions.jsonl')} if arm=='on_20ms' else {}
    receipts={x['report_id']:x for x in jsonlines(z,pre+'queue_telemetry_receipts.jsonl')} if arm=='on_20ms' else {}
    qc=json.loads(z.read(pre+f'P12L{batch}_PHYSICAL_QC_ONLY.json'))
    require(qc['seed']==seed and qc['site']==site and qc['load']==load and qc['telemetry']==arm,'CASE_QC_METADATA')
    require(qc['decisions']==128 and qc['partition']=='PROSPECTIVE_REPLICATION','CASE_QC_DECISIONS')
    require(qc['telemetry_transport'].get('causal_feature_leakage',False) is False,'TELEMETRY_CAUSALITY_FLAG')
    sources=qc['physical']['selected_role_sender_node_ids']
    require(set(sources)=={'relay','mid','producer'} and len(set(sources.values()))==3,'SELECTED_PATH_NODES')
    path_nodes=set(sources.values());drops=[]
    for x in jsonlines(z,pre+'pathwide_witness_b.jsonl'):
        if x['event_type']=='QUEUE_DROP' and x['node_id'] in path_nodes and x['device_index']==0:
            drops.append(x['timestamp_ns'])
    drops.sort()
    out=[]
    for idx,d in enumerate(decisions,1):
        require(d['decision_id']==idx,'DECISION_ORDER_'+root)
        t=d['time_ns'];cand=sorted(d['candidates'],key=lambda c:c['routing_cost'])
        require(cand and cand[0]['routing_cost']==1,'FIB_SELECTED_COST_'+root)
        face=cand[0]['face_id'];a=loc[(idx,face)]
        require(a['sim_time_ns']==t and a['link_up'] is True,'LOCAL_DECISION_TIME')
        f={'fib_route_cost':cand[0]['routing_cost'],'local_selected_queue_packets':a['queue_packets'],
           'local_selected_queue_fraction':a['local_queue_occupancy_fraction'],'local_selected_link_up':a['link_up']}
        ev={x['report_id'].split('-')[0]:x['report_id'] for x in evidence[idx]['feature_evidence']} if arm=='on_20ms' else {}
        if arm=='on_20ms':
            require(evidence[idx]['decision_ns']==t,'TELEM_DECISION_TIME')
            require(set(ev).issubset({'relay','mid','producer'}),'UNKNOWN_REMOTE_ROLE')
            require(len(ev)==len(evidence[idx]['feature_evidence']),'DUPLICATE_TELEM_ROLE')
        for role in ('relay','mid','producer'):
            rr=receipts.get(ev.get(role,''))
            f[role+'_telemetry_missing']=rr is None
            f[role+'_queue_packets']=rr['queue_packets_now'] if rr else None
            f[role+'_telemetry_age_ms']=(t-rr['sample_ns'])/1e6 if rr else None
            if rr is not None:
                require(0<=rr['sample_ns']<=rr['receipt_ns']<=t,'FUTURE_TELEMETRY_LEAKAGE')
                require(rr['source_node_id']==sources[role] and rr['source_device_index']==0,'TELEM_PATH_ORIGIN')
        y=int(any(t<timestamp<=t+75_000_000 for timestamp in drops))
        key=f'{seed}:{site}:{load}:{arm}:{idx}'
        out.append((key,seed,site,load,arm,y,*[f[k] for k in FEATURES]))
    return out

def extract(args):
    plan,model=load_frozen();matrix=load_matrix();batch=args.batch
    require(batch in range(1,7),'INVALID_BATCH')
    provenance=json.loads((DOC/'P12M_PARENT_PROVENANCE.json').read_text())
    rec=next(x for x in provenance['batch_records'] if x['batch']==batch)
    qc=json.loads((DOC/rec['qc_record_json']).read_text())
    require(qc['status']==f'PASS_P12L{batch}_SIX_INDEPENDENT_SEED_BLOCKS_PHYSICAL_RAW_QC_ONLY','PARENT_QC_STATUS')
    require(qc['seed_blocks']==rec['expected_seeds'],'PARENT_QC_SEEDS')
    base=Path(args.input)
    dirs=sorted(x for x in base.iterdir() if x.is_dir() and x.name.startswith('hcraf-f3-p12l'))
    require(len(dirs)==6,'NOT_SIX_DOWNLOADED_ARTIFACTS')
    expected=rec['expected_seeds'];rows=[];seeds_seen=[]
    for seed,expected_sha in zip(expected,rec['expected_raw_zip_sha256']):
        matching=[x for x in dirs if x.name.startswith(f'hcraf-f3-p12l{batch}-seed-{seed}-')]
        require(len(matching)==1,'RAW_ARTIFACT_MISSING_DUPLICATED_'+str(seed))
        folder=matching[0]
        zs=list(folder.rglob(f'P12L{batch}_RAW_SEED_{seed}.zip'))
        rs=list(folder.rglob(f'P12L{batch}_SEED_{seed}_RECEIPT.json'))
        require(len(zs)==len(rs)==1,'SEED_FILES_MISSING_'+str(seed))
        require(sha(zs[0].read_bytes())==expected_sha,'RAW_ZIP_SHA_'+str(seed))
        receipt=json.loads(rs[0].read_text())
        require(receipt['seed']==seed and receipt['raw_archive_sha256']==expected_sha,'RAW_RECEIPT_'+str(seed))
        require(receipt['interim_AP_computed'] is False and receipt['model_fits']==0,'SEED_NO_PEEK_'+str(seed))
        with zipfile.ZipFile(zs[0]) as z:
            require(z.testzip() is None,'RAW_ARCHIVE_CRC_'+str(seed))
            for site in SITES:
                for load in LOADS:
                    for arm in ARMS:
                        data=case_rows(z,'',seed,site,load,arm,batch,matrix[(seed,site,load,arm)])
                        if arm=='on_20ms':rows.extend(data)
        seeds_seen.append(seed)
        print('PASS_P12N_EXTRACT_ONLY_NO_AP',seed,'active_rows',768,flush=True)
    require(len(rows)==6*768,'BATCH_PRIMARY_ROWS')
    require(len(set(r[0] for r in rows))==len(rows),'DUPLICATE_PRIMARY_ROW_KEYS')
    out=Path(args.output);out.parent.mkdir(parents=True,exist_ok=True)
    with out.open('w',newline='') as f:
        wr=csv.writer(f);wr.writerow(COLUMNS);wr.writerows(sorted(rows,key=lambda r:r[0]))
    receipt={'status':'PASS_P12N_BATCH_EXTRACT_ONLY_NOT_SCORED','batch':batch,'seeds':seeds_seen,
             'rows':len(rows),'raw_archives_checked':6,'raw_zip_sha256':rec['expected_raw_zip_sha256'],
             'primary_rows_csv_sha256':sha(out.read_bytes()),'P12M_run':45788559718,
             'model_sha256':MODEL_HASH,'no_AP_or_model_scoring_this_job':True,'model_fits':0,**LOCKS}
    Path(args.receipt).write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
    print('PASS_P12N_BATCH_SIX_SEEDS_RECORDED_NO_AP',batch,flush=True)

def score_one(row,model):
    score=model['intercept']
    for name,mean,sd,weight in zip(model['names'],model['means'],model['sds'],model['weights']):
        raw=row[name];v=float(raw) if raw not in ('',None) else 0.0
        score+=weight*max(-5.0,min(5.0,(v-mean)/sd))
    return 1/(1+math.exp(-max(-50,min(50,score))))

def ap_grouped(rows,score_index):
    npos=sum(int(row[1]) for row in rows)
    if not npos:return None
    scored=sorted(((row[score_index],int(row[1])) for row in rows),reverse=True)
    tp=seen=area=0;idx=0
    while idx<len(scored):
        j=idx;val=scored[idx][0];batchpos=0
        while j<len(scored) and scored[j][0]==val:
            batchpos+=scored[j][1];j+=1
        tp+=batchpos;seen=j;area+=batchpos*tp/seen;idx=j
    return area/npos

def quantile_linear(data,q):
    a=sorted(data);pos=(len(a)-1)*q;lo=int(math.floor(pos));hi=int(math.ceil(pos))
    return a[lo]+(a[hi]-a[lo])*(pos-lo)


def score_tie_groups(all_scores,score_index):
    """Preorder tied scores once; seed-cluster bootstrap retains entire blocks."""
    enumerated=sorted(((r[score_index],r[0],r[1]) for r in all_scores),reverse=True)
    groups=[];i=0
    while i<len(enumerated):
        val=enumerated[i][0];counters={}
        while i<len(enumerated) and enumerated[i][0]==val:
            _,seed,y=enumerated[i]
            k=counters.setdefault(seed,[0,0]);k[0]+=1;k[1]+=y;i+=1
        groups.append(tuple((SEEDS.index(seed),x[0],x[1]) for seed,x in counters.items()))
    return groups

def ap_from_cluster_weights(groups,weights):
    total_positives=sum(weights[s]*p for group in groups for s,n,p in group)
    if total_positives==0:return None
    seen=tp=0;area=0.0
    for group in groups:
        n=sum(weights[s]*nn for s,nn,p in group)
        pos=sum(weights[s]*p for s,nn,p in group)
        if not n:continue
        seen+=n;tp+=pos
        if pos:area+=pos*tp/seen
    return area/total_positives

def once(args):
    plan,model=load_frozen();load_matrix()
    base=Path(args.input);folders=[x for x in base.iterdir() if x.is_dir() and x.name.startswith('hcraf-f3-p12n-batch-')]
    require(len(folders)==6,'SIX_BATCH_FEATURE_ARTIFACTS_REQUIRED')
    complete=[];all_keys=set();covered=set();digest={}
    for batch in range(1,7):
        dirs=[x for x in folders if x.name.startswith(f'hcraf-f3-p12n-batch-{batch}-')]
        require(len(dirs)==1,'EXTRACT_BATCH_MISSING_'+str(batch));folder=dirs[0]
        cs=list(folder.rglob(f'P12N_BATCH_{batch}_RAW_FEATURES_LABELS_ONLY.csv'))
        rs=list(folder.rglob(f'P12N_BATCH_{batch}_EXTRACT_ONLY_RECEIPT.json'))
        require(len(cs)==len(rs)==1,'BATCH_ROWS_OR_RECEIPT_MISSING_'+str(batch))
        receipt=json.loads(rs[0].read_text())
        require(receipt['status']=='PASS_P12N_BATCH_EXTRACT_ONLY_NOT_SCORED','EXTRACT_RECEIPT_STATUS')
        require(receipt['batch']==batch and receipt['model_sha256']==MODEL_HASH,'EXTRACT_RECEIPT_PROVENANCE')
        require(receipt['no_AP_or_model_scoring_this_job'] is True and receipt['model_fits']==0,'EXTRACT_AP_PEEK')
        require(receipt['seeds']==list(range(24801+6*(batch-1),24807+6*(batch-1))),'EXTRACT_SEED_RANGE')
        require(receipt['primary_rows_csv_sha256']==sha(cs[0].read_bytes()),'BATCH_ROW_SHA_CHANGED')
        digest[str(batch)]=receipt['primary_rows_csv_sha256']
        with cs[0].open(newline='') as f:
            reader=csv.DictReader(f);require(tuple(reader.fieldnames)==COLUMNS,'FEATURES_SCHEMA_CHANGED')
            count=0
            for row in reader:
                seed=int(row['seed']);key=row['row_key'];require(seed in receipt['seeds'],'WRONG_BATCH_SEED')
                require(row['telemetry']=='on_20ms' and row['site'] in SITES and row['load'] in LOADS,'INVALID_PRIMARY_CASE')
                require(key not in all_keys,'DUPLICATE_ROW_KEY');all_keys.add(key)
                require(row['y'] in ('0','1'),'INVALID_BINARY_LABEL')
                require(all(row[k] in ('True','False') for k in ['local_selected_link_up','relay_telemetry_missing','mid_telemetry_missing','producer_telemetry_missing']),'INVALID_BOOLEAN_FEATURE')
                for k in ['local_selected_link_up','relay_telemetry_missing','mid_telemetry_missing','producer_telemetry_missing']:
                    row[k]=1.0 if row[k]=='True' else 0.0
                complete.append((seed,int(row['y']),score_one(row,model['local_model']),score_one(row,model['remote_model']),key,row['site'],row['load']))
                covered.add(seed);count+=1
            require(count==4608,'BATCH_ROW_COUNT_'+str(batch))
    require(covered==set(SEEDS) and len(complete)==27648 and len(all_keys)==27648,'PRIMARY_COMPLETE_36_SEEDS')
    counters=collections.Counter(r[0] for r in complete)
    require(all(counters[s]==768 for s in SEEDS),'SEED_CLUSTER_SIZE')
    require(len({(r[0],r[5],r[6]) for r in complete})==216,'PRIMARY_CASE_COUNT')
    out=Path(args.output);out.parent.mkdir(parents=True,exist_ok=True)
    audit={'stage':'P12N_v0.52.33','P12M_run':45788559718,'P12M_parent_artifact':15102130997,
           'P12M_parent_digest':'sha256:5d9a96be23a672532f0278dadf344c96e2ad3d8b47a32cdc25128ffccc7b8ca2',
           'previous_validation_P12H':'NO_GO_P12H_VALIDATION_EVIDENCE_OR_PREDICTABILITY',
           'prereg_plan_sha256':PLAN_HASH,'frozen_model_sha256':MODEL_HASH,
           'data_row_sha256_by_batch':digest,'seed_blocks':list(SEEDS),
           'physical_cases_authenticated_from_P12M':432,'scored_active_cases':216,'scored_episodes':27648,
           'new_simulations':0,'model_fits':0,'no_interim_AP_peeks':True,'heldout_rows_read':0,
           'bootstraps_attempted':0,'bootstrap_invalid_resamples':0,**LOCKS}
    npos=sum(row[1] for row in complete); nneg=len(complete)-npos
    audit.update({'positives':npos,'negatives':nneg,'observed_prevalence':npos/len(complete)})
    if npos==0 or nneg==0:
        audit.update({'status':'INDETERMINATE_P12N_ABSENT_GLOBAL_CLASS','replication_success':False,
                      'scientific_decision':'NO_GO_INDETERMINATE_UNDEFINED_AP'})
    else:
        all_scores=[(row[0],row[1],row[2],row[3]) for row in complete]
        apl=ap_grouped(all_scores,2);apr=ap_grouped(all_scores,3)
        grouped=collections.defaultdict(list)
        for row in all_scores:grouped[row[0]].append(row)
        seed_metric=[];positive_seed_delta=0
        for s in SEEDS:
            rr=grouped[s];count=sum(r[1] for r in rr)
            la=ap_grouped(rr,2);ra=ap_grouped(rr,3)
            good=(la is not None and ra is not None and ra>la)
            positive_seed_delta+=int(good)
            seed_metric.append({'seed':s,'positives':count,'AP_local':la,'AP_remote':ra,
                                'delta_AP_remote_minus_local':None if la is None else ra-la,
                                'strictly_positive_seed_gate':good})
        rng=random.Random(plan['bootstrap']['rng_seed']);boot=[];bad=0
        local_ties=score_tie_groups(all_scores,2)
        remote_ties=score_tie_groups(all_scores,3)
        for i in range(plan['bootstrap']['replicates']):
            selection=rng.choices(range(36),k=36)
            weights=[0]*36
            for index in selection:weights[index]+=1
            a=ap_from_cluster_weights(local_ties,weights)
            b=ap_from_cluster_weights(remote_ties,weights)
            if a is None or b is None:
                bad+=1
                # Still count all replicates. Never selectively discard invalid draws.
            else:boot.append(b-a)
        audit.update({'AP_local':apl,'AP_remote':apr,'delta_AP_remote_minus_local':apr-apl,
                      'positive_seed_count':positive_seed_delta,'per_seed_AP':seed_metric,
                      'bootstraps_attempted':10000,'bootstrap_invalid_resamples':bad,
                      'bootstrap_rng_seed':525250,'bootstrap_resampling_unit':'paired whole seed block',
                      'bootstrap_percentile_method':'ordered linear interpolation at (N-1)*q',
                      'bootstrap_interval_coverage':0.975})
        if bad:
            audit.update({'bootstrap_CI_97p5':None,'status':'INDETERMINATE_P12N_INVALID_BOOTSTRAP_RESAMPLE',
                          'replication_success':False,'scientific_decision':'NO_GO_INDETERMINATE_INVALID_RESAMPLE'})
        else:
            ci=[quantile_linear(boot,plan['bootstrap']['lower_percentile']),
                quantile_linear(boot,plan['bootstrap']['upper_percentile'])]
            gates={'all_432_exact_cases_and_causal_provenance':True,
                   'both_event_classes_present':npos>0 and nneg>0,
                   'remote_AP_above_local':apr>apl,'remote_AP_above_prevalence':apr>npos/len(complete),
                   'at_least_27_of_36_seed_blocks_positive':positive_seed_delta>=27,
                   'lower_97p5_bootstrap_limit_strictly_positive':ci[0]>0}
            success=all(gates.values())
            audit.update({'bootstrap_CI_97p5':ci,'replication_gates':gates,
                          'replication_success':success,
                          'status':'PASS_P12N_REPLICATION_EVIDENCE_ONLY' if success else 'NO_GO_P12N_CONFIRMATORY_REPLICATION',
                          'scientific_decision':'REPLICATION_SUPPORTS_REVIEW_ONLY_NOT_AUTOMATIC_F3_GO' if success else 'NO_GO'})
    out.write_text(json.dumps(audit,indent=2,sort_keys=True)+'\n')
    print('P12N_FINAL_CONFIRMMATORY_ONCE_ONLY',audit['status'],'positives',npos,'rows',len(complete),flush=True)
    print('NO_TRAINING_NO_HELDOUT_NO_AUTOMATIC_F3_GO',flush=True)

def main():
    p=argparse.ArgumentParser();sub=p.add_subparsers(dest='mode',required=True)
    x=sub.add_parser('extract');x.add_argument('--batch',type=int,required=True);x.add_argument('--input',required=True)
    x.add_argument('--output',required=True);x.add_argument('--receipt',required=True)
    y=sub.add_parser('score-once');y.add_argument('--input',required=True);y.add_argument('--output',required=True)
    a=p.parse_args();(extract if a.mode=='extract' else once)(a)
if __name__=='__main__':main()
