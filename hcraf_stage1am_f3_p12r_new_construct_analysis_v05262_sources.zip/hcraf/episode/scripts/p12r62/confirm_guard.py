"""Read-only authentication and full-set integrity; never score or fit."""
import json,zipfile,pathlib as pl,hashlib,os,urllib.request,urllib.parse,subprocess,sys
import pilot_audit as a
P=pl.Path
AMEND_SHA='cb5a67651f8342cec2883741ae59d89e606e50e23ce449c94c3e3b1002350e64'
AMEND_COMMIT='737c7395d2aa16ff23ed710e81928cdb6811d9db'
AMEND_RUN=46068985498; AMEND_ART=15231539274
FILES=set('background.csv command.txt confirm_candidate_reference.json devices.csv events.jsonl events.jsonl.background.jsonl events.jsonl.collection.jsonl events.jsonl.decisions.jsonl events.jsonl.states.jsonl features.csv local_events.csv probe.csv producer.csv queue_a.csv queue_b.csv schedule.csv simulator.log wire.csv'.split())
def verify_amendment(p,prereg):
 a.need(a.digest(p)==AMEND_SHA,'AMEND_ZIP');_,_,hashes=a.read_prereg(prereg)
 with zipfile.ZipFile(p) as z:
  a.need(z.testzip() is None and len(z.namelist())==4 and set(z.namelist())=={'AMENDMENT_RECEIPT.json','AMENDMENT_LOCK.json','FROZEN_COMPARATORS.json','ORIGINAL_FROZEN_MODELS.json'},'AMEND_MEMBERS');r=json.loads(z.read('AMENDMENT_RECEIPT.json'));a.need(r['status']=='PASS_P12R_COMPARATOR_AMENDMENT_RTT_FROZEN_ONLY_NO_F3_RELEASE' and all(r[k]==v for k,v in a.LOCKS.items()) and r['model_fits']==1 and r['original_model_refits']==0 and r['training_rows']==22680 and r['prior_NO_GO_preserved'] and r['prior_prediction_gate_blocked'] and all(not r[k] for k in ('confirmation_cases_executed','confirmation_rows_read','confirmation_execution_authorized','new_AP_computed','new_bootstrap_computed','heldout_rows_read','official_F3_labels_constructed')),'AMEND_GATE');a.need(set(r['files'])==set(z.namelist())-{'AMENDMENT_RECEIPT.json'} and all(a.sha(z.read(n))==h for n,h in r['files'].items()),'AMEND_FILE_HASHES');l=json.loads(z.read('AMENDMENT_LOCK.json'));m=json.loads(z.read('FROZEN_COMPARATORS.json'));o=json.loads(z.read('ORIGINAL_FROZEN_MODELS.json'));a.need(l['parent_plan_sha256']==hashes['PLAN.json'] and l['parent_matrix_sha256']==hashes['LOCKED_MATRIX.csv'] and l['parent_schedule_sha256']==hashes['LOCKED_PROBE_SCHEDULE.csv'] and l['partition_seeds']['confirmation']==[620201,620236] and all(l[k]==v for k,v in a.LOCKS.items()),'AMEND_PLAN');a.need(m['B0']==o['B0'] and m['B1']==o['B1'] and m['original_model_sha256']==r['files']['ORIGINAL_FROZEN_MODELS.json'] and m['amendment_sha256']==r['files']['AMENDMENT_LOCK.json'] and m['training_rows']==22680 and m['training_seeds']==list(range(620101,620113)) and all(m[k]==v for k,v in a.LOCKS.items()),'FROZEN_MODELS');a.need(m['RTT_ONLY']['names']==l['prediction']['baseline_features'] and len(m['B0']['names'])==7,'COMPARATOR_FEATURES')
 return r['files']
def api(path):
 repo=os.environ['GITHUB_REPOSITORY'];a.need(repo=='parhamarjomand-hub/hcraf-ndnsim','REPO');q=urllib.request.Request('https://api.github.com/repos/'+repo+path,headers={'Authorization':'Bearer '+os.environ['GH_TOKEN'],'Accept':'application/vnd.github+json','User-Agent':'HCRAF-P12R60'});
 with urllib.request.urlopen(q,timeout=60) as r:return json.load(r)
def provenance(out):
 r=api('/actions/runs/'+str(AMEND_RUN));ar=api('/actions/artifacts/'+str(AMEND_ART));a.need(r['status']=='completed' and r['conclusion']=='success' and r['run_attempt']==1 and r['head_sha']==AMEND_COMMIT and r['path']=='.github/workflows/hcraf-stage1am-f3-p12r-comparator-amendment-v0.52.59.yml','AMEND_RUN');a.need(not ar['expired'] and ar['workflow_run']['id']==AMEND_RUN and ar['workflow_run']['head_sha']==AMEND_COMMIT and ar['digest']=='sha256:'+AMEND_SHA and ar['size_in_bytes']==7356,'AMEND_ART');subprocess.check_call(['git','merge-base','--is-ancestor',AMEND_COMMIT,'HEAD'])
 # Check all relevant tracked workflow runs since registration, including failed attempts. The known compile-only failure and approved runs are explicitly enumerated.
 approved={46044334756,46045524607,46051275419,46062593390,46068343005,46068985498,int(os.environ['GITHUB_RUN_ID'])};seen=[];page=1
 while True:
  q=api('/actions/runs?per_page=100&page='+str(page)+'&created='+urllib.parse.quote('>=2026-11-27T17:45:38Z'));a.need(q['total_count']<1000,'HISTORY_API_LIMIT');runs=q['workflow_runs'];
  for x in runs:
   path=x.get('path','');name=x.get('name','').lower();relevant=any(k in path for k in ('p12r-new-construct','p12r-comparator-amendment','p12r-dev-degeneracy-audit')) or ('p12r' in name and ('construct' in name or 'comparator amendment' in name))
   if relevant:a.need(x['id'] in approved and x['run_attempt']==1,'UNAPPROVED_RELEVANT_RUN:'+str(x['id']));seen.append(x['id'])
  if len(runs)<100:break
  page+=1;a.need(page<=10,'HISTORY_API_PAGES')
 a.need(approved<=set(seen),'MISSING_KNOWN_RUNS');a.write(out,dict(status='PASS_DECLARED_RUN_ANCESTRY_ONLY',amendment_run=AMEND_RUN,amendment_artifact=AMEND_ART,amendment_sha256=AMEND_SHA,relevant_runs=sorted(set(seen)),scope='visible repository workflow history; cannot establish unrecorded or differently named external executions',**a.LOCKS))
def verify_block(root,block,cases,hashes):
 r=json.loads((root/'BLOCK_RECEIPT.json').read_text());expected={str(P(c['seed'],c['site'],c['arm'],'case_receipt.json')):c for c in a.block_cases(cases,block)}
 a.need(r['status']==a.STATUS and r['block']==block and r['seeds']==sorted(a.block_seeds(block)) and r['prereg_files']==hashes and r['amendment_zip_sha256']==AMEND_SHA and r['cases']==90 and r['decisions']==11340 and r['all_candidate_feature_rows']==34020 and all(r[k]==v for k,v in a.LOCKS.items()) and all(not r[k] for k in ('model_fits','new_AP_computed','new_bootstrap_computed','heldout_rows_read','official_F3_labels_constructed','development_cases')),'BLOCK_RECEIPT');a.need(set(r['case_receipt_hashes'])==set(expected)=={str(p.relative_to(root)) for p in root.rglob('case_receipt.json')},'CASE_SET')
 expected_paths={'BLOCK_RECEIPT.json'};count=0
 for n,c in expected.items():
  f=root/n;d=f.parent;a.need(a.digest(f)==r['case_receipt_hashes'][n],'CASE_SHA');rc=json.loads(f.read_text());a.need(rc['case']==c and rc['status']=='PASS_CONFIRM_CASE_ENGINEERING_ONLY' and rc['decisions']==126 and rc['all_candidate_feature_rows']==378 and rc['return_reference_rows']==126 and all(rc[k]==v for k,v in a.LOCKS.items()),'CASE_GATE');a.need(set(rc['files'])==FILES,'RAW_SET');expected_paths.add(n)
  for fn,h in rc['files'].items():
   p=d/fn;a.need(p.is_file() and not p.is_symlink() and a.digest(p)==h,'RAW_SHA');expected_paths.add(str(p.relative_to(root)));count+=1
 a.need(count==1620 and expected_paths=={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()},'RAW_COUNT_OR_EXTRA');return a.digest(root/'BLOCK_RECEIPT.json')
def aggregate(prereg,amend,root,out):
 seals=verify_amendment(amend,prereg);cases,_,hashes=a.read_prereg(prereg);a.need(not out.exists(),'NO_OVERWRITE');receipts={};a.need(len(list(root.iterdir()))==6,'ARTIFACT_COUNT')
 for b in range(1,7):
  name='hcraf-f3-p12r-new-construct-confirm-block-'+str(b)+'-v05260-run-'+os.environ['GITHUB_RUN_ID'];d=root/name/'p12r60_confirm';receipts[str(b)]=verify_block(d,b,cases,hashes);print('PASS_BLOCK_SEALS',b,flush=True)
 a.write(out,dict(status='PASS_P12R_NEW_CONSTRUCT_CONFIRM_COLLECTION_QC_ONLY_NO_SCORING_NO_F3_RELEASE',blocks=6,cases=540,decisions=68040,all_candidate_feature_rows=204120,raw_files_verified=9720,seeds=sorted(set.union(*(a.block_seeds(b) for b in range(1,7)))),prereg_files=hashes,amendment_zip_sha256=AMEND_SHA,frozen_member_hashes=seals,block_receipt_hashes=receipts,model_fits=0,new_AP_computed=False,new_bootstrap_computed=False,construct_validated=False,official_F3_labels_constructed=0,heldout_rows_read=0,**a.LOCKS))
if __name__=='__main__':
 if sys.argv[1]=='provenance':provenance(P(sys.argv[2]))
 elif sys.argv[1]=='amendment':print('PASS_FROZEN_AMENDMENT',verify_amendment(P(sys.argv[2]),P(sys.argv[3])))
 elif sys.argv[1]=='aggregate':aggregate(*map(P,sys.argv[2:]))
 else:raise RuntimeError('UNKNOWN_COMMAND')
