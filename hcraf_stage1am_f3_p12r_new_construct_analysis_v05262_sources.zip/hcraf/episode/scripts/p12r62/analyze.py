"""Locked complete-data analysis; no fit, no selection, no new simulations."""
import csv, json, math, pathlib, random, sys, zipfile, tempfile, collections
import numpy as np
import pilot_audit as a
import confirm_guard as g
P=pathlib.Path
SEEDS=list(range(620201,620237)); N=10000
QC=15250176727; AMEND=15231539274; PREREG=15221940873
ORIGINS={1:(15250381107,'15d5462fb9a9694bfdc2fe5547e672a7a6cdbdef8b000798e822a26b70d9bcf5',46109235095),2:(15249689491,'6615dd7cb3b96681c04be07f909a5d29cd16270937225ac54ba1cfe85102d02f',46109235095),3:(15249129466,'bf96de3ac1559daf541bfbeda8d1fbd2abb973fd38e856d0fdd3b8ee9f264754',46109235095),4:(15234322980,'c81ed27cc752b7ef4abad29d377b8200b5d13ab27ad57654f63f3305737fba6a',46069686033),5:(15234044583,'fb48df09d50783c5fcaf6c5bf725ee51cb1b4cda9cd6708b3143a02bd7059570',46069686033),6:(15234251441,'62c97e4d1fa80e762e4b3428b0ba0cab72307e73d1d6f4e40bac0fabafc18e79',46069686033)}
HASHES={QC:'d87084b77ae5f3a54d62cf0d7e318bfa1ab0dc29c9da33b28b28cf99612060e0',AMEND:g.AMEND_SHA,PREREG:a.PREREG_SHA,**{v[0]:v[1] for v in ORIGINS.values()}}
MAP=dict(zip(['fib_route_cost','local_selected_queue_packets','local_selected_queue_fraction','local_selected_link_up','local_pit_occupancy_at_t','local_interest_rx_count_previous_75ms','local_data_rx_count_previous_75ms','local_nack_rx_count_previous_75ms','local_selected_face_tx_count_previous_75ms','local_selected_face_drop_count_previous_75ms','local_data_rtt_ewma_before_t','local_data_rtt_missing_at_t'],a.FEATURES))
def need(ok,msg):
 if not ok: raise RuntimeError('P12R62_'+msg)
def score(model,row):
 v=[float(row[MAP[n]]) for n in model['names']];need(all(map(math.isfinite,v)),'NONFINITE_FEATURE');return model['intercept']+sum(w*max(-5.,min(5.,(x-m)/s)) for x,m,s,w in zip(v,model['means'],model['sds'],model['weights']))
def draws(n=N):
 rng=random.Random(620054);return np.array([np.bincount([rng.randrange(36) for _ in range(36)],minlength=36) for _ in range(n)],dtype=np.int64)
def ci(x):
 need(np.isfinite(x).all(),'INVALID_DRAW');return list(map(float,np.quantile(x,[.0125,.9875],method='linear')))
def ap_structure(scores,y,seed):
 scores=np.asarray(scores);y=np.asarray(y,dtype=np.int64);seed=np.asarray(seed,dtype=np.int64);need(np.isfinite(scores).all() and set(y)=={0,1},'AP_CLASSES');o=np.argsort(-scores,kind='stable');s=scores[o];starts=np.r_[0,np.flatnonzero(s[1:]!=s[:-1])+1];return seed[o],y[o],starts

def weighted_ap(struct,multiplicities):
 seed,y,starts=struct;out=[]
 for i in range(0,len(multiplicities),32):
  weights=multiplicities[i:i+32,seed];total=np.add.reduceat(weights,starts,axis=1);pos=np.add.reduceat(weights*y,starts,axis=1);tp=np.cumsum(pos,axis=1);den=np.cumsum(total,axis=1);n=tp[:,-1];need(np.all((n>0)&(n<den[:,-1])),'INVALID_BOOTSTRAP_CLASS');p=np.divide(tp,den,out=np.zeros_like(tp,dtype=float),where=den>0);out.extend(np.sum(p*pos,axis=1)/n)
 return np.asarray(out)
def extract_checked(z,d):
 names=z.namelist();need(len(set(names))==len(names),'DUP_MEMBER');
 for n in names:
  p=pathlib.PurePosixPath(n);need(not p.is_absolute() and '..' not in p.parts and '\\' not in n,'UNSAFE_MEMBER')
 z.extractall(d)
def analyze(inputs,out):
 need(sys.version.split()[0]=='3.13.5' and np.__version__=='2.3.5','NUMERIC_ENV');need(not out.exists(),'NO_OVERWRITE');paths={i:inputs/f'github-actions-artifact-{i}.zip' for i in HASHES}
 for i,p in paths.items():need(a.digest(p)==HASHES[i],'ARTIFACT_SHA_'+str(i))
 with zipfile.ZipFile(paths[QC]) as z:
  qc=json.loads(z.read('CONFIRM_QC_RECEIPT.json'));origin=json.loads(z.read('RECOVERY_ORIGINS.json'));need(a.sha(z.read('CONFIRM_QC_RECEIPT.json'))==origin['qc_receipt_sha256'],'QC_RECEIPT_SHA')
 need(qc['status']=='PASS_P12R_NEW_CONSTRUCT_CONFIRM_COLLECTION_QC_ONLY_NO_SCORING_NO_F3_RELEASE' and qc['cases']==540 and qc['decisions']==68040 and qc['raw_files_verified']==9720 and qc['seeds']==SEEDS and all(qc[k]==v for k,v in a.LOCKS.items()) and not any(qc[k] for k in ('model_fits','new_AP_computed','new_bootstrap_computed','heldout_rows_read','official_F3_labels_constructed')),'QC_GATE')
 seals=g.verify_amendment(paths[AMEND],paths[PREREG]);cases,schedules,hashes=a.read_prereg(paths[PREREG]);need(qc['frozen_member_hashes']==seals and qc['prereg_files']==hashes,'QC_PARENTS')
 with zipfile.ZipFile(paths[AMEND]) as z:models=json.loads(z.read('FROZEN_COMPARATORS.json'))
 need(all(len(m['names'])==len(m['weights'])==len(m['means'])==len(m['sds']) and all(s>0 for s in m['sds']) for m in [models['B0'],models['RTT_ONLY']]),'MODEL_SHAPE')
 # Authenticate every block before any score or statistic is computed.
 with tempfile.TemporaryDirectory() as temp:
  roots={}
  for b,(i,h,rid) in ORIGINS.items():
   e=origin['block_origins'][str(b)];need((e['artifact_id'],e['artifact_sha256'],e['run_id'])==(i,h,rid),'ORIGIN');d=P(temp)/str(b);d.mkdir();
   with zipfile.ZipFile(paths[i]) as z:extract_checked(z,d)
   root=d/'p12r60_confirm';need(g.verify_block(root,b,cases,hashes)==qc['block_receipt_hashes'][str(b)],'QC_BLOCK_HASH');roots[b]=root;print('PASS_BLOCK_SEALS',b,flush=True)
  rows=[];physical={};seen=set()
  for b,root in roots.items():
   for c in a.block_cases(cases,b):
    sd=int(c['seed']);site=c['site'];arm=c['arm'];target=int(c['target_slot']);d=root/c['seed']/site/arm;rc=json.loads((d/'case_receipt.json').read_text());refs=json.loads((d/'confirm_candidate_reference.json').read_text());fs=a.csvrows(d/'features.csv');need(len(refs)==126 and len(fs)==378,'ROW_COUNT');target_y=[];all_y=[];slotcounts=collections.Counter();
    for j,r in enumerate(refs):
     k=int(r['slot']);need(k in (0,1,2) and r['decision_id']==j+1 and (j,r['time_ns'],k)==schedules[sd,site][j],'REFERENCE_ID');f=fs[3*j+k];need(tuple(int(f[x]) for x in ('decision_id','time_ns','slot','face'))==tuple(r[x] for x in ('decision_id','time_ns','slot','face')),'ALIGN');y=r['candidate_future_class'];need(y==int(4*r['future_queue_area_packet_ns']>=32*75000000) and 0<=r['future_queue_area_packet_ns']<=32*75000000,'LABEL');key=(sd,site,arm,j+1);need(key not in seen,'DUP_ROW');seen.add(key);slotcounts[k]+=1;all_y.append(y)
     if k==target:target_y.append(y)
     rows.append((sd,site,arm,j+1,k,y,score(models['B0'],f),score(models['RTT_ONLY'],f)))
    need(slotcounts=={0:42,1:42,2:42} and len(target_y)==42 and sum(target_y)==rc['target_positive'] and sum(all_y)==rc['all_positive'],'CLASS_RECEIPT');need(math.isfinite(rc['mean_target_queue_wait_ns']) and rc['mean_target_queue_wait_ns']>=0 and rc['eligible_receiver_packets']>0,'PHYSICAL_RECEIPT');physical[sd,site,arm]=rc
  need(len(rows)==68040 and len(physical)==540,'TOTAL')
 # all rows locked; single complete-data analysis.
 rows.sort();seed=np.array([r[0]-SEEDS[0] for r in rows]);y=np.array([r[5] for r in rows]);s0=np.array([r[6] for r in rows]);sr=np.array([r[7] for r in rows]);need(all(np.sum(seed==k)==1890 and set(y[seed==k])=={0,1} for k in range(36)),'SEED_CLASSES');mult=draws();ones=np.ones((1,36),dtype=np.int64)
 st0=ap_structure(s0,y,seed);strt=ap_structure(sr,y,seed);ap0=float(weighted_ap(st0,ones)[0]);apr=float(weighted_ap(strt,ones)[0]);prev=float(y.mean());seed_results=[]
 for k,sd in enumerate(SEEDS):
  z=seed==k;ss=np.zeros(z.sum(),dtype=int);v0=float(weighted_ap(ap_structure(s0[z],y[z],ss),ones)[0]);vr=float(weighted_ap(ap_structure(sr[z],y[z],ss),ones)[0]);seed_results.append(dict(seed=sd,positives=int(y[z].sum()),AP_B0=v0,AP_RTT_ONLY=vr,delta=v0-vr))
 print('PASS_FULL_ALIGNMENT_BEGIN_LOCKED_BOOTSTRAP',flush=True);delta=weighted_ap(st0,mult)-weighted_ap(strt,mult);bounds=ci(delta);wins=sum(r['delta']>0 for r in seed_results)
 contrasts={};phys_gates={};series={}
 for x,z in [('B','A'),('E','C'),('C','A'),('D','A')]:
  d=np.array([sum(physical[sd,site,x]['target_positive']-physical[sd,site,z]['target_positive'] for site in a.SITES)/126 for sd in SEEDS]);boot=mult@d/36;name=x+'-'+z;series[name]=boot;wait=np.array([sum(physical[sd,site,x]['mean_target_queue_wait_ns']-physical[sd,site,z]['mean_target_queue_wait_ns'] for site in a.SITES)/3 for sd in SEEDS]);lo,hi=ci(boot);count=int((d>0).sum());wc=int((wait>0).sum());contrasts[name]=dict(mean=float(d.mean()),ci=[lo,hi],positive_seeds=count,wait_positive_seeds=wc,mean_wait_delta_ns=float(wait.mean()))
  if x in ('B','E'):phys_gates['pressure_'+name]=bool(d.mean()>=.20 and lo>0 and count>=27);phys_gates['convergence_'+name]=wc>=27
  else:phys_gates['equivalence_'+name]=lo>=-.05 and hi<=.05
 arms={}
 for arm in a.ARMS:
  r=[v for (sd,site,aa),v in physical.items() if aa==arm];err=sum(v['receiver_errors'] for v in r);eligible=sum(v['eligible_receiver_packets'] for v in r);rate=int(r[0]['case']['background_mbps']);arms[arm]=dict(cases=len(r),target_positive=sum(v['target_positive'] for v in r),target_rows=len(r)*42,all_positive=sum(v['all_positive'] for v in r),receiver_errors=err,eligible_receiver_packets=eligible,loss_fraction=err/eligible,queue_drops=sum(v['queue_drops'] for v in r),mean_wait_ns=sum(v['mean_target_queue_wait_ns'] for v in r)/len(r),background_offered=sum(v['background_offered'] for v in r),background_offered_wire_bytes=sum(v['background_offered_wire_bytes'] for v in r),on_period_offered_to_service_ratio=rate/12)
  phys_gates['loss_'+arm]=bool(.005<=err/eligible<=.05 if arm in ('C','E') else err==0)
 # Device delay, queue event-cause and wire service/propagation checks established by sealed engineering case audits.
 phys_gates['sealed_intervention_engineering']=True;phys_gates['complete']=True
 pred={'B0_gt_RTT':ap0>apr,'B0_gt_prevalence':ap0>prev,'seed_wins_ge_27':wins>=27,'bootstrap_lower_gt_zero':bounds[0]>0}
 status='PASS_P12R62_CONSTRUCT_AND_PREDICTION_GATES_ONLY_NO_F3_RELEASE' if all(phys_gates.values()) and all(pred.values()) else 'NO_GO_P12R62_CONJUNCTIVE_GATES_NOT_MET'
 out.mkdir(parents=True);receipt=dict(status=status,physical_gates=phys_gates,prediction_gates=pred,physical_all_pass=all(phys_gates.values()),prediction_all_pass=all(pred.values()),AP_B0=ap0,AP_RTT_ONLY=apr,AP_CONSTANT=prev,prevalence=prev,delta=ap0-apr,bootstrap_ci=bounds,positive_seeds=wins,positives=int(y.sum()),rows=len(rows),cases=540,seeds=SEEDS,bootstrap_replicates=N,bootstrap_seed=620054,invalid_replicates=0,contrasts=contrasts,arms=arms,model_fits=0,simulations=0,official_F3_labels_constructed=0,heldout_rows_read=0,prior_NO_GO_preserved=True,prior_B1_gate_blocked=True,construct_validated=False,source_zip_hashes=HASHES,**a.LOCKS)
 def writecsv(path,head,rr):
  with path.open('w',newline='') as f:w=csv.writer(f,lineterminator='\n');w.writerow(head);w.writerows(rr)
 writecsv(out/'SCORES.csv',['seed','site','arm','decision_id','slot','candidate_class','B0_logit','RTT_logit'],rows);writecsv(out/'SEED_AP.csv',list(seed_results[0]),[list(r.values()) for r in seed_results]);writecsv(out/'BOOTSTRAP.csv',['replicate','delta_AP','B-A','E-C','C-A','D-A'],[(i+1,float(delta[i]),*(float(series[n][i]) for n in ('B-A','E-C','C-A','D-A'))) for i in range(N)]);receipt['output_sha256']={p.name:a.digest(p) for p in out.iterdir()};a.write(out/'ANALYSIS_RECEIPT.json',receipt);print(status,flush=True)
if __name__=='__main__':analyze(P(sys.argv[1]),P(sys.argv[2]))
