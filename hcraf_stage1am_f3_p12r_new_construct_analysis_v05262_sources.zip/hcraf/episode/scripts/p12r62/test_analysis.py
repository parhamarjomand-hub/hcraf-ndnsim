import unittest, numpy as np
from analyze import *
class Test(unittest.TestCase):
 def test_tie(self):
  st=ap_structure([2,2,1],[1,0,1],[0,1,0]);self.assertAlmostEqual(weighted_ap(st,np.ones((1,36),dtype=int))[0],.5*.5+2/3*.5)
 def test_seed_weights(self):
  st=ap_structure([2,2,1],[1,0,1],[0,1,0]);m=np.ones((1,36),dtype=int);m[0,0]=2;self.assertAlmostEqual(weighted_ap(st,m)[0],.5*2/3+.5*4/5)
 def test_zero_groups(self):
  st=ap_structure([3,2,1],[0,1,0],[1,0,0]);m=np.zeros((1,36),dtype=int);m[0,0]=2;self.assertEqual(weighted_ap(st,m)[0],1)
 def test_invalid(self):
  st=ap_structure([2,1],[0,1],[1,0]);m=np.zeros((1,36),dtype=int);m[0,0]=2
  with self.assertRaises(RuntimeError): weighted_ap(st,m)
 def test_draw(self):
  m=draws(3);r=random.Random(620054);self.assertEqual(m.tolist(),[np.bincount([r.randrange(36) for _ in range(36)],minlength=36).tolist() for _ in range(3)])
 def test_quantile(self):self.assertEqual(ci(np.arange(10000)),[124.98750000000001,9874.0125])
 def test_score(self):
  m=dict(names=['local_data_rtt_missing_at_t'],means=[0],sds=[1],weights=[2],intercept=1);self.assertEqual(score(m,{'missing':'8'}),11)
 def test_perfect(self):self.assertEqual(weighted_ap(ap_structure([1,0],[1,0],[0,0]),np.ones((1,36),dtype=int))[0],1)
 def test_constant(self):self.assertEqual(weighted_ap(ap_structure([1,1,1,1],[1,0,0,0],[0]*4),np.ones((1,36),dtype=int))[0],.25)
 def test_nonfinite(self):
  with self.assertRaises(RuntimeError):ap_structure([float('nan'),1],[0,1],[0,0])
if __name__=='__main__':unittest.main()
