# اصلاح فنی P2 تله‌متری v0.52.2 — فقط انتقال NDN

## شاهد مستقل

- GitHub run `44137214798`: restore/test/compile PASS؛ simulate FAILED.
- اجرای `PRODUCER_RETURN_12M/telemetry20`: تعداد درخواست‌های ثبت‌شده 2700، پاسخ‌های ساخته‌شده در Source برابر 2700، رسید در Sink برابر صفر، شواهد ویژگی در 108 تصمیم برابر صفر.
- P1 از `/hcraf-queue-telemetry` استفاده می‌کند و خطای Stage1M قبلی دیگر رخ نداده است.

## فرضیه فنی و اصلاح حداقلی

نسخه ndn-cxx 0.8 در `Interest::matchesData` اگر `MustBeFresh=true` و `Data::FreshnessPeriod<=0` باشد، تطبیق را رد می‌کند. Source قبلی FreshnessPeriod صفر داشت و Sink با MustBeFresh درخواست می‌فرستاد. پاسخ‌های NDN از نظر نام تطبیق داشتند اما در مسیر برگشت قادر به ارضای Interest نبودند.

در این اصلاح، FreshnessPeriod پاسخ کنترلی تنها در `HcrafQueueTelemetrySource` به 1000 میلی‌ثانیه تغییر کرده و یک بررسی runtime `interest->matchesData(*data)` افزوده شده است. نام یکتای هر درخواست، CS غیرفعال (`stack.setCsSize(0)`) و جدایی کنترل `/hcraf-queue-telemetry` برقرار می‌مانند. ترافیک TARGET/COMPETITOR، انتخاب مسیر، برچسب‌های آینده، RNG، NFD و قفل پیش‌ثبت تغییر نکرده‌اند.

این بسته **اصلاح اثبات‌شده در سورس با اجرای ابریِ در انتظار** است؛ نتیجه GitHub و دریافت واقعی هنوز باید ممیزی شود.

## وضعیت پژوهش

`Congestion=null`، `FutureCongestion=null`، `F3_ready=false`، `GO_FREEZE=false`، `training_ready=false`.

هیچ اجرای HELDOUT، آموزش مدل یا NSGA-III مجاز نیست.
