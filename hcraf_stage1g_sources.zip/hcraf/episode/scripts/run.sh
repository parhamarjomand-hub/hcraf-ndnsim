#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK_DIR="$PROJECT_DIR/hcraf/episode"
OUTPUT_DIR="$PROJECT_DIR/episode_output"
cd "$PROJECT_DIR/episode_sources/ns-3"
status=0
# Repeated seed/run tests determinism, not independent statistical replication.
for mode in control local-pressure return-pressure random-loss receive-outage no-route; do
  for repetition in 1 2; do
    folder="$OUTPUT_DIR/$mode/repeat-$repetition"
    mkdir -p "$folder"
    command="hcraf-episode-pilot --mode=$mode --output=$folder --seed=1 --run=1"
    printf '%s\n' "python3 ./waf --run-no-build '$command'" > "$folder/command.txt"
    if ! python3 ./waf --run-no-build "$command" 2>&1 | tee "$folder/simulator.log"; then
      status=1
      continue
    fi
    if ! python3 "$TASK_DIR/scripts/episodes.py" "$folder" --run-id "$mode-seed1-run1"; then
      status=1
      continue
    fi
    if ! python3 "$TASK_DIR/scripts/verify_causes.py" "$folder"; then status=1; fi
  done
done
if ! python3 "$TASK_DIR/scripts/compare_causes.py" "$OUTPUT_DIR"; then status=1; fi
exit "$status"
