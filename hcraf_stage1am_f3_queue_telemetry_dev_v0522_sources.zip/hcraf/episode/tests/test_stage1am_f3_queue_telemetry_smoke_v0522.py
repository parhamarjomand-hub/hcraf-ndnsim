"""Simulator-free smoke preflight; never substitute for actual C++ compilation."""
import importlib.util
import json
from pathlib import Path
import sys
import unittest

ROOT=Path(__file__).resolve().parents[3]
SRC=ROOT/"hcraf/episode/src/hcraf-stage1am-f3-queue-telemetry-smoke-v0522.cpp"
SCRIPTS=ROOT/"hcraf/episode/scripts"
DOCS=ROOT/"hcraf/episode/docs/1AM/F3_CAUSAL_TELEMETRY_DEV_v0.52.2"


class QueueTelemetryPreflightV0522(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cpp=SRC.read_text()

    def test_01_separate_binary_and_never_heldout(self):
        self.assertIn("TECHNICAL TRANSPORT SMOKE",self.cpp)
        self.assertIn('"CALIBRATION"',self.cpp)
        self.assertNotIn("HELDOUT_CONFIRMATORY",self.cpp)
        self.assertIn('telemetry_smoke_only\\\":true',self.cpp)

    def test_02_uses_ndn_interest_data_not_simulated_direct_callback(self):
        for token in ("m_appLink->onReceiveInterest", "m_appLink->onReceiveData",
                      "class HcrafQueueTelemetrySource", "class HcrafQueueTelemetrySink"):
            self.assertIn(token,self.cpp)

    def test_03_online_receipt_timestamp_only_after_data(self):
        start=self.cpp.index("void OnData(std::shared_ptr<const ::ndn::Data> data) override",self.cpp.index("class HcrafQueueTelemetrySink"))
        end=self.cpp.index("void ObserveBeforeForwarding",start)
        receiver=self.cpp[start:end]
        self.assertIn("Simulator::Now().GetNanoSeconds()",receiver)
        self.assertIn("m_latest[role]",receiver)
        self.assertIn('"receipt_ns"',receiver.replace("\\", ""))

    def test_04_retrospective_logs_not_used_by_online_sink(self):
        start=self.cpp.index("class HcrafQueueTelemetrySink")
        end=self.cpp.index("NS_OBJECT_ENSURE_REGISTERED(HcrafQueueTelemetrySink)",start)
        sink=self.cpp[start:end]
        for forbidden in ("link_events.jsonl","pathwide_witness_b.jsonl","selected_slot","future_congestion"):
            self.assertNotIn(forbidden,sink)

    def test_05_science_locks(self):
        locks=json.loads((DOCS/"SCIENCE_LOCKS.json").read_text())
        self.assertEqual({k:locks[k] for k in
                         ("Congestion","FutureCongestion","F3_ready","GO_FREEZE","training_ready")},
                         {"Congestion":None,"FutureCongestion":None,"F3_ready":False,
                          "GO_FREEZE":False,"training_ready":False})
        self.assertFalse(locks["heldout_release_authorized"])

    def test_06_fail_closed_receipt_contract_synthetic(self):
        spec=importlib.util.spec_from_file_location("validator",SCRIPTS/"validate_online_queue_telemetry_v0522.py")
        module=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        self.assertEqual(module.selftest()["status"],"PASS_SYNTHETIC_SCHEMA_TESTS_ONLY")

    def test_07_exact_source_sender_role_and_report_id(self):
        for token in ('{"relay",relayDown}', '{"mid",midDown}', '{"producer",producerDown}',
                      '"/hcraf/telemetry/"', 'm_latest.count(role)', 'm_outOfOrderDiscarded'):
            self.assertIn(token,self.cpp)

    def test_08_workflow_no_heldout_input(self):
        workflow=(DOCS/"WORKFLOW_CONTRACT_FA.md").read_text()
        self.assertIn("CALIBRATION تاریخی فقط به‌عنوان fixture فنی",workflow)
        self.assertIn("بدون آزادسازی HELDOUT",workflow)


if __name__=="__main__":
    unittest.main()
