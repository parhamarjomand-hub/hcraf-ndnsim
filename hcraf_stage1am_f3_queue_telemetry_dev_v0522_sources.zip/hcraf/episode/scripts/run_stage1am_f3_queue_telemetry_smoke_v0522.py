#!/usr/bin/env python3
"""Technical NDN telemetry transport smoke, NEVER confirmatory F3 CALIBRATION.

Reuses a few *previously seen* v0.52.0 CALIBRATION schedules only as immutable
network load fixtures; no supervised model, no candidate-label evaluation.
"""
import argparse
from collections import Counter
import json
import pathlib
import subprocess

from run_stage1am_f3_future_path_queue_calibration_v0521 import (
    ROOT,matrix,locked_plan,simulation_args,assert_send_plan,check,LOCKS,
)
from validate_online_queue_telemetry_v0522 import validate,read_lines

BIN="hcraf-stage1am-f3-queue-telemetry-smoke-v0522"
DEST=ROOT/"episode_output/stage1am_f3_telemetry_smoke_v0522"
ARMS=("PRODUCER_RETURN_12M","ALL_RETURN_50M","NONQUEUE_RX_LOSS_50M")


def selections():
    rows,_=matrix()
    indexed={(r["rng_block"],r["family"],r["arm"]):r
             for r in rows if r["arm"] in ARMS and r["instrumented"]=="1"}
    keys={(rng,fam) for rng,fam,arm in indexed if arm==ARMS[0]}
    for arm in ARMS[1:]:
        keys&={(rng,fam) for rng,fam,a in indexed if a==arm}
    check(bool(keys),"NO_COMMON_MONITORED_TECHNICAL_FIXTURE")
    rng,fam=min(keys)
    check(int(rng) in range(22001,22013),"UNREGISTERED_FIXTURE_RNG")
    return [indexed[(rng,fam,arm)] for arm in ARMS]


def spec(row,dest,period,enabled):
    old=simulation_args(row,dest)
    check(old.startswith("hcraf-stage1am-f3-future-path-queue-calibration-v0521 "),
          "PARENT_EXE_CHANGED")
    return (BIN+old[len("hcraf-stage1am-f3-future-path-queue-calibration-v0521"):]
            +f" --telemetryEnabled={int(enabled)} --telemetryPeriodMs={period}")


def verify_transport(dest,enabled):
    config=json.loads((dest/"scenario.json").read_text())
    check(config["holdout_partition"]=="CALIBRATION" and
          config["telemetry_smoke_only"] and not config["telemetry_path_discovery_independently_audited"],
          "SMOKE_SCIENCE_FENCE_MISSING")
    for key,value in LOCKS.items():
        check(config[key] is value,"SCIENCE_LOCK_BROKEN:"+key)
    if not enabled:
        check(not (dest/"queue_telemetry_receipts.jsonl").exists(),
              "BASELINE_SHOULD_HAVE_NO_REPORTS")
        return {"telemetry_enabled":False,"transport_checked":False}
    receipt_path=dest/"queue_telemetry_receipts.jsonl"
    decisions_path=dest/"queue_telemetry_decisions.jsonl"
    sent_path=dest/"queue_telemetry_sent.jsonl"
    request_path=dest/"queue_telemetry_requests.jsonl"
    for p in (receipt_path,decisions_path,sent_path,request_path):
        check(p.is_file(),"MISSING_REAL_NETWORK_TELEMETRY_LOG:"+str(p))
    receipts=list(read_lines(receipt_path));decisions=list(read_lines(decisions_path))
    sent=list(read_lines(sent_path));requests=list(read_lines(request_path))
    check(bool(receipts) and bool(sent) and bool(requests) and bool(decisions),
          "NO_ACTUAL_NETWORK_TRANSPORT_RECEIPTS")
    check(all(r["receipt_ns"]>=r["sample_ns"] for r in receipts),"NEGATIVE_TRANSIT_TIME")
    check({r["source_node_id"] for r in receipts}==
          {v["node_id"] for v in decisions[0]["selected_sender_sources"]},
          "MISSING_REMOTE_SOURCE_ROLE")
    # 500ms is a permissive TECHNICAL bound, not a frozen science threshold.
    contract=validate(receipts,decisions,max_age_ns=500_000_000)
    check(not contract["status"].startswith("FAIL"),"CAUSAL_RECEIPT_CONTRACT_FAILURE")
    lag=[r["receipt_ns"]-r["sample_ns"] for r in receipts]
    lag.sort()
    return {"telemetry_enabled":True,"source_roles":dict(Counter(
            r["source_node_id"] for r in receipts)),
            "real_packets_requested":len(requests),"real_reports_sent":len(sent),
            "real_reports_received":len(receipts),
            "real_request_wire_bytes":sum(r["interest_wire_bytes"] for r in requests),
            "real_report_wire_bytes_at_sender":sum(r["data_wire_bytes"] for r in sent),
            "receive_age_ms_min":lag[0]/1e6,
            "receive_age_ms_p50":lag[len(lag)//2]/1e6,
            "receive_age_ms_max":lag[-1]/1e6,
            "observer_coverage_3_of_3_including_possible_control_interests":contract["valid_3_of_3_decisions"]/len(decisions),
            "contract":contract,
            "note":"Real NDN Interest/Data; decision observer may include control Interests; no independent route attestation or scientific F3 claim"}


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--preflight-only",action="store_true")
    args=p.parse_args()
    rows=selections()
    if args.preflight_only:
        print(json.dumps({"status":"PASS_TECHNICAL_FIXTURE_SELECTION_ONLY",
                          "arms":[r["arm"] for r in rows],
                          "rng":rows[0]["rng_block"],"family":rows[0]["family"],
                          "historically_seen":True,"heldout_runs_executed":0,
                          "models_trained":0,**LOCKS},indent=2))
        return
    check((ROOT/"episode_sources/ns-3/build/scratch"/BIN).is_file(),"TELEMETRY_CXX_BINARY_MISSING")
    check(not DEST.exists(),"REFUSE_OVERWRITE_PREVIOUS_TELEMETRY_SMOKE")
    results=[]
    for row in rows:
        for tag,period,enabled in (("baseline",20,False),("telemetry20",20,True),
                                   ("telemetry50",50,True)):
            dest=DEST/row["arm"]/tag
            dest.mkdir(parents=True,exist_ok=False)
            command=spec(row,dest,period,enabled)
            (dest/"command.txt").write_text(command+"\n")
            (dest/"fixed_technical_fixture.json").write_text(json.dumps(row,indent=2)+"\n")
            with (dest/"simulator.log").open("w") as log:
                subprocess.run(["/usr/bin/time","-f","wall_seconds=%e\\nmax_rss_kib=%M",
                                "-o",str(dest/"resource_usage.txt"),"python3","./waf",
                                "--run-no-build",command],
                               cwd=ROOT/"episode_sources/ns-3",stdout=log,
                               stderr=subprocess.STDOUT,check=True)
            assert_send_plan(dest,locked_plan(row))
            result=verify_transport(dest,enabled)
            result.update(arm=row["arm"],period_ms=period,profile=tag,
                          original_rng_block=row["rng_block"],
                          science_claim="NONE_TECHNICAL_SMOKE_ONLY")
            (dest/"telemetry_transport_audit.json").write_text(json.dumps(result,indent=2)+"\n")
            results.append(result)
            print("TECHNICAL_RUN_OK",row["arm"],tag,result.get("real_reports_received",0),flush=True)
    report={"status":"TECHNICAL_TRANSPORT_SMOKE_ONLY_NOT_F3_VALIDATION",
            "runs":len(results),"historical_calibration_schedules_reused_as_technical_fixture":True,
            "heldout_runs_executed":0,"new_rng_confirmatory_runs":0,
            "F3_science_gate":"CLOSED",**LOCKS,"results":results}
    (DEST/"technical_smoke_summary.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps({k:v for k,v in report.items() if k!="results"},indent=2))


if __name__=="__main__":
    main()
