#!/usr/bin/env python3
"""Fail-closed contract validator for a future v0.52.2 ns-3 telemetry exporter.

This script proves only the schema/time checks on supplied receipt records.
It does not implement message transport or assert any current ndnSIM binary
emits the expected traces. --selftest uses synthetic data only.
"""
import argparse
from collections import Counter,defaultdict
import json
from pathlib import Path


def read_lines(path):
    with path.open(encoding="utf-8") as f:
        for line_number,line in enumerate(f,1):
            if line.strip():
                try:
                    yield json.loads(line)
                except json.JSONDecodeError as exc:
                    raise ValueError(f"Malformed JSON at {path}:{line_number}") from exc


def validate(receipts,decisions,max_age_ns=100_000_000):
    errs=[]
    by_id={}
    by_source=defaultdict(list)
    if not receipts or not decisions:
        return {"status":"INCOMPLETE_TELEMETRY_FOR_DECISIONS",
                "num_receipts":len(receipts),"num_decisions":len(decisions),
                "valid_3_of_3_decisions":0,"unavailable_receipt_references":0,
                "errors":["NO_RECEIPTS_OR_DECISIONS"],"heldout_runs_executed":0,
                "real_transport_proven":False,"F3_ready":False}
    nonnegative_int=lambda v: type(v) is int and v>=0
    for r in receipts:
        required=("report_id","source_node_id","source_device_index","path_id",
                  "counter_epoch","sequence","sample_ns","receipt_ns",
                  "queue_enqueue_packets_total","queue_drop_packets_total",
                  "queue_packets_now","payload_bytes")
        if not isinstance(r,dict) or any(k not in r for k in required):
            errs.append("MISSING_RECEIPT_FIELD")
            continue
        if (not isinstance(r["report_id"],str) or not r["report_id"]
            or not isinstance(r["path_id"],str) or not r["path_id"]
            or not isinstance(r["counter_epoch"],str) or not r["counter_epoch"]
            or any(not nonnegative_int(r[k]) for k in
                   ("source_node_id","source_device_index","sequence","sample_ns",
                    "receipt_ns","queue_enqueue_packets_total","queue_drop_packets_total",
                    "queue_packets_now","payload_bytes"))):
            errs.append("INVALID_RECEIPT_TYPE")
            continue
        rid=str(r["report_id"])
        if rid in by_id:
            errs.append(f"REPLAY_OR_DUPLICATE_REPORT:{rid}")
            continue
        by_id[rid]=r
        if r["receipt_ns"]<r["sample_ns"]:
            errs.append(f"INVALID_TIMESTAMP_OR_COUNTER:{rid}")
        source=(r["path_id"],r["source_node_id"],r["source_device_index"])
        by_source[source].append(r)
    for source,rows in by_source.items():
        rows.sort(key=lambda r:r["receipt_ns"])
        last={}
        for r in rows:
            key=r["counter_epoch"]
            past=last.get(key)
            if past is not None:
                if (r["sequence"]<=past["sequence"] or
                    r["sample_ns"]<=past["sample_ns"] or
                    r["queue_enqueue_packets_total"]<past["queue_enqueue_packets_total"] or
                    r["queue_drop_packets_total"]<past["queue_drop_packets_total"]):
                    errs.append(f"COUNTER_REGRESSION_OR_REPLAY:{r['report_id']}")
            last[key]=r
    valid_decisions=0
    missing=0
    seen_decisions=set()
    for d in decisions:
        if (not isinstance(d,dict) or any(k not in d for k in
                ("decision_id","decision_ns","selected_path_id",
                 "selected_sender_sources","feature_evidence"))):
            errs.append("MISSING_DECISION_FIELD")
            continue
        did=d["decision_id"]
        if (not isinstance(did,(int,str)) or isinstance(did,bool)
            or not nonnegative_int(d["decision_ns"])
            or not isinstance(d["selected_path_id"],str) or not d["selected_path_id"]
            or not isinstance(d["selected_sender_sources"],list)
            or not isinstance(d["feature_evidence"],list)
            or any(not isinstance(e,dict) for e in
                   d["selected_sender_sources"]+d["feature_evidence"])):
            errs.append("INVALID_DECISION_TYPE")
            continue
        if did in seen_decisions:
            errs.append(f"DUPLICATE_DECISION:{did}")
        seen_decisions.add(did)
        if (any("source_node_id" not in e or "source_device_index" not in e or
                "report_id" not in e for e in d["feature_evidence"])
            or any("node_id" not in e or "device_index" not in e for e in
                   d["selected_sender_sources"])):
            errs.append(f"MALFORMED_DEVICE_REFERENCE:{did}")
            continue
        actual={(e["source_node_id"],e["source_device_index"]) for e in d["feature_evidence"]}
        expected={(e["node_id"],e["device_index"]) for e in d["selected_sender_sources"]}
        if len(expected)!=3 or len(actual)!=len(d["feature_evidence"]) or len(d["feature_evidence"])!=3:
            errs.append(f"INVALID_DEVICE_CARDINALITY:{did}")
        found=0
        for evidence in d["feature_evidence"]:
            r=by_id.get(str(evidence.get("report_id")))
            if r is None:
                continue
            source=(r["source_node_id"],r["source_device_index"])
            if (source not in expected or source!=(evidence["source_node_id"],evidence["source_device_index"])
                or r["path_id"]!=d["selected_path_id"]):
                errs.append(f"INVALID_ROUTE_ATTRIBUTION:{did}")
                continue
            if (not r["sample_ns"]<=r["receipt_ns"]<=d["decision_ns"]
                or d["decision_ns"]-r["sample_ns"]>max_age_ns):
                errs.append(f"FUTURE_OR_STALE_TELEMETRY:{did}")
                continue
            found+=1
        if found==3 and actual==expected:
            valid_decisions+=1
        else:
            missing+=max(0,3-found)
    status=("FAIL_SCHEMA_OR_CAUSAL_RECEIPT_PRECHECK" if errs else
            "INCOMPLETE_TELEMETRY_FOR_DECISIONS" if valid_decisions<len(decisions) else
            "PASS_SCHEMA_AND_CAUSAL_RECEIPT_PRECHECK_ONLY")
    return {"status":status,
            "num_receipts":len(receipts),"num_decisions":len(decisions),
            "valid_3_of_3_decisions":valid_decisions,
            "unavailable_receipt_references":missing,
            "errors":errs[:100],"heldout_runs_executed":0,
            "real_transport_proven":False,"F3_ready":False}


def selftest():
    receipts=[{
        "report_id":f"r{k}","source_node_id":k,"source_device_index":0,
        "path_id":"path-A","counter_epoch":"epoch-0","sequence":1,
        "sample_ns":100_000_000,"receipt_ns":110_000_000,
        "queue_enqueue_packets_total":100,"queue_drop_packets_total":2,
        "queue_packets_now":3,"payload_bytes":100} for k in (2,7,8)]
    decisions=[{"decision_id":1,"decision_ns":120_000_000,
                "selected_path_id":"path-A",
                "selected_sender_sources":[{"node_id":k,"device_index":0} for k in (2,7,8)],
                "feature_evidence":[{"source_node_id":k,"source_device_index":0,
                                     "report_id":f"r{k}"} for k in (2,7,8)]}]
    clean=validate(receipts,decisions)
    assert clean["status"].startswith("PASS") and clean["valid_3_of_3_decisions"]==1
    late=[dict(r) for r in receipts]
    late[0]["receipt_ns"]=125_000_000
    assert validate(late,decisions)["status"].startswith("FAIL")
    replay=receipts+[dict(receipts[0])]
    assert validate(replay,decisions)["status"].startswith("FAIL")
    absent=[dict(d) for d in decisions]
    absent[0]["feature_evidence"]=[dict(e) for e in decisions[0]["feature_evidence"]]
    absent[0]["feature_evidence"][0]["report_id"]="missing"
    assert validate(receipts,absent)["status"]=="INCOMPLETE_TELEMETRY_FOR_DECISIONS"
    assert validate([],decisions)["status"]=="INCOMPLETE_TELEMETRY_FOR_DECISIONS"
    assert validate(receipts,[])["status"]=="INCOMPLETE_TELEMETRY_FOR_DECISIONS"
    wrong_path=[dict(d) for d in decisions]
    wrong_path[0]["selected_path_id"]="other-path"
    assert validate(receipts,wrong_path)["status"].startswith("FAIL")
    duplicate_evidence=[dict(d) for d in decisions]
    duplicate_evidence[0]["feature_evidence"]=[decisions[0]["feature_evidence"][0]]*3
    assert validate(receipts,duplicate_evidence)["status"].startswith("FAIL")
    return {"status":"PASS_SYNTHETIC_SCHEMA_TESTS_ONLY", "cases":8,
            "real_transport_proven":False,"F3_ready":False}


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--selftest",action="store_true")
    p.add_argument("--receipts",type=Path)
    p.add_argument("--decisions",type=Path)
    p.add_argument("--summary",type=Path)
    o=p.parse_args()
    if o.selftest:
        result=selftest()
    else:
        if not o.receipts or not o.decisions:
            p.error("--receipts and --decisions are required unless --selftest")
        result=validate(list(read_lines(o.receipts)),list(read_lines(o.decisions)))
    if o.summary:
        o.summary.parent.mkdir(parents=True,exist_ok=True)
        o.summary.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(result,indent=2))
    return 0 if result["status"].startswith("PASS") else 2


if __name__=="__main__":
    raise SystemExit(main())
