# HCRAF Stage 1AM F3 — v0.51.8 Hotfix P2

This additive package performs only an independent, no-resimulation recovery of existing shard 1 and
adds a **new**, distinctly named Executor Workflow for shards 2..7. It does not change any existing
ndnSIM source, pinned v0.51.7 matrix, observer recordings, or F3 scientific states.

Sources are pinned by SHA-256. The new Executor verifies the patch was applied to the old verifier
**before** compiling or executing even one simulation. Shards 0 and 1 are blocked in that Executor.

Do not call this a final F3 validation; 1AN and 1AO stay gated.
