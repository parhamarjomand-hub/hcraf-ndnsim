#!/usr/bin/env python3
"""Re-audit immutable 27-run shard 1 Artifact in GitHub without invoking ndnSIM.
P2 recovery is structural Development evidence only; it cannot assign official F3 labels.
"""
import argparse, hashlib, json, pathlib, subprocess, sys, csv
from repair_stage1am_f3_bottleneck_relocation_v0518_p1 import restore, apply, check, sha

ROOT=pathlib.Path.cwd()
PRE=ROOT/'episode_output/v0518_preflight'
OUT=ROOT/'episode_output/v0518_recovery_shard1'
EXPECTED_RUN='43261271719'
EXPECTED_SOURCE_SHA='5ebc2b0b62bc4519c945fad63d734bc8b45c7598'
LOCK_RUN='43242291541'
MATRIX_SHA='6c66dfefce2abcc73e8c07fdb0afa7ef892524e74b8eb2a004a4181942180649'
EXPECTED_LOG_COUNT=27
EXPECTED_LOCKS={'Congestion':None,'FutureCongestion':None,'F3_ready':False,'GO_FREEZE':False,'training_ready':False}

def recover(run_id):
    check(str(run_id)==EXPECTED_RUN,'WRONG_SOURCE_RUN_NOT_SHARD1')
    check(PRE.is_dir(),'ARTIFACT_PREFLIGHT_ABSENT')
    diagnostic=(PRE/'EXECUTOR_RUN_DIAGNOSTICS.txt').read_text()
    check('run_id='+EXPECTED_RUN in diagnostic and 'shard_id=1' in diagnostic
          and 'simulation=failure' in diagnostic,'WRONG_FAILED_RUN_DIAGNOSTICS')
    check('git_sha='+EXPECTED_SOURCE_SHA in diagnostic,'ORIGINAL_GIT_COMMIT_MISMATCH')
    log_path=PRE/'shard_simulation_and_audit.log'
    log=log_path.read_text()
    check(log.count('RUN_OK ')==EXPECTED_LOG_COUNT and "KeyError: 'node_id'" in log,
          'NOT_THE_EXPECTED_POSTSIMULATION_SCHEMA_ERROR')
    receipt=json.loads((PRE/'lock_artifact/prereg_lock_receipt.json').read_text())
    check(str(receipt['github_run_id'])==LOCK_RUN,'WRONG_OR_EXPIRED_LOCK_RUN')
    check(receipt['matrix_sha256']==MATRIX_SHA,'PREREG_MATRIX_HASH_MISMATCH')
    for k,v in EXPECTED_LOCKS.items():check(receipt.get(k) is v,'F3_GATE_CHANGED:'+k)
    check(not (ROOT/'episode_output/stage1am_f3_bottleneck_relocation_report/shard_01').exists(),
          'REFUSE_OVERWRITE_EXISTING_SHARD1_AUDIT')
    OUT.mkdir(parents=True,exist_ok=True)
    # Reconstruct ONLY original immutable code and locked declarations (never simulate).
    restore()
    patch=apply()
    check(patch['status']=='PASS_VERIFIER_SCHEMA_HOTFIX_P1','PATCH_NOT_APPLIED')
    verifier=ROOT/'hcraf/episode/scripts/verify_stage1am_f3_bottleneck_relocation_dev.py'
    check(sha(verifier)=='5a4e59324158c714b6bdfebe4c0976379512f140ef6331e55a147ce89ce6ce8f',
          'VERIFIER_POSTPATCH_SHA_MISMATCH')
    cmd=[sys.executable,str(verifier),'--shard-id','1']
    with (OUT/'audit.log').open('w') as f:
        completed=subprocess.run(cmd,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,check=False)
    check(completed.returncode==0,'RECOVERY_AUDIT_FAILED_READ_AUDIT_LOG')
    path=ROOT/'episode_output/stage1am_f3_bottleneck_relocation_report/shard_01'
    summary=json.loads((path/'summary.json').read_text())
    check(summary['status']=='PASS_BOTTLENECK_RELOCATION_SHARD_STRUCTURAL_DEV_ONLY'
          and summary['shard_id']==1 and summary['arm']=='PRODUCER_RETURN_12M',
          'RECOVERED_STATUS_OR_ARM_WRONG')
    check(summary['runs']==27 and summary['monitored_runs']==24 and summary['unmonitored_runs']==3,
          'RECOVERED_RUN_COUNTS_WRONG')
    check(summary['whole_matrix_completed'] is False
          and summary['final_F3_validated'] is False
          and summary['scientific_construct_validated'] is False
          and summary['historical_stage1s_full_regression_verified'] is False,
          'RECOVERY_SCOPE_OVERRUN')
    for k,v in EXPECTED_LOCKS.items():check(summary[k] is v,'RECOVERY_SCIENCE_LOCK_OPENED:'+k)
    with (path/'shard_reconciliation.csv').open(newline='') as f: rows=list(csv.DictReader(f))
    check(len(rows)==27 and sum(int(r['instrumented']) for r in rows)==24,'RECONCILIATION_COUNT')
    monitored=[r for r in rows if int(r['instrumented'])==1]
    check(all(r['a_b_agreement']=='PASS_EVENT_LEVEL' and int(r['devices'])==20
              and int(r['path_devices'])==8 and int(r['path_queue_drops'])==int(r['total_queue_drops'])
              for r in monitored),'A_B_MISMATCH_OR_OFF_PATH_DROPS')
    check({r['arm'] for r in rows}=={'PRODUCER_RETURN_12M'},'WRONG_ARM')
    result={
      'status':'PASS_RECOVERED_SHARD1_STRUCTURAL_DEV_ONLY_NO_RESIMULATION',
      'source_run_id':EXPECTED_RUN,'source_commit':EXPECTED_SOURCE_SHA,
      'lock_run_id':LOCK_RUN,'shard_id':1,'arm':'PRODUCER_RETURN_12M',
      'runs':27,'monitored_runs':24,'unmonitored_runs':3,
      'physical_events_A_B':sum(int(r['physical_events']) for r in monitored),
      'path_queue_drops':sum(int(r['path_queue_drops']) for r in monitored),
      'off_path_queue_drops':sum(int(r['total_queue_drops'])-int(r['path_queue_drops']) for r in monitored),
      'source_simulations_reexecuted':0,'F3_final_validated':False,
      'historical_stage1s_tests_deferred':20,'verifier_sha256':sha(verifier),
      'original_failed_log_sha256':sha(log_path),'sciences_locks':EXPECTED_LOCKS,
    }
    (OUT/'RECOVERY_RECEIPT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
    (OUT/'PATCH_RECEIPT.json').write_text(json.dumps(patch,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--source-run-id',required=True)
    args=parser.parse_args();recover(args.source_run_id)
