#!/usr/bin/env python3
"""Additive v0.51.8 P1 schema hotfix and no-resimulation shard-0 audit.
No formal scientific labels, no simulator execution, no changes to locked preregistration.
"""
import argparse,csv,hashlib,io,json,os,pathlib,shutil,subprocess,sys,zipfile

ROOT=pathlib.Path.cwd()
SRC=ROOT/'hcraf/episode/scripts/verify_stage1am_f3_bottleneck_relocation_dev.py'
PARENT=ROOT/'hcraf/episode/docs/1AM/F3_PATHWIDE_WITNESS_DEV_v0.51.5/PATH_MAP_LOCKED_24.csv'
OLD="path={(int(x['node_id']),int(x['device_index'])) for x in oldmap if int(x['slot'])==slot}"
NEW="path={(int(x['sender_node_id']),int(x['device_index'])) for x in oldmap if int(x['slot'])==slot}"
BEFORE='6293e8b089041d129e27cb03d482ade829fa8b0a954c4501defac0f09f674a59'
AFTER='5a4e59324158c714b6bdfebe4c0976379512f140ef6331e55a147ce89ce6ce8f'
OLD_SOURCE_ZIP='hcraf_stage1am_f3_bottleneck_relocation_executor_v0518_sources.zip'
OLD_SOURCE_SHA='a2723c201b48d61e862d24d7cfc51e08b4782642d3e9b3e480aea9961dba788d'
WITNESS_ZIP='hcraf_stage1am_f3_pathwide_witness_dev_v0515_sources.zip'
WITNESS_SHA='bfbd90c638692ba241a161eaf5dcadfbc7dceae82ba4d5f236e863b2d849b28f'
EXPECTED_MATRIX='6c66dfefce2abcc73e8c07fdb0afa7ef892524e74b8eb2a004a4181942180649'
EXPECTED_SOURCE_RUN='43248203936'
EXPECTED_LOCK_RUN='43242291541'
EXPECTED_SOURCE_SHA='bdfef1cd118b3d17392f6f8e1b518eea5ab227ce'
LOCK_CONTRACT='hcraf/episode/docs/1AM/F3_PATHWIDE_BOTTLENECK_RELOCATION_PREREG_v0.51.7'


def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def check(cond,msg):
 if not cond:raise RuntimeError(msg)

def apply():
 check(SRC.is_file() and PARENT.is_file(),'MISSING_VERIFIER_OR_PARENT_MAP')
 with PARENT.open(newline='') as f:
  r=list(csv.DictReader(f))
 check(len(r)==24,'UNEXPECTED_PARENT_MAP_LENGTH')
 check({'slot','sender_node_id','device_index','direction','receiver_node_id'}.issubset(set(r[0])),'MISSING_PARENT_MAP_COLUMNS')
 check('node_id' not in r[0],'PARENT_MAP_SCHEMA_UNEXPECTEDLY_CHANGED')
 source=SRC.read_text()
 if sha(SRC)==AFTER:
  check(source.count(NEW)==1 and OLD not in source,'PATTERN_POSTCONDITION')
  outcome='ALREADY_APPLIED_IDENTICAL'
 else:
  check(sha(SRC)==BEFORE,'UNEXPECTED_ORIGINAL_VERIFIER_HASH')
  check(source.count(OLD)==1 and NEW not in source,'BAD_ORIGINAL_PATTERN_COUNT')
  SRC.write_text(source.replace(OLD,NEW))
  check(sha(SRC)==AFTER,'VERIFIER_PATCH_HASH_MISMATCH')
  outcome='PATCHED_ONLY_VERIFIER_SCHEMA_KEY'
 return {'status':'PASS_VERIFIER_SCHEMA_HOTFIX_P1','mode':outcome,'original_sha256':BEFORE,'patched_sha256':AFTER,
         'parent_map_rows':24,'changes_to_scientific_contract':0}

def restore():
 check(sha(OLD_SOURCE_ZIP)==OLD_SOURCE_SHA,'IMMUTABLE_OLD_EXECUTOR_ZIP_CHANGED')
 check(sha(WITNESS_ZIP)==WITNESS_SHA,'IMMUTABLE_WITNESS_ZIP_CHANGED')
 with zipfile.ZipFile(OLD_SOURCE_ZIP) as z:
  check(z.testzip() is None,'OLD_EXECUTOR_CRC_FAILED')
  for member in ['hcraf/episode/scripts/run_stage1am_f3_bottleneck_relocation_dev.py',
                 'hcraf/episode/scripts/verify_stage1am_f3_bottleneck_relocation_dev.py']:
   dest=ROOT/member;dest.parent.mkdir(parents=True,exist_ok=True);raw=z.read(member)
   if dest.exists():check(dest.read_bytes()==raw or (member.endswith('verify_stage1am_f3_bottleneck_relocation_dev.py') and sha(dest)==AFTER),'REFUSE_DIFFERENT_EXISTING_FILE:'+member)
   else:dest.write_bytes(raw)
 with zipfile.ZipFile(WITNESS_ZIP) as z:
  check(z.testzip() is None,'WITNESS_ZIP_CRC_FAILED')
  m='hcraf/episode/docs/1AM/F3_PATHWIDE_WITNESS_DEV_v0.51.5/PATH_MAP_LOCKED_24.csv'
  dest=ROOT/m;dest.parent.mkdir(parents=True,exist_ok=True);raw=z.read(m)
  if dest.exists():check(dest.read_bytes()==raw,'REFUSE_CHANGED_PARENT_MAP')
  else:dest.write_bytes(raw)
 src=ROOT/'episode_output/v0518_preflight/lock_artifact/staged'/LOCK_CONTRACT
 dst=ROOT/LOCK_CONTRACT
 check(src.is_dir(),'LOCK_ARTIFACT_STAGED_CONTRACT_MISSING')
 locked=json.loads((ROOT/'episode_output/v0518_preflight/locked_design_verification.json').read_text())
 check(locked['file_sha256']['RUN_MATRIX_LOCKED_216.csv']==EXPECTED_MATRIX,'LOCKED_DESIGN_MATRIX_SHA_CHANGED')
 for f in src.rglob('*'):
  if not f.is_file():continue
  out=dst/f.relative_to(src);out.parent.mkdir(parents=True,exist_ok=True)
  if out.exists():check(out.read_bytes()==f.read_bytes(),'REFUSE_CHANGED_CONTRACT:'+str(f))
  else:shutil.copyfile(f,out)
 for name,value in locked['file_sha256'].items():
  check(sha(dst/name)==value,'LOCKED_FILE_HASH_MISMATCH:'+name)
 return True

def recover(src_run):
 check(str(src_run)==EXPECTED_SOURCE_RUN,'WRONG_SOURCE_RUN_FOR_P1_SHARD0')
 pre=ROOT/'episode_output/v0518_preflight'
 check(pre.is_dir(),'MISSING_ARTIFACT_PREFLIGHT')
 diag=(pre/'EXECUTOR_RUN_DIAGNOSTICS.txt').read_text()
 check('run_id='+EXPECTED_SOURCE_RUN in diag and 'shard_id=0' in diag and 'simulation=failure' in diag,'SOURCE_RUN_DIAGNOSTIC_MISMATCH')
 check('git_sha='+EXPECTED_SOURCE_SHA in diag,'SOURCE_GIT_SHA_MISMATCH')
 log=(pre/'shard_simulation_and_audit.log').read_text()
 check(log.count('RUN_OK ')==27 and "KeyError: 'node_id'" in log,'EXPECTED_27_RUN_SCHEMA_FAILURE_NOT_FOUND')
 receipt=json.loads((pre/'lock_artifact/prereg_lock_receipt.json').read_text())
 check(str(receipt['github_run_id'])==EXPECTED_LOCK_RUN and receipt['matrix_sha256']==EXPECTED_MATRIX,
       'PREREG_RECEIPT_INVALID')
 check(all(receipt[k] is v for k,v in {'Congestion':None,'FutureCongestion':None,'F3_ready':False,'GO_FREEZE':False,'training_ready':False}.items()),'SCIENCE_LOCK_CHANGED')
 restore()
 patched=apply()
 runner=ROOT/'hcraf/episode/scripts/verify_stage1am_f3_bottleneck_relocation_dev.py'
 audit_log=ROOT/'episode_output/v0518_recovery/audit.log'
 audit_log.parent.mkdir(parents=True,exist_ok=True)
 with audit_log.open('w') as log:
  p=subprocess.run([sys.executable,str(runner),'--shard-id','0'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
 check(p.returncode==0,'RECOVERED_AUDIT_FAILED_SEE_LOG')
 summary=ROOT/'episode_output/stage1am_f3_bottleneck_relocation_report/shard_00/summary.json'
 reconc=ROOT/'episode_output/stage1am_f3_bottleneck_relocation_report/shard_00/shard_reconciliation.csv'
 check(summary.exists() and reconc.exists(),'MISSING_RECOVERED_REPORT')
 obj=json.loads(summary.read_text())
 check(obj['status']=='PASS_BOTTLENECK_RELOCATION_SHARD_STRUCTURAL_DEV_ONLY' and obj['runs']==27 and obj['monitored_runs']==24 and obj['unmonitored_runs']==3,'REPORT_CONTENT_INVALID')
 check(not obj['final_F3_validated'] and not obj['scientific_construct_validated'],'INVALID_SCIENTIFIC_CLAIM')
 for k,v in {'Congestion':None,'FutureCongestion':None,'F3_ready':False,'GO_FREEZE':False,'training_ready':False}.items():check(obj[k] is v,'SCIENCE_GATE_OPENED')
 with reconc.open(newline='') as f:rows=list(csv.DictReader(f))
 check(len(rows)==27 and sum(int(x['instrumented']) for x in rows)==24,'BAD_SHARD_COUNTS')
 check(all(r['a_b_agreement']=='PASS_EVENT_LEVEL' and int(r['path_devices'])==8 and int(r['devices'])==20 for r in rows if r['instrumented']=='1'),'AB_OR_PATHWIDE_FAIL')
 info={'status':'PASS_RECOVERED_SHARD0_STRUCTURAL_DEV_ONLY_NO_RESIMULATION','source_run_id':EXPECTED_SOURCE_RUN,
       'lock_run_id':EXPECTED_LOCK_RUN,'simulations_reexecuted':0,'runs_covered':27,'monitored':24,'unmonitored':3,
       'physical_events':sum(int(x['physical_events']) for x in rows if x['instrumented']=='1'),
       'path_queue_drops':sum(int(x['path_queue_drops']) for x in rows if x['instrumented']=='1'),
       'off_path_queue_drops':sum(int(x['total_queue_drops'])-int(x['path_queue_drops']) for x in rows if x['instrumented']=='1'),
       'verifier_hotfix':patched,'full_historical_regression':'DEFERRED_STAGE1S_FIXTURES',
       'final_F3_validated':False,'scientific_construct_validated':False,
       'Congestion':None,'FutureCongestion':None,'F3_ready':False,'GO_FREEZE':False,'training_ready':False}
 (audit_log.parent/'RECOVERY_RECEIPT.json').write_text(json.dumps(info,indent=2,sort_keys=True)+'\n')
 return info

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('command',choices=['apply','recover']);p.add_argument('--source-run-id',default=EXPECTED_SOURCE_RUN)
 a=p.parse_args();print(json.dumps(apply() if a.command=='apply' else recover(a.source_run_id),indent=2))
