#!/usr/bin/env python3
"""P12-B static safety gates, deterministic physical-plan replay, raw recovery."""
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import run_stage1am_f3_p12_pilot_v05216 as p12
from generate_stage1am_f3_p12_randomized_pilot_v05215 import (
    SEEDS,SITES,LOADS,allocation,rows,events,filename,FAMILY,
)


class PilotOnlyP12BTests(unittest.TestCase):
    def test_new_parent_p12a_locked_24_unchanged(self):
        p12.check_locked()
        cases=p12.plan()
        self.assertEqual(len(cases),24)
        self.assertEqual({r['seed'] for r in cases},{23401,23402})
        self.assertEqual(len({(r['seed'],r['site'],r['load'],r['telemetry'])
                              for r in cases}),24)
        self.assertEqual({r['scientific_partition'] for r in cases},{'PILOT_EXCLUDED'})
        self.assertEqual({r['eligible_to_execute_in_P12A'] for r in cases},{'false'})
        self.assertTrue(all(not r['validation_or_heldout']=='true' for r in cases))
        self.assertEqual(p12.preflight()['simulations_in_preflight'],0)

    def test_command_exact_same_p12a_csv_no_formal_arms(self):
        for row in p12.plan():
            cmd=p12.command(row,Path('/tmp/isolated-pilot'))
            a=allocation()[(row['seed'],row['site'])]
            self.assertIn('--scheduleFamily='+FAMILY,cmd)
            self.assertIn(filename(row['seed'],row['site'],row['load']),cmd)
            self.assertIn('--technicalQueueMaxPackets=12',cmd)
            self.assertIn('--intervalNs=330000000',cmd)
            self.assertIn('--targetOffsetNs=260000000',cmd)
            self.assertIn('--competitorIntervalNs=3600000',cmd)
            self.assertIn('--telemetryPeriodMs=20',cmd)
            self.assertIn('--prospectiveTrafficStreamSeed='+str(a['traffic_stream_seed']),cmd)
            self.assertIn('--selectedSlot='+str(a['selected_slot']),cmd)
            self.assertNotIn('23301',cmd)
            self.assertNotIn('24301',cmd)
            self.assertNotIn('25301',cmd)

    def test_cpp_refuses_every_nonpilot_seed_and_requires_6_site_mapping(self):
        src=Path(__file__).resolve().parents[1]/'src/hcraf-stage1am-f3-p12-pilot-v05216.cpp'
        content=src.read_text()
        self.assertIn('P12B_WRONG_PILOT_ONLY_SEED_SITE_STREAM_OR_ROUTE',content)
        self.assertIn('P12B_SITE_SPECIFIC_PILOT_CSV_FILENAME_CHANGED',content)
        self.assertIn('P12_V05215_INDEPENDENT_TIME_COUNTERBALANCED_PILOT_LOCKED_CSV',content)
        self.assertIn('PILOT_EXCLUDED',content)
        self.assertIn('p12_pilot_excluded_from_formal_F3_partitions',content)
        for (seed,site),a in allocation().items():
            self.assertIn('{{'+str(seed)+'u,"'+site+'"},{'+
                str(a['traffic_stream_seed'])+'u,'+
                str(a['routing_stream_seed'])+'u,'+
                str(a['telemetry_stream_seed'])+'u,'+
                str(a['selected_slot'])+'u}}',content)
        for forbidden in (23301,23308,24301,25301,23501,24501,25501):
            self.assertNotIn('{{'+str(forbidden)+'u,',content)

    def test_real_send_must_match_csv_exactly(self):
        row=p12.plan()[0]
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)
            for kind,name in (('TARGET','consumer_events.jsonl'),
                              ('INDEPENDENT_COMPETITOR','competitor_events.jsonl')):
                expected=[e for e in events(row['seed'],row['site'],row['load'])
                          if e['traffic_class']==kind]
                (path/name).write_text(''.join(json.dumps({'event':'SEND',
                    'name':('/hcraf/pilot/' if kind=='TARGET' else '/hcraf/competitor/')+
                           str(e['sequence']),'time_ns':e['time_ns']})+'\n' for e in expected))
                (path/(name+'.arrivals.jsonl')).write_text(''.join(json.dumps({
                    'sequence':e['sequence'],'time_ns':e['time_ns'],
                    'schedule':'F3_P12_V05215_PILOT_EXCLUDED_LOCKED_CSV'})+'\n'
                    for e in expected))
            p12.verify_sends(path,row)
            target=path/'consumer_events.jsonl'
            source=target.read_text()
            target.write_text(source.replace('"time_ns": ', '"time_ns": 1',1))
            with self.assertRaisesRegex(RuntimeError,'ACTUAL_NDNSIM_SEND'):
                p12.verify_sends(path,row)

    def test_within100ms_diagnostics_are_exactly_future_75ms(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td)
            (d/'pathwide_witness_b.jsonl').write_text(json.dumps({
                'event_type':'QUEUE_DROP','timestamp_ns':2_080_000_000,
                'node_id':2,'device_index':0})+'\n'+json.dumps({
                'event_type':'RX_DROP','timestamp_ns':2_050_000_000,
                'node_id':2,'device_index':0})+'\n')
            (d/'events.jsonl.decisions.jsonl').write_text(''.join(json.dumps({
                'time_ns':2_000_000_000+i*1_000_000})+'\n' for i in range(108)))
            r=p12.matched_time_pairs(d,{'selected_relay_node_id':2,
                'selected_mid_node_id':5,'selected_producer_node_id':8})
            self.assertEqual(r['positive_75ms'],75)
            self.assertEqual(r['negative_75ms'],33)
            self.assertGreater(r['matched_pos_neg_pairs_same_100ms'],0)

    def test_science_no_go_not_hidden_or_silently_replaced(self):
        batch=[]
        for site in SITES:
            role={'producer_egress':'producer','transit_middle':'mid',
                  'consumer_ingress':'relay'}[site]
            for telemetry in ('off','on_20ms'):
                batch.append({'load':'high_pressure','site':site,'telemetry':telemetry,
                              'target_role':role,
                              'physical':{'physical_drops_by_role':{role:4}},
                              'within_100ms':{'positive_75ms':42,
                                             'matched_pos_neg_pairs_same_100ms':12}})
        self.assertEqual(p12.science_gate(batch),[])
        batch[1]['within_100ms']['matched_pos_neg_pairs_same_100ms']=0
        self.assertIn('NO_WITHIN_100MS_POS_NEG_PAIRS',str(p12.science_gate(batch)))
        batch[1]['physical']['physical_drops_by_role'][batch[1]['target_role']]=0
        self.assertIn('NO_ACTUAL_TARGET_QUEUE_DROP',str(p12.science_gate(batch)))

    def test_archive_raw_per_seed_full_sha_before_cleanup(self):
        with tempfile.TemporaryDirectory() as td:
            t=Path(td);seed_work=t/'temporary_raw';seed_work.mkdir()
            for n in range(101):
                (seed_work/f'physical_{n}.jsonl').write_text('QUEUE_DROP '+str(n)+'\n')
            dest=t/'artifact';dest.mkdir()
            with patch.object(p12,'DEST',dest):
                info=p12.archive_seed(23401,seed_work)
            self.assertFalse(seed_work.exists())
            blob=dest/info['raw_archive_name']
            self.assertEqual(hashlib.sha256(blob.read_bytes()).hexdigest(),info['sha256'])
            with zipfile.ZipFile(blob) as z:
                self.assertIsNone(z.testzip())
                hashes=json.loads(z.read('P12B_PILOT_RAW_FILE_SHA256.json'))
                self.assertEqual(len(hashes),101)
                self.assertTrue(all(hashlib.sha256(z.read(n)).hexdigest()==h
                                    for n,h in hashes.items()))

    def test_archive_refuses_insufficient_physical_raw_without_deletion(self):
        with tempfile.TemporaryDirectory() as td:
            t=Path(td);raw=t/'raw';raw.mkdir()
            (raw/'important.jsonl').write_text('keep\n')
            dest=t/'archive';dest.mkdir()
            with patch.object(p12,'DEST',dest):
                with self.assertRaisesRegex(RuntimeError,'INCOMPLETE_RAW'):
                    p12.archive_seed(23401,raw)
            self.assertTrue((raw/'important.jsonl').exists())


if __name__=='__main__':unittest.main()
