#!/usr/bin/env python3
"""P12-B: execute at most 24 SHA-frozen, permanently excluded PILOT cases.

No Development/Validation/Heldout simulation, model, official F3 labels or AP.
One 12-case seed is archived with full per-file CRC/SHA before any NO_GO.
"""
import argparse
from bisect import bisect_right
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

from generate_stage1am_f3_p12_randomized_pilot_v05215 import (
    PARTITION, SEEDS, SITES, LOADS, TELEMETRIES, FAMILY, SCHEMA,
    PLANS, MATRIX, COMMITMENTS, allocation, rows, events, filename,
    render_schedule, render_matrix, commitments,
)
from run_stage1am_f3_p4_route_diversity_dev_v0527 import physical_witness, check_decisions
from run_stage1am_f3_p4_revised_dev_v0529 import verify_telemetry
from build_stage1am_f3_p12_pilot_tables_v05216 import process_one


ROOT=Path(__file__).resolve().parents[3]
DEST=ROOT/'episode_output/stage1am_f3_p12_pilot_v05216'
WORK=ROOT/'episode_output/v05216_temporary_raw_seed_work'
BIN='hcraf-stage1am-f3-p12-pilot-v05216'
SCIENCE={'Congestion':None,'FutureCongestion':None,'F3_ready':False,
         'GO_FREEZE':False,'training_ready':False,
         'heldout_release_authorized':False}
EXPECTED_PARENT=dict(parent_p10_run=44591102013,
       parent_p10_commit='6bddc98b89cf47d7fca0eccc877916efe0e351a5',
       parent_p10_artifact_id=14565749815,
       parent_p10_artifact_sha256='45bfb6c2e65277d8aa00c480f2b5be789445c7d1c68670740cb049db935aa45c')


def check(ok,why):
    if not ok:raise RuntimeError('P12B_'+why)


def sha256_file(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for part in iter(lambda:f.read(1<<20),b''):h.update(part)
    return h.hexdigest()


def load_jsonl(path):
    with Path(path).open() as f:
        return [json.loads(line) for line in f if line.strip()]


def check_locked():
    check(SEEDS==(23401,23402) and PARTITION=='PILOT_EXCLUDED',
          'ONLY_TWO_NEW_PERMANENTLY_EXCLUDED_PILOT_SEEDS')
    check(MATRIX.read_bytes()==render_matrix(),'P12A_MATRIX_24_BYTE_PREIMAGE_CHANGED')
    record=json.loads(COMMITMENTS.read_text())
    check(record==commitments(),'P12A_SCHEDULE_COMMITMENTS_CHANGED')
    check(all(record[k]==v for k,v in EXPECTED_PARENT.items()),
          'P12A_PARENT_PROVENANCE_CHANGED')
    check(record['pilot_exec_authorized_now'] is False and
          record['executed_simulations']==0 and
          record['validation_or_heldout_schedules_emitted']==0,
          'P12A_DESIGN_LOCK_UNSEALED')
    check(all(record[k] is v for k,v in SCIENCE.items()),
          'P12A_SCIENCE_FENCE_CHANGED')
    expected=set()
    for seed in SEEDS:
        for site in SITES:
            for load in LOADS:
                name=filename(seed,site,load)
                path=PLANS/name
                blob=render_schedule(seed,site,load)
                check(path.is_file() and path.read_bytes()==blob,
                      'P12A_PILOT_CSV_CHANGED:'+name)
                check(hashlib.sha256(blob).hexdigest()==record['per_schedule_SHA256'][name],
                      'P12A_PILOT_CSV_SHA_CHANGED:'+name)
                expected.add(name)
            l={r['sequence']:r['time_ns'] for r in events(seed,site,'low_control')
               if r['traffic_class']=='TARGET'}
            h={r['sequence']:r['time_ns'] for r in events(seed,site,'high_pressure')
               if r['traffic_class']=='TARGET'}
            check(l==h and len(l)==12,'P12A_PAIRED_TARGET_SEND_CHANGED')
    check({p.name for p in PLANS.glob('*.csv')}==expected and len(expected)==12,
          'P12A_UNAUTHORIZED_SCHEDULE_ADDED_OR_REMOVED')


def plan():
    current=rows()
    check(len(current)==24 and {r['seed'] for r in current}==set(SEEDS),
          'NOT_EXACTLY_24_PILOT_CASES')
    check(len({(r['seed'],r['site'],r['load'],r['telemetry'])
               for r in current})==24,'DUPLICATE_PILOT_CELL')
    check(all(r['scientific_partition']==PARTITION and
              r['eligible_to_execute_in_P12A']=='false' and
              r['validation_or_heldout']=='false' and
              r['candidate_queue_capacity_packets']==12 for r in current),
          'FORMAL_F3_PARTITION_OR_P12A_LOCK_ESCAPED')
    return current


def command(row,dest):
    a=allocation()[(row['seed'],row['site'])]
    values=[f"--pathArm={row['arm']}",f"--interventionLocation={row['location']}",
            '--interventionReturnBps=12000000','--lossProbability=0',
            '--lossStream=79','--lossReceiverNodeId=-1',
            '--lossReceiverDeviceIndex=-1',
            f'--scheduleFamily={FAMILY}',
            f"--scheduleCsv={PLANS/row['schedule_filename']}",
            f"--prospectiveLoad={row['load']}",
            f"--prospectiveTrafficStreamSeed={a['traffic_stream_seed']}",
            f"--prospectiveRoutingStreamSeed={a['routing_stream_seed']}",
            f"--prospectiveTelemetryStreamSeed={a['telemetry_stream_seed']}",
            f"--selectedSlot={row['selected_slot']}",f"--run={row['seed']}",
            f'--output={dest}','--instrument=1','--topology=DEV_CHAIN_L',
            '--mode=LP_INDEPENDENT_COMPETITOR_NO_DROP','--seed=17',
            '--lifetimeMs=2600','--requestCount=12','--intervalNs=330000000',
            '--competitorCount=96','--competitorIntervalNs=3600000',
            '--competitorOffsetNs=0','--targetOffsetNs=260000000',
            '--forwardBps=50000000','--returnBps=50000000',
            '--technicalQueueMaxPackets=12',
            f"--telemetryEnabled={int(row['telemetry']=='on_20ms')}",
            '--telemetryPeriodMs=20']
    return BIN+' '+' '.join(values)


def verify_sends(dest,row):
    locked=events(row['seed'],row['site'],row['load'])
    for traffic,file in (('TARGET','consumer_events.jsonl'),
                         ('INDEPENDENT_COMPETITOR','competitor_events.jsonl')):
        expected={r['sequence']:r['time_ns'] for r in locked
                  if r['traffic_class']==traffic}
        sent={int(e['name'].rsplit('/',1)[-1]):e['time_ns']
              for e in load_jsonl(dest/file) if e['event']=='SEND'}
        arrivals=load_jsonl(dest/(file+'.arrivals.jsonl'))
        observed={int(e['sequence']):int(e['time_ns']) for e in arrivals}
        check(expected==sent==observed,
              'ACTUAL_NDNSIM_SEND_NOT_EQUAL_FROZEN_P12A_CSV')
        check({e['schedule'] for e in arrivals}==
              {'F3_P12_V05215_PILOT_EXCLUDED_LOCKED_CSV'},
              'ACTUAL_SEND_HAS_WRONG_PILOT_PROVENANCE')


def matched_time_pairs(dest,scenario):
    selected={int(scenario['selected_'+r+'_node_id'])
              for r in ('relay','mid','producer')}
    drops=sorted(int(e['timestamp_ns']) for e in load_jsonl(dest/'pathwide_witness_b.jsonl')
                 if e['event_type']=='QUEUE_DROP' and
                 e['node_id'] in selected and e['device_index']==0)
    bins=defaultdict(lambda:[0,0])
    positives=0
    for d in load_jsonl(dest/'events.jsonl.decisions.jsonl'):
        t=int(d['time_ns'])
        future=bisect_right(drops,t+75_000_000)-bisect_right(drops,t)
        lab=int(future>0)
        positives+=lab;bins[t//100_000_000][lab]+=1
    check(sum(sum(x) for x in bins.values())==108,
          'PILOT_MATCHED_DECISION_STREAM_INCOMPLETE')
    return {'matched_pos_neg_pairs_same_100ms':sum(a*b for a,b in bins.values()),
            'time_bins_with_both_classes':sum(a>0 and b>0 for a,b in bins.values()),
            'positive_75ms':positives,'negative_75ms':108-positives}


def simulate_one(row,seed_work,feature_writer,label_writer):
    dest=seed_work/row['site']/row['load']/row['telemetry']
    dest.mkdir(parents=True,exist_ok=False)
    a=allocation()[(row['seed'],row['site'])]
    cmd=command(row,dest)
    (dest/'command.txt').write_text(cmd+'\n')
    (dest/'P12B_LOCKED_CASE.json').write_text(json.dumps({**row,**SCIENCE},indent=2)+'\n')
    with (dest/'simulator.log').open('w') as log:
        subprocess.run(['/usr/bin/time','-f','wall_seconds=%e\nmax_rss_kib=%M',
                        '-o',str(dest/'resource_usage.txt'),
                        'python3','./waf','--run-no-build',cmd],
                       cwd=ROOT/'episode_sources/ns-3',
                       stdout=log,stderr=subprocess.STDOUT,check=True)
    scenario=json.loads((dest/'scenario.json').read_text())
    check(scenario['holdout_partition']==PARTITION and
          scenario['p12_pilot_excluded_from_formal_F3_partitions'] is True and
          scenario['p12_pilot_site']==row['site'] and
          scenario['independent_rng_block']==row['seed'] and
          scenario['selected_face_slot']==row['selected_slot'] and
          scenario['selected_face_id']==258+row['selected_slot'] and
          scenario['schedule_family']==FAMILY and
          scenario['schedule_contract']==
              'P12_V05215_INDEPENDENT_TIME_COUNTERBALANCED_PILOT_LOCKED_CSV' and
          scenario['schedule_csv_filename']==row['schedule_filename'] and
          scenario['p4_locked_traffic_stream_seed']==a['traffic_stream_seed'] and
          scenario['p4_locked_routing_stream_seed']==a['routing_stream_seed'] and
          scenario['p4_locked_telemetry_stream_seed']==a['telemetry_stream_seed'] and
          scenario['p4_prospective_load']==row['load'] and
          scenario['phase_arm']==row['arm'] and
          scenario['intervention_location']==row['location'] and
          scenario['technical_queue_max_packets']==12 and
          scenario['telemetry_enabled']==(row['telemetry']=='on_20ms') and
          scenario['official_F3_labels_constructed']==0 and
          all(scenario[k] is v for k,v in SCIENCE.items()),
          'REAL_SIMULATION_BROKE_FROZEN_PILOT_OR_SCIENCE_FENCE')
    verify_sends(dest,row)
    physical=physical_witness(dest,scenario,row['target_role'])
    decision_count=check_decisions(dest,scenario)
    transport=verify_telemetry(dest,scenario,row['telemetry']=='on_20ms')
    audit={**row,'physical':physical,'decisions':decision_count,
           'telemetry_transport':transport,
           'off_target_real_queue_drops_retained':True,
           'nonqueue_receiver_losses_excluded':True,
           'official_F3_labels_constructed':0,'F3_PR_AUC_computed':False,
           **SCIENCE}
    (dest/'P12B_PILOT_PHYSICAL_AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n')
    diagnostic=process_one(row,dest,feature_writer,label_writer)
    matched=matched_time_pairs(dest,scenario)
    check(matched['positive_75ms']==diagnostic['positive_75ms'],
          'INDEPENDENT_MATCHED_AND_TABLE_LABELS_DISAGREE')
    return {**audit,'diagnostic':diagnostic,'within_100ms':matched}


def archive_seed(seed,seed_work):
    target=DEST/('P12B_PILOT_RAW_SEED_'+str(seed)+'.zip')
    check(not target.exists(),'REFUSE_OVERWRITE_RAW_SEED_ARCHIVE')
    files=sorted(p for p in seed_work.rglob('*') if p.is_file())
    check(len(files)>100,'INCOMPLETE_RAW_PHYSICAL_EVIDENCE')
    digests={str(p.relative_to(seed_work)):sha256_file(p) for p in files}
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files:z.write(p,str(p.relative_to(seed_work)))
        z.writestr('P12B_PILOT_RAW_FILE_SHA256.json',
                   json.dumps(digests,sort_keys=True,indent=2)+'\n')
    with zipfile.ZipFile(target) as z:
        check(z.testzip() is None and
              set(z.namelist())==set(digests)|{'P12B_PILOT_RAW_FILE_SHA256.json'},
              'ARCHIVE_CRC_OR_MANIFEST_MISMATCH')
        for name,digest in digests.items():
            check(hashlib.sha256(z.read(name)).hexdigest()==digest,
                  'RAW_ARCHIVED_FILE_SHA_MISMATCH:'+name)
    sha=sha256_file(target)
    size=target.stat().st_size
    shutil.rmtree(seed_work)
    return {'seed':seed,'raw_archive_name':target.name,'sha256':sha,
            'raw_archive_bytes':size,'raw_file_count':len(digests),
            'transient_removed_only_after_full_recoverable_crc_sha':True}


def science_gate(one_seed_rows):
    high=[r for r in one_seed_rows if r['load']=='high_pressure']
    check(len(high)==6,'NOT_SIX_HIGH_CASES_PER_PILOT_SEED')
    failures=[]
    for r in high:
        physical=r['physical']['physical_drops_by_role'][r['target_role']]
        diag=r['within_100ms']
        if physical==0:failures.append({'case':r['site']+':'+r['telemetry'],
                                       'reason':'NO_ACTUAL_TARGET_QUEUE_DROP'})
        if not 0<diag['positive_75ms']<108:
            failures.append({'case':r['site']+':'+r['telemetry'],
                             'reason':'ONE_DIAGNOSTIC_CLASS'})
        if r['telemetry']=='on_20ms' and not diag['matched_pos_neg_pairs_same_100ms']:
            failures.append({'case':r['site']+':'+r['telemetry'],
                             'reason':'NO_WITHIN_100MS_POS_NEG_PAIRS'})
    return failures


def preflight():
    check_locked()
    return {'stage':'v0.52.16_P12_B_FROZEN_PILOT_24_CASE_EXECUTOR_PREFLIGHT',
            'parent_p12a_run':44688603269,'pilot_seed_blocks':list(SEEDS),
            'planned_pilot_conditions':24,'simulations_in_preflight':0,
            'official_F3_label_count':0,'training_executed':False,**SCIENCE}


def run():
    check_locked();cases=plan()
    check((ROOT/'episode_sources/ns-3/build/scratch'/BIN).is_file(),
          'P12B_CPP_BINARY_NOT_BUILT')
    check(not DEST.exists() and not WORK.exists(),
          'REFUSE_OVERWRITE_PREVIOUS_P12B_SIMULATION')
    DEST.mkdir(parents=True,exist_ok=False)
    WORK.mkdir(parents=True,exist_ok=False)
    audited=[];archives=[];failed=[]
    features=DEST/'P12B_PILOT_FEATURES_ONLY_v05216.jsonl'
    labels=DEST/'P12B_PILOT_DIAGNOSTIC_FUTURE_ONLY_v05216.jsonl'
    with features.open('w') as f,labels.open('w') as l:
        for seed in SEEDS:
            work=WORK/str(seed)
            work.mkdir(parents=True,exist_ok=False)
            batch=[]
            for row in cases:
                if row['seed']!=seed:continue
                res=simulate_one(row,work,f,l)
                audited.append(res);batch.append(res)
                print('P12B_PILOT_PHYSICAL',len(audited),'/24',seed,row['site'],
                      row['load'],row['telemetry'],
                      'queue_drops',res['physical']['physical_drops_by_role'],
                      'matched_pairs',res['within_100ms']['matched_pos_neg_pairs_same_100ms'],
                      flush=True)
            f.flush();l.flush()
            check(len(batch)==12,'ONE_SEED_NOT_EXACTLY_12_CASES')
            (work/'P12B_PILOT_SEED_AUDIT.json').write_text(json.dumps(batch,indent=2)+'\n')
            archives.append(archive_seed(seed,work))
            (DEST/'P12B_ARCHIVED_SEED_INDEX.json').write_text(json.dumps(archives,indent=2)+'\n')
            reasons=science_gate(batch)
            if reasons:
                failed.append({'seed':seed,'science_gate_failures':reasons})
                print('P12B_SCIENCE_NO_GO_AFTER_FULLY_ARCHIVED_SEED',seed,reasons,flush=True)
                # No replacement seed, no posthoc schedule change; preserve evidence.
                break
    complete=len(audited)==24
    status=('PASS_P12B_PILOT_PHYSICAL_AND_TIME_BIN_CLASS_VARIATION_ONLY'
            if complete and not failed else
            'NO_GO_P12B_PILOT_PHYSICAL_OR_TIME_BIN_FEASIBILITY')
    report={'status':status,'scientific_scope':'PILOT_EXCLUDED_NEVER_OFFICIAL_F3',
            'planned_simulations':24,'completed_simulations':len(audited),
            'pilot_seed_blocks_completed':len(archives),
            'selected_face_forwarding_episodes':108*len(audited),
            'total_positive_75ms':sum(r['diagnostic']['positive_75ms'] for r in audited),
            'total_negative_75ms':sum(r['diagnostic']['negative_75ms'] for r in audited),
            'science_gate_failures':failed,'seed_archives':archives,'results':audited,
            'validation_runs':0,'heldout_runs':0,'formal_development_runs':0,
            'official_F3_labels_constructed':0,'F3_PR_AUC_computed':False,
            'training_executed':False,**SCIENCE}
    (DEST/'P12B_PILOT_FEASIBILITY_SUMMARY.json').write_text(json.dumps(report,indent=2)+'\n')
    (DEST/'P12B_OUTPUT_SHA256SUMS.txt').write_text(''.join(
         sha256_file(p)+'  '+p.name+'\n' for p in sorted(DEST.iterdir())
         if p.is_file() and p.name!='P12B_OUTPUT_SHA256SUMS.txt'))
    print('P12B_FINAL',json.dumps({k:report[k] for k in ('status','completed_simulations',
           'selected_face_forwarding_episodes','total_positive_75ms',
           'total_negative_75ms','science_gate_failures')},sort_keys=True),flush=True)


def main():
    p=argparse.ArgumentParser();p.add_argument('--preflight-only',action='store_true')
    if p.parse_args().preflight_only:
        print(json.dumps(preflight(),indent=2))
    else:run()


if __name__=='__main__':main()
