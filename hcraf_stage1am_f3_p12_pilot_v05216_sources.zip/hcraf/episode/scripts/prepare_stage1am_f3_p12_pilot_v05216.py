#!/usr/bin/env python3
"""Verified restoration of ndnSIM ancestors and frozen P12-A/P12-B sources.

Caller first authenticates this module's raw bytes and Git HEAD preimage from
the fixed-hash P12-B inner ZIP. The source itself never overwrites parents.
"""
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import zipfile


PINS=(
 ('hcraf_stage1am_f3_p4_route_diversity_dev_v0527_sources.zip',
  'ed810ed57656c1d977a100f34f727a38acc2d8c9ce01fad753bf4c9d4875abdc',
  'HCRAF_F3_P4_ROUTE_DIVERSITY_V0527_SOURCE_SHA256.json',
  'v0.52.7_P4_P4_DEV_ROUTE_DIVERSITY_HISTORICAL_FIXTURES_ONLY'),
 ('hcraf_stage1am_f3_p4_prospective_dev_v0528_sources.zip',
  '02e37199013bc26acf705db17811e7e175f0b13a3353bb8b34e11961dc65ab58',
  'HCRAF_F3_P4_PROSPECTIVE_DEV_V0528_SOURCE_SHA256.json',
  'v0.52.8_P4_P5_PROSPECTIVE_ONE_DEVELOPMENT_SEED_ONLY'),
 ('hcraf_stage1am_f3_p4_revised_development_v0529_sources.zip',
  '6689c538befd0d74cdc305c5d12bcca6f2e594559d54e44a0c247e9c87f95ece',
  'HCRAF_F3_P4_REVISED_DEV_V0529_SOURCE_SHA256.json',
  'v0.52.9_P4_P6_REVISED_PROSPECTIVE_NEW_FOUR_DEV_SEEDS'),
 ('hcraf_stage1am_f3_p4_temporal_prereg_v05212_sources.zip',
  '050ca15feab2336df4af4607777407bb832da1619bf05bc48a03118a8089985e',
  'HCRAF_F3_P4_TEMPORAL_PREREG_V05212_SOURCE_SHA256.json',
  'v0.52.12_P4_P9_TEMPORAL_288_PRE_REGISTERED_DESIGN_ONLY'),
 ('hcraf_stage1am_f3_p4_temporal_dev_v05213_sources.zip',
  'c4828a9828e372e65f46ffb20ae1b10521a64472418aa420bac90985c5091899',
  'HCRAF_F3_P4_TEMPORAL_DEV_V05213_SOURCE_SHA256.json',
  'v0.52.13_P4_P10_TEMPORAL_96_DEVELOPMENT_ONLY'),
 ('hcraf_stage1am_f3_p12_counterbalanced_pilot_prereg_v05215_sources.zip',
  '47001b31de9c9422c74cfba7910dd0b4f0d8eb64c303f826e7bb352aa0632e83',
  'HCRAF_F3_P12_COUNTERBALANCED_PILOT_V05215_SOURCE_SHA256.json',
  'v0.52.15_P12_A_COUNTERBALANCED_PRESSURE_PILOT_PREREG_ONLY'),
)
P12B_SOURCE='hcraf_stage1am_f3_p12_pilot_v05216_sources.zip'
P12B_MANIFEST='HCRAF_F3_P12_PILOT_V05216_SOURCE_SHA256.json'
V0526_SOURCE='hcraf_stage1am_f3_p4_physical_mapping_dev_v0526_sources.zip'
V0526_MANIFEST='HCRAF_F3_P4_PHYSICAL_MAPPING_V0526_SOURCE_SHA256.json'
V0526_HELPER='hcraf/episode/scripts/prepare_stage1am_f3_p4_physical_mapping_v0526.py'
P12A_PARENT_COMMIT='13cab43cbc1965eb42e78693b3bf4f29e199874e'
P12A_ARTIFACT_SHA='6234850df8c2e12b67c61fae87b830aa1fec237a4dfe5c76f53e1a7eb61f8b42'
LOCKS={'Congestion':None,'FutureCongestion':None,'F3_ready':False,
       'GO_FREEZE':False,'training_ready':False,
       'heldout_release_authorized':False}


def check(ok,message):
    if not ok:raise AssertionError('P12B_RESTORE_'+message)


def sha(data):return hashlib.sha256(data).hexdigest()


def checked_zip(name,expected,manifest):
    blob=Path(name).read_bytes()
    check(sha(blob)==expected,'PINNED_ROOT_ZIP_DIGEST:'+name)
    check(subprocess.check_output(['git','show','HEAD:'+name])==blob,
          'GIT_COMMITTED_ROOT_ZIP_PREIMAGE:'+name)
    with zipfile.ZipFile(io.BytesIO(blob)) as z:
        check(z.testzip() is None,'SOURCE_ZIP_CRC:'+name)
        names=z.namelist()
        check(len(names)==len(set(names)),'DUPLICATE_ZIP_MEMBER:'+name)
        m=json.loads(z.read(manifest))
        files=m['files']
        check(set(names)==set(files)|{manifest},'SOURCE_MANIFEST_MEMBERS:'+name)
        for n,h in files.items():
            p=PurePosixPath(n)
            check(n.startswith('hcraf/episode/') and not n.startswith('/') and
                  '..' not in p.parts and '\\' not in n and
                  not stat.S_ISLNK(z.getinfo(n).external_attr>>16),
                  'UNSAFE_MEMBER:'+n)
            check(sha(z.read(n))==h,'PER_FILE_SHA:'+n)
        return m,{n:z.read(n) for n in files}


def overlay(m,files,label):
    for k,v in LOCKS.items():check(m[k] is v,'SCIENCE_LOCK_CHANGED:'+label+':'+k)
    for n in files:check(not Path(n).exists(),'REFUSE_OVERWRITE:'+n)
    for n,blob in files.items():
        target=Path(n)
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(blob)
        if target.suffix=='.sh':target.chmod(0o755)
    print('PASS_VERIFIED_IMMUTABLE_SOURCE_OVERLAY',label,len(files),flush=True)


def main():
    for ancestor in ('9a83987db3b6e1c279f324e1f0a3b328f3ad7518',
                     '6bddc98b89cf47d7fca0eccc877916efe0e351a5',
                     P12A_PARENT_COMMIT):
        subprocess.check_call(['git','merge-base','--is-ancestor',ancestor,'HEAD'])
    old_info,old_files=checked_zip(V0526_SOURCE,os.environ['V0526_SOURCE_SHA256'],V0526_MANIFEST)
    check(V0526_HELPER in old_files,'MISSING_PINNED_HISTORICAL_SOURCE_RESTORER')
    exec(compile(old_files[V0526_HELPER],V0526_HELPER,'exec'),{'__name__':'__main__'})
    for name,digest,manifest,stage in PINS:
        m,files=checked_zip(name,digest,manifest)
        check(m['stage']==stage,'UNEXPECTED_ANCESTOR_STAGE:'+name)
        if 'v05212' in name:
            check(m['registered_conditions']==288 and m['new_simulations']==0 and
                  m['validation_test_executable_now'] is False,
                  'P9_PROSPECTIVE_LOCK_BROKEN')
        if 'v05213' in name:
            check(m['authorized_dev_simulations']==96 and
                  m['validation_simulations_authorized']==0 and
                  m['heldout_simulations_authorized']==0,
                  'P10_PROTECTED_SPLIT_BROKEN')
        if 'v05215' in name:
            check(m['planned_pilot_conditions']==24 and
                  m['pilot_seeds']==[23401,23402] and
                  m['pilot_executable_now'] is False and
                  m['new_simulations']==0 and
                  m['p11_report_sha256']==
                    'a984085bfae01a69d673908f635d86d41e25cb7b1b9e80a837cdda1d090b71aa',
                  'P12A_PINNED_PILOT_DESIGN_BROKEN')
        overlay(m,files,name)
    m,files=checked_zip(P12B_SOURCE,os.environ['V05216_SOURCE_SHA256'],P12B_MANIFEST)
    check(m['stage']=='v0.52.16_P12_B_COUNTERBALANCED_PILOT_24_EXECUTOR_ONLY',
          'WRONG_CURRENT_STAGE')
    check(m['parent_p12a_run_id']==44688603269 and
          m['parent_p12a_commit']==P12A_PARENT_COMMIT and
          m['parent_p12a_artifact_id']==14607013980 and
          m['parent_p12a_artifact_sha256']==P12A_ARTIFACT_SHA,
          'CURRENT_PARENT_PROVENANCE_CHANGED')
    check(m['pilot_seed_blocks']==[23401,23402] and
          m['max_pilot_simulations']==24 and
          m['validation_simulations_authorized']==0 and
          m['heldout_simulations_authorized']==0 and
          m['formal_development_simulations_authorized']==0 and
          m['official_F3_labels_constructed']==0 and
          m['F3_PR_AUC_computed'] is False and
          m['training_executed'] is False,
          'CURRENT_SCIENCE_SCOPE_BROKEN')
    overlay(m,files,P12B_SOURCE)
    print('PASS_P12B_COMPLETE_PINNED_GIT_ANCESTRY_ALL_SOURCE_SHA_NO_OFFICIAL_F3',flush=True)


if __name__=='__main__':main()
