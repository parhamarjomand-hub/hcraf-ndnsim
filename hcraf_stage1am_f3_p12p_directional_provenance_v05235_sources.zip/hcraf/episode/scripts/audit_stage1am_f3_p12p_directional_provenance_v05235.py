#!/usr/bin/env python3
"""P12P read-only source/physical witness audit; no AP/model fit/heldout.

Diagnoses an observational difference, NOT an error or F3 authorization.
Exact C++ source, P12O immutable report, and one fixed sentinel seed are authenticated.
"""
import argparse, hashlib, io, json, pathlib, zipfile
from collections import Counter

L6_SOURCE_SHA='f45e1e1b9dfa276568e9c3b6989dfec6496e8fc7e3d86e1b30d53963b549a265'
CPP_SHA='7516da22fd6abc07d6ee1ed1a6126a861a2685d50b1cbf7d5169bb3d4d7889a4'
P12O_REPORT_SHA='aadb0bb6ceadcaf9223e7f8e3ae83a4006d12875cc84172c32a90a27543ab0e6'
SENTINEL_RAW_SHA='2399bc2cc5ba51a56c5e6f3cf8cea594d25094f2714e31e68e3a63a47f7d3bdf'
SEED=24831
SITES=('producer_egress','transit_middle','consumer_ingress')
LOADS=('low_control','high_pressure')
ARMS=('off','on_20ms')


def demand(cond,reason):
    if not cond:raise ValueError('P12P_FAIL_CLOSED_'+reason)


def sha(b):return hashlib.sha256(b).hexdigest()


def read_cpp(source_zip):
    raw=pathlib.Path(source_zip).read_bytes()
    demand(sha(raw)==L6_SOURCE_SHA,'SOURCE_ZIP_SHA')
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        demand(z.testzip() is None,'CPP_ZIP_CRC')
        name='hcraf/episode/src/hcraf-stage1am-f3-p12l6-physical-v05231.cpp'
        cpp=z.read(name)
        demand(sha(cpp)==CPP_SHA,'CPP_PINNED_CONTENT_SHA')
    return cpp.decode('utf-8')


def source_topology(cpp):
    required={
        'node1_forward_decision':'nodes.Get(1)->GetObject<ns3::ndn::L3Protocol>()',
        'local_primary_forward_device':'liveLocalQueue->AddCandidate(DynamicCast<PointToPointNetDevice>(primaryDevices.Get(0)),primary->getId())',
        'local_secondary_forward_device':'liveLocalQueue->AddCandidate(DynamicCast<PointToPointNetDevice>(secondaryDevices.Get(0)),secondary->getId())',
        'local_tertiary_forward_device':'liveLocalQueue->AddCandidate(DynamicCast<PointToPointNetDevice>(thirdDevices.Get(0)),third->getId())',
        'relay_reverse_sender':'auto relayDown = DynamicCast<PointToPointNetDevice>(candidateDown);',
        'mid_reverse_sender':'auto midDown = DynamicCast<PointToPointNetDevice>(relayLinks[selectedSlot].Get(1));',
        'producer_reverse_sender':'auto producerDown = DynamicCast<PointToPointNetDevice>(midLinks[selectedSlot].Get(1));',
        'loss_receiver_node1':'lossReceiver->GetNode()->GetId()!=1u',
        'decision_before_forward':'liveLocalQueue->ObserveBeforeForwarding(id);',
        'telemetry_receiver_before_forward':'telemetrySink->ObserveBeforeForwarding(id);',
        'telemetry_on_data_receipt':'m_latest[role]={seq,sample,received,enq,drop,depth};',
        'selected_path_remote_queue_sources':'selected_role_sender_node_ids',
    }
    # `selected_role_sender_node_ids` is a field in physical case QC, not C++ source itself.
    required.pop('selected_path_remote_queue_sources')
    for key,snip in required.items():demand(snip in cpp,'SOURCE_MAPPING_'+key)
    return {
      'decision_node':1,
      'local_observer_device':'node1 selected upstream Face, outgoing Interest-direction NetDevice queue',
      'remote_event_source':'selected-path relay/mid/producer return-direction NetDevice queues',
      'source_evidence':list(required),
      'interpretation':'Different physical devices and directions. Sparse local occupancy may be expected; not in itself proof of defect or fair comparison.',
    }


def jsonlines(z,name):
    return [json.loads(s) for s in z.read(name).splitlines() if s.strip()]


def audit_sample(seed_dir):
    base=pathlib.Path(seed_dir)
    targets=list(base.rglob('P12L6_RAW_SEED_24831.zip'))
    receipts=list(base.rglob('P12L6_SEED_24831_RECEIPT.json'))
    demand(len(targets)==len(receipts)==1,'SENTINEL_ARTIFACT_COUNT')
    raw=targets[0].read_bytes()
    demand(sha(raw)==SENTINEL_RAW_SHA,'SENTINEL_RAW_SHA')
    rc=json.loads(receipts[0].read_bytes())
    demand(rc['seed']==SEED and rc['cases']==12 and rc['expected_episodes']==1536,'SENTINEL_COUNTS')
    demand(rc['raw_archive_sha256']==SENTINEL_RAW_SHA,'SENTINEL_RECEIPT_SHA')
    demand(rc['model_fits']==0 and rc['interim_AP_computed'] is False,'SENTINEL_NO_SCORING')
    summaries=[];nlocal=0;nrem=0;positive_local=0;selected=0;drop_events=0
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        demand(z.testzip() is None,'SENTINEL_INNER_CRC')
        for site in SITES:
            for load in LOADS:
                for arm in ARMS:
                    p=f'{site}/{load}/{arm}/'
                    local=jsonlines(z,p+'nfd_local_queue_at_decision.jsonl')
                    choices=jsonlines(z,p+'events.jsonl.decisions.jsonl')
                    physical=json.loads(z.read(p+'P12L6_PHYSICAL_QC_ONLY.json'))
                    source_nodes=physical['physical']['selected_role_sender_node_ids']
                    demand(set(source_nodes)=={'producer','mid','relay'},'REMOTE_ROLES')
                    demand(len(set(source_nodes.values()))==3 and 1 not in set(source_nodes.values()),'REMOTE_DISTINCT_FROM_LOCAL')
                    demand(len(choices)==128 and len(local)==384,'DECISIONS_LOCAL_SNAP_COUNT')
                    maps={(x['decision_id'],x['candidate_face_id']):x for x in local}
                    demand(len(maps)==len(local),'LOCAL_SNAP_DUPLICATE')
                    for x in local:
                        demand(x['node_id']==1 and x['observed_before_forwarding'] is True,'LOCAL_ORIGIN')
                        demand(x['remote_node_queue_accessed'] is False and x['future_pressure_label'] is None,'LOCAL_NO_FUTURE')
                        demand(x['device_index'] in (1,2,3) and x['capacity_packets']==12,'LOCAL_SELECTED_DEVICES')
                    if arm=='on_20ms':
                        telem=jsonlines(z,p+'queue_telemetry_decisions.jsonl')
                        tr={x['report_id']:x for x in jsonlines(z,p+'queue_telemetry_receipts.jsonl')}
                        demand(len(telem)==128,'TELEM_DECISION_COUNT')
                        telem_by_id={x['decision_id']:x for x in telem}
                    else:
                        telem_by_id={};tr={}
                    nonzero=0
                    for i,dec in enumerate(choices,1):
                        demand(dec['decision_id']==i,'DECISION_ORDER')
                        chosen=min(dec['candidates'],key=lambda x:x['routing_cost'])
                        demand(chosen['routing_cost']==1,'SELECTED_FIB_COST')
                        q=maps[(i,chosen['face_id'])]
                        demand(q['sim_time_ns']==dec['time_ns'] and q['link_up'] is True,'LOCAL_SELECTED_TIME')
                        nonzero+=int(q['queue_packets']!=0)
                        if arm=='on_20ms':
                            td=telem_by_id[i]
                            demand(td['decision_ns']==dec['time_ns'],'TELEM_DECISION_SYNC')
                            demand(len(td['selected_sender_sources'])==3,'TELEM_SOURCE_COUNT')
                            demand({(x['node_id'],x['device_index']) for x in td['selected_sender_sources']}=={(n,0) for n in source_nodes.values()},'TELEM_SELECTED_ORIGIN')
                            for ev in td['feature_evidence']:
                                rr=tr[ev['report_id']]
                                demand(rr['source_node_id'] in set(source_nodes.values()) and rr['source_device_index']==0,'REMOTE_RECEIPT_ORIGIN')
                                demand(0<=rr['sample_ns']<=rr['receipt_ns']<=dec['time_ns'],'TELEM_CAUSALITY')
                                nrem+=1
                        selected+=1
                    witness=jsonlines(z,p+'pathwide_witness_b.jsonl')
                    drops=sum(x.get('event_type')=='QUEUE_DROP' and x.get('node_id') in set(source_nodes.values()) and x.get('device_index')==0 for x in witness)
                    drop_events+=drops
                    positive_local+=nonzero;nlocal+=len(local)
                    summaries.append({'site':site,'load':load,'arm':arm,'decisions':128,'selected_local_nonzero':nonzero,'remote_reverse_queue_drops':drops,'remote_sender_nodes':source_nodes})
    demand(len(summaries)==12 and selected==1536 and nlocal==4608,'SENTINEL_GRID')
    return {'sentinel_seed':SEED,'site_load_telemetry_cases':12,'decisions':selected,
            'all_candidate_local_snapshot_rows':nlocal,
            'selected_local_queue_nonzero':positive_local,
            'telemetry_receipts_used_at_decision':nrem,
            'selected_path_reverse_QUEUE_DROP_events':drop_events,
            'cases':summaries,'sentinel_limit':'One preselected seed; this is illustrative source/direction QC, not new hypothesis testing or proof of all-seed comparability.'}


def run(args):
    cpp=read_cpp(args.l6_source)
    mapping=source_topology(cpp)
    p=pathlib.Path(args.p12o_report)
    demand(sha(p.read_bytes())==P12O_REPORT_SHA,'P12O_ORIGINAL_REPORT_SHA')
    report=json.loads(p.read_text())
    demand(report['status']=='PASS_P12O_SOURCE_ROWS_INTEGRITY_CONSTRUCT_REVIEW_REQUIRED','P12O_STATUS')
    demand(report['raw_rows_authenticated']==27648 and report['local_features_constant_seed_count']==25,'P12O_SOURCE_COUNTS')
    demand(report['construct_review_required'] is True and report['F3_ready'] is False,'P12O_NO_GO')
    sentinel=audit_sample(args.seed_dir)
    result={'stage':'P12P_v0.52.35_DIRECTIONAL_SOURCE_PROVENANCE',
       'status':'PASS_P12P_SOURCE_AND_SENTINEL_TRACE_CONSTRUCT_REVIEW_STILL_REQUIRED',
       'P12O_parent_run':45826880462,'P12O_original_report_sha256':P12O_REPORT_SHA,
       'P12L6_original_cpp_sha256':CPP_SHA,'P12L6_source_zip_sha256':L6_SOURCE_SHA,
       'P12L6_sentinel_raw_sha256':SENTINEL_RAW_SHA,
       'original_full_cohort_observations':{'episodes':27648,'constant_local_seeds':25,'local_queue_nonzero_rows':16},
       'source_device_direction_provenance':mapping,'fixed_sentinel_raw_diagnostic':sentinel,
       'causal_limit':'Source and one sentinel trace support distinct directional observation, but cannot prove no other confounding or comparator fairness across all operating conditions.',
       'scientific_decision':'REPLICATION_POSITIVE_CONSTRUCT_COMPARATOR_FAIRNESS_REVIEW_PENDING',
       'new_AP_computed':False,'new_bootstrap_computed':False,'model_fits':0,'heldout_reads':0,'new_simulations':0,
       'Congestion':None,'FutureCongestion':None,'F3_ready':False,'GO_FREEZE':False,'training_ready':False,
       'heldout_release_authorized':False,'Stage1AO_or_NSGAIII_authorized':False}
    pathlib.Path(args.output).write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    print(result['status'])
    print('SENTINEL_SELECTED_LOCAL_QUEUE_NONZERO',sentinel['selected_local_queue_nonzero'])
    return result


def cli():
    p=argparse.ArgumentParser()
    p.add_argument('--l6-source',required=True)
    p.add_argument('--p12o-report',required=True)
    p.add_argument('--seed-dir',required=True)
    p.add_argument('--output',required=True)
    run(p.parse_args())
if __name__=='__main__':cli()
