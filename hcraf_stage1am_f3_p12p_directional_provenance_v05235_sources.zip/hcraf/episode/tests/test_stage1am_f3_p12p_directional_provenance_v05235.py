#!/usr/bin/env python3
import importlib.util,unittest, pathlib, tempfile, json
from unittest.mock import patch
P=pathlib.Path(__file__).resolve().parents[1]/'scripts'/'audit_stage1am_f3_p12p_directional_provenance_v05235.py'
s=importlib.util.spec_from_file_location('p12p',P)
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)

class P12P(unittest.TestCase):
 def test_constants(self):
  self.assertEqual(m.SEED,24831)
  self.assertEqual(len(m.SITES)*len(m.LOADS)*len(m.ARMS),12)
 def test_reject_tampered_sources(self):
  with tempfile.TemporaryDirectory() as t:
   p=pathlib.Path(t)/'z';p.write_bytes(b'not the frozen source')
   with self.assertRaises(ValueError):m.read_cpp(p)
 def test_reject_missing_mapping(self):
  with self.assertRaises(ValueError):m.source_topology('unrelated simulator code')
 def test_reject_tampered_report(self):
  with tempfile.TemporaryDirectory() as t:
   p=pathlib.Path(t)/'j';p.write_text('{}')
   class A:pass
   a=A();a.l6_source=p;a.p12o_report=p;a.seed_dir=t;a.output=p
   with patch.object(m,'read_cpp',return_value='fake'):
    with patch.object(m,'source_topology',return_value={}):
     with self.assertRaises(ValueError):m.run(a)
 def test_no_scoring(self):
  body=P.read_text()
  for forbidden in ('average_precision_score','bootstrap_ci(','fit_predict(','train_test_split('):self.assertNotIn(forbidden,body)
 def test_lock_fields_explicit(self):
  body=P.read_text()
  for key in ('GO_FREEZE','heldout_release_authorized','Stage1AO_or_NSGAIII_authorized','construct_review_required'):
   self.assertIn(key,body)
 def test_source_directional_anchors(self):
  body=P.read_text()
  for key in ('primaryDevices.Get(0)','candidateDown','relayLinks[selectedSlot].Get(1)','midLinks[selectedSlot].Get(1)'):
   self.assertIn(key,body)
 def test_fail_closed_guard(self):
  with self.assertRaisesRegex(ValueError,'P12P_FAIL_CLOSED_'):m.demand(False,'TAMPERED')

if __name__=='__main__':unittest.main()
