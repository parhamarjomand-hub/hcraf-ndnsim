#!/usr/bin/env python3
"""P12H synthetic leakage, exact seed mapping, model freeze and physical gates."""
from collections import Counter
import json
from pathlib import Path
import re
import sys
import tempfile
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import run_stage1am_f3_p12g_seedblocked_dev_v05221 as g
import freeze_stage1am_f3_p12h_models_v05222 as f
import run_stage1am_f3_p12h_validation_v05222 as h
from generate_stage1am_f3_p12e_independent_prereg_v05219 import allocation,filename


class P12H(unittest.TestCase):
    def test_p12e_exact_48_validation_and_protected_splits(self):
        rows=h.plan()
        self.assertEqual(len(rows),48)
        self.assertEqual({r['seed'] for r in rows},set(range(24601,24605)))
        self.assertFalse({r['seed'] for r in rows}&set(g.SEEDS))
        self.assertFalse({r['seed'] for r in rows}&set(range(24701,24705)))
        self.assertEqual(Counter(r['seed'] for r in rows),{s:12 for s in h.SEEDS})
        self.assertTrue(all(r['execution_authorized_now']=='false' for r in rows))

    def test_exact_validation_streams_and_CXX_gate(self):
        source=(Path(__file__).resolve().parents[1]/'src'/
                'hcraf-stage1am-f3-p12-validation-v05222.cpp').read_text()
        x=re.findall(r'\{\{(\d+)u,"([a-z_]+)"\},\{(\d+)u,(\d+)u,(\d+)u,(\d+)u\}\}',source)
        self.assertEqual(len(x),12)
        for seed,site,traffic,routing,telem,slot in x:
            a=allocation()[int(seed),site]
            self.assertEqual((int(traffic),int(routing),int(telem),int(slot)),
                             (a['traffic_stream_seed'],a['routing_stream_seed'],
                              a['telemetry_stream_seed'],a['selected_slot']))
        self.assertNotIn('{{24501u',source)
        self.assertNotIn('{{24701u',source)
        self.assertNotIn('{{23501u',source)

    def test_cpp_validation_partition_contract(self):
        source=(Path(__file__).resolve().parents[1]/'src'/
                'hcraf-stage1am-f3-p12-validation-v05222.cpp').read_text()
        for value in ('VALIDATION_RESERVED','F3_P12E_V05219_VALIDATION_LOCKED_CSV',
                      '1AM.F3.P12H.VALIDATION_V05222.0',
                      'P12E_V05219_INDEPENDENT_VALIDATION_PREREG_LOCKED_CSV',
                      'validation_partition_controlled_release_P12H_only',
                      'p12e-v05219-validation_reserved-seed-'):
            self.assertIn(value,source)
        self.assertNotIn('"research_partition":"DEVELOPMENT"',source)

    def test_commands_use_no_other_seed_or_future_feature(self):
        r=h.plan()[0]
        with tempfile.TemporaryDirectory() as td:
            c=h.command(r,Path(td))
        self.assertIn('--run='+str(r['seed']),c)
        self.assertIn('--scheduleCsv=',c)
        self.assertIn(r['schedule_filename'],c)
        self.assertIn('--technicalQueueMaxPackets=12',c)
        self.assertIn('--telemetryPeriodMs=20',c)
        self.assertNotIn('24701',c)

    def test_preflight_no_model_or_validation_data(self):
        p=h.preflight()
        self.assertEqual(p['cases'],48)
        self.assertEqual(p['episodes'],6144)
        self.assertEqual(p['telemetry_on_model_episodes'],3072)
        self.assertEqual(p['simulations_in_preflight'],0)
        self.assertEqual(p['heldout_simulations'],0)
        self.assertTrue(all(p[k] is v for k,v in h.SCIENCE.items()))

    def test_frozen_model_policy_and_protected_split(self):
        self.assertEqual(f.ALL_DEV_SHUFFLE_ID,24600)
        self.assertEqual(g.PREREG['epochs'],24)
        self.assertEqual(len(g.REMOTE_FEATURES),13)
        self.assertTrue(set(g.SEEDS).isdisjoint(h.SEEDS))
        self.assertTrue(set(g.PROTECTED).issuperset(h.SEEDS))
        self.assertFalse(g.PREREG['model_search_or_hyperparameter_tuning'])

    @staticmethod
    def synthetic_dev():
        rows=[]
        for seed in g.SEEDS:
            for site in ('consumer_ingress','producer_egress','transit_middle'):
                for load in ('low_control','high_pressure'):
                    for k in range(128):
                        y=int((k+seed)%19==0)
                        x={v:0 for v in g.BASE_FEATURES}
                        x['fib_route_cost']=1;x['local_selected_link_up']=True
                        for role in ('relay','mid','producer'):
                            x[role+'_queue_packets']=int(y and role=='mid')
                            x[role+'_telemetry_missing']=False
                            x[role+'_telemetry_age_ms']=10
                        rows.append({'seed':seed,'site':site,'load':load,
                                     'telemetry':'on_20ms','y':y,'x':x})
        return rows

    def test_deterministic_full_dev_model_without_validation_input(self):
        dev=self.synthetic_dev()
        self.assertEqual(len(dev),4608)
        a=f.fit_all_six_dev(dev,g.BASE_FEATURES)
        b=f.fit_all_six_dev(dev,g.BASE_FEATURES)
        self.assertEqual(a,b)
        self.assertEqual(a['names'],list(g.BASE_FEATURES))
        with self.assertRaisesRegex(RuntimeError,'NOT_ALL_SIX_EXCLUSIVE_DEV'):
            f.fit_all_six_dev([r for r in dev if r['seed']!=24501],g.BASE_FEATURES)

    def test_frozen_model_rejects_validation_seed_in_training(self):
        rows=self.synthetic_dev()
        rows[0]['seed']=24601
        with self.assertRaisesRegex(RuntimeError,'NOT_ALL_SIX_EXCLUSIVE_DEV'):
            f.fit_all_six_dev(rows,g.BASE_FEATURES)

    def test_offline_physical_gate_after_all_48(self):
        rows=[]
        for seed in h.SEEDS:
            for site in h.SITES:
                for load in h.LOADS:
                    for telemetry in h.TELEMETRIES:
                        eligible=seed in (24601,24602,24603)
                        positives=int(load=='high_pressure' and eligible)*12
                        rows.append(dict(seed=seed,site=site,load=load,
                                         telemetry=telemetry,target_role='relay',
                                         physical={'physical_drops_by_role':{'relay':2 if positives else 0}},
                                         within_100ms={'positive_75ms':positives,
                                                       'negative_75ms':128-positives,
                                                       'matched_pos_neg_pairs_same_100ms':10 if positives else 0}))
        errors,viable=h.physical_gate(rows)
        self.assertEqual(errors,[])
        self.assertTrue(all(len(v)==3 for v in viable.values()))
        with self.assertRaisesRegex(RuntimeError,'BEFORE_ALL_48'):
            h.physical_gate(rows[:47])

    def test_validation_cluster_bootstrap_and_ap_no_tuning(self):
        rows=[dict(seed=seed,y=int(i%17==0),
                   score_local=0.2,score_remote=float(i%17==0))
              for seed in h.SEEDS for i in range(768)]
        self.assertEqual(h.locked_metric_ap(rows,'score_remote'),1.0)
        ci=h.validation_bootstrap(rows)
        self.assertIsNotNone(ci)
        self.assertEqual(len(ci),2)
        self.assertTrue(ci[0]>0)

    def test_prohibits_reopening_frozen_model(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaisesRegex(RuntimeError,'REFUSE_OVERWRITE_OR_REFIT'):
                f.freeze(Path(td)/'missing',Path(td))

    def test_one_shot_validation_scoring_only_synthetic(self):
        with tempfile.TemporaryDirectory() as td:
            saved=h.DEST
            h.DEST=Path(td)
            try:
                model_local=dict(names=list(g.BASE_FEATURES),
                                 means=[0]*4,sds=[1]*4,weights=[0]*4,intercept=0)
                model_remote=dict(names=list(g.REMOTE_FEATURES),
                                  means=[0]*13,sds=[1]*13,weights=[0]*13,intercept=0)
                models=dict(local_model=model_local,remote_model=model_remote)
                raw=[]
                with (h.DEST/'P12H_VALIDATION_FEATURES_ONLY_v05222.jsonl').open('w') as ff, \
                     (h.DEST/'P12H_VALIDATION_DIAGNOSTIC_FUTURE_ONLY_v05222.jsonl').open('w') as ll:
                    for seed in h.SEEDS:
                        for site in h.SITES:
                            for load in h.LOADS:
                                for telemetry in h.TELEMETRIES:
                                    npos=0
                                    for i in range(128):
                                        key=f'{seed}:{site}:{load}:{telemetry}:{i+1}'
                                        y=int(i%23==0);npos+=y
                                        xx={name:0 for name in g.BASE_FEATURES}
                                        xx['fib_route_cost']=1
                                        xx['local_selected_link_up']=True
                                        for role in ('relay','mid','producer'):
                                            xx[role+'_queue_packets']=0
                                            xx[role+'_telemetry_age_ms']=None
                                            xx[role+'_telemetry_missing']=True
                                        ff.write(json.dumps({'metadata_NOT_A_PREDICTOR':
                                            {'row_key':key,'seed':seed,'site':site,
                                             'load':load,'telemetry':telemetry},
                                            'allowed_decision_time_features':xx})+'\n')
                                        ll.write(json.dumps({'row_key':key,
                                            'retrospective_future_selected_path_QUEUE_DROP_75ms':y})+'\n')
                                    raw.append({'diagnostic':{'positive_75ms':npos}})
                result=h.evaluate_validation(models,raw)
                self.assertEqual(result['validation_telemetry_on_rows'],3072)
                self.assertEqual(result['positive'],4*3*2*6)
                self.assertAlmostEqual(result['AP_local'],result['prevalence_reference'])
                self.assertAlmostEqual(result['AP_remote'],result['prevalence_reference'])
                self.assertFalse(all(result['predictability_gate'].values()))
            finally:h.DEST=saved


if __name__=='__main__':unittest.main()
