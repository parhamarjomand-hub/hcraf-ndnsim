#!/usr/bin/env python3
"""SHA-seal fixed models from all six Development seeds BEFORE Validation runs."""
import hashlib
import json
import math
from pathlib import Path
import random

import run_stage1am_f3_p12g_seedblocked_dev_v05221 as g

ROOT=Path(__file__).resolve().parents[3]
PARENT=ROOT/'p12h_input_p12g/stage1am_f3_p12g_development_v05221'
OUT=ROOT/'episode_output/stage1am_f3_p12h_validation_v05222'
PROTOCOL_ID='P12H_V05222_FIXED_FULL_SIX_DEV_MODELS_VALIDATION_FROZEN'
ALL_DEV_SHUFFLE_ID=24600
SCIENCE=g.SCIENCE


def check(ok,why):
    if not ok:raise RuntimeError('P12H_FREEZE_'+why)


def sha(path):return g.sha_file(path)


def parents(parent=PARENT):
    sums=parent/'P12G_OUTPUT_SHA256SUMS.txt'
    check(sums.is_file(),'P12G_REPORT_NOT_DOWNLOADED')
    expected={}
    for line in sums.read_text().splitlines():
        digest,name=line.split('  ',1)
        check(name not in expected and '/' not in name and len(digest)==64,
              'P12G_SHA_MANIFEST_INVALID')
        expected[name]=digest
    check(len(expected)==6 and
          {p.name for p in parent.iterdir() if p.is_file() and p.name!=sums.name}==set(expected),
          'P12G_MEMBER_COUNT_CHANGED')
    for name,digest in expected.items():
        check(sha(parent/name)==digest,'P12G_MEMBER_SHA_MISMATCH:'+name)
    report=json.loads((parent/'P12G_DEVELOPMENT_ONLY_PR_AUC_REPORT.json').read_text())
    receipt=json.loads((parent/'P12G_PREREGISTERED_MODEL_PROTOCOL.json').read_text())
    check(report['protocol']==receipt==g.PREREG and
          report['status']=='P12G_DEVELOPMENT_ONLY_DIAGNOSTIC_PR_AUC_NO_CONFIRMATORY_CLAIM' and
          report['development_only_out_of_seed_fold_predictions']==4608 and
          report['positive_count']==303 and report['negative_count']==4305 and
          report['validation_runs']==report['heldout_runs']==0 and
          report['official_F3_labels_constructed']==0 and
          all(report.get(k) is v for k,v in SCIENCE.items()),
          'P12G_PROSPECTIVE_PROTOCOL_OR_SCIENCE_FENCE_CHANGED')
    return report,expected


def fit_all_six_dev(rows,names):
    """Exactly P12G's precommitted SGD, refitted on ALL six DEV seed blocks.

    Only the deterministically pre-registered permutation identifier changes;
    it never references a Validation seed, label or scenario.
    """
    check(len(rows)==4608 and
          {x['seed'] for x in rows}==set(g.SEEDS) and
          all(x['telemetry']=='on_20ms' and x['seed'] not in g.PROTECTED for x in rows),
          'NOT_ALL_SIX_EXCLUSIVE_DEV_SEED_BLOCKS')
    n=len(rows)
    means=[sum(g.numeric(r['x'][f]) for r in rows)/n for f in names]
    sds=[max(1e-10,math.sqrt(sum((g.numeric(r['x'][f])-mu)**2 for r in rows)/n))
         for f,mu in zip(names,means)]
    xx=[[max(-5.0,min(5.0,(g.numeric(r['x'][f])-mu)/sd))
         for f,mu,sd in zip(names,means,sds)] for r in rows]
    y=[r['y'] for r in rows]
    pos=sum(y)
    check(0<pos<n,'DEVELOPMENT_TRAINING_ONE_CLASS')
    w=[0.0]*len(names)
    b=math.log((pos+g.PREREG['intercept_prior_pseudocount'])/
               (n-pos+g.PREREG['intercept_prior_pseudocount']))
    for epoch in range(g.PREREG['epochs']):
        order=list(range(n))
        random.Random(g.PREREG['shuffle_seed_offset']+
                      ALL_DEV_SHUFFLE_ID*100+epoch).shuffle(order)
        lr=g.PREREG['initial_lr']/(1+g.PREREG['epoch_decay']*epoch)
        for i in order:
            v=xx[i]
            pred=g.sigmoid(b+sum(a*c for a,c in zip(w,v)))
            error=pred-y[i]
            b-=lr*error
            for j,x in enumerate(v):
                w[j]-=lr*(error*x+g.PREREG['l2_per_step']*w[j])
    return dict(names=list(names),means=means,sds=sds,weights=w,intercept=b)


def freeze(parent=PARENT,out=OUT):
    check(not out.exists(),'REFUSE_OVERWRITE_OR_REFIT_MODEL')
    report,source_hashes=parents(parent)
    rows=g.load_development(parent,{'total_positive_75ms':604})
    on=[r for r in rows if r['telemetry']=='on_20ms']
    check(len(on)==4608 and sum(r['y'] for r in on)==303,
          'DEVELOPMENT_MODEL_CASES_CHANGED')
    model_local=fit_all_six_dev(on,g.BASE_FEATURES)
    model_remote=fit_all_six_dev(on,g.REMOTE_FEATURES)
    out.mkdir(parents=True,exist_ok=False)
    model=dict(protocol_id=PROTOCOL_ID,source_stage='P12G_DEVELOPMENT_ONLY',
               trained_on_seeds=list(g.SEEDS),trained_on_rows=4608,
               training_positives=303,training_negatives=4305,
               label_horizon_ns=75_000_000,
               validation_rows_observed_before_freeze=0,
               validation_simulations_before_freeze=0,
               model_selection_using_validation=False,
               full_development_shuffle_identifier=ALL_DEV_SHUFFLE_ID,
               fixed_P12G_model_prereg=g.PREREG,
               local_model=model_local,remote_model=model_remote,
               P12G_parent_source_file_hashes=source_hashes,
               **SCIENCE)
    frozen=out/'P12H_FROZEN_FULL_DEV_MODELS_BEFORE_VALIDATION.json'
    frozen.write_text(json.dumps(model,sort_keys=True,indent=2)+'\n')
    (out/'P12H_FROZEN_MODEL_SHA256_BEFORE_VALIDATION.txt').write_text(
        sha(frozen)+'  '+frozen.name+'\n')
    print('PASS_P12H_FROZEN_BEFORE_ANY_VALIDATION_SIMULATOR_RUN',
          'trained_on',model['trained_on_seeds'],'sha256',sha(frozen),flush=True)
    return model


def main():
    import argparse
    p=argparse.ArgumentParser()
    p.add_argument('--parent-dir',type=Path,default=PARENT)
    p.add_argument('--output-dir',type=Path,default=OUT)
    a=p.parse_args()
    freeze(a.parent_dir,a.output_dir)


if __name__=='__main__':main()
