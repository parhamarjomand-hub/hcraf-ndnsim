#!/usr/bin/env python3
"""Authenticated immutable parent overlays, then P12G and P12H only."""
import hashlib
import io
import json
import os
from pathlib import Path,PurePosixPath
import stat
import subprocess
import zipfile

P12F_ZIP='hcraf_stage1am_f3_p12_development_v05220_sources.zip'
P12F_MANIFEST='HCRAF_F3_P12F_DEVELOPMENT_EXECUTOR_V05220_SOURCE_SHA256.json'
P12F_HELPER='hcraf/episode/scripts/prepare_stage1am_f3_p12_development_v05220.py'
P12G_ZIP='hcraf_stage1am_f3_p12g_seedblocked_dev_v05221_sources.zip'
P12G_MANIFEST='HCRAF_F3_P12G_SEED_BLOCKED_DEV_V05221_SOURCE_SHA256.json'
P12H_ZIP='hcraf_stage1am_f3_p12h_validation_v05222_sources.zip'
P12H_MANIFEST='HCRAF_F3_P12H_VALIDATION_V05222_SOURCE_SHA256.json'
P12F_COMMIT='293a7b5fcd73ba1afb50c8a8116cbc0b636850a7'
P12G_COMMIT='9689fa0e1c5dc80a990451a282cf78f1b0e71c6c'
P12F_ARTIFACT_SHA='d5bdc660033e6eee23bba2e4f5a6412ca81363a9f8d40a252dcb3aefe1365f24'
P12G_ARTIFACT_SHA='1792fce65047c4594f8fd8691cd8480842edfaae0a2b38bb5cf75226b5919718'
LOCKS={'Congestion':None,'FutureCongestion':None,'F3_ready':False,
       'GO_FREEZE':False,'training_ready':False,
       'heldout_release_authorized':False}


def check(ok,message):
    if not ok:raise RuntimeError('P12H_RESTORE_'+message)


def sha(b):return hashlib.sha256(b).hexdigest()


def read_auth_zip(name,expected,manifest):
    b=Path(name).read_bytes()
    check(sha(b)==expected,'ZIP_SHA_CHANGED:'+name)
    check(subprocess.check_output(['git','show','HEAD:'+name])==b,
          'ZIP_NOT_COMMITTED_TO_GIT:'+name)
    with zipfile.ZipFile(io.BytesIO(b)) as z:
        check(z.testzip() is None,'ZIP_CRC:'+name)
        names=z.namelist()
        check(len(names)==len(set(names)),'DUPLICATE_SOURCE_MEMBERS:'+name)
        m=json.loads(z.read(manifest))
        check(set(names)==set(m['files'])|{manifest},'SOURCE_MANIFEST_MEMBERS:'+name)
        contents={}
        for n,digest in m['files'].items():
            p=PurePosixPath(n)
            check(n.startswith('hcraf/episode/') and not n.startswith('/') and
                  '..' not in p.parts and '\\' not in n and
                  not stat.S_ISLNK(z.getinfo(n).external_attr>>16),
                  'UNSAFE_SOURCE_MEMBER:'+n)
            contents[n]=z.read(n)
            check(sha(contents[n])==digest,'SOURCE_FILE_SHA:'+n)
        for k,v in LOCKS.items():check(m[k] is v,'SCIENTIFIC_LOCK:'+k)
    return m,contents


def overlay(files,label):
    for name,blob in files.items():
        dest=Path(name)
        check(not dest.exists(),'REFUSE_PARENT_OVERWRITE:'+name)
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_bytes(blob)
        if dest.suffix=='.sh':dest.chmod(0o755)
    print('PASS_P12H_VERIFIED_SOURCE_OVERLAY',label,len(files),flush=True)


def main():
    for commit in (P12F_COMMIT,P12G_COMMIT):
        subprocess.check_call(['git','merge-base','--is-ancestor',commit,'HEAD'])
    f,files=read_auth_zip(P12F_ZIP,os.environ['V05220_SOURCE_SHA256'],P12F_MANIFEST)
    check(f['stage']=='v0.52.20_P12_F_DEVELOPMENT_72_PHYSICAL_EXECUTOR_ONLY' and
          f['development_seed_blocks']==[24501,24502,24503,24504,24505,24506] and
          f['max_development_simulations']==72 and
          P12F_HELPER in files,
          'P12F_IMMUTABLE_72_DEV_PARENT_CHANGED')
    exec(compile(files[P12F_HELPER],P12F_HELPER,'exec'),{'__name__':'__main__'})
    m,files=read_auth_zip(P12G_ZIP,os.environ['V05221_SOURCE_SHA256'],P12G_MANIFEST)
    check(m['stage']=='v0.52.21_P12G_PROSPECTIVE_FIXED_DEV_SEED_BLOCKED_OOF_ONLY' and
          m['parent_p12f_run']==44764413606 and
          m['parent_p12f_commit']==P12F_COMMIT and
          m['parent_p12f_artifact_id']==14649465595 and
          m['parent_p12f_artifact_sha256']==P12F_ARTIFACT_SHA and
          m['development_only_model_cases']==36 and
          m['out_of_seed_fold_predictions']==4608 and
          m['validation_cases_authorized']==m['heldout_cases_authorized']==0,
          'P12G_DEVELOPMENT_MODEL_PARENT_CHANGED')
    overlay(files,P12G_ZIP)
    m,files=read_auth_zip(P12H_ZIP,os.environ['V05222_SOURCE_SHA256'],P12H_MANIFEST)
    check(m['stage']=='v0.52.22_P12H_INDEPENDENT_VALIDATION_48_FROZEN_MODEL_EXECUTOR' and
          m['parent_p12g_run']==44779320010 and
          m['parent_p12g_commit']==P12G_COMMIT and
          m['parent_p12g_artifact_id']==14652215437 and
          m['parent_p12g_artifact_sha256']==P12G_ARTIFACT_SHA and
          m['validation_seed_blocks']==[24601,24602,24603,24604] and
          m['development_seed_blocks']==[24501,24502,24503,24504,24505,24506] and
          m['heldout_seed_blocks_protected']==[24701,24702,24703,24704] and
          m['authorized_validation_simulations']==48 and
          m['authorized_heldout_simulations']==0 and
          m['model_freeze_before_validation_required'] is True,
          'P12H_NEW_VALIDATION_AUTHORIZATION_OR_PARENT_CHANGED')
    overlay(files,P12H_ZIP)
    print('PASS_P12H_ALL_IMMUTABLE_PARENTS_GIT_SHA_VALIDATION_ONLY_HELDOUT_SEALED',flush=True)


if __name__=='__main__':main()
