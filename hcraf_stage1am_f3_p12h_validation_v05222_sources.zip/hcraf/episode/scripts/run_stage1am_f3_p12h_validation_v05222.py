#!/usr/bin/env python3
"""Execute EXACT 48 SHA-locked P12-E Validation cases after model freeze.

All frozen models originate exclusively from P12G Development. Validation is
used once for scoring only. HELDOUT remains fully barred, F3 remains unready.
"""
import argparse
from collections import Counter,defaultdict
import csv
import hashlib
import json
from pathlib import Path
import random
import shutil
import subprocess
import zipfile

from generate_stage1am_f3_p12e_independent_prereg_v05219 import (
    SEED_SPLITS,SITES,LOADS,TELEMETRIES,FAMILY,allocation,matrix_rows,events,PLANS)
from run_stage1am_f3_p12_development_v05220 import (
    check_locked as check_all_84_p12e_schedules,
    physical_witness,check_decisions_128,verify_telemetry_128,
    matched_time_pairs,load_jsonl,sha256_file)
from build_stage1am_f3_p12_validation_tables_v05222 import process_one
from freeze_stage1am_f3_p12h_models_v05222 import (
    PROTOCOL_ID,OUT,sha,SCIENCE)
import run_stage1am_f3_p12g_seedblocked_dev_v05221 as g

ROOT=Path(__file__).resolve().parents[3]
DEST=OUT
WORK=ROOT/'episode_output/v05222_temporary_raw_validation_seed_work'
BIN='hcraf-stage1am-f3-p12-validation-v05222'
PARTITION='VALIDATION_RESERVED'
SEEDS=SEED_SPLITS[PARTITION]
PARENT_P12G_RUN=44779320010
PARENT_P12G_COMMIT='9689fa0e1c5dc80a990451a282cf78f1b0e71c6c'
PARENT_P12G_ARTIFACT_ID=14652215437
PARENT_P12G_ARTIFACT_SHA='1792fce65047c4594f8fd8691cd8480842edfaae0a2b38bb5cf75226b5919718'


def check(ok,why):
    if not ok:raise RuntimeError('P12H_VALIDATION_'+why)


def plan():
    check_all_84_p12e_schedules()
    check(SEEDS==(24601,24602,24603,24604) and
          SEED_SPLITS['DEVELOPMENT']==(24501,24502,24503,24504,24505,24506) and
          SEED_SPLITS['HELDOUT_RESERVED']==(24701,24702,24703,24704),
          'VALIDATION_AND_HELDOUT_SEED_LOCK')
    matrix=matrix_rows()
    check(len(matrix)==168,'PROSPECTIVE_168_CASES_NOT_PRESENT')
    rows=[r for r in matrix if r['partition']==PARTITION]
    check(len(rows)==48 and len({(r['seed'],r['site'],r['load'],r['telemetry'])
                                   for r in rows})==48,'NOT_EXACT_48_VAL_CASES')
    check(all(r['seed'] in SEEDS and r['candidate_queue_capacity_packets']==12 and
              r['target_requests']==12 and r['competitor_requests']==116 and
              r['execution_authorized_now']=='false' and
              r['validation_or_heldout_released']=='false' and
              r['tail_probe_requests_per_pulse']==10
              for r in rows),'ORIGINAL_P12E_PROTECTED_MATRIX_MUTATED')
    check({r['seed'] for r in rows}==set(SEEDS),'INCOMPLETE_VALIDATION_SEED_COVERAGE')
    return rows


def command(row,dest):
    a=allocation()[row['seed'],row['site']]
    values=[f"--pathArm={row['arm']}",f"--interventionLocation={row['location']}",
            '--interventionReturnBps=12000000','--lossProbability=0',
            '--lossStream=79','--lossReceiverNodeId=-1','--lossReceiverDeviceIndex=-1',
            f'--scheduleFamily={FAMILY}',f"--scheduleCsv={PLANS/row['schedule_filename']}",
            f"--prospectiveLoad={row['load']}",
            f"--prospectiveTrafficStreamSeed={a['traffic_stream_seed']}",
            f"--prospectiveRoutingStreamSeed={a['routing_stream_seed']}",
            f"--prospectiveTelemetryStreamSeed={a['telemetry_stream_seed']}",
            f"--selectedSlot={row['selected_slot']}",f"--run={row['seed']}",
            f'--output={dest}','--instrument=1','--topology=DEV_CHAIN_L',
            '--mode=LP_INDEPENDENT_COMPETITOR_NO_DROP','--seed=17',
            '--lifetimeMs=2600','--requestCount=12','--intervalNs=330000000',
            '--competitorCount=116','--competitorIntervalNs=3600000',
            '--competitorOffsetNs=0','--targetOffsetNs=260000000',
            '--forwardBps=50000000','--returnBps=50000000',
            '--technicalQueueMaxPackets=12',
            f"--telemetryEnabled={int(row['telemetry']=='on_20ms')}",
            '--telemetryPeriodMs=20']
    return BIN+' '+' '.join(values)


def validate_actual_sends(dest,row):
    locked=events(row['seed'],row['site'],row['load'])
    for kind,file in (('TARGET','consumer_events.jsonl'),
                      ('INDEPENDENT_COMPETITOR','competitor_events.jsonl')):
        expected={r['sequence']:r['time_ns'] for r in locked if r['traffic_class']==kind}
        sends={int(x['name'].rsplit('/',1)[-1]):x['time_ns']
               for x in load_jsonl(dest/file) if x['event']=='SEND'}
        arrivals=load_jsonl(dest/(file+'.arrivals.jsonl'))
        seen={int(x['sequence']):int(x['time_ns']) for x in arrivals}
        check(expected==sends==seen,'SIMULATOR_SEND_NOT_FROZEN_P12E_VALIDATION_CSV')
        check({x['schedule'] for x in arrivals}==
              {'F3_P12E_V05219_VALIDATION_LOCKED_CSV'},
              'SIMULATOR_SEND_WRONG_PARTITION_PROVENANCE')


def frozen_models():
    path=DEST/'P12H_FROZEN_FULL_DEV_MODELS_BEFORE_VALIDATION.json'
    receipt=DEST/'P12H_FROZEN_MODEL_SHA256_BEFORE_VALIDATION.txt'
    check(path.is_file() and receipt.is_file(),'NO_PRE_VALIDATION_MODEL_FREEZE')
    digest,name=receipt.read_text().strip().split('  ',1)
    check(name==path.name and digest==sha(path),'MODEL_SHA_CHANGED_AFTER_FREEZE')
    models=json.loads(path.read_text())
    check(models['protocol_id']==PROTOCOL_ID and
          models['trained_on_seeds']==list(g.SEEDS) and
          models['trained_on_rows']==4608 and
          models['validation_simulations_before_freeze']==0 and
          models['validation_rows_observed_before_freeze']==0 and
          models['model_selection_using_validation'] is False and
          models['fixed_P12G_model_prereg']==g.PREREG and
          models['local_model']['names']==list(g.BASE_FEATURES) and
          models['remote_model']['names']==list(g.REMOTE_FEATURES) and
          all(models[k] is v for k,v in SCIENCE.items()),
          'FROZEN_MODEL_OR_SCIENCE_SCOPE_CHANGED')
    return models,digest


def run_one(row,seed_work,feature_stream,label_stream):
    dest=seed_work/row['site']/row['load']/row['telemetry']
    dest.mkdir(parents=True,exist_ok=False)
    cmd=command(row,dest)
    (dest/'command.txt').write_text(cmd+'\n')
    (dest/'P12H_LOCKED_VALIDATION_CASE.json').write_text(
        json.dumps({**row,**SCIENCE},indent=2)+'\n')
    with (dest/'simulator.log').open('w') as log:
        subprocess.run(['/usr/bin/time','-f','wall_seconds=%e\nmax_rss_kib=%M',
                        '-o',str(dest/'resource_usage.txt'),
                        'python3','./waf','--run-no-build',cmd],
                       cwd=ROOT/'episode_sources/ns-3',
                       stdout=log,stderr=subprocess.STDOUT,check=True)
    scenario=json.loads((dest/'scenario.json').read_text())
    a=allocation()[row['seed'],row['site']]
    check(scenario['research_partition']==PARTITION and
          scenario['validation_partition_controlled_release_P12H_only'] is True and
          scenario['p12e_validation_site']==row['site'] and
          scenario['amendment_stage']=='1AM.F3.P12H.VALIDATION_V05222.0' and
          scenario['independent_rng_block']==row['seed'] and
          scenario['schedule_family']==FAMILY and
          scenario['schedule_contract']==
              'P12E_V05219_INDEPENDENT_VALIDATION_PREREG_LOCKED_CSV' and
          scenario['schedule_csv_filename']==row['schedule_filename'] and
          scenario['selected_face_slot']==row['selected_slot'] and
          scenario['selected_face_id']==258+row['selected_slot'] and
          scenario['p4_locked_traffic_stream_seed']==a['traffic_stream_seed'] and
          scenario['p4_locked_routing_stream_seed']==a['routing_stream_seed'] and
          scenario['p4_locked_telemetry_stream_seed']==a['telemetry_stream_seed'] and
          scenario['p4_prospective_load']==row['load'] and
          scenario['phase_arm']==row['arm'] and
          scenario['intervention_location']==row['location'] and
          scenario['technical_queue_max_packets']==12 and
          scenario['telemetry_enabled']==(row['telemetry']=='on_20ms') and
          scenario['competitor_planned_requests']==116 and
          scenario['planned_requests']==12 and
          scenario['future_oracle_horizon_ns_pilot']==75_000_000 and
          scenario['official_F3_labels_constructed']==0 and
          all(scenario[k] is v for k,v in SCIENCE.items()),
          'REAL_VALIDATION_SIM_BROKE_FROZEN_SCENARIO')
    validate_actual_sends(dest,row)
    physical=physical_witness(dest,scenario,row['target_role'])
    count=check_decisions_128(dest,scenario)
    telemetry=verify_telemetry_128(dest,scenario,row['telemetry']=='on_20ms')
    audit={**row,'physical':physical,'decisions':count,
           'telemetry_transport':telemetry,
           'official_F3_labels_constructed':0,'official_F3_PR_AUC_computed':False,
           'nonqueue_receiver_losses_excluded':True,**SCIENCE}
    (dest/'P12H_VALIDATION_PHYSICAL_AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n')
    diagnostic=process_one(row,dest,feature_stream,label_stream)
    matched=matched_time_pairs(dest,scenario)
    check(matched['positive_75ms']==diagnostic['positive_75ms'],
          'DIAGNOSTIC_LABELS_DIFFER_FROM_RAW_WITNESS')
    return {**audit,'diagnostic':diagnostic,'within_100ms':matched}


def archive_seed(seed,work):
    path=DEST/('P12H_VALIDATION_RAW_SEED_'+str(seed)+'.zip')
    check(not path.exists(),'REFUSE_OVERWRITE_RAW_VALIDATION_ARCHIVE')
    files=sorted(p for p in work.rglob('*') if p.is_file())
    check(len(files)==481,'NOT_481_EXPECTED_RAW_PHYSICAL_FILES_PER_VALIDATION_SEED')
    digests={str(p.relative_to(work)):sha256_file(p) for p in files}
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files:z.write(p,str(p.relative_to(work)))
        z.writestr('P12H_VALIDATION_RAW_FILE_SHA256.json',
                   json.dumps(digests,sort_keys=True,indent=2)+'\n')
    with zipfile.ZipFile(path) as z:
        check(z.testzip() is None and
              set(z.namelist())==set(digests)|{'P12H_VALIDATION_RAW_FILE_SHA256.json'},
              'RAW_ARCHIVE_CRC_OR_MANIFEST')
        for name,digest in digests.items():
            check(hashlib.sha256(z.read(name)).hexdigest()==digest,
                  'RAW_ARCHIVE_MEMBER_SHA_MISMATCH:'+name)
    info=dict(seed=seed,raw_archive_name=path.name,sha256=sha(path),
              raw_file_count=len(digests),raw_archive_bytes=path.stat().st_size,
              transient_removed_only_after_full_crc_sha=True)
    shutil.rmtree(work)
    return info


def physical_gate(records):
    check(len(records)==48,'GATE_BEFORE_ALL_48_VALIDATION_CASES')
    errors=[];viable={}
    for site in SITES:
        passed=[]
        for seed in SEEDS:
            pairs={r['telemetry']:r for r in records
                   if r['seed']==seed and r['site']==site and r['load']=='high_pressure'}
            check(set(pairs)==set(TELEMETRIES),'MISSING_PAIRED_VALIDATION_CASE')
            def good(r):
                d=r['within_100ms']
                return (r['physical']['physical_drops_by_role'][r['target_role']]>0 and
                        0<d['positive_75ms']<128 and d['negative_75ms']>0)
            if (good(pairs['off']) and good(pairs['on_20ms']) and
                pairs['on_20ms']['within_100ms']['matched_pos_neg_pairs_same_100ms']>0):
                passed.append(seed)
        viable[site]=passed
        if len(passed)<2:
            errors.append({'site':site,'reason':'FEWER_THAN_2_OF_4_VALIDATION_SEEDS_PHYSICAL_MATCHED_CLASSES',
                           'viable_seed_blocks':passed})
    return errors,viable


def locked_metric_ap(rows,score_key):
    return g.average_precision([(x[score_key],x['y']) for x in rows])


def validation_bootstrap(rows):
    rng=random.Random(522522)
    groups={seed:[x for x in rows if x['seed']==seed] for seed in SEEDS}
    draws=[]
    for i in range(1000):
        sample=[x for seed in (rng.choice(SEEDS) for _ in SEEDS) for x in groups[seed]]
        a=locked_metric_ap(sample,'score_remote')
        b=locked_metric_ap(sample,'score_local')
        if a is not None and b is not None:
            draws.append(a-b)
    if len(draws)<950:return None
    draws.sort()
    return [draws[int(.025*len(draws))],draws[min(len(draws)-1,int(.975*len(draws)))]]


def evaluate_validation(models,all_rows):
    features=DEST/'P12H_VALIDATION_FEATURES_ONLY_v05222.jsonl'
    labels=DEST/'P12H_VALIDATION_DIAGNOSTIC_FUTURE_ONLY_v05222.jsonl'
    ft={r['metadata_NOT_A_PREDICTOR']['row_key']:r for r in load_jsonl(features)}
    lb={r['row_key']:r for r in load_jsonl(labels)}
    check(len(ft)==len(lb)==6144 and set(ft)==set(lb),
          'VALIDATION_FEATURE_LABEL_TABLE_KEY_MISMATCH')
    check(sum(x['retrospective_future_selected_path_QUEUE_DROP_75ms']
              for x in lb.values())==sum(x['diagnostic']['positive_75ms'] for x in all_rows),
          'VALIDATION_FUTURE_DROP_REPLAY_COUNT_CHANGED')
    rows=[]
    for key,v in ft.items():
        m=v['metadata_NOT_A_PREDICTOR']
        check(m['seed'] in SEEDS and m['telemetry'] in TELEMETRIES and
              m['site'] in SITES and m['load'] in LOADS,
              'PROHIBITED_PARTITION_IN_VALIDATION_TABLE')
        if m['telemetry']!='on_20ms':continue
        x=v['allowed_decision_time_features']
        y=lb[key]['retrospective_future_selected_path_QUEUE_DROP_75ms']
        proxy={'x':x}
        rows.append({'row_key':key,'seed':m['seed'],'site':m['site'],
                     'load':m['load'],'telemetry':'on_20ms','y':y,
                     'score_local':g.predict(models['local_model'],proxy),
                     'score_remote':g.predict(models['remote_model'],proxy)})
    rows.sort(key=lambda r:r['row_key'])
    check(len(rows)==3072 and
          Counter(r['seed'] for r in rows)=={seed:768 for seed in SEEDS} and
          len({r['row_key'] for r in rows})==3072,
          'NOT_ALL_3072_ONCE_SCORED_VALIDATION_DECISIONS')
    with (DEST/'P12H_VALIDATION_ONCE_ONLY_FROZEN_MODEL_PREDICTIONS.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=('row_key','seed','site','load','telemetry','y',
                                         'score_local','score_remote'))
        w.writeheader();w.writerows(rows)
    positive=sum(x['y'] for x in rows)
    prevalence=positive/len(rows)
    local=locked_metric_ap(rows,'score_local')
    remote=locked_metric_ap(rows,'score_remote')
    folds=[];improving=[]
    for seed in SEEDS:
        part=[x for x in rows if x['seed']==seed]
        la=locked_metric_ap(part,'score_local')
        ra=locked_metric_ap(part,'score_remote')
        if la is not None and ra is not None and ra>la:improving.append(seed)
        folds.append(dict(seed=seed,rows=len(part),positive=sum(x['y'] for x in part),
                          AP_local=la,AP_remote=ra))
    ci=validation_bootstrap(rows) if positive>0 else None
    gate=dict(at_least_3_of_4_seeds_remote_strictly_better=len(improving)>=3,
              remote_AP_above_validation_positive_prevalence=(remote is not None and remote>prevalence),
              remote_AP_strictly_above_local_AP=(remote is not None and local is not None and remote>local),
              seed_block_bootstrap_delta_lower_strictly_positive=(ci is not None and ci[0]>0))
    return dict(validation_telemetry_on_rows=len(rows),
                positive=positive,negative=len(rows)-positive,
                prevalence_reference=prevalence,
                AP_local=local,AP_remote=remote,
                delta_AP_remote_minus_local=(remote-local if remote is not None and local is not None else None),
                validation_seed_block_bootstrap_95pct_delta_AP=ci,
                improving_validation_seeds=improving,
                folds=folds,predictability_gate=gate)


def preflight():
    rows=plan()
    check(not (ROOT/'episode_output/stage1am_f3_p12h_validation_v05222/P12H_VALIDATION_FEATURES_ONLY_v05222.jsonl').exists(),
          'VALIDATION_EVIDENCE_ALREADY_EXISTS')
    return dict(stage='v0.52.22_P12H_FROZEN_VALIDATION_48_PREFLIGHT',
                parent_p12g_run=PARENT_P12G_RUN,
                validation_seeds=list(SEEDS),cases=len(rows),episodes=6144,
                telemetry_on_model_episodes=3072,
                no_new_development_simulations=True,
                heldout_simulations=0,simulations_in_preflight=0,
                model_freeze_required_before_first_validation_simulation=True,
                **SCIENCE)


def run():
    cases=plan()
    models,model_sha=frozen_models()
    check((ROOT/'episode_sources/ns-3/build/scratch'/BIN).is_file(),
          'VALIDATION_CXX_NOT_COMPILED')
    check(not WORK.exists() and
          not any((DEST/n).exists() for n in (
              'P12H_VALIDATION_FEATURES_ONLY_v05222.jsonl',
              'P12H_VALIDATION_DIAGNOSTIC_FUTURE_ONLY_v05222.jsonl',
              'P12H_VALIDATION_ONCE_ONLY_FROZEN_MODEL_PREDICTIONS.csv')),
          'REFUSE_OVERWRITE_ALREADY_EVALUATED_VALIDATION')
    WORK.mkdir(parents=True,exist_ok=False)
    all_rows=[];archives=[]
    fp=DEST/'P12H_VALIDATION_FEATURES_ONLY_v05222.jsonl'
    lp=DEST/'P12H_VALIDATION_DIAGNOSTIC_FUTURE_ONLY_v05222.jsonl'
    with fp.open('w') as f,lp.open('w') as l:
        for seed in SEEDS:
            work=WORK/str(seed)
            work.mkdir(parents=True,exist_ok=False)
            batch=[]
            for row in cases:
                if row['seed']!=seed:continue
                one=run_one(row,work,f,l)
                all_rows.append(one);batch.append(one)
                print('P12H_VALIDATION_PHYSICAL',len(all_rows),'/48',seed,
                      row['site'],row['load'],row['telemetry'],
                      'real_queue_drops',one['physical']['physical_drops_by_role'],
                      flush=True)
            f.flush();l.flush()
            check(len(batch)==12,'NOT_12_FROZEN_CASES_PER_VALIDATION_SEED')
            (work/'P12H_VALIDATION_SEED_AUDIT.json').write_text(json.dumps(batch,indent=2)+'\n')
            archives.append(archive_seed(seed,work))
            (DEST/'P12H_VALIDATION_RAW_SEED_INDEX.json').write_text(
                json.dumps(archives,indent=2)+'\n')
    check(len(all_rows)==48 and len(archives)==4,
          'VALIDATION_CANNOT_SCORE_BEFORE_48_FULL_RAW_ARCHIVES')
    qc_errors,viable=physical_gate(all_rows)
    metrics=evaluate_validation(models,all_rows)
    conditions=metrics['predictability_gate']
    scientific_pass=(not qc_errors and all(conditions.values()))
    status=('PASS_P12H_VALIDATION_SIGNAL_REQUIRES_HELDOUT_CONFIRMATION'
            if scientific_pass else 'NO_GO_P12H_VALIDATION_EVIDENCE_OR_PREDICTABILITY')
    summary=dict(status=status,physical_cases=48,episodes=6144,
                 validation_seed_archives=archives,
                 physical_QC_failures=qc_errors,
                 physical_viable_seed_blocks_by_site=viable,
                 development_train_seed_blocks=list(g.SEEDS),
                 frozen_model_sha256_before_validation=model_sha,
                 frozen_model_training_rows=4608,
                 validation_model_refits_or_tuning=0,
                 validation_runs=48,heldout_runs=0,
                 original_v0520_and_p12e_prereg_unchanged=True,
                 official_F3_labels_constructed=0,
                 official_F3_PR_AUC_confirmed=False,
                 F3_claim_authorized=False,
                 physical_results=all_rows,metrics=metrics,
                 **SCIENCE)
    (DEST/'P12H_VALIDATION_EVIDENCE_AND_PR_AUC_REPORT.json').write_text(
        json.dumps(summary,sort_keys=True,indent=2)+'\n')
    (DEST/'P12H_OUTPUT_SHA256SUMS.txt').write_text(''.join(
        sha(p)+'  '+p.name+'\n' for p in sorted(DEST.iterdir())
        if p.is_file() and p.name!='P12H_OUTPUT_SHA256SUMS.txt'))
    print('P12H_FINAL',json.dumps({k:summary[k] for k in (
        'status','physical_cases','episodes','physical_QC_failures')},sort_keys=True),
          'AP_local',metrics['AP_local'],'AP_remote',metrics['AP_remote'],
          'bootstrap',metrics['validation_seed_block_bootstrap_95pct_delta_AP'],flush=True)


def main():
    p=argparse.ArgumentParser();p.add_argument('--preflight-only',action='store_true')
    if p.parse_args().preflight_only:print(json.dumps(preflight(),indent=2))
    else:run()


if __name__=='__main__':main()
