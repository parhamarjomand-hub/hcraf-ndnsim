#!/usr/bin/env python3
"""1AM development-only FUTURE PHYSICAL-DROP diagnostic, not F3/labels for ML.

Oracle evidence: independent physical Queue::Drop on SELECTED LOCAL outgoing
NetDevice (decision router), strictly AFTER decision and at most +50 ms.
Positive iff the dropped packet decodes as an INDEPENDENT_COMPETITOR Interest.
Zero iff the complete physical recorder window contains no competitor drops
AND no unclassifiable drops. Unknown if the source is incomplete/ambiguous.
Remote/link-wide/fragment-path congestion and official FutureCongestion remain NULL.
"""
from collections import defaultdict

HORIZON_NS = 50_000_000

class OracleError(ValueError):
    pass


def ensure(cond, msg):
    if not cond:
        raise OracleError(msg)


def oracle(cfg, decisions, local_snapshots, physical):
    ensure(cfg.get('future_oracle_horizon_ns_pilot') == HORIZON_NS, 'Unregistered horizon')
    ensure(cfg.get('future_oracle_is_final_F3') is False and cfg.get('F3_ready') is False
           and cfg.get('training_ready') is False and cfg.get('future_congestion') is None,
           'Attempt to convert a physical diagnostic into training/F3 outcome')
    ids=[d.get('decision_id') for d in decisions]
    ensure(len(ids)==len(set(ids)), 'Duplicate decision identity')
    seq=[e['link_event_seq'] for e in physical]
    ensure(seq==list(range(1,len(seq)+1)), 'Missing, reordered or duplicated link event')
    inits=[e for e in physical if e.get('event_type')=='INITIAL']
    finals=[e for e in physical if e.get('event_type')=='FINAL']
    ensure(len(inits)==len(finals)==14, 'Physical recorder incomplete 14-device start/end')
    dev_init={(e['node_id'],e['device_index']):e for e in inits}
    dev_final={(e['node_id'],e['device_index']):e for e in finals}
    ensure(len(dev_init)==len(dev_final)==14 and set(dev_init)==set(dev_final),
           'Physical device map changed or lost')
    ensure(all(e['time_ns']==0 for e in inits) and
           all(e['time_ns']==20_000_000_000 for e in finals),
           'Unregistered physical capture boundaries')
    selected=cfg['selected_face_id']
    candidates=[e for e in inits if e['node_id']==1 and e['face_id']==selected]
    ensure(len(candidates)==1, 'Selected local forward Face absent or ambiguous')
    selected_dev=candidates[0]['device_index']
    for e in physical:
        ensure((e['node_id'],e['device_index']) in dev_init and
               e['face_id']==dev_init[(e['node_id'],e['device_index'])]['face_id'],
               'Unregistered physical device/Face change')
        ensure(type(e['time_ns']) is int and 0<=e['time_ns']<=20_000_000_000,
               'Invalid physical event time')
    local_by_id=defaultdict(list)
    for q in local_snapshots:
        local_by_id[q['decision_id']].append(q)
    selected_events=[e for e in physical if e['node_id']==1 and e['device_index']==selected_dev]
    selected_drops=[e for e in selected_events if e['event_type']=='QUEUE_DROP']
    target_rows=[]
    for d in decisions:
        if not d['name'].startswith('/hcraf/pilot/'):
            continue
        t=d['time_ns']; uid=d['decision_id']
        shots=[x for x in local_by_id[uid] if x['candidate_face_id']==selected]
        ensure(len(shots)==1 and shots[0]['sim_time_ns']==t,
               'Target candidate local observation missing or after decision')
        q=shots[0]['queue_packets']
        ensure(type(q) is int and 0<=q<=20, 'Invalid selected local queue occupancy')
        reason=None; y=None; witnesses=[]; ambiguous=[]
        if t+HORIZON_NS>20_000_000_000:
            reason='UNKNOWN_HORIZON_CENSORED'; y='UNKNOWN'
        else:
            window=[e for e in selected_drops if t<e['time_ns']<=t+HORIZON_NS]
            for e in window:
                name=e.get('ndn_name'); kind=e.get('ndn_packet_type')
                status=e.get('wire_status'); lp=e.get('lp_status')
                if status=='PILOT' and kind=='INTEREST' and lp=='SINGLE_LP' and isinstance(name,str):
                    if name.startswith('/hcraf/competitor/'):
                        witnesses.append(e)
                    elif name.startswith('/hcraf/pilot/'):
                        pass # verified TARGET, not independent competitor
                    else:
                        ambiguous.append(e) # external/management class: no trustworthy zero
                else:
                    ambiguous.append(e) # LP fragment/drop; no fabricated class
            if witnesses:
                y=1;reason='VERIFIED_FUTURE_INDEPENDENT_COMPETITOR_DROP'
            elif ambiguous:
                y='UNKNOWN';reason='UNKNOWN_DROPPED_PACKET_CLASS'
            else:
                y=0;reason='COMPLETE_LOCAL_ORACLE_WINDOW_NO_COMPETITOR_DROP'
        target_rows.append({
            'decision_id':uid,'pit_instance_id':d['pit_instance_id'],'target_name':d['name'],
            't_decision_ns':t,'horizon_end_ns':t+HORIZON_NS,
            'selected_local_face_id':selected,'selected_local_device_index':selected_dev,
            'selected_local_queue_packets_at_decision':q,
            'pilot_future_competitor_drop_50ms':y,'oracle_reason':reason,
            'verified_competitor_drop_count':len(witnesses),
            'ambiguous_drop_count':len(ambiguous),
            'future_oracle_source':'independent physical PointToPoint NetDevice Queue::Drop link_events.jsonl',
            'oracle_witness_link_event_seq':[e['link_event_seq'] for e in witnesses],
            'online_feature_uses_future_events':False,
            'no_remote_queue_observed_online':True,
            'Congestion':None,'FutureCongestion':None,'F3_ready':False,'training_ready':False,
        })
    ensure(len(target_rows)==12,'Not exactly 12 TARGET NFD decisions')
    ensure(len({x['target_name'] for x in target_rows})==12,'Target Name collision')
    ensure(len({x['decision_id'] for x in target_rows})==12,'Target PIT decision duplication')
    return {'stage':'1AM.NONZERO_PHYSICAL_QUEUE.ORACLE_PILOT.0',
            'scope':'selected LOCAL forward link only; NOT all-path congestion',
            'pilot_outcome_not_final_F3':True,'GO_FREEZE':False,'F3_ready':False,
            'training_ready':False,'Congestion':None,'FutureCongestion':None,
            'target_rows':target_rows}
