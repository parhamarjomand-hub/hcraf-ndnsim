// v0.52.65: pilot then conditional DEV only. No scoring or official labels.
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/ndnSIM-module.h"
#include "ns3/ndnSIM/apps/ndn-app.hpp"
#include "ns3/ndnSIM/model/ndn-l3-protocol.hpp"
#include "ns3/ndnSIM/NFD/daemon/fw/forwarder.hpp"
#include "ns3/error-model.h"
#include "ns3/ndnSIM/NFD/daemon/fw/strategy.hpp"
#include <deque>
#include <functional>
#include <array>
#include <algorithm>
#include <fstream>
#include <sstream>
#include <map>
#include <set>
#include <vector>
#include <stdexcept>
#include <iomanip>
#include <memory>
using namespace ns3;
using U=uint64_t;
static U now(){return Simulator::Now().GetNanoSeconds();}
static void need(bool x,const char* m){if(!x)throw std::runtime_error(m);}
static std::string name(unsigned i){return "/hcraf/pilot/"+std::to_string(i);}
struct HcrafP12R65ScheduleEntry{U t;unsigned slot;std::array<unsigned,3> costs;};
static std::vector<HcrafP12R65ScheduleEntry> readPlan(const std::string& path){
 std::ifstream in(path);std::string l;need(bool(std::getline(in,l))&&l=="decision_index,decision_ns,selected_slot,cost_slot0,cost_slot1,cost_slot2","PLAN_HEADER");
 std::vector<HcrafP12R65ScheduleEntry> v;std::array<unsigned,3> counts{{0,0,0}};while(std::getline(in,l)){
  std::replace(l.begin(),l.end(),',',' ');std::istringstream s(l);unsigned i,k,c0,c1,c2;U t;std::string extra;
  need(bool(s>>i>>t>>k>>c0>>c1>>c2)&&!(s>>extra)&&i==v.size()&&k<3&&t>=1990000000ULL&&t<18000000000ULL&&(v.empty()||t>v.back().t),"PLAN_ROW");
  need(std::set<unsigned>{c0,c1,c2}==std::set<unsigned>{10,20,30},"COSTS");++counts[k];v.push_back({t,k,{{c0,c1,c2}}});
 }
 need(v.size()==126&&counts[0]==42&&counts[1]==42&&counts[2]==42,"PLAN_COUNT");
 for(unsigned i=0;i<126;i+=9){std::set<std::pair<unsigned,unsigned>> pairs;for(unsigned j=i;j<i+9;++j)pairs.emplace(v[j].slot,v[j].costs[v[j].slot]);need(pairs.size()==9,"PLAN_BLOCK");}return v;
}
namespace ns3 {
class P12R65ProbeApp:public ns3::ndn::App {
 public:
 static TypeId GetTypeId(){static TypeId t=TypeId("ns3::P12R65ProbeApp").SetParent<ns3::ndn::App>().AddConstructor<P12R65ProbeApp>();return t;}
 void Configure(const std::vector<HcrafP12R65ScheduleEntry>& p,std::ofstream* out){m_plan=p;m_out=out;}
 void OnData(std::shared_ptr<const ::ndn::Data> d) override {ns3::ndn::App::OnData(d);*m_out<<"DATA,"<<now()<<','<<d->getName().toUri()<<'\n';}
 void OnNack(std::shared_ptr<const ::ndn::lp::Nack> n) override {ns3::ndn::App::OnNack(n);*m_out<<"NACK,"<<now()<<','<<n->getInterest().getName().toUri()<<'\n';}
 protected: void StartApplication() override {ns3::ndn::App::StartApplication();for(unsigned i=0;i<m_plan.size();++i)Simulator::Schedule(NanoSeconds(m_plan[i].t),&P12R65ProbeApp::Send,this,i);}
 private: void Send(unsigned i){need(m_active&&now()==m_plan[i].t,"PROBE_TIME");auto p=std::make_shared<::ndn::Interest>(::ndn::Name(name(i)));p->setNonce(1001+i);p->setCanBePrefix(false);p->setMustBeFresh(true);p->setInterestLifetime(::ndn::time::milliseconds(1000));*m_out<<"SEND,"<<now()<<','<<name(i)<<'\n';m_transmittedInterests(p,this,m_face);m_appLink->onReceiveInterest(*p);}
 std::vector<HcrafP12R65ScheduleEntry> m_plan;std::ofstream* m_out=nullptr;
};
NS_OBJECT_ENSURE_REGISTERED(P12R65ProbeApp);
class P12R65Producer:public ns3::ndn::App {
 public: static TypeId GetTypeId(){static TypeId t=TypeId("ns3::P12R65Producer").SetParent<ns3::ndn::App>().AddConstructor<P12R65Producer>();return t;}
 void Configure(std::ofstream* out){m_out=out;}
 void OnInterest(std::shared_ptr<const ::ndn::Interest> interest) override {
  ns3::ndn::App::OnInterest(interest);need(m_active,"INACTIVE_PRODUCER");*m_out<<GetNode()->GetId()<<','<<now()<<','<<interest->getName().toUri()<<'\n';
  auto data=std::make_shared<::ndn::Data>(interest->getName());data->setFreshnessPeriod(::ndn::time::milliseconds(1000));data->setContent(std::make_shared<::ndn::Buffer>(4096));
  ::ndn::SignatureInfo signature(static_cast<::ndn::tlv::SignatureTypeValue>(255));data->setSignatureInfo(signature);
  ::ndn::EncodingEstimator estimator;::ndn::EncodingBuffer encoder(estimator.appendVarNumber(0),0);encoder.appendVarNumber(0);data->setSignatureValue(encoder.getBuffer());data->wireEncode();m_transmittedDatas(data,this,m_face);m_appLink->onReceiveData(*data);
 }
 protected: void StartApplication() override {ns3::ndn::App::StartApplication();ns3::ndn::FibHelper::AddRoute(GetNode(),"/hcraf",m_face,0);}
 private: std::ofstream* m_out=nullptr;
};
NS_OBJECT_ENSURE_REGISTERED(P12R65Producer);
}
// Witness A: native queue packet events; B: independent queue-length changes and MacTxDrop.
// Both share the same simulator, not independent experimental observations.
class QueueWitness{
 public:
 QueueWitness(Ptr<PointToPointNetDevice> d,unsigned key,std::ofstream& a,std::ofstream& b):dev(d),id(key),A(a),B(b){
  auto q=dev->GetQueue();need(bool(q)&&q->GetMaxSize().GetValue()==32,"QUEUE_CAPACITY");
  need(q->TraceConnectWithoutContext("Enqueue",MakeCallback(&QueueWitness::Enq,this)),"ENQ_HOOK");
  need(q->TraceConnectWithoutContext("Dequeue",MakeCallback(&QueueWitness::Deq,this)),"DEQ_HOOK");
  need(q->TraceConnectWithoutContext("Drop",MakeCallback(&QueueWitness::Drop,this)),"DROP_HOOK");
  need(q->TraceConnectWithoutContext("PacketsInQueue",MakeCallback(&QueueWitness::Change,this)),"LENGTH_HOOK");
  need(dev->TraceConnectWithoutContext("MacTxDrop",MakeCallback(&QueueWitness::MacDrop,this)),"MAC_DROP_HOOK");
  write("INITIAL",0,0,0);B<<id<<','<<now()<<",INITIAL,0,0,0\n";
 }
 void Finish(){need(pending.empty()&&dev->GetQueue()->GetNPackets()==0,"UNDRAINED");write("FINAL",0,0,0);B<<id<<','<<now()<<",FINAL,0,0,0\n";}
 private:
 void write(const char* e,U uid,U bytes,U wait){A<<id<<','<<now()<<','<<e<<','<<uid<<','<<bytes<<','<<dev->GetQueue()->GetNPackets()<<','<<wait<<'\n';need(bool(A),"QUEUE_A_WRITE");}
 void Enq(Ptr<const Packet> p){need(pending.emplace(p->GetUid(),now()).second,"DUP_ENQUEUE");write("ENQUEUE",p->GetUid(),p->GetSize(),0);}
 void Deq(Ptr<const Packet> p){auto i=pending.find(p->GetUid());need(i!=pending.end(),"DEQ_NO_ENQUEUE");write("DEQUEUE",p->GetUid(),p->GetSize(),now()-i->second);pending.erase(i);}
 void Drop(Ptr<const Packet> p){write("DROP",p->GetUid(),p->GetSize(),0);}
 void Change(uint32_t before,uint32_t after){B<<id<<','<<now()<<",CHANGE,"<<before<<','<<after<<",0\n";need(bool(B),"QUEUE_B_WRITE");}
 void MacDrop(Ptr<const Packet> p){auto q=dev->GetQueue()->GetNPackets();B<<id<<','<<now()<<",MAC_DROP,"<<q<<','<<q<<','<<p->GetUid()<<'\n';}
 Ptr<PointToPointNetDevice> dev;unsigned id;std::ofstream &A,&B;std::map<U,U> pending;
};
static U actualRate(Ptr<PointToPointNetDevice> d){DataRateValue v;d->GetAttribute("DataRate",v);return v.Get().GetBitRate();}
static U actualDelay(Ptr<PointToPointNetDevice> d){TimeValue v;d->GetChannel()->GetAttribute("Delay",v);return v.Get().GetNanoSeconds();}
static void phy(std::ofstream* f,unsigned key,std::string e,Ptr<const Packet> p){*f<<key<<','<<now()<<','<<e<<','<<p->GetUid()<<','<<p->GetSize()<<'\n';need(bool(*f),"PHY_WRITE");}
// Explicit IPv4 PPP protocol with no IP stack on receiving node: raw cross traffic uses
// the same netdevice queue/service, never enters NFD. Exactly 1198 payload + 2 PPP bytes.
static void background(Ptr<PointToPointNetDevice> d,std::ofstream* f){auto p=Create<Packet>(1198);U id=p->GetUid();bool ok=d->Send(p,d->GetBroadcast(),0x0800);*f<<now()<<','<<id<<','<<ok<<'\n';need(bool(*f),"BACKGROUND_WRITE");}
// Independent native local state. Queue history excludes the instant t in area.
// Hard cap from maximum service rate (50Mbps), minimum PPP wire bytes (2),
// 75ms window, 32 waiting packets plus boundary slack. Fail, never approximate.
class QueueHistory65{
 public:
 static constexpr U H=75000000ULL, LIMIT=500000;
 explicit QueueHistory65(Ptr<PointToPointNetDevice> d):dev(d){need(dev->GetQueue()->GetNPackets()==0,"G_INITIAL");hist.emplace_back(0,0);need(dev->GetQueue()->TraceConnectWithoutContext("PacketsInQueue",MakeCallback(&QueueHistory65::change,this)),"G_HOOK");}
 void prune(U t){U start=t>H?t-H:0;while(hist.size()>1&&hist[1].first<=start)hist.pop_front();}
 void change(uint32_t old,uint32_t q){need(hist.back().second==old&&q<=32,"G_CHANGE");prune(now());if(hist.back().first==now())hist.back().second=q;else hist.emplace_back(now(),q);need(hist.size()<=LIMIT,"G_BOUND");++updates;peak=std::max<U>(peak,hist.size());}
 U area(U t,U& ops){need(t>=H,"G_WARMUP");prune(t);U last=t-H,n=hist.front().second,area=0;ops=0;for(auto i=std::next(hist.begin());i!=hist.end();++i){++ops;if(i->first>=t)break;need(i->first>=last,"G_ORDER");area+=(i->first-last)*n;last=i->first;n=i->second;}return area+(t-last)*n;}
 U updates=0,peak=1;std::deque<std::pair<U,uint32_t>> hist;Ptr<PointToPointNetDevice> dev;
};
static std::function<nfd::Face&(const ::ndn::Interest&,const nfd::fib::Entry&)> choose65;
namespace nfd { namespace fw {
class HcrafProbe65:public Strategy {
 public:
 static const Name& getStrategyName(){static Name n=Name("/localhost/nfd/strategy/hcraf-probe65").appendVersion(1);return n;}
 HcrafProbe65(Forwarder& f,const Name& n=getStrategyName()):Strategy(f){this->setInstanceName(makeInstanceName(n,getStrategyName()));}
 void afterReceiveInterest(const Interest& interest,const FaceEndpoint& ingress,const shared_ptr<pit::Entry>& pitEntry) override {
  need(bool(choose65),"CHOICE_UNBOUND");auto& face=choose65(interest,lookupFib(*pitEntry));need(face.getId()!=ingress.face.getId(),"SCOPE");sendInterest(interest,face,pitEntry);
 }
};
}}
class Local65{
 public:
 Local65(std::shared_ptr<nfd::Forwarder> fw,const std::vector<HcrafP12R65ScheduleEntry>& p,const std::array<Ptr<PointToPointNetDevice>,3>& d,const std::array<U,3>& f,std::ofstream& out,std::ofstream& ev,std::ofstream& over):F(fw),plan(p),faces(f),O(out),E(ev),V(over){
  for(unsigned s=0;s<3;++s)hist[s].reset(new QueueHistory65(d[s]));
  F->hcrafP12VInterestIn.connect([this](const ::ndn::Interest& i,const nfd::Face& f){log(0,f.getId(),i.getName().toUri());});
  F->hcrafP12VInterestTx.connect([this](const ::ndn::Interest& i,const nfd::Face& f){auto n=i.getName().toUri();if(!research(n))return;log(3,f.getId(),n);prune();need(sent.emplace(std::make_pair(n,f.getId()),now()).second&&sent.size()<=12,"TX_BOUND");});
  F->beforeSatisfyInterest.connect([this](const nfd::pit::Entry& p,const nfd::Face& f,const ::ndn::Data& d){auto n=d.getName().toUri();if(!research(n))return;auto it=sent.find({n,f.getId()});if(it==sent.end())return;need(p.getName()==d.getName()&&now()>it->second&&now()-it->second<=1000000000ULL,"MATCHED_RTT");auto s=std::find(faces.begin(),faces.end(),f.getId())-faces.begin();need(s<3,"RTT_FACE");U sample=now()-it->second;rt[s]=missing[s]?sample:round5(4*rt[s]+sample);missing[s]=false;log(5,f.getId(),n,sample);sent.erase(it);});
 }
 static U round5(U x){return x/5+(x%5>=3);}
 static bool research(const std::string& n){return n.find("/hcraf/pilot/")==0;}
 void prune(){for(auto it=sent.begin();it!=sent.end();){if(it->second+1000000000ULL<now())it=sent.erase(it);else ++it;}}
 void log(unsigned k,U f,const std::string& n,U sample=0){if(!research(n))return;E<<++ordinal<<','<<now()<<','<<k<<','<<f<<','<<n<<','<<sample<<'\n';need(bool(E),"EVENT_WRITE");}
 nfd::Face& decision(const ::ndn::Interest& i,const nfd::fib::Entry& fib){need(index<plan.size()&&now()==plan[index].t&&i.getName().toUri()==name(index),"STRATEGY_DECISION_TIME");prune();auto t=now();auto& ent=plan[index];std::array<nfd::Face*,3> selected{{nullptr,nullptr,nullptr}};std::array<U,3> costs{{0,0,0}};
  for(auto& hop:fib.getNextHops()){auto& f=hop.getFace();auto s=std::find(faces.begin(),faces.end(),f.getId())-faces.begin();need(s<3&&!selected[s],"FIB_FACE");selected[s]=&f;costs[s]=hop.getCost();}
  for(unsigned s=0;s<3;++s){need(selected[s]&&costs[s]==ent.costs[s],"FIB_REAL_COST");U ops=0,a=hist[s]->area(t,ops);O<<index+1<<','<<t<<','<<s<<','<<faces[s]<<','<<ordinal<<','<<costs[s]<<','<<a<<','<<(4*a>=32*QueueHistory65::H)<<','<<rt[s]<<','<<missing[s]<<','<<hist[s]->hist.size()<<','<<ops<<'\n';need(bool(O),"FEATURE_WRITE");}
  ++index;return *selected[ent.slot];}
 void Finish(){need(index==126,"DECISION_COUNT");for(unsigned s=0;s<3;++s)V<<s<<','<<hist[s]->updates<<','<<hist[s]->peak<<','<<sizeof(std::pair<U,uint32_t>)<<','<<QueueHistory65::LIMIT<<'\n';}
 private:std::shared_ptr<nfd::Forwarder> F;const std::vector<HcrafP12R65ScheduleEntry>& plan;std::array<U,3> faces;std::ofstream &O,&E,&V;std::array<std::unique_ptr<QueueHistory65>,3> hist;std::map<std::pair<std::string,U>,U> sent;std::array<U,3> rt{{0,0,0}};std::array<bool,3> missing{{true,true,true}};U ordinal=0;unsigned index=0;
};
int main(int argc,char** argv){
 std::string site,arm,output,schedule;U seed=0;unsigned target=99,rate=0,loss=0,delay=0,trafficStream=0,errorStream=0,streamBase=0;
 CommandLine cmd;cmd.AddValue("run","Pilot run number",seed);cmd.AddValue("site","Site",site);cmd.AddValue("arm","Arm",arm);cmd.AddValue("output","Directory",output);cmd.AddValue("schedule","Locked schedule",schedule);cmd.AddValue("target","Target slot",target);cmd.AddValue("rate","Background Mbps",rate);cmd.AddValue("loss","Loss ppm",loss);cmd.AddValue("delay","Added propagation ms",delay);cmd.AddValue("trafficStream","Reserved deterministic traffic stream",trafficStream);cmd.AddValue("errorStream","Error model stream",errorStream);cmd.AddValue("streamBase","Reserved ns3 stream base",streamBase);cmd.Parse(argc,argv);
 unsigned start=seed>=640001&&seed<=640003?640001:seed>=640101&&seed<=640112?640101:0;need(start&&target<3&&arm.size()==1&&arm[0]>='A'&&arm[0]<='E',"PILOT_DEV_ONLY");unsigned siteIndex=site=="local_forward"?0:site=="producer_return"?1:99;need(siteIndex<2,"SITE");unsigned j=siteIndex?2:0;unsigned base=2000000+(seed-640000)*100+siteIndex*10;need(target==(seed-start+siteIndex)%3&&trafficStream==base&&errorStream==base+1&&streamBase==base+2,"MATRIX_STREAM_SLOT");need(rate==((arm=="B"||arm=="E")?18:3)&&loss==((arm=="C"||arm=="E")?20000:0)&&delay==(arm=="D"?20:0),"ARM");
 auto plan=readPlan(schedule);RngSeedManager::SetSeed(17);RngSeedManager::SetRun(seed);
 NodeContainer nodes;nodes.Create(11);PointToPointHelper link;link.SetQueue("ns3::DropTailQueue<Packet>","MaxSize",StringValue("32p"));link.SetDeviceAttribute("InterframeGap",TimeValue(NanoSeconds(0)));link.SetDeviceAttribute("DataRate",StringValue("50Mbps"));link.SetChannelAttribute("Delay",StringValue("2ms"));link.Install(nodes.Get(0),nodes.Get(1));
 std::array<std::array<Ptr<PointToPointNetDevice>,3>,3> ret,up;
 std::array<unsigned,3> mids{{7,6,5}};
 for(unsigned s=0;s<3;++s){unsigned ns[4]={1,2+s,mids[s],8+s};for(unsigned h=0;h<3;++h){link.SetChannelAttribute("Delay",TimeValue(MilliSeconds(2+((s==target&&h==j)?delay:0))));auto ds=link.Install(nodes.Get(ns[h]),nodes.Get(ns[h+1]));up[s][h]=DynamicCast<PointToPointNetDevice>(ds.Get(0));ret[s][h]=DynamicCast<PointToPointNetDevice>(ds.Get(1));need(bool(up[s][h])&&bool(ret[s][h]),"DEVICES");ret[s][h]->SetDataRate(DataRate((siteIndex==1&&s==target&&h==j)?12000000:50000000));up[s][h]->SetDataRate(DataRate((siteIndex==0&&s==target&&h==j)?12000000:50000000));}}
 for(unsigned n=0;n<nodes.GetN();++n)for(unsigned d=0;d<nodes.Get(n)->GetNDevices();++d)need(nodes.Get(n)->GetDevice(d)->SetMtu(9000),"MTU");
 if(loss){auto err=CreateObject<RateErrorModel>();err->SetUnit(RateErrorModel::ERROR_UNIT_PACKET);err->SetRate(double(loss)/1e6);err->AssignStreams(errorStream);(siteIndex?up[target][j]:ret[target][j])->SetReceiveErrorModel(err);}
 ns3::ndn::StackHelper stack;stack.setCsSize(0);stack.InstallAll();ns3::ndn::StrategyChoiceHelper::InstallAll("/hcraf","/localhost/nfd/strategy/best-route");
 for(unsigned s=0;s<3;++s){ns3::ndn::FibHelper::AddRoute(nodes.Get(2+s),"/hcraf",nodes.Get(mids[s]),1);ns3::ndn::FibHelper::AddRoute(nodes.Get(mids[s]),"/hcraf",nodes.Get(8+s),1);}
 for(unsigned i=0;i<plan.size();++i)for(unsigned s=0;s<3;++s){ns3::ndn::FibHelper::AddRoute(nodes.Get(1),name(i),nodes.Get(2+s),plan[i].costs[s]);}
 std::ofstream app(output+"/probe.csv"),prod(output+"/producer.csv"),qa(output+"/queue_a.csv"),qb(output+"/queue_b.csv"),wire(output+"/wire.csv"),bg(output+"/background.csv"),ft(output+"/features.csv"),ev(output+"/local_events.csv"),cfg(output+"/devices.csv"),over(output+"/overhead.csv");need(bool(app)&&bool(prod)&&bool(qa)&&bool(qb)&&bool(wire)&&bool(bg)&&bool(ft)&&bool(ev)&&bool(cfg)&&bool(over),"OUTPUT_OPEN");
 app<<"event,time_ns,name\n";prod<<"node,time_ns,name\n";qa<<"queue,time_ns,event,uid,bytes,packets,wait_ns\n";qb<<"queue,time_ns,event,old,new,uid\n";wire<<"link,time_ns,event,uid,bytes\n";bg<<"time_ns,uid,accepted\n";ft<<"decision_id,time_ns,slot,face,ordinal,rank,area,g,srtt_ns,missing,retained,ops\n";ev<<"ordinal,time_ns,kind,face,name,sample_ns\n";over<<"slot,updates,peak,event_payload_bytes,hard_limit\n";cfg<<"queue,sender,receiver,rate_bps,delay_ns,capacity,face\n";
 for(unsigned s=0;s<3;++s){auto p=CreateObject<P12R65Producer>();p->Configure(&prod);nodes.Get(8+s)->AddApplication(p);p->SetStartTime(Seconds(0));}
 auto requester=CreateObject<P12R65ProbeApp>();requester->Configure(plan,&app);nodes.Get(1)->AddApplication(requester);requester->SetStartTime(Seconds(0));
 auto l3=nodes.Get(1)->GetObject<ns3::ndn::L3Protocol>();auto fw=l3->getForwarder();std::array<Ptr<PointToPointNetDevice>,3> local;std::array<U,3> faces;std::vector<std::unique_ptr<QueueWitness>> monitors;
 for(unsigned s=0;s<3;++s){local[s]=up[s][0];auto f=l3->getFaceByNetDevice(local[s]);need(bool(f),"MISSING_FACE");faces[s]=f->getId();for(unsigned h=0;h<3;++h){unsigned key=s*3+h;auto a=ret[s][h],b=up[s][h];monitors.emplace_back(new QueueWitness(a,key,qa,qb));monitors.emplace_back(new QueueWitness(b,12+key,qa,qb));cfg<<key<<','<<a->GetNode()->GetId()<<','<<b->GetNode()->GetId()<<','<<actualRate(a)<<','<<actualDelay(a)<<','<<a->GetQueue()->GetMaxSize().GetValue()<<",0\n";cfg<<12+key<<','<<b->GetNode()->GetId()<<','<<a->GetNode()->GetId()<<','<<actualRate(b)<<','<<actualDelay(b)<<','<<b->GetQueue()->GetMaxSize().GetValue()<<','<<(h==0?faces[s]:0)<<'\n';
  // Capture both directions: return keys 0..8 and forward keys 12..20.
  need(a->TraceConnectWithoutContext("PhyTxBegin",MakeBoundCallback(&phy,&wire,key,std::string("TX"))),"RETURN_TX");
  need(b->TraceConnectWithoutContext("PhyRxEnd",MakeBoundCallback(&phy,&wire,key,std::string("RX"))),"RETURN_RX");
  need(b->TraceConnectWithoutContext("PhyRxDrop",MakeBoundCallback(&phy,&wire,key,std::string("ERROR"))),"RETURN_ERROR");
  need(b->TraceConnectWithoutContext("PhyTxBegin",MakeBoundCallback(&phy,&wire,12+key,std::string("TX"))),"FORWARD_TX");
  need(a->TraceConnectWithoutContext("PhyRxEnd",MakeBoundCallback(&phy,&wire,12+key,std::string("RX"))),"FORWARD_RX");
  need(a->TraceConnectWithoutContext("PhyRxDrop",MakeBoundCallback(&phy,&wire,12+key,std::string("ERROR"))),"FORWARD_ERROR");
 }}
 need(std::set<U>(faces.begin(),faces.end()).size()==3,"FACE_DISTINCT");
 // Historical recorder emits actual PIT IDs, candidate list and TX events.
 fw->hcrafEnable(output+"/events.jsonl",1);fw->hcrafEnableCoverage([](){return 1.0/6.0;},false);
 Local65 obs(fw,plan,local,faces,ft,ev,over);choose65=[&obs](const ::ndn::Interest& i,const nfd::fib::Entry& f)->nfd::Face&{return obs.decision(i,f);};nfd::fw::Strategy::registerType<nfd::fw::HcrafProbe65>();ns3::ndn::StrategyChoiceHelper::Install(nodes.Get(1),"/hcraf",nfd::fw::HcrafProbe65::getStrategyName());
 auto targetDev=siteIndex?ret[target][j]:up[target][j];U bps=U(rate)*1000000ULL;
 for(U pulse=0;pulse<18;++pulse)for(U k=0;;++k){U dt=k*9600000000000ULL/bps;if(dt>=500000000ULL)break;Simulator::Schedule(NanoSeconds(1000000000ULL+pulse*1000000000ULL+dt),&background,targetDev,&bg);}
 Simulator::Stop(Seconds(20));Simulator::Run();fw->hcrafFinish();choose65={};obs.Finish();for(auto& m:monitors)m->Finish();for(auto f:{&app,&prod,&qa,&qb,&wire,&bg,&ft,&ev,&cfg,&over}){f->flush();need(bool(*f),"FLUSH");}Simulator::Destroy();return 0;
}
