#!/usr/bin/env python3
"""Pre-execution unit tests, using only synthetic development rows."""
import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import run_stage1am_f3_p12g_seedblocked_dev_v05221 as g


class P12G(unittest.TestCase):
    def test_locked_parent_and_science(self):
        p=g.preflight()
        self.assertEqual(p['parent_p12f_run'],44764413606)
        self.assertEqual(p['parent_p12f_artifact_id'],14649465595)
        self.assertEqual(len(p['development_seed_blocks']),6)
        self.assertEqual(len(p['validation_seed_blocks_protected']),4)
        self.assertEqual(len(p['heldout_seed_blocks_protected']),4)
        self.assertEqual(p['new_ndnsim_simulations'],0)
        self.assertEqual(p['official_F3_labels_constructed'],0)
        self.assertFalse(p['official_F3_PR_AUC_computed'])
        self.assertTrue(all(p[k] is v for k,v in g.SCIENCE.items()))

    def test_metadata_never_used_as_feature(self):
        self.assertEqual(len(g.BASE_FEATURES),4)
        self.assertEqual(len(g.REMOTE_FEATURES),13)
        for term in ('seed','site','load','telemetry','decision_ns','row_key',
                     'retrospective_future_selected_path_QUEUE_DROP_75ms'):
            self.assertNotIn(term,g.REMOTE_FEATURES)
        self.assertTrue(all('future' not in k and 'target' not in k
                            for k in g.REMOTE_FEATURES))

    def test_ap_constant_scores_equals_prevalence(self):
        self.assertAlmostEqual(g.average_precision([(0.2,1),(0.2,0),
                        (0.2,0),(0.2,1),(0.2,0)]),0.4)

    def test_ap_perfect_separation(self):
        self.assertAlmostEqual(g.average_precision([(0.8,1),(0.7,1),
                        (0.5,0),(0.1,0)]),1.0)

    def test_ap_tied_threshold_group_handling(self):
        self.assertAlmostEqual(g.average_precision([(1,1),(1,0),(0,1),(0,0)]),0.5)

    def test_ap_no_positive_is_undefined(self):
        self.assertIsNone(g.average_precision([(0.2,0),(0.9,0)]))

    def test_missing_remote_is_encoded_as_zero_with_indicator(self):
        self.assertEqual(g.numeric(None),0.0)
        self.assertEqual(g.numeric(True),1.0)
        with self.assertRaises(RuntimeError):g.numeric('not-a-predictor')

    def test_sigmoid_stable_extremes(self):
        self.assertAlmostEqual(g.sigmoid(-200),0.0,places=12)
        self.assertAlmostEqual(g.sigmoid(200),1.0,places=12)

    def test_no_overwrite_existing_dataset(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaisesRegex(RuntimeError,'REFUSE_OVERWRITE'):
                g.run(Path(td)/'unavailable',Path(td))

    def test_bounded_frozen_hyperparameters(self):
        p=g.preflight()
        self.assertEqual(p['epochs'],24)
        self.assertEqual(p['initial_lr'],0.035)
        self.assertEqual(p['l2_per_step'],0.0005)
        self.assertEqual(p['holdout_rule'],
                         'leave_exactly_one_entire_development_seed_out_six_folds')
        self.assertFalse(p['model_search_or_hyperparameter_tuning'])
        self.assertIsNone(p['success_threshold'])

    @staticmethod
    def fixture_rows():
        rows=[]
        for seed in g.SEEDS:
            for site in g.SITES:
                for load in g.LOADS:
                    for i in range(128):
                        positive=int((i+seed)%23==0)
                        x={f:0 for f in g.BASE_FEATURES}
                        x['fib_route_cost']=1
                        x['local_selected_link_up']=True
                        for role in ('relay','mid','producer'):
                            x[role+'_queue_packets']=int(positive and role=='producer')
                            x[role+'_telemetry_age_ms']=7+(i%4)
                            x[role+'_telemetry_missing']=False
                        rows.append(dict(key=f'{seed}:{site}:{load}:on_20ms:{i+1}',
                                         seed=seed,site=site,load=load,
                                         telemetry='on_20ms',y=positive,x=x))
        return rows

    def test_model_all_six_seed_folds_only_synthetic(self):
        rows=self.fixture_rows()
        predictions,m=g.model_evaluation(rows)
        self.assertEqual(len(predictions),4608)
        self.assertEqual(len(m['folds']),6)
        self.assertEqual({f['heldout_development_seed'] for f in m['folds']},
                         set(g.SEEDS))
        self.assertTrue(all(f['heldout_development_seed'] not in f['train_seeds']
                            and len(f['train_seeds'])==5 for f in m['folds']))
        self.assertTrue(0<=m['development_out_of_fold_AP_remote']<=1)
        self.assertTrue(0<=m['development_out_of_fold_AP_local']<=1)
        self.assertEqual(len(m['seed_cluster_bootstrap_95pct_delta_AP']),2)

    def test_separated_partition_guard(self):
        self.assertTrue(set(g.SEEDS).isdisjoint(g.PROTECTED))
        self.assertEqual(len(set(g.SEEDS)|set(g.PROTECTED)),14)


if __name__=='__main__':unittest.main()
