#!/usr/bin/env python3
"""P12-G: a frozen, seed-blocked DEVELOPMENT-only diagnostic PR-AUC study.

The GitHub source commit precedes every fit. No Validation/Heldout input,
official F3 endpoint, Stage 1AO optimization or NSGA-III is permitted.
"""
import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import io
import json
import math
from pathlib import Path
import random
import shutil
import zipfile

HERE = Path(__file__).resolve().parents[3]
PARENT = HERE/'p12g_input/stage1am_f3_p12_development_v05220'
OUT = HERE/'episode_output/stage1am_f3_p12g_development_v05221'
SEEDS = tuple(range(24501,24507))
PROTECTED = tuple(range(24601,24605))+tuple(range(24701,24705))
SITES = ('consumer_ingress','producer_egress','transit_middle')
LOADS = ('low_control','high_pressure')
TELEMETRIES = ('off','on_20ms')
SCIENCE = dict(Congestion=None,FutureCongestion=None,F3_ready=False,
               GO_FREEZE=False,training_ready=False,
               heldout_release_authorized=False)
PARENT_RUN = 44764413606
PARENT_COMMIT = '293a7b5fcd73ba1afb50c8a8116cbc0b636850a7'
PARENT_ARTIFACT_ID = 14649465595
PARENT_ARTIFACT_SHA = 'd5bdc660033e6eee23bba2e4f5a6412ca81363a9f8d40a252dcb3aefe1365f24'
PARENT_P12F_SOURCE_SHA = '000f5d89c0490c46afdc5e4d741dcf85935e193f013dd37a4ed33299b7403082'
PARENT_P12E_SOURCE_SHA = '72e46581c8124e83372fb84f5bf014637d44d1c61f990cb8d0582f04de14b96f'
BASE_FEATURES = ('fib_route_cost','local_selected_queue_packets',
                 'local_selected_queue_fraction','local_selected_link_up')
REMOTE_FEATURES = BASE_FEATURES + tuple(
    f'{role}_{suffix}' for role in ('relay','mid','producer')
    for suffix in ('queue_packets','telemetry_missing','telemetry_age_ms'))
MODEL_NAMES = ('LOCAL_ONLY','REMOTE_QUEUE_CAUSAL')
PREREG = {
    'stage':'v0.52.21_P12G_PROSPECTIVE_FIXED_DEV_SEED_BLOCKED_OOF_ONLY',
    'parent_p12f_run':PARENT_RUN,
    'parent_p12f_commit':PARENT_COMMIT,
    'parent_p12f_artifact_id':PARENT_ARTIFACT_ID,
    'parent_p12f_artifact_sha256':PARENT_ARTIFACT_SHA,
    'development_seed_blocks':list(SEEDS),
    'validation_seed_blocks_protected':list(range(24601,24605)),
    'heldout_seed_blocks_protected':list(range(24701,24705)),
    'model_subset':'telemetry_on_20ms_only',
    'development_cases_considered':72,
    'model_cases_expected':36,
    'model_episodes_expected':4608,
    'all_development_episodes_expected':9216,
    'future_horizon_ns':75000000,
    'event_semantics':'selected_route_device0_actual_QUEUE_DROP_in_open_closed_75ms',
    'label_status':'PROVISIONAL_DEVELOPMENT_DIAGNOSTIC_ONLY',
    'features_local_only':list(BASE_FEATURES),
    'features_remote_causal':list(REMOTE_FEATURES),
    'metadata_never_predictors':['row_key','seed','site','load','telemetry',
                                'decision_ns','decision_id','pit_instance_id',
                                'selected_face_id','traffic_type'],
    'holdout_rule':'leave_exactly_one_entire_development_seed_out_six_folds',
    'no_random_episode_split':True,
    'classifier':'fixed_logistic_SGD_without_tuning_or_external_packages',
    'epochs':24,'intercept_prior_pseudocount':0.5,
    'initial_lr':0.035,'epoch_decay':0.08,'l2_per_step':0.0005,
    'standardize':'training_fold_only_mean_std_population_then_clip_minus5_plus5',
    'shuffle_seed_offset':521000,
    'ap_definition':'threshold_tie_grouped_uninterpolated_average_precision',
    'primary_comparison':'pooled_development_oof_AP_remote_minus_local',
    'other_metrics':'seed_fold_AP_prevalence_and_descriptive_site_AP',
    'uncertainty':'development_seed_block_bootstrap_1000_replicates_seed521521',
    'success_threshold':None,
    'model_search_or_hyperparameter_tuning':False,
    'new_ndnsim_simulations':0,
    'validation_simulations':0,'heldout_simulations':0,
    'official_F3_labels_constructed':0,
    'official_F3_PR_AUC_computed':False,
    'Stage1AO_or_NSGAIII_authorized':False,
    **SCIENCE,
}


def require(c, message):
    if not c:raise RuntimeError('P12G_'+message)


def sha_file(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for c in iter(lambda:f.read(1<<20),b''):h.update(c)
    return h.hexdigest()


def sha_bytes(blob):return hashlib.sha256(blob).hexdigest()


def read_jsonl(path):
    with Path(path).open('r',encoding='utf-8') as f:
        for line in f:
            if line.strip():yield json.loads(line)


def parent_seal(parent):
    require(parent.is_dir(),'P12F_ARTIFACT_DIRECTORY_NOT_PRESENT')
    mf=parent/'P12F_OUTPUT_SHA256SUMS.txt'
    require(mf.is_file(),'P12F_SHA_MANIFEST_MISSING')
    expected={}
    for line in mf.read_text().splitlines():
        digest,name=line.split('  ',1)
        require(name not in expected and '/' not in name and len(digest)==64,
                'INVALID_P12F_SHA_MANIFEST')
        expected[name]=digest
    files={x.name for x in parent.iterdir() if x.is_file() and x.name!=mf.name}
    require(set(expected)==files and len(expected)==10,
            'P12F_FILES_MISSING_EXTRA_OR_CHANGED')
    for name,digest in expected.items():
        require(sha_file(parent/name)==digest,'P12F_SHA_MISMATCH_'+name)
    r=json.loads((parent/'P12F_DEVELOPMENT_FEASIBILITY_SUMMARY.json').read_text())
    require(r['status']=='PASS_P12F_DEVELOPMENT_PHYSICAL_PREREGISTERED_QC_ONLY' and
            r['completed_simulations']==72 and
            r['selected_face_forwarding_episodes']==9216 and
            r['total_positive_75ms']==604 and r['total_negative_75ms']==8612 and
            r['development_seed_blocks_completed']==6 and
            r['science_gate_failures']==[] and
            r['validation_runs']==r['heldout_runs']==0 and
            all(r.get(k) is v for k,v in SCIENCE.items()),
            'P12F_POS_NEG_OR_SCIENCE_GATE_CHANGED')
    index=json.loads((parent/'P12F_ARCHIVED_SEED_INDEX.json').read_text())
    require(index==r['seed_archives'] and len(index)==6 and
            {a['seed'] for a in index}==set(SEEDS),'P12F_SEED_ARCHIVE_INDEX_CHANGED')
    # Every raw physical byte is authenticated, not just the GitHub artifact summary.
    for a in index:
        require(a['raw_file_count']==481 and expected[a['raw_archive_name']]==a['sha256'],
                'P12F_RAW_ARCHIVE_SHA_INDEX')
        with zipfile.ZipFile(parent/a['raw_archive_name']) as z:
            manifest=json.loads(z.read('P12F_DEVELOPMENT_RAW_FILE_SHA256.json'))
            require(len(manifest)==481 and
                    set(z.namelist())==set(manifest)|{'P12F_DEVELOPMENT_RAW_FILE_SHA256.json'},
                    'P12F_RAW_ARCHIVE_MEMBER_CONTRACT')
            for name,digest in manifest.items():
                h=hashlib.sha256()
                with z.open(name) as f:
                    for c in iter(lambda:f.read(1<<20),b''):h.update(c)
                require(h.hexdigest()==digest,'P12F_RAW_MEMBER_SHA_'+name)
    return r,expected


def load_development(parent,report):
    fpath=parent/'P12F_DEVELOPMENT_FEATURES_ONLY_v05220.jsonl'
    lpath=parent/'P12F_DEVELOPMENT_DIAGNOSTIC_FUTURE_ONLY_v05220.jsonl'
    features={}
    for r in read_jsonl(fpath):
        require(set(r)=={'metadata_NOT_A_PREDICTOR','allowed_decision_time_features'},
                'FEATURES_ROW_UNEXPECTED_FIELDS')
        m=r['metadata_NOT_A_PREDICTOR'];k=m['row_key']
        require(k not in features and m['seed'] in SEEDS and
                m['site'] in SITES and m['load'] in LOADS and
                m['telemetry'] in TELEMETRIES and
                set(r['allowed_decision_time_features'])==set(BASE_FEATURES)|
                {f'{role}_{suffix}' for role in ('relay','mid','producer')
                 for suffix in ('queue_packets','queue_drops_observed_total',
                                'telemetry_age_ms','telemetry_missing')},
                'FEATURE_SCHEMA_OR_PARTITION')
        require(k.startswith(f"{m['seed']}:{m['site']}:{m['load']}:{m['telemetry']}:") and
                m['decision_ns']>=0 and m['decision_id']>0 and
                m['selected_face_id'] in (258,259,260),
                'METADATA_IDENTITY_OR_TIME')
        features[k]=r
    labels={}
    for r in read_jsonl(lpath):
        k=r['row_key']
        require(k not in labels and
                set(r)=={'row_key','DIAGNOSTIC_ONLY_not_official_F3',
                          'retrospective_future_selected_path_QUEUE_DROP_75ms',
                          'retrospective_future_drop_event_count'} and
                r['DIAGNOSTIC_ONLY_not_official_F3'] is True and
                r['retrospective_future_selected_path_QUEUE_DROP_75ms'] in (0,1) and
                r['retrospective_future_drop_event_count']>=0 and
                (r['retrospective_future_drop_event_count']>0)==
                bool(r['retrospective_future_selected_path_QUEUE_DROP_75ms']),
                'DIAGNOSTIC_LABEL_SCHEMA_OR_SCOPE')
        labels[k]=r
    require(len(features)==len(labels)==9216 and set(features)==set(labels),
            'DEVELOPMENT_ROW_JOIN_MISMATCH')
    counts=Counter((v['metadata_NOT_A_PREDICTOR']['seed'],
                    v['metadata_NOT_A_PREDICTOR']['site'],
                    v['metadata_NOT_A_PREDICTOR']['load'],
                    v['metadata_NOT_A_PREDICTOR']['telemetry'])
                   for v in features.values())
    require(len(counts)==72 and set(counts.values())=={128} and
            {k[0] for k in counts}==set(SEEDS),
            'NOT_72_COMPLETE_DEVELOPMENT_CASES')
    rows=[]
    for k,v in features.items():
        m=v['metadata_NOT_A_PREDICTOR']
        rows.append({'key':k,'seed':m['seed'],'site':m['site'],
                     'load':m['load'],'telemetry':m['telemetry'],
                     'y':labels[k]['retrospective_future_selected_path_QUEUE_DROP_75ms'],
                     'x':v['allowed_decision_time_features']})
    rows.sort(key=lambda r:r['key'])
    require(sum(r['y'] for r in rows)==report['total_positive_75ms'],
            'P12F_LABEL_COUNTS_NOT_REPRODUCED')
    return rows


def numeric(x):
    require(x is None or isinstance(x,(int,float,bool)),'NONNUMERIC_FEATURE_VALUE')
    return 0.0 if x is None else float(x)


def fit_logistic(rows,feature_names,fold_seed):
    """Fixed SGD. All moments and labels are obtained from five train seeds only."""
    require(len(rows)==3840 and all(r['seed']!=fold_seed for r in rows),
            'TRAIN_FOLD_NOT_5_INDEPENDENT_SEED_BLOCKS')
    n=len(rows)
    means=[sum(numeric(r['x'][f]) for r in rows)/n for f in feature_names]
    sds=[max(1e-10, math.sqrt(sum((numeric(r['x'][f])-mu)**2
                  for r in rows)/n)) for f,mu in zip(feature_names,means)]
    def normalize(r):
        return [max(-5.0,min(5.0,(numeric(r['x'][f])-mu)/sd))
                for f,mu,sd in zip(feature_names,means,sds)]
    X=[normalize(r) for r in rows]
    y=[r['y'] for r in rows]
    pos=sum(y)
    require(0<pos<n,'TRAIN_FOLD_ONE_CLASS_ONLY')
    w=[0.0]*len(feature_names)
    b=math.log((pos+0.5)/(n-pos+0.5))
    for epoch in range(PREREG['epochs']):
        order=list(range(n))
        random.Random(PREREG['shuffle_seed_offset']+fold_seed*100+epoch).shuffle(order)
        lr=PREREG['initial_lr']/(1+PREREG['epoch_decay']*epoch)
        for i in order:
            xx=X[i]
            z=b+sum(a*c for a,c in zip(w,xx))
            pred=sigmoid(z)
            error=pred-y[i]
            b-=lr*error
            for j,x in enumerate(xx):
                w[j]-=lr*(error*x+PREREG['l2_per_step']*w[j])
    return {'names':feature_names,'means':means,'sds':sds,'weights':w,'intercept':b}


def sigmoid(z):
    if z>=0:
        return 1/(1+math.exp(-z))
    e=math.exp(z)
    return e/(1+e)


def predict(model,row):
    x=[max(-5.0,min(5.0,(numeric(row['x'][f])-mu)/sd)) for f,mu,sd in
       zip(model['names'],model['means'],model['sds'])]
    return sigmoid(model['intercept']+sum(w*a for w,a in zip(model['weights'],x)))


def average_precision(pairs):
    """PR-AUC as uninterpolated AP, with explicit threshold ties."""
    positives=sum(y for _,y in pairs)
    if positives==0:return None
    ranked=sorted(pairs,key=lambda t:t[0],reverse=True)
    seen=correct=0
    area=0.0
    i=0
    while i<len(ranked):
        j=i
        group_pos=0
        while j<len(ranked) and ranked[j][0]==ranked[i][0]:
            group_pos+=ranked[j][1]
            j+=1
        seen+=j-i
        correct+=group_pos
        area+=(correct/seen)*(group_pos/positives)
        i=j
    require(0<=area<=1.0000000001,'INVALID_AVERAGE_PRECISION')
    return min(1.0,area)


def bootstrap_ci(predictions, metric, n=1000):
    rng=random.Random(521521)
    seeds=tuple(SEEDS)
    per_seed={seed:[p for p in predictions if p['seed']==seed] for seed in seeds}
    draws=[]
    for _ in range(n):
        chosen=[rng.choice(seeds) for _ in seeds]
        sample=[p for s in chosen for p in per_seed[s]]
        a=average_precision([(x[metric],x['y']) for x in sample])
        b=average_precision([(x['score_local'],x['y']) for x in sample])
        if a is not None and b is not None:
            draws.append(a-b)
    require(len(draws)==n,'BOOTSTRAP_NO_POSITIVES')
    draws.sort()
    return [draws[int(0.025*n)],draws[min(n-1,int(0.975*n))]]


def model_evaluation(rows):
    model_rows=[r for r in rows if r['telemetry']=='on_20ms']
    require(len(model_rows)==4608 and
            Counter(r['seed'] for r in model_rows)=={s:768 for s in SEEDS},
            'WRONG_FROZEN_PRIMARY_MODEL_SUBSET')
    predictions=[];folds=[]
    for seed in SEEDS:
        train=[r for r in model_rows if r['seed']!=seed]
        test=[r for r in model_rows if r['seed']==seed]
        require(len(train)==3840 and len(test)==768,
                'SEED_BLOCK_LEAKAGE_OR_FOLD_SIZE')
        base=fit_logistic(train,BASE_FEATURES,seed)
        remote=fit_logistic(train,REMOTE_FEATURES,seed)
        fold=[]
        for r in test:
            p={'row_key':r['key'],'seed':seed,'site':r['site'],
               'load':r['load'],'telemetry':'on_20ms','y':r['y'],
               'score_local':predict(base,r),
               'score_remote':predict(remote,r)}
            predictions.append(p);fold.append(p)
        folds.append({'heldout_development_seed':seed,'train_seeds':[x for x in SEEDS if x!=seed],
                      'test_rows':len(fold),'test_positive':sum(x['y'] for x in fold),
                      'test_prevalence':sum(x['y'] for x in fold)/len(fold),
                      'ap_local':average_precision([(x['score_local'],x['y']) for x in fold]),
                      'ap_remote':average_precision([(x['score_remote'],x['y']) for x in fold]),
                      'models_frozen_after_training_only_on_five_seed_blocks':True})
    predictions.sort(key=lambda r:r['row_key'])
    require(len(predictions)==4608 and len({p['row_key'] for p in predictions})==4608,
            'OOS_PREDICTIONS_NOT_EXACT')
    ap_local=average_precision([(p['score_local'],p['y']) for p in predictions])
    ap_remote=average_precision([(p['score_remote'],p['y']) for p in predictions])
    require(ap_local is not None and ap_remote is not None,'PRIMARY_AP_UNDEFINED')
    prevalence=sum(p['y'] for p in predictions)/len(predictions)
    sub=[]
    for site in SITES:
        rr=[p for p in predictions if p['site']==site]
        sub.append({'site':site,'n':len(rr),'positives':sum(p['y'] for p in rr),
                    'ap_local':average_precision([(p['score_local'],p['y']) for p in rr]),
                    'ap_remote':average_precision([(p['score_remote'],p['y']) for p in rr])})
    return predictions,{'development_out_of_fold_AP_local':ap_local,
        'development_out_of_fold_AP_remote':ap_remote,
        'development_out_of_fold_delta_AP_remote_minus_local':ap_remote-ap_local,
        'pooled_telemetry_on_positive_prevalence_reference':prevalence,
        'seed_cluster_bootstrap_95pct_delta_AP':bootstrap_ci(predictions,'score_remote'),
        'folds':folds,'site_subgroup_DESCRIPTIVE_ONLY':sub,
        'positive_count':sum(p['y'] for p in predictions),
        'negative_count':sum(1-p['y'] for p in predictions)}


def preflight():
    require(SEEDS==(24501,24502,24503,24504,24505,24506) and len(PROTECTED)==8 and
            set(PROTECTED).isdisjoint(SEEDS),'PREREG_SEED_PARTITIONS')
    require(set(BASE_FEATURES).issubset(REMOTE_FEATURES) and
            len(REMOTE_FEATURES)==13 and
            PREREG['model_search_or_hyperparameter_tuning'] is False and
            PREREG['official_F3_PR_AUC_computed'] is False,
            'PREDECLARED_MODEL_OR_SCIENCE_SCOPE')
    return dict(PREREG)


def run(parent=PARENT,out=OUT):
    prereg=preflight()
    require(not out.exists(),'REFUSE_OVERWRITE_PREVIOUS_DEVELOPMENT_MODEL')
    report,hashes=parent_seal(parent)
    rows=load_development(parent,report)
    out.mkdir(parents=True,exist_ok=False)
    (out/'P12G_PREREGISTERED_MODEL_PROTOCOL.json').write_text(
        json.dumps(prereg,sort_keys=True,indent=2)+'\n')
    (out/'P12G_AUTHENTICATED_P12F_SOURCE_SHA256.json').write_text(
        json.dumps({'parent_run_id':PARENT_RUN,'parent_commit':PARENT_COMMIT,
                    'parent_artifact_id':PARENT_ARTIFACT_ID,
                    'parent_artifact_sha256':PARENT_ARTIFACT_SHA,
                    'all_parent_p12f_artifact_member_shas':hashes,
                    'all_2886_raw_files_SHA256_verified':True,
                    'all_72_physical_cases_prior_independent_replay_PASS':True,
                    **SCIENCE},sort_keys=True,indent=2)+'\n')
    # Preserve the two authenticated original tables separately, never produce
    # a training-ready joined table or an official F3 endpoint here.
    for name in ('P12F_DEVELOPMENT_FEATURES_ONLY_v05220.jsonl',
                 'P12F_DEVELOPMENT_DIAGNOSTIC_FUTURE_ONLY_v05220.jsonl'):
        shutil.copyfile(parent/name,out/name)
        require(sha_file(out/name)==hashes[name],'COPIED_DATA_SHA_CHANGED')
    predictions,metrics=model_evaluation(rows)
    with (out/'P12G_DEVELOPMENT_ONLY_OOF_PREDICTIONS.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=('row_key','seed','site','load','telemetry','y',
                                         'score_local','score_remote'))
        w.writeheader();w.writerows(predictions)
    summary={'status':'P12G_DEVELOPMENT_ONLY_DIAGNOSTIC_PR_AUC_NO_CONFIRMATORY_CLAIM',
             'protocol':prereg,'parent_P12F_QC':'PASS',
             'original_development_cases':72,'prospective_development_rows':9216,
             'development_only_out_of_seed_fold_predictions':4608,
             'development_only_exploratory_fits_executed':12,
             'training_for_Stage1AO_executed':False,
             'validation_runs':0,'heldout_runs':0,
             'official_F3_labels_constructed':0,'official_F3_PR_AUC_computed':False,
             'F3_scientific_claim_authorized':False,
             'all_parent_raw_sha_verified_before_any_model_fit':True,
             **metrics,**SCIENCE}
    (out/'P12G_DEVELOPMENT_ONLY_PR_AUC_REPORT.json').write_text(
        json.dumps(summary,sort_keys=True,indent=2)+'\n')
    (out/'P12G_OUTPUT_SHA256SUMS.txt').write_text(''.join(
        sha_file(p)+'  '+p.name+'\n' for p in sorted(out.iterdir())
        if p.is_file() and p.name!='P12G_OUTPUT_SHA256SUMS.txt'))
    print('P12G_COMPLETED',json.dumps({k:summary[k] for k in (
        'status','development_only_out_of_seed_fold_predictions',
        'development_out_of_fold_AP_local','development_out_of_fold_AP_remote',
        'development_out_of_fold_delta_AP_remote_minus_local')},sort_keys=True),flush=True)
    return summary


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--preflight-only',action='store_true')
    p.add_argument('--parent-dir',type=Path,default=PARENT)
    p.add_argument('--output-dir',type=Path,default=OUT)
    args=p.parse_args()
    if args.preflight_only:print(json.dumps(preflight(),indent=2))
    else:run(args.parent_dir,args.output_dir)


if __name__=='__main__':main()
