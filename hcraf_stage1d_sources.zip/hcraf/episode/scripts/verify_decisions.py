#!/usr/bin/env python3
"""Strict acceptance checks for Stage 1B pilot only; Python >=3.8."""
import json
from pathlib import Path
import sys
from episodes import load, require


def verify(folder, load_profile=False, multi_profile=False):
    decisions = load(folder/'events.jsonl.decisions.jsonl')
    events = load(folder/'events.jsonl')
    links = load(folder/'link_events.jsonl')
    episodes = load(folder/'episodes.jsonl')
    config = json.loads((folder/'scenario.json').read_text())
    mode = config['mode']
    expected = config['planned_requests'] if (load_profile or multi_profile) else (1 if mode == 'open' else 6 if mode == 'retransmit' else 3)
    require(len(decisions) == expected, 'unexpected decision count')
    require([d['decision_id'] for d in decisions] == list(range(1, expected+1)), 'decision ID gap')
    lookup = {d['decision_id']: d for d in decisions}
    require(events[-1]['event_type'] == 'SIMULATION_END', 'incomplete events')
    require(links and links[-1]['event_type'] == 'FINAL', 'incomplete link trace')
    require([x['link_event_seq'] for x in links] == list(range(1,len(links)+1)), 'link sequence gap')
    require(all(a['time_ns'] <= b['time_ns'] for a,b in zip(links,links[1:])), 'link time order')
    mapping = {(x['node_id'], x['face_id']): x['device_index'] for x in links if x['event_type']=='INITIAL'}
    require(len(mapping)==6, 'six directed devices required')
    running = {key: [0,0] for key in mapping}
    snapshots = {}
    upstream_faces = {c['face_id'] for d in decisions for c in d['candidates']} if load_profile else set()
    for x in links:
        key = (x['node_id'],x['face_id'])
        require(key in mapping and mapping[key]==x['device_index'], 'Face/device mapping changed')
        require(x['event_type'] in {'INITIAL','FINAL','DECISION_SNAPSHOT','PHY_TX_BEGIN','PHY_TX_END','QUEUE_DROP'}, 'unknown link event')
        require(0 <= x['time_ns'] <= config['stop_ns'], 'link event outside run')
        for field in ('queue_packets','queue_bytes','phy_tx_started_bytes_total','queue_drop_packets_total'):
            require(type(x[field]) is int and x[field]>=0, 'invalid link count '+field)
        bottleneck = load_profile and (x['node_id']==2 or (x['node_id']==1 and x['face_id'] in upstream_faces))
        expected_rate = config['bottleneck_rate_bps'] if bottleneck else config['link_rate_bps']
        if multi_profile:
            if x['node_id']==2 or (x['node_id']==1 and x['face_id']==config['primary_face_id']):
                expected_rate=config['primary_rate_bps']
            elif x['node_id']==3 or (x['node_id']==1 and x['face_id']==config['secondary_face_id']):
                expected_rate=config['secondary_rate_bps']
            else: expected_rate=config['link_rate_bps']
        require(x['data_rate_bps']==expected_rate, 'wrong link rate')
        require(type(x['link_up']) is bool, 'missing link state')
        if x['event_type']=='PHY_TX_BEGIN':
            require(type(x['packet_bytes']) is int and x['packet_bytes']>0, 'missing PHY bytes')
            running[key][0] += x['packet_bytes']
        if x['event_type']=='QUEUE_DROP': running[key][1] += 1
        require(running[key]==[x['phy_tx_started_bytes_total'],x['queue_drop_packets_total']], 'counter/evidence mismatch')
        if x['event_type']=='DECISION_SNAPSHOT':
            require(x['decision_id'] in lookup, 'orphan link snapshot')
            d=lookup[x['decision_id']]
            require(x['decision_node_id']==d['node_id'] and x['time_ns']==d['time_ns'], 'snapshot is not decision-time')
            skey=(x['decision_id'],key)
            require(skey not in snapshots, 'duplicate snapshot')
            snapshots[skey]=x
    require(sum(v[0] for v in running.values())>0, 'no observed transmissions')
    for kind,t in [('INITIAL',0),('FINAL',config['stop_ns'])]:
        rows=[x for x in links if x['event_type']==kind]
        require(len(rows)==6 and len({(x['node_id'],x['face_id']) for x in rows})==6, 'missing boundary snapshot')
        require(all(x['time_ns']==t for x in rows), 'wrong boundary time')
    tx_by_decision={d['decision_id']:[] for d in decisions}
    for e in events:
        if e['event_type']!='TX_INTEREST': continue
        require(e.get('decision_id') in lookup, 'pilot TX outside recorded synchronous decision')
        d=lookup[e['decision_id']]
        require((e['node_id'],e['pit_instance_id'],e['name'],e['time_ns']) ==
                (d['node_id'],d['pit_instance_id'],d['name'],d['time_ns']), 'TX context mismatch')
        require(e['event_seq']>d['after_event_seq'], 'decision snapshot after action')
        require(e['face_id'] in {c['face_id'] for c in d['candidates']}, 'TX outside name FIB')
        tx_by_decision[d['decision_id']].append(e)
    episode_by_tx={seq:row['episode_id'] for row in episodes for seq in row['tx_event_seqs']}
    rows=[]
    for d in decisions:
        require(d['schema_version']=='1B.1' and d['anchor']=='BEFORE_AFTER_RECEIVE_INTEREST', 'wrong decision schema/anchor')
        require(d['candidate_semantics']=='RAW_NAME_FIB_NOT_STRATEGY_ELIGIBILITY', 'wrong candidate semantics')
        require(d['fib_prefix']=='/hcraf', 'unexpected pilot FIB prefix')
        require(0<=d['after_event_seq']<=len(events), 'bad anchor sequence')
        before=events[:d['after_event_seq']]
        after=events[d['after_event_seq']:]
        require(not before or before[-1]['time_ns']<=d['time_ns'], 'anchor preceding past evidence')
        require(not after or after[0]['time_ns']>=d['time_ns'], 'anchor includes future evidence')
        require(len(d['candidates'])==(2 if (mode=='cancel' or multi_profile) else 1), 'missing pilot next hop')
        require(len({c['face_id'] for c in d['candidates']})==len(d['candidates']), 'duplicate candidate')
        require(sum(1 for sid,_ in snapshots if sid==d['decision_id'])==6, 'missing decision link snapshot')
        for c in d['candidates']:
            expected_cost=1
            if multi_profile:
                require(c['face_id'] in (config['primary_face_id'],config['secondary_face_id']), 'unknown upstream Face')
                expected_cost=2 if c['face_id']==config['secondary_face_id'] else (
                    3 if mode=='multi-change' and d['time_ns']>=5000000000 else 1)
            require(type(c['routing_cost']) is int and c['routing_cost']==expected_cost, 'pilot actual FIB cost mismatch')
            require(c['strategy_eligible'] is None, 'eligibility must not be invented')
            require(c['is_ingress']==(c['face_id']==d['ingress_face_id']), 'ingress flag mismatch')
            link=snapshots.get((d['decision_id'],(d['node_id'],c['face_id'])))
            require(link is not None, 'candidate has no local link measurement')
            tx=[x for x in tx_by_decision[d['decision_id']] if x['face_id']==c['face_id']]
            require(all(x['event_seq'] in episode_by_tx for x in tx), 'TX not reconstructed')
            rows.append(dict(decision_id=d['decision_id'],node_id=d['node_id'],
                pit_instance_id=d['pit_instance_id'],name=d['name'],time_ns=d['time_ns'],
                after_event_seq=d['after_event_seq'],face_id=c['face_id'],routing_cost=c['routing_cost'],
                selected=bool(tx),tx_event_seqs=[x['event_seq'] for x in tx],
                episode_ids=[episode_by_tx[x['event_seq']] for x in tx],
                strategy_eligible=None,selection_role=None,congestion=None,
                congestion_missing_reason='RAW_PRIMITIVES_ONLY_DEFINITION_PENDING',
                local_queue_packets=link['queue_packets'],local_queue_bytes=link['queue_bytes'],
                local_link_up=link['link_up'],local_data_rate_bps=link['data_rate_bps'],
                local_phy_tx_started_bytes_total=link['phy_tx_started_bytes_total'],
                local_queue_drop_packets_total=link['queue_drop_packets_total'],
                research_training_eligible=False,split_role='ENGINEERING_PILOT_ONLY'))
    return rows,dict(status='PASS',stage='1D.1' if multi_profile else '1C.1' if load_profile else '1B.1',decisions=len(decisions),candidate_rows=len(rows),
                     mapped_tx=sum(map(len,tx_by_decision.values())),directed_links=len(mapping),
                     research_training_eligible=False)

if __name__=='__main__':
    folder=Path(sys.argv[1])
    try:
        rows,report=verify(folder)
        (folder/'decision_faces.jsonl').write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in rows))
    except Exception as e:
        report=dict(status='FAIL',error=str(e))
    (folder/'decision_verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
    sys.exit(0 if report['status']=='PASS' else 1)
