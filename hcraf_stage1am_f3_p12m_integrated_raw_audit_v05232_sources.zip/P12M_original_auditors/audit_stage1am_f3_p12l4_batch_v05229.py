#!/usr/bin/env python3
"""Cross-check six raw GitHub Actions seed artifacts. Never compute AP."""
import argparse,hashlib,json,zipfile
from pathlib import Path
SEEDS=tuple(range(24819,24825))
MODEL='de46e2f5fcb052f96e920729664084ad0edd029cc4af88b2c5480209976a35d1'
LOCKS=dict(Congestion=None,FutureCongestion=None,F3_ready=False,GO_FREEZE=False,training_ready=False,heldout_release_authorized=False)
def check(v,tag):
    if not v:raise RuntimeError('P12L4_BATCH_'+tag)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def audit(path):
    path=Path(path)
    check(path.is_dir(),'NO_ARTIFACT_DIRECTORY')
    dirs=[p for p in path.iterdir() if p.is_dir() and p.name.startswith('hcraf-f3-p12l4-seed-')]
    check(len(dirs)==6,'NOT_EXACTLY_SIX_UPLOADED_ARTIFACTS')
    output=[]
    for seed in SEEDS:
        matches=[p for p in dirs if p.name.startswith(f'hcraf-f3-p12l4-seed-{seed}-')]
        check(len(matches)==1,'DUPLICATE_OR_MISSING_SEED_ARTIFACT')
        folder=matches[0]
        receipts=list(folder.rglob(f'P12L4_SEED_{seed}_RECEIPT.json'))
        archives=list(folder.rglob(f'P12L4_RAW_SEED_{seed}.zip'))
        check(len(receipts)==len(archives)==1,'MISSING_RECEIPT_OR_RAW_ARCHIVE')
        r=json.loads(receipts[0].read_text()); zfile=archives[0]
        check(r['seed']==seed and r['cases']==12 and r['raw_file_count']==481 and r['expected_episodes']==1536 and
              r['telemetry_on_episodes']==768 and r['frozen_model_sha256']==MODEL and
              r['P12K_parent_run']==45195251299 and r['P12L3_prev_run']==45618979484 and r['P12K_parent_commit']=='e9819bb1aeb9c786fe68061a97f02308a110c56d',
              'RECEIPT_PROVENANCE')
        check(all(r.get(k) is v for k,v in LOCKS.items()) and r['model_fits']==0 and
              r['interim_AP_computed'] is False and r['validation_reads']==r['heldout_reads']==0 and
              r['official_F3_labels_constructed']==0,'SCIENTIFIC_LOCK')
        check(sha(zfile)==r['raw_archive_sha256'],'ARCHIVE_SHA')
        with zipfile.ZipFile(zfile) as z:
            check(z.testzip() is None,'ARCHIVE_CRC')
            m=json.loads(z.read('P12L4_RAW_FILE_SHA256.json'))
            check(len(m)==481 and set(z.namelist())==set(m)|{'P12L4_RAW_FILE_SHA256.json'},'RAW_MEMBER_COUNT')
            for name,digest in m.items():
                check(hashlib.sha256(z.read(name)).hexdigest()==digest,'RAW_MEMBER_SHA_'+name)
            cases={tuple(n.split('/')[:3]) for n in m if len(n.split('/'))>3}
            check(cases=={(site,load,t) for site in ('producer_egress','transit_middle','consumer_ingress')
                          for load in ('low_control','high_pressure') for t in ('off','on_20ms')},
                  'CASE_MATRIX_MISMATCH')
        output.append({'seed':seed,'raw_archive_sha256':r['raw_archive_sha256'],
                       'raw_files':481,'cases':12,'expected_episodes':1536})
        print('PASS_P12L4_SEED_RAW_ARCHIVE',seed,flush=True)
    return {'status':'PASS_P12L4_SIX_INDEPENDENT_SEED_BLOCKS_PHYSICAL_RAW_QC_ONLY',
            'P12K_prereg_run':45195251299,'P12L3_prior_success_run':45618979484,'seed_blocks':[x['seed'] for x in output],
            'raw_archives':output,'physical_cases':72,'expected_episodes':9216,
            'telemetry_on_episodes':4608,'interim_AP_computed':False,
            'model_fits':0,'Validation_read':False,'Heldout_read':False,
            'scientific_decision':'NO_INTERIM_GO_NO_GO','previous_validation':'P12H_NO_GO',**LOCKS}

def main():
    p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--output',required=True)
    a=p.parse_args();report=audit(a.input);out=Path(a.output)
    out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
    print('PASS_P12L4_BATCH_ARCHIVES_COMPLETE_NO_AP')
if __name__=='__main__':main()
