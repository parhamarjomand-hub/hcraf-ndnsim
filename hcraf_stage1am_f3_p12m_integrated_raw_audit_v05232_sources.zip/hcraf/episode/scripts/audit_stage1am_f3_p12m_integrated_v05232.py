#!/usr/bin/env python3
"""P12M: independent 36-seed raw integrity audit, strictly NO AP and NO training.
Reuses unchanged frozen P12L1-L6 per-batch auditors, cross-checks original QC receipts and GitHub sources.
"""
import argparse,hashlib,importlib.util,json,os,pathlib,subprocess,urllib.request,sys
ROOT=pathlib.Path(__file__).resolve().parents[3]
DOC=ROOT/'P12M_original_QC'
AUD=ROOT/'P12M_original_auditors'
MAN=ROOT/'P12M_PARENT_PROVENANCE.json'
PLAN=ROOT/'P12M_prereg/P12K_ANALYSIS_PLAN_FROZEN_v05225.json'
MODEL=ROOT/'P12M_prereg/P12K_PINNED_P12H_FROZEN_MODELS.json'
LOCKS=('Congestion','FutureCongestion','F3_ready','GO_FREEZE','training_ready','heldout_release_authorized')
def fail(why):raise RuntimeError('P12M_INTEGRITY_FAIL_'+why)
def need(test,why):
    if not test:fail(why)
def sha(x):return hashlib.sha256(pathlib.Path(x).read_bytes()).hexdigest()
def load(x):return json.loads(pathlib.Path(x).read_text())
def api(path):
    token=os.environ.get('GH_TOKEN')
    need(token,'MISSING_GITHUB_TOKEN')
    url='https://api.github.com/repos/parhamarjomand-hub/hcraf-ndnsim'+path
    headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','User-Agent':'HCRAF-P12M-immutable-raw-QC'}
    with urllib.request.urlopen(urllib.request.Request(url,headers=headers),timeout=60) as r:return json.load(r)
def prereg():
    m=load(MAN);p=load(PLAN)
    need(len(m['batch_records'])==6 and m['expected_seeds']==list(range(24801,24837)),'MATRIX_36')
    need(m['expected_physical_cases']==432 and m['expected_episodes']==55296 and m['expected_active_arm_episodes']==27648,'EPISODES')
    need(p['physical_case_count']==432 and p['primary_episodes_planned']==27648 and p['seed_blocks']==m['expected_seeds'],'PREREG_COUNTS')
    need(p['bootstrap']['rng_seed']==525250 and p['bootstrap']['replicates']==10000 and p['bootstrap']['two_sided_CI_coverage']==0.975,'STATISTICAL_LOCK')
    need(sha(PLAN)==m['p12k']['plan_sha256'] and sha(MODEL)==m['p12k']['model_sha256']==p['frozen_model_sha256'],'FROZEN_HASH')
    need(m['no_interim_ap'] is True and m['no_model_fit'] is True,'NO_AP_LOCK')
    need(m['forbidden_original_heldout_seeds']==list(range(24701,24705)),'HELDOUT_SEAL')
    return m
def authenticate(m,batch):
    entry=m['batch_records'][batch-1];par=m['p12k']
    for r in [par,entry]:
        data=api('/actions/runs/'+str(r['run']))
        need(data['conclusion']=='success' and data['status']=='completed','PARENT_RUN_NOT_SUCCESS_'+str(r['run']))
        need(data['head_sha']==r['commit'],'PARENT_COMMIT_'+str(r['run']))
        if 'path' in r:need(data['path']==r['path'],'PARENT_WORKFLOW_PATH_'+str(r['run']))
        # Prevent quietly switching repository branch to an unrelated commit.
        subprocess.run(['git','merge-base','--is-ancestor',r['commit'],'HEAD'],check=True)
    for aid,digest,runid in [(par['artifact_id'],par['artifact_digest'],par['run']),
                            (entry['qc_artifact_id'],entry['qc_artifact_digest'],entry['run'])]:
        a=api('/actions/artifacts/'+str(aid))
        need(a['digest']==digest and a['workflow_run']['id']==runid and not a['expired'],'AUTH_ARTIFACT_'+str(aid))
    # Validate individual GitHub artifact identities, not just ZIP contents.
    listing=api('/actions/runs/'+str(entry['run'])+'/artifacts?per_page=100')
    q=[a for a in listing['artifacts'] if a['name'].startswith('hcraf-f3-p12l'+str(batch)+'-seed-')]
    need(len(q)==6,'EXACT_SIX_GITHUB_RAW_ARTIFACTS')
    for seed in entry['expected_seeds']:
        name=f'hcraf-f3-p12l{batch}-seed-{seed}-v052{25+batch}-run-{entry["run"]}-attempt-1'
        matches=[x for x in q if x['name']==name]
        need(len(matches)==1 and not matches[0]['expired'] and matches[0]['workflow_run']['id']==entry['run'],'AUTH_SEED_ARTIFACT_'+str(seed))
    return entry
def inspect_batch(batch,input_dir,output,authenticate_parents=True):
    m=prereg();need(1<=batch<=6,'INVALID_BATCH')
    entry=authenticate(m,batch) if authenticate_parents else m['batch_records'][batch-1]
    auditorscript=ROOT/entry['auditor_file']
    need(sha(auditorscript)==entry['auditor_sha256'],'AUDITOR_SHA_TAMPER')
    spec=importlib.util.spec_from_file_location(f'p12m_original_batch_auditor_{batch}',auditorscript)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    qc=module.audit(str(input_dir))  # Exact original auditor: 481 SHA per seed; no AP.
    original=load(ROOT/entry['qc_record_json'])
    need(qc==original,'CROSS_AUDIT_RESULT_DIFFERS_FROM_ORIGINAL_QC')
    need(qc['seed_blocks']==entry['expected_seeds'] and qc['physical_cases']==72 and qc['expected_episodes']==9216,'BATCH_COUNTS')
    need(sum(r['raw_files'] for r in qc['raw_archives'])==2886,'RAW_FILES_COUNT')
    need([r['raw_archive_sha256'] for r in qc['raw_archives']]==entry['expected_raw_zip_sha256'],'ARCHIVE_SHA_UNEXPECTED')
    need(all(qc.get(k) is (None if k in ('Congestion','FutureCongestion') else False) for k in LOCKS),'SCIENCE_LOCKS')
    need(qc['model_fits']==0 and qc['interim_AP_computed'] is False and qc['Validation_read'] is False and qc['Heldout_read'] is False,'NO_LEAKAGE')
    report={'batch':batch,'run':entry['run'],'parent_commit':entry['commit'],
            'parent_qc_artifact_id':entry['qc_artifact_id'],'parent_qc_digest':entry['qc_artifact_digest'],
            'status':'PASS_P12M_INDEPENDENT_REPEAT_BATCH_RAW_QC_NO_AP',
            'seeds':qc['seed_blocks'],'physical_cases':72,'episodes':9216,'on_arm_episodes':4608,
            'verified_raw_files':2886,'raw_archives':qc['raw_archives'],
            'interim_AP_computed':False,'model_fits':0,'Validation_read':False,'Heldout_read':False,
            'scientific_decision':'NO_INTERIM_GO_NO_GO'}
    pathlib.Path(output).write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
    print('PASS_P12M_BATCH',batch,flush=True)
    return report
def aggregate(path,out):
    m=prereg();path=pathlib.Path(path)
    files=sorted(path.rglob('P12M_BATCH_?_REPEAT_QC.json'))
    need(len(files)==6,'NOT_SIX_CROSS_BATCH_RECEIPTS')
    rows=[load(x) for x in files]
    need(sorted(x['batch'] for x in rows)==list(range(1,7)),'BATCH_DUPLICATE_OR_MISSING')
    seeds=[];raw=[]
    for x in sorted(rows,key=lambda x:x['batch']):
        b=x['batch'];entry=m['batch_records'][b-1]
        need(x['status']=='PASS_P12M_INDEPENDENT_REPEAT_BATCH_RAW_QC_NO_AP','BAD_REPEAT_AUDIT')
        need(x['run']==entry['run'] and x['parent_commit']==entry['commit'],'WRONG_PARENT')
        need(x['seeds']==entry['expected_seeds'] and x['physical_cases']==72 and x['episodes']==9216 and x['on_arm_episodes']==4608,'WRONG_COUNTS')
        need(x['verified_raw_files']==2886 and x['interim_AP_computed'] is False and x['model_fits']==0,'BAD_SCIENCE_FENCE')
        need(x['Validation_read'] is False and x['Heldout_read'] is False,'DATA_LEAKAGE')
        need([q['raw_archive_sha256'] for q in x['raw_archives']]==entry['expected_raw_zip_sha256'],'ARCHIVE_LOCK')
        seeds.extend(x['seeds']);raw.extend(x['raw_archives'])
    need(seeds==m['expected_seeds'] and len(set(seeds))==36 and len({q['raw_archive_sha256'] for q in raw})==36,'SEEDS_OR_ARCHIVE_COLLISION')
    result={'status':'PASS_P12M_INDEPENDENT_ALL_36_SEEDS_432_CASES_RAW_QC_ONLY',
            'P12K_run':m['p12k']['run'],'run_ids':[x['run'] for x in m['batch_records']],
            'seeds':seeds,'seed_count':36,'case_count':432,'episodes':55296,'primary_active_arm_episodes':27648,
            'raw_files_sha_checked':36*481,'raw_archives_revalidated':36,
            'frozen_model_sha256':m['p12k']['model_sha256'],
            'interim_AP_computed':False,'model_fits':0,'Validation_read':False,'Heldout_read':False,
            'previous_P12H_validation':'NO_GO',
            'scientific_decision':'READY_FOR_ONE_TIME_PREREGISTERED_ANALYSIS_ONLY_NOT_F3_GO',
            'Congestion':None,'FutureCongestion':None,'F3_ready':False,'GO_FREEZE':False,'training_ready':False,
            'heldout_release_authorized':False,'Stage1AO_or_NSGAIII_authorized':False}
    pathlib.Path(out).write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(result['status'])
    return result
if __name__=='__main__':
 p=argparse.ArgumentParser();sub=p.add_subparsers(dest='command',required=True)
 v=sub.add_parser('batch');v.add_argument('--batch',type=int,required=True);v.add_argument('--input',required=True);v.add_argument('--output',required=True);v.add_argument('--offline-fixture',action='store_true')
 v=sub.add_parser('aggregate');v.add_argument('--input',required=True);v.add_argument('--output',required=True)
 args=p.parse_args()
 if args.command=='batch':inspect_batch(args.batch,args.input,args.output,not args.offline_fixture)
 if args.command=='aggregate':aggregate(args.input,args.output)
