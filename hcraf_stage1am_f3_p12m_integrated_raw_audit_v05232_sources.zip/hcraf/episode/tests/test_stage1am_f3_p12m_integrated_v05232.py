import unittest,tempfile,pathlib,json,copy,shutil
from hcraf.episode.scripts.audit_stage1am_f3_p12m_integrated_v05232 import prereg,aggregate,fail,inspect_batch
class TestP12M(unittest.TestCase):
  def test_prereg_counts(self):
    m=prereg();self.assertEqual(len(m['expected_seeds']),36);self.assertEqual(m['expected_physical_cases'],432)
  def test_disjoint_batch_seeds(self):
    m=prereg();self.assertEqual(sorted(s for e in m['batch_records'] for s in e['expected_seeds']),list(range(24801,24837)))
  def test_sha_metadata_length(self):
    m=prereg();self.assertEqual(len({h for e in m['batch_records'] for h in e['expected_raw_zip_sha256']}),36)
  def test_bad_batch_refused(self):
    with self.assertRaises(RuntimeError):inspect_batch(7,'/missing','/tmp/none',False)
  def test_missing_report_refused(self):
    with tempfile.TemporaryDirectory() as d:
      with self.assertRaises(RuntimeError):aggregate(d,pathlib.Path(d)/'out.json')
  def test_aggregate_real_signed_receipt_fixtures(self):
    m=prereg()
    with tempfile.TemporaryDirectory() as d:
      for e in m['batch_records']:
        b=e['batch'];q=json.loads(pathlib.Path('P12M_original_QC/P12L%d_SIGNED_QC.json'%b).read_text())
        x={'batch':b,'run':e['run'],'parent_commit':e['commit'],'status':'PASS_P12M_INDEPENDENT_REPEAT_BATCH_RAW_QC_NO_AP','seeds':q['seed_blocks'],'physical_cases':72,'episodes':9216,'on_arm_episodes':4608,'verified_raw_files':2886,'raw_archives':q['raw_archives'],'interim_AP_computed':False,'model_fits':0,'Validation_read':False,'Heldout_read':False}
        pathlib.Path(d,f'P12M_BATCH_{b}_REPEAT_QC.json').write_text(json.dumps(x))
      r=aggregate(d,pathlib.Path(d)/'all.json')
      self.assertEqual((r['seed_count'],r['case_count'],r['episodes'],r['raw_files_sha_checked']),(36,432,55296,17316))
      self.assertFalse(r['F3_ready'])
  def test_reject_modified_parent(self):
    m=prereg()
    with tempfile.TemporaryDirectory() as d:
      for e in m['batch_records']:
        b=e['batch'];q=json.loads(pathlib.Path('P12M_original_QC/P12L%d_SIGNED_QC.json'%b).read_text())
        x={'batch':b,'run':e['run'],'parent_commit':e['commit'],'status':'PASS_P12M_INDEPENDENT_REPEAT_BATCH_RAW_QC_NO_AP','seeds':q['seed_blocks'],'physical_cases':72,'episodes':9216,'on_arm_episodes':4608,'verified_raw_files':2886,'raw_archives':q['raw_archives'],'interim_AP_computed':False,'model_fits':0,'Validation_read':False,'Heldout_read':False}
        if b==6:x['raw_archives'][0]['raw_archive_sha256']='0'*64
        pathlib.Path(d,f'P12M_BATCH_{b}_REPEAT_QC.json').write_text(json.dumps(x))
      with self.assertRaises(RuntimeError):aggregate(d,pathlib.Path(d)/'all.json')
if __name__=='__main__':unittest.main()
