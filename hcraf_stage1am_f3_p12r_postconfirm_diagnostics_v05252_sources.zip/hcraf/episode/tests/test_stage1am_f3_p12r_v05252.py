import pathlib,sys,unittest,tempfile
import numpy as np
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'scripts'))
import diagnose_stage1am_f3_p12r_v05252 as d
class TestDiagnostics(unittest.TestCase):
    def test_ties(self):self.assertAlmostEqual(d.ap(np.array([.5,.5]),np.array([1,0])),.5)
    def test_no_positive(self):self.assertIsNone(d.ap(np.array([.5]),np.array([0])))
    def test_empty(self):self.assertIsNone(d.ap(np.array([]),np.array([])))
    def test_age_boundary(self):
        a=d.age_groups(np.array([50,50.1,75,75.1,100]),np.array([False,False,False,False,True]));self.assertEqual([v.tolist() for _,v in a],[[True,False,False,False,False],[False,True,True,False,False],[False,False,False,True,False],[False,False,False,False,True]])
    def test_constant_corr(self):self.assertIsNone(d.corr(np.array([1,1]),np.array([1,0])))
    def test_perfect_corr(self):self.assertAlmostEqual(d.corr(np.array([1,2,3]),np.array([2,4,6])),1)
    def test_normalization(self):self.assertEqual(d.normalize(np.array([[100.,-100.]]),{'means':[0,0],'sds':[1,1]}).tolist(),[[5.,-5.]])
    def test_no_overwrite(self):
        with tempfile.TemporaryDirectory() as t:
            with self.assertRaisesRegex(RuntimeError,'REFUSE_OVERWRITE'):d.diagnose(None,None,None,None,pathlib.Path(t))
    def test_bad_parent(self):
        with tempfile.TemporaryDirectory() as t:
            p=pathlib.Path(t)/'bad.zip';p.write_bytes(b'not authenticated');
            with self.assertRaisesRegex(RuntimeError,'ZIP_HASH'):d.read_parent(p,[],[])
    def test_science_fences(self):self.assertTrue(d.p.flags(d.p.FLAGS));self.assertTrue(d.NO_GO.startswith('NO_GO_'));self.assertNotEqual(d.STATUS,d.NO_GO)
if __name__=='__main__':unittest.main()
