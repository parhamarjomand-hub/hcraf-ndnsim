#!/usr/bin/env python3
"""P12R v0.52.51: locked confirmatory analysis, never fit or release official F3."""
import argparse,collections,csv,hashlib,io,json,math,pathlib,random,zipfile,sys
import numpy as np
QC_SHA='5ec1fae15e3406214bac508dfb295d9e3db7310e713a0e48038f98cb16f151c4'
FREEZE_SHA='c68ed8da0f82229b04d5c20623142c2f46f355cb88e7aa129ba9171f24819f9c'
MODEL_SHA='6ae14949b3bdc5218d2420b84452b7326142869e843711d2cb0958672363de82'
PREREG_SHA='dbb12863ca83c26b687b243211aaf698986b8d6f2f7b8656cffb06278751ae30'
SEEDS=list(range(25001,25037)); N=27648; REPS=10000; RNG=525250
FLAGS=dict(F3_ready=False,GO_FREEZE=False,training_ready=False,heldout_release_authorized=False,Stage1AO_or_NSGAIII_authorized=False,Congestion=None,FutureCongestion=None)
FILES={'B1_confirmation_features.csv':'643cb1946a5f98ceb6923261d8fcadf9f72b7a75bd17c72d936d4bb42cc7a875','R_confirmation_features.csv':'daa74ceae1fce3b986f8d6591c60e876849fb4960108552cc4505159a82575ca','case_qc.csv':'26957830f55b7a0b148cd34765fba6554bbfebd3a489fb1e1cd94de6c70c341a','confirmation_audit_keys_NOT_FEATURES.csv':'b9e30c209c821fa556185365bdb53b72d407e0f739946a405553eac21f77b853','confirmation_research_endpoint.csv':'dad61b2716759ee5dc4dd6d47ddfede42869fe1690c985fec8308b139eb871b6'}
def need(ok,msg):
    if not ok: raise RuntimeError('P12R51_'+msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def encode(x):return (json.dumps(x,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def archive(path,digest):
    need(sha(path.read_bytes())==digest,'ZIP_HASH_'+path.name)
    z=zipfile.ZipFile(path);need(z.testzip() is None and len(z.namelist())==len(set(z.namelist())),'ZIP_STRUCTURE');return z
def flags(x):return all(x[k] is v for k,v in FLAGS.items())
def load(qc,frozen,prereg):
    with archive(prereg,PREREG_SHA) as z:
        n=[n for n in z.namelist() if n.endswith('/P12R_FAIR_COMPARATOR_PROSPECTIVE_PLAN_v05237.json')];need(len(n)==1,'PLAN');plan=json.loads(z.read(n[0]))
    ar=plan['analysis_rules'];need(ar['AP_ties']=='tie-grouped non-interpolated' and ar['CI_coverage']==.975 and ar['CI_lower_quantile']==.0125 and ar['CI_upper_quantile']==.9875 and ar['bootstrap_replicates']==REPS and ar['bootstrap_rng_seed']==RNG and ar['bootstrap_unit']=='whole-seed paired resampling 36 blocks' and all(ar[k] for k in ('full_blind_until_36_seeds','no_interim_AP','no_multiple_looks','no_optional_stopping')),'ANALYSIS_CONTRACT')
    need(flags(plan) and plan['seed_partitions']['independent_confirmation']==SEEDS and plan['endpoint']['horizon_ns']==75000000 and plan['endpoint']['primary_arm']=='on_20ms','PLAN_FENCES')
    b1=plan['feature_sets']['strengthened_local_B1_primary_control'];r=plan['feature_sets']['remote_plus_B1_R_primary_treatment'];need(len(b1)==12 and len(r)==21 and r[:12]==b1,'FEATURE_CONTRACT')
    with archive(frozen,FREEZE_SHA) as z:
        prefix='p12r_frozen_models/';name='P12R_FROZEN_FULL_DEV_MODELS_v05248.json';data=z.read(prefix+name);m=json.loads(data);f=json.loads(z.read(prefix+'P12R_DEV_MODEL_FREEZE_RECEIPT_v05248.json'))
        need(sha(data)==MODEL_SHA==f['model_sha256'] and z.read(prefix+'P12R_FROZEN_MODEL_SHA256SUMS.txt').decode().strip()==MODEL_SHA+'  '+name,'MODEL_HASH')
        need(f['status']=='PASS_P12R_TWO_DEV_MODELS_FROZEN_ONLY_NO_CONFIRMATION_NO_F3_RELEASE' and f['model_fits']==2 and flags(f) and flags(m),'FREEZE_STATUS')
        need(m['trained_on_seeds']==list(range(24901,24907)) and m['trained_on_rows']==4608 and m['fixed_model_prereg']==plan['model_training_locked'] and m['source_prereg_zip_sha256']==PREREG_SHA,'TRAINING_PROVENANCE')
        need(all(m[k]==0 and f[k]==0 for k in ('confirmation_rows_read','confirmation_simulations_this_stage','diagnostic_rows_used','legacy_validation_rows_read','heldout_rows_read','official_F3_labels_constructed')) and not m['new_AP_computed'] and not m['new_bootstrap_computed'],'FREEZE_NO_LOOK')
        for key,header,lab in [('local_model',b1,'B1'),('remote_model',r,'R')]:
            v=m[key];need(v['names']==header and sha(encode(v))==f[lab+'_model_sha256'],'MODEL_FEATURES_HASH');need(all(len(v[k])==len(header) and all(math.isfinite(x) for x in v[k]) for k in ('means','sds','weights')) and all(s>0 for s in v['sds']) and math.isfinite(v['intercept']),'MODEL_VALUES')
        need(m['local_model']['means']==m['remote_model']['means'][:12] and m['local_model']['sds']==m['remote_model']['sds'][:12],'SCALER_PAIR')
    with archive(qc,QC_SHA) as z:
        prefix='p12r_confirm_dataset_qc/';q=json.loads(z.read(prefix+'P12R_CONFIRM_DATASET_QC_RECEIPT_v05250.json'))
        need(q['status']=='PASS_P12R_CONFIRM_DATASET_QC_ONLY_NO_SCORING_NO_F3_RELEASE' and flags(q) and q['model_sha256']==MODEL_SHA and q['prereg_sha256']==PREREG_SHA and q['parent_run']==45995680622 and q['parent_commit']=='cc0b8dba61dc2d19192d5d0795d0fdfe086ff1b9','QC_STATUS')
        need(q['primary_rows']==N and q['confirmation_cases']==432 and q['decisions_audited']==55296 and q['raw_files_checked']==17280 and q['paired_times_match']==216 and all(q[k]==0 for k in ('model_fits','diagnostic_rows_used','development_cases_read','heldout_rows_read','official_F3_labels_constructed')) and not q['new_AP_computed'] and not q['new_bootstrap_computed'],'QC_COUNTS')
        need(q['feature_order_B1']==b1 and q['feature_order_R']==r and q['output_sha256']==FILES,'QC_FILE_CONTRACT');raw={n:z.read(prefix+n) for n in FILES};need(all(sha(raw[n])==h for n,h in FILES.items()),'QC_FILE_HASH')
    def read(name,header):
        rows=list(csv.reader(io.StringIO(raw[name].decode(),newline='')));need(rows[0]==header and len(rows)==N+1 and all(len(x)==len(header) for x in rows[1:]),'CSV_SCHEMA_'+name);return rows[1:]
    X=[[float(v) for v in row] for row in read('B1_confirmation_features.csv',b1)];R=[[float(v) for v in row] for row in read('R_confirmation_features.csv',r)]
    keys=read('confirmation_audit_keys_NOT_FEATURES.csv',['seed','site','load','decision_id','decision_time_ns']);ys=read('confirmation_research_endpoint.csv',['future_selected_path_device0_queue_drop_75ms']);need(all(x[0] in ('0','1') for x in ys),'LABEL');y=[int(x[0]) for x in ys]
    need(all(all(math.isfinite(v) for v in row) for row in X+R) and all(a==b[:12] for a,b in zip(X,R)),'FEATURE_PAIR')
    sites=plan['prospective_design']['sites'];loads=plan['prospective_design']['loads'];counts=collections.Counter((int(k[0]),k[1],k[2]) for k in keys);need(counts=={(s,i,j):128 for s in SEEDS for i in sites for j in loads},'CONFIRM_MATRIX')
    need(len({tuple(k[:4]) for k in keys})==N and all(int(k[3])>0 and int(k[4])>=0 for k in keys),'KEY_UNIQUENESS')
    seed=[int(k[0]) for k in keys];pos=collections.Counter(s for s,v in zip(seed,y) if v);need(sum(y)==q['positive'] and N-sum(y)==q['negative'] and {str(s):pos[s] for s in SEEDS}==q['positives_by_seed'],'LABEL_COUNTS')
    need(0<sum(y)<N,'POOLED_CLASSES')
    cases=list(csv.DictReader(io.StringIO(raw['case_qc.csv'].decode())));need(len(cases)==432 and {(int(c['seed']),c['site'],c['load'],c['telemetry']) for c in cases}=={(s,i,j,t) for s in SEEDS for i in sites for j in loads for t in ('off','on_20ms')},'CASE_QC_MATRIX');need(all(int(c['decisions'])==128 for c in cases),'CASE_DECISIONS')
    need(sum(int(c['positive']) for c in cases if c['telemetry']=='on_20ms')==sum(y),'CASE_LABELS')
    return X,R,keys,np.array(y,dtype=np.int64),np.array(seed,dtype=np.int64),m,q,plan,cases

def sigmoid(z):
    if z>=0:return 1/(1+math.exp(-z))
    e=math.exp(z);return e/(1+e)
def score(X,m):
    out=[]
    for row in X:
        need(len(row)==len(m['names']),'SCORE_SHAPE')
        xx=[max(-5.,min(5.,(v-mu)/sd)) for v,mu,sd in zip(row,m['means'],m['sds'])]
        out.append(sigmoid(m['intercept']+sum(a*b for a,b in zip(m['weights'],xx))))
    need(all(math.isfinite(x) and 0<=x<=1 for x in out),'SCORE_FINITE');return np.array(out)
class AP:
    """Tie-grouped weighted AP. Integer seed multiplicity equals literal row replication."""
    def __init__(self,s,y,blocks):
        s=np.asarray(s);y=np.asarray(y);blocks=np.asarray(blocks)
        need(len(s)>0 and s.shape==y.shape==blocks.shape and np.all(np.isfinite(s)) and np.all((y==0)|(y==1)) and np.all(blocks>=0),'AP_INPUT')
        order=np.argsort(-s,kind='stable');ss=s[order];self.y=y[order];self.blocks=blocks[order];self.starts=np.r_[0,np.flatnonzero(ss[1:]!=ss[:-1])+1]
    def value(self,counts):
        weights=counts[self.blocks];p=np.add.reduceat(weights*self.y,self.starts);n=np.add.reduceat(weights,self.starts);total=int(p.sum())
        if not total:return None
        cp=np.cumsum(p);cn=np.cumsum(n);prec=np.divide(cp,cn,out=np.zeros(len(cn),dtype=np.float64),where=cn!=0)
        return float(np.sum(prec*p)/total)
def percentile(values,q):
    need(len(values)>0 and 0<=q<=1,'PERCENTILE');v=sorted(values);i=(len(v)-1)*q;lo=math.floor(i);hi=math.ceil(i);return v[lo]+(i-lo)*(v[hi]-v[lo])
def bootstrap(a,b):
    rng=random.Random(RNG);deltas=[]
    for _ in range(REPS):
        c=np.bincount([rng.randrange(36) for __ in range(36)],minlength=36).astype(np.int64);x=a.value(c);z=b.value(c)
        if x is None or z is None:return None
        deltas.append(z-x)
    return deltas

def costs(cases):
    out={}; fields=['remote_missing','remote_age_count','remote_age_sum_ms','telemetry_requests','telemetry_data_sent','telemetry_data_received','telemetry_interest_wire_bytes','telemetry_data_sent_wire_bytes','telemetry_data_received_wire_bytes','observer_wall_ns_sum','nfd_path_wall_ns_sum','nfd_path_cpu_ns_sum']
    for arm in ('off','on_20ms'):
        rows=[r for r in cases if r['telemetry']==arm];v={k:sum(float(r[k]) for r in rows) if k=='remote_age_sum_ms' else sum(int(r[k]) for r in rows) for k in fields};v['decisions']=sum(int(r['decisions']) for r in rows);v['remote_age_mean_ms']=v['remote_age_sum_ms']/v['remote_age_count'] if v['remote_age_count'] else None;v['remote_age_max_ms']=max((float(r['remote_age_max_ms']) for r in rows if r['remote_age_max_ms']),default=None);v['nfd_path_cpu_ns_per_decision']=v['nfd_path_cpu_ns_sum']/v['decisions'];v['observer_wall_ns_per_decision']=v['observer_wall_ns_sum']/v['decisions'];out[arm]=v
    return out

def write_csv(p,header,rows):
    with p.open('w',newline='') as f:w=csv.writer(f,lineterminator='\n');w.writerow(header);w.writerows(rows)
def analyze(qc,frozen,prereg,out):
    need(not out.exists(),'REFUSE_OVERWRITE');X,R,keys,y,seed,m,q,plan,cases=load(qc,frozen,prereg)
    # No scores computed until all 36 seed blocks and frozen inputs pass authentication.
    s1=score(X,m['local_model']);s2=score(R,m['remote_model']);idx=seed-SEEDS[0];a=AP(s1,y,idx);b=AP(s2,y,idx);ones=np.ones(36,dtype=np.int64);ap1=a.value(ones);ap2=b.value(ones);need(ap1 is not None and ap2 is not None,'POOLED_AP')
    per=[]
    for i,s in enumerate(SEEDS):
        c=np.zeros(36,dtype=np.int64);c[i]=1;x=a.value(c);z=b.value(c);d=None if x is None or z is None else z-x;per.append([s,int((idx==i).sum()),int(y[idx==i].sum()),x,z,d,d is not None and d>0])
    d=bootstrap(a,b);lo=percentile(d,.0125) if d is not None else None;hi=percentile(d,.9875) if d is not None else None;positive_seeds=sum(x[-1] for x in per);prevalence=float(y.sum()/len(y));gates={'all_cases_and_causal_QC':True,'pooled_both_classes':0<int(y.sum())<N,'R_AP_gt_B1':ap2>ap1,'R_AP_gt_prevalence':ap2>prevalence,'positive_seeds_at_least_27':positive_seeds>=27,'paired_bootstrap_lower_gt_zero':lo is not None and lo>0,'frozen_models_no_refit_no_legacy_or_heldout':True}
    status='INDETERMINATE_P12R_INVALID_BOOTSTRAP' if d is None else ('PASS_P12R_CONFIRMATORY_STATISTICAL_GATES_ONLY_NO_F3_RELEASE' if all(gates.values()) else 'NO_GO_P12R_CONFIRMATORY_STATISTICAL_GATES_NOT_MET')
    report=dict(status=status,primary_estimand=plan['primary_estimand'],AP_B1=ap1,AP_R=ap2,delta_AP=ap2-ap1,prevalence=prevalence,positive=int(y.sum()),negative=N-int(y.sum()),primary_rows=N,confirmation_cases=432,seed_blocks=36,positive_seed_count=positive_seeds,negative_seed_count=sum(x[5] is not None and x[5]<0 for x in per),zero_delta_seed_count=sum(x[5]==0 for x in per),undefined_seed_count=sum(x[5] is None for x in per),CI_coverage=.975,CI_lower=lo,CI_upper=hi,bootstrap_replicates=0 if d is None else len(d),bootstrap_rng_seed=RNG,bootstrap_unit='paired whole-seed blocks; Python Random.randrange(36) 36 draws per replicate',percentile_method='linear interpolation at (n-1)*q (type 7); specified before scoring',AP_ties='tie-grouped non-interpolated; frozen sigmoid probability',gates=gates,model_sha256=MODEL_SHA,QC_artifact_sha256=QC_SHA,freeze_artifact_sha256=FREEZE_SHA,prereg_sha256=PREREG_SHA,model_fits=0,confirmation_simulations_this_stage=0,diagnostic_rows_used=0,legacy_validation_rows_read=0,heldout_rows_read=0,official_F3_labels_constructed=0,new_AP_computed=True,new_bootstrap_computed=d is not None,construct_review_required=True,historical_NO_GO_preserved=True,multiplicity_limitation_preserved=True,secondary_descriptive_costs=costs(cases),B0_secondary='legacy local four-feature historical comparator not refitted; no new B0 fit',constant_B1_features=q['constant_B1_features'],remote_missing=q['remote_missing'],python_version=sys.version.split()[0],numpy_version=np.__version__,**FLAGS)
    out.mkdir(parents=True,exist_ok=False);write_csv(out/'P12R_PER_SEED_AP.csv',['seed','rows','positive','AP_B1','AP_R','delta_AP','strict_positive'],per);write_csv(out/'P12R_PAIRED_SCORES.csv',['seed','site','load','decision_id','decision_time_ns','research_endpoint','score_B1','score_R'],(k+[int(v),float(x),float(z)] for k,v,x,z in zip(keys,y,s1,s2)));write_csv(out/'P12R_BOOTSTRAP_DELTA_AP.csv',['replicate','delta_AP'],enumerate(d or [],1));(out/'P12R_CONFIRM_STATISTICAL_REPORT_v05251.json').write_bytes(encode(report));(out/'P12R_OUTPUT_SHA256SUMS.txt').write_text(''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in sorted(out.iterdir())));print(status,flush=True);print(json.dumps({k:report[k] for k in ('AP_B1','AP_R','delta_AP','prevalence','positive_seed_count','CI_lower','CI_upper','gates')},sort_keys=True),flush=True);return report
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--qc-zip',type=pathlib.Path,required=True);p.add_argument('--freeze-zip',type=pathlib.Path,required=True);p.add_argument('--prereg-zip',type=pathlib.Path,required=True);p.add_argument('--output',type=pathlib.Path,required=True);a=p.parse_args();analyze(a.qc_zip,a.freeze_zip,a.prereg_zip,a.output)
