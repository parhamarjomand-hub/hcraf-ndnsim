#!/usr/bin/env python3
"""Read-only exploratory post-confirmation diagnostics. No new candidate scoring or fit."""
import argparse, collections, csv, io, json, math, pathlib
import numpy as np
import p12r52_parent_analysis as p
ANALYSIS_SHA='39aeb581a3db73218e8c1188ff91425ab3f21c87a07c79961569a289e8b4cff7'
ANALYSIS_FILES={'P12R_BOOTSTRAP_DELTA_AP.csv':'90680ffd0343a5ada51ac88226158106ec30864441d92855f4a2bad05c4710a2','P12R_CONFIRM_STATISTICAL_REPORT_v05251.json':'408ead8ed68cf9f66c0cc4a1106d879cd09790050907c517ddef53177e8b9d46','P12R_PAIRED_SCORES.csv':'851b6548e950731023a902180ede53676785b5ae966f3760dd9286bddd5c4377','P12R_PER_SEED_AP.csv':'3d8759b441a878dcf11d41cb2dbc4bc79ec43596ce105e1c0839eaf2bd5576f2'}
STATUS='PASS_P12R_POSTCONFIRM_EXPLORATORY_DIAGNOSTICS_ONLY_NO_F3_RELEASE'
NO_GO='NO_GO_P12R_CONFIRMATORY_STATISTICAL_GATES_NOT_MET'

def need(ok,msg):
    if not ok:raise RuntimeError('P12R52_'+msg)
def read_parent(path,keys,y):
    with p.archive(path,ANALYSIS_SHA) as z:
        prefix='p12r_confirm_analysis/'; raw={n:z.read(prefix+n) for n in ANALYSIS_FILES}
        need(all(p.sha(raw[n])==h for n,h in ANALYSIS_FILES.items()),'PARENT_MEMBER_HASH')
        sums=dict((n,h) for h,n in (line.split('  ',1) for line in z.read(prefix+'P12R_OUTPUT_SHA256SUMS.txt').decode().splitlines()))
        need(sums==ANALYSIS_FILES,'PARENT_SUMS')
    r=json.loads(raw['P12R_CONFIRM_STATISTICAL_REPORT_v05251.json']);need(r['status']==NO_GO and p.flags(r) and not r['gates']['R_AP_gt_B1'] and not r['gates']['positive_seeds_at_least_27'] and not r['gates']['paired_bootstrap_lower_gt_zero'] and r['model_sha256']==p.MODEL_SHA and r['QC_artifact_sha256']==p.QC_SHA and r['freeze_artifact_sha256']==p.FREEZE_SHA and r['prereg_sha256']==p.PREREG_SHA and r['primary_rows']==p.N and r['bootstrap_replicates']==10000,'PARENT_NO_GO')
    need(all(r[k]==0 for k in ('model_fits','confirmation_simulations_this_stage','diagnostic_rows_used','legacy_validation_rows_read','heldout_rows_read','official_F3_labels_constructed')),'PARENT_FENCES')
    rows=list(csv.reader(io.StringIO(raw['P12R_PAIRED_SCORES.csv'].decode())));need(rows[0]==['seed','site','load','decision_id','decision_time_ns','research_endpoint','score_B1','score_R'] and len(rows)==p.N+1,'SCORE_SCHEMA')
    need(all(a[:5]==k and a[5]==str(v) for a,k,v in zip(rows[1:],keys,y)),'SCORE_ALIGNMENT')
    s=np.array([[float(v) for v in row[6:]] for row in rows[1:]]);need(np.all(np.isfinite(s)) and np.all((s>=0)&(s<=1)),'SCORE_VALUES');return r,s

def ap(s,y):
    if not len(y) or not int(y.sum()):return None
    return p.AP(s,y,np.zeros(len(y),dtype=np.int64)).value(np.ones(1,dtype=np.int64))
def group(name,mask,y,s):
    yy=y[mask];ss=s[mask];n=len(yy);pos=int(yy.sum());a=ap(ss[:,0],yy);b=ap(ss[:,1],yy)
    return dict(group=name,rows=n,positive=pos,negative=n-pos,prevalence=pos/n if n else None,AP_B1=a,AP_R=b,delta_AP=b-a if a is not None and b is not None else None)
def corr(a,b):
    if len(a)<2 or np.all(a==a[0]) or np.all(b==b[0]):return None
    return float(np.corrcoef(a,b)[0,1])
def avg(x):return float(np.mean(x)) if len(x) else None
def summarize(x):return dict(mean=avg(x),sd=float(np.std(x)) if len(x) else None,min=float(np.min(x)) if len(x) else None,max=float(np.max(x)) if len(x) else None)
def age_groups(age,missing):
    good=~missing
    return [('max_age_le_50ms',good&(age<=50)),('max_age_gt_50_le_75ms',good&(age>50)&(age<=75)),('max_age_gt_75ms',good&(age>75)),('any_remote_missing',missing)]
def normalize(X,m):return np.clip((X-np.array(m['means']))/np.array(m['sds']),-5,5)
def diagnose(qc,freeze,prereg,analysis,out):
    need(not out.exists(),'REFUSE_OVERWRITE')
    X,R,keys,y,seeds,m,q,plan,cases=p.load(qc,freeze,prereg);r,s=read_parent(analysis,keys,y)
    # Recheck scores against frozen coefficients, no alternate scoring model.
    need(np.array_equal(s[:,0],p.score(X,m['local_model'])) and np.array_equal(s[:,1],p.score(R,m['remote_model'])),'FROZEN_SCORE_REPLAY')
    X=np.asarray(X);R=np.asarray(R);site=np.array([k[1] for k in keys]);load=np.array([k[2] for k in keys]);allrows=np.ones(len(y),dtype=bool)
    groups=[group('all',allrows,y,s)]
    need(abs(groups[0]['AP_B1']-r['AP_B1'])<1e-12 and abs(groups[0]['AP_R']-r['AP_R'])<1e-12,'POOLED_AP_REPLAY')
    for i in plan['prospective_design']['sites']:
        groups.append(group('site:'+i,site==i,y,s))
        for j in plan['prospective_design']['loads']:groups.append(group('site_load:'+i+'/'+j,(site==i)&(load==j),y,s))
    for j in plan['prospective_design']['loads']:groups.append(group('load:'+j,load==j,y,s))
    ages=R[:,[14,17,20]];missing=R[:,[13,16,19]].astype(bool);max_age=ages.max(axis=1);ag=age_groups(max_age,missing.any(axis=1));need(np.all(sum(mask.astype(int) for _,mask in ag)==1),'AGE_PARTITION')
    for name,mask in ag:groups.append(group('age:'+name,mask,y,s))
    for seed in p.SEEDS:groups.append(group('seed:'+str(seed),seeds==seed,y,s))
    nodes=[]
    for node,qi,mi,ai in [('relay',12,13,14),('mid',15,16,17),('producer',18,19,20)]:
        g=R[:,mi]==0;a=R[g,ai];queue=R[g,qi];yy=y[g]
        nodes.append(dict(node=node,available=int(g.sum()),missing=int((~g).sum()),age_mean_ms=avg(a),age_p95_ms=float(np.percentile(a,95)),age_gt_75=int((a>75).sum()),age_gt_75_fraction=avg(a>75),queue_positive=int((queue>0).sum()),endpoint_prevalence_queue_positive=avg(yy[queue>0]),endpoint_prevalence_queue_zero=avg(yy[queue==0]),queue_endpoint_pearson=corr(queue,yy)))
    local=m['local_model'];remote=m['remote_model'];Z=normalize(R,remote);w=np.array(remote['weights']);v=np.array(local['weights']);features=[]
    for i,name in enumerate(remote['names']):
        a=R[:,i];features.append(dict(feature=name,scope='local' if i<12 else 'remote',distinct=int(len(np.unique(a))),nonzero=int(np.count_nonzero(a)),raw_sd=float(np.std(a)),endpoint_pearson=corr(a,y),B1_weight=float(v[i]) if i<12 else None,R_weight=float(w[i]),R_logit_contribution_sd=float(np.std(Z[:,i]*w[i])),clipped_rows=int(np.count_nonzero(np.abs((a-remote['means'][i])/remote['sds'][i])>5))))
    pairs=[]
    for i in range(21):
        for j in range(i+1,21):
            c=corr(R[:,i],R[:,j]);pairs.append(dict(feature_a=remote['names'][i],feature_b=remote['names'][j],pearson=c,exact_equal=bool(np.array_equal(R[:,i],R[:,j]))))
    # A decomposition of EXISTING logits, not a new predictor, ablation, or fitted model.
    local_shift=Z[:,:12]@(w[:12]-v);remote_term=Z[:,12:]@w[12:];bias=remote['intercept']-local['intercept'];delta=local_shift+remote_term+bias
    valid=(s[:,0]>0)&(s[:,0]<1)&(s[:,1]>0)&(s[:,1]<1)
    logit=lambda x:np.log(x/(1-x))
    need(np.allclose(delta[valid],logit(s[valid,1])-logit(s[valid,0]),atol=1e-8,rtol=1e-8),'LOGIT_DECOMPOSITION')
    components={k:{'all':summarize(a),'positive':summarize(a[y==1]),'negative':summarize(a[y==0])} for k,a in [('local_weight_shift',local_shift),('remote_term',remote_term),('delta_logit',delta)]}
    components['intercept_shift']=bias
    arm={(int(c['seed']),c['site'],c['load'],c['telemetry']):c for c in cases}; paired=[]
    for seed in p.SEEDS:
        for i in plan['prospective_design']['sites']:
            for j in plan['prospective_design']['loads']:
                a=arm[(seed,i,j,'off')];b=arm[(seed,i,j,'on_20ms')];paired.append(dict(seed=seed,site=i,load=j,positive_off=int(a['positive']),positive_on=int(b['positive']),drop_events_off=int(a['selected_path_drops']),drop_events_on=int(b['selected_path_drops']),cpu_ns_off=int(a['nfd_path_cpu_ns_sum']),cpu_ns_on=int(b['nfd_path_cpu_ns_sum'])))
    result=dict(status=STATUS,parent_scientific_status=NO_GO,parent_AP_B1=r['AP_B1'],parent_AP_R=r['AP_R'],parent_delta_AP=r['delta_AP'],parent_CI=[r['CI_lower'],r['CI_upper']],primary_rows=p.N,confirmation_cases=432,seed_blocks=36,model_sha256=p.MODEL_SHA,analysis_artifact_sha256=ANALYSIS_SHA,QC_artifact_sha256=p.QC_SHA,freeze_artifact_sha256=p.FREEZE_SHA,prereg_sha256=p.PREREG_SHA,exploratory_only=True,confirmation_consumed_for_diagnostics=True,independent_new_validation_required=True,causal_root_cause_established=False,model_fits=0,new_candidate_scores=0,new_bootstrap_computed=False,new_hypothesis_tests=0,new_simulations=0,heldout_rows_read=0,diagnostic_injection_rows_used=0,official_F3_labels_constructed=0,subgroup_AP_descriptive=True,missing_values_not_excluded_from_pooled=True,groups=groups,remote_nodes=nodes,logit_decomposition=components,score_pearson=corr(s[:,0],s[:,1]),paired_control_summary={k:sum(row[k] for row in paired) for k in ('positive_off','positive_on','drop_events_off','drop_events_on','cpu_ns_off','cpu_ns_on')},limitations=['Post hoc comparisons on consumed confirmation, no new inferential claim or selection of a winning subgroup.','Age strata are associated with topology, load and decision timing; not randomized freshness interventions. Age >75ms is a descriptive threshold, not a protocol violation.','Missingness weights were learned only in DEV; no refit.','Logit terms reflect joint fitted coefficients, not a causal decomposition or ablation.','Endpoint is future selected reverse-path queue drop, not a validated general congestion construct.'],**p.FLAGS)
    out.mkdir(parents=True,exist_ok=False)
    for n,rows in [('subgroup_AP.csv',groups),('remote_age_queue.csv',nodes),('feature_diagnostics.csv',features),('feature_correlations.csv',pairs),('paired_control_cases.csv',paired)]:
        p.write_csv(out/n,list(rows[0]),([row[k] for k in rows[0]] for row in rows))
    (out/'P12R_EXPLORATORY_REPORT_v05252.json').write_bytes(p.encode(result));names=sorted(x.name for x in out.iterdir());(out/'P12R_OUTPUT_SHA256SUMS.txt').write_text(''.join(p.sha((out/n).read_bytes())+'  '+n+'\n' for n in names));print(STATUS);return result
if __name__=='__main__':
    a=argparse.ArgumentParser();
    for k in ('qc','freeze','prereg','analysis','output'):a.add_argument('--'+k,type=pathlib.Path,required=True)
    v=a.parse_args();diagnose(v.qc,v.freeze,v.prereg,v.analysis,v.output)
