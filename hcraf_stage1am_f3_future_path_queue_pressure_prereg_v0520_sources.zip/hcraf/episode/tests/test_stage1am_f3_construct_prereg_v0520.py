#!/usr/bin/env python3
"""Unit tests for v0.52.0 prospectively frozen *candidate* protocol only."""
import csv,json,sys,unittest
from collections import Counter
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]/'docs'/'1AM'/'F3_FUTURE_PATH_QUEUE_PRESSURE_PREREG_v0.52.0'
sys.path.insert(0,str(ROOT))
import generate_prereg_v0520 as g
from label_rules import classify_candidate,verify_online_features,HORIZON_NS
DEV=[(8,0),(7,0),(2,0)]
EV=[{'time_ns':1,'node_id':n,'device_index':d,'event_type':'QUEUE_ENQUEUE'} for n,d in DEV]
def lab(events=EV,**extra):
 a=dict(decision_ns=0,observed_end_ns=HORIZON_NS,return_senders=DEV,events=events,witnesses_complete=True,observers_agree=True,path_valid=True);a.update(extra);return classify_candidate(**a)
class TestV0520(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.matrix=list(csv.DictReader((ROOT/'RUN_MATRIX_LOCKED_648.csv').read_text().splitlines()))
  cls.idx=list(csv.DictReader((ROOT/'SCHEDULE_INDEX_LOCKED_72.csv').read_text().splitlines()))
  cls.split=list(csv.DictReader((ROOT/'RNG_SPLIT_LOCKED_36.csv').read_text().splitlines()))
 def test_01_deterministic_files(self):self.assertEqual(g.verify(ROOT)['total_runs'],648)
 def test_02_monitor_counts(self):self.assertEqual(Counter(r['instrumented'] for r in self.matrix),{'1':576,'0':72})
 def test_03_split_counts(self):self.assertEqual(Counter(r['split'] for r in self.matrix),{'CALIBRATION':216,'HELDOUT_CONFIRMATORY':432})
 def test_04_rng_blocks_no_overlap(self):
  a={r['rng_block'] for r in self.matrix if r['split']=='CALIBRATION'};b={r['rng_block'] for r in self.matrix if r['split']=='HELDOUT_CONFIRMATORY'};self.assertEqual((len(a),len(b)),(12,24));self.assertFalse(a&b)
 def test_05_schedule_identity_across_paired_arms(self):
  groups={}
  for r in self.matrix:
   if r['instrumented']!='1':continue
   k=(r['rng_block'],r['family']);groups.setdefault(k,set()).add(r['schedule_sha256'])
  self.assertEqual(len(groups),72);self.assertTrue(all(len(v)==1 for v in groups.values()))
 def test_06_monitored_full_arm_count(self):
  groups=Counter((r['rng_block'],r['family']) for r in self.matrix if r['instrumented']=='1')
  self.assertTrue(all(n==8 for n in groups.values()))
 def test_07_one_unmon_per_schedule(self):
  groups=Counter((r['rng_block'],r['family']) for r in self.matrix if r['instrumented']=='0')
  self.assertEqual(len(groups),72);self.assertTrue(all(n==1 for n in groups.values()))
 def test_08_balanced_unmon_arms(self):
  for split,n in [('CALIBRATION',3),('HELDOUT_CONFIRMATORY',6)]:
   counts=Counter(r['arm'] for r in self.matrix if r['instrumented']=='0' and r['split']==split)
   self.assertEqual(set(counts.values()),{n});self.assertEqual(len(counts),8)
 def test_09_arms_and_sites(self):
  sites=list(csv.DictReader((ROOT/'INTERVENTION_SITES_LOCKED_12.csv').read_text().splitlines()))
  self.assertEqual(len(sites),12);self.assertEqual({s['selected_slot'] for s in sites},{'0','1','2'})
 def test_10_target_competitor_schedule(self):
  for r in self.idx:
   plan=list(csv.DictReader((ROOT/r['plan_filename']).read_text().splitlines()))
   self.assertEqual(Counter(x['traffic_class'] for x in plan),{'TARGET':12,'INDEPENDENT_COMPETITOR':96})
 def test_11_future_strict_boundaries(self):
  e=EV+[{'time_ns':0,'node_id':8,'device_index':0,'event_type':'QUEUE_DROP'}]
  self.assertEqual(lab(e)['candidate_label'],0)
  e.append({'time_ns':HORIZON_NS,'node_id':8,'device_index':0,'event_type':'QUEUE_DROP'})
  self.assertEqual(lab(e)['candidate_label'],1)
 def test_12_nonqueue_loss_not_congestion(self):
  e=EV+[{'time_ns':2,'node_id':8,'device_index':0,'event_type':'PHY_RX_DROP'}]
  self.assertEqual(lab(e)['candidate_label'],0)
 def test_13_missing_opportunity_unknown(self):
  self.assertEqual(lab([EV[0]])['status'],'UNKNOWN')
 def test_14_censored_precedence(self):
  self.assertEqual(lab(EV+[{'time_ns':3,'node_id':8,'device_index':0,'event_type':'QUEUE_DROP'}],observed_end_ns=HORIZON_NS-1)['status'],'CENSORED')
 def test_15_bad_witness_unknown(self):self.assertEqual(lab(witnesses_complete=False)['status'],'UNKNOWN')
 def test_16_bad_A_B_unknown(self):self.assertEqual(lab(observers_agree=False)['status'],'UNKNOWN')
 def test_17_bad_path_unknown(self):self.assertEqual(lab(path_valid=False)['status'],'UNKNOWN')
 def test_18_feature_leakage_hard_fail(self):
  with self.assertRaises(ValueError):verify_online_features({'future_congestion':{'value':1,'max_observation_ns':0}},100)
  with self.assertRaises(ValueError):verify_online_features({'historical_rtt_ms_before_t':{'value':2,'max_observation_ns':101}},100)
 def test_19_feature_provenance_good(self):
  self.assertTrue(verify_online_features({'historical_rtt_ms_before_t':{'value':3,'max_observation_ns':99}},100))
 def test_20_no_science_gate_release(self):
  s=json.loads((ROOT/'SCIENCE_LOCKS.json').read_text());self.assertFalse(s['heldout_release_authorized']);self.assertIsNone(s['Congestion']);self.assertIsNone(s['FutureCongestion']);self.assertFalse(s['F3_ready']);self.assertFalse(s['GO_FREEZE']);self.assertFalse(s['training_ready'])
 def test_21_candidates_never_official(self):
  self.assertFalse(lab()['is_official_f3_label']);self.assertFalse(lab([])['is_official_f3_label'])
 def test_22_unique_names_and_unseen_rngs(self):
  self.assertEqual(len({r['run_id'] for r in self.matrix}),648)
  self.assertTrue(all(int(r['rng_block']) not in range(11901,11913) for r in self.matrix))
 def test_23_holdout_not_authorized(self):
  self.assertEqual({r['access_rule'] for r in self.split if r['split']=='HELDOUT_CONFIRMATORY'},{'DO_NOT_RUN_OR_INSPECT_UNTIL_FROZEN_GATE'})
 def test_24_construct_physical_queue_only(self):
  e=EV+[{'time_ns':1,'node_id':7,'device_index':0,'event_type':'QUEUE_DROP'}]
  self.assertEqual(lab(e)['status'],'CANDIDATE_POSITIVE')
  self.assertEqual(lab(EV)['status'],'CANDIDATE_NEGATIVE')
if __name__=='__main__':unittest.main()
