#!/usr/bin/env python3
"""Candidate v0.52.0 label rule. Diagnostic/prospective only; NOT official F3.

Caller must supply independently verified witness flags; this function NEVER
infers that absence of a recorded event implies complete observation.
"""
HORIZON_NS=75_000_000
RETURN_SENDER_DEVICE_COUNT=3

def classify_candidate(*,decision_ns,observed_end_ns,return_senders,events,
                       witnesses_complete,observers_agree,path_valid):
    if isinstance(decision_ns,bool) or not isinstance(decision_ns,int) or decision_ns<0:
        raise ValueError('INVALID_DECISION_NS')
    if isinstance(observed_end_ns,bool) or not isinstance(observed_end_ns,int):
        raise ValueError('INVALID_END_NS')
    if observed_end_ns<decision_ns+HORIZON_NS:
        return {'candidate_label':None,'status':'CENSORED','reason':'FULL_75MS_NOT_OBSERVED', 'is_official_f3_label':False}
    if (not witnesses_complete) or (not observers_agree) or (not path_valid):
        return {'candidate_label':None,'status':'UNKNOWN','reason':'PHYSICAL_WITNESS_OR_MAP_NOT_VALID','is_official_f3_label':False}
    devices=tuple(tuple(x) for x in return_senders)
    if len(devices)!=RETURN_SENDER_DEVICE_COUNT or len(set(devices))!=RETURN_SENDER_DEVICE_COUNT:
        return {'candidate_label':None,'status':'UNKNOWN','reason':'RETURN_PATH_NOT_THREE_UNIQUE_DEVICES','is_official_f3_label':False}
    drops=0;enqueue_devices=set()
    for event in events:
        if not isinstance(event,dict):raise ValueError('INVALID_EVENT')
        t=event['time_ns']
        if isinstance(t,bool) or not isinstance(t,int):raise ValueError('INVALID_EVENT_TIME')
        if not(decision_ns<t<=decision_ns+HORIZON_NS):continue
        node_dev=(event['node_id'],event['device_index'])
        if node_dev not in devices:continue
        if event['event_type']=='QUEUE_DROP':drops+=1
        elif event['event_type']=='QUEUE_ENQUEUE':enqueue_devices.add(node_dev)
        # PHY_RX_DROP and target TIMEOUT are explicitly excluded.
    if drops>0:
        return {'candidate_label':1,'status':'CANDIDATE_POSITIVE','reason':'WITNESSED_PATH_QUEUE_DROP','is_official_f3_label':False}
    if set(devices).issubset(enqueue_devices):
        return {'candidate_label':0,'status':'CANDIDATE_NEGATIVE','reason':'ALL_THREE_RETURN_SENDERS_TRAFFIC_OPPORTUNITY','is_official_f3_label':False}
    return {'candidate_label':None,'status':'UNKNOWN','reason':'INSUFFICIENT_QUEUE_TRAFFIC_OPPORTUNITY','is_official_f3_label':False}

ONLINE_ALLOWLIST={
 'decision_time_ns', 'slot_id', 'face_id', 'prior_pit_count',
 'historical_success_rate_before_t','historical_rtt_ms_before_t',
 'historical_nack_rate_before_t','previous_100ms_local_queue_sample',
 'configured_nominal_return_capacity_bps'
}
ONLINE_DENYLIST={
 'future_path_queue_drop','future_queue_wait','target_timeout','target_success',
 'episode_outcome','deadline_reconstruction','phy_rx_drop_after_t',
 'lp_group_from_future','future_congestion','Congestion','FutureCongestion',
 'phase_label','rng_block','arm','loss_kind'
}

def verify_online_features(features,decision_ns):
    """features: dict name -> {'value': scalar, 'max_observation_ns': int}.

    Static nominal capacity is allowed as online configuration, with required
    independent no-capacity ablation; its timestamp may be zero.
    """
    keys=set(features)
    if not keys.issubset(ONLINE_ALLOWLIST) or (keys & ONLINE_DENYLIST):
        raise ValueError('FUTURE_OR_UNAPPROVED_FEATURE:'+repr(sorted(keys-ONLINE_ALLOWLIST)))
    for name,record in features.items():
        if not isinstance(record,dict) or 'max_observation_ns' not in record or 'value' not in record:
            raise ValueError('FEATURE_PROVENANCE_REQUIRED:'+name)
        t=record['max_observation_ns']
        if not isinstance(t,int) or isinstance(t,bool) or t>decision_ns:
            raise ValueError('FEATURE_LEAKAGE_OR_INVALID_TIME:'+name)
    return True
