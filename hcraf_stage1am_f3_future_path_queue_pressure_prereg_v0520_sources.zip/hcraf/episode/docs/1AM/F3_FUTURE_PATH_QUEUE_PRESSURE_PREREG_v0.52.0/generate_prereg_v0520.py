#!/usr/bin/env python3
"""v0.52.0 scientific proxy preregistered DESIGN ONLY. NEVER run simulator here."""
import argparse,csv,hashlib,io,json
from collections import Counter,defaultdict
from pathlib import Path

SCHEMA='HCRAF_F3_PHYSICAL_QUEUE_PRESSURE_PREREG_V0520'
MASTER='HCRAF-F3-QUEUE-PRESSURE-v0.52.0-20261114-CALIBRATION-HELDOUT-LOCK'
SPLITS={'CALIBRATION': tuple(range(22001,22013)), 'HELDOUT_CONFIRMATORY':tuple(range(23001,23025))}
FAMILIES=('C_STAGGERED_BURSTS','D_RAMPED_PULSES')
PHASE_MS=(-150,-50,50,150)
ARMS=(('PRODUCER_RETURN_6M','PRODUCER_RETURN',6000000,0),('PRODUCER_RETURN_12M','PRODUCER_RETURN',12000000,0),('MID_RETURN_6M','MID_RETURN',6000000,0),('MID_RETURN_12M','MID_RETURN',12000000,0),('RELAY_RETURN_6M','RELAY_RETURN',6000000,0),('RELAY_RETURN_12M','RELAY_RETURN',12000000,0),('ALL_RETURN_50M','NONE',50000000,0),('NONQUEUE_RX_LOSS_50M','NONE',50000000,15))
PATHS={0: ((8,0,7,1),(7,0,2,1),(2,0,1,1),(2,0,1,1)),1: ((9,0,6,1),(6,0,3,1),(3,0,1,2),(3,0,1,2)),2: ((10,0,5,1),(5,0,4,1),(4,0,1,3),(4,0,1,3))}
SITE_TYPES=('PRODUCER_RETURN','MID_RETURN','RELAY_RETURN','NONQUEUE_RX_LOSS_RECEIVER')
SCHEDULE_COLUMNS=('traffic_class','sequence','time_ns','family','rng_block','split','phase_label','phase_nominal_ns','phase_jitter_ns','selected_slot','load_level','schedule_schema')
INDEX_COLUMNS=('split','rng_block','selected_slot','family','load_level','phase_label','phase_nominal_ns','phase_jitter_ns','target_start_ns','competitor_start_ns','plan_filename','schedule_sha256','target_schedule_sha256','competitor_schedule_sha256')
MATRIX_COLUMNS=('run_id','split','rng_block','seed','selected_slot','family','load_level','phase_label','arm','intervention_location','intervention_return_bps','other_path_return_bps','forward_bps','loss_kind','loss_probability','loss_stream','loss_receiver_node_id','loss_receiver_device_index','instrumented','plan_filename','schedule_sha256','target_schedule_sha256','competitor_schedule_sha256','status')
SITE_COLUMNS=('selected_slot','intervention_location','sender_node_id','sender_device_index','receiver_node_id','receiver_device_index','mapping_provenance','runtime_identity_crosscheck_required')
SPLIT_COLUMNS=('split','rng_block','selected_slot','phase_label','phase_nominal_ns','family_count','arm_count','monitored_run_count','unmonitored_run_count','access_rule')
SCIENCE={'Congestion':None,'FutureCongestion':None,'F3_ready':False,'GO_FREEZE':False,'training_ready':False}

def sha(b):return hashlib.sha256(b).hexdigest()
def h(*parts):return hashlib.sha256('|'.join((MASTER,*map(str,parts))).encode()).digest()
def signed(bound,*parts):return int.from_bytes(h(*parts)[:8],'big')%(2*bound+1)-bound
def encode_csv(rows,fields):
 out=io.StringIO(newline='');w=csv.DictWriter(out,fieldnames=fields,lineterminator='\n');w.writeheader();w.writerows(rows);return out.getvalue().encode()

def allocation():
 control={}; phases={}; loads={}
 for split,rngs in SPLITS.items():
  first=rngs[0]
  for rng in rngs:
   slot=(rng-first)%3
   serial=(rng-first)//3
   phase=serial%4
   # Balanced load per slot in heldout (two cycles), calibration is diagnostic only.
   load='HEAVY' if ((serial + (serial//4))%2) else 'LIGHT'
   phases[rng]=phase;loads[rng]=load
  for slot in range(3):
   cells=[(rng,f) for rng in rngs if (rng-first)%3==slot for f in FAMILIES]
   cells.sort(key=lambda c:h('unmon-cell',split,slot,*c))
   arms=[(a[0],rep) for rep in range(len(cells)//8) for a in ARMS]
   arms.sort(key=lambda x:h('unmon-arm',split,slot,x[0],x[1]))
   assert len(cells)==len(arms)
   control.update(dict(zip(cells,(name for name,_ in arms))))
 return phases,loads,control

def plan(rng,split,family,phase,load):
 slot=(rng-SPLITS[split][0])%3
 offset=PHASE_MS[phase]*1000000
 jitter=signed(9000000,'phase-jitter',rng,family)
 tstart=2520000000+signed(80000000,'targetstart',rng,family)
 cstart=tstart+offset+jitter
 rows=[]
 for seq in range(12):
  when=tstart+seq*31000000+signed(4500000,'target-jitter',rng,family,seq)
  rows.append(dict(traffic_class='TARGET',sequence=seq,time_ns=when))
 for seq in range(96):
  if family=='C_STAGGERED_BURSTS':
   # Four asymmetric waves. Both load modes preserve the 96 send opportunities.
   wave=seq//24;within=seq%24
   base=(0,98000000,219000000,353000000)[wave]
   delta=1700000 if load=='HEAVY' else 3600000
   when=cstart+base+within*delta+signed(140000,'cwave',rng,family,seq)
  else:
   # Eight compressed or expanded bursts with a ramp and deterministic jitter.
   wave=seq//12;within=seq%12
   base=wave*(43000000 if load=='HEAVY' else 69000000)
   delta=(1200000 if load=='HEAVY' else 3100000)+(wave//3)*120000
   when=cstart+base+within*delta+signed(170000,'dramp',rng,family,seq)
  rows.append(dict(traffic_class='INDEPENDENT_COMPETITOR',sequence=seq,time_ns=when))
 for r in rows:
  r.update(family=family,rng_block=rng,split=split,phase_label=f'P{phase}',phase_nominal_ns=offset,phase_jitter_ns=jitter,selected_slot=slot,load_level=load,schedule_schema=SCHEMA)
 rows.sort(key=lambda r:(r['time_ns'],r['traffic_class'],r['sequence']))
 assert len(rows)==108 and len({r['time_ns'] for r in rows if r['traffic_class']=='TARGET'})==12
 assert all(1800000000<int(r['time_ns'])<8000000000 for r in rows)
 return rows,tstart,cstart

def make():
 phases,loads,control=allocation()
 files={};index=[];matrix=[];split_rows=[];sites=[]
 for slot in range(3):
  for typ,(sender,dev,recv,rd) in zip(SITE_TYPES,PATHS[slot]):
   sites.append(dict(selected_slot=slot,intervention_location=typ,sender_node_id=sender,sender_device_index=dev,receiver_node_id=recv,receiver_device_index=rd,mapping_provenance='V0515_VALIDATED_V0517_UNCHANGED_V0518_OBSERVED',runtime_identity_crosscheck_required='YES'))
 files['INTERVENTION_SITES_LOCKED_12.csv']=encode_csv(sites,SITE_COLUMNS)
 for split,rngs in SPLITS.items():
  for rng in rngs:
   slot=(rng-rngs[0])%3;p=phases[rng];load=loads[rng];unmon_count=0
   for family in FAMILIES:
    rows,tstart,cstart=plan(rng,split,family,p,load)
    fn=f'plans/{split.lower()}/rng-{rng}_{family}.csv';raw=encode_csv(rows,SCHEDULE_COLUMNS);files[fn]=raw
    target_sha=sha(encode_csv([r for r in rows if r['traffic_class']=='TARGET'],SCHEDULE_COLUMNS));competitor_sha=sha(encode_csv([r for r in rows if r['traffic_class']=='INDEPENDENT_COMPETITOR'],SCHEDULE_COLUMNS))
    index.append(dict(split=split,rng_block=rng,selected_slot=slot,family=family,load_level=load,phase_label=f'P{p}',phase_nominal_ns=PHASE_MS[p]*1000000,phase_jitter_ns=rows[0]['phase_jitter_ns'],target_start_ns=tstart,competitor_start_ns=cstart,plan_filename=fn,schedule_sha256=sha(raw),target_schedule_sha256=target_sha,competitor_schedule_sha256=competitor_sha))
    for arm,loc,bps,loss in ARMS:
     receiver=PATHS[slot][3]
     loss_arm=(loss!=0)
     common=dict(split=split,rng_block=rng,seed=17,selected_slot=slot,family=family,load_level=load,phase_label=f'P{p}',arm=arm,intervention_location=loc,intervention_return_bps=bps,other_path_return_bps=50000000,forward_bps=50000000,loss_kind='RATE_ERROR_MODEL_RX' if loss_arm else 'NONE',loss_probability=f'{loss/100:.2f}',loss_stream=79,loss_receiver_node_id=receiver[2] if loss_arm else -1,loss_receiver_device_index=receiver[3] if loss_arm else -1,plan_filename=fn,schedule_sha256=sha(raw),target_schedule_sha256=target_sha,competitor_schedule_sha256=competitor_sha,status='PREREG_PLANNED_ZERO_EXECUTED')
     for instrumented in ((1,0) if control[(rng,family)]==arm else (1,)):
      matrix.append(dict(run_id=f'{split.lower()}-v0520-{rng}-{family}-{arm}-'+('mon' if instrumented else 'unmon'),instrumented=instrumented,**common))
      if not instrumented:unmon_count+=1
   assert unmon_count==2
   split_rows.append(dict(split=split,rng_block=rng,selected_slot=slot,phase_label=f'P{p}',phase_nominal_ns=PHASE_MS[p]*1000000,family_count=2,arm_count=8,monitored_run_count=16,unmonitored_run_count=2,access_rule='CALIBRATION_VISIBLE_FOR_LOCKED_GATE' if split=='CALIBRATION' else 'DO_NOT_RUN_OR_INSPECT_UNTIL_FROZEN_GATE'))
 files['SCHEDULE_INDEX_LOCKED_72.csv']=encode_csv(index,INDEX_COLUMNS)
 files['RUN_MATRIX_LOCKED_648.csv']=encode_csv(matrix,MATRIX_COLUMNS)
 files['RNG_SPLIT_LOCKED_36.csv']=encode_csv(split_rows,SPLIT_COLUMNS)
 assert len(index)==72 and len(matrix)==648 and len(split_rows)==36
 assert Counter(r['split'] for r in matrix)=={'CALIBRATION':216,'HELDOUT_CONFIRMATORY':432}
 assert Counter(r['instrumented'] for r in matrix)=={1:576,0:72}
 assert all(Counter(r['arm'] for r in matrix if r['split']==split and r['instrumented']==0)=={a[0]:3 if split=='CALIBRATION' else 6 for a in ARMS} for split in SPLITS)
 assert len({r['run_id'] for r in matrix})==648
 assert len({r['schedule_sha256'] for r in index})==72
 assert len({int(r['rng_block']) for r in matrix})==36
 meta=dict(schema=SCHEMA,status='PREREG_DRAFT_LOCK_ONLY_NO_NDNSIM',simulations_executed=0,parent_prereg_run_id='43242291541',parent_v0519_evidence_sha256='c0227688aa194f6056558ed571441fb6dae577038f9c524453143f039a59d251',planned_runs=648,calibration_runs=216,heldout_runs=432,monitored_runs=576,unmonitored_runs=72,independent_rng_blocks=36,calibration_rng_blocks=12,heldout_rng_blocks=24,simulator_code_status='NOT_IMPLEMENTED_AND_NOT_TESTED',predictor_code_status='NOT_FROZEN',scientific_construct='CANDIDATE_FUTURE_PATH_QUEUE_DROP_75MS',scientific_gates=SCIENCE)
 files['LOCK_META.json']=(json.dumps(meta,indent=2,sort_keys=True,ensure_ascii=False)+'\n').encode()
 return files

def verify(root):
 root=Path(root);expected=make();different=[]
 for n,b in expected.items():
  p=root/n
  if not p.is_file() or p.read_bytes()!=b:different.append(n)
 if different:raise RuntimeError('PREREG_FILES_MISMATCH:'+repr(different[:15]))
 rows=list(csv.DictReader((root/'RUN_MATRIX_LOCKED_648.csv').read_text().splitlines()))
 idx=list(csv.DictReader((root/'SCHEDULE_INDEX_LOCKED_72.csv').read_text().splitlines()))
 split=list(csv.DictReader((root/'RNG_SPLIT_LOCKED_36.csv').read_text().splitlines()))
 assert len(rows)==648 and len(idx)==72 and len(split)==36
 for r in idx:
  assert sha((root/r['plan_filename']).read_bytes())==r['schedule_sha256']
 assert set(x['rng_block'] for x in rows if x['split']=='CALIBRATION').isdisjoint(set(x['rng_block'] for x in rows if x['split']=='HELDOUT_CONFIRMATORY'))
 return {'status':'PASS_V0520_PREREG_DESIGN_ONLY_NO_NDNSIM','run_matrix_sha256':sha((root/'RUN_MATRIX_LOCKED_648.csv').read_bytes()),'schedule_index_sha256':sha((root/'SCHEDULE_INDEX_LOCKED_72.csv').read_bytes()),'splits_sha256':sha((root/'RNG_SPLIT_LOCKED_36.csv').read_bytes()),'total_runs':648,'calibration_runs':216,'heldout_runs':432,'monitored_runs':576,'unmonitored_runs':72,'rng_blocks':36,'simulations_executed':0}

if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--write',type=Path);a.add_argument('--verify',type=Path);args=a.parse_args()
 if bool(args.write)==bool(args.verify):a.error('Exactly one of --write or --verify')
 if args.write:
  for n,b in make().items():
   p=args.write/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
  print(json.dumps(verify(args.write),sort_keys=True))
 else:print(json.dumps(verify(args.verify),sort_keys=True))
