#!/usr/bin/env python3
"""Read-only causal replay of SHA-locked P12X and P12Y real physical diagnostics.
No simulation, model fit, AP, official labels or confirmation partition permitted.
"""
import argparse, hashlib, json, pathlib, zipfile

ROOT = pathlib.Path(__file__).resolve().parents[3]
SEAL = pathlib.Path(__file__).resolve().parents[1] / 'docs/1AM/F3_P12Z/P12Z_FROZEN_EXTERNAL_ARTIFACT_FILE_HASHES_v05245.json'
WINDOW_NS = 75_000_000


def need(ok, label):
    if not ok:
        raise RuntimeError('P12Z_' + label)


def sha(b):
    return hashlib.sha256(b).hexdigest()


class Artifact:
    def __init__(self, source):
        self.source = pathlib.Path(source)
        need(self.source.exists(), 'ARTIFACT_NOT_FOUND')
        self.z = zipfile.ZipFile(self.source) if self.source.is_file() else None
        if self.z:
            need(self.z.testzip() is None, 'CORRUPT_ZIP')

    def files(self):
        if self.z:
            return set(self.z.namelist())
        return {p.relative_to(self.source).as_posix() for p in self.source.rglob('*') if p.is_file()}

    def get(self, name):
        if self.z:
            return self.z.read(name)
        need('..' not in pathlib.PurePosixPath(name).parts and not name.startswith('/'), 'UNSAFE_PATH')
        return (self.source / name).read_bytes()

    def json(self, name):
        return json.loads(self.get(name))

    def jsonl(self, name):
        return [json.loads(line) for line in self.get(name).decode('utf-8').splitlines() if line.strip()]


def verify_files(a, manifest):
    files = a.files()
    need(files == set(manifest), 'EXTRA_OR_MISSING_ARTIFACT_FILES')
    for name, expected in manifest.items():
        need(sha(a.get(name)) == expected, 'ARTIFACT_FILE_HASH_MISMATCH:' + name)
    return len(files)


def integrity_decisions(a, probe):
    native = a.jsonl(probe + '/p12v_native_local_12_at_decision.jsonl')
    base = a.jsonl(probe + '/p12t_native_local_at_decision.jsonl')
    need(len(native) == len(base) == 128, 'BAD_DECISION_COUNT')
    for index, (n, p) in enumerate(zip(native, base), 1):
        need(n['decision_id'] == p['decision_id'] == index, 'BAD_DECISION_ORDER')
        need(n['time_ns'] == p['time_ns'] and n['selected_face_id'] == p['selected_face_id'], 'BAD_CAUSAL_ALIGNMENT')
        need(n['node_id'] == 1, 'NOT_NODE1')
        v = n['b1_all_twelve_native']
        need(len(v) == 12, 'NOT_TWELVE_B1')
        need(v[:5] == p['b1_first_five_native'], 'FIRST_FIVE_CHANGED')
        need(n['F3_ready'] is False and n['GO_FREEZE'] is False and n['model_training_authorized'] is False, 'PREMATURE_GO')
    return native


def count_window(native, signals, name, column, face_scoped):
    valid = [e for e in signals if e['event'] == name]
    first_face = native[0]['selected_face_id']
    need(all(e.get('time_ns', 0) > 0 and e.get('face_id') == first_face for e in valid), 'WRONG_SIGNAL_FACE')
    observed = 0
    maxval = 0
    for r in native:
        t = r['time_ns']
        selected = r['selected_face_id']
        actual = sum(1 for e in valid if t - WINDOW_NS < e['time_ns'] <= t and (not face_scoped or e['face_id'] == selected))
        expected = r['b1_all_twelve_native'][column]
        need(actual == expected, 'LIVE_B1_WINDOW_COUNT_MISMATCH')
        if expected > 0:
            observed += 1
        maxval = max(maxval, expected)
    return {'native_events': len(valid), 'decisions_with_positive_75ms_feature': observed, 'feature_max': maxval}


def science_guard(receipt):
    for k in ('F3_ready', 'GO_FREEZE', 'training_ready', 'new_AP_computed'):
        need(receipt[k] is False, 'SCIENCE_LOCK:' + k)
    for k in ('confirmation_seed_reads', 'heldout_reads', 'model_fits'):
        need(receipt[k] == 0, 'PARTITION_LOCK:' + k)
    need(receipt['Congestion'] is None and receipt['FutureCongestion'] is None, 'CONSTRUCT_STILL_NULL')


def audit(x, y):
    x_root = x.json('P12X_NEGATIVE_PATH_COVERAGE_RECEIPT_v05243.json')
    y_root = y.json('P12Y_LP_RELIABILITY_EXHAUSTION_RECEIPT_v05244.json')
    science_guard(x_root)
    science_guard(y_root)
    need(x_root['status'] == 'PASS_P12X_TWO_EXPLORATORY_PHYSICAL_PROBES_EXECUTED_NOT_F3_VALIDATION', 'BAD_X_RECEIPT')
    need(y_root['status'] == 'PASS_P12Y_EXPLORATORY_LP_PHYSICAL_PROBES_ONLY_NOT_F3_RELEASE', 'BAD_Y_RECEIPT')
    need(len(x_root['probes']) == len(y_root['probes']) == 2, 'BAD_PROBE_COUNTS')
    for p in x_root['probes'] + y_root['probes']:
        science_guard(p)
        need(p['native_128_decisions'] == 128 if 'native_128_decisions' in p else p['native_decisions'] == 128, 'NOT_128')
    n = integrity_decisions(x, 'NACK_NO_ROUTE')
    sig = x.jsonl('NACK_NO_ROUTE/p12x_live_nfd_negative_signals.jsonl')
    need(all(e['event'] == 'NFD_NATIVE_NACK_IN' for e in sig), 'UNEXPECTED_NACK_PROBE_SIGNAL')
    nack = count_window(n, sig, 'NFD_NATIVE_NACK_IN', 7, False)
    need(nack['native_events'] == 128 and nack['decisions_with_positive_75ms_feature'] > 0, 'NOT_PHYSICAL_NACK')
    fail_x = integrity_decisions(x, 'L2_DROP_PRESSURE')
    x_pressure = x.json('L2_DROP_PRESSURE/P12X_PROBE_PHYSICAL_DIAGNOSTIC_v05243.json')
    need(x_pressure['physical_local_link_layer_queue_drop_frames'] == 2791 and x_pressure['physical_NFD_native_InterestDrop_events'] == 0, 'FALSE_L2_EQUALS_NFD_DROP')
    need(len(x.jsonl('L2_DROP_PRESSURE/p12x_live_nfd_negative_signals.jsonl')) == 0, 'L2_HAS_NATIVE_DROPS')
    need(len(fail_x) == 128, 'BAD_L2_DECISIONS')
    y_control = integrity_decisions(y, 'LP_RELIABILITY_NO_LOSS')
    y_loss = integrity_decisions(y, 'LP_RELIABILITY_RX_LOSS')
    for probe, rows in (('LP_RELIABILITY_NO_LOSS', y_control), ('LP_RELIABILITY_RX_LOSS', y_loss)):
        opts = y.json(probe + '/p12y_lp_face_options_runtime.json')
        need(opts['node1_LP_reliability_enabled'] is True and opts['relay_LP_reliability_enabled'] is True, 'LP_NOT_ENABLED')
        need(opts['LP_max_retx_on_both_faces'] == 1 and opts['NFD_onDroppedInterest_not_injected'] is True, 'FALSE_DROP_SIGNAL')
        need(opts['node1_face_id'] == rows[0]['selected_face_id'], 'LP_SELECTED_FACE_DIFFERS')
        need(opts['diagnostic_only_not_P12R'] is True, 'MIXED_PARTITION')
    need(len(y.jsonl('LP_RELIABILITY_NO_LOSS/p12y_live_nfd_negative_signals.jsonl')) == 0, 'FALSE_CONTROL_DROPS')
    native = y.jsonl('LP_RELIABILITY_RX_LOSS/p12y_live_nfd_negative_signals.jsonl')
    need(all(e['event'] == 'NFD_NATIVE_INTEREST_DROP' for e in native), 'NONNATIVE_DROP_SIGNAL')
    drop = count_window(y_loss, native, 'NFD_NATIVE_INTEREST_DROP', 9, True)
    faults = y.jsonl('LP_RELIABILITY_RX_LOSS/fault_events.jsonl')
    need(all(f['event'] == 'PHY_RX_DROP' for f in faults) and len(faults) == 5656, 'PHYSICAL_RECEIVER_LOSS_MISMATCH')
    need(drop['native_events'] == 128 and drop['decisions_with_positive_75ms_feature'] > 0, 'NOT_PHYSICAL_DROP')
    need(x_root['can_train'] is False and y_root['may_not_train_on_any_diagnostic_data'] is True, 'TRAINING_FORBIDDEN')
    return {
        'status': 'PASS_P12Z_CAUSAL_NATIVE_NEGATIVE_PATH_WITNESS_ONLY_NO_F3_RELEASE',
        'P12X_parent_run': 45879957294, 'P12Y_parent_run': 45939975523,
        'native_Nack': nack, 'native_Drop': drop,
        'L2_queue_drops_without_native_drop': 2791,
        'receiver_phy_drops_under_diagnostic_LP': len(faults),
        'original_P12R_dev_case_executed': False,
        'experimental_conditions_match_frozen_P12R': False,
        'diagnostic_evidence_not_trainable': True,
        'P12R_development_cases_completed_this_stage': 0,
        'P12R_confirmation_cases_completed_this_stage': 0,
        'model_fits': 0, 'new_AP_computed': False,
        'F3_ready': False, 'GO_FREEZE': False, 'training_ready': False,
        'heldout_release_authorized': False, 'Stage1AO_or_NSGAIII_authorized': False,
        'Congestion': None, 'FutureCongestion': None,
        'next_scientific_gate': 'Implement original-condition six-seed 72-case P12R development; verify fair B1 and remote telemetry, then freeze fixed B1/R models before any independent confirmation.'
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--p12x', required=True)
    p.add_argument('--p12y', required=True)
    p.add_argument('--output', required=True)
    args = p.parse_args()
    seal = json.loads(SEAL.read_text())
    x, y = Artifact(args.p12x), Artifact(args.p12y)
    verify_files(x, seal['P12X']['files'])
    verify_files(y, seal['P12Y']['files'])
    receipt = audit(x, y)
    target = pathlib.Path(args.output)
    need(not target.exists(), 'REFUSE_RECEIPT_OVERWRITE')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(receipt, ensure_ascii=False, indent=2, sort_keys=True) + '\n')
    print(receipt['status'])
    print('NACK', receipt['native_Nack'])
    print('DROP', receipt['native_Drop'])


if __name__ == '__main__':
    main()
