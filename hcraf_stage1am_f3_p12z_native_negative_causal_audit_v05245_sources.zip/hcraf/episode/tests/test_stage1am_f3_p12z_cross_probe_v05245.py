"""P12Z guard tests; uses ONLY original frozen physical artifact files."""
import copy, importlib.util, json, os, pathlib, tempfile, unittest

SCRIPT = pathlib.Path(__file__).resolve().parents[1] / 'scripts/audit_stage1am_f3_p12z_cross_probe_v05245.py'
spec = importlib.util.spec_from_file_location('p12z_forensic_audit', SCRIPT)
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)


class P12Z(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.x = audit.Artifact(os.environ['P12Z_X'])
        cls.y = audit.Artifact(os.environ['P12Z_Y'])
        cls.x_rows = cls.x.jsonl('NACK_NO_ROUTE/p12v_native_local_12_at_decision.jsonl')
        cls.y_rows = cls.y.jsonl('LP_RELIABILITY_RX_LOSS/p12v_native_local_12_at_decision.jsonl')
        cls.x_events = cls.x.jsonl('NACK_NO_ROUTE/p12x_live_nfd_negative_signals.jsonl')
        cls.y_events = cls.y.jsonl('LP_RELIABILITY_RX_LOSS/p12y_live_nfd_negative_signals.jsonl')

    def test_real_physical_nack_count(self):
        self.assertEqual(len(self.x_events), 128)

    def test_real_physical_drop_count(self):
        self.assertEqual(len(self.y_events), 128)

    def test_b1_nack_75ms_replay(self):
        s = audit.count_window(self.x_rows, self.x_events, 'NFD_NATIVE_NACK_IN', 7, False)
        self.assertEqual((s['native_events'], s['decisions_with_positive_75ms_feature']), (128, 109))

    def test_b1_drop_75ms_replay(self):
        s = audit.count_window(self.y_rows, self.y_events, 'NFD_NATIVE_INTEREST_DROP', 9, True)
        self.assertEqual((s['native_events'], s['decisions_with_positive_75ms_feature']), (128, 17))

    def test_no_loss_control_has_no_drop(self):
        self.assertEqual(len(self.y.jsonl('LP_RELIABILITY_NO_LOSS/p12y_live_nfd_negative_signals.jsonl')), 0)

    def test_l2_queue_drop_not_aliased_as_native(self):
        p = self.x.json('L2_DROP_PRESSURE/P12X_PROBE_PHYSICAL_DIAGNOSTIC_v05243.json')
        self.assertEqual((p['physical_local_link_layer_queue_drop_frames'], p['physical_NFD_native_InterestDrop_events']), (2791, 0))

    def test_no_confirmation_or_model(self):
        receipt = audit.audit(self.x, self.y)
        self.assertFalse(any(receipt[k] for k in ('training_ready', 'F3_ready', 'GO_FREEZE', 'new_AP_computed', 'Stage1AO_or_NSGAIII_authorized')))
        self.assertTrue(receipt['diagnostic_evidence_not_trainable'])

    def test_missing_signal_not_interpreted_as_complete(self):
        self.assertGreater(len(self.x_events), 0)
        with self.assertRaisesRegex(RuntimeError, 'P12Z_LIVE_B1_WINDOW_COUNT_MISMATCH'):
            audit.count_window(self.x_rows, [], 'NFD_NATIVE_NACK_IN', 7, False)

    def test_drop_wrong_face_rejected(self):
        corrupted = copy.deepcopy(self.y_events)
        corrupted[0]['face_id'] = 999
        with self.assertRaisesRegex(RuntimeError, 'P12Z_WRONG_SIGNAL_FACE'):
            audit.count_window(self.y_rows, corrupted, 'NFD_NATIVE_INTEREST_DROP', 9, True)

    def test_mutated_nack_feature_rejected(self):
        corrupted = copy.deepcopy(self.x_rows)
        corrupted[11]['b1_all_twelve_native'][7] += 1
        with self.assertRaisesRegex(RuntimeError, 'P12Z_LIVE_B1_WINDOW_COUNT_MISMATCH'):
            audit.count_window(corrupted, self.x_events, 'NFD_NATIVE_NACK_IN', 7, False)

    def test_mutated_drop_feature_rejected(self):
        corrupted = copy.deepcopy(self.y_rows)
        corrupted[66]['b1_all_twelve_native'][9] += 1
        with self.assertRaisesRegex(RuntimeError, 'P12Z_LIVE_B1_WINDOW_COUNT_MISMATCH'):
            audit.count_window(corrupted, self.y_events, 'NFD_NATIVE_INTEREST_DROP', 9, True)

    def test_mutated_decision_time_rejected(self):
        corrupted = copy.deepcopy(self.y_rows)
        corrupted[20]['time_ns'] -= 1
        source = self.y.jsonl('LP_RELIABILITY_RX_LOSS/p12t_native_local_at_decision.jsonl')
        self.assertNotEqual(corrupted[20]['time_ns'], source[20]['time_ns'])

    def test_require_real_LP_configuration(self):
        opts = self.y.json('LP_RELIABILITY_RX_LOSS/p12y_lp_face_options_runtime.json')
        self.assertTrue(opts['node1_LP_reliability_enabled'] and opts['relay_LP_reliability_enabled'])
        self.assertEqual(opts['LP_max_retx_on_both_faces'], 1)
        self.assertTrue(opts['diagnostic_only_not_P12R'])

    def test_mutated_science_lock_rejected(self):
        p = self.y.json('P12Y_LP_RELIABILITY_EXHAUSTION_RECEIPT_v05244.json')
        p['F3_ready'] = True
        with self.assertRaisesRegex(RuntimeError, 'P12Z_SCIENCE_LOCK:F3_ready'):
            audit.science_guard(p)

    def test_original_partitions_unchanged(self):
        p = self.x.json('P12X_NEGATIVE_PATH_COVERAGE_RECEIPT_v05243.json')
        q = self.y.json('P12Y_LP_RELIABILITY_EXHAUSTION_RECEIPT_v05244.json')
        self.assertTrue(p['can_train'] is False)
        self.assertTrue(q['may_not_train_on_any_diagnostic_data'])


if __name__ == '__main__': unittest.main()
