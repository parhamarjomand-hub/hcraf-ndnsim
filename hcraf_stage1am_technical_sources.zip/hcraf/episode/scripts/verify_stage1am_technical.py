#!/usr/bin/env python3
"""Fail-closed 1AM technical NFD/ndnSIM pilot evidence audit.

Labels intentionally null. Only verifies that each NFD decision has three *local*
physical Queue snapshots taken before actual forwarding and cost sampled inside
NFD's forwarding dispatch. No remote telemetry/online congestion is claimed.
"""
import argparse, json
from pathlib import Path
from collections import Counter, defaultdict

ARMS={
 'OFF_5M':(0,0),
 'ON_5M_SYNC':(12,0),
 'OFF_5M_TARGET_LAG_6MS':(0,6_000_000),
 'ON_5M_TARGET_LAG_6MS':(12,6_000_000),
}
SEEDS=(9401,9402,9403)

class EvidenceError(RuntimeError):pass

def check(expr,msg):
    if not expr:raise EvidenceError(msg)

def records(p):
    p=Path(p)
    check(p.is_file(),'Missing required file '+str(p))
    return [json.loads(t) for t in p.read_text().splitlines() if t.strip()]

def one_index(rows,key):
    keys=[x[key] for x in rows]
    check(len(set(keys))==len(keys),'Duplicate '+key)
    return {x[key]:x for x in rows}

def audit(folder, expected_arm):
    p=Path(folder)
    cfg=json.loads((p/'scenario.json').read_text())
    check(expected_arm in ARMS and cfg['phase_arm']==expected_arm,'Unregistered 1AM technical arm')
    ncomp,offset=ARMS[expected_arm]
    check(cfg.get('collector_stage')=='1AM.NFD_LOCAL_QUEUE.0' and
          cfg.get('amendment_stage')=='1AM.TECHNICAL.ONLINE_PILOT.0','Wrong stage provenance')
    check(cfg.get('topology_id')=='DEV_CHAIN_B' and cfg.get('selected_face_slot')==0 and
          cfg.get('selected_face_id')==cfg.get('eligible_face_ids',[None])[0] and
          len(set(cfg.get('eligible_face_ids',[])))==3,'Incorrect real candidate map')
    check(cfg.get('run') in SEEDS and cfg.get('seed')==17 and
          cfg.get('planned_requests')==12 and cfg.get('interest_lifetime_ms')==2600 and
          cfg.get('nominal_arrival_interval_ns')==250_000_000 and
          cfg.get('selected_return_bps')==5_000_000 and
          cfg.get('competitor_planned_requests')==ncomp and
          cfg.get('target_offset_ns')==offset and cfg.get('competitor_offset_ns')==0 and
          cfg.get('instrument_enabled') is True and cfg.get('actual_assignment_probability')==1.0,
          'Not the preregistered development experiment')
    check(cfg.get('local_NFD_queue_observed_before_send') is True and
          cfg.get('NFD_dispatch_wall_CPU_measured') is True and
          cfg.get('remote_queue_online_feature') is False and
          cfg.get('NFD_cost_includes_recorder') is True,
          'Missing explicit telemetry boundary')
    for k in ('congestion','future_congestion','decision_time_us_real_HCRAF'):
        check(cfg.get(k) is None,'Forbidden pseudo-online outcome: '+k)
    check(cfg.get('F3_ready') is False and cfg.get('training_ready') is False and
          cfg.get('no_counterfactual_unselected_face') is True,'Forbidden final F3 claims')
    decisions=records(p/'events.jsonl.decisions.jsonl')
    states=records(p/'events.jsonl.states.jsonl')
    events=records(p/'events.jsonl')
    physical=records(p/'link_events.jsonl')
    locals_=records(p/'nfd_local_queue_at_decision.jsonl')
    costs=records(p/'nfd_dispatch_cost.jsonl')
    count=12+ncomp
    check(len(decisions)==len(costs)==count and len(states)==len(locals_)==3*count,
          'One NFD decision must have exactly 3 candidate snapshots and 1 C++ timing')
    d_byid=one_index(decisions,'decision_id');c_byid=one_index(costs,'decision_id')
    check(set(d_byid)==set(c_byid),'NFD cost must be linked to exactly one decision')
    face_ids=set(cfg['eligible_face_ids'])
    shots=defaultdict(list);srows=defaultdict(list)
    for q in locals_:
        check(q.get('schema')=='1AM.TECHNICAL.LOCAL_ONLY.0' and
              q.get('observed_before_forwarding') is True and
              q.get('node_id')==1 and
              q.get('remote_node_queue_accessed') is False and
              q.get('future_pressure_label') is None and q.get('Congestion') is None,
              'Future/remote evidence leaked into NFD live snapshot')
        shots[q['decision_id']].append(q)
    for q in states:srows[q['decision_id']].append(q)
    init={(e['node_id'],e['face_id']):e for e in physical if e.get('event_type')=='INITIAL'}
    snapshot={(e['decision_id'],e['face_id']):e for e in physical
              if e.get('event_type')=='DECISION_SNAPSHOT' and e.get('node_id')==1}
    check(len(snapshot)==3*count,'Missing real physical local monitor crosscheck')
    tx_byname=defaultdict(list)
    for e in events:
        if e.get('event_type')=='TX_INTEREST':tx_byname[e['name']].append(e)
    all_ids=set()
    for id_,d in d_byid.items():
        check(d.get('node_id')==1 and d.get('anchor')=='BEFORE_AFTER_RECEIVE_INTEREST' and
              d.get('name','').startswith(('/hcraf/pilot/','/hcraf/competitor/')),
              'NFD decision outside intended PIT scope')
        real_fib={x['face_id'] for x in d['candidates']}
        check(real_fib==face_ids and len(d['candidates'])==3,'Invalid NFD FIB Face coverage')
        check(len(shots[id_])==len(srows[id_])==3,'Missing Face candidate per decision')
        check({x['candidate_face_id'] for x in shots[id_]}==face_ids and
              {x['face_id'] for x in srows[id_]}==face_ids,'Missing/duplicated candidates')
        ts=d['time_ns']
        for x in shots[id_]:
            face=x['candidate_face_id']
            check(x['sim_time_ns']==ts,'Snapshot accessed AFTER decision time')
            check((1,face) in init,'Candidate not mapped to local real NetDevice')
            initial=init[(1,face)]
            check(x['device_index']==initial['device_index'] and
                  x['data_rate_bps']==initial['data_rate_bps'],
                  'NFD candidate/physical device mismatch')
            check(type(x['queue_packets'])==int and type(x['capacity_packets'])==int and
                  0<=x['queue_packets']<=x['capacity_packets']==20 and
                  x['queue_bytes']>=0 and
                  abs(x['local_queue_occupancy_fraction']-x['queue_packets']/20)<1e-9,
                  'Invalid online local physical occupancy')
            physical_shot=snapshot.get((id_,face))
            check(physical_shot is not None and physical_shot['time_ns']==ts and
                  physical_shot['queue_packets']==x['queue_packets'] and
                  physical_shot['queue_bytes']==x['queue_bytes'],
                  'Independent physical monitor disagrees with actual NFD local queue')
        for state in srows[id_]:
            check(state['time_ns']==ts and state['after_event_seq']==d['after_event_seq'] and
                  state['max_terminal_event_seq']<=d['after_event_seq'] and
                  state['Congestion'] is None,
                  'Future NFD state evidence leaked into snapshot')
        tx=tx_byname[d['name']]
        check(len(tx)==1 and tx[0]['face_id']==cfg['selected_face_id'] and
              tx[0]['time_ns']>=ts and tx[0]['event_seq']>d['after_event_seq'] and
              tx[0]['pit_instance_id']==d['pit_instance_id'],
              'No actual post-snapshot NFD Interest forwarding on selected Face')
        c=c_byid[id_]
        check(type(c['NFD_forwarding_path_wall_ns'])==int and
              c['NFD_forwarding_path_wall_ns']>0 and
              type(c['NFD_forwarding_path_cpu_ns'])==int and
              c['NFD_forwarding_path_cpu_ns']>=0 and
              c.get('includes_telemetry_and_recorder') is True and
              c.get('is_HCRAF_Gate_only_cost') is False,
              'Invalid C++ dispatch wall/CPU measurement or inflated gate-cost claim')
        check(id_ not in all_ids,'Duplicate PIT decision')
        all_ids.add(id_)
    # The expected physical universe is 14 directed interfaces; never infer remote queues from local shots.
    check(len({(e['node_id'],e['device_index']) for e in physical if e['event_type']=='INITIAL'})==14,
          'Partial physical trace coverage')
    drops=[e for e in physical if e['event_type']=='QUEUE_DROP']
    result={'stage':'1AM.TECHNICAL.ONLINE_PILOT.0','arm':expected_arm,'rng_run':cfg['run'],
        'status':'PASS_NFD_LOCAL_SNAPSHOT_AND_DISPATCH_MEASUREMENT' if not drops else 'UNKNOWN_DROPS_REQUIRES_CLASS_ATTRIBUTION',
        'NFD_decisions':count,'NFD_local_queue_candidate_rows':3*count,
        'C++_NFD_dispatch_timing_rows':count,'queue_drop_events':len(drops),
        'max_dispatch_wall_ns':max(x['NFD_forwarding_path_wall_ns'] for x in costs),
        'max_dispatch_cpu_ns':max(x['NFD_forwarding_path_cpu_ns'] for x in costs),
        'GO_FREEZE':False,'Congestion':None,'FutureCongestion':None,
        'F3_ready':False,'training_ready':False,
        'measured_latency_scope':'NFD forwarding dispatch incl. recorder; not HCRAF Cost/Reward/Gate'}
    (p/'stage1am_technical_verification.json').write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    return result

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('directory');a.add_argument('--arm',required=True,choices=sorted(ARMS))
    args=a.parse_args()
    print(json.dumps(audit(args.directory,args.arm),sort_keys=True))
