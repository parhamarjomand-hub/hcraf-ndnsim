import unittest,os,pathlib,tempfile,subprocess,csv,io,json,shutil
import confirm as c
import repair68 as f
P=pathlib.Path
class RepairTests(unittest.TestCase):
 def test_source(self):
  b=f.NATIVE.read_bytes();self.assertEqual(f.sha(b),f.CPP_SHA);self.assertNotIn(b'PILOT_DEV_ONLY',b);self.assertLess(b.index(b'CONFIRMATION_ONLY'),b.index(b'RngSeedManager::SetRun'));self.assertLess(b.index(b'if(contractCheck)'),b.index(b'RngSeedManager::SetRun'))
 def test_old_artifacts(self):
  folder=os.environ.get('RECOVERY_TEST_DIR')
  if folder:self.assertEqual(f.verify_failures(P(folder),P(os.environ['P12R66_PREREG']))['simulations_started'],0)
  else:self.assertEqual(len(f.FAILURES),6)
 def test_exact_native_guard_all_matrix(self):
  cases,sch,_=c.load_prereg(P(os.environ['P12R66_PREREG']));cpp=f.NATIVE.read_text();guard=next(x for x in cpp.splitlines() if 'unsigned start=seed' in x);parser=cpp[cpp.index('struct HcrafP12R66ScheduleEntry'):cpp.index('namespace ns3 {')];src='#include <iostream>\n#include <array>\n#include <set>\n#include <vector>\n#include <fstream>\n#include <sstream>\n#include <algorithm>\n#include <stdexcept>\n#include <cstdint>\nusing U=uint64_t;static void need(bool x,const char*m){if(!x)throw std::runtime_error(m);}\n'+parser+'\nint main(){U seed;unsigned target,rate,loss,delay,trafficStream,errorStream,streamBase;std::string site,arm,schedule;while(std::cin>>seed>>site>>arm>>target>>rate>>loss>>delay>>trafficStream>>errorStream>>streamBase>>schedule){try{'+guard+'auto plan=readPlan(schedule);std::cout<<"OK\\n";}catch(const std::exception& e){std::cout<<e.what()<<"\\n";}}}'
  with tempfile.TemporaryDirectory() as td:
   d=P(td);(d/'test.cpp').write_text(src);subprocess.check_call(['g++','-std=c++14',str(d/'test.cpp'),'-o',str(d/'test')]);lines=[];expected=[]
   for r in cases:
    seed=int(r['seed']);site=r['site'];p=d/f'{seed}_{site}.csv'
    with p.open('w',newline='') as q:w=csv.writer(q,lineterminator='\n');w.writerow(('decision_index','decision_ns','selected_slot','cost_slot0','cost_slot1','cost_slot2'));w.writerows(sch[seed,site])
    row=[r[k] for k in ('seed','site','arm','target_slot','background_mbps','error_ppm','extra_propagation_ms','traffic_stream','error_stream','stream_base')]+[str(p)];lines.append(' '.join(row));expected.append('OK')
   for seed in (0,640001,640003,640101,640112,640200,640237,640999):
    z=row.copy();z[0]=str(seed);lines.append(' '.join(z));expected.append('CONFIRMATION_ONLY')
   for idx,val,err in [(1,'other','SITE'),(2,'F','CONFIRMATION_ONLY'),(3,'3','CONFIRMATION_ONLY'),(4,'99','ARM'),(5,'123','ARM'),(6,'99','ARM'),(7,'0','MATRIX_STREAM_SLOT'),(8,'0','MATRIX_STREAM_SLOT'),(9,'0','MATRIX_STREAM_SLOT')]:
    z=row.copy();z[idx]=val;lines.append(' '.join(z));expected.append(err)
   res=subprocess.check_output([str(d/'test')],input='\n'.join(lines)+'\n',text=True).splitlines();self.assertEqual(res,expected)
