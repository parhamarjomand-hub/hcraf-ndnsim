# بسته افزایشی HCRAF F3 Return Matched Controls — v0.49.0

**نه اجرای شبیه‌سازی، نه تأیید F3؛ فقط کد جدید، پروتکل قفل‌شده Development و آزمون‌های محلی.**

برای راهنمای نصب، قبل از اجرا فایل `hcraf/episode/docs/1AM/F3_RETURN_MATCHED_DEV_v0.49/README_FA.md` و سپس `PREREGISTRATION_FA.md` را بخوانید. این بسته به‌صورت غیرمخرب و با مسیر نسبی از ریشه Repository ساخته شده است.

۷۲ اجرای فقط Development: `3 reverse rates × 3 selected slots × 4 fresh RNG runs × 2 instrumentation states`. هیچ I/J یا Run موفق 42489775274 تکرار نمی‌شود. Version 0.49.0 صرفاً شناسه بسته کد جدید است، نه نتیجه اجرای GitHub.

```json
{"Congestion":null,"FutureCongestion":null,"F3_ready":false,"GO_FREEZE":false,"training_ready":false}
```
