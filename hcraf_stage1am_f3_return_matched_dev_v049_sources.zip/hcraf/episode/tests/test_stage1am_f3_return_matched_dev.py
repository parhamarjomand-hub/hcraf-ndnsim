import copy
import importlib.util
import json
import pathlib
import shutil
import tempfile
import unittest

ROOT=pathlib.Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('matched',ROOT/'scripts/verify_stage1am_f3_return_matched_dev.py')
M=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)

class ContractTests(unittest.TestCase):
  def sample_config(self,arm='RETURN_STRESSED_6M',slot=0,run=11421,monitored=True):
    return {'topology_id':'DEV_CHAIN_K','holdout_partition':'DEVELOPMENT',
      'amendment_stage':'1AM.F3_RETURN_MATCHED_DEV.0',
      'purpose':'RETURN_MATCHED_DEV_EXPLORATION_NOT_HCRAF_POLICY',
      'phase_arm':arm,'selected_face_slot':slot,'run':run,'seed':17,
      'instrument_enabled':monitored,'selected_forward_bps':50_000_000,
      'selected_relay_forward_bps':50_000_000,'selected_mid_forward_bps':50_000_000,
      'selected_return_bps':50_000_000,
      'selected_producer_reverse_bps':M.ARMS[arm],
      'matched_rate_only_manipulated_parameter':'selected_producer_reverse_bps',
      'candidate_negative_control_is_not_scientific_label':True,
      'competitor_planned_requests':96,'competitor_interval_ns':2_000_000,
      'competitor_offset_ns':0,'target_offset_ns':30_000_000,
      'planned_requests':12,'nominal_arrival_interval_ns':30_000_000,
      'interest_lifetime_ms':2600,'queue_capacity_packets':20,
      'mtu_bytes':600,'payload_bytes':4096,'network_node_count':11,
      'network_directed_device_count':20,'stop_ns':M.STOP,
      'competitor_pulse_count':2,'competitor_burst_start_rng_stream':139,
      'target_schedule_rng_stream':129,'Congestion':None,'FutureCongestion':None,
      'congestion':None,'future_congestion':None,'F3_ready':False,
      'GO_FREEZE':False,'training_ready':False,'future_oracle_is_final_F3':False,
      'remote_queue_online_feature':False,'no_counterfactual_unselected_face':True,
      'actual_assignment_probability':1.0,
      'selected_producer_node_id':[8,9,10][slot],
      'selected_mid_node_id':[7,6,5][slot],
      'local_NFD_queue_observed_before_send':monitored,
      'NFD_dispatch_wall_CPU_measured':monitored}

  def test_valid_config(self):
    for arm in M.ARMS:
      M.check_config(self.sample_config(arm),arm,0,11421,True)

  def test_rejects_old_test_rng(self):
    c=self.sample_config();c['run']=11321
    with self.assertRaises(M.AuditFailure):M.check_config(c,'RETURN_STRESSED_6M',0,11421,True)

  def test_forbidden_gates(self):
    for field,value in [('F3_ready',True),('GO_FREEZE',True),('training_ready',True),
                        ('FutureCongestion',0),('Congestion',1)]:
      c=self.sample_config();c[field]=value
      with self.subTest(field=field),self.assertRaises(M.AuditFailure):
        M.check_config(c,'RETURN_STRESSED_6M',0,11421,True)

  def test_wrong_rate_or_load_rejected(self):
    for field,value in [('selected_producer_reverse_bps',50_000_000),
                        ('selected_relay_forward_bps',12_000_000),
                        ('competitor_planned_requests',0),('payload_bytes',2048),
                        ('mtu_bytes',1200)]:
      c=self.sample_config();c[field]=value
      with self.subTest(field=field),self.assertRaises(M.AuditFailure):
        M.check_config(c,'RETURN_STRESSED_6M',0,11421,True)

  def write_jsonl(self,p,rows):
    p.write_text(''.join(json.dumps(x)+'\n' for x in rows))

  def make_case(self,root,arm='RETURN_STRESSED_6M',slot=0,run=11421,monitored=True,
                offset=0,drop=0):
    kind='monitored' if monitored else 'uninstrumented'
    p=root/'DEV_CHAIN_K'/f'slot-{slot}'/kind/arm/f'run-{run}'
    p.mkdir(parents=True,exist_ok=True)
    c=self.sample_config(arm,slot,run,monitored)
    (p/'scenario.json').write_text(json.dumps(c))
    for key,n,offset_time in [('consumer',12,30_000_000),('competitor',96,0)]:
      name='pilot' if key=='consumer' else 'competitor'
      records=[];arrivals=[]
      for i in range(n):
        t=2_000_000_000+offset_time+i*(30_000_000 if key=='consumer' else 2_000_000)+run*10+offset
        records.append({'event':'SEND','time_ns':t,'name':f'/hcraf/{name}/{i}',
                        'nonce':(1000 if key=='consumer' else 11000)+i})
        arrivals.append({'sequence':i,'time_ns':t})
      self.write_jsonl(p/(key+'_events.jsonl'),records)
      self.write_jsonl(p/(key+'_events.jsonl.arrivals.jsonl'),arrivals)
    (p/'resource_usage.txt').write_text('wall_seconds=1\n')
    if monitored:
      initial=[];final=[]
      for nid in range(20):
        rate=M.ARMS[arm] if nid==c['selected_producer_node_id'] else 50_000_000
        initial.append({'link_event_seq':nid+1,'event_type':'INITIAL','time_ns':0,
                        'node_id':nid,'device_index':0,'data_rate_bps':rate})
        final.append({'link_event_seq':nid+22,'event_type':'FINAL',
                      'time_ns':M.STOP,'node_id':nid,'device_index':0,
                      'queue_drop_packets_total':drop if nid==c['selected_producer_node_id'] else 0,
                      'queue_packets':0,'queue_bytes':0})
      event={'link_event_seq':21,'event_type':'QUEUE_DEQUEUE','time_ns':3_000_000_000,
             'node_id':c['selected_producer_node_id'],'device_index':0,'queue_wait_ns':1_000}
      data=initial+[event]+final
      if drop:
        for i in range(drop):
          data.insert(-20,{'event_type':'QUEUE_DROP','time_ns':4_000_000_000,
                           'node_id':c['selected_producer_node_id'],'device_index':0})
        for i,x in enumerate(data,1):x['link_event_seq']=i
      self.write_jsonl(p/'link_events.jsonl',data)
    return p

  def test_traffic_and_physical_diagnostics(self):
    with tempfile.TemporaryDirectory() as d:
      p=self.make_case(pathlib.Path(d),drop=2)
      cfg=M.json_file(p/'scenario.json')
      x=M.traffic(p)
      self.assertEqual(len(x['target']),12)
      r=M.pressure(p,cfg)
      self.assertEqual(r['reverse_drop_fragments'],2)
      self.assertEqual(r['control_status'],'UNADJUDICATED_NOT_A_NEGATIVE_LABEL')

  def test_broken_drop_counter_fails_closed(self):
    with tempfile.TemporaryDirectory() as d:
      p=self.make_case(pathlib.Path(d),drop=1)
      x=M.jsonl(p/'link_events.jsonl')
      next(e for e in x if e['event_type']=='FINAL' and e['node_id']==8)['queue_drop_packets_total']=0
      self.write_jsonl(p/'link_events.jsonl',x)
      with self.assertRaises(M.AuditFailure):M.pressure(p,M.json_file(p/'scenario.json'))

  def test_malformed_arrival_pair_fails(self):
    with tempfile.TemporaryDirectory() as d:
      p=self.make_case(pathlib.Path(d))
      f=p/'consumer_events.jsonl.arrivals.jsonl'
      x=M.jsonl(f);x[0]['time_ns']+=5
      self.write_jsonl(f,x)
      with self.assertRaises(M.AuditFailure):M.traffic(p)

  def test_incomplete_matrix_fails_closed(self):
    with tempfile.TemporaryDirectory() as d:
      with self.assertRaises(M.AuditFailure):M.audit(pathlib.Path(d),pathlib.Path(d)/'out')

  def test_full_synthetic_matrix_and_changed_send_fails(self):
    with tempfile.TemporaryDirectory() as d:
      root=pathlib.Path(d)/'runs'; out=pathlib.Path(d)/'out'
      for slot in M.SLOTS:
        for run in M.RUNS:
          for arm in M.ARMS:
            for flag in (True,False):self.make_case(root,arm,slot,run,flag)
      result=M.audit(root,out)
      self.assertEqual(result['matrix_total_runs'],72)
      self.assertEqual(result['negative_control_label'],'NOT_ASSIGNED')
      self.assertFalse(result['F3_ready'])
      p=root/'DEV_CHAIN_K/slot-0/monitored/RETURN_INTERMEDIATE_12M/run-11421/competitor_events.jsonl'
      x=M.jsonl(p);x[0]['time_ns']+=10
      self.write_jsonl(p,x)
      with self.assertRaises(M.AuditFailure):M.audit(root,out)

  def test_source_dev_isolated(self):
    source=(ROOT/'src/hcraf-stage1am-f3-return-matched-dev.cpp').read_text()
    self.assertIn('run<11421 || run>11424',source)
    self.assertIn('DEV_CHAIN_K',source)
    self.assertIn('6000000ULL',source)
    self.assertIn('12000000ULL',source)
    self.assertIn('50000000ULL',source)
    self.assertIn('GO_FREEZE',source)
    self.assertNotIn('TEST_CHAIN_J',source)
    self.assertNotIn('VAL_CHAIN_I',source)

if __name__=='__main__': unittest.main()
