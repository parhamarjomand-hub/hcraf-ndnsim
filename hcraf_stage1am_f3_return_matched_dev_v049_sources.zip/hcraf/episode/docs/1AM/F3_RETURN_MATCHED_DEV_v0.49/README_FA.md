# HCRAF — دستورالعمل مرحله تازه 1AM-F3-RETURN-MATCHED-CONTROLS v0.49.0

**وضعیت این بسته:** کد و پروتکل جدید آماده بررسی و اجرای Development؛ **هیچ شبیه‌سازی ndnSIM تازه اجرا نشده است.**

## نصب بدون تخریب نسخه قبلی

۱. از پروژه فعلی نسخه پشتیبان داشته باشید. ZIP افزایشی را از **ریشه Repository خصوصی** باز کنید. تنها فایل‌های **جدید** به `hcraf/episode/src/`, `scripts/`, `tests/`, `docs/` و `.github/workflows/` افزوده می‌شوند؛ فایل قدیمی v0.47.1 بازنویسی نمی‌شود.

۲. پرونده `PREREGISTRATION_FA.md` را قبل از هر اجرای ابری قفل و در Commit مستقل ثبت کنید. SHA-256 همین بسته را نیز ثبت کنید. پروژه اصلی باید آرشیو منابع `hcraf_stage1am_f3_mixed_sources.zip` و آرشیو مرجع مجاز stage1s داشته باشد (نام و هش داخل Workflow جدید کنترل می‌شود).

۳. Workflow **جدید و مجزا** با نام `HCRAF F3 Return Matched Controls DEV ONLY (v0.49.0)` را در GitHub Actions فقط بعد از بررسی Commit اجرا کنید. نام Workflow قدیمی v0.47.1 را انتخاب نکنید.

۴. خروجی GitHub Artifact را برای ممیزی واقعی مرحله بعد بارگذاری کنید. تا قبل از آن هیچ یافته‌ای درباره نرخ 50Mbps، ایجاد منفی یا عبور گیت F3 ادعا نکنید.

## کنترل محلی بدون ndnSIM

```bash
bash -n hcraf/episode/scripts/build_stage1am_f3_return_matched_dev.sh
bash -n hcraf/episode/scripts/run_stage1am_f3_return_matched_dev.sh
python3 -m unittest discover -s hcraf/episode/tests -p 'test_stage1am_f3_return_matched_dev.py' -v
```

در محیط واقعی و پس از آماده بودن ndnSIM، Workflow جدید ساخت C++ را انجام می‌دهد و ۷۲ شبیه‌سازی جدید (فقط DEV K) اجرا می‌کند. ابزار:

```bash
python3 hcraf/episode/scripts/verify_stage1am_f3_return_matched_dev.py \
  episode_output/stage1am_f3_return_matched_dev \
  --output episode_output/stage1am_f3_return_matched_report
```

ابزار به‌طور fail-closed وضعیت کامل‌بودن Matrix، تطابق برنامه‌ها، صحت شمارنده‌های فیزیکی و ۱۲ جفت Cluster را بررسی و `matched_dev_72_runs.csv`, `matched_dev_12_pairs.csv`, `summary.json` ایجاد می‌کند؛ هیچ Label رسمی تولید نمی‌کند.

## ممنوعیت‌ها

Workflow تاریخی Run ID `42489775274` دوباره اجرا نشود. برای 1AO، NSGA-III، نهایی‌کردن PR-AUC، یا قفل Gate از این بسته مجوزی صادر نمی‌شود.
