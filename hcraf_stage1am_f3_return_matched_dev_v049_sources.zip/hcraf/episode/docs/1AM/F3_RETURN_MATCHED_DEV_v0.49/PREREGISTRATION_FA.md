# HCRAF — پیش‌ثبت علمی مرحله 1AM-F3-RETURN-MATCHED-CONTROLS (v0.49.0)

**وضعیت:** پروتکل Development از پیش نوشته‌شده؛ این بسته هنوز روی ndnSIM اجرا نشده است. **F3: NO_GO**.

## پرسش و فرضیه

آیا با نگه‌داشتن برنامه واقعی ارسال Interest برای Target و Competitor، توپولوژی، مسیر، MTU، صف و بذر، **فقط تغییر نرخ دستگاه برگشت Producer→Mid** به‌صورت جفت‌شده شواهد فیزیکی Drop و انتظار صف را تغییر می‌دهد؟ این پرسش درباره Pressure فیزیکی است، نه لزوماً Data Loss مربوط به همان Target یا امکان پیش‌بینی آن با ویژگی آنلاین.

## ماتریس قفل‌شده Development

- توپولوژی فقط `DEV_CHAIN_K`؛ مسیر ۴ هاپ، ۱۱ گره، ۲۰ NetDevice جهت‌دار؛ permutation شاخه‌ها: Relay→Mid `[7,6,5]` و Mid→Producer `[8,9,10]`؛ تأخیر لینک‌های نخست 16ms، Relay→Mid 18ms، Mid→Producer 20ms.
- Face slot: `0,1,2` با FIB انتخاب اجباری؛ propensity رفتاری واقعی ۱ و نه ۱/۳.
- RNG: Seed=17 و RngRunهای `11421,11422,11423,11424`، **متمایز از I/J** و صرفاً Development. چهار اجرای RNG در هر slot، ۱۲ جفت Cluster؛ کافی برای نتیجه آماری نهایی نیستند.
- بازوهای نرخ فقط در دستگاه برگشت Producer→Mid: `RETURN_STRESSED_6M` = 6Mbps؛ `RETURN_INTERMEDIATE_12M` = 12Mbps؛ `RETURN_MATCHED_HIGH_CAPACITY_50M` = 50Mbps.
- سایر دستگاه‌های مرتبط روی مسیر منتخب 50Mbps؛ MTU=600 bytes، صف DropTail با ظرفیت 20 packet؛ 4096-byte payload.
- Target: ۱۲ Interest از t≈2.03s با فاصله پایه 30ms و Stream=129، عمر 2600ms.
- Competitor: **۹۶ Interest** در دو پالس ۴۸تایی، فاصله 2ms و آغاز تصادفی با Stream=139؛ همان کد تولید برنامه نسخه پیشین.
- هر ترکیب Rate × Face × RNG در دو وضعیت `monitored` و `uninstrumented`، در مجموع **۷۲ اجرای تازه**، شامل ۳۶ پایش‌شده و ۳۶ شاهد سربار پایش.
- خروجی جدید فقط `episode_output/stage1am_f3_return_matched_dev/`. خروجی قبلی و Workflow `v0.47.1` نباید اجرا/بازنویسی شوند.

## قواعد پذیرش فنی پیش از هر تفسیر

۱. هر ۷۲ اجرای برنامه کامل باشد؛ هیچ اجرای ناموفق به‌صورت سکوت حذف نشود. پوشش پیوسته INITIAL/FINAL برای هر ۲۰ device در زمان ۰ و ۲۰ ثانیه و شمارنده‌های Drop معتبر باشد.

۲. در هر `Face × RNG`، برنامه واقعی ۱۲ Target و ۹۶ Competitor بین هر ۶ اجرای نرخ×پایش **بایت‌به‌بایت در کلیدهای زمان، نام و Nonce** برابر باشد؛ زمان‌های گزارش Arrival نیز به SEND بخورند. در هر Face، برنامه RNG بین ۴ RngRun واقعاً متفاوت باشد.

۳. تنها تفاوت پارامتر فیزیکی بین سه بازو ظرفیت برگشت Producer→Mid باشد؛ بقیه قیود scenario و source باید یکسان بمانند. اگر خطای نرخ یا تغییر برنامه رخ دهد Fail-closed است.

۴. رخدادهای `QUEUE_DROP` روی دستگاه درست با نرخ درست، `QUEUE_DEQUEUE.queue_wait_ns` و شمارنده FINAL همخوان باشند. در صورت نبود داده یا عدم دسترسی، **UNKNOWN/UNADJUDICATED** گزارش شود، نه منفی.

۵. مقایسه اولیه فقط شامل Drop Fragment در مسیر برگشت و Max wait مشاهده‌شده برای همان Link در سطح هر یک از ۱۲ جفت Face×RNG است؛ AP، CI یا p-value از Fragmentها/پنجره‌ها تولید نشود.

## تفکیک علمی سازه‌ها

- `PhysicalPressure`: رویدادهای واقعی Drop، انتظار صف، ازدحام فیزیکی و انتساب به لینک/جهت. **تاکنون تعریف نهایی برچسب نشده است**.
- `TargetImpact`: Receipt، NACK، افزایش Delay و فقدان سرویس Target؛ **حوزه متفاوت و پسینی**؛ هیچ Receipt/Trace آینده وارد online feature نمی‌شود.
- `NegativeControl`: بازوی 50Mbps تنها **نامزد کنترل منفی** است؛ حتی صفر Drop و انتظار کم به‌خودی‌خود سازه رسمی را اثبات نمی‌کند. باید کامل‌بودن پوشش، شرط انتظار فیزیکی، ظرفیت مسیر و سازگاری با Target به‌طور جداگانه ممیزی شوند.
- `UNKNOWN`: اگر پدیده، انتساب یا پوشش قابل احراز نباشد، برقرار می‌ماند. UNKNOWN→0 یا UNKNOWN→1 ممنوع.
- پنجره 50ms و آستانه 5ms از پایلوت تاریخی معیار معتبر نهایی نیستند؛ این بسته هیچ threshold جدیدی بر پایه Test J نمی‌بندد.

## معیارهای توقف پژوهشی

- حتی اگر ممیزی فنی PASS شود، گیت علمی F3 همچنان NO_GO است.
- اگر نرخ 50Mbps Drop داشت یا نتوانست نمونه‌های منفی معتبر تولید کند، نتیجه **کنترل منفی ناموفق/نامشخص** است، نه تغییر پسینی نرخ یا threshold بر مبنای Test مشاهده‌شده.
- هر تغییر طراحی پس از Development باید پیش از Validation تازه، همراه دلیل و نسخه جدید مستند شود.
- برای اعتبارسنجی بعدی نیاز به مجموعه Validation و Test کاملاً جدید، مهر زمانی نسخه/Threshold و تحلیل گروه‌آگاه داریم؛ `VAL_CHAIN_I` و `TEST_CHAIN_J` قبلاً دیده شده‌اند.

## قفل‌های غیرقابل‌تغییر

```json
{"Congestion":null,"FutureCongestion":null,"F3_ready":false,"GO_FREEZE":false,"training_ready":false}
```

F3 فعلی: `NO_GO_F3_CONSTRUCT_AND_PREDICTABILITY_NOT_VALIDATED`. ساخت دیتاست 1AO و آموزش NSGA-III **BLOCKED**.
