#!/usr/bin/env python3
"""Fail-closed DEVELOPMENT-only matched-rate physical-pressure auditor.

No F3 labels, negative class, PR-AUC, or Test claims are produced.
Input: 72 experiment dirs (3 rates x 3 slots x 4 runs x monitored/uninstrumented).
"""
import argparse
import csv
import hashlib
import json
import pathlib
import sys

ARMS = {
    'RETURN_STRESSED_6M': 6_000_000,
    'RETURN_INTERMEDIATE_12M': 12_000_000,
    'RETURN_MATCHED_HIGH_CAPACITY_50M': 50_000_000,
}
RUNS = range(11421, 11425)
SLOTS = range(3)
STOP = 20_000_000_000

class AuditFailure(RuntimeError):
    pass

def require(condition, message):
    if not condition:
        raise AuditFailure(message)

def json_file(p):
    return json.loads(pathlib.Path(p).read_text())

def jsonl(p):
    p = pathlib.Path(p)
    require(p.is_file(), 'MISSING_FILE: '+str(p))
    out=[]
    with p.open(encoding='utf-8') as f:
        for idx,line in enumerate(f,1):
            require(bool(line.strip()), f'EMPTY_JSONL_LINE:{p}:{idx}')
            x=json.loads(line)
            require(isinstance(x,dict), f'INVALID_JSONL_OBJECT:{p}:{idx}')
            out.append(x)
    return out

def traffic(root):
    result={}
    for key,file,need in [('target','consumer_events.jsonl',12),('competitor','competitor_events.jsonl',96)]:
        s=jsonl(root/file)
        emitted=[x for x in s if x.get('event')=='SEND']
        require(len(emitted)==need, f'UNEXPECTED_{key.upper()}_COUNT:{root}')
        require(len({x.get('name') for x in emitted})==need, f'DUPLICATE_{key.upper()}_NAME:{root}')
        require(all(type(x.get('time_ns')) is int and 0<=x['time_ns']<STOP and
                    type(x.get('nonce')) is int and
                    x.get('name')==f'/hcraf/{"pilot" if key=="target" else "competitor"}/{i}'
                    for i,x in enumerate(emitted)), f'INVALID_{key.upper()}_SEND:{root}')
        tuples=[(x['time_ns'],x['name'],x['nonce']) for x in emitted]
        schedule=jsonl(root/(file+'.arrivals.jsonl'))
        require(len(schedule)==need and
                all(x.get('time_ns')==tuples[i][0] and x.get('sequence')==i
                    for i,x in enumerate(schedule)), 'ARRIVAL_SCHEDULE_MISMATCH:'+str(root))
        result[key]=tuples
    return result

def signature(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def check_config(c, arm,slot,run, monitored):
    require(c.get('topology_id')=='DEV_CHAIN_K' and
            c.get('holdout_partition')=='DEVELOPMENT' and
            c.get('amendment_stage')=='1AM.F3_RETURN_MATCHED_DEV.0' and
            c.get('purpose')=='RETURN_MATCHED_DEV_EXPLORATION_NOT_HCRAF_POLICY',
            'FORBIDDEN_HOLDOUT_OR_SCHEMA')
    require(c.get('phase_arm')==arm and c.get('selected_face_slot')==slot and
            c.get('run')==run and c.get('seed')==17 and
            c.get('instrument_enabled') is monitored, 'BAD_EXPERIMENT_ID')
    require(c.get('selected_forward_bps')==50_000_000 and
            c.get('selected_relay_forward_bps')==50_000_000 and
            c.get('selected_mid_forward_bps')==50_000_000 and
            c.get('selected_return_bps')==50_000_000 and
            c.get('selected_producer_reverse_bps')==ARMS[arm] and
            c.get('matched_rate_only_manipulated_parameter')=='selected_producer_reverse_bps' and
            c.get('candidate_negative_control_is_not_scientific_label') is True,
            'RATE_OR_CONTROL_CONTRACT_VIOLATION')
    require(c.get('competitor_planned_requests')==96 and
            c.get('competitor_interval_ns')==2_000_000 and
            c.get('competitor_offset_ns')==0 and
            c.get('target_offset_ns')==30_000_000 and
            c.get('planned_requests')==12 and
            c.get('nominal_arrival_interval_ns')==30_000_000 and
            c.get('interest_lifetime_ms')==2600 and
            c.get('queue_capacity_packets')==20 and
            c.get('mtu_bytes')==600 and c.get('payload_bytes')==4096 and
            c.get('network_node_count')==11 and
            c.get('network_directed_device_count')==20 and
            c.get('stop_ns')==STOP,
            'LOAD_OR_PHYSICAL_BASELINE_CHANGED')
    require(c.get('competitor_pulse_count')==2 and
            c.get('competitor_burst_start_rng_stream')==139 and
            c.get('target_schedule_rng_stream')==129,
            'RNG_SCHEDULE_CHANGED')
    for k in ('Congestion','FutureCongestion','congestion','future_congestion'):
        require(k in c and c[k] is None, 'FORBIDDEN_LABEL:'+k)
    for k in ('F3_ready','GO_FREEZE','training_ready'):
        require(c.get(k) is False, 'FORBIDDEN_GATE:'+k)
    require(c.get('future_oracle_is_final_F3') is False and
            c.get('remote_queue_online_feature') is False and
            c.get('no_counterfactual_unselected_face') is True and
            c.get('actual_assignment_probability')==1.0,
            'FORBIDDEN_ONLINE_OR_COUNTERFACTUAL_CLAIM')
    require(c.get('selected_producer_node_id') in {8,9,10} and
            c.get('selected_mid_node_id') in {5,6,7}, 'INVALID_RETURN_NODES')
    return {k:v for k,v in c.items() if k not in {'phase_arm','selected_producer_reverse_bps',
                       'instrument_enabled','local_NFD_queue_observed_before_send',
                       'NFD_dispatch_wall_CPU_measured'}}

def pressure(root, config):
    data=jsonl(root/'link_events.jsonl')
    require(len(data)>40 and all(x.get('link_event_seq')==i for i,x in enumerate(data,1)),
            'INVALID_LINK_SEQUENCE:'+str(root))
    initial={(x['node_id'],x['device_index']):x for x in data if x.get('event_type')=='INITIAL'}
    final={(x['node_id'],x['device_index']):x for x in data if x.get('event_type')=='FINAL'}
    require(len(initial)==len(final)==20 and set(initial)==set(final), 'MISSING_INITIAL_FINAL')
    require(all(x['time_ns']==0 for x in initial.values()) and
            all(x['time_ns']==STOP for x in final.values()), 'INCOMPLETE_TRACE_DURATION')
    producer=config['selected_producer_node_id']
    reverse=[k for k in initial if k[0]==producer]
    require(len(reverse)==1, 'AMBIGUOUS_RETURN_DEVICE')
    reverse_key=reverse[0]
    require(initial[reverse_key]['data_rate_bps']==config['selected_producer_reverse_bps'],
            'RETURN_RATE_NOT_ACTUAL')
    drops={k:0 for k in initial}
    waitmax={k:0 for k in initial}
    for e in data:
        k=(e.get('node_id'),e.get('device_index'))
        require(k in initial, 'EVENT_OUTSIDE_MONITORED_DEVICES')
        require(type(e.get('time_ns')) is int and 0<=e['time_ns']<=STOP,
                'EVENT_TIME_OUTSIDE_RECORDING')
        if e.get('event_type')=='QUEUE_DROP':drops[k]+=1
        if e.get('event_type')=='QUEUE_DEQUEUE':
            w=e.get('queue_wait_ns')
            require(type(w) is int and w>=0, 'MISSING_OR_INVALID_QUEUE_WAIT')
            waitmax[k]=max(waitmax[k],w)
    require(all(final[k]['queue_drop_packets_total']==drops[k] for k in initial),
            'DROP_COUNT_DISAGREES_WITH_FINAL')
    nonmanipulated=sorted((k[0],k[1],x.get('data_rate_bps'),x.get('face_id'),x.get('link_up'))
                            for k,x in initial.items() if k!=reverse_key)
    return {'nonmanipulated_device_rates_sha256':signature(nonmanipulated),
            'reverse_drop_fragments':drops[reverse_key],
            'reverse_max_dequeue_wait_ns':waitmax[reverse_key],
            'all_devices_drop_fragments':sum(drops.values()),
            'all_devices_max_dequeue_wait_ns':max(waitmax.values()),
            'reverse_final_queue_packets':final[reverse_key]['queue_packets'],
            'reverse_final_queue_bytes':final[reverse_key]['queue_bytes'],
            'full_20_device_20s_coverage':True,
            'control_status':'UNADJUDICATED_NOT_A_NEGATIVE_LABEL'}

def audit(root, out):
    root=pathlib.Path(root)
    rows=[]
    matches={}; fingerprints={}
    for slot in SLOTS:
      for run in RUNS:
        ref=None; ref_config=None
        for arm,rate in ARMS.items():
          for kind in ('monitored','uninstrumented'):
            p=root/'DEV_CHAIN_K'/f'slot-{slot}'/kind/arm/f'run-{run}'
            require(p.is_dir(), 'MISSING_EXPERIMENT:'+str(p))
            config=json_file(p/'scenario.json')
            invariant=check_config(config,arm,slot,run,kind=='monitored')
            t=traffic(p)
            if ref is None:
                ref=t;ref_config=invariant
            require(ref==t, 'CROSS_RATE_OR_MONITOR_INPUT_CHANGED:'+str(p))
            require(ref_config==invariant, 'NON_RATE_OR_MONITOR_CONFIG_CHANGED:'+str(p))
            row={'topology':'DEV_CHAIN_K','slot':slot,'rng_run':run,'arm':arm,
                 'reverse_bps':rate,'instrumented':kind=='monitored',
                 'target_schedule_sha256':signature(t['target']),
                 'competitor_schedule_sha256':signature(t['competitor'])}
            if kind=='monitored':
                row.update(pressure(p,config))
                physical_hash=row['nonmanipulated_device_rates_sha256']
                pair_key=(slot,run)
                if pair_key in fingerprints:
                    require(fingerprints[pair_key]==physical_hash,
                            'NONMANIPULATED_PHYSICAL_DEVICES_CHANGED:'+str(p))
                else:fingerprints[pair_key]=physical_hash
                # Prevent accidental retrospective or proxy relabeling.
                require(not any(key in row for key in ('label','FutureCongestion','negative_control_label')),
                        'FORBIDDEN_SCIENTIFIC_LABEL')
            else:
                require((p/'resource_usage.txt').is_file(), 'MISSING_UNINSTRUMENTED_RESOURCE_USAGE')
            rows.append(row)
        matches[(slot,run)]=(signature(ref['target']),signature(ref['competitor']))
    # Real input diversity: each RNG has its own independently emitted schedule.
    for slot in SLOTS:
        assert len({matches[(slot,r)][1] for r in RUNS})==len(RUNS), 'NO_RNG_INPUT_DIVERSITY'
    require(len(rows)==72, 'INCOMPLETE_MATRIX')
    out=pathlib.Path(out);out.mkdir(parents=True,exist_ok=True)
    columns=['topology','slot','rng_run','arm','reverse_bps','instrumented',
             'target_schedule_sha256','competitor_schedule_sha256',
             'nonmanipulated_device_rates_sha256',
             'reverse_drop_fragments','reverse_max_dequeue_wait_ns','all_devices_drop_fragments',
             'all_devices_max_dequeue_wait_ns','reverse_final_queue_packets','reverse_final_queue_bytes',
             'full_20_device_20s_coverage','control_status']
    with (out/'matched_dev_72_runs.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=columns);w.writeheader();w.writerows(rows)
    # Pair-level differences are descriptive only; Fragment counts are not independent units.
    selected={(r['slot'],r['rng_run'],r['arm']):r for r in rows if r['instrumented']}
    pairs=[]
    for slot in SLOTS:
      for run in RUNS:
        lo=selected[(slot,run,'RETURN_STRESSED_6M')]
        mid=selected[(slot,run,'RETURN_INTERMEDIATE_12M')]
        hi=selected[(slot,run,'RETURN_MATCHED_HIGH_CAPACITY_50M')]
        pairs.append({'topology':'DEV_CHAIN_K','slot':slot,'rng_run':run,
          'drop_fragments_6m':lo['reverse_drop_fragments'],
          'drop_fragments_12m':mid['reverse_drop_fragments'],
          'drop_fragments_50m':hi['reverse_drop_fragments'],
          'paired_drop_difference_6m_minus_50m':lo['reverse_drop_fragments']-hi['reverse_drop_fragments'],
          'reverse_max_wait_ns_6m':lo['reverse_max_dequeue_wait_ns'],
          'reverse_max_wait_ns_12m':mid['reverse_max_dequeue_wait_ns'],
          'reverse_max_wait_ns_50m':hi['reverse_max_dequeue_wait_ns'],
          '50m_drop_free_observed':hi['reverse_drop_fragments']==0,
          'scientific_control_label':'UNADJUDICATED'})
    with (out/'matched_dev_12_pairs.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(pairs[0]));w.writeheader();w.writerows(pairs)
    result={'experiment':'1AM-F3-RETURN-MATCHED-CONTROLS','phase':'DEVELOPMENT_ONLY',
      'matrix_total_runs':72, 'monitored_runs':36, 'paired_clusters_slot_x_rng':12,
      'input_pairing':'PASS','physical_coverage':'PASS',
      'pairwise_rate_effects':'DESCRIPTIVE_12_SLOT_RNG_PAIRS',
      'group_inference':'DESCRIPTIVE_ONLY_DEPENDENT_CLUSTERS',
      'negative_control_label':'NOT_ASSIGNED',
      'scientific_f3_status':'NO_GO_F3_CONSTRUCT_AND_PREDICTABILITY_NOT_VALIDATED',
      'Congestion':None,'FutureCongestion':None,'F3_ready':False,
      'GO_FREEZE':False,'training_ready':False}
    (out/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    return result

def main():
    p=argparse.ArgumentParser()
    p.add_argument('root',type=pathlib.Path)
    p.add_argument('--output',type=pathlib.Path,required=True)
    a=p.parse_args()
    try:audit(a.root,a.output)
    except (AuditFailure,ValueError,KeyError,AssertionError,FileNotFoundError) as e:
        print('DEVELOPMENT_MATCHED_AUDIT_FAILED:',str(e),file=sys.stderr)
        raise SystemExit(3)

if __name__=='__main__':main()
