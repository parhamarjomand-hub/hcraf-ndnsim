#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
OUT="$ROOT/episode_output/stage1am_f3_return_matched_dev"
# Fail closed: never overwrite prior experiment evidence or I/J outputs.
if [ -e "$OUT" ];then
  echo "REFUSE_TO_OVERWRITE_EXISTING_DEV_OUTPUT: $OUT" >&2
  exit 10
fi
mkdir -p "$OUT"
cd "$ROOT/episode_sources/ns-3"
for slot in 0 1 2;do
  for rng in 11421 11422 11423 11424;do
    for arm in RETURN_STRESSED_6M RETURN_INTERMEDIATE_12M RETURN_MATCHED_HIGH_CAPACITY_50M;do
      for instrument in 1 0;do
        if [ "$instrument" = 1 ];then kind=monitored;else kind=uninstrumented;fi
        dest="$OUT/DEV_CHAIN_K/slot-$slot/$kind/$arm/run-$rng"
        mkdir -p "$dest"
        cmd="hcraf-stage1am-f3-return-matched-dev --pathArm=$arm --topology=DEV_CHAIN_K --selectedSlot=$slot --mode=LP_INDEPENDENT_COMPETITOR_NO_DROP --seed=17 --run=$rng --output=$dest --instrument=$instrument --lifetimeMs=2600 --requestCount=12 --intervalNs=30000000 --competitorCount=96 --competitorIntervalNs=2000000 --competitorOffsetNs=0 --targetOffsetNs=30000000 --forwardBps=50000000 --returnBps=50000000"
        printf '%s\n' "$cmd" > "$dest/command.txt"
        /usr/bin/time -f 'wall_seconds=%e\nuser_seconds=%U\nsystem_seconds=%S\nmax_rss_kib=%M' -o "$dest/resource_usage.txt" \
          python3 ./waf --run-no-build "$cmd" > "$dest/simulator.log" 2>&1
        if [ "$instrument" = 1 ];then
          python3 "$TASK/scripts/episodes_stage1u.py" "$dest" \
            --run-id "1am_return_dev-DEV_CHAIN_K-$slot-$arm-17-$rng" > "$dest/episodes.log" 2>&1
        fi
      done
    done
  done
done
python3 "$TASK/scripts/verify_stage1am_f3_return_matched_dev.py" "$OUT" \
  --output "$ROOT/episode_output/stage1am_f3_return_matched_report" \
  > "$ROOT/episode_output/stage1am_f3_return_matched_report.log" 2>&1
