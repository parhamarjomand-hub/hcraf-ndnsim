#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
# Same previously approved NFD instrumentation patch chain; does NOT rerun old GitHub Workflow.
bash "$TASK/scripts/build_stage1am_pathwide.sh"
cd "$ROOT/episode_sources/ns-3"
cp "$TASK/src/hcraf-stage1am-f3-return-matched-dev.cpp" scratch/hcraf-stage1am-f3-return-matched-dev.cc
cmp -s "$TASK/src/hcraf-stage1am-f3-return-matched-dev.cpp" scratch/hcraf-stage1am-f3-return-matched-dev.cc
python3 ./waf -j 2
test -x build/scratch/hcraf-stage1am-f3-return-matched-dev
