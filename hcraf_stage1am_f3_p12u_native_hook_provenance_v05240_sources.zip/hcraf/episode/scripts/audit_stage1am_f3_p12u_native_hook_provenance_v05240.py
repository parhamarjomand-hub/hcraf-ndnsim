#!/usr/bin/env python3
"""P12U: read-only source/causal gap audit of immutable P12T 24901 raw trace.
   IMPORTANT: not a model, no AP, no new simulation, no training authorization.
"""
import argparse
import collections
import hashlib
import json
import pathlib
import zipfile

P12T_RUN = 45844118722
P12T_ARTIFACT_SHA = '42b4299bdb6da37fe8c900b6105275f287a41b23b3b2a922d349aafaf8b2cc5e'
P12T_SOURCE_SHA = '08b76621c5cb371fe04955d42b27f1a682f883f058ec06f050c60c42724fafa1'
P12R_SOURCE_SHA = 'dbb12863ca83c26b687b243211aaf698986b8d6f2f7b8656cffb06278751ae30'
P12S_SOURCE_SHA = '587d792d7e7e7f1837da8df0490b6fba5a0394248917ae2f0b570bb925b594e0'
SOURCE_ROOT = 'hcraf/episode/docs/1AM/F3_P12R_FAIR_COMPARATOR_PREREG_v0.52.37/'
PLAN_NAME = SOURCE_ROOT + 'P12R_FAIR_COMPARATOR_PROSPECTIVE_PLAN_v05237.json'
FEATURES = (
 'fib_route_cost', 'local_selected_queue_packets', 'local_selected_queue_fraction',
 'local_selected_link_up', 'local_pit_occupancy_at_t',
 'local_interest_rx_count_previous_75ms', 'local_data_rx_count_previous_75ms',
 'local_nack_rx_count_previous_75ms', 'local_selected_face_tx_count_previous_75ms',
 'local_selected_face_drop_count_previous_75ms', 'local_data_rtt_ewma_before_t',
 'local_data_rtt_missing_at_t'
)


def need(test, code):
    if not test:
        raise RuntimeError('P12U_FAIL_CLOSED_' + code)


def sha(b):
    return hashlib.sha256(b).hexdigest()


def read_jsonl(z, name):
    need(name in z.namelist(), 'FILE_MISSING_' + name)
    raw = z.read(name)
    return [json.loads(line) for line in raw.splitlines() if line.strip()]


def audit(raw_path, p12r_path, p12t_source_path, p12s_source_path=None):
    raw_path = pathlib.Path(raw_path)
    need(sha(raw_path.read_bytes()) == P12T_ARTIFACT_SHA, 'P12T_ARTIFACT_ZIP_SHA')
    need(sha(pathlib.Path(p12r_path).read_bytes()) == P12R_SOURCE_SHA, 'P12R_SOURCE_SHA')
    need(sha(pathlib.Path(p12t_source_path).read_bytes()) == P12T_SOURCE_SHA, 'P12T_SOURCE_SHA')
    if p12s_source_path:
        need(sha(pathlib.Path(p12s_source_path).read_bytes()) == P12S_SOURCE_SHA, 'P12S_SOURCE_SHA')
    with zipfile.ZipFile(p12r_path) as z:
        need(z.testzip() is None, 'P12R_ZIP_CRC')
        plan = json.loads(z.read(PLAN_NAME))
    b1 = plan['feature_sets']['strengthened_local_B1_primary_control']
    need(b1 == list(FEATURES), 'P12R_B1_EXACT_ORDER')
    need(plan['prospective_design']['development_cases']==72 and plan['prospective_design']['confirmation_cases']==432, 'P12R_MATRIX')
    need(plan['seed_partitions']['development'] == list(range(24901,24907)), 'P12R_DEV_SEEDS')
    need(plan['seed_partitions']['independent_confirmation'] == list(range(25001,25037)), 'P12R_CONF_SEEDS')
    with zipfile.ZipFile(p12t_source_path) as z:
        need(z.testzip() is None, 'P12T_SOURCE_CRC')
        src=z.read('hcraf/episode/src/hcraf-stage1am-f3-p12t-native-development-v05239.cpp').decode('utf-8')
        for anchor in ('HcrafP12TNativeWiring','NFD_BEGIN_DECISION_AND_LOCAL_NS3_QUEUE',
                       'interest_data_nack_nfd_hooks_wired', 'completed_local_rtt_hook_wired',
                       'raw_frames_not_equated_with_ndn_interest_counts'):
            need(anchor in src, 'P12T_SOURCE_ANCHOR_'+anchor)
    with zipfile.ZipFile(raw_path) as z:
        need(z.testzip() is None,'P12T_RAW_ZIP_CRC')
        scenario=json.loads(z.read('scenario.json'))
        receipt=json.loads(z.read('P12T_NATIVE_INTEGRATION_SENTINEL_RECEIPT_v05239.json'))
        native=read_jsonl(z,'p12t_native_local_at_decision.jsonl')
        decisions=read_jsonl(z,'events.jsonl.decisions.jsonl')
        queue=read_jsonl(z,'nfd_local_queue_at_decision.jsonl')
        telemetry=read_jsonl(z,'queue_telemetry_decisions.jsonl')
        telemetry_receipts=read_jsonl(z,'queue_telemetry_receipts.jsonl')
        events=read_jsonl(z,'events.jsonl')
        states=read_jsonl(z,'events.jsonl.states.jsonl')
    need(receipt['status']=='PASS_P12T_ONE_DEV_SENTINEL_REAL_NDNSIM_PARTIAL_NATIVE_WIRING_ONLY','P12T_REPORT_STATUS')
    need(receipt['native_local_features_valid_count']==5 and not receipt['complete_B1_valid'], 'P12T_INCOMPLETE_B1')
    need(receipt['seed']==24901 and receipt['case_count']==1 and receipt['native_decision_snapshots']==128, 'P12T_SENTINEL_COUNT')
    need(receipt['missing_NFD_interest_data_nack_hooks'] and receipt['locally_completed_RTT_hook_missing'], 'P12T_GAP_DECLARATION')
    need(receipt['heldout_reads']==0 and receipt['confirmation_seed_reads']==0 and receipt['model_fits']==0 and not receipt['new_AP_computed'], 'P12T_NO_TRAIN_OR_HELDOUT')
    need(not receipt['F3_ready'] and not receipt['GO_FREEZE'] and not receipt['training_ready'], 'P12T_SCIENCE_LOCKS')
    need(scenario['independent_rng_block']==24901 and scenario['research_partition']=='FAIR_LOCAL_DEV', 'PHYSICAL_DEV_PARTITION')
    need(scenario['schedule_family']=='P12R_NEW_FAIR_COMPARATOR_PROSPECTIVE_PREREG_ONLY' and scenario['p12k_replication_site']=='producer_egress', 'P12R_CASE_CONTEXT')
    need(scenario['p4_prospective_load']=='high_pressure' and scenario['telemetry_period_ms']==20 and scenario['telemetry_enabled'], 'P12R_ARM')
    need(len(native)==len(decisions)==len(telemetry)==128 and len(queue)==len(states)==384, 'NATIVE_ROW_COUNTS')
    need([x['decision_id'] for x in native]==list(range(1,129)), 'NATIVE_ID_SET')
    qmap={(r['decision_id'],r['candidate_face_id']):r for r in queue}
    smap={(r['decision_id'],r['face_id']):r for r in states}
    receipt_map={r['report_id']:r for r in telemetry_receipts}
    need(len(qmap)==384 and len(smap)==384 and len(receipt_map)==len(telemetry_receipts), 'NO_DUPLICATE_STATES')
    etypes=collections.Counter(e['event_type'] for e in events)
    need(etypes['TX_INTEREST']==128 and etypes['PIT_SATISFIED']>0, 'EXISTING_NFD_EVENT_COUNTS')
    txmap=collections.defaultdict(list)
    for e in events:
        need(e['node_id']==1, 'EVENT_LOCAL_ONLY')
        if e['event_type']=='TX_INTEREST':txmap[e['decision_id']].append(e)
    need(set(txmap)==set(range(1,129)), 'NFD_TX_PER_DECISION')
    native_raw_drops=[]
    for i,(n,d,t) in enumerate(zip(native,decisions,telemetry)):
        ident=i+1
        need(n['decision_id']==d['decision_id']==t['decision_id']==ident,'DECISION_ID_ALIGNMENT')
        need(n['node_id']==d['node_id']==1 and n['time_ns']==d['time_ns']==t['decision_ns'], 'NFD_DECISION_CLOCK')
        need(n['source']=='NFD_BEGIN_DECISION_AND_LOCAL_NS3_QUEUE' and n['before_actual_selected_face_tx'], 'BEFORE_SELECTED_TX')
        face=n['selected_face_id']
        need(face==258 and face in (c['face_id'] for c in d['candidates']), 'SELECTED_FACE')
        chosen=next(c for c in d['candidates'] if c['face_id']==face)
        q=qmap[(ident,face)]
        need(q['observed_before_forwarding'] and q['sim_time_ns']==n['time_ns'], 'QUEUE_TIME')
        need(q['node_id']==1 and q['candidate_face_id']==face and not q['remote_node_queue_accessed'], 'QUEUE_SOURCE')
        v=n['b1_first_five_native']
        need(len(v)==5 and v[0]==chosen['routing_cost'] and v[1]==q['queue_packets'], 'B1_FIRST_TWO')
        need(abs(v[2]-q['local_queue_occupancy_fraction'])<1e-12 and v[3]==int(q['link_up']), 'B1_FRACTION_LINK')
        need(isinstance(v[4],int) and v[4]>=0, 'PIT_SNAPSHOT_NUMERIC')
        need(n['raw_frames_not_equated_with_ndn_interest_counts'] and not n['interest_data_nack_nfd_hooks_wired'] and not n['completed_local_rtt_hook_wired'], 'GAP_FLAGS')
        need(not n['all_B1_features_valid'] and not n['model_training_authorized'] and not n['F3_ready'] and not n['GO_FREEZE'], 'FENCE_EVERY_ROW')
        tx=txmap[ident]
        need(len(tx)==1 and tx[0]['face_id']==face and tx[0]['name']==d['name'] and tx[0]['time_ns']>=d['time_ns'], 'NFD_TX_PROVENANCE')
        native_raw_drops.append(n['selected_local_queue_dropped_raw_frames_total'])
        # Telemetry is a separate causal source; it must not be used to fill B1 local features.
        for e in t['feature_evidence']:
            tr=receipt_map[e['report_id']]
            need(tr['source_node_id']==e['source_node_id'] and tr['source_device_index']==e['source_device_index'], 'REMOTE_ORIGIN')
            need(tr['sample_ns']<=tr['receipt_ns']<=n['time_ns'], 'TELEMETRY_TIME_CAUSAL')
        need(not t['feature_missing_sources'], 'SENTINEL_TELEMETRY_MISSING')
    need(all(b>=a for a,b in zip(native_raw_drops,native_raw_drops[1:])), 'LOCAL_RAW_DROP_MONOTONE')
    need(native_raw_drops[-1]==0,'SENTINEL_RAW_DROP_ZERO_EXPECTED')
    need(not any(x['event_type'] in ('RX_NACK','INCOMING_NACK','NACK_RX') for x in events), 'NACK_NONZERO_UNEXPECTED')
    ret={
      'status':'PASS_P12U_P12T_IMMUTABLE_NATIVE_HOOK_GAP_QC_ONLY',
      'parent_p12t_run_id':P12T_RUN,
      'raw_artifact_sha256':P12T_ARTIFACT_SHA,
      'independent_development_seed':24901,
      'original_physical_cases_read':1,
      'decisions_authenticated':128,
      'NFD_TX_INTEREST_recorder_events':etypes['TX_INTEREST'],
      'NFD_DATA_PIT_SATISFIED_recorder_events':etypes['PIT_SATISFIED'],
      'NFD_NACK_event_types_observed':0,
      'native_first_five_features_count':5,
      'native_first_five_feature_names':list(FEATURES[:5]),
      'missing_native_last_seven_features_count':7,
      'missing_native_last_seven_names':list(FEATURES[5:]),
      'native_selected_queue_packets_nonzero_decisions':sum(r['b1_first_five_native'][1]>0 for r in native),
      'native_PIT_occupancy_min':min(r['b1_first_five_native'][4] for r in native),
      'native_PIT_occupancy_max':max(r['b1_first_five_native'][4] for r in native),
      'raw_frames_enqueue_at_first_decision':native[0]['selected_local_queue_enqueued_raw_frames_total'],
      'raw_frames_enqueue_at_last_decision':native[-1]['selected_local_queue_enqueued_raw_frames_total'],
      'raw_frames_drop_at_last_decision':native[-1]['selected_local_queue_dropped_raw_frames_total'],
      'telemetry_decision_rows_causal_verified':len(telemetry),
      'physical_NFD_hook_provenance':'NFD_TX logged, RX/RTT/drop missing dedicated online B1 hooks',
      'B1_complete_and_valid':False,'online_last_seven_NFD_hooks_wired':False,
      'new_simulations':0,'new_AP_computed':False,'new_bootstrap_computed':False,
      'model_fits':0,'confirmation_seed_reads':0,'heldout_reads':0,
      'Congestion':None,'FutureCongestion':None,'F3_ready':False,'GO_FREEZE':False,
      'training_ready':False,'Stage1AO_or_NSGAIII_authorized':False,
      'next_action':'Implement NFD 75ms Interest/Data/Nack and selected Face Interest TX/drop callbacks and completed local RTT before a NEW DEVELOPMENT sentinel; never use raw L2 frames as NFD Interest counts.'
    }
    return ret


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--p12t-artifact',required=True)
    p.add_argument('--p12r-source',required=True)
    p.add_argument('--p12t-source',required=True)
    p.add_argument('--p12s-source')
    p.add_argument('--output',required=True)
    a=p.parse_args()
    result=audit(a.p12t_artifact,a.p12r_source,a.p12t_source,a.p12s_source)
    pathlib.Path(a.output).write_text(json.dumps(result,sort_keys=True,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(result['status'],'decisions',result['decisions_authenticated'],'B1',result['native_first_five_features_count'],'/12','training_ready',result['training_ready'])
if __name__=='__main__':main()
