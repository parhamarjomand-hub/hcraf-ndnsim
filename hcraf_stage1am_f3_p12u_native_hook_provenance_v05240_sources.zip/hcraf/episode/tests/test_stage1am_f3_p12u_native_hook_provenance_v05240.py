import importlib.util
import json
import os
import pathlib
import unittest

S = pathlib.Path(__file__).resolve().parents[1] / 'scripts' / 'audit_stage1am_f3_p12u_native_hook_provenance_v05240.py'
q = importlib.util.spec_from_file_location('p12u_audit', S)
M = importlib.util.module_from_spec(q)
q.loader.exec_module(M)

class P12U(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = os.environ.get('P12U_TEST_RAW_PATH')
        cls.r = os.environ.get('P12U_TEST_P12R_PATH')
        cls.t = os.environ.get('P12U_TEST_P12T_PATH')
        cls.s = os.environ.get('P12U_TEST_P12S_PATH')
        if all([cls.raw,cls.r,cls.t,cls.s]):
            cls.report = M.audit(cls.raw,cls.r,cls.t,cls.s)
        else:
            cls.report = None
    def test_exact_twelve_B1_names(self):
        self.assertEqual(len(M.FEATURES),12)
        self.assertEqual(M.FEATURES[4],'local_pit_occupancy_at_t')
        self.assertEqual(M.FEATURES[11],'local_data_rtt_missing_at_t')
    def test_exact_parent_artifact_digest(self):
        self.assertEqual(M.P12T_ARTIFACT_SHA,'42b4299bdb6da37fe8c900b6105275f287a41b23b3b2a922d349aafaf8b2cc5e')
    def test_original_audit_mandatory(self):
        self.assertIsNotNone(self.report,'GitHub P12T raw + frozen P12R/S/T sources required for this test')
        self.assertEqual(self.report['status'],'PASS_P12U_P12T_IMMUTABLE_NATIVE_HOOK_GAP_QC_ONLY')
    def test_sentinel_128_decisions(self):
        self.assertEqual(self.report['decisions_authenticated'],128)
        self.assertEqual(self.report['NFD_TX_INTEREST_recorder_events'],128)
    def test_only_five_physically_wired(self):
        self.assertEqual(self.report['native_first_five_features_count'],5)
        self.assertEqual(self.report['missing_native_last_seven_features_count'],7)
        self.assertFalse(self.report['B1_complete_and_valid'])
    def test_native_pit_changes(self):
        self.assertLess(self.report['native_PIT_occupancy_min'],self.report['native_PIT_occupancy_max'])
    def test_local_queues_remain_zero(self):
        self.assertEqual(self.report['native_selected_queue_packets_nonzero_decisions'],0)
        self.assertEqual(self.report['raw_frames_drop_at_last_decision'],0)
    def test_raw_frames_never_rebranded_as_interest(self):
        self.assertNotEqual(self.report['raw_frames_enqueue_at_last_decision'],
                            self.report['NFD_TX_INTEREST_recorder_events'])
        self.assertIn('NFD_TX logged',self.report['physical_NFD_hook_provenance'])
    def test_telemetry_not_used_as_B1(self):
        self.assertEqual(self.report['telemetry_decision_rows_causal_verified'],128)
        self.assertTrue(set(self.report['native_first_five_feature_names']).isdisjoint({'relay_queue_packets','mid_queue_packets','producer_queue_packets'}))
    def test_no_training_heldout_or_confirmation(self):
        for key in ['new_simulations','model_fits','confirmation_seed_reads','heldout_reads']:
            self.assertEqual(self.report[key],0)
        for key in ['F3_ready','GO_FREEZE','training_ready','Stage1AO_or_NSGAIII_authorized','new_AP_computed','new_bootstrap_computed']:
            self.assertFalse(self.report[key])
    def test_reject_wrong_artifact_zip(self):
        with self.assertRaisesRegex(RuntimeError,'P12U_FAIL_CLOSED_P12T_ARTIFACT_ZIP_SHA'):
            M.audit(self.r,self.r,self.t,self.s)
    def test_reject_wrong_prereg_zip(self):
        with self.assertRaisesRegex(RuntimeError,'P12U_FAIL_CLOSED_P12R_SOURCE_SHA'):
            M.audit(self.raw,self.t,self.t,self.s)
    def test_reject_missing_source_file(self):
        with self.assertRaises(FileNotFoundError):
            M.audit(self.raw,self.r,self.t+'_not_real',self.s)
    def test_fail_closed_helper(self):
        M.need(True,'OK')
        with self.assertRaisesRegex(RuntimeError,'P12U_FAIL_CLOSED_TEST'):
            M.need(False,'TEST')

if __name__=='__main__':unittest.main()
