#include "hcraf-stage1am-f3-p12u-local-nfd-hook-adapter-v05240.hpp"
#include <cmath>
#include <iostream>
#include <stdexcept>
using namespace hcraf_p12u;
static void ensure(bool x,const char* message){if(!x)throw std::runtime_error(message);}
template<typename F>static void fails(F f){bool yes=false;try{f();}catch(const std::exception&){yes=true;}ensure(yes,"FAIL_CLOSED_NOT_REJECTED");}
int main(){
  Node1NativeEventAdapter a;
  ensure(!a.observe(NfdHook::IncomingInterest,1,1,"/hcraf-queue-telemetry/producer/1"),"CONTROL_NOT_EXCLUDED");
  ensure(!Node1NativeEventAdapter::isResearchTraffic("/hcraf/pilotish/1"),"FALSE_POSITIVE_NAME");
  fails([&](){a.observe(NfdHook::IncomingInterest,2,1,"/other/1");});
  fails([&](){a.observe(NfdHook::IncomingInterest,3,0,"/hcraf/pilot/1");});
  auto s=a.snapshotBeforeSelectedFaceTx(100000000,258,1,0,12,true,14);
  ensure(s.values[0]==1&&s.values[1]==0&&s.values[2]==0&&s.values[3]==1&&s.values[4]==14,"FIRST_FIVE");
  ensure(s.values[10]==0&&s.values[11]==1,"RTT_MISSING_AT_START");
  std::cout<<"PASS_P12U_ADAPTER_FIRST_FIVE_AND_MISSING_RTT\n";
  auto e=[&](NfdHook k,std::uint64_t t,std::uint64_t face,double rtt=0.){
    return a.observe(k,t,face,"/hcraf/competitor/1",rtt);
  };
  e(NfdHook::IncomingInterest,110000000,257);
  e(NfdHook::IncomingData,115000000,258);
  e(NfdHook::IncomingNack,120000000,258);
  e(NfdHook::OutgoingSelectedInterest,125000000,258);
  e(NfdHook::OutgoingSelectedInterest,130000000,259);
  e(NfdHook::DroppedSelectedInterest,135000000,258);
  e(NfdHook::DroppedSelectedInterest,140000000,259);
  e(NfdHook::LocallyCompletedDataRtt,145000000,258,20.0);
  e(NfdHook::LocallyCompletedDataRtt,145000000,258,28.0);
  auto b=a.snapshotBeforeSelectedFaceTx(150000000,258,1,0,12,true,16);
  ensure(b.values[5]==1&&b.values[6]==1&&b.values[7]==1,"NFD_RX_COUNT_WINDOW");
  ensure(b.values[8]==1&&b.values[9]==1,"ONLY_SELECTED_FACE_EVENTS");
  ensure(std::abs(b.values[10]-21.0)<1e-9&&b.values[11]==0,"COMPLETED_RTT_EWMA");
  ensure(a.researchEvents()==9,"RESEARCH_EVENT_COUNT");
  std::cout<<"PASS_P12U_ADAPTER_CAUSAL_RX_TX_DROP_AND_COMPLETED_RTT\n";
  auto c=a.snapshotBeforeSelectedFaceTx(230000000,258,1,0,12,true,11);
  ensure(c.values[5]==0&&c.values[6]==0&&c.values[7]==0&&c.values[8]==0&&c.values[9]==0,"EXPIRED_OPEN_LOOKBACK");
  fails([&](){e(NfdHook::IncomingInterest,225000000,257);});
  fails([&](){a.snapshotBeforeSelectedFaceTx(229000000,258,1,0,12,true,11);});
  ensure(hcraf_p12s::B1_FEATURES.size()==12,"EXACT_12_B1");
  std::cout<<"PASS_P12U_ADAPTER_LOOKBACK_CAUSALITY_AND_FAIL_CLOSED\n";
  std::cout<<"PASS_P12U_NATIVE_HOOK_ADAPTER_STANDALONE_SPEC_ONLY_NOT_NDNSIM_WIRED\n";
}
