#pragma once
// P12U v0.52.40 -- source-independent adapter SPECIFICATION for native NFD hooks.
// Not yet attached to the pinned NFD Forwarder. Synthetic C++ tests are NOT native validation.
// Only selected node1 local research traffic, at or before decision time.
#include "hcraf-stage1am-f3-p12s-local-causal-meter-v05238.hpp"
#include <cstdint>
#include <stdexcept>
#include <string>

namespace hcraf_p12u {
using Meter=hcraf_p12s::LocalCausalMeter;
using State=hcraf_p12s::BeforeDecisionLocalState;
using Snapshot=hcraf_p12s::B1Snapshot;
enum class NfdHook { IncomingInterest, IncomingData, IncomingNack,
                     OutgoingSelectedInterest, DroppedSelectedInterest, LocallyCompletedDataRtt };

class Node1NativeEventAdapter {
 public:
  // Caller must supply NFD-sourced events with reliable simulator time and actual Face ID.
  // Only the selected outgoing Face's packet counts can populate selected-Face features.
  // Telemetry control packets never enter any B1 counters.
  bool observe(NfdHook source, std::uint64_t time_ns, std::uint64_t face_id,
               const std::string& full_ndn_name, double completed_local_rtt_ms=0.0) {
    if (isTelemetryControl(full_ndn_name)) return false;
    if (!isResearchTraffic(full_ndn_name))
      throw std::runtime_error("P12U_NON_RESEARCH_OR_UNCLASSIFIED_NDN_NAME");
    if (!face_id)throw std::runtime_error("P12U_INVALID_NFD_FACE_ID");
    hcraf_p12s::Kind k;
    switch(source){
      case NfdHook::IncomingInterest:k=hcraf_p12s::Kind::InterestRx;break;
      case NfdHook::IncomingData:k=hcraf_p12s::Kind::DataRx;break;
      case NfdHook::IncomingNack:k=hcraf_p12s::Kind::NackRx;break;
      case NfdHook::OutgoingSelectedInterest:k=hcraf_p12s::Kind::SelectedFaceTx;break;
      case NfdHook::DroppedSelectedInterest:k=hcraf_p12s::Kind::SelectedFaceDrop;break;
      case NfdHook::LocallyCompletedDataRtt:k=hcraf_p12s::Kind::CompletedLocalDataRtt;break;
      default: throw std::runtime_error("P12U_UNKNOWN_NFD_HOOK");
    }
    // Ordinal is source-observer event order; same-tick observations before
    // the decision are included only when the real NFD hook calls this before capture.
    m_meter.observe(hcraf_p12s::LocalEvent{k,time_ns,++m_ordinal,face_id,1,true,completed_local_rtt_ms});
    ++m_researchEvents;
    return true;
  }
  Snapshot snapshotBeforeSelectedFaceTx(std::uint64_t now_ns,
                                       std::uint64_t selected_face_id,
                                       std::uint64_t fib_cost,
                                       std::uint64_t local_queue_packets,
                                       std::uint64_t local_queue_capacity,
                                       bool local_link_up,
                                       std::uint64_t local_pit_entries){
    return m_meter.capture(State{now_ns,++m_ordinal,1,selected_face_id,fib_cost,
                                 local_queue_packets,local_queue_capacity,
                                 local_link_up,local_pit_entries});
  }
  std::uint64_t researchEvents() const{return m_researchEvents;}
  static bool isResearchTraffic(const std::string& name){
    return hasNamespace(name,"/hcraf/pilot") || hasNamespace(name,"/hcraf/competitor");
  }
  static bool isTelemetryControl(const std::string& name){
    return hasNamespace(name,"/hcraf-queue-telemetry");
  }
 private:
  static bool hasNamespace(const std::string& name,const std::string& prefix){
    return name==prefix || (name.size()>prefix.size() &&
           name.compare(0,prefix.size(),prefix)==0 && name[prefix.size()]=='/');
  }
  Meter m_meter;
  std::uint64_t m_ordinal=0,m_researchEvents=0;
};
} // namespace hcraf_p12u
