"""Confirmation-only wrapper around the unchanged v66 native audit."""
import sys,pathlib,zipfile,io,csv,json,collections,subprocess,os,stat,math,shutil
from fractions import Fraction as F
P=pathlib.Path
sys.path.insert(0,str(P(__file__).resolve().parent.parent/'p12r66'))
import audit as a
import provenance as prov
DEV_SHA='00e81bb2adc87f3bc922afbcd646908326813480ca000c21d1cef1f4d66f6988'
DEV_RUN=46121410008; DEV_ART=15255451489; DEV_COMMIT='249d6570c05eaf20f7928ce9552176f630ed36c8'
SOURCE66='b242ab5941e4373105ac9c00c77a5f5d9dcf3caa4ed17f8c97d8bb4b5566cd20'
NORM_SHA='d70deaa2050eeb7b7c4b3e8b8d2aadb9d16d3e7956459dfc79998f82ed0cf4ab'
PILOT_SHA='d16a53b35ff07318edc396e31a4ce7f539bc52c9152b33d8aeca02af09abb4e2'
DEV_RECEIPT_SHA='d64956212e870d6ac042b71554c48c18793615ec630ea4e7d56d8a3d91e2302e'
IMPL_SHA='6cae68979203b85eb0cffea5bf19f98f3ead5a1ab9864736405389c0d451e6ac'
WORKFLOW='hcraf-stage1am-f3-p12r-direct-cost-confirm-v0.52.67.yml'
SOURCE='hcraf_stage1am_f3_p12r_direct_cost_confirm_v05267_sources.zip'
SEEDS=list(range(640201,640237)); SITES=a.SITES
RAW_FILES=set('background.csv candidate_reference.json command.txt devices.csv events.jsonl events.jsonl.background.jsonl events.jsonl.collection.jsonl events.jsonl.decisions.jsonl events.jsonl.states.jsonl features.csv local_events.csv overhead.csv probe.csv producer.csv queue_a.csv queue_b.csv schedule.csv simulator.log wire.csv'.split())
need=a.need

def safe_extract(zpath,out):
 need(not out.exists(),'EXTRACT_OVERWRITE');out.mkdir(parents=True)
 with zipfile.ZipFile(zpath) as z:
  names=z.namelist();need(len(names)==len(set(names)) and z.testzip() is None,'ZIP_CRC')
  for m in z.infolist():
   q=pathlib.PurePosixPath(m.filename);need(not q.is_absolute() and '..' not in q.parts and '\\' not in m.filename and not stat.S_ISLNK(m.external_attr>>16),'ZIP_PATH')
   z.extract(m,out)

def load_prereg(p):
 need(a.digest(p)==a.PREREG_SHA,'PREREG_SHA')
 with zipfile.ZipFile(p) as z:
  r=json.loads(z.read('prereg_result/PREREG_RECEIPT.json'));b={k:z.read('prereg_result/'+k) for k in ('PLAN.json','LOCKED_MATRIX.csv','LOCKED_SCHEDULE.csv')}
 need(r['status']=='PASS_P12R64_DIRECT_COST_DESIGN_LOCK_ONLY_NO_EXECUTION' and all(r[k]==v for k,v in a.LOCKS.items()) and r['simulations']==0,'PREREG_LOCK');need(all(a.sha(v)==r['files'][k] for k,v in b.items()),'PREREG_MEMBERS')
 plan=json.loads(b['PLAN.json']);need(plan['confirmation']['cases']==360 and plan['confirmation']['primary_cases']==144 and plan['confirmation']['primary_rows']==18144,'PLAN')
 def rows(k):return list(csv.DictReader(io.StringIO(b[k].decode())))
 cases=[x for x in rows('LOCKED_MATRIX.csv') if x['partition']=='confirmation'];s=collections.defaultdict(list)
 for x in rows('LOCKED_SCHEDULE.csv'):
  if x['partition']=='confirmation':s[int(x['seed']),x['site']].append(tuple(int(x[k]) for k in ('decision_index','decision_ns','selected_slot','cost_slot0','cost_slot1','cost_slot2')))
 need(len(cases)==360 and {(int(x['seed']),x['site'],x['arm']) for x in cases}=={(i,j,k) for i in SEEDS for j in SITES for k in 'ABCDE'},'CASE_SET');need(set(s)=={(i,j) for i in SEEDS for j in SITES},'SCHEDULE_SET')
 for v in s.values():
  need(len(v)==126 and [x[0] for x in v]==list(range(126)) and all(set(x[3:])=={10,20,30} and x[2] in (0,1,2) for x in v),'SCHEDULE')
  for i in range(0,126,9):need({(x[2],x[3+x[2]]) for x in v[i:i+9]}=={(k,c) for k in range(3) for c in (10,20,30)},'SCHEDULE_BLOCK')
 return cases,s,{k:a.sha(v) for k,v in b.items()}

def norm_read(p):
 need(a.digest(p)==NORM_SHA,'NORMALIZATION_SEAL');n=json.loads(p.read_text());need(n['status']=='FROZEN_DEV_NORMALIZATION_ONLY' and all(n[k]==v for k,v in a.LOCKS.items()) and n['rc_min']==10 and n['rc_max']==30 and n['training_rows']==15120 and n['nonmissing']==14749 and n['missing_normalized']==1,'NORMALIZATION_FIELDS');lo,hi=F(*n['srtt_p1_ns']),F(*n['srtt_p99_ns']);need(0<lo<hi,'NORMALIZATION_RANGE');return n

def check_dev(zpath,out):
 need(a.digest(zpath)==DEV_SHA,'DEV_ZIP');safe_extract(zpath,out);p=out/'p12r66_pilot';d=out/'p12r66_dev';i=out/'p12r66_preflight/IMPLEMENTATION_RECEIPT.json'
 need(a.digest(p/'PARTITION_RECEIPT.json')==PILOT_SHA and a.digest(d/'PARTITION_RECEIPT.json')==DEV_RECEIPT_SHA and a.digest(i)==IMPL_SHA,'DEV_RECEIPT_SEALS')
 pr=a.verify_partition(p,'pilot');dr=a.verify_partition(d,'development');n=norm_read(d/'NORMALIZATION.json');impl=json.loads(i.read_text());need(impl['source_archive_sha256']==SOURCE66 and impl['run_id']==str(DEV_RUN) and impl['head_sha']==DEV_COMMIT and impl['prereg_sha256']==a.PREREG_SHA,'IMPL_ORIGIN')
 need(dr['pilot_receipt_sha256']==PILOT_SHA and dr['normalization_sha256']==NORM_SHA and not dr['AP_computed'] and dr['model_fits']==dr['confirmation_cases']==dr['official_F3_labels_constructed']==0 and pr['decisions']==3780 and dr['decisions']==15120,'DEV_FENCES')
 return n

def provenance(out):
 current=int(os.environ['GITHUB_RUN_ID']);head=os.environ['GITHUB_SHA'];need(os.environ['GITHUB_RUN_ATTEMPT']=='1' and os.environ['GITHUB_RUN_NUMBER']=='1','FIRST_ONLY')
 prior=dict(prov.PRIOR);prior[DEV_RUN]=DEV_COMMIT
 for rid,c in prior.items():
  r=prov.api('/actions/runs/'+str(rid));need(r['status']=='completed' and r['conclusion']==('failure' if rid in (46069686033,prov.FAILED) else 'success') and r['head_sha']==c and r['run_attempt']==1,'PRIOR_RUN_'+str(rid));subprocess.check_call(['git','merge-base','--is-ancestor',c,'HEAD'])
 for rid,aid,h,c in [(prov.RID,prov.ART,a.PREREG_SHA,a.PREREG_COMMIT),(DEV_RUN,DEV_ART,DEV_SHA,DEV_COMMIT),(prov.FAILED,prov.FAILED_ART,prov.FAILED_SHA,prov.FAILED_COMMIT)]:
  r=prov.api('/actions/artifacts/'+str(aid));need(not r['expired'] and r['digest']=='sha256:'+h and r['workflow_run']['id']==rid and r['workflow_run']['head_sha']==c,'PARENT_ARTIFACT')
 old='hcraf-stage1am-f3-p12r-direct-cost-native-v0.52.'
 for wf,rid in [(old+'65.yml',prov.FAILED),(old+'66.yml',DEV_RUN)]:
  r=prov.api('/actions/workflows/'+wf+'/runs?per_page=100');need(r['total_count']==1 and len(r['workflow_runs'])==1 and r['workflow_runs'][0]['id']==rid,'PARENT_REPEAT')
 r=prov.api('/actions/runs/'+str(current));need(r['path']=='.github/workflows/'+WORKFLOW and r['head_sha']==head and r['run_attempt']==1,'CURRENT_RUN');r=prov.api('/actions/workflows/'+WORKFLOW+'/runs?per_page=100');need(r['total_count']<=1 and all(x['id']==current for x in r['workflow_runs']),'REPEAT')
 need(subprocess.check_output(['git','rev-parse','--is-shallow-repository'],text=True).strip()=='false','SHALLOW')
 allowed=set()
 for ref,paths in [(a.PREREG_COMMIT,['hcraf_stage1am_f3_p12r_direct_cost_prereg_v05264_sources.zip','.github/workflows/hcraf-stage1am-f3-p12r-direct-cost-prereg-v0.52.64.yml']),(prov.FAILED_COMMIT,['hcraf_stage1am_f3_p12r_direct_cost_native_v05265_sources.zip','.github/workflows/'+old+'65.yml']),(DEV_COMMIT,['hcraf_stage1am_f3_p12r_direct_cost_native_v05266_sources.zip','.github/workflows/'+old+'66.yml']),('HEAD',[SOURCE,'.github/workflows/'+WORKFLOW])]:
  for p in paths:allowed.add(subprocess.check_output(['git','rev-parse',ref+':'+p],text=True).strip())
 seen=set();hits=[];checked=archives=0
 for l in subprocess.check_output(['git','rev-list','--objects','HEAD'],text=True).splitlines():
  if ' ' not in l:continue
  oid,n=l.split(' ',1)
  if oid in seen or oid in allowed or not(prov.eligible(n) or prov.source_archive(n)):continue
  seen.add(oid)
  if subprocess.check_output(['git','cat-file','-t',oid],text=True).strip()!='blob':continue
  need(int(subprocess.check_output(['git','cat-file','-s',oid],text=True))<=128*1024*1024,'BLOB_SIZE');h,c=prov.scan(subprocess.check_output(['git','cat-file','blob',oid]),n);hits+=h;checked+=c;archives+=prov.source_archive(n)
 need(checked>0 and archives>0 and not hits,'NAMESPACE_COLLISION');return dict(status='PASS_CONFIRMATION_AUTHORIZED_ENGINEERING_ONLY',run_id=current,head_sha=head,source66_sha=SOURCE66,source67_sha=os.environ['P12R67_SOURCE_SHA256'],prereg_sha=a.PREREG_SHA,normalization_sha=NORM_SHA,dev_artifact=DEV_ART,checked_members=checked,checked_archives=archives,prior_runs=sorted(prior),scope='reachable tracked ancestry and known repository runs only',blocks=list(range(1,7)),**a.LOCKS)

def auth_read(p):
 r=json.loads((p/'AUTH.json').read_text());need(r['status']=='PASS_CONFIRMATION_AUTHORIZED_ENGINEERING_ONLY' and r['run_id']==int(os.environ['GITHUB_RUN_ID']) and r['head_sha']==os.environ['GITHUB_SHA'] and r['source66_sha']==SOURCE66 and r['source67_sha']==os.environ['P12R67_SOURCE_SHA256'] and r['prereg_sha']==a.PREREG_SHA and r['normalization_sha']==NORM_SHA and r['dev_artifact']==DEV_ART and r['blocks']==list(range(1,7)) and all(r[k]==v for k,v in a.LOCKS.items()),'AUTH');norm_read(p/'NORMALIZATION.json');return r

def block_cases(cases,b):
 need(1<=b<=6,'BLOCK');return [r for r in cases if int(r['seed']) in SEEDS[(b-1)*6:b*6]]

def run_block(prereg,auth,ns3,out,b):
 auth_read(auth);cases,sch,hashes=load_prereg(prereg);rows=block_cases(cases,b);need(len(rows)==60 and not out.exists(),'BLOCK_INIT');out.mkdir(parents=True)
 binary=ns3/'build/scratch'/a.BIN;need(binary.is_file(),'BINARY');bh=a.digest(binary)
 a.write(out/'BUILD_RECEIPT.json',dict(status='PASS_CONFIRM_BUILD_LOCK_BEFORE_SIMULATION',block=b,binary_sha=bh,auth_sha=a.digest(auth/'AUTH.json'),source66_sha=SOURCE66,simulations=0,**a.LOCKS))
 for r in rows:
  s=sch[int(r['seed']),r['site']];d=(out/r['seed']/r['site']/r['arm']).resolve();d.mkdir(parents=True);schedule=d/'schedule.csv'
  with schedule.open('w',newline='') as f:w=csv.writer(f,lineterminator='\n');w.writerow(('decision_index','decision_ns','selected_slot','cost_slot0','cost_slot1','cost_slot2'));w.writerows(s)
  opts={'run':r['seed'],'site':r['site'],'arm':r['arm'],'output':d,'schedule':schedule,'target':r['target_slot'],'rate':r['background_mbps'],'loss':r['error_ppm'],'delay':r['extra_propagation_ms'],'trafficStream':r['traffic_stream'],'errorStream':r['error_stream'],'streamBase':r['stream_base']};cmd=a.BIN+' '+' '.join('--%s=%s'%x for x in opts.items());(d/'command.txt').write_text(cmd+'\n')
  with (d/'simulator.log').open('w') as f:subprocess.run(['python3','./waf','--run-no-build',cmd],cwd=str(ns3),stdout=f,stderr=subprocess.STDOUT,check=True)
  a.audit_case(r,s,d);print('PASS_CONFIRM_CASE',r['seed'],r['site'],r['arm'],flush=True)
 need(a.digest(binary)==bh,'BINARY_CHANGED');a.write(out/'BLOCK_RECEIPT.json',dict(status='PASS_P12R67_BLOCK_ENGINEERING_ONLY_NO_SCORING',block=b,cases=60,decisions=7560,candidate_rows=22680,prereg_files=hashes,auth_sha=a.digest(auth/'AUTH.json'),binary_sha=bh,case_receipt_hashes={str(p.relative_to(out)):a.digest(p) for p in sorted(out.rglob('case_receipt.json'))},**a.LOCKS));verify_block(out,b,cases,sch,hashes,auth)

def verify_block(out,b,cases,sch,hashes,auth):
 r=json.loads((out/'BLOCK_RECEIPT.json').read_text());need(r['status']=='PASS_P12R67_BLOCK_ENGINEERING_ONLY_NO_SCORING' and r['block']==b and r['cases']==60 and r['decisions']==7560 and r['candidate_rows']==22680 and r['prereg_files']==hashes and r['auth_sha']==a.digest(auth/'AUTH.json') and all(r[k]==v for k,v in a.LOCKS.items()),'BLOCK_RECEIPT')
 build=json.loads((out/'BUILD_RECEIPT.json').read_text());need(build['status']=='PASS_CONFIRM_BUILD_LOCK_BEFORE_SIMULATION' and build['block']==b and build['binary_sha']==r['binary_sha'] and len(r['binary_sha'])==64 and build['auth_sha']==r['auth_sha'] and build['source66_sha']==SOURCE66 and build['simulations']==0 and all(build[k]==v for k,v in a.LOCKS.items()),'BUILD_SEAL')
 expected={f"{x['seed']}/{x['site']}/{x['arm']}/case_receipt.json":x for x in block_cases(cases,b)};need(set(expected)==set(r['case_receipt_hashes'])=={str(p.relative_to(out)) for p in out.rglob('case_receipt.json')},'BLOCK_CASES');result=[];expected_files={'BLOCK_RECEIPT.json','BUILD_RECEIPT.json'}
 for n,x in expected.items():
  p=out/n;need(a.digest(p)==r['case_receipt_hashes'][n],'CASE_SEAL');c=json.loads(p.read_text());need(c['case']==x and c['status']=='PASS_P12R66_CASE_ENGINEERING_ONLY' and c['decisions']==c['reference_rows']==126 and c['all_candidate_feature_rows']==378 and all(c[k]==v for k,v in a.LOCKS.items()),'CASE_RECEIPT')
  need(set(c['files'])==RAW_FILES and all(P(k).name==k for k in c['files']) and set(c['files'])=={q.name for q in p.parent.iterdir() if q.is_file() and q.name!='case_receipt.json'},'RAW_SET');need(all(a.digest(p.parent/k)==v for k,v in c['files'].items()),'RAW_SEAL');expected_files.add(n);expected_files.update(str((p.parent/k).relative_to(out)) for k in c['files'])
  rows=json.loads((p.parent/'candidate_reference.json').read_text());s=sch[int(x['seed']),x['site']];need(len(rows)==126 and len({v['pit_instance_id'] for v in rows})==126,'ROWS')
  for v,(i,t,k,*cost) in zip(rows,s):need((v['decision_id'],v['time_ns'],v['slot'],v['rc'])==(i+1,t,k,cost[k]) and v['g'] in (0,1) and v['candidate_future_class']==int(4*v['future_queue_area_packet_ns']>=32*a.H) and (v['srtt_ns'] is None or type(v['srtt_ns']) is int and 0<v['srtt_ns']<=10**9),'ROW_ALIGNMENT')
  need(c['all_positive']==sum(v['candidate_future_class'] for v in rows) and c['target_positive']==sum(v['candidate_future_class'] for v in rows if v['slot']==int(x['target_slot'])) and c['g_positive']==sum(v['g'] for v in rows) and c['srtt_nonmissing']==sum(v['srtt_ns'] is not None for v in rows) and sum(c['outcomes'].values())==126,'ROW_TOTALS');result.append((c,rows))
 need(expected_files=={str(p.relative_to(out)) for p in out.rglob('*') if p.is_file()},'UNEXPECTED_BLOCK_FILE')
 return result

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['preflight','block']);p.add_argument('--prereg',type=P,required=True);p.add_argument('--auth',type=P,required=True);p.add_argument('--dev',type=P);p.add_argument('--ns3',type=P);p.add_argument('--out',type=P);p.add_argument('--block',type=int);q=p.parse_args()
 if q.mode=='preflight':
  load_prereg(q.prereg);r=provenance(q.auth);check_dev(q.dev,q.out);q.auth.mkdir();shutil.copyfile(q.out/'p12r66_dev/NORMALIZATION.json',q.auth/'NORMALIZATION.json');a.write(q.auth/'AUTH.json',r);auth_read(q.auth);print(r['status'])
 else:run_block(q.prereg,q.auth,q.ns3,q.out,q.block)
