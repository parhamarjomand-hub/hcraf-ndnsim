import unittest, tempfile, pathlib, json, os
from fractions import Fraction as F
import confirm as c
import analysis67 as m
class Tests(unittest.TestCase):
 def test_ap_ties(self):self.assertAlmostEqual(m.ap([3,3,1,1],[1,0,1,0]),.5)
 def test_ap_perfect(self):self.assertEqual(m.ap([4,3,2,1],[1,1,0,0]),1)
 def test_ap_reversed(self):self.assertAlmostEqual(m.ap([3,2,1],[0,0,1]),1/3)
 def test_ap_single_class(self):
  with self.assertRaises(RuntimeError):m.ap([1,2],[0,0])
 def test_score_missing(self):self.assertEqual(m.score(dict(rc=30,srtt_ns=None,g=1),dict(srtt_p1_ns=[1,1],srtt_p99_ns=[3,1])),(2000000,3000000))
 def test_score_exact_tie(self):self.assertEqual(m.score(dict(rc=20,srtt_ns=2,g=0),dict(srtt_p1_ns=[1,1],srtt_p99_ns=[3,1])),(1000000,1000000))
 def test_quantization(self):self.assertEqual(m.score(dict(rc=10,srtt_ns=1,g=0),dict(srtt_p1_ns=[0,1],srtt_p99_ns=[2000000,1])),(0,0))
 def test_q7(self):self.assertEqual(m.q7([0.,10.],F(1,80)),.125)
 def test_bootstrap(self):
  d=m.draws(reps=10);self.assertEqual(d,m.draws(reps=10));self.assertTrue(all(len(x)==36 for x in d));r,b=m.contrast([.125]*36,d);self.assertEqual(r['ci97_5'],[.125,.125])
 def test_matrix(self):
  p=pathlib.Path(os.environ['P12R66_PREREG']);r,s,h=c.load_prereg(p);self.assertEqual(len(r),360);self.assertEqual([len(c.block_cases(r,b)) for b in range(1,7)],[60]*6);self.assertEqual(len(s),72)
 def test_norm(self):
  p=os.environ.get('TEST_NORM');
  if p:self.assertEqual(c.norm_read(pathlib.Path(p))['nonmissing'],14749)
  else:self.assertEqual(len(c.NORM_SHA),64)
 def test_no_go_and_single_class(self):
  # Synthetic fixed outcomes, not historical or confirmation data.
  data=[]
  for seed in c.SEEDS:
   for j in c.SITES:
    for k in 'ABCDE':
     rows=[dict(decision_id=i+1,slot=i%3,rc=10+10*(i%3),srtt_ns=20,g=int(j=='local_forward' and k in 'BE' and i%2==0),candidate_future_class=int(k in 'BE' and i%2==0)) for i in range(126)]
     r=dict(case=dict(seed=seed,site=j,arm=k),all_positive=sum(x['candidate_future_class'] for x in rows),g_positive=sum(x['g'] for x in rows),target_positive=21 if k in 'BE' else 0,srtt_nonmissing=126,receiver_errors=20 if k in 'CE' else 0,eligible_receiver_packets=1000,mean_target_queue_wait_ns=100 if k in 'BE' else 1)
     data.append((r,rows))
  # Remote has same AP; local can improve. Verify a synthetic PASS then force a negative-control failure.
  with tempfile.TemporaryDirectory() as td:
   p=pathlib.Path(td);n=dict(srtt_p1_ns=[10,1],srtt_p99_ns=[30,1]);r=m.analyze(data,n,p/'pass');self.assertTrue(r['status'].startswith('PASS_'));self.assertFalse(r['F3_ready'])
   for r,v in data:
    if r['case']['arm']=='A':
     r['g_positive']=126
     for x in v:x['g']=1
   r=m.analyze(data,n,p/'mixed');self.assertTrue(r['status'].startswith('NO_GO'));self.assertEqual(r['primary_cases'],144);self.assertFalse(r['F3_ready']);self.assertEqual(r['prediction']['sites']['producer_return']['mean'],0.)
   next(r for r,v in data if r['case']['arm']=='B')['all_positive']=0
   r=m.analyze(data,n,p/'single');self.assertTrue(r['status'].startswith('INDETERMINATE'));self.assertFalse((p/'single'/'RUN_AP.csv').exists())
 def test_block_seals(self):
  import audit as a
  cases,sch,h=c.load_prereg(pathlib.Path(os.environ['P12R66_PREREG']))
  with tempfile.TemporaryDirectory() as td:
   p=pathlib.Path(td);out=p/'block';out.mkdir();auth=p/'auth';auth.mkdir();a.write(auth/'AUTH.json',{'test':'synthetic'});ah=a.digest(auth/'AUTH.json');bh='a'*64
   a.write(out/'BUILD_RECEIPT.json',dict(status='PASS_CONFIRM_BUILD_LOCK_BEFORE_SIMULATION',block=1,binary_sha=bh,auth_sha=ah,source66_sha=c.SOURCE66,simulations=0,**a.LOCKS))
   seals={}
   for r in c.block_cases(cases,1):
    d=out/r['seed']/r['site']/r['arm'];d.mkdir(parents=True);vs=[dict(decision_id=i+1,time_ns=t,slot=k,rc=cost[k],g=0,candidate_future_class=0,future_queue_area_packet_ns=0,srtt_ns=None,pit_instance_id=i+1) for i,t,k,*cost in sch[int(r['seed']),r['site']]];a.write(d/'candidate_reference.json',vs)
    for k in c.RAW_FILES-{'candidate_reference.json'}:(d/k).write_text('test')
    a.write(d/'case_receipt.json',dict(case=r,status='PASS_P12R66_CASE_ENGINEERING_ONLY',decisions=126,reference_rows=126,all_candidate_feature_rows=378,all_positive=0,target_positive=0,g_positive=0,srtt_nonmissing=0,outcomes={'TIMEOUT':126},files={x.name:a.digest(x) for x in d.iterdir()},**a.LOCKS));seals[str((d/'case_receipt.json').relative_to(out))]=a.digest(d/'case_receipt.json')
   a.write(out/'BLOCK_RECEIPT.json',dict(status='PASS_P12R67_BLOCK_ENGINEERING_ONLY_NO_SCORING',block=1,cases=60,decisions=7560,candidate_rows=22680,prereg_files=h,auth_sha=ah,binary_sha=bh,case_receipt_hashes=seals,**a.LOCKS))
   self.assertEqual(len(c.verify_block(out,1,cases,sch,h,auth)),60)
   (d/'background.csv').write_text('tampered')
   with self.assertRaises(RuntimeError):c.verify_block(out,1,cases,sch,h,auth)
if __name__=='__main__':unittest.main()
