"""Locked v64 direct-Cost confirmatory analysis. No fitting or pooled primary AP."""
import csv,random,math,statistics,sys,pathlib,json,collections,os,time,urllib.request
from fractions import Fraction as F
import confirm as c
import audit as a
P=pathlib.Path;need=a.need

def ap(keys,labels):
 need(len(keys)==len(labels)>0 and set(labels)=={0,1},'AP_MIXED');g=collections.defaultdict(lambda:[0,0])
 for k,y in zip(keys,labels):g[k][0]+=y;g[k][1]+=1
 p=sum(labels);tp=n=0;v=F(0)
 for k,(pos,tot) in sorted(g.items(),reverse=True):
  tp+=pos;n+=tot;v+=F(pos*tp,p*n)
 return float(v)

def score(row,norm):
 r=(row['rc']-10)*50000;lo,hi=F(*norm['srtt_p1_ns']),F(*norm['srtt_p99_ns']);s=1000000 if row['srtt_ns'] is None else round(1000000*max(F(0),min(F(1),(row['srtt_ns']-lo)/(hi-lo))));need(0<=r<=1000000 and 0<=s<=1000000 and row['g'] in (0,1),'SCORE_RANGE');return r+s,r+s+1000000*row['g']

def mean(x):return math.fsum(x)/len(x)
def q7(v,p):
 x=sorted(v);i,rem=divmod((len(x)-1)*p.numerator,p.denominator);return x[i]+float(F(rem,p.denominator))*(x[min(i+1,len(x)-1)]-x[i])
def draws(n=36,reps=10000):
 r=random.Random(640064);return [[r.randrange(n) for _ in range(n)] for _ in range(reps)]
def contrast(values,ds):
 need(len(values)==36 and all(math.isfinite(v) for v in values),'CONTRAST_INVALID');b=[mean([values[i] for i in d]) for d in ds];return dict(mean=mean(values),positive_seeds=sum(v>0 for v in values),ci97_5=[q7(b,F(1,80)),q7(b,F(79,80))]),b

def analyze(data,norm,out):
 need(len(data)==360,'TOTAL_CASES');out.mkdir(parents=True,exist_ok=False);by={(int(r['case']['seed']),r['case']['site'],r['case']['arm']):(r,v) for r,v in data};need(len(by)==360 and set(by)=={(s,j,k) for s in c.SEEDS for j in c.SITES for k in 'ABCDE'},'GLOBAL_CASE_SET')
 primary=[(r,v) for r,v in data if r['case']['arm'] in 'BE'];need(len(primary)==144,'PRIMARY_COUNT');allrows=[x for r,v in data for x in v];need(len(allrows)==45360,'TOTAL_ROWS')
 ds=draws();gates={};gates['complete_rows']=True;gates['primary_runs_mixed']=all(0<r['all_positive']<126 for r,v in primary);gates['srtt_pooled']=sum(r['srtt_nonmissing'] for r,v in data)*10>=45360*9;gates['srtt_primary']=all(r['srtt_nonmissing']*5>=126*4 for r,v in primary);gates['local_g_variation']=all(0<sum(by[s,'local_forward',k][0]['g_positive'] for k in 'BE')<252 for s in c.SEEDS);gates['rc_support']={x['rc'] for x in allrows}=={10,20,30}
 physical={};boot={};seedvals={}
 for name,k1,k0 in [('B-A','B','A'),('E-C','E','C'),('C-A','C','A'),('D-A','D','A')]:
  per={j:[(by[s,j,k1][0]['target_positive']-by[s,j,k0][0]['target_positive'])/42 for s in c.SEEDS] for j in c.SITES};v=[mean([per[j][i] for j in c.SITES]) for i in range(36)];r,b=contrast(v,ds);physical[name]=dict(r,per_site={j:mean(per[j]) for j in c.SITES});boot[name]=b;seedvals[name]=v
  gates['physical_'+name]=(r['mean']>=.20 and r['ci97_5'][0]>0 and r['positive_seeds']>=27) if name in ('B-A','E-C') else (r['ci97_5'][0]>=-.05 and r['ci97_5'][1]<=.05)
 for k1,k0 in [('B','A'),('E','C')]:
  name='wait_'+k1+'-'+k0;v=[mean([by[s,j,k1][0]['mean_target_queue_wait_ns']-by[s,j,k0][0]['mean_target_queue_wait_ns'] for j in c.SITES]) for s in c.SEEDS];need(all(math.isfinite(x) for x in v),'WAIT_INVALID');r,b=contrast(v,ds);physical[name]=r;boot[name]=b;seedvals[name]=v;gates[name]=r['positive_seeds']>=27
 loss={};controls={}
 for k in 'ABCDE':
  rr=[r for r,v in data if r['case']['arm']==k];e=sum(r['receiver_errors'] for r in rr);n=sum(r['eligible_receiver_packets'] for r in rr);need(n>0,'LOSS_DENOM');loss[k]=dict(errors=e,eligible=n,rate=e/n);gates['loss_'+k]=F(5,1000)<=F(e,n)<=F(5,100) if k in 'CE' else e==0
  if k in 'ACD':
   controls[k]={'g_rate':sum(r['g_positive'] for r in rr)/(len(rr)*126),'positive':sum(r['all_positive'] for r in rr),'by_site':{j:sum(r['g_positive'] for r in rr if r['case']['site']==j)/(36*126) for j in c.SITES}};gates['control_g_'+k]=controls[k]['g_rate']<=.05
 # Physical fidelity and causal reconstruction are enforced per case before this analysis.
 gates['engineering_fidelity']=True # all 360 cases passed unchanged audit_case plus raw seals
 pred={};runrows=[];score_rows=[];mixed=gates['primary_runs_mixed']
 for (s,j,k),(r,vs) in sorted(by.items()):
  keys=[score(x,norm) for x in vs];ys=[x['candidate_future_class'] for x in vs];p=sum(ys)/126
  for x,(base,full) in zip(vs,keys):score_rows.append((s,j,k,x['decision_id'],x['slot'],x['rc'],x['srtt_ns'],x['g'],x['candidate_future_class'],base,full))
  if mixed and k in 'BE':
   ab,af=ap([x[0] for x in keys],ys),ap([x[1] for x in keys],ys);runrows.append(dict(seed=s,site=j,arm=k,ap_base=ab,ap_full=af,delta=af-ab,prevalence=p))
 for k in 'ACD':
  z=[x for x in score_rows if x[2]==k];controls[k]['score_summary']={name:{'min':min(x[i] for x in z)/den,'mean':mean([x[i] for x in z])/den,'max':max(x[i] for x in z)/den} for name,i,den in [('base',9,2000000),('full',10,3000000)]}
 if mixed:
  v=[mean([x['delta'] for x in runrows if x['seed']==s]) for s in c.SEEDS];r,b=contrast(v,ds);boot['delta_ap']=b;seedvals['delta_ap']=v;pred.update(r,mean_ap_base=mean([x['ap_base'] for x in runrows]),mean_ap_full=mean([x['ap_full'] for x in runrows]),mean_prevalence=mean([x['prevalence'] for x in runrows]));pred['F3_base_diagnostic']=1-pred['mean_ap_base'];pred['F3_full_diagnostic']=1-pred['mean_ap_full'];pred['sites']={}
  for j in c.SITES:
   rr=[x for x in runrows if x['site']==j];v=[mean([x['delta'] for x in rr if x['seed']==s]) for s in c.SEEDS];p,b=contrast(v,ds);boot['delta_'+j]=b;seedvals['delta_'+j]=v;pred['sites'][j]=dict(p,mean_ap_base=mean([x['ap_base'] for x in rr]),mean_ap_full=mean([x['ap_full'] for x in rr]))
  gates['AP_gain']=r['mean']>=.02;gates['AP_vs_prevalence']=pred['mean_ap_full']>pred['mean_prevalence'];gates['AP_seed_consistency']=r['positive_seeds']>=27;gates['AP_bootstrap']=r['ci97_5'][0]>0;remote=pred['sites']['producer_return'];gates['remote_noninferiority']=remote['mean']>=-.02 and remote['ci97_5'][0]>=-.02
  with (out/'RUN_AP.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(runrows[0]));w.writeheader();w.writerows(runrows)
 with (out/'SCORES.csv').open('w',newline='') as f:w=csv.writer(f);w.writerow(['seed','site','arm','decision_id','slot','rc','srtt_ns','g','candidate_future_class','base_key','full_key']);w.writerows(score_rows)
 with (out/'RUN_COUNTS.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['seed','site','arm','selected','positive','negative','target_positive','g_positive','srtt_nonmissing','receiver_errors','eligible_receiver_packets','mean_target_queue_wait_ns']);w.writerows([[s,j,k,126,r['all_positive'],126-r['all_positive'],r['target_positive'],r['g_positive'],r['srtt_nonmissing'],r['receiver_errors'],r['eligible_receiver_packets'],r['mean_target_queue_wait_ns']] for (s,j,k),(r,v) in sorted(by.items())])
 status='INDETERMINATE_P12R67_PRIMARY_RUN_SINGLE_CLASS' if not mixed else ('PASS_P12R67_DIRECT_COST_GATES_ONLY_NO_F3_RELEASE' if all(gates.values()) else 'NO_GO_P12R67_CONJUNCTIVE_GATES_NOT_MET')
 with (out/'BOOTSTRAP.csv').open('w',newline='') as f:w=csv.writer(f);w.writerow(['replicate']+list(boot));w.writerows([[i+1]+[boot[k][i] for k in boot] for i in range(10000)])
 with (out/'SEED_CONTRASTS.csv').open('w',newline='') as f:w=csv.writer(f);w.writerow(['seed']+list(seedvals));w.writerows([[s]+[seedvals[k][i] for k in seedvals] for i,s in enumerate(c.SEEDS)])
 receipt=dict(status=status,gates=gates,physical=physical,loss=loss,controls=controls,prediction=pred,cases=360,selected_rows=45360,candidate_rows=136080,primary_cases=144,control_cases=216,bootstrap_reps=10000,prediction_bootstrap_reps=10000 if mixed else 0,invalid_replicates=0,bootstrap_draws_sha256=a.sha(json.dumps(ds,separators=(',',':')).encode()),primary_metric='equal mean of grouped tie AP across 144 prespecified B/E Runs',normalization_sha=c.NORM_SHA,prior_NO_GO_preserved=True,model_fits=0,official_F3_labels_constructed=0,heldout_rows_read=0,files={p.name:a.digest(p) for p in out.iterdir()},**a.LOCKS);a.write(out/'ANALYSIS_RECEIPT.json',receipt);print(status,flush=True);return receipt

def collect(prereg,auth,out):
 c.auth_read(auth);cases,s,hashes=c.load_prereg(prereg);rid=int(os.environ['GITHUB_RUN_ID']);head=os.environ['GITHUB_SHA'];want={f'hcraf-f3-p12r-direct-cost-confirm-block-{b}-v05267-run-{rid}':b for b in range(1,7)};auth_name=f'hcraf-f3-p12r-direct-cost-confirm-auth-v05267-run-{rid}'
 for _ in range(8):
  listing=c.prov.api(f'/actions/runs/{rid}/artifacts?per_page=100');arts={x['name']:x for x in listing['artifacts']}
  if set(arts)==set(want)|{auth_name} and len(listing['artifacts'])==7:break
  time.sleep(10)
 else:raise RuntimeError('INCOMPLETE_OR_EXTRA_ARTIFACTS_NO_SCORING')
 data=[];origins={};root=P('collected');root.mkdir()
 au=arts[auth_name];need(not au['expired'] and au['workflow_run']['id']==rid and au['workflow_run']['head_sha']==head,'AUTH_ORIGIN');z=root/'auth.zip';subprocess_download(au['id'],z);need(z.stat().st_size==au['size_in_bytes'] and 'sha256:'+a.digest(z)==au['digest'],'AUTH_ZIP_SEAL');d=root/'auth';c.safe_extract(z,d);need(a.digest(d/'AUTH.json')==a.digest(auth/'AUTH.json') and a.digest(d/'NORMALIZATION.json')==c.NORM_SHA,'AUTH_FILE_SEAL')
 for name,b in want.items():
  x=arts[name];need(not x['expired'] and x['workflow_run']['id']==rid and x['workflow_run']['head_sha']==head and x['digest'].startswith('sha256:'),'BLOCK_ORIGIN');z=root/f'{b}.zip';subprocess_download(x['id'],z);need(z.stat().st_size==x['size_in_bytes'] and 'sha256:'+a.digest(z)==x['digest'],'BLOCK_ZIP_SEAL');d=root/str(b);c.safe_extract(z,d);data.extend(c.verify_block(d,b,cases,s,hashes,auth));origins[str(b)]=dict(artifact_id=x['id'],sha256=a.digest(z),block_receipt_sha=a.digest(d/'BLOCK_RECEIPT.json'),binary_sha=json.loads((d/'BLOCK_RECEIPT.json').read_text())['binary_sha'])
 need(sys.version_info[:3]==(3,13,5),'BOOTSTRAP_PYTHON_VERSION');r=analyze(data,c.norm_read(auth/'NORMALIZATION.json'),out);a.write(out/'ORIGINS.json',dict(run_id=rid,head_sha=head,blocks=origins,auth_artifact_id=au['id'],auth_artifact_sha256=au['digest'],auth_sha=a.digest(auth/'AUTH.json'),analysis_receipt_sha=a.digest(out/'ANALYSIS_RECEIPT.json'),**a.LOCKS))

def subprocess_download(aid,p):
 import subprocess
 subprocess.check_call(['curl','--fail','--silent','--show-error','--location','--retry','3','--max-time','300','-H','Authorization: Bearer '+os.environ['GH_TOKEN'],'-H','Accept: application/vnd.github+json',f'https://api.github.com/repos/parhamarjomand-hub/hcraf-ndnsim/actions/artifacts/{aid}/zip','-o',str(p)])
if __name__=='__main__':collect(P(sys.argv[1]),P(sys.argv[2]),P(sys.argv[3]))
