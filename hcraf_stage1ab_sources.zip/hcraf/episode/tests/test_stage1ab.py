"""Unit-only fixtures. These are NOT ndnSIM measurements or research data."""
import collections
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

P=Path(__file__).resolve().parents[1]/'scripts'/'verify_stage1ab.py'
spec=importlib.util.spec_from_file_location('stage1ab_verify',P)
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)

class Stage1ABUnit(unittest.TestCase):
    def event(self,kind,time,dr,typ,name,uid,**extra):
        return {'event_type':kind,'time_ns':time,'node_id':dr[0],'device_index':dr[1],
            'ndn_packet_type':typ,'ndn_name':name,'ndn_nonce':1001 if typ=='INTEREST' else None,
            'packet_uid':uid,'packet_bytes':100,'data_rate_bps':1_000_000,'queue_wait_ns':None,
            'lp_status':'SINGLE_LP',**extra}
    def fixture(self):
        name='/hcraf/pilot/0';ev=[]
        for i,(dr,typ) in enumerate(zip(a.PATH_DIRECTIONS,('INTEREST','INTEREST','DATA','DATA'))):
            t=(10,30,50,70)[i];uid=20+i
            enq=self.event('QUEUE_ENQUEUE',t-1,dr,typ,name,uid)
            dq=self.event('QUEUE_DEQUEUE',t,dr,typ,name,uid);dq['queue_wait_ns']=1
            tx=self.event('PHY_TX_BEGIN',t,dr,typ,name,uid)
            txend=self.event('PHY_TX_END',t+2,dr,typ,name,uid)
            rx=self.event('MAC_RX',t+5,a.RECEIVER[dr],typ,name,100+uid)
            ev.extend((enq,dq,tx,txend,rx))
        hop1=[{'event_type':'TX_INTEREST','node_id':1,'name':name,'nonce':1001},
              {'event_type':'DATA_PIT_BIND_1U','node_id':1,'name':name,'time_ns':90,'pit_instance_id':1}]
        hop2=[{'event_type':'TX_INTEREST','node_id':2,'name':name,'nonce':1001},
              {'event_type':'DATA_PIT_BIND_1U','node_id':2,'name':name,'time_ns':75,'pit_instance_id':1}]
        ep={'episode_id':'e0','pit_instance_id':'1','start_ns':1,'end_ns':100,'name':name,
           'outcome':'SUCCESS','tx_nonces':[1001]}
        return ep,ev,hop1,hop2
    def test_complete_fixture(self):
        ep,e,x,y=self.fixture();valid,why,matched=a.complete_path(ep,e,x,y)
        self.assertTrue(valid,why);self.assertEqual(len(matched),4)
        self.assertEqual({tuple(k['sender']) for k in matched},set(a.PATH_DIRECTIONS))
    def test_no_global_uid_assumption(self):
        ep,e,x,y=self.fixture()
        for i,r in enumerate(e):
            if r['event_type']=='MAC_RX':r['packet_uid']=500+i
        self.assertTrue(a.complete_path(ep,e,x,y)[0])
    def test_drop_one_receive_is_unknown(self):
        ep,e,x,y=self.fixture();e=[r for r in e if not (r['event_type']=='MAC_RX' and r['node_id']==1)]
        self.assertFalse(a.complete_path(ep,e,x,y)[0])
    def test_duplicate_receive_is_unknown(self):
        ep,e,x,y=self.fixture();v=next(r for r in e if r['event_type']=='MAC_RX' and r['node_id']==2)
        e.append(dict(v,packet_uid=999));self.assertFalse(a.complete_path(ep,e,x,y)[0])
    def test_nonce_mismatch_is_unknown(self):
        ep,e,x,y=self.fixture();x[0]['nonce']=500
        self.assertFalse(a.complete_path(ep,e,x,y)[0])
    def test_missing_pit_bind_is_unknown(self):
        ep,e,x,y=self.fixture();y.pop()
        self.assertFalse(a.complete_path(ep,e,x,y)[0])
    def test_wrong_pit_generation_is_unknown(self):
        ep,e,x,y=self.fixture();x[-1]['pit_instance_id']=22
        self.assertFalse(a.complete_path(ep,e,x,y)[0])
    def test_cancelled_is_not_negative(self):
        ep,e,x,y=self.fixture();ep['outcome']='CANCELLED'
        self.assertFalse(a.complete_path(ep,e,x,y)[0])
    def test_after_horizon_not_negative(self):
        ep,e,x,y=self.fixture();ep['end_ns']=ep['start_ns']+a.HORIZON_NS+1
        self.assertEqual(a.complete_path(ep,e,x,y)[1],'CENSORED_BY_HORIZON')
    def test_missing_tx_end_is_unknown(self):
        ep,e,x,y=self.fixture();e=[r for r in e if not (r['event_type']=='PHY_TX_END' and r['node_id']==1)]
        self.assertFalse(a.complete_path(ep,e,x,y)[0])
    def test_receive_before_tx_end_is_unknown(self):
        ep,e,x,y=self.fixture();e=[r for r in e if not (r['event_type']=='MAC_RX' and r['node_id']==2)]
        v=self.event('MAC_RX',9,(2,0),'INTEREST',ep['name'],222)
        e.append(v)
        self.assertFalse(a.complete_path(ep,e,x,y)[0])
    def test_missing_queue_wait_is_unknown(self):
        ep,e,x,y=self.fixture()
        for r in e:
            if r['event_type']=='QUEUE_DEQUEUE':r['queue_wait_ns']=None;break
        self.assertFalse(a.complete_path(ep,e,x,y)[0])
    def test_repeat_queue_packet_ambiguous(self):
        ep,e,x,y=self.fixture();v=next(r for r in e if r['event_type']=='QUEUE_DEQUEUE')
        e.append(dict(v));self.assertFalse(a.complete_path(ep,e,x,y)[0])
    def test_wait_threshold_exact_boundary(self):
        sample={'queue_wait_ns':1600000,'packet_bytes':100,'data_rate_bps':1000000}
        self.assertFalse(a.exceed_ratio(sample))
        sample['queue_wait_ns']+=1;self.assertTrue(a.exceed_ratio(sample))
    def test_missing_denominator_unknown(self):
        self.assertIsNone(a.exceed_ratio({'queue_wait_ns':1,'packet_bytes':0,'data_rate_bps':100}))
    def test_shared_link_forward_positive(self):
        r=self.event('QUEUE_DEQUEUE',100,(1,1),'INTEREST','/other',3)
        r['queue_wait_ns']=5_000_000
        x=a.pressure_stats([r],1,100)
        self.assertEqual(x['forward_high_wait'],1);self.assertEqual(x['return_high_wait'],0)
    def test_off_path_pressure_ignored(self):
        r=self.event('QUEUE_DEQUEUE',100,(3,1),'INTEREST','/other',3)
        r['queue_wait_ns']=5_000_000
        self.assertEqual(a.pressure_stats([r],1,100)['forward_high_wait'],0)
    def test_future_event_ignored(self):
        r=self.event('QUEUE_DROP',101,(1,1),'INTEREST','/other',3)
        self.assertEqual(a.pressure_stats([r],1,100)['forward_drops'],0)
    def test_management_drop_not_false_positive(self):
        r=self.event('QUEUE_DROP',100,(1,1),None,None,3)
        self.assertEqual(a.pressure_stats([r],1,100)['forward_drops'],0)
    def test_phy_rx_drop_separate(self):
        r=self.event('PHY_RX_DROP',100,(2,0),'INTEREST','/other',3)
        self.assertEqual(a.pressure_stats([r],1,100)['path_phy_drops'],1)
        self.assertEqual(a.pressure_stats([r],1,100)['forward_drops'],0)
    def test_missing_jsonl_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(a.EvidenceError):a.read_jsonl(Path(tmp)/'not_exist')
    def test_invalid_json_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'x.jsonl';p.write_text('{bad')
            with self.assertRaises(a.EvidenceError):a.read_jsonl(p)
    def test_no_training_semantics_in_script(self):
        text=P.read_text()
        self.assertIn("'FutureCongestion':None",text)
        self.assertIn("'final_F3_labels_created':0",text)
        self.assertNotIn('train_test_split',text)
    def test_requester_fragmentation_flag_is_local_and_compilable(self):
        # The requester has its own local `mixed` flag. The `fragmented`
        # flag belongs to main() and must never be referenced here.
        src=(P.parents[1]/'src'/'hcraf-stage1ab-pilot.cpp').read_text()
        start=src.index('  void StartApplication() override {')
        stop=src.index('\nprivate:',start)
        body=src[start:stop]
        self.assertIn('const bool mixed = m_mode == "mixed-fragmented";',body)
        self.assertIn('m_mode == "receive-loss" ? 40u : mixed ? 24u : 16u;',body)
        self.assertNotIn('fragmented ? 24u',body)

    def test_source_build_installs_headers(self):
        file=P.parent/'build_stage1ab.sh';t=file.read_text()
        self.assertIn('cp "$TASK/src/hcraf-stage1w-monitor.hpp" scratch/',t)
        self.assertIn('cp "$TASK/src/hcraf-stage1w-lp.hpp" scratch/',t)
        self.assertIn('cmp -s',t)
    def test_pilot_has_two_hops_and_no_label(self):
        p=P.parents[1]/'src'/'hcraf-stage1ab-pilot.cpp';t=p.read_text()
        self.assertIn('const bool mixed = true',t)
        self.assertIn('stage1ab_path_nodes',t)
        self.assertIn('\\"future_congestion\\":null',t)
    def test_run_random_groups_are_development(self):
        t=(P.parent/'run_stage1ab.sh').read_text()
        for run in ['6101','6102','6103']:self.assertIn(run,t)
        for run in ['2101','3101','4101','5101']:self.assertNotIn('run-'+run,t)

if __name__=='__main__':unittest.main()
