import copy
import os
import pathlib
import unittest
from audit_stage1am_f3_p12w_native_12_causal_v05242 import load_locked,audit_loaded,ARTIFACT_SHA

class P12W(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.archive=pathlib.Path(os.environ['P12W_ORIGINAL_ARTIFACT'])
        cls.original=load_locked(cls.archive)
    def clone(self):return copy.deepcopy(self.original)
    def test_original_digest(self):self.assertEqual(__import__('hashlib').sha256(self.archive.read_bytes()).hexdigest(),ARTIFACT_SHA)
    def test_full_audit_must_warn(self):
        o=audit_loaded(self.original)
        self.assertFalse(o['all_12_B1_features_fully_validated'])
        self.assertFalse(o['F3_ready'])
        self.assertFalse(o['training_ready'])
        self.assertFalse(o['native_Nack_path_physical_coverage_validated'])
        self.assertFalse(o['native_Drop_path_physical_coverage_validated'])
    def test_first_five_physical_exact(self):
        x=self.clone();x['p12v_native_local_12_at_decision.jsonl'][10]['b1_all_twelve_native'][4]+=1
        with self.assertRaisesRegex(ValueError,'FIRST_FIVE'):audit_loaded(x)
    def test_no_missing_decisions(self):
        x=self.clone();x['p12v_native_local_12_at_decision.jsonl'].pop()
        with self.assertRaisesRegex(ValueError,'FIXED_128'):audit_loaded(x)
    def test_no_fabricated_nack(self):
        x=self.clone();x['p12v_native_local_12_at_decision.jsonl'][-1]['b1_all_twelve_native'][7]=1
        with self.assertRaisesRegex(ValueError,'WINDOW_COUNTS'):audit_loaded(x)
    def test_no_fabricated_drop(self):
        x=self.clone();x['p12v_native_local_12_at_decision.jsonl'][-1]['b1_all_twelve_native'][9]=1
        with self.assertRaisesRegex(ValueError,'WINDOW_COUNTS'):audit_loaded(x)
    def test_no_future_decision_time(self):
        x=self.clone();x['p12v_native_local_12_at_decision.jsonl'][25]['time_ns']=x['p12v_native_local_12_at_decision.jsonl'][24]['time_ns']
        with self.assertRaises(ValueError):audit_loaded(x)
    def test_no_invented_feature(self):
        x=self.clone();x['p12v_native_local_12_at_decision.jsonl'][2]['b1_all_twelve_native'].append(23)
        with self.assertRaisesRegex(ValueError,'TWELVE'):audit_loaded(x)
    def test_no_ap(self):
        x=self.clone();x['P12V_NATIVE_12_HOOK_DEVELOPMENT_SMOKE_RECEIPT_v05241.json']['new_AP_computed']=True
        with self.assertRaises(ValueError):audit_loaded(x)
    def test_no_go(self):
        x=self.clone();x['P12V_NATIVE_12_HOOK_DEVELOPMENT_SMOKE_RECEIPT_v05241.json']['GO_FREEZE']=True
        with self.assertRaises(ValueError):audit_loaded(x)
    def test_no_heldout(self):
        x=self.clone();x['P12V_NATIVE_12_HOOK_DEVELOPMENT_SMOKE_RECEIPT_v05241.json']['heldout_reads']=1
        with self.assertRaises(ValueError):audit_loaded(x)
    def test_no_confirmatory_partition(self):
        x=self.clone();x['scenario.json']['research_partition']='CONFIRMATORY'
        with self.assertRaises(ValueError):audit_loaded(x)
    def test_rtt_requires_completed_event(self):
        x=self.clone();x['p12v_native_local_12_at_decision.jsonl'][0]['b1_all_twelve_native'][11]=0
        with self.assertRaisesRegex(ValueError,'RTT_MISSINGNESS'):audit_loaded(x)
    def test_window_counts_causal_bound(self):
        x=self.clone();x['p12v_native_local_12_at_decision.jsonl'][3]['b1_all_twelve_native'][5]=0
        with self.assertRaisesRegex(ValueError,'PREVIOUS_DECISION_DELTA'):audit_loaded(x)

if __name__=='__main__':unittest.main()
