#!/usr/bin/env python3
"""P12W v0.52.42: read-only 128-decision forensic QC; never trains/labels or unlocks F3.

Proves observable source/temporal invariants only; no guarantee all NFD hooks are
exercised, and no per-packet post-decision replay is made.
"""
import argparse
import hashlib
import json
import math
import pathlib
import zipfile

ARTIFACT_SHA='4d63c630f405ee6c7bca64906683888666ca7f3eb15bbc13d7346fc9b7edda49'
RUN_ID=45868303602
COUNTERS=(('live_NFD_interest_rx_total',5),('live_NFD_data_rx_total',6),
          ('live_NFD_nack_rx_total',7),('live_NFD_interest_tx_total',8),
          ('live_NFD_interest_drop_total',9))
LOOKBACK_NS=75_000_000
B1_NAMES=('fib_route_cost','local_selected_queue_packets','local_selected_queue_fraction',
          'local_selected_link_up','local_pit_occupancy_at_t',
          'local_interest_rx_count_previous_75ms','local_data_rx_count_previous_75ms',
          'local_nack_rx_count_previous_75ms','local_selected_face_tx_count_previous_75ms',
          'local_selected_face_drop_count_previous_75ms','local_data_rtt_ewma_before_t',
          'local_data_rtt_missing_at_t')

def require(test,reason):
    if not test:raise ValueError('P12W_FAIL_CLOSED_'+reason)

def load_locked(path,require_sha=True):
    b=pathlib.Path(path).read_bytes()
    if require_sha:require(hashlib.sha256(b).hexdigest()==ARTIFACT_SHA,'ORIGINAL_ARTIFACT_SHA')
    with zipfile.ZipFile(pathlib.Path(path)) as z:
        require(z.testzip() is None,'ARTIFACT_ZIP_CRC')
        required=['p12t_native_local_at_decision.jsonl','p12v_native_local_12_at_decision.jsonl',
                  'P12V_NATIVE_12_HOOK_DEVELOPMENT_SMOKE_RECEIPT_v05241.json',
                  'P12T_NATIVE_INTEGRATION_SENTINEL_RECEIPT_v05239.json','scenario.json']
        require(all(name in z.namelist() for name in required),'MISSING_REQUIRED_EVIDENCE')
        d={n:json.loads(z.read(n)) for n in required if n.endswith('.json')}
        for n in required:
            if n.endswith('.jsonl'):
                d[n]=[json.loads(x) for x in z.read(n).splitlines() if x.strip()]
    return d

def audit_loaded(data):
    r=data['P12V_NATIVE_12_HOOK_DEVELOPMENT_SMOKE_RECEIPT_v05241.json']
    old=data['P12T_NATIVE_INTEGRATION_SENTINEL_RECEIPT_v05239.json']
    sc=data['scenario.json']
    p=data['p12t_native_local_at_decision.jsonl']
    v=data['p12v_native_local_12_at_decision.jsonl']
    require(r['status']=='PASS_P12V_ONE_DEV_PINNED_LIVE_NFD_TWELVE_SLOTS_ONLY_NOT_FULL_FEATURE_VALIDATION', 'P12V_RECEIPT_STATUS')
    require(r['seed']==24901 and r['run_partition']=='P12R_FAIR_LOCAL_DEV' and r['cases']==1,'P12V_CASE_BOUND')
    require(r['native_decisions']==128 and r['twelve_feature_slots_observed'] is True,'P12V_DECISION_CONTRACT')
    require(r['fully_validated_12_feature_construct'] is False and not r['training_ready'],'FALSE_FEATURE_VALIDATION_REQUIRED')
    require(all(r[x]==0 for x in ('heldout_reads','confirmation_seed_reads','model_fits')) and not r['new_AP_computed'],'NO_FIT_CONFIRMATORY_AP')
    require(all(r[x] is False for x in ('F3_ready','GO_FREEZE','Stage1AO_or_NSGAIII_authorized')),'P12V_SCIENCE_LOCK')
    require(r['Congestion'] is None and r['FutureCongestion'] is None,'P12V_CONSTRUCT_NOT_RELEASED')
    require(old['seed']==24901 and old['complete_B1_valid'] is False and old['native_decision_snapshots']==128,'P12T_OLD_BOUND')
    require(sc['run']==24901 and sc['research_partition']=='FAIR_LOCAL_DEV' and sc['p12k_replication_site']=='producer_egress','FROZEN_DEV_CLASS')
    require(sc['schedule_contract']=='P12R_V05237_FAIR_LOCAL_DEV_PREREG_LOCKED_CSV','FROZEN_SCHEDULE')
    require(sc['telemetry_period_ms']==20 and sc['technical_queue_max_packets']==12,'P12R_DEV_CONDITIONS')
    require(len(p)==len(v)==128,'FIXED_128_ROWS')
    expected_face=v[0]['selected_face_id']
    require(expected_face>0,'INVALID_FACE_ID')
    all_rtt=[]
    prev=None
    for id,(x,y) in enumerate(zip(v,p),start=1):
        require(x['decision_id']==y['decision_id']==id,'DECISION_ID_ORDER')
        require(x['time_ns']==y['time_ns'],'PHYSICAL_DECISION_TIME_ALIGNMENT')
        require(x['node_id']==y['node_id']==1 and x['selected_face_id']==y['selected_face_id']==expected_face,'NODE_FACE_ID')
        require(x['source']=='NFD_LIVE_EVENT_SIGNALS_PLUS_NODE1_QUEUE_BEFORE_TX','NFD_SOURCE')
        require(x['hook_wiring_development_only'] is True and not x['all_B1_features_validated'] and not x['model_training_authorized'],'PER_DECISION_GATES')
        require(not x['F3_ready'] and not x['GO_FREEZE'],'NO_PER_DECISION_GO')
        feat=x['b1_all_twelve_native']; old5=y['b1_first_five_native']
        require(isinstance(feat,list) and len(feat)==len(B1_NAMES)==12,'TWELVE_NATIVE_SLOTS')
        require(all(isinstance(t,(int,float)) and not isinstance(t,bool) and math.isfinite(t) for t in feat),'FINITE_FEATURES')
        require(all(abs(feat[i]-old5[i])<1e-9 for i in range(5)),'FIRST_FIVE_IMMUTABLE_EQUIVALENCE')
        require(feat[1]>=0 and feat[1]<=12 and abs(feat[2]-feat[1]/12.0)<1e-8,'LOCAL_QUEUE_CAPACITY')
        require(feat[3] in (0,1) and feat[4]>=0,'LOCAL_LINK_PIT')
        require(all(feat[i]>=0 and feat[i]==int(feat[i]) for i in range(5,10)),'NONNEGATIVE_INTEGER_COUNTS')
        require(all(x[k]>=0 and isinstance(x[k],int) for k,_ in COUNTERS),'CUMULATIVE_NFD_TOTAL_TYPES')
        require(isinstance(x['locally_completed_RTT_total'],int) and x['locally_completed_RTT_total']>=0,'RTT_TOTAL_TYPE')
        require(all(feat[j]<=x[k] for k,j in COUNTERS),'WINDOW_COUNTS_BOUND_BY_CUMULATIVE')
        require(x['locally_completed_RTT_total']<=x['live_NFD_data_rx_total'],'RTT_NOT_EXCEED_DATA')
        require(feat[11]==(0 if x['locally_completed_RTT_total'] else 1),'RTT_MISSINGNESS')
        require((feat[10]>0) == (x['locally_completed_RTT_total']>0),'RTT_CAUSAL_COMPLETION')
        if prev is not None:
            require(x['time_ns']>prev['time_ns'],'STRICT_DECISION_TIME')
            require(all(x[k]>=prev[k] for k,_ in COUNTERS),'MONOTONIC_NFD_EVENT_TOTAL')
            require(x['locally_completed_RTT_total']>=prev['locally_completed_RTT_total'],'MONOTONIC_RTT_TOTAL')
            if x['time_ns']-prev['time_ns']<=LOOKBACK_NS:
                require(all(x[k]-prev[k]<=feat[j] for k,j in COUNTERS),'PREVIOUS_DECISION_DELTA_INSIDE_LOOKBACK')
        prev=x
        if x['locally_completed_RTT_total']:all_rtt.append(feat[10])
    totals={k:v[-1][k] for k,_ in COUNTERS}
    totals['locally_completed_RTT_total']=v[-1]['locally_completed_RTT_total']
    require(totals['live_NFD_interest_rx_total']==128,'ALL_INTEREST_EVENTS')
    require(totals['live_NFD_interest_tx_total']>0 and totals['live_NFD_data_rx_total']>0,'TX_DATA_EVENTS_PRESENT')
    require(totals['locally_completed_RTT_total']>0,'RTT_EVENTS_PRESENT')
    require(totals==r['live_hook_totals_at_final_decision'],'FINAL_TOTALS_MATCH_LOCKED_RECEIPT')
    require(totals['live_NFD_nack_rx_total']==0 and totals['live_NFD_interest_drop_total']==0,'NACK_DROP_NOT_OBSERVED_MUST_STAY_UNVALIDATED')
    require(r['nack_hook_exercised'] is False and r['drop_hook_exercised'] is False and r['rtt_hook_exercised'] is True,'EXERCISE_FLAGS')
    require(all(x['b1_all_twelve_native'][7]==x['b1_all_twelve_native'][9]==0 for x in v),'ZERO_WINDOW_NACK_DROP')
    return {'status':'PASS_P12W_CAUSAL_OBSERVABILITY_QC_ONLY_TWO_NATIVE_PATHS_UNEXERCISED',
      'parent_run_id':RUN_ID,'parent_artifact_sha256':ARTIFACT_SHA,
      'partition':'P12R_FAIR_LOCAL_DEV','development_seed':24901,'development_cases_audited':1,
      'native_decisions_authenticated':128,'B1_feature_count':len(B1_NAMES),'B1_feature_names':list(B1_NAMES),
      'first_five_retain_exact_p12t_physical_values':True,'all_native_twelve_slots_finite':True,
      'physical_node_face_selected':{'node':1,'face_id':expected_face},
      'nfd_event_totals_at_last_decision':totals,'local_pit_distinct_values':len({x['b1_all_twelve_native'][4] for x in v}),
      'local_queue_nonzero_decisions':sum(x['b1_all_twelve_native'][1]>0 for x in v),
      'RTT_EWMA_positive_decisions':len(all_rtt),
      'native_Nack_path_physical_coverage_validated':False,'native_Drop_path_physical_coverage_validated':False,
      'all_12_B1_features_fully_validated':False,'B1_training_authorized':False,
      'F3_ready':False,'GO_FREEZE':False,'training_ready':False,'Stage1AO_or_NSGAIII_authorized':False,
      'Congestion':None,'FutureCongestion':None,'heldout_reads':0,'confirmation_seed_reads':0,
      'model_fits':0,'new_AP_computed':False,'physical_cases_run_in_P12W':0,
      'next_recommended_gate':'P12X_EXPLORATORY_DEVELOPMENT_ONLY_NATIVE_NACK_DROP_PHYSICAL_PROBE',
      'scientific_interpretation':'Physical NFD Interest/Data/RTT evidence supports 12-slot implementation but cannot certify unexercised Nack/Drop channels; no new F3 GO.'}

def main():
    p=argparse.ArgumentParser();p.add_argument('--artifact',required=True);p.add_argument('--output',required=True);a=p.parse_args()
    rec=audit_loaded(load_locked(a.artifact))
    dest=pathlib.Path(a.output);dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(json.dumps(rec,sort_keys=True,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
    print(rec['status'],'decisions',rec['native_decisions_authenticated'],'missing Nack/Drop coverage','F3_ready',rec['F3_ready'])
if __name__=='__main__':main()
