#!/usr/bin/env python3
"""P4/P3: four historical-fixture, DEV-only physical queue relocation checks.

Never uses the P4 reserved seeds or constructs a model/official future label.
"""
import argparse
import json
import pathlib
import subprocess

from run_stage1am_f3_future_path_queue_calibration_v0521 import (
    ROOT, LOCKS, assert_send_plan, check, locked_plan, matrix,
)
from run_stage1am_f3_queue_telemetry_smoke_v0522 import (
    BIN, spec, verify_transport,
)
from run_stage1am_f3_queue_pressure_feasibility_v0523 import independent_queue_audit

DEST = ROOT / "episode_output/stage1am_f3_p4_physical_mapping_dev_v0526"
ARMS = {
    "MID_RETURN_12M": ("MID_RETURN", "mid"),
    "RELAY_RETURN_12M": ("RELAY_RETURN", "relay"),
}
PROFILES = (("baseline", False), ("telemetry20", True))
CAPACITY_PACKETS = 12
PLAN_HASH = "5518733b0d4db2d194c76d468cee870728419b34d56c049a92e5205f9aacc559"
P4_RESERVED_SEEDS = set(range(23101, 23105)) | set(range(24101, 24105)) | set(range(25101, 25105))


def fixtures():
    rows, _ = matrix()
    selected = [r for r in rows if r["arm"] in ARMS
                and r["rng_block"] == "22001"
                and r["family"] == "C_STAGGERED_BURSTS"
                and r["instrumented"] == "1"]
    check(len(selected) == len(ARMS) and
          {r["arm"] for r in selected} == set(ARMS), "P4P3_WRONG_OR_MISSING_FIXTURE")
    for row in selected:
        intervention, _ = ARMS[row["arm"]]
        check(row["split"] == "CALIBRATION" and row["selected_slot"] == "0" and
              row["seed"] == "17" and row["intervention_location"] == intervention and
              row["intervention_return_bps"] == "12000000" and
              row["schedule_sha256"] == PLAN_HASH and
              int(row["rng_block"]) not in P4_RESERVED_SEEDS,
              "P4P3_HISTORICAL_FIXTURE_OR_P4_SEED_VIOLATION")
    return sorted(selected, key=lambda r: list(ARMS).index(r["arm"]))


def location_gate(physical, role):
    """Require explicit physical QUEUE_DROP at the targeted, selected device 0."""
    senders = physical["selected_return_senders_device_0"]
    counts = {r: senders[r]["drops"] for r in ("relay", "mid", "producer")}
    target = counts[role]
    others = sum(v for k, v in counts.items() if k != role)
    check(sum(counts.values()) == physical["selected_path_physical_queue_drop_events"],
          "P4P3_SELECTED_PHYSICAL_WITNESS_COUNTER_MISMATCH")
    check(all(senders[r]["device_index"] == 0 for r in counts),
          "P4P3_WRONG_PHYSICAL_DEVICE")
    return {
        "target_role": role,
        "selected_device_index": 0,
        "physical_drops_by_sender_role": counts,
        "target_role_physical_queue_drops": target,
        "other_selected_roles_physical_queue_drops": others,
        "target_has_real_queue_drop": target > 0,
        "strict_target_exclusive_relocation": target > 0 and others == 0,
        "no_receiver_nonqueue_loss_counted": True,
        "label_is_diagnostic_not_official": True,
    }


def aggregate(results):
    check(len(results) == 4, "P4P3_EXPECTED_EXACTLY_FOUR_RUNS")
    pairs = []
    for arm in ARMS:
        match = [r for r in results if r["arm"] == arm]
        check({r["profile"] for r in match} == {"baseline", "telemetry20"},
              "P4P3_MISSING_CONTROL_PAIR")
        baseline = next(r for r in match if r["profile"] == "baseline")
        telemetry = next(r for r in match if r["profile"] == "telemetry20")
        passes = (baseline["localization"]["strict_target_exclusive_relocation"]
                  and telemetry["localization"]["strict_target_exclusive_relocation"])
        pairs.append({
            "arm": arm,
            "target_role": ARMS[arm][1],
            "baseline_target_drops": baseline["localization"]["target_role_physical_queue_drops"],
            "telemetry20_target_drops": telemetry["localization"]["target_role_physical_queue_drops"],
            "strict_exclusive_physical_relocation_pair_pass": passes,
            "telemetry_transport_contract_pass": telemetry["transport"].get("telemetry_contract_pass"),
        })
    physical_pass = all(p["strict_exclusive_physical_relocation_pair_pass"] for p in pairs)
    telemetry_pass = all(p["telemetry_transport_contract_pass"] is True for p in pairs)
    return {
        "status": "PASS_DEV_PHYSICAL_RELOCATION_PREFLIGHT_ONLY" if physical_pass and telemetry_pass
                  else "NO_GO_DEV_PHYSICAL_RELOCATION_OR_TRANSPORT_UNVERIFIED",
        "technical_physical_relocation_pass": physical_pass,
        "technical_NDN_telemetry_transport_pass": telemetry_pass,
        "not_authorization_to_run_p4_144_scenarios": True,
        "next_science_gate": "REVIEW_P4_TOPOLOGY_SEEDS_ROUTE_DIVERSITY_CONTROLS_AND_PARTITION_LOCK",
        "scenario_count": len(results),
        "pairs": pairs,
        "results": results,
        "historical_v0520_traffic_schedule_only": True,
        "global_12_packet_capacity_outside_v0520_preregistration": True,
        "registered_v0520_matrix_unmodified": True,
        "reserved_p4_seeds_consumed": 0,
        "official_F3_labels_constructed": 0,
        "PR_AUC_computed": False,
        "training_executed": False,
        "heldout_runs_executed": 0,
        **LOCKS,
        "heldout_release_authorized": False,
    }


def run_one(row, profile, enabled):
    arm = row["arm"]
    intervention, role = ARMS[arm]
    dest = DEST / arm / profile
    dest.mkdir(parents=True, exist_ok=False)
    command = spec(row, dest, 20, enabled) + " --technicalQueueMaxPackets=12"
    (dest / "command.txt").write_text(command + "\n")
    (dest / "P4P3_TECHNICAL_DEVIATION.json").write_text(json.dumps({
        "stage": "P4_P3_v0.52.6_DEV_PHYSICAL_MAPPING",
        "historical_fixture_row": row,
        "global_queue_capacity_packets": CAPACITY_PACKETS,
        "original_v0520_capacity_packets": 20,
        "not_official_calibration": True,
        "not_p4_prospective_sample": True,
        "reserved_p4_seed_count_used": 0,
        "heldout_runs_executed": 0,
        **LOCKS,
        "heldout_release_authorized": False,
    }, indent=2) + "\n")
    with (dest / "simulator.log").open("w") as log:
        subprocess.run(["/usr/bin/time", "-f", "wall_seconds=%e\\nmax_rss_kib=%M",
                        "-o", str(dest / "resource_usage.txt"), "python3", "./waf",
                        "--run-no-build", command],
                       cwd=ROOT / "episode_sources/ns-3", stdout=log,
                       stderr=subprocess.STDOUT, check=True)
    assert_send_plan(dest, locked_plan(row))
    config = json.loads((dest / "scenario.json").read_text())
    check(config["holdout_partition"] == "CALIBRATION" and
          config["phase_arm"] == arm and
          config["intervention_location"] == intervention and
          config["intervention_return_bps"] == 12_000_000 and
          config["selected_face_slot"] == 0 and
          config["technical_queue_max_packets"] == CAPACITY_PACKETS and
          config["queue_capacity_packets"] == CAPACITY_PACKETS and
          config["v0520_locked_reference_queue_capacity_packets"] == 20 and
          config["p3_dev_global_queue_cap_override_not_in_v0520_lock"] is True and
          config["p3_queue_capacity_intervention_is_exploratory_only"] is True and
          config["only_locked_physical_intervention_varies"].startswith("NO_P3_DEV") and
          config["purpose"].startswith("P3_DEV_QUEUE_CAP_FEASIBILITY") and
          config["telemetry_enabled"] is enabled,
          "P4P3_PHYSICAL_SCENARIO_OR_DEVIATION_UNMARKED")
    for key, value in LOCKS.items():
        check(config[key] is value, "P4P3_SCIENCE_LOCK_BROKEN:" + key)
    physical = independent_queue_audit(dest, config)
    localization = location_gate(physical, role)
    check(localization["physical_drops_by_sender_role"][role] ==
          physical["selected_return_senders_device_0"][role]["drops"],
          "P4P3_ROLE_WITNESS_DISAGREEMENT")
    transport = {"telemetry_contract_pass": None, "telemetry_enabled": enabled}
    if enabled:
        try:
            transport = verify_transport(dest, True)
            transport["telemetry_contract_pass"] = True
        except (AssertionError, ValueError, RuntimeError, KeyError, OSError) as exc:
            transport = {"telemetry_enabled": True, "telemetry_contract_pass": False,
                         "transport_failure": str(exc)}
    else:
        check(not (dest / "queue_telemetry_receipts.jsonl").exists(),
              "P4P3_BASELINE_CONTAMINATED_WITH_TELEMETRY")
    result = {
        "arm": arm, "profile": profile, "telemetry_enabled": enabled,
        "queue_capacity_packets": CAPACITY_PACKETS,
        "physical": physical, "localization": localization,
        "transport": transport, "science_claim": "NONE_DEV_HISTORICAL_PHYSICAL_FIXTURE_ONLY",
        "heldout_runs_executed": 0,
        **LOCKS, "heldout_release_authorized": False,
    }
    (dest / "P4P3_PHYSICAL_MAPPING_AUDIT.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--preflight-only", action="store_true")
    args = parser.parse_args()
    rows = fixtures()
    if args.preflight_only:
        print(json.dumps({
            "status": "PASS_P4P3_FOUR_DEV_FIXTURES_PREFLIGHT_ONLY",
            "arms": [r["arm"] for r in rows],
            "profiles": [p[0] for p in PROFILES],
            "technical_runs_planned": 4,
            "historical_rng_block": "22001",
            "historical_schedule_sha256": PLAN_HASH,
            "experimental_capacity_packets": CAPACITY_PACKETS,
            "reserved_P4_rng_blocks_used": 0,
            "heldout_runs_executed": 0,
            **LOCKS, "heldout_release_authorized": False,
        }, indent=2))
        return
    check((ROOT / "episode_sources/ns-3/build/scratch" / BIN).is_file(),
          "P4P3_NDNSIM_BINARY_NOT_BUILT")
    check(not DEST.exists(), "P4P3_REFUSE_TO_OVERWRITE_PRIOR_RUN")
    results = []
    for row in rows:
        for profile, enabled in PROFILES:
            one = run_one(row, profile, enabled)
            results.append(one)
            print("P4P3_RUN_COMPLETE", row["arm"], profile,
                  one["localization"]["physical_drops_by_sender_role"], flush=True)
    report = aggregate(results)
    (DEST / "P4P3_PHYSICAL_MAPPING_SUMMARY.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k != "results"}, indent=2))


if __name__ == "__main__":
    main()
