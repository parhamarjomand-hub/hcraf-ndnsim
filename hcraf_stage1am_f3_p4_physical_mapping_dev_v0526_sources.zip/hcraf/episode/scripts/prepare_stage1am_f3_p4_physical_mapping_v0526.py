#!/usr/bin/env python3
"""Fail-closed scientific provenance and source restoration for P4/P3 v0.52.6.

The caller first authenticates the bytes of this module from the pinned v0526
archive and executes it in memory, before restoring any files to the worktree.
"""
import hashlib
import json
import os
import pathlib
import stat
import subprocess
import zipfile


ZIPS = (
    ("hcraf_stage1am_f3_mixed_sources.zip", "f21a132299e88fdee65397b7d846c3fa47bc7ee041dd6a161e7bd48651c925da", ".", None, None),
    ("hcraf_stage1s_approved_reference.zip", "b4fe49f0796ca6f12b2f140931e3158c6278dc5742309ea4c3f5f79c5502b8c4", "artifact", None, None),
    ("hcraf_stage1am_f3_pathwide_witness_dev_v0515_sources.zip", "bfbd90c638692ba241a161eaf5dcadfbc7dceae82ba4d5f236e863b2d849b28f", ".", "HCRAF_F3_PATHWIDE_WITNESS_DEV_V0515_SOURCE_SHA256.json", "files"),
    ("hcraf_stage1am_f3_future_path_queue_pressure_prereg_v0520_sources.zip", "0523ad0ef216426d128596fdf15bc91e1c78523346dab2bbd843c16cf139601e", ".", "HCRAF_F3_FUTURE_PATH_QUEUE_PRESSURE_V0520_SOURCE_SHA256.json", "source_files"),
    ("hcraf_stage1am_f3_future_path_queue_calibration_executor_v0521_sources.zip", "30ca65f18895d24c0b23f5e44fa8504737aa6b19c0093c48976b3a67568381cc", ".", "HCRAF_F3_FUTURE_PATH_QUEUE_CALIBRATION_EXECUTOR_V0521_SOURCE_SHA256.json", "files"),
    ("hcraf_stage1am_f3_queue_telemetry_dev_v0522_sources.zip", "76af91b0d94754f21b53922b412c5c7882a4612c1cb702d8c95764fbab5845c6", ".", "HCRAF_F3_QUEUE_TELEMETRY_V0522_SOURCE_SHA256.json", "files"),
)
P3_SOURCE = "hcraf_stage1am_f3_queue_pressure_feasibility_dev_v0523_sources.zip"
P3_SHA = "2864b8f1917ac38154dde24c42aaf1c03101eaf509c809c95a4113c1ce1ea382"
P3_MANIFEST = "HCRAF_F3_QUEUE_PRESSURE_FEASIBILITY_V0523_SOURCE_SHA256.json"
P4_SOURCE = "hcraf_stage1am_f3_p4_prospective_prereg_v0524_sources.zip"
P4_SHA = "7c8976a9ebee7b21d93979648d8be08e7586b54fc712c334d19d1177c1803577"
P4P2_SOURCE = "hcraf_stage1am_f3_p4_parent_evidence_audit_v0525_sources.zip"
P4P2_SHA = "ca6d351f77b00c722bac6e56de677a1f29cade6f39c5826571495e58a984a176"
P4P3_SOURCE = "hcraf_stage1am_f3_p4_physical_mapping_dev_v0526_sources.zip"
P4P3_MANIFEST = "HCRAF_F3_P4_PHYSICAL_MAPPING_V0526_SOURCE_SHA256.json"
PARENT_COMMITS = (
    "3808ddcebc4480eefbe64f0a16c69afd35f05dcd",  # v0.52.0
    "079cb06ae8cdef07abf6df3b2ff34b0607113b2a",  # P3
    "059c6485957450d2ffcf7bb2b2a46656bb6088e2",  # P4/P1
    "4e78a88ea11f16c315704838e3db8b291237d41b",  # P4/P2
)
LOCKS = {"Congestion": None, "FutureCongestion": None,
         "F3_ready": False, "GO_FREEZE": False, "training_ready": False,
         "heldout_release_authorized": False}


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def safe_members(z):
    names = z.namelist()
    assert len(names) == len(set(names)), "DUPLICATE_ZIP_MEMBER"
    assert z.testzip() is None, "BAD_ZIP_CRC"
    for name in names:
        part = pathlib.PurePosixPath(name)
        assert name and not name.startswith("/") and ".." not in part.parts and \
               "\\" not in name and not stat.S_ISLNK(z.getinfo(name).external_attr >> 16), \
               "UNSAFE_ZIP_MEMBER:" + name
    return names


def committed_zip(name, expected):
    blob = pathlib.Path(name).read_bytes()
    assert sha256(blob) == expected, "BAD_SOURCE_ZIP_SHA:" + name
    assert subprocess.check_output(["git", "show", "HEAD:" + name]) == blob, \
           "SOURCE_ZIP_NOT_COMMITTED_AT_HEAD:" + name
    return blob


def source_manifest(z, manifest_name, field):
    names = safe_members(z)
    info = json.loads(z.read(manifest_name))
    expected = info[field]
    assert isinstance(expected, dict) and set(names) == set(expected) | {manifest_name}, \
           "SOURCE_HASH_MANIFEST_MISMATCH"
    for name, expected_hash in expected.items():
        assert sha256(z.read(name)) == expected_hash, "CONTENT_SHA_MISMATCH:" + name
    return info


def restore_immutable_sources():
    for name, expected, root, manifest, field in ZIPS:
        with zipfile.ZipFile(pathlib.Path(name)) as z:
            assert sha256(pathlib.Path(name).read_bytes()) == expected, "PARENT_SHA_MISMATCH:" + name
            names = safe_members(z)
            if manifest:
                source_manifest(z, manifest, field)
            for member in names:
                if member.endswith("/"):
                    continue
                dst = pathlib.Path(root, member)
                payload = z.read(member)
                if dst.exists():
                    assert dst.read_bytes() == payload, "REFUSE_OVERWRITE_PARENT:" + member
                else:
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    dst.write_bytes(payload)
                if dst.suffix == ".sh":
                    dst.chmod(0o755)
            print("RESTORED_VERIFIED_PARENT", name, len(names), flush=True)


def restore_p3_overlay():
    with zipfile.ZipFile(P3_SOURCE) as z:
        info = source_manifest(z, P3_MANIFEST, "files")
        assert info["stage"] == "v0.52.3_P3_UNREGISTERED_PHYSICAL_QUEUE_CAPACITY_DEV_FEASIBILITY_ONLY"
        assert info["physical_queue_cap_p3_outside_original_v0520_lock"] is True
        for k, v in LOCKS.items():
            assert info[k] is v, "P3_SCIENCE_LOCK_BROKEN:" + k
        pending = []
        for name in info["files"]:
            dst = pathlib.Path(name)
            if name in info["parent_original_v0522_preimages_sha256"]:
                assert dst.is_file() and sha256(dst.read_bytes()) == info["parent_original_v0522_preimages_sha256"][name], \
                       "P3_PARENT_PREIMAGE_MISMATCH:" + name
            else:
                assert not dst.exists(), "REFUSE_OVERWRITE_P3:" + name
            pending.append((dst, z.read(name)))
        for dst, payload in pending:
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_bytes(payload)
    cpp = pathlib.Path("hcraf/episode/src/hcraf-stage1am-f3-queue-telemetry-smoke-v0522.cpp")
    assert sha256(cpp.read_bytes()) == "b46dfde6ac8e8ff5ca48f6add7f943bbf1fbb62adbe952a18661e2bbaeea7d3c"
    code = cpp.read_text()
    assert "interest->matchesData(*data)" in code
    assert "data->setFreshnessPeriod(::ndn::time::milliseconds(1000));" in code
    assert "technicalQueueMaxPackets!=8 && technicalQueueMaxPackets!=12 && technicalQueueMaxPackets!=20" in code
    print("PASS_P3_CUMULATIVE_P1_P2_CAPACITY_PATCH", flush=True)


def restore_v0526_overlay(expected_sha):
    with zipfile.ZipFile(P4P3_SOURCE) as z:
        info = source_manifest(z, P4P3_MANIFEST, "files")
        assert info["stage"] == "v0.52.6_P4_P3_DEV_PHYSICAL_MAPPING_ONLY"
        assert info["simulations_planned"] == 4
        assert info["new_P4_rng_blocks_consumed"] == 0
        assert info["original_v0520_prereg_unchanged"] is True
        for k, v in LOCKS.items():
            assert info[k] is v, "V0526_SCIENCE_LOCK_BROKEN:" + k
        pending = []
        for name in info["files"]:
            dst = pathlib.Path(name)
            assert not dst.exists(), "REFUSE_OVERWRITE_V0526:" + name
            pending.append((dst, z.read(name)))
        for dst, payload in pending:
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_bytes(payload)
    assert sha256(pathlib.Path(P4P3_SOURCE).read_bytes()) == expected_sha
    print("PASS_V0526_VERIFIED_FOUR_DEV_ONLY_SOURCE_OVERLAY", flush=True)


def main():
    expected = os.environ["V0526_SOURCE_SHA256"]
    assert len(expected) == 64 and all(c in "0123456789abcdef" for c in expected)
    committed_zip(P3_SOURCE, P3_SHA)
    committed_zip(P4_SOURCE, P4_SHA)
    committed_zip(P4P2_SOURCE, P4P2_SHA)
    committed_zip(P4P3_SOURCE, expected)
    for fn, expected_hash, _, _, _ in ZIPS:
        committed_zip(fn, expected_hash)
    for ancestor in PARENT_COMMITS:
        subprocess.check_call(["git", "merge-base", "--is-ancestor", ancestor, "HEAD"])
    receipt = json.loads(pathlib.Path(
        "episode_output/v0526_preflight/lock_artifact/prereg_lock_receipt.json").read_text())
    assert receipt["result"] == "PASS_V0520_CONSTRUCT_PREREG_LOCK_ONLY_NO_NDNSIM"
    assert receipt["git_commit_sha"] == PARENT_COMMITS[0]
    assert receipt["matrix_sha256"] == "920c190702526ad11efc10781ce23c629e7918932b4c52159fbfb96234600bd3"
    assert receipt["source_zip_sha256"] == ZIPS[3][1]
    assert str(receipt["github_run_id"]) == "43567814962"
    assert receipt["planned_runs"] == 648 and receipt["simulations_executed"] == 0
    assert not receipt["heldout_release_authorized"]
    for k, v in LOCKS.items():
        if k in receipt:
            assert receipt[k] is v, "V0520_SCIENCE_LOCK_BROKEN:" + k
    restore_immutable_sources()
    restore_p3_overlay()
    restore_v0526_overlay(expected)
    print("PASS_ALL_PARENT_HASHES_AND_LOCKS; NO_OFFICIAL_F3_LABELS", flush=True)


if __name__ == "__main__":
    main()
