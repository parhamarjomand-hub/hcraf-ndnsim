"""Offline safety and aggregation tests for P4/P3 v0.52.6."""
import unittest

from run_stage1am_f3_p4_physical_mapping_v0526 import (
    ARMS, P4_RESERVED_SEEDS, PROFILES, aggregate, fixtures, location_gate,
)


def physical(role, target_count, wrong_count=0):
    counts = {r: 0 for r in ("relay", "mid", "producer")}
    counts[role] = target_count
    wrong_role = "producer" if role != "producer" else "mid"
    counts[wrong_role] += wrong_count
    return {
        "selected_return_senders_device_0": {
            r: {"device_index": 0, "drops": drops} for r, drops in counts.items()
        },
        "selected_path_physical_queue_drop_events": sum(counts.values()),
    }


def four_results(mid_drops=1, relay_drops=2, remote_noise=0, transport_ok=True):
    results = []
    for arm, (_, role) in ARMS.items():
        for profile, enabled in PROFILES:
            loc = location_gate(physical(role, mid_drops if role == "mid" else relay_drops,
                                         remote_noise), role)
            results.append({"arm": arm, "profile": profile,
                            "localization": loc,
                            "transport": {"telemetry_contract_pass": transport_ok if enabled else None}})
    return results


class PhysicalMappingContractTests(unittest.TestCase):
    def test_only_previously_exposed_historical_rng_and_arms(self):
        rows = fixtures()
        self.assertEqual([r["arm"] for r in rows], list(ARMS))
        self.assertEqual({r["rng_block"] for r in rows}, {"22001"})
        self.assertFalse(22001 in P4_RESERVED_SEEDS)
        self.assertEqual(len(P4_RESERVED_SEEDS), 12)

    def test_target_drop_must_be_explicit_and_exclusive(self):
        self.assertFalse(location_gate(physical("mid", 0), "mid")
                         ["strict_target_exclusive_relocation"])
        self.assertTrue(location_gate(physical("relay", 4), "relay")
                        ["strict_target_exclusive_relocation"])
        self.assertFalse(location_gate(physical("mid", 5, 1), "mid")
                         ["strict_target_exclusive_relocation"])

    def test_all_physical_pairs_and_transport_required(self):
        good = aggregate(four_results())
        self.assertEqual(good["status"], "PASS_DEV_PHYSICAL_RELOCATION_PREFLIGHT_ONLY")
        self.assertTrue(good["technical_physical_relocation_pass"])
        self.assertTrue(good["technical_NDN_telemetry_transport_pass"])
        self.assertEqual(good["official_F3_labels_constructed"], 0)
        self.assertEqual(good["reserved_p4_seeds_consumed"], 0)
        self.assertFalse(good["F3_ready"])
        self.assertFalse(good["heldout_release_authorized"])

    def test_no_drop_means_no_go(self):
        report = aggregate(four_results(mid_drops=0))
        self.assertFalse(report["technical_physical_relocation_pass"])
        self.assertTrue(report["status"].startswith("NO_GO_"))

    def test_wrong_role_drop_means_no_go(self):
        report = aggregate(four_results(remote_noise=1))
        self.assertFalse(report["technical_physical_relocation_pass"])

    def test_lost_network_telemetry_means_no_go(self):
        report = aggregate(four_results(transport_ok=False))
        self.assertTrue(report["technical_physical_relocation_pass"])
        self.assertFalse(report["technical_NDN_telemetry_transport_pass"])
        self.assertTrue(report["status"].startswith("NO_GO_"))

    def test_no_scenario_count_shortcuts(self):
        with self.assertRaises(RuntimeError):
            aggregate(four_results()[:3])


if __name__ == "__main__":
    unittest.main()
