// Stage 1AM-F3 P12-X v0.52.43: TWO NEW EXPLORATORY NFD negative-path controls.
// This is NOT an eligible P12R trial; frozen P12R schedule is used only as a
// repeatable arrival stimulus. No AP, calibration, model fit, or GO authorized.
// DIAGNOSTIC ONLY: not complete B1 native hooks; no training or confirmatory seed access.
// Exact P12-K v0.52.19 frozen 48-case Validation, 128-event tail-probe schedule.
// All PILOT, Development and Heldout seeds are banned; no official F3 release.
// No F3 label, classifier, PR-AUC or heldout scenario is constructed here.
// No HCRAF policy evaluation, no labels, no use of post-decision events online.
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/ndnSIM-module.h"
#include "ns3/ndnSIM/apps/ndn-app.hpp"
#include "ns3/ndnSIM/model/ndn-l3-protocol.hpp"
#include "ns3/ndnSIM/NFD/daemon/fw/forwarder.hpp"
#include <fstream>
#include "hcraf-stage1am-f3-p12s-local-causal-meter-v05238.hpp"
#include "hcraf-stage1am-f3-p12u-local-nfd-hook-adapter-v05240.hpp"
#include "hcraf-collection-policy.hpp"
#include "hcraf-stage1w-monitor.hpp"
#include "hcraf-stage1am-local-snapshot.hpp"
#include "hcraf-stage1am-pathwide-witness-b.hpp"
#include <set>
#include "ns3/error-model.h"
#include <stdexcept>
#include <sstream>
#include <memory>
#include <chrono>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <limits>
#include <map>
#include <tuple>
#include <utility>
#include <iomanip>

namespace ns3 {
class HcrafRequester : public ns3::ndn::App {
public:
  static TypeId GetTypeId() {
    static TypeId tid = TypeId("ns3::HcrafRequester").SetParent<ns3::ndn::App>()
      .AddConstructor<HcrafRequester>();
    return tid;
  }
  void Configure(const std::string& mode, const std::string& output, uint32_t sourceId,
                 uint32_t requestOverride, uint64_t intervalOverrideNs, uint32_t lifetimeMs,
                 const std::string& prefix, const std::string& trafficClass,
                 int stream, uint64_t offsetNs, const std::string& scheduleFamily,
                 const std::string& scheduleCsv, uint64_t preregRun, uint32_t preregSlot,
                 const std::string& prospectiveLoad) {
    m_prefix=prefix; m_trafficClass=trafficClass; m_stream=stream; m_offsetNs=offsetNs; m_family=scheduleFamily;
    m_scheduleCsv=scheduleCsv; m_preregRun=preregRun; m_preregSlot=preregSlot;
    m_load=prospectiveLoad;
    m_requestOverride = requestOverride; m_intervalOverrideNs = intervalOverrideNs; m_lifetimeMs = lifetimeMs;
    m_mode = mode;
    m_sourceId = sourceId;
    m_nonce = 1000 + 10000 * sourceId;
    m_out.open(output);
    m_arrivals.open(output + ".arrivals.jsonl");
    if(!m_arrivals)throw std::runtime_error("Cannot open arrival schedule");
    m_arrivals << std::setprecision(17);
    if (!m_out) throw std::runtime_error("Cannot open consumer event file");
  }
  void OnData(std::shared_ptr<const ::ndn::Data> data) override {
    ns3::ndn::App::OnData(data);
    m_out << "{\"event\":\"DATA\",\"time_ns\":" << Simulator::Now().GetNanoSeconds()
          << ",\"name\":" << hcraf::Recorder::quote(data->getName().toUri())
          << ",\"payload_bytes\":" << data->getContent().value_size() << "}\n";
    m_out.flush();
  }
  void OnNack(std::shared_ptr<const ::ndn::lp::Nack> nack) override {
    ns3::ndn::App::OnNack(nack);
    m_out << "{\"event\":\"NACK\",\"time_ns\":" << Simulator::Now().GetNanoSeconds()
          << ",\"name\":" << hcraf::Recorder::quote(nack->getInterest().getName().toUri())
          << ",\"reason\":" << static_cast<int>(nack->getReason()) << "}\n";
    m_out.flush();
  }
protected:
  void StartApplication() override {
    ns3::ndn::App::StartApplication();
    // Consume only SHA-committed P12-R FAIR_LOCAL_DEV schedules.
    const uint32_t requests=m_requestOverride;
    if ((m_trafficClass=="TARGET" && requests!=12u) ||
        (m_trafficClass=="INDEPENDENT_COMPETITOR" && requests!=116u) ||
        m_family!="P12R_NEW_FAIR_COMPARATOR_PROSPECTIVE_PREREG_ONLY" ||
        (m_load!="low_control" && m_load!="high_pressure"))
      throw std::runtime_error("OUTSIDE_FROZEN_P12R_REPLICATION_SCHEDULE_CLASS");
    if (m_scheduleCsv.empty()) throw std::runtime_error("MISSING_LOCKED_SCHEDULE_CSV");
    const std::string lockedPrefix="p12r-v05237-fair_local_dev-seed-"+std::to_string(m_preregRun)+"-";
    const std::string lockedSuffix="-slot-"+std::to_string(m_preregSlot)+"-"+m_load+".csv";
    const size_t slash=m_scheduleCsv.find_last_of("/\\");
    const std::string lockedFilename=m_scheduleCsv.substr(slash==std::string::npos ? 0 : slash+1);
    if (lockedFilename.size()<=lockedPrefix.size()+lockedSuffix.size() ||
        lockedFilename.substr(0,lockedPrefix.size())!=lockedPrefix ||
        lockedFilename.substr(lockedFilename.size()-lockedSuffix.size())!=lockedSuffix)
      throw std::runtime_error("PREREG_SCHEDULE_FILENAME_MISMATCH");
    std::ifstream plan(m_scheduleCsv);
    if (!plan) throw std::runtime_error("MISSING_PREREG_SCHEDULE_CSV");
    std::string line;
    if (!std::getline(plan,line) || line!=
        "traffic_class,sequence,time_ns,family,rng_block,split,phase_label,phase_nominal_ns,phase_jitter_ns,selected_slot,load_level,schedule_schema")
      throw std::runtime_error("PREREG_CSV_HEADER_CHANGED");
    std::vector<bool> observed(requests,false);
    uint32_t found=0, allLines=0;
    while (std::getline(plan,line)) {
      if (line.empty()) throw std::runtime_error("PREREG_CSV_EMPTY_LINE");
      std::vector<std::string> cols;
      std::istringstream split(line); std::string piece;
      while(std::getline(split,piece,',')) cols.push_back(piece);
      if (cols.size()!=12) throw std::runtime_error("PREREG_CSV_COLUMN_COUNT");
      ++allLines;
      if (cols[3]!=m_family || cols[4]!=std::to_string(m_preregRun) ||
          cols[5]!="FAIR_LOCAL_DEV" || cols[9]!=std::to_string(m_preregSlot) ||
          cols[10]!=m_load ||
          cols[11]!="HCRAF_F3_P12R_FAIR_COMPARATOR_STUDY_V05237")
        throw std::runtime_error("P12T_FROZEN_REPLICATION_CSV_CONTEXT_CHANGED");
      if (cols[6]!="T0" && cols[6]!="T1" && cols[6]!="T2" && cols[6]!="T3" &&
          cols[6]!="C0" && cols[6]!="C1" &&
          cols[6]!="P0_TAIL_PROBE" && cols[6]!="P1_TAIL_PROBE")
        throw std::runtime_error("PREREG_PHASE_INVALID");
      if (cols[0]!="TARGET" && cols[0]!="INDEPENDENT_COMPETITOR")
        throw std::runtime_error("PREREG_TRAFFIC_CLASS_INVALID");
      if (cols[0]!=m_trafficClass) continue;
      const unsigned long long sequence=std::stoull(cols[1]);
      const unsigned long long when=std::stoull(cols[2]);
      if (sequence>=requests || observed[sequence] ||
          when<2000000000ULL || when>=20000000000ULL)
        throw std::runtime_error("PREREG_SEQUENCE_OR_TIME_INVALID");
      observed[sequence]=true; ++found;
      m_arrivals << "{\"sequence\":" << sequence << ",\"time_ns\":" << when
        << ",\"traffic_class\":" << hcraf::Recorder::quote(m_trafficClass)
        << ",\"schedule_family\":" << hcraf::Recorder::quote(m_family)
        << ",\"schedule\":\"F3_P12R_V05237_FAIR_LOCAL_DEV_LOCKED_CSV\""
        << ",\"phase_label\":" << hcraf::Recorder::quote(cols[6])
        << ",\"phase_nominal_ns\":" << cols[7]
        << ",\"phase_jitter_ns\":" << cols[8]
        << ",\"rng_block\":" << m_preregRun
        << ",\"selected_slot\":" << m_preregSlot
        << ",\"schedule_csv_basename\":" << hcraf::Recorder::quote(lockedFilename) << "}\n";
      Simulator::Schedule(NanoSeconds(when), &HcrafRequester::Send, this, static_cast<uint32_t>(sequence));
    }
    if (allLines!=128u || found!=requests ||
        std::find(observed.begin(),observed.end(),false)!=observed.end())
      throw std::runtime_error("PREREG_SCHEDULE_NOT_EXACTLY_128_OR_CLASS_COUNT");
    m_arrivals.flush();if(!m_arrivals)throw std::runtime_error("Arrival trace failed");
  }
private:
  void Send(uint32_t sequence) {
    if (!m_active) return;
    const uint32_t nameId = sequence;
    const bool prefixInterest = false;
    auto interest = std::make_shared<::ndn::Interest>(
      ::ndn::Name(prefixInterest ? m_prefix : m_prefix + "/" + std::to_string(nameId)));
    interest->setNonce(++m_nonce);
    interest->setInterestLifetime(::ndn::time::milliseconds(m_lifetimeMs));
    interest->setCanBePrefix(prefixInterest);
    interest->setMustBeFresh(true);
    m_out << "{\"event\":\"SEND\",\"time_ns\":" << Simulator::Now().GetNanoSeconds()
          << ",\"name\":" << hcraf::Recorder::quote(interest->getName().toUri())
          << ",\"nonce\":" << m_nonce << ",\"source_id\":" << m_sourceId
          << ",\"traffic_class\":" << hcraf::Recorder::quote(m_trafficClass) << "}\n";
    m_out.flush();
    m_transmittedInterests(interest, this, m_face);
    m_appLink->onReceiveInterest(*interest);
  }
  uint32_t m_nonce = 1000;
  uint32_t m_sourceId = 0;
  uint32_t m_requestOverride = 0, m_lifetimeMs = 1000;
  uint64_t m_intervalOverrideNs = 0, m_offsetNs = 0;
  int m_stream = 129;
  std::string m_prefix = "/hcraf/pilot", m_trafficClass = "TARGET", m_family = "P12R_NEW_FAIR_COMPARATOR_PROSPECTIVE_PREREG_ONLY";
  std::string m_load = "high_pressure";
  std::string m_mode;
  std::string m_scheduleCsv;
  uint64_t m_preregRun=0;
  uint32_t m_preregSlot=0;
  std::ofstream m_out;
  std::ofstream m_arrivals;
};
NS_OBJECT_ENSURE_REGISTERED(HcrafRequester);

class HcrafResponder : public ns3::ndn::App {
public:
  static TypeId GetTypeId() {
    static TypeId tid = TypeId("ns3::HcrafResponder").SetParent<ns3::ndn::App>()
      .AddConstructor<HcrafResponder>();
    return tid;
  }
  void Configure(bool silent, double delay, bool forceLeaf, bool doubleReply, bool spontaneous, bool bigPayload, std::ofstream* receipts) {
    m_silent = silent; m_delay = delay; m_forceLeaf = forceLeaf;
    m_doubleReply = doubleReply; m_spontaneous = spontaneous; m_bigPayload = bigPayload; m_receipts = receipts;
  }
  void OnInterest(std::shared_ptr<const ::ndn::Interest> interest) override {
    ns3::ndn::App::OnInterest(interest);
    if (!m_active || m_silent) return;
    if (!m_receipts) throw std::runtime_error("Path receipts log unavailable");
    // ndn-cxx prints Nonce as eight hexadecimal digits (e.g. 00002af9).
    // Streaming that representation directly as a JSON number is invalid.
    // Convert the verified hexadecimal text to an unsigned *decimal* number;
    // it must match the consumer's numeric nonce for the same Interest Name.
    std::ostringstream nonceHexStream;
    nonceHexStream << interest->getNonce();
    const std::string nonceHex = nonceHexStream.str();
    if (nonceHex.size() != 8 ||
        nonceHex.find_first_not_of("0123456789abcdefABCDEF") != std::string::npos) {
      throw std::runtime_error("Producer receipt Nonce is not eight hex digits");
    }
    const uint32_t nonceDecimal = static_cast<uint32_t>(std::stoul(nonceHex, nullptr, 16));
    *m_receipts << "{\"producer_node_id\":" << GetNode()->GetId()
      << ",\"time_ns\":" << Simulator::Now().GetNanoSeconds()
      << ",\"name\":" << hcraf::Recorder::quote(interest->getName().toUri())
      << ",\"nonce\":" << nonceDecimal << "}\n";
    m_receipts->flush();
    if (!*m_receipts) throw std::runtime_error("Path receipts log write failed");
    auto name = m_forceLeaf ? ::ndn::Name("/hcraf/pilot/0") : interest->getName();
    Simulator::Schedule(Seconds(m_delay), &HcrafResponder::Reply, this, name);
    if (m_doubleReply) Simulator::Schedule(Seconds(m_delay + 0.0001), &HcrafResponder::Reply, this, name);
  }
protected:
  void StartApplication() override {
    ns3::ndn::App::StartApplication();
    ns3::ndn::FibHelper::AddRoute(GetNode(), "/hcraf", m_face, 0);
    if (m_spontaneous)
      Simulator::Schedule(Seconds(2.06), &HcrafResponder::Reply, this, ::ndn::Name("/hcraf/pilot/0"));
  }
private:
  void Reply(::ndn::Name name) {
    if (!m_active) return;
    auto data = std::make_shared<::ndn::Data>(name);
    data->setFreshnessPeriod(::ndn::time::milliseconds(1000));
    data->setContent(std::make_shared<::ndn::Buffer>(m_bigPayload ? 4096 : 1024));
    // Same simulation signature convention as the official ndnSIM Producer.
    ::ndn::SignatureInfo signature(static_cast<::ndn::tlv::SignatureTypeValue>(255));
    data->setSignatureInfo(signature);
    ::ndn::EncodingEstimator estimator;
    ::ndn::EncodingBuffer encoder(estimator.appendVarNumber(0), 0);
    encoder.appendVarNumber(0);
    data->setSignatureValue(encoder.getBuffer());
    data->wireEncode();
    m_transmittedDatas(data, this, m_face);
    m_appLink->onReceiveData(*data);
  }
  std::ofstream* m_receipts = nullptr;
  bool m_silent = false, m_forceLeaf = false, m_doubleReply = false, m_spontaneous = false, m_bigPayload = false;
  double m_delay = 0;
};
NS_OBJECT_ENSURE_REGISTERED(HcrafResponder);


// P12T: direct real ndnSIM node1 selected NetDevice queue callbacks and
// real NFD beginDecision callback. This is a NATIVE CONNECTION DIAGNOSTIC,
// NOT a claim of all 12 B1 features or a model-training dataset.
class HcrafP12TNativeWiring {
public:
  HcrafP12TNativeWiring(const std::string& destination,
                       Ptr<PointToPointNetDevice> device,
                       std::uint64_t selectedFace,
                       std::uint32_t fibCost,
                       const std::shared_ptr<nfd::Forwarder>& fw)
    : m_device(device), m_face(selectedFace), m_cost(fibCost), m_fw(fw),
      m_output(destination) {
    if (!m_device || !m_device->GetQueue() || !m_fw || !m_face || !m_output)
      throw std::runtime_error("P12T_MISSING_NATIVE_NODE1_LOCAL_HOOK");
    // Raw layer-2 events are explicitly not conflated with NFD Interest TX.
    if (!m_device->GetQueue()->TraceConnectWithoutContext(
          "Enqueue",MakeCallback(&HcrafP12TNativeWiring::OnQueueEnqueue,this)))
      throw std::runtime_error("P12T_NATIVE_ENQUEUE_TRACE_MISSING");
    if (!m_device->GetQueue()->TraceConnectWithoutContext(
          "Drop",MakeCallback(&HcrafP12TNativeWiring::OnQueueDrop,this)))
      throw std::runtime_error("P12T_NATIVE_DROP_TRACE_MISSING");
  }
  void OnQueueEnqueue(Ptr<const Packet> packet) {
    if (!packet)throw std::runtime_error("P12T_NATIVE_ENQUEUE_PACKET_MISSING");
    ++m_queueEnqueueFrames;
  }
  void OnQueueDrop(Ptr<const Packet> packet) {
    if (!packet)throw std::runtime_error("P12T_NATIVE_DROP_PACKET_MISSING");
    ++m_queueDropFrames;
  }
  void BeforeDecision(std::uint64_t id) {
    const std::uint64_t t=static_cast<std::uint64_t>(Simulator::Now().GetNanoSeconds());
    const auto n=m_device->GetQueue()->GetNPackets();
    if (n>12u)throw std::runtime_error("P12T_NATIVE_QUEUE_CAPACITY_VIOLATION");
    const hcraf_p12s::BeforeDecisionLocalState d{
      t, ++m_ordinal, 1u, m_face, m_cost, static_cast<std::uint64_t>(n),
      12u, m_device->IsLinkUp(), static_cast<std::uint64_t>(m_fw->getPit().size())};
    const auto snapshot=m_meter.capture(d);
    if (!id || snapshot.node_id!=1u || snapshot.selected_face_id!=m_face ||
        snapshot.decision_time_ns!=t)
      throw std::runtime_error("P12T_NATIVE_DECISION_MISMATCH");
    // Fields B1[5..11] are NOT valid until true NFD Interest/Data/Nack,
    // Interest TX, and locally completed RTT hooks are implemented.
    m_output << "{\"decision_id\":" << id
      << ",\"time_ns\":" << t
      << ",\"node_id\":1,\"selected_face_id\":" << m_face
      << ",\"source\":\"NFD_BEGIN_DECISION_AND_LOCAL_NS3_QUEUE\""
      << ",\"before_actual_selected_face_tx\":true"
      << ",\"b1_first_five_native\":["
      << snapshot.values[0] << ',' << snapshot.values[1] << ','
      << snapshot.values[2] << ',' << snapshot.values[3] << ','
      << snapshot.values[4] << ']'
      << ",\"selected_local_queue_enqueued_raw_frames_total\":" << m_queueEnqueueFrames
      << ",\"selected_local_queue_dropped_raw_frames_total\":" << m_queueDropFrames
      << ",\"raw_frames_not_equated_with_ndn_interest_counts\":true"
      << ",\"interest_data_nack_nfd_hooks_wired\":false"
      << ",\"completed_local_rtt_hook_wired\":false"
      << ",\"all_B1_features_valid\":false"
      << ",\"model_training_authorized\":false"
      << ",\"F3_ready\":false,\"GO_FREEZE\":false}"
      << '\n';
    if (!m_output)throw std::runtime_error("P12T_NATIVE_TRACE_WRITE_FAILED");
  }
  void Finish() {
    m_output.flush();
    if(!m_output || !m_meter.decisionCount())
      throw std::runtime_error("P12T_NATIVE_EMPTY_OR_FAILED_TRACE");
  }
private:
  Ptr<PointToPointNetDevice> m_device;
  std::uint64_t m_face, m_ordinal=0, m_queueEnqueueFrames=0, m_queueDropFrames=0;
  std::uint32_t m_cost;
  std::shared_ptr<nfd::Forwarder> m_fw;
  std::ofstream m_output;
  hcraf_p12s::LocalCausalMeter m_meter;
};


// P12V: direct signals emitted by REAL NFD Forwarder, not replayed log rows.
// This is one development sentinel only; no official F3 / performance readiness.
class HcrafP12VNativeWiring {
 public:
  HcrafP12VNativeWiring(const std::string& destination,
         Ptr<PointToPointNetDevice> device, std::uint64_t chosenFace,
         std::uint32_t fibCost, const std::shared_ptr<nfd::Forwarder>& fw)
   : m_device(device),m_face(chosenFace),m_cost(fibCost),m_fw(fw),m_output(destination) {
    if(!m_device || !m_device->GetQueue() || !m_face || !m_fw || !m_output)
      throw std::runtime_error("P12V_NO_NATIVE_LOCAL_SOURCE");
  }
  static bool research(const std::string& s){return hcraf_p12u::Node1NativeEventAdapter::isResearchTraffic(s);}
  void InterestIn(const ::ndn::Interest& interest,const nfd::Face& face){
    const auto name=interest.getName().toUri(); if(!research(name))return;
    if(m_adapter.observe(hcraf_p12u::NfdHook::IncomingInterest,now(),face.getId(),name))++m_ri;
  }
  void DataIn(const ::ndn::Data& data,const nfd::Face& face){
    const auto name=data.getName().toUri(); if(!research(name))return;
    if(m_adapter.observe(hcraf_p12u::NfdHook::IncomingData,now(),face.getId(),name))++m_rd;
  }
  void NackIn(const ::ndn::lp::Nack& nack,const nfd::Face& face){
    const auto name=nack.getInterest().getName().toUri(); if(!research(name))return;
    if(m_adapter.observe(hcraf_p12u::NfdHook::IncomingNack,now(),face.getId(),name))++m_rn;
  }
  void InterestTx(const ::ndn::Interest& interest,const nfd::Face& face){
    const auto name=interest.getName().toUri(); if(!research(name))return;
    if(m_adapter.observe(hcraf_p12u::NfdHook::OutgoingSelectedInterest,now(),face.getId(),name)){
      ++m_tx; if(face.getId()==m_face)m_sent[std::make_pair(name,face.getId())]=now();
    }
  }
  void InterestDrop(const ::ndn::Interest& interest,const nfd::Face& face){
    const auto name=interest.getName().toUri(); if(!research(name))return;
    if(m_adapter.observe(hcraf_p12u::NfdHook::DroppedSelectedInterest,now(),face.getId(),name))++m_drop;
  }
  void Satisfied(const nfd::pit::Entry&,const nfd::Face& face,const ::ndn::Data& data){
    const auto name=data.getName().toUri();if(!research(name)||face.getId()!=m_face)return;
    const auto it=m_sent.find(std::make_pair(name,static_cast<std::uint64_t>(face.getId())));
    if(it==m_sent.end())return;
    const auto t=now();if(t<=it->second)throw std::runtime_error("P12V_NONPOSITIVE_COMPLETED_LOCAL_RTT");
    const double rtt=static_cast<double>(t-it->second)/1000000.0;
    if(m_adapter.observe(hcraf_p12u::NfdHook::LocallyCompletedDataRtt,t,face.getId(),name,rtt))++m_rtt;
    m_sent.erase(it);
  }
  void BeforeDecision(std::uint64_t id){
    const auto t=now(); const auto q=m_device->GetQueue()->GetNPackets();
    if(q>12u)throw std::runtime_error("P12V_LOCAL_QUEUE_OVERCAPACITY");
    const auto x=m_adapter.snapshotBeforeSelectedFaceTx(t,m_face,m_cost,q,12u,
                m_device->IsLinkUp(),m_fw->getPit().size());
    if(!id || x.node_id!=1 || x.selected_face_id!=m_face || x.decision_time_ns!=t)
      throw std::runtime_error("P12V_NFD_DECISION_ALIGNMENT");
    m_output << "{\"decision_id\":" << id << ",\"time_ns\":" << t
      << ",\"node_id\":1,\"selected_face_id\":" << m_face
      << ",\"source\":\"NFD_LIVE_EVENT_SIGNALS_PLUS_NODE1_QUEUE_BEFORE_TX\""
      << ",\"b1_all_twelve_native\":[";
    for(std::size_t i=0;i<x.values.size();++i){if(i)m_output<<',';m_output<<x.values[i];}
    m_output << "]"
      << ",\"live_NFD_interest_rx_total\":" << m_ri
      << ",\"live_NFD_data_rx_total\":" << m_rd
      << ",\"live_NFD_nack_rx_total\":" << m_rn
      << ",\"live_NFD_interest_tx_total\":" << m_tx
      << ",\"live_NFD_interest_drop_total\":" << m_drop
      << ",\"locally_completed_RTT_total\":" << m_rtt
      << ",\"same_tick_events_observed_before_decision\":" << (x.same_tick_events_included?"true":"false")
      << ",\"hook_wiring_development_only\":true"
      << ",\"all_B1_features_validated\":false"
      << ",\"model_training_authorized\":false"
      << ",\"F3_ready\":false,\"GO_FREEZE\":false}" << '\n';
    if(!m_output)throw std::runtime_error("P12V_NATIVE_TRACE_OUTPUT_ERROR");
    ++m_decisions;
  }
  void Finish(){m_output.flush();if(!m_output||m_decisions!=128)
    throw std::runtime_error("P12V_EXPECT_128_EXACT_DEVELOPMENT_DECISIONS");}
 private:
  static std::uint64_t now(){return static_cast<std::uint64_t>(Simulator::Now().GetNanoSeconds());}
  Ptr<PointToPointNetDevice> m_device;
  std::uint64_t m_face;std::uint32_t m_cost;
  std::shared_ptr<nfd::Forwarder> m_fw;
  std::ofstream m_output;
  hcraf_p12u::Node1NativeEventAdapter m_adapter;
  std::map<std::pair<std::string,std::uint64_t>,std::uint64_t> m_sent;
  std::uint64_t m_ri=0,m_rd=0,m_rn=0,m_tx=0,m_drop=0,m_rtt=0,m_decisions=0;
};

// Queue telemetry lives at the *source* ns-3 node.  The source observes only
// its own return NetDevice queue; it never reads another node's monitor.
class HcrafQueueTelemetrySource : public ns3::ndn::App {
public:
  static TypeId GetTypeId() {
    static TypeId tid=TypeId("ns3::HcrafQueueTelemetrySource")
      .SetParent<ns3::ndn::App>().AddConstructor<HcrafQueueTelemetrySource>();
    return tid;
  }
  void Configure(const std::string& role, Ptr<PointToPointNetDevice> dev, std::ofstream* sent) {
    if (!dev || !dev->GetQueue() || !sent) throw std::runtime_error("TELEMETRY_SOURCE_QUEUE_MISSING");
    m_role=role;m_device=dev;m_sent=sent;
    auto q=dev->GetQueue();
    if (!q->TraceConnectWithoutContext("Enqueue",MakeCallback(&HcrafQueueTelemetrySource::OnEnqueue,this)) ||
        !q->TraceConnectWithoutContext("Drop",MakeCallback(&HcrafQueueTelemetrySource::OnDrop,this)))
      throw std::runtime_error("TELEMETRY_SOURCE_QUEUE_TRACE_MISSING");
  }
  void OnInterest(std::shared_ptr<const ::ndn::Interest> interest) override {
    ns3::ndn::App::OnInterest(interest);
    if (!m_active) return;
    const auto uri=interest->getName().toUri();
    const std::string prefix="/hcraf-queue-telemetry/"+m_role+"/";
    if (uri.compare(0,prefix.size(),prefix)!=0) throw std::runtime_error("UNEXPECTED_TELEMETRY_INTEREST");
    const uint64_t sample=Simulator::Now().GetNanoSeconds();
    const uint64_t seq=++m_sequence;
    std::ostringstream value;
    value << m_role << ',' << GetNode()->GetId() << ',' << m_device->GetIfIndex()
          << ',' << seq << ',' << sample << ',' << m_enqueues << ',' << m_drops
          << ',' << m_device->GetQueue()->GetNPackets();
    const std::string payload=value.str();
    auto data=std::make_shared<::ndn::Data>(interest->getName());
    // Legacy ndn-cxx requires positive Data FreshnessPeriod when the matching
    // Interest sets MustBeFresh. The CS is disabled and names are unique;
    // this does not enable caching or alter any queue-pressure label.
    data->setFreshnessPeriod(::ndn::time::milliseconds(1000));
    auto buffer=std::make_shared<::ndn::Buffer>(payload.size());
    std::copy(payload.begin(),payload.end(),buffer->begin());
    data->setContent(buffer);
    ::ndn::SignatureInfo signature(static_cast<::ndn::tlv::SignatureTypeValue>(255));
    data->setSignatureInfo(signature);
    ::ndn::EncodingEstimator estimator;
    ::ndn::EncodingBuffer encoder(estimator.appendVarNumber(0),0);
    encoder.appendVarNumber(0);
    data->setSignatureValue(encoder.getBuffer());
    data->wireEncode();
    if (!interest->matchesData(*data))
      throw std::runtime_error("TELEMETRY_INTEREST_DATA_MATCH_CONTRACT_FAILED");
    *m_sent << "{\"role\":" << hcraf::Recorder::quote(m_role)
            << ",\"source_node_id\":" << GetNode()->GetId()
            << ",\"source_device_index\":" << m_device->GetIfIndex()
            << ",\"sample_ns\":" << sample << ",\"sequence\":" << seq
            << ",\"payload_bytes\":" << payload.size()
            << ",\"data_wire_bytes\":" << data->wireEncode().size() << "}\n";
    if (!*m_sent) throw std::runtime_error("TELEMETRY_SENDER_LOG_WRITE_FAILED");
    m_transmittedDatas(data,this,m_face);
    m_appLink->onReceiveData(*data);
  }
protected:
  void StartApplication() override {
    ns3::ndn::App::StartApplication();
    ns3::ndn::FibHelper::AddRoute(GetNode(),"/hcraf-queue-telemetry/"+m_role,m_face,0);
  }
private:
  void OnEnqueue(Ptr<const Packet>) {++m_enqueues;}
  void OnDrop(Ptr<const Packet>) {++m_drops;}
  std::string m_role;
  Ptr<PointToPointNetDevice> m_device;
  std::ofstream* m_sent=nullptr;
  uint64_t m_sequence=0,m_enqueues=0,m_drops=0;
};
NS_OBJECT_ENSURE_REGISTERED(HcrafQueueTelemetrySource);

// The sole online feature source for the decision callback below.  Receipts
// arrive through the NDN forwarder and OnData, NOT through direct ns-3 reads.
class HcrafQueueTelemetrySink : public ns3::ndn::App {
public:
  static TypeId GetTypeId() {
    static TypeId tid=TypeId("ns3::HcrafQueueTelemetrySink")
      .SetParent<ns3::ndn::App>().AddConstructor<HcrafQueueTelemetrySink>();
    return tid;
  }
  void Configure(uint32_t periodMs,const std::string& pathId,
                 const std::map<std::string,std::pair<uint32_t,uint32_t>>& expected,
                 std::ofstream* requests,std::ofstream* receipts,std::ofstream* decisions,
                 uint64_t prospectivePollOffsetNs) {
    if ((periodMs!=20 && periodMs!=50) || expected.size()!=3 || !requests || !receipts || !decisions)
      throw std::runtime_error("INVALID_TELEMETRY_SINK_CONFIGURATION");
    m_periodMs=periodMs;m_path=pathId;m_expected=expected;
    if (prospectivePollOffsetNs>=20000000ULL)
      throw std::runtime_error("P4P6_TELEMETRY_OFFSET_OUTSIDE_20MS");
    m_pollOffsetNs=prospectivePollOffsetNs;
    m_requests=requests;m_receipts=receipts;m_decisions=decisions;
  }
  void OnData(std::shared_ptr<const ::ndn::Data> data) override {
    ns3::ndn::App::OnData(data);
    if (!m_active) return;
    std::string body(reinterpret_cast<const char*>(data->getContent().value()),data->getContent().value_size());
    std::istringstream stream(body);
    std::vector<std::string> fields;std::string field;
    while(std::getline(stream,field,','))fields.push_back(field);
    if (fields.size()!=8) throw std::runtime_error("TELEMETRY_PAYLOAD_FIELDS_INVALID");
    const std::string role=fields[0];
    auto it=m_expected.find(role);
    if (it==m_expected.end() || data->getName().toUri().find("/hcraf-queue-telemetry/"+role+"/")!=0)
      throw std::runtime_error("TELEMETRY_PATH_ROLE_MISMATCH");
    auto number=[&fields](size_t i)->uint64_t {
      if (fields[i].empty() || fields[i].find_first_not_of("0123456789")!=std::string::npos)
        throw std::runtime_error("TELEMETRY_NUMERIC_FIELD_INVALID");
      return std::stoull(fields[i]);
    };
    const auto node=number(1),dev=number(2),seq=number(3),sample=number(4);
    const auto enq=number(5),drop=number(6),depth=number(7);
    const uint64_t received=Simulator::Now().GetNanoSeconds();
    if (node!=it->second.first || dev!=it->second.second || sample>received)
      throw std::runtime_error("TELEMETRY_CAUSALITY_OR_SOURCE_INVALID");
    if (m_latest.count(role) && (seq<=m_latest[role].seq || sample<=m_latest[role].sample)) {
      // Legitimate reordering is possible on a congested return path.  Fail
      // closed at the feature boundary, without aborting the network run.
      ++m_outOfOrderDiscarded;
      return;
    }
    // A real packet was delivered here. This is the only point at which
    // the online decision source gains access to these remote counters.
    m_latest[role]={seq,sample,received,enq,drop,depth};
    const std::string reportId=role+"-"+std::to_string(seq);
    *m_receipts << "{\"report_id\":" << hcraf::Recorder::quote(reportId)
       << ",\"source_node_id\":" << node << ",\"source_device_index\":" << dev
       << ",\"path_id\":" << hcraf::Recorder::quote(m_path)
       << ",\"counter_epoch\":\"boot-0\",\"sequence\":" << seq
       << ",\"sample_ns\":" << sample << ",\"receipt_ns\":" << received
       << ",\"queue_enqueue_packets_total\":" << enq
       << ",\"queue_drop_packets_total\":" << drop
       << ",\"queue_packets_now\":" << depth
       << ",\"payload_bytes\":" << body.size()
       << ",\"data_wire_bytes\":" << data->wireEncode().size() << "}\n";
    if (!*m_receipts) throw std::runtime_error("TELEMETRY_RECEIPT_LOG_WRITE_FAILED");
  }
  void ObserveBeforeForwarding(uint64_t decisionId) {
    // Expose only receipts already in m_latest. Do not treat missing reports
    // as zero queue pressure or as evidence of a negative future label.
    const uint64_t now=Simulator::Now().GetNanoSeconds();
    *m_decisions << "{\"decision_id\":" << decisionId << ",\"decision_ns\":" << now
      << ",\"selected_path_id\":" << hcraf::Recorder::quote(m_path)
      << ",\"selected_sender_sources\":[";
    bool first=true;
    for (const auto& role:m_expected) {
      if (!first)*m_decisions << ',';first=false;
      *m_decisions << "{\"node_id\":" << role.second.first
                   << ",\"device_index\":" << role.second.second << '}';
    }
    *m_decisions << "],\"out_of_order_discarded_total\":" << m_outOfOrderDiscarded
                 << ",\"feature_evidence\":[";first=true;
    for (const auto& role:m_expected) {
      const auto it=m_latest.find(role.first);
      if (it==m_latest.end() || it->second.receipt>now ||
          it->second.sample>now || now-it->second.sample>100000000ULL)continue;
      if (!first)*m_decisions << ',';first=false;
      *m_decisions << "{\"source_node_id\":" << role.second.first
         << ",\"source_device_index\":" << role.second.second
         << ",\"report_id\":" << hcraf::Recorder::quote(role.first+"-"+std::to_string(it->second.seq)) << '}';
    }
    *m_decisions << "],\"feature_missing_sources\":[";first=true;
    for (const auto& role:m_expected) {
      const auto it=m_latest.find(role.first);
      if (it!=m_latest.end() && it->second.receipt<=now &&
          it->second.sample<=now && now-it->second.sample<=100000000ULL)continue;
      if (!first)*m_decisions << ',';first=false;
      const bool stale=it!=m_latest.end() && it->second.receipt<=now &&
                       it->second.sample<=now;
      *m_decisions << "{\"source_node_id\":" << role.second.first
        << ",\"source_device_index\":" << role.second.second
        << ",\"reason\":" << hcraf::Recorder::quote(stale?"STALE_GT_100MS":"UNRECEIVED")
        << '}';
    }
    *m_decisions << "]}\n";
    if (!*m_decisions) throw std::runtime_error("TELEMETRY_DECISION_LOG_WRITE_FAILED");
  }
protected:
  void StartApplication() override {
    ns3::ndn::App::StartApplication();
    Simulator::Schedule(Seconds(1.0)+NanoSeconds(m_pollOffsetNs),
                        &HcrafQueueTelemetrySink::Poll,this);
  }
private:
  struct Report {uint64_t seq,sample,receipt,enq,drop,depth;};
  void Poll() {
    if (!m_active || Simulator::Now()>=Seconds(19.0))return;
    for (const auto& role:m_expected) {
      auto interest=std::make_shared<::ndn::Interest>(
        ::ndn::Name("/hcraf-queue-telemetry/"+role.first+"/"+std::to_string(++m_requestSequence)));
      interest->setNonce(++m_nonce);
      interest->setInterestLifetime(::ndn::time::milliseconds(1000));
      interest->setMustBeFresh(true);
      *m_requests << "{\"time_ns\":" << Simulator::Now().GetNanoSeconds()
         << ",\"role\":" << hcraf::Recorder::quote(role.first)
         << ",\"name\":" << hcraf::Recorder::quote(interest->getName().toUri())
         << ",\"interest_wire_bytes\":" << interest->wireEncode().size() << "}\n";
      if (!*m_requests)throw std::runtime_error("TELEMETRY_REQUEST_LOG_WRITE_FAILED");
      m_transmittedInterests(interest,this,m_face);
      m_appLink->onReceiveInterest(*interest);
    }
    Simulator::Schedule(MilliSeconds(m_periodMs),&HcrafQueueTelemetrySink::Poll,this);
  }
  uint32_t m_periodMs=0,m_nonce=900000;
  uint64_t m_requestSequence=0;
  uint64_t m_outOfOrderDiscarded=0;
  uint64_t m_pollOffsetNs=0;
  std::string m_path;
  std::map<std::string,std::pair<uint32_t,uint32_t>> m_expected;
  std::map<std::string,Report> m_latest;
  std::ofstream *m_requests=nullptr,*m_receipts=nullptr,*m_decisions=nullptr;
};
NS_OBJECT_ENSURE_REGISTERED(HcrafQueueTelemetrySink);
}

 static void P12XLocalQueueDrop(std::ofstream* out, ns3::Ptr<const ns3::Packet> packet) {
   if (!out || !*out || !packet) throw std::runtime_error("P12X_LOCAL_QUEUE_DROP_TRACE_UNAVAILABLE");
   *out << "{\"event\":\"L2_QUEUE_DROP_NOT_NFD_DROP\",\"time_ns\":"
        << ns3::Simulator::Now().GetNanoSeconds()
        << ",\"packet_size_bytes\":" << packet->GetSize() << "}\n";
 }
static void RecordRxDrop(std::ofstream* out, uint32_t rxNode, uint32_t rxDevice, ns3::Ptr<const ns3::Packet> packet) {
  *out << "{\"event\":\"PHY_RX_DROP\",\"node_id\":" << rxNode << ",\"device_index\":" << rxDevice << ",\"time_ns\":"
       << ns3::Simulator::Now().GetNanoSeconds() << ",\"packet_uid\":" << packet->GetUid() << "}\n";
  out->flush();
}

int main(int argc, char* argv[]) {
  using namespace ns3;
  std::string mode = "LP_SELF_ONLY", output = ".";
  std::string topology = "DEV_CHAIN_L";
  std::string pathArm = "PRODUCER_RETURN_6M";
  std::string interventionLocation = "PRODUCER_RETURN";
  uint64_t interventionReturnBps = 6000000ULL;
  double lossProbability = 0.0;
  int lossStream = 79, lossReceiverNodeId = -1, lossReceiverDeviceIndex = -1;
  std::string scheduleFamily = "P12R_NEW_FAIR_COMPARATOR_PROSPECTIVE_PREREG_ONLY";
  std::string scheduleCsv;
  uint32_t selectedSlot = 0;
  std::string prospectiveLoad = "high_pressure";
  uint32_t prospectiveTrafficStreamSeed=0, prospectiveRoutingStreamSeed=0;
  uint32_t prospectiveTelemetryStreamSeed=0;
  bool telemetryEnabled = false;
  uint32_t telemetryPeriodMs = 20;
  // P12T's independent v0.52.19 REPLICATION executor: 12-packet candidate.
  // It does not replace or edit the original v0.52.0 20-packet experiment.
  uint32_t technicalQueueMaxPackets = 12;
  // P12X controls alter routing or transmission only for PROBE data; not a P12R arm.
  std::string p12xProbe = "NONE";
  uint32_t seed = 17;
  uint64_t run = 9401;
  bool instrument = true;
  uint32_t requestOverride=0, lifetimeMs=1000, producerDelayMs=0;
  uint64_t intervalOverrideNs=0, forwardBps=0, returnBps=0;
  uint32_t competitorCount=0;
  uint64_t competitorIntervalNs=0, competitorOffsetNs=0, targetOffsetNs=0;
  CommandLine cmd;
  cmd.AddValue("mode", "LP_INDEPENDENT_COMPETITOR_NO_DROP (fixed 1AJ diagnostic regime)", mode);
  cmd.AddValue("p12xProbe", "Exploratory only: NACK_NO_ROUTE or L2_DROP_PRESSURE", p12xProbe);
  cmd.AddValue("pathArm", "P12T REPLICATION: PRODUCER_RETURN_12M, MID_RETURN_12M, RELAY_RETURN_12M", pathArm);
  cmd.AddValue("interventionLocation", "PRODUCER_RETURN, MID_RETURN, RELAY_RETURN, or NONE", interventionLocation);
  cmd.AddValue("interventionReturnBps", "Locked return-link capacity on single intervention device", interventionReturnBps);
  cmd.AddValue("lossProbability", "Locked independent receiver packet loss rate", lossProbability);
  cmd.AddValue("lossStream", "Locked ns-3 ErrorModel stream=79", lossStream);
  cmd.AddValue("lossReceiverNodeId", "Locked receiving node, -1 unless loss arm", lossReceiverNodeId);
  cmd.AddValue("lossReceiverDeviceIndex", "Locked receiving device, -1 unless loss arm", lossReceiverDeviceIndex);
  cmd.AddValue("scheduleFamily", "P12R_NEW_FAIR_COMPARATOR_PROSPECTIVE_PREREG_ONLY", scheduleFamily);
  cmd.AddValue("scheduleCsv", "Absolute path to v0.52.19 frozen REPLICATION CSV", scheduleCsv);
  cmd.AddValue("prospectiveLoad", "P12 REPLICATION load: low_control or high_pressure", prospectiveLoad);
  cmd.AddValue("prospectiveTrafficStreamSeed", "v0.52.19 locked traffic stream", prospectiveTrafficStreamSeed);
  cmd.AddValue("prospectiveRoutingStreamSeed", "v0.52.19 locked routing stream", prospectiveRoutingStreamSeed);
  cmd.AddValue("prospectiveTelemetryStreamSeed", "v0.52.19 locked telemetry stream", prospectiveTelemetryStreamSeed);
  cmd.AddValue("competitorCount", "Distinct competitor requests (only C1/C2)", competitorCount);
  cmd.AddValue("competitorIntervalNs", "Competitor request interval", competitorIntervalNs);
  cmd.AddValue("competitorOffsetNs", "Competitor start offset from t=2s", competitorOffsetNs);
  cmd.AddValue("targetOffsetNs", "Pre-registered 1AH-A1 target start offset from t=2s", targetOffsetNs);
  cmd.AddValue("topology", "DEV_CHAIN_L registered P12R PROSPECTIVE REPLICATION ONLY", topology);
  cmd.AddValue("selectedSlot", "Controlled upstream face slot 0/1/2 (forced assignment)", selectedSlot);
  cmd.AddValue("output", "Existing output directory", output);
  cmd.AddValue("seed", "ns-3 random seed", seed);
  cmd.AddValue("run", "ns-3 random run number", run);
  cmd.AddValue("instrument", "Enable event and queue monitor (1/0)", instrument);
  cmd.AddValue("telemetryEnabled", "Enable actual network-delivered NDN telemetry (1/0), technical smoke only", telemetryEnabled);
  cmd.AddValue("telemetryPeriodMs", "Technical telemetry Interest polling period, 20 or 50ms", telemetryPeriodMs);
  cmd.AddValue("technicalQueueMaxPackets", "P12T frozen validation capacity candidate, exactly 12 packets", technicalQueueMaxPackets);
  cmd.AddValue("requestCount", "Override number of distinct requests (0 keeps mode defaults)", requestOverride);
  cmd.AddValue("intervalNs", "Override request separation in nanoseconds", intervalOverrideNs);
  cmd.AddValue("lifetimeMs", "Interest lifetime in milliseconds", lifetimeMs);
  cmd.AddValue("producerDelayMs", "Producer response delay in milliseconds", producerDelayMs);
  cmd.AddValue("forwardBps", "Override primary forward link bps", forwardBps);
  cmd.AddValue("returnBps", "Override primary return link bps", returnBps);

  cmd.Parse(argc, argv);
  if (p12xProbe!="NACK_NO_ROUTE" && p12xProbe!="L2_DROP_PRESSURE")
    throw std::runtime_error("P12X_REFUSE_NON_EXPLORATORY_PROBE");
  if (std::set<std::string>{"LP_SELF_ONLY","LP_INDEPENDENT_COMPETITOR_NO_DROP","LP_INDEPENDENT_COMPETITOR_DROP","UNFRAGMENTED_MATCHED_BYTES"}.count(mode)==0)
    throw std::runtime_error("Unregistered 1AH regime");
  if (topology!="DEV_CHAIN_L" || selectedSlot>2 || scheduleFamily!="P12R_NEW_FAIR_COMPARATOR_PROSPECTIVE_PREREG_ONLY" ||
      (prospectiveLoad!="low_control" && prospectiveLoad!="high_pressure"))
    throw std::runtime_error("UNREGISTERED_P12T_DEV_SMOKE_TOPOLOGY_LOAD");
  if ((telemetryPeriodMs!=20 && telemetryPeriodMs!=50) || (telemetryEnabled && !instrument))
    throw std::runtime_error("TELEMETRY_SMOKE_REQUIRES_INSTRUMENTATION_AND_20_OR_50MS");
  if (technicalQueueMaxPackets!=12 || !instrument)
    throw std::runtime_error("P4P6_ONLY_12_PACKET_INSTRUMENTED_DEV_QUEUE");

  if(lifetimeMs<100 || lifetimeMs>5000 || producerDelayMs>3000 || requestOverride>200 ||
     intervalOverrideNs>1000000000ULL) throw std::runtime_error("Invalid registered 1AD bounds");
  const bool hasCompetitor=(competitorCount!=0);
  if ((hasCompetitor && !competitorIntervalNs) ||
      (!hasCompetitor && (competitorIntervalNs || competitorOffsetNs)) ||
      competitorCount>200 || competitorIntervalNs>1000000000ULL || competitorOffsetNs>5000000000ULL)
    throw std::runtime_error("Unregistered competitor injection plan");
  if (!requestOverride || !intervalOverrideNs)
    throw std::runtime_error("1AH requires explicit target request plan");
  // All prior designs stay immutable. Only the six authorized P12-K replication seeds are executable.
  const bool isLossArm = pathArm=="NONQUEUE_RX_LOSS_50M";
  const bool isNoThrottleArm = pathArm=="ALL_RETURN_50M";
  const bool isThrottledArm = interventionLocation=="PRODUCER_RETURN" ||
                              interventionLocation=="MID_RETURN" ||
                              interventionLocation=="RELAY_RETURN";
  const bool armValid = (isThrottledArm &&
       (pathArm == interventionLocation+"_6M" || pathArm == interventionLocation+"_12M") &&
       interventionReturnBps==(pathArm==interventionLocation+"_6M"?6000000ULL:12000000ULL)) ||
       ((isLossArm||isNoThrottleArm) && interventionLocation=="NONE" && interventionReturnBps==50000000ULL);
  const std::string pilotSite = interventionLocation=="PRODUCER_RETURN" ? "producer_egress" :
      (interventionLocation=="MID_RETURN" ? "transit_middle" :
       (interventionLocation=="RELAY_RETURN" ? "consumer_ingress" : "INVALID"));
  // Frozen (seed, site) C++ gate: refuses every non-authorized replication seed and site.
  const std::map<std::pair<uint64_t,std::string>,
      std::tuple<uint32_t,uint32_t,uint32_t,uint32_t>> replicationStreams = {
    {{24901u,"producer_egress"},{278720417u,1551908065u,261509793u,0u}},
    {{24901u,"transit_middle"},{337109647u,860173673u,529659753u,1u}},
    {{24901u,"consumer_ingress"},{1020808457u,1924642131u,1022975717u,2u}},
    {{24902u,"producer_egress"},{1739472024u,980546090u,2003900874u,1u}},
    {{24902u,"transit_middle"},{1721961586u,1400031330u,1646286051u,2u}},
    {{24902u,"consumer_ingress"},{507763528u,637669737u,152958231u,0u}},
    {{24903u,"producer_egress"},{536581970u,297796105u,896512756u,2u}},
    {{24903u,"transit_middle"},{2091812896u,1222792159u,202285947u,0u}},
    {{24903u,"consumer_ingress"},{432390492u,2012610760u,2140463644u,1u}},
    {{24904u,"producer_egress"},{2124918709u,1097277342u,558858727u,0u}},
    {{24904u,"transit_middle"},{242820413u,14154138u,1308341907u,1u}},
    {{24904u,"consumer_ingress"},{1502857242u,1528071756u,934103729u,2u}},
    {{24905u,"producer_egress"},{1779383902u,1711228088u,1375242739u,1u}},
    {{24905u,"transit_middle"},{1140466918u,2091649659u,2039250592u,2u}},
    {{24905u,"consumer_ingress"},{1090968233u,216785767u,332630505u,0u}},
    {{24906u,"producer_egress"},{1154389408u,1276725426u,653036243u,2u}},
    {{24906u,"transit_middle"},{328404263u,363720211u,1145258555u,0u}},
    {{24906u,"consumer_ingress"},{1610047020u,524650455u,1110650516u,1u}}
  };
  const auto streamIt=replicationStreams.find(std::make_pair(run,pilotSite));
  if (streamIt==replicationStreams.end() ||
      prospectiveTrafficStreamSeed!=std::get<0>(streamIt->second) ||
      prospectiveRoutingStreamSeed!=std::get<1>(streamIt->second) ||
      prospectiveTelemetryStreamSeed!=std::get<2>(streamIt->second) ||
      selectedSlot!=std::get<3>(streamIt->second))
    throw std::runtime_error("P12T_WRONG_DEV_SEED_SITE_STREAM_OR_ROUTE");
  if (run != 24901u || pilotSite!="producer_egress" ||
      prospectiveLoad!="high_pressure" || !telemetryEnabled ||
      selectedSlot!=0u || pathArm!="PRODUCER_RETURN_12M")
    throw std::runtime_error("P12T_ONLY_P12R_DEV_SENTINEL_CASE_24901");
  const std::string replicationLockedFilename="p12r-v05237-fair_local_dev-seed-"+std::to_string(run)+
       "-"+pilotSite+"-slot-"+std::to_string(selectedSlot)+"-"+prospectiveLoad+".csv";
  const size_t csvSlash=scheduleCsv.find_last_of("/\\");
  if (scheduleCsv.substr(csvSlash==std::string::npos ? 0 : csvSlash+1)!=replicationLockedFilename)
    throw std::runtime_error("P12T_SITE_SPECIFIC_DEV_CSV_FILENAME_CHANGED");
  if (!armValid || seed!=17 || technicalQueueMaxPackets!=12 || scheduleCsv.empty() ||
      interventionReturnBps!=12000000ULL ||
      !isThrottledArm ||
      mode!="LP_INDEPENDENT_COMPETITOR_NO_DROP" || lifetimeMs!=2600 ||
      producerDelayMs!=0 || requestOverride!=12 || intervalOverrideNs!=330000000ULL ||
      returnBps!=50000000ULL || targetOffsetNs!=260000000ULL || forwardBps!=50000000ULL ||
      competitorCount!=116 || competitorIntervalNs!=3600000ULL || competitorOffsetNs!=0ULL ||
      lossStream!=79 || (isLossArm && (lossReceiverNodeId!=1 ||
            lossReceiverDeviceIndex!=static_cast<int>(selectedSlot+1) || lossProbability!=0.15)) ||
      (!isLossArm && (lossProbability!=0.0 || lossReceiverNodeId!=-1 || lossReceiverDeviceIndex!=-1)))
    throw std::runtime_error("OUTSIDE_P12T_DEV_SMOKE_FROZEN_72_CASES");
  const uint64_t backgroundRate = 50000000ULL;
  const uint64_t remoteForwardRate = backgroundRate;
  const uint64_t midForwardRate = backgroundRate;
  const uint64_t producerReturnRate = interventionLocation=="PRODUCER_RETURN" ? interventionReturnBps : backgroundRate;
  const uint64_t midReturnRate = interventionLocation=="MID_RETURN" ? interventionReturnBps : backgroundRate;
  const uint64_t relayReturnRate = interventionLocation=="RELAY_RETURN" ? interventionReturnBps : backgroundRate;
  const std::string phaseArm = pathArm;
  RngSeedManager::SetSeed(seed); RngSeedManager::SetRun(run);
  NodeContainer nodes;
  const bool fragmented = mode != "UNFRAGMENTED_MATCHED_BYTES";
  const bool mixed = true; // Four-hop physical path; eleven nodes and ten links.
  nodes.Create(11u);
  PointToPointHelper link;
  // This new independent design applies the 12-packet candidate to every
  // point-to-point queue in every paired low/high/telemetry condition.
  link.SetQueue("ns3::DropTailQueue<Packet>", "MaxSize",
                StringValue(std::to_string(technicalQueueMaxPackets)+"p"));
  link.SetDeviceAttribute("InterframeGap", TimeValue(NanoSeconds(0)));
  link.SetDeviceAttribute("DataRate", StringValue("50Mbps"));
  link.SetChannelAttribute("Delay", StringValue("16ms"));
  link.Install(nodes.Get(0), nodes.Get(1));
  link.SetDeviceAttribute("DataRate", StringValue("50Mbps"));
  link.SetChannelAttribute("Delay", StringValue("16ms"));
  auto primaryDevices = link.Install(nodes.Get(1), nodes.Get(2));
  auto routerDevice = DynamicCast<PointToPointNetDevice>(primaryDevices.Get(0));
  auto producerDevice = DynamicCast<PointToPointNetDevice>(primaryDevices.Get(1));
  const uint64_t forwardRate = forwardBps ? forwardBps : 10000000;
  const uint64_t returnRate = returnBps ? returnBps : 10000000;
  routerDevice->SetDataRate(DataRate(forwardRate));
  producerDevice->SetDataRate(DataRate(returnRate));
  std::ofstream faults(output + "/fault_events.jsonl");
  if (!faults) throw std::runtime_error("Cannot open fault log");
  link.SetDeviceAttribute("DataRate", StringValue("512kbps"));
  link.SetChannelAttribute("Delay", StringValue("30ms"));
  auto secondaryDevices = link.Install(nodes.Get(1), nodes.Get(3));
  link.SetDeviceAttribute("DataRate", StringValue("1Mbps"));
  link.SetChannelAttribute("Delay", StringValue("20ms"));
  auto thirdDevices=link.Install(nodes.Get(1),nodes.Get(4));
  // Dedicated new Development K topology: not Validation I / observed Test J.
  // Each rate arm and RNG sees the exact same topology, delays and selected slot.
  const std::vector<uint32_t> relayToMid = {7u,6u,5u};
  const std::vector<uint32_t> midToProducerBySlot = {8u,9u,10u};
  link.SetDeviceAttribute("DataRate", StringValue("50Mbps"));
  link.SetChannelAttribute("Delay", StringValue("18ms"));
  std::vector<NetDeviceContainer> relayLinks, midLinks;
  for (uint32_t s=0; s<3; ++s)
    relayLinks.push_back(link.Install(nodes.Get(2+s), nodes.Get(relayToMid[s])));
  link.SetChannelAttribute("Delay", StringValue("20ms"));
  for (uint32_t s=0; s<3; ++s)
    midLinks.push_back(link.Install(nodes.Get(relayToMid[s]), nodes.Get(midToProducerBySlot[s])));
  // Slot-specific bottleneck controls use the actual path, not a hardcoded Face ID.

  // NFD NetDeviceTransport reads device MTU during StackHelper::InstallAll.
  // Constrain BOTH endpoints to ensure LP (not IP) fragmentation on these point-to-point faces.
  if (fragmented) {
    for (uint32_t n=0; n<nodes.GetN(); ++n) {
      auto node = nodes.Get(n);
      for (uint32_t d=0;d<node->GetNDevices();++d) {
        auto dev=DynamicCast<PointToPointNetDevice>(node->GetDevice(d));
        if (dev && !dev->SetMtu(600)) throw std::runtime_error("Cannot set test face MTU");
      }
    }
  }
  if (!fragmented) { // 4096 content bytes in a single NDN packet (not 1500 MTU).
    for (uint32_t n=0; n<nodes.GetN(); ++n)
      for (uint32_t d=0;d<nodes.Get(n)->GetNDevices();++d) {
        auto dev=DynamicCast<PointToPointNetDevice>(nodes.Get(n)->GetDevice(d));
        if (dev && !dev->SetMtu(9000)) throw std::runtime_error("Cannot set unfragmented matched-byte MTU");
      }
  }
  // Bottleneck is limited to the selected branch and direction.
  auto candidateUp = selectedSlot==0 ? primaryDevices.Get(0) :
    (selectedSlot==1 ? secondaryDevices.Get(0) : thirdDevices.Get(0));
  auto candidateDown = selectedSlot==0 ? primaryDevices.Get(1) :
    (selectedSlot==1 ? secondaryDevices.Get(1) : thirdDevices.Get(1));
  // Only selected physical branch throttled; both unmonitored and monitored
  // uses the SAME link speeds and NFD FIB-first selected Face.
  DynamicCast<PointToPointNetDevice>(candidateUp)->SetDataRate(DataRate(forwardBps));
  // Physical packet-level loss, deliberately distinct from NFD InterestDrop.
  // Never alias device Drop to NFD onDroppedInterest.
  if (p12xProbe=="L2_DROP_PRESSURE")
    DynamicCast<PointToPointNetDevice>(candidateUp)->SetDataRate(DataRate(640));
  DynamicCast<PointToPointNetDevice>(candidateDown)->SetDataRate(DataRate(returnBps));
  auto relayUp = DynamicCast<PointToPointNetDevice>(relayLinks[selectedSlot].Get(0));
  auto midUp = DynamicCast<PointToPointNetDevice>(midLinks[selectedSlot].Get(0));
  auto producerDown = DynamicCast<PointToPointNetDevice>(midLinks[selectedSlot].Get(1));
  if (!relayUp || !midUp || !producerDown) throw std::runtime_error("Selected remote devices missing");
  relayUp->SetDataRate(DataRate(remoteForwardRate));
  midUp->SetDataRate(DataRate(midForwardRate));
  producerDown->SetDataRate(DataRate(producerReturnRate));
  // Mid -> Relay is relayLinks[selectedSlot].Get(1).
  auto midDown = DynamicCast<PointToPointNetDevice>(relayLinks[selectedSlot].Get(1));
  // Relay->Node1 sender is candidateDown (the relay-side net device);
  // the receiver of this packet flow is candidateUp (node1-side net device).
  auto relayDown = DynamicCast<PointToPointNetDevice>(candidateDown);
  auto lossReceiver = DynamicCast<PointToPointNetDevice>(candidateUp);
  if (!midDown || !relayDown || !lossReceiver) throw std::runtime_error("SELECTED_REVERSE_DEVICES_MISSING");
  midDown->SetDataRate(DataRate(midReturnRate));
  relayDown->SetDataRate(DataRate(relayReturnRate));
  // Runtime identity check against the immutable INTERVENTION_SITES_LOCKED_12.csv.
  Ptr<PointToPointNetDevice> targetDevice = interventionLocation=="PRODUCER_RETURN" ? producerDown :
    (interventionLocation=="MID_RETURN" ? midDown : relayDown);
  const uint32_t expectedSender = interventionLocation=="PRODUCER_RETURN" ? midToProducerBySlot[selectedSlot] :
     (interventionLocation=="MID_RETURN" ? relayToMid[selectedSlot] : 2u+selectedSlot);
  if (targetDevice->GetNode()->GetId()!=expectedSender || targetDevice->GetIfIndex()!=0u)
     throw std::runtime_error("LOCKED_SENDER_DEVICE_IDENTITY_MISMATCH");
  if (lossReceiver->GetNode()->GetId()!=1u || lossReceiver->GetIfIndex()!=selectedSlot+1u)
     throw std::runtime_error("LOCKED_RECEIVER_DEVICE_IDENTITY_MISMATCH");
  // ErrorModel is installed on the receiver of Relay->Node1, never on producer.
  if (isLossArm) {
    auto lossModel = CreateObject<RateErrorModel>();
    lossModel->SetUnit(RateErrorModel::ERROR_UNIT_PACKET);
    lossModel->SetRate(lossProbability);
    lossModel->AssignStreams(lossStream);
    lossReceiver->SetReceiveErrorModel(lossModel);
  }
  if (!lossReceiver->TraceConnectWithoutContext("PhyRxDrop",
         MakeBoundCallback(&RecordRxDrop, &faults, 1u, selectedSlot+1u)))
    throw std::runtime_error("MISSING_NODE1_PHY_RX_DROP_TRACE");

  ns3::ndn::StackHelper stack;
  // Disable all content stores for the controlled queue/loss experiment.
  // Cache and retransmission remain separately evidenced in approved 1S/1U.
  stack.setCsSize(0);
  stack.InstallAll();
  ns3::ndn::StrategyChoiceHelper::InstallAll("/hcraf", "/localhost/nfd/strategy/best-route");
  // Native NFD BestRoute is used for diagnostic controls ONLY.
  // This does not implement or alter the HCRAF two-branch/Gate strategy.
  // No special forwarding policy: all controls use native NFD BestRoute.
  // An absent route is deliberately created ONLY in the no-route control.
  ns3::ndn::FibHelper::AddRoute(nodes.Get(0), "/hcraf", nodes.Get(1), 1);
  // Actual FIB cost-1 branch is the registered Face.  This guarantees
  // uninstrumented native NFD BestRoute chooses the SAME selected branch.
  // Instrumented collector also picks the first eligible (uniform draw 1/6).
  for (uint32_t s=0; s<3; ++s) {
    const uint32_t rank = (s==selectedSlot ? 1u : (s<selectedSlot ? s+2u : s+1u));
    ns3::ndn::FibHelper::AddRoute(nodes.Get(1), "/hcraf", nodes.Get(2+s), rank);
  }
  for (uint32_t s=0; s<3; ++s) {
    // Physical no-route probe, on the chosen relay ONLY, requires native NFD
    // downstream behavior; never forge a synthetic Nack signal.
    if (p12xProbe=="NACK_NO_ROUTE" && s==selectedSlot) continue;
    ns3::ndn::FibHelper::AddRoute(nodes.Get(2+s), "/hcraf", nodes.Get(relayToMid[s]), 1);
  }
  for (uint32_t s=0; s<3; ++s)
    ns3::ndn::FibHelper::AddRoute(nodes.Get(relayToMid[s]), "/hcraf", nodes.Get(midToProducerBySlot[s]), 1);
  std::ofstream producerReceipts(output + "/producer_receipts.jsonl");
  if (!producerReceipts) throw std::runtime_error("Cannot open independent producer receipts");
  const std::vector<uint32_t> producerNodes = {8u,9u,10u};
  for (uint32_t n : producerNodes) {
    auto responder = CreateObject<HcrafResponder>();
    responder->Configure(false,
      double(producerDelayMs)/1000.0,
      false, false, false, true, &producerReceipts); // identical 4096-byte Data content
    nodes.Get(n)->AddApplication(responder); responder->SetStartTime(Seconds(0));
  }
  auto requester = CreateObject<HcrafRequester>();
  requester->Configure(mode, output + "/consumer_events.jsonl", 0, requestOverride,
    intervalOverrideNs, lifetimeMs, "/hcraf/pilot", "TARGET", 129, targetOffsetNs, scheduleFamily,
    scheduleCsv, run, selectedSlot, prospectiveLoad);
  nodes.Get(0)->AddApplication(requester); requester->SetStartTime(Seconds(0));
  if (hasCompetitor) {
    auto competitor=CreateObject<HcrafRequester>();
    competitor->Configure(mode, output + "/competitor_events.jsonl", 1, competitorCount,
      competitorIntervalNs, lifetimeMs, "/hcraf/competitor", "INDEPENDENT_COMPETITOR", 139,
      competitorOffsetNs, scheduleFamily, scheduleCsv, run, selectedSlot, prospectiveLoad);
    nodes.Get(0)->AddApplication(competitor); competitor->SetStartTime(Seconds(0));
  }
  auto l3 = nodes.Get(1)->GetObject<ns3::ndn::L3Protocol>();
  auto primary = l3->getFaceByNetDevice(primaryDevices.Get(0));
  auto secondary = l3->getFaceByNetDevice(secondaryDevices.Get(0));
  auto third=l3->getFaceByNetDevice(thirdDevices.Get(0));
  if (!primary || !secondary || !third) throw std::runtime_error("Missing upstream Face mapping");
  auto forwarder = l3->getForwarder();
  std::ofstream p12xLiveSignals(output + "/p12x_live_nfd_negative_signals.jsonl");
  std::ofstream p12xLocalDrops(output + "/p12x_local_l2_queue_drop.jsonl");
  if (!p12xLiveSignals || !p12xLocalDrops)
    throw std::runtime_error("P12X_NEGATIVE_PATH_LOG_OPEN_FAILED");
  Ptr<PointToPointNetDevice> p12xDevice = DynamicCast<PointToPointNetDevice>(candidateUp);
  if (!p12xDevice || !p12xDevice->GetQueue() ||
      !p12xDevice->GetQueue()->TraceConnectWithoutContext("Drop",
        MakeBoundCallback(&P12XLocalQueueDrop, &p12xLocalDrops)))
    throw std::runtime_error("P12X_MISSING_REAL_L2_QUEUE_DROP_TRACE");
  std::ofstream telemetryRequests,telemetrySent,telemetryReceipts,telemetryDecisions;
  Ptr<HcrafQueueTelemetrySink> telemetrySink;
  if (telemetryEnabled) {
    // P1: The historical Stage1AH NFD recorder scopes /hcraf/* to a
    // three-eligible-Face Stage1M collector. Telemetry must use a SEPARATE
    // Name namespace so real NDN control Interests are forwarded by native
    // best-route without entering this scientific collector.
    // NDN control-plane Interest/Data traverse exactly the existing shared
    // point-to-point queues.  There is no direct cross-node read at node 1.
    telemetryRequests.open(output+"/queue_telemetry_requests.jsonl");
    telemetrySent.open(output+"/queue_telemetry_sent.jsonl");
    telemetryReceipts.open(output+"/queue_telemetry_receipts.jsonl");
    telemetryDecisions.open(output+"/queue_telemetry_decisions.jsonl");
    if (!telemetryRequests || !telemetrySent || !telemetryReceipts || !telemetryDecisions)
      throw std::runtime_error("TELEMETRY_OUTPUT_OPEN_FAILED");
    const uint32_t relayNode=relayDown->GetNode()->GetId();
    const uint32_t midNode=midDown->GetNode()->GetId();
    const uint32_t producerNode=producerDown->GetNode()->GetId();
    const std::map<std::string,std::pair<uint32_t,uint32_t>> sources={
      {"relay",{relayNode,relayDown->GetIfIndex()}},
      {"mid",{midNode,midDown->GetIfIndex()}},
      {"producer",{producerNode,producerDown->GetIfIndex()}}};
    // The first hop is the actual NFD Face ID, resolved at runtime rather
    // than relying on historical source/label trace rows.
    const std::string pathId="node1-face-"+std::to_string(
      selectedSlot==0?primary->getId():(selectedSlot==1?secondary->getId():third->getId()));
    for (const auto& s:std::vector<std::pair<std::string,Ptr<PointToPointNetDevice>>>{
         {"relay",relayDown},{"mid",midDown},{"producer",producerDown}}) {
      auto app=CreateObject<HcrafQueueTelemetrySource>();
      app->Configure(s.first,s.second,&telemetrySent);
      s.second->GetNode()->AddApplication(app);app->SetStartTime(Seconds(0));
    }
    ns3::ndn::FibHelper::AddRoute(nodes.Get(1),"/hcraf-queue-telemetry",nodes.Get(relayNode),1);
    ns3::ndn::FibHelper::AddRoute(nodes.Get(relayNode),"/hcraf-queue-telemetry/mid",nodes.Get(midNode),1);
    ns3::ndn::FibHelper::AddRoute(nodes.Get(relayNode),"/hcraf-queue-telemetry/producer",nodes.Get(midNode),1);
    ns3::ndn::FibHelper::AddRoute(nodes.Get(midNode),"/hcraf-queue-telemetry/producer",nodes.Get(producerNode),1);
    telemetrySink=CreateObject<HcrafQueueTelemetrySink>();
    telemetrySink->Configure(telemetryPeriodMs,pathId,sources,
                            &telemetryRequests,&telemetryReceipts,&telemetryDecisions,
                            prospectiveTelemetryStreamSeed%20000000ULL);
    nodes.Get(1)->AddApplication(telemetrySink);telemetrySink->SetStartTime(Seconds(0));
  }
  if (instrument) {
    forwarder->hcrafEnable(output + "/events.jsonl", nodes.Get(1)->GetId());
    // Deliberately deterministic allocation; nominal Uniform prob 1/3 is NOT
    // the behavioral propensity for this forced action (which is 1).
    forwarder->hcrafEnableCoverage([]() { return 1.0/6.0; }, false);
  }
  std::vector<std::shared_ptr<nfd::Forwarder>> relayForwarders;
  for (uint32_t s=0; s<3; ++s) {
    auto relay=nodes.Get(2+s)->GetObject<ns3::ndn::L3Protocol>()->getForwarder();
    relayForwarders.push_back(relay);
    if (instrument)
      relay->hcrafEnable(output + "/events_hop2_node" + std::to_string(2+s) + ".jsonl", 2+s);
  }
  std::unique_ptr<HcrafStage1wMonitor> linkMonitor;
  std::unique_ptr<HcrafPathwideWitnessB> pathwideWitnessB;
  std::ofstream observerCosts;
  std::ofstream nfdDispatchCosts;
  std::unique_ptr<HcrafStage1amLocalSnapshot> liveLocalQueue;
  std::unique_ptr<HcrafP12TNativeWiring> nativeWiring;
  std::unique_ptr<HcrafP12VNativeWiring> nativeV;
  if (instrument) {
    linkMonitor.reset(new HcrafStage1wMonitor(nodes, output + "/link_events.jsonl"));
    const std::string witnessRunId = "v05239-P12T-DEVELOPMENT-"+std::to_string(run)+
      "-"+prospectiveLoad+"-"+pathArm+"-telemetry-"+
      (telemetryEnabled?"on20":"off");
    pathwideWitnessB.reset(new HcrafPathwideWitnessB(nodes, output + "/pathwide_witness_b.jsonl", witnessRunId, selectedSlot));
    // Only the three LOCAL interfaces of the actual decision router are read.
    liveLocalQueue.reset(new HcrafStage1amLocalSnapshot(output + "/nfd_local_queue_at_decision.jsonl"));
    liveLocalQueue->AddCandidate(DynamicCast<PointToPointNetDevice>(primaryDevices.Get(0)),primary->getId());
    liveLocalQueue->AddCandidate(DynamicCast<PointToPointNetDevice>(secondaryDevices.Get(0)),secondary->getId());
    liveLocalQueue->AddCandidate(DynamicCast<PointToPointNetDevice>(thirdDevices.Get(0)),third->getId());
    Ptr<PointToPointNetDevice> selectedLocalDev =
      selectedSlot==0 ? DynamicCast<PointToPointNetDevice>(primaryDevices.Get(0)) :
      (selectedSlot==1 ? DynamicCast<PointToPointNetDevice>(secondaryDevices.Get(0)) :
                         DynamicCast<PointToPointNetDevice>(thirdDevices.Get(0)));
    const auto selectedLocalFace = selectedSlot==0 ? primary->getId() :
      (selectedSlot==1 ? secondary->getId() : third->getId());
    nativeWiring.reset(new HcrafP12TNativeWiring(
      output + "/p12t_native_local_at_decision.jsonl",selectedLocalDev,
      selectedLocalFace,1u,forwarder));
    // NFD source signals, emitted inside pinned Forwarder methods, guarantee
    // observation before current PIT decision and before outgoing TX.
    nativeV.reset(new HcrafP12VNativeWiring(
      output + "/p12v_native_local_12_at_decision.jsonl",selectedLocalDev,
      selectedLocalFace,1u,forwarder));
    forwarder->hcrafP12VInterestIn.connect([&nativeV](const ::ndn::Interest& i,const nfd::Face& f){nativeV->InterestIn(i,f);});
    forwarder->hcrafP12VDataIn.connect([&nativeV](const ::ndn::Data& d,const nfd::Face& f){nativeV->DataIn(d,f);});
    forwarder->hcrafP12VNackIn.connect([&nativeV](const ::ndn::lp::Nack& n,const nfd::Face& f){nativeV->NackIn(n,f);});
    forwarder->hcrafP12VNackIn.connect([&p12xLiveSignals](const ::ndn::lp::Nack& n,const nfd::Face& f) {
      const auto name=n.getInterest().getName().toUri();
      if (!HcrafP12VNativeWiring::research(name))return;
      p12xLiveSignals << "{\"event\":\"NFD_NATIVE_NACK_IN\",\"time_ns\":"
        << Simulator::Now().GetNanoSeconds() << ",\"face_id\":" << f.getId()
        << ",\"reason\":" << static_cast<int>(n.getReason())
        << ",\"name\":" << hcraf::Recorder::quote(name) << "}\n";
      if (!p12xLiveSignals)throw std::runtime_error("P12X_NACK_SIGNAL_WRITE_FAILED");
    });
    forwarder->hcrafP12VInterestTx.connect([&nativeV](const ::ndn::Interest& i,const nfd::Face& f){nativeV->InterestTx(i,f);});
    forwarder->hcrafP12VInterestDrop.connect([&nativeV](const ::ndn::Interest& i,const nfd::Face& f){nativeV->InterestDrop(i,f);});
    forwarder->hcrafP12VInterestDrop.connect([&p12xLiveSignals](const ::ndn::Interest& i,const nfd::Face& f) {
      const auto name=i.getName().toUri();
      if (!HcrafP12VNativeWiring::research(name))return;
      p12xLiveSignals << "{\"event\":\"NFD_NATIVE_INTEREST_DROP\",\"time_ns\":"
        << Simulator::Now().GetNanoSeconds() << ",\"face_id\":" << f.getId()
        << ",\"name\":" << hcraf::Recorder::quote(name) << "}\n";
      if (!p12xLiveSignals)throw std::runtime_error("P12X_NFD_DROP_SIGNAL_WRITE_FAILED");
    });
    forwarder->beforeSatisfyInterest.connect([&nativeV](const nfd::pit::Entry& p,const nfd::Face& f,const ::ndn::Data& d){nativeV->Satisfied(p,f,d);});

    nfdDispatchCosts.open(output + "/nfd_dispatch_cost.jsonl");
    if (!nfdDispatchCosts) throw std::runtime_error("Cannot open NFD dispatch cost log");
    forwarder->hcrafSetDispatchTimingObserver([&nfdDispatchCosts](uint64_t id, uint64_t wall, uint64_t cpu) {
      nfdDispatchCosts << "{\"decision_id\":" << id << ",\"NFD_forwarding_path_wall_ns\":" << wall
        << ",\"NFD_forwarding_path_cpu_ns\":" << cpu
        << ",\"includes_telemetry_and_recorder\":true,\"is_HCRAF_Gate_only_cost\":false}\n";
      if (!nfdDispatchCosts) throw std::runtime_error("NFD dispatch cost write failed");
    });
    observerCosts.open(output + "/observer_cost.jsonl");
    if (!observerCosts) throw std::runtime_error("Cannot open observer cost log");
    forwarder->hcrafSetDecisionObserver([&linkMonitor, &observerCosts, &liveLocalQueue, &nativeWiring, &nativeV, telemetrySink](uint64_t id) {
      // Invoked from NFD beginDecision BEFORE actual selected Face TX.
      liveLocalQueue->ObserveBeforeForwarding(id);
      nativeWiring->BeforeDecision(id);
      nativeV->BeforeDecision(id);
      if (telemetrySink) telemetrySink->ObserveBeforeForwarding(id);
      const auto a = std::chrono::steady_clock::now();
      linkMonitor->Snapshot(id);
      const auto b = std::chrono::steady_clock::now();
      const auto duration = std::chrono::duration_cast<std::chrono::nanoseconds>(b-a).count();
      observerCosts << "{\"decision_id\":" << id << ",\"snapshot_observer_wall_ns\":" << duration
                    << ",\"is_NFD_decision_latency\":false}\n";
      if (!observerCosts) throw std::runtime_error("Observer timing write failure");
    });
  }
  std::ofstream control(output + "/control_events.jsonl");
  if (!control) throw std::runtime_error("Cannot open control log");
  std::ofstream config(output + "/scenario.json");
  // Explicit local device validation: avoid using hardcoded Face IDs.
  const std::vector<uint64_t> actualFaces = {primary->getId(),secondary->getId(),third->getId()};
  const uint32_t selectedRelay=2+selectedSlot;
  const uint32_t selectedMid=relayToMid[selectedSlot];
  const uint32_t selectedProducer=midToProducerBySlot[selectedSlot];
  const uint64_t plannedCount = requestOverride;
  const uint64_t nominalInterval = intervalOverrideNs;
  if (!plannedCount || !nominalInterval) throw std::runtime_error("1AF requires explicit registered traffic plan");
  config << "{\"mode\":" << hcraf::Recorder::quote(mode)
    << ",\"p12x_exploratory_diagnostic_only\":true"
    << ",\"p12x_fault_probe\":" << hcraf::Recorder::quote(p12xProbe)
    << ",\"p12x_not_in_preregistered_P12R_experimental_matrix\":true"
    << ",\"p12x_data_must_never_enter_training_or_confirmation\":true"
    << ",\"p12x_selected_local_device_bps_actual\":"
    << (p12xProbe=="L2_DROP_PRESSURE"?640ULL:forwardBps)
    << ",\"p12x_nfd_interest_drop_distinct_from_l2_packet_drop\":true"
    << ",\"collector_stage\":\"1AM.NFD_LOCAL_QUEUE.0\""
    << ",\"amendment_stage\":\"1AM.F3.P12T.DEV_SENTINEL_V05239.0\""
    << ",\"phase_arm\":" << hcraf::Recorder::quote(phaseArm)
    << ",\"schedule_family\":" << hcraf::Recorder::quote(scheduleFamily)
    << ",\"schedule_contract\":\"P12R_V05237_FAIR_LOCAL_DEV_PREREG_LOCKED_CSV\""
    << ",\"independent_rng_block\":" << run
    << ",\"target_offset_ns\":" << targetOffsetNs
    << ",\"schedule_csv_filename\":" << hcraf::Recorder::quote(replicationLockedFilename)
    << ",\"schedule_execution_source\":\"IMMUTABLE_V05225_REPLICATION_PREREG_CSV\""
    << ",\"p12k_replication_site\":" << hcraf::Recorder::quote(pilotSite)
    << ",\"p12l6_replication_authorized_after_p12k_prereg_run\":true"
    << ",\"p4_prospective_load\":" << hcraf::Recorder::quote(prospectiveLoad)
    << ",\"p4_locked_traffic_stream_seed\":" << prospectiveTrafficStreamSeed
    << ",\"p4_locked_routing_stream_seed\":" << prospectiveRoutingStreamSeed
    << ",\"p4_locked_telemetry_stream_seed\":" << prospectiveTelemetryStreamSeed
    << ",\"p4_telemetry_poll_offset_ns\":" << (prospectiveTelemetryStreamSeed%20000000ULL)
    << ",\"p4_split_separation_enforced\":true"
    << ",\"no_counterfactual_unselected_face\":true"
    << ",\"topology_id\":" << hcraf::Recorder::quote(topology)
    << ",\"selected_face_slot\":" << selectedSlot
    << ",\"selected_face_id\":" << actualFaces[selectedSlot]
    << ",\"actual_assignment_probability\":1.0"
    << ",\"nominal_uniform_probability_NOT_behavioral_propensity\":0.33333333333333331"
    << ",\"selection_policy\":\"FORCED_DETERMINISTIC_DRAW_UNIFORM_NOMINAL\""
    << ",\"eligible_face_ids\":[" << actualFaces[0] << "," << actualFaces[1] << "," << actualFaces[2] << "]"
    << ",\"path_nodes\":[0,1," << selectedRelay << "," << selectedMid << "," << selectedProducer << "]"
    << ",\"network_node_count\":11,\"network_directed_device_count\":20"
    << ",\"research_partition\":\"FAIR_LOCAL_DEV\""
    << ",\"decision_node_id\":1,\"selected_relay_node_id\":" << selectedRelay
    << ",\"selected_mid_node_id\":" << selectedMid
    << ",\"selected_producer_node_id\":" << selectedProducer
    << ",\"purpose\":\"P12T_P12R_FAIR_LOCAL_DEV_SMOKE_NO_HELDOUT_NO_FIT\""
    << ",\"seed\":" << seed << ",\"run\":" << run
    << ",\"instrument_enabled\":" << (instrument?"true":"false")
    << ",\"traffic_class_primary\":\"TARGET\""
    << ",\"traffic_class_competitor\":\"INDEPENDENT_COMPETITOR\""
    << ",\"target_prefix\":\"/hcraf/pilot\""
    << ",\"competitor_prefix\":\"/hcraf/competitor\""
    << ",\"competitor_injection_enabled\":" << (hasCompetitor?"true":"false")
    << ",\"competitor_planned_requests\":" << competitorCount
    << ",\"competitor_interval_ns\":" << competitorIntervalNs
    << ",\"competitor_offset_ns\":" << competitorOffsetNs
    << ",\"competitor_pulse_schedule\":\"P12R_V05237_PRECOMMITTED_TAIL_PROBE_CSV_ONLY\""
    << ",\"competitor_burst_start_rng_stream\":null"
    << ",\"competitor_pulse_spacing_ns\":null"
    << ",\"competitor_pulse_count\":null"
    << ",\"target_schedule_rng_stream\":null,\"competitor_schedule_rng_stream\":null"
    << ",\"planned_requests\":" << plannedCount
    << ",\"nominal_arrival_interval_ns\":" << nominalInterval
    << ",\"randomized_arrival_jitter_stream\":null"
    << ",\"interest_lifetime_ms\":" << lifetimeMs
    << ",\"stop_ns\":20000000000,\"cache_enabled\":false,\"multi_hop_enabled\":true"
    << ",\"p12t_native_pit_and_queue_diagnostic_only\":true"
    << ",\"p12t_all_B1_features_valid\":false"
    << ",\"p12t_new_training_authorized\":false"
    << ",\"queue_capacity_packets\":" << technicalQueueMaxPackets
    << ",\"v0520_locked_reference_queue_capacity_packets\":20,\"queue_trace_schema\":\"1W.0\""
    << ",\"mtu_bytes\":" << (fragmented?600:9000)
    << ",\"payload_bytes\":4096"
    << ",\"selected_forward_bps\":" << forwardBps
    << ",\"selected_relay_forward_bps\":" << remoteForwardRate
    << ",\"selected_mid_forward_bps\":" << midForwardRate
    << ",\"selected_producer_reverse_bps\":" << producerReturnRate
    << ",\"selected_mid_reverse_bps\":" << midReturnRate
    << ",\"selected_relay_reverse_bps\":" << relayReturnRate
    << ",\"intervention_location\":" << hcraf::Recorder::quote(interventionLocation)
    << ",\"intervention_return_bps\":" << interventionReturnBps
    << ",\"loss_kind\":" << hcraf::Recorder::quote(isLossArm?"RATE_ERROR_MODEL_RX":"NONE")
    << ",\"loss_probability\":" << lossProbability
    << ",\"loss_stream\":" << lossStream
    << ",\"loss_receiver_node_id\":" << lossReceiverNodeId
    << ",\"loss_receiver_device_index\":" << lossReceiverDeviceIndex
    << ",\"only_locked_physical_intervention_varies\":\"P4_REGISTERED_LOCATION_AND_LOAD_AND_TELEMETRY_FACTORS\""
    << ",\"technical_queue_max_packets\":" << technicalQueueMaxPackets
    << ",\"p3_dev_global_queue_cap_override_not_in_v0520_lock\":false"
    << ",\"p3_queue_capacity_intervention_is_exploratory_only\":false"
    << ",\"candidate_negative_control_is_not_scientific_label\":true"
    << ",\"selected_return_bps\":" << returnBps
    << ",\"theta_pilot\":2,\"horizon_ms_pilot\":2000"
    << ",\"future_oracle_horizon_ns_pilot\":75000000"
    << ",\"diagnostic_horizons_ms\":[50,75,100]"
    << ",\"whole_path_oracle_is_retrospective\":true"
    << ",\"path_reverse_fragment_unclassifiable_means_UNKNOWN\":true"
    << ",\"future_oracle_scope\":\"EIGHT_DEVICES_FOUR_HOP_FRAGMENT_AWARE_WITH_CENSORING\""
    << ",\"pathwide_witness_b_version\":\"PATHWIDE_WITNESS_B.1\""
    << ",\"pathwide_witness_b_independent_software_only\":true"
    << ",\"future_oracle_is_final_F3\":false"
    << ",\"M0_raw_wait_is_not_final_F3\":true"
    << ",\"group_aware_metric_candidates\":[\"M0\",\"M1\",\"M2\",\"M3\"]"
    << ",\"independent_physical_pressure_test\":true"
    << ",\"paired_target_arrivals_must_match\":true"
    << ",\"paired_comparison_is_same_selected_face_not_unselected_counterfactual\":true"
    << ",\"decision_time_us_real_HCRAF\":null,\"observer_cost_is_decision_time\":false"
    << ",\"local_NFD_queue_observed_before_send\":" << (instrument?"true":"false")
    << ",\"NFD_dispatch_wall_CPU_measured\":" << (instrument?"true":"false")
    << ",\"NFD_cost_includes_recorder\":true"
    << ",\"remote_queue_online_feature\":" << (telemetryEnabled?"true":"false")
    << ",\"telemetry_enabled\":" << (telemetryEnabled?"true":"false")
    << ",\"telemetry_transport\":\"NDN_INTEREST_DATA_REAL_NETWORK_PROSPECTIVE_DEV\""
    << ",\"telemetry_period_ms\":" << telemetryPeriodMs
    << ",\"telemetry_reports_observed_by_node1_app\":" << (telemetryEnabled?"true":"false")
    << ",\"telemetry_path_discovery_independently_audited\":false"
    << ",\"NFD_telemetry_control_excluded_from_research_recorder\":true"
    << ",\"NFD_control_isolation_patch\":\"v0.52.2-P1-pinned-recorder-scope\""
    << ",\"NFD_decision_stream_includes_control_interests\":false"
    << ",\"telemetry_smoke_only\":false"
    << ",\"path_first_face_is_fib_cost_1\":true"
    << ",\"official_F3_labels_constructed\":0,\"F3_PR_AUC_computed\":false"
    << ",\"heldout_release_authorized\":false"
    << ",\"congestion\":null,\"future_congestion\":null,\"F3_ready\":false,\"training_ready\":false"
    << ",\"Congestion\":null,\"FutureCongestion\":null,\"GO_FREEZE\":false}\n";
  config.flush();
  if (!config) throw std::runtime_error("Cannot write configuration");
  config.close();
  Simulator::Stop(Seconds(20)); Simulator::Run();
  if (instrument) {
    forwarder->hcrafFinish(); forwarder->hcrafSetDecisionObserver({});
    forwarder->hcrafSetDispatchTimingObserver({});
    nativeWiring->Finish();
    nativeV->Finish();
    liveLocalQueue->Finish();nfdDispatchCosts.flush();
    if (!nfdDispatchCosts) throw std::runtime_error("NFD cost log flush failed");
    for (auto& relay : relayForwarders) relay->hcrafFinish();
    linkMonitor->Finish();
    pathwideWitnessB->Finish();
    observerCosts.flush();
    if (!observerCosts) throw std::runtime_error("Observer cost flush failure");
  }
  if (telemetryEnabled) {
    telemetryRequests.flush();telemetrySent.flush();telemetryReceipts.flush();telemetryDecisions.flush();
    if (!telemetryRequests || !telemetrySent || !telemetryReceipts || !telemetryDecisions)
      throw std::runtime_error("TELEMETRY_LOG_FLUSH_FAILED");
  }
  p12xLiveSignals.flush(); p12xLocalDrops.flush();
  if (!p12xLiveSignals || !p12xLocalDrops)
    throw std::runtime_error("P12X_NATIVE_EVENT_LOG_FLUSH_FAILED");
  Simulator::Destroy();
  return 0;
}
