import pathlib,unittest,ast
P=pathlib.Path(__file__).resolve().parents[1]
C=(P/'src/hcraf-stage1am-f3-p12x-native-negative-path-v05243.cpp').read_text()
R=(P/'scripts/run_stage1am_f3_p12x_v05243.py').read_text()
B=(P/'scripts/build_stage1am_f3_p12x_v05243.sh').read_text()
class P12X(unittest.TestCase):
 def test_two_exploratory_probes_only(self):
  self.assertIn('NACK_NO_ROUTE',C);self.assertIn('L2_DROP_PRESSURE',C)
  self.assertIn("PROBES=('NACK_NO_ROUTE','L2_DROP_PRESSURE')",R)
 def test_true_no_route_experiment(self):
  self.assertIn('if (p12xProbe=="NACK_NO_ROUTE" && s==selectedSlot) continue;',C)
 def test_real_physical_local_drop(self):
  self.assertIn('SetDataRate(DataRate(640))',C)
  self.assertIn('TraceConnectWithoutContext("Drop"',C)
  self.assertIn('L2_QUEUE_DROP_NOT_NFD_DROP',C)
 def test_no_alias_native_drop_and_l2(self):
  self.assertIn('NFD_NATIVE_INTEREST_DROP',C);self.assertIn('NFD_NATIVE_NACK_IN',C)
  self.assertIn('NFD_drop_is_not_L2_drop',R)
 def test_original_native_NFD_signals_not_simulated(self):
  self.assertIn('hcrafP12VNackIn.connect',C)
  self.assertIn('hcrafP12VInterestDrop.connect',C)
  self.assertNotIn('nativeV->NackIn(::ndn::lp::Nack',C)
 def test_real_compiler_pinned_parent(self):
  self.assertIn('build_stage1am_f3_p12v_native_v05241.sh',B)
  self.assertIn('python3 ./waf -j 2',B)
 def test_no_preregistered_trial_claims(self):
  self.assertIn('p12x_not_in_preregistered_P12R_experimental_matrix',C)
  self.assertIn('exploratory_not_valid_P12R_dev_or_confirmation',R)
 def test_no_false_go(self):
  for x in ["'F3_ready':False","'GO_FREEZE':False","'training_ready':False","'new_AP_computed':False"]:self.assertIn(x,R)
 def test_dev_partition_only(self):
  self.assertIn("r['seed']=='24901'",R)
  self.assertIn('p12t.plan()',R)
 def test_no_fabricated_native_signals(self):
  self.assertNotIn('hcrafP12VNackIn(',C)
  self.assertNotIn('hcrafP12VInterestDrop(',C)
 def test_stable_parse(self):
  ast.parse(R)
 def test_log_count_based_coverage(self):
  self.assertIn("nack=sum(e['event']=='NFD_NATIVE_NACK_IN'",R)
  self.assertIn("drop=sum(e['event']=='NFD_NATIVE_INTEREST_DROP'",R)
 def test_zero_is_no_coverage(self):
  self.assertIn('nack>0',R);self.assertIn('drop>0',R)
if __name__=='__main__':unittest.main()
