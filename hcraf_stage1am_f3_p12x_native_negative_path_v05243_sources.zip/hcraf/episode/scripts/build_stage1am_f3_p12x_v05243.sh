#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
# Immutable P12V build recipe recompiled first, including NFD pinned callbacks.
bash "$ROOT/hcraf/episode/scripts/build_stage1am_f3_p12v_native_v05241.sh"
NS3="$ROOT/episode_sources/ns-3"
CPP="$ROOT/hcraf/episode/src/hcraf-stage1am-f3-p12x-native-negative-path-v05243.cpp"
DEST="$NS3/scratch/hcraf-stage1am-f3-p12x-native-negative-path-v05243.cc"
cp "$CPP" "$DEST"
cmp -s "$CPP" "$DEST"
(cd "$NS3" && python3 ./waf -j 2)
test -x "$NS3/build/scratch/hcraf-stage1am-f3-p12x-native-negative-path-v05243"
echo PASS_P12X_PINNED_NFD_PHYSICAL_PROBE_BINARY_COMPILED_NO_SCORES
