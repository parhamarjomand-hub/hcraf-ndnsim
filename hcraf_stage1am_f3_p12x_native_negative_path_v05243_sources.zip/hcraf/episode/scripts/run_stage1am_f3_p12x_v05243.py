#!/usr/bin/env python3
"""New exploratory physical NFD negative-path coverage; NOT part of P12R's trials.
Only reuse frozen P12R development seed 24901 scheduling as input stimulus. Never
release heldout, compute F3 AP, train, or label these interventions as fair trials.
"""
import argparse, importlib.util, json, subprocess, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
PARENT=ROOT/'hcraf/episode/scripts/run_stage1am_f3_p12t_smoke_v05239.py'
SPEC=importlib.util.spec_from_file_location('p12t_schedule_driver_only',PARENT)
p12t=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(p12t)
OUTPUT=ROOT/'episode_output/stage1am_f3_p12x_v05243'
BIN='hcraf-stage1am-f3-p12x-native-negative-path-v05243'
PROBES=('NACK_NO_ROUTE','L2_DROP_PRESSURE')

def need(x,tag):
 if not x: raise RuntimeError('P12X_'+tag)
def rows(p):
 need(p.is_file(),'MISSING_'+p.name)
 return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]
def audit(d,probe):
 scenario=json.loads((d/'scenario.json').read_text())
 need(scenario['p12x_exploratory_diagnostic_only'] is True,'NO_DIAGNOSTIC_PROVENANCE')
 need(scenario['p12x_fault_probe']==probe,'PROBE_SCENARIO_MISMATCH')
 need(scenario['p12x_not_in_preregistered_P12R_experimental_matrix'] is True,'MISCLASSIFIED_PREREG')
 need(scenario['p12x_data_must_never_enter_training_or_confirmation'] is True,'TRAINING_REUSE_FORBIDDEN')
 need(scenario['seed']==17 and scenario['run']==24901,'WRONG_ONLY_DEV_SEED')
 native=rows(d/'p12v_native_local_12_at_decision.jsonl')
 before=rows(d/'p12t_native_local_at_decision.jsonl')
 need(len(native)==len(before)==128,'NOT_128_DECISIONS')
 for i,(a,b) in enumerate(zip(native,before),1):
  need(a['decision_id']==b['decision_id']==i and a['time_ns']==b['time_ns'],'TIME_ID_DESYNC')
  v=a['b1_all_twelve_native'];need(len(v)==12 and a['node_id']==1,'BAD_NATIVE_12_SLOTS')
  need(all(abs(v[j]-b['b1_first_five_native'][j])<1e-9 for j in range(5)),'FIRST_FIVE_DIFFER')
  need(not a['all_B1_features_validated'] and not a['model_training_authorized'] and not a['F3_ready'] and not a['GO_FREEZE'],'F3_FALSE_RELEASE')
 for x,y in zip(native,native[1:]):
  need(x['time_ns']<=y['time_ns'],'NONMONOTONE_DECISION')
  for k in ('live_NFD_interest_rx_total','live_NFD_data_rx_total','live_NFD_nack_rx_total','live_NFD_interest_tx_total','live_NFD_interest_drop_total','locally_completed_RTT_total'):
   need(x[k]<=y[k],'NONMONOTONE_EVENT_'+k)
 events=rows(d/'p12x_live_nfd_negative_signals.jsonl')
 local_l2=rows(d/'p12x_local_l2_queue_drop.jsonl')
 need(all(e['event'] in ('NFD_NATIVE_NACK_IN','NFD_NATIVE_INTEREST_DROP') and e['face_id']>0 for e in events),'INVALID_NATIVE_EVENT')
 need(all(e['event']=='L2_QUEUE_DROP_NOT_NFD_DROP' and e['packet_size_bytes']>0 for e in local_l2),'INVALID_L2_EVENT')
 nack=sum(e['event']=='NFD_NATIVE_NACK_IN' for e in events)
 drop=sum(e['event']=='NFD_NATIVE_INTEREST_DROP' for e in events)
 need(native[-1]['live_NFD_nack_rx_total']<=nack,'NACK_COUNTER_MUST_NOT_EXCEED_RAW_EVENTS')
 need(native[-1]['live_NFD_interest_drop_total']<=drop,'DROP_COUNTER_MUST_NOT_EXCEED_RAW_EVENTS')
 result={'probe':probe,'physical_real_ns3':True,'physical_NFD_native_Nack_events':nack,
  'physical_NFD_native_InterestDrop_events':drop,'physical_local_link_layer_queue_drop_frames':len(local_l2),
  'NFD_drop_is_not_L2_drop':True,'native_128_decisions':len(native),
  'nack_path_physically_exercised':nack>0,'nfd_interest_drop_path_physically_exercised':drop>0,
  'NFD_counters_at_last_decision':{k:native[-1][k] for k in ('live_NFD_nack_rx_total','live_NFD_interest_drop_total')},
  'exploratory_not_valid_P12R_dev_or_confirmation':True,'can_train':False,'new_AP_computed':False,
  'model_fits':0,'F3_ready':False,'GO_FREEZE':False,'training_ready':False,
  'Congestion':None,'FutureCongestion':None,'confirmation_seed_reads':0,'heldout_reads':0}
 (d/'P12X_PROBE_PHYSICAL_DIAGNOSTIC_v05243.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
 return result

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--preflight-only',action='store_true');args=ap.parse_args()
 r,p=p12t.plan()
 need(r['seed']=='24901' and r['partition']=='FAIR_LOCAL_DEV','FORBIDDEN_PARTITION')
 need(r['schedule_sha256']==hashlib.sha256(p.read_bytes()).hexdigest(),'MUTATED_FROZEN_SCHEDULE')
 print('PASS_P12X_FROZEN_DEV_SCHEDULE_USED_AS_STIMULUS_ONLY',r['seed'])
 if args.preflight_only:return
 need(not OUTPUT.exists(),'REFUSE_OVERWRITE')
 need((ROOT/'episode_sources/ns-3/build/scratch'/BIN).is_file(),'PINNED_BINARY_MISSING')
 OUTPUT.mkdir(parents=True)
 results=[]
 for probe in PROBES:
  out=OUTPUT/probe
  out.mkdir()
  p12t.OUT=out
  p12t.BIN=BIN
  command=p12t.cmd(r,p)+' --p12xProbe='+probe
  (out/'command.txt').write_text(command+'\n')
  with (out/'simulator.log').open('w') as f:
   subprocess.run(['python3','./waf','--run-no-build',command],cwd=ROOT/'episode_sources/ns-3',stdout=f,stderr=subprocess.STDOUT,check=True)
  result=audit(out,probe)
  results.append(result)
  print('PASS_P12X_EXECUTED_REAL_PINNED_DIAGNOSTIC_ONLY',probe, 'NFD_NACK',result['physical_NFD_native_Nack_events'], 'NFD_DROP',result['physical_NFD_native_InterestDrop_events'], 'L2_DROP',result['physical_local_link_layer_queue_drop_frames'])
 report={'status':'PASS_P12X_TWO_EXPLORATORY_PHYSICAL_PROBES_EXECUTED_NOT_F3_VALIDATION',
  'parent_P12W_run':45878775964,'original_P12V_run':45868303602,'probe_count':len(results),
  'probes':results,'nfd_Nack_coverage_any':any(q['nack_path_physically_exercised'] for q in results),
  'nfd_InterestDrop_coverage_any':any(q['nfd_interest_drop_path_physically_exercised'] for q in results),
  'L2_drop_cannot_validate_NFD_drop':True,'can_train':False,'F3_ready':False,'GO_FREEZE':False,
  'training_ready':False,'heldout_reads':0,'confirmation_seed_reads':0,
  'model_fits':0,'new_AP_computed':False,'Congestion':None,'FutureCongestion':None}
 (OUTPUT/'P12X_NEGATIVE_PATH_COVERAGE_RECEIPT_v05243.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
 print(report['status'],'NACK_COVERED=',report['nfd_Nack_coverage_any'],'NFD_DROP_COVERED=',report['nfd_InterestDrop_coverage_any'])
if __name__=='__main__':main()
