#!/usr/bin/env python3
"""Deterministic DEV-only preregistration for v0.51.7; never launches ndnSIM.

This program produces prospective SHA-256-frozen traffic plans, intervention
inventory and paired arm matrix. All randomness depends only on MASTER_SEED,
run ID, family, phase assignment and sequence, not observed metrics.
"""
import argparse
import csv
import hashlib
import io
import json
from collections import Counter, defaultdict
from pathlib import Path

SCHEMA='HCRAF_F3_PATHWIDE_BOTTLENECK_RELOCATION_PREREG_V0517'
MASTER_SEED='HCRAF-PATHWIDE-RELOCATION-v0.51.7-20261112-PROSPECTIVE-DEV-ONLY'
RNGS=tuple(range(11901,11913))
FAMILIES=('A_SHIFTED_PULSES','B_INTERLEAVED_PULSES')
PHASE_MS=(-180,-60,60,180)
# Shared no-throttle 50Mbps baseline is physically identical at all locations.
ARMS=(
 ('PRODUCER_RETURN_6M','PRODUCER_RETURN',6000000,0.0),
 ('PRODUCER_RETURN_12M','PRODUCER_RETURN',12000000,0.0),
 ('MID_RETURN_6M','MID_RETURN',6000000,0.0),
 ('MID_RETURN_12M','MID_RETURN',12000000,0.0),
 ('RELAY_RETURN_6M','RELAY_RETURN',6000000,0.0),
 ('RELAY_RETURN_12M','RELAY_RETURN',12000000,0.0),
 ('ALL_RETURN_50M','NONE',50000000,0.0),
 ('NONQUEUE_RX_LOSS_50M','NONE',50000000,0.15),
)
ARM_BY_NAME={a[0]:a for a in ARMS}
OLD_PATHS={
 0: [(8,0,7,1),(7,0,2,1),(2,0,1,1),(2,0,1,1)],
 1: [(9,0,6,1),(6,0,3,1),(3,0,1,2),(3,0,1,2)],
 2: [(10,0,5,1),(5,0,4,1),(4,0,1,3),(4,0,1,3)],
}
LOCATION_TYPES=('PRODUCER_RETURN','MID_RETURN','RELAY_RETURN','NONQUEUE_RX_LOSS_RECEIVER')
SCHEDULE_FIELDS=('traffic_class','sequence','time_ns','family','rng_block','phase_label',
                 'phase_nominal_ns','phase_jitter_ns','selected_slot','schedule_schema')
INDEX_FIELDS=('rng_block','selected_slot','family','phase_label','phase_nominal_ns',
              'phase_jitter_ns','target_start_ns','competitor_start_ns','plan_filename',
              'schedule_sha256','target_schedule_sha256','competitor_schedule_sha256')
MATRIX_FIELDS=('run_id','rng_block','seed','selected_slot','family','phase_label',
               'arm','intervention_location','intervention_return_bps','other_path_return_bps',
               'forward_bps','loss_kind','loss_probability','loss_stream',
               'loss_receiver_node_id','loss_receiver_device_index','instrumented',
               'plan_filename','schedule_sha256','target_schedule_sha256',
               'competitor_schedule_sha256','status')
SITE_FIELDS=('selected_slot','intervention_location','sender_node_id','sender_device_index',
             'receiver_node_id','receiver_device_index','mapping_provenance','runtime_identity_crosscheck_required')
GATES={"Congestion":None,"FutureCongestion":None,"F3_ready":False,"GO_FREEZE":False,"training_ready":False}

def sha(blob): return hashlib.sha256(blob).hexdigest()
def digest(*parts): return hashlib.sha256('|'.join((MASTER_SEED,*map(str,parts))).encode('ascii')).digest()
def uval(mod,*parts): return int.from_bytes(digest(*parts)[:8],'big')%mod
def signed(bound,*parts): return uval(2*bound+1,*parts)-bound

def csv_bytes(rows,fields):
    buf=io.StringIO(newline='')
    w=csv.DictWriter(buf,fieldnames=fields,lineterminator='\n')
    w.writeheader();w.writerows(rows)
    return buf.getvalue().encode()

def allocation():
    phase={}
    for slot in range(3):
        rr=sorted((r for r in RNGS if (r-11901)%3==slot),key=lambda r:digest('phase-order',slot,r))
        assert len(rr)==4
        for p,r in enumerate(rr):phase[r]=p
    assert Counter(phase.values())=={0:3,1:3,2:3,3:3}
    controls={}
    # Each slot sees each arm exactly once among its 4 RNG x 2 families.
    for slot in range(3):
        cells=sorted(((rng,fam) for rng in RNGS if (rng-11901)%3==slot for fam in FAMILIES),
                     key=lambda c:digest('overhead-cell-order',*c))
        arms=sorted((arm[0] for arm in ARMS), key=lambda a:digest('overhead-arm-order',slot,a))
        assert len(cells)==len(arms)==8
        controls.update(dict(zip(cells,arms)))
    assert Counter(controls.values())=={arm[0]:3 for arm in ARMS}
    return phase,controls

def build_plan(rng,family,phase):
    slot=(rng-11901)%3
    offset=PHASE_MS[phase]*1000000
    jitter=signed(12000000,'phase-jitter',rng,family)
    target_start=2450000000+signed(100000000,'target-start',rng,family)
    competitor_start=target_start+offset+jitter
    rows=[]
    for cls,count in (('TARGET',12),('INDEPENDENT_COMPETITOR',96)):
        for i in range(count):
            if cls=='TARGET':
                base=30000000*i
                if family=='B_INTERLEAVED_PULSES':
                    base+=90000000*(i>=6)+(6000000 if i%2==0 else -6000000)
                when=target_start+base+signed(4000000,'target-delta',rng,family,i)
            elif family=='A_SHIFTED_PULSES':
                when=competitor_start+(i//48)*145000000+(i%48)*2000000+signed(100000,'competitor-delta',rng,family,i)
            else:
                when=competitor_start+(i//24)*110000000+(i%24)*2000000+signed(100000,'competitor-delta',rng,family,i)
            rows.append(dict(traffic_class=cls,sequence=i,time_ns=when,family=family,rng_block=rng,
                             phase_label=f'P{phase}',phase_nominal_ns=offset,phase_jitter_ns=jitter,
                             selected_slot=slot,schedule_schema=SCHEMA))
    rows.sort(key=lambda r:(r['time_ns'],r['traffic_class'],r['sequence']))
    assert len(rows)==108 and all(2000000000<=r['time_ns']<20000000000 for r in rows)
    for cls in ('TARGET','INDEPENDENT_COMPETITOR'):
        events=[r['time_ns'] for r in rows if r['traffic_class']==cls]
        assert len(events)==(12 if cls=='TARGET' else 96)
        assert len(events)==len(set(events)),(rng,family,cls)
    return rows,target_start,competitor_start

def build_files():
    phase,controls=allocation()
    files={}; index=[];matrix=[]
    for slot in range(3):
        for typ,ident in zip(LOCATION_TYPES,OLD_PATHS[slot]):
            assert ident[0] not in (0,1) or typ=='NONQUEUE_RX_LOSS_RECEIVER'
    sites=[]
    for slot in range(3):
        for typ,(sender,dev,receiver,recv_dev) in zip(LOCATION_TYPES,OLD_PATHS[slot]):
            sites.append(dict(selected_slot=slot, intervention_location=typ,sender_node_id=sender,
                 sender_device_index=dev,receiver_node_id=receiver,receiver_device_index=recv_dev,
                 mapping_provenance='V0515_PATH_MAP_LOCKED_24_AND_NATIVE_LINK_INSTALL',
                 runtime_identity_crosscheck_required='YES'))
    files['INTERVENTION_SITES_LOCKED_12.csv']=csv_bytes(sites,SITE_FIELDS)
    for rng in RNGS:
        p=phase[rng]
        for family in FAMILIES:
            rows,tstart,cstart=build_plan(rng,family,p)
            filename=f'plans/rng-{rng}_{family}.csv';data=csv_bytes(rows,SCHEDULE_FIELDS)
            files[filename]=data
            target_sha=sha(csv_bytes([r for r in rows if r['traffic_class']=='TARGET'],SCHEDULE_FIELDS))
            competitor_sha=sha(csv_bytes([r for r in rows if r['traffic_class']=='INDEPENDENT_COMPETITOR'],SCHEDULE_FIELDS))
            common=dict(rng_block=rng,selected_slot=(rng-11901)%3,family=family,
              phase_label=f'P{p}',plan_filename=filename,schedule_sha256=sha(data),
              target_schedule_sha256=target_sha,competitor_schedule_sha256=competitor_sha)
            index.append({**common,'phase_nominal_ns':PHASE_MS[p]*1000000,
                 'phase_jitter_ns':rows[0]['phase_jitter_ns'],'target_start_ns':tstart,'competitor_start_ns':cstart})
            for arm,loc,bps,loss in ARMS:
                for instrumented in (1,0):
                    if not instrumented and controls[(rng,family)]!=arm:continue
                    loss_node=1 if loss else -1
                    loss_dev=(1+((rng-11901)%3)) if loss else -1
                    matrix.append(dict(run_id=f'dev-v0517-rng-{rng}-{family}-{arm}-'+('mon' if instrumented else 'unmon'),
                       rng_block=rng,seed=17,selected_slot=(rng-11901)%3,family=family,
                       phase_label=f'P{p}',arm=arm,intervention_location=loc,
                       intervention_return_bps=bps,other_path_return_bps=50000000,forward_bps=50000000,
                       loss_kind='PHY_RX_PACKET_ERROR' if loss else 'NONE',loss_probability=f'{loss:.2f}',
                       loss_stream=79,loss_receiver_node_id=loss_node,
                       loss_receiver_device_index=loss_dev,instrumented=instrumented,
                       plan_filename=filename,schedule_sha256=sha(data),target_schedule_sha256=target_sha,
                       competitor_schedule_sha256=competitor_sha,status='PREREG_PLANNED_NO_SIMULATIONS'))
    files['SCHEDULE_INDEX_LOCKED_24.csv']=csv_bytes(index,INDEX_FIELDS)
    files['RUN_MATRIX_LOCKED_216.csv']=csv_bytes(matrix,MATRIX_FIELDS)
    return files

def verify(root):
    expected=build_files()
    names={p.relative_to(root).as_posix() for p in root.rglob('*.csv')}
    assert names=={k for k in expected if k.endswith('.csv')},'UNEXPECTED_OR_MISSING_CSV'
    for name,contents in expected.items():
        assert (root/name).read_bytes()==contents,'LOCKED_FILE_MODIFIED:'+name
    with (root/'RUN_MATRIX_LOCKED_216.csv').open() as f: rows=list(csv.DictReader(f))
    with (root/'SCHEDULE_INDEX_LOCKED_24.csv').open() as f: plans=list(csv.DictReader(f))
    with (root/'INTERVENTION_SITES_LOCKED_12.csv').open() as f:sites=list(csv.DictReader(f))
    assert len(plans)==24 and len(sites)==12 and len(rows)==216
    assert sum(int(r['instrumented']) for r in rows)==192 and sum(not int(r['instrumented']) for r in rows)==24
    assert len({r['run_id'] for r in rows})==216
    assert {r['rng_block'] for r in rows}=={str(x) for x in RNGS}
    assert Counter(r['arm'] for r in rows if int(r['instrumented']))=={a[0]:24 for a in ARMS}
    assert Counter(r['arm'] for r in rows if not int(r['instrumented']))=={a[0]:3 for a in ARMS}
    assert Counter((r['selected_slot'],r['arm']) for r in rows if not int(r['instrumented']))=={(str(s),a[0]):1 for s in range(3) for a in ARMS}
    assert all(r['status']=='PREREG_PLANNED_NO_SIMULATIONS' for r in rows)
    assert all(r['forward_bps']=='50000000' and r['other_path_return_bps']=='50000000' for r in rows)
    assert all(r['loss_kind']=='NONE' or (r['arm']=='NONQUEUE_RX_LOSS_50M' and r['loss_probability']=='0.15') for r in rows)
    groups=defaultdict(list)
    for row in rows:groups[(row['rng_block'],row['family'])].append(row)
    assert len(groups)==24
    for key,rr in groups.items():
        assert len(rr)==9
        assert len({r['schedule_sha256'] for r in rr})==1
        assert len({r['target_schedule_sha256'] for r in rr})==1
        assert len({r['competitor_schedule_sha256'] for r in rr})==1
    assert Counter(int(r['phase_label'][1:]) for r in plans)=={i:6 for i in range(4)}
    for slot in range(3):
        assert Counter(int(r['phase_label'][1:]) for r in plans if r['selected_slot']==str(slot))=={i:2 for i in range(4)}
    return dict(status='PASS_LOCKED_DESIGN_VERIFIED_NO_NDNSIM_RUN',schedules=24,
                total_runs=216,monitored_runs=192,unmonitored_pairs=24,
                rng_blocks=12, intervention_sites=12,arm_count=8,
                file_sha256={k:sha(v) for k,v in sorted(expected.items())},science=GATES)

def main():
    ap=argparse.ArgumentParser();g=ap.add_mutually_exclusive_group(required=True)
    g.add_argument('--output',type=Path);g.add_argument('--verify',type=Path)
    args=ap.parse_args()
    if args.output:
        root=args.output;root.mkdir(parents=True,exist_ok=True)
        for n,data in build_files().items():
            p=root/n;p.parent.mkdir(parents=True,exist_ok=True)
            if p.exists():raise RuntimeError('REFUSE_OVERWRITE:'+str(p))
            p.write_bytes(data)
    else:root=args.verify
    print(json.dumps(verify(root),indent=2,ensure_ascii=False,sort_keys=True))

if __name__=='__main__':main()
