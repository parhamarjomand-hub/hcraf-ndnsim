#!/usr/bin/env python3
"""Provenance and physical topology check against immutable v0.51.5 source ZIP."""
import argparse,csv,hashlib,io,json,zipfile
from pathlib import Path

PARENT_SHA='bfbd90c638692ba241a161eaf5dcadfbc7dceae82ba4d5f236e863b2d849b28f'
PARENT_MAP='hcraf/episode/docs/1AM/F3_PATHWIDE_WITNESS_DEV_v0.51.5/PATH_MAP_LOCKED_24.csv'

def verify(root,parent_zip):
    parent_zip=Path(parent_zip)
    if hashlib.sha256(parent_zip.read_bytes()).hexdigest()!=PARENT_SHA:raise RuntimeError('PARENT_SOURCE_SHA_CHANGED')
    with zipfile.ZipFile(parent_zip) as z:
        if z.testzip():raise RuntimeError('PARENT_SOURCE_ZIP_CORRUPTED')
        rows=list(csv.DictReader(io.StringIO(z.read(PARENT_MAP).decode('utf8'))))
    if len(rows)!=24:raise RuntimeError('PARENT_PATH_MAP_NOT_24')
    old={(int(r['slot']),r['direction'],int(r['sender_node_id']),int(r['receiver_node_id'])):int(r['device_index']) for r in rows}
    if len(old)!=24:raise RuntimeError('PARENT_DUPLICATE_MAP')
    with (Path(root)/'INTERVENTION_SITES_LOCKED_12.csv').open() as f: sites=list(csv.DictReader(f))
    if len(sites)!=12:raise RuntimeError('INTERVENTION_MAP_NOT_12')
    for s in sites:
        slot=int(s['selected_slot']);sender=int(s['sender_node_id']);receiver=int(s['receiver_node_id']);dev=int(s['sender_device_index']);recv_dev=int(s['receiver_device_index'])
        # Parent return-sender device must match. Reverse direction must identify the receiver device.
        a=old.get((slot,'RETURN',sender,receiver));b=old.get((slot,'FORWARD',receiver,sender))
        if a!=dev or b!=recv_dev:raise RuntimeError('PATH_SITE_MISMATCH:'+str(s))
        if s['intervention_location']=='NONQUEUE_RX_LOSS_RECEIVER':
            if receiver!=1 or recv_dev!=slot+1:raise RuntimeError('NONQUEUE_LOSS_SITE_WRONG')
    return {'status':'PASS_MATCHED_TO_REAL_V0515_PATH_MAP','sites_checked':12,'parent_source_sha256':PARENT_SHA}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);ap.add_argument('--source-zip',type=Path,required=True)
    a=ap.parse_args();print(json.dumps(verify(a.root,a.source_zip),indent=2))
