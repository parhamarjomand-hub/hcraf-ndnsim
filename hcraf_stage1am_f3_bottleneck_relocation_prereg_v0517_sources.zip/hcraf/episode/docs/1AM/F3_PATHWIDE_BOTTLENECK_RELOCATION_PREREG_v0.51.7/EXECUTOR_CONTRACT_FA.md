# قرارداد تحویل به Executor آینده — فقط طراحی، نه اجرای فعلی

کد بعدی باید سناریوی مستقل C++ تازه‌ای بسازد که `RUN_MATRIX_LOCKED_216.csv` و ۲۴ فایل `plans/` را **بدون بازتولید تصادفی زمان‌بندی** بخواند. نرخ مداخله تنها روی دستگاه `sender_node_id/sender_device_index` متناظر Slot اعمال شود؛ نرخ سایر لینک‌های برگشت ۵۰Mbps باقی بماند. در بازوی loss، `RateErrorModel` با `ERROR_UNIT_PACKET`, rate=0.15 و stream=79 فقط روی `receiver_node_id/receiver_device_index` همان لینک قرار گیرد؛ شمارنده `PHY_RX_DROP` از `QUEUE_DROP` جداست. FIB و Face منتخب نباید تغییر کنند.

در اجرای هر Run، فایل‌های `scenario.json`, `config.json`, `link_events.jsonl`, `pathwide_witness_b.jsonl`, `events.jsonl.states.jsonl`, `target/competitor arrivals`, `producer_receipts` و هزینه‌های پایش باید تولید و به Matrix و hash برنامه وصل شوند. شرط خروج: ۲۰ INITIAL/FINAL، ۸ device مسیر، آزمون timestamp/UID، A=B، ۱۲/۹۶ SEND درست و Receipt مستقل. هیچ FutureCongestion و هیچ آموزش NSGA-III مجاز نیست.

ساختار اجرایی بهتر است به Shardهای کوچک و مستقل با Artifact مجزا تقسیم شود تا محدودیت زمان GitHub/حجم Trace سبب از دست رفتن کل شواهد نشود؛ اما **هیچ Shard بدون موفقیت و صحت رسید پیش‌ثبت v0.51.7 حق اجرا ندارد**. نتیجه هر Shard باید شامل provenance Commit، SHA منبع و قفل و هش ورودی باشد؛ جزئیات shard کردن نباید ترکیب ماتریس را عوض کند. موفقیت تک‌تک Runها پیش از ادعای تکمیل ۲۱۶ اجرا لازم است.

برای مطالعه اصلی، ۱۲ RNG بلوکی کافی برای اثبات تعمیم‌پذیری نهایی نیست؛ نتیجه Executor صرفاً Development بوده و پس از آن باید مجموعه قفل‌شده جدیدِ تأییدی طراحی شود.
