# HCRAF Stage 1AM — F3 Pathwide Bottleneck Relocation Prereg v0.51.7

این مجموعه **قفل آینده‌نگر GitHub** است: بدون C++ جدید، بدون اجرای ndnSIM، بدون ساخت دیتاست اصلی و بدون تغییر در برچسب F3.

- `SCIENTIFIC_PROTOCOL_FA.md`: تعریف علمی و محدودیت‌های طرح.
- `EXECUTOR_CONTRACT_FA.md`: شرط‌های جداگانه برای Executor آینده.
- `RUN_MATRIX_LOCKED_216.csv`: ۱۹۲ اجرای پایش‌شده و ۲۴ جفت بدون پایش؛ **همه فقط برنامه‌ریزی‌شده‌اند**.
- `SCHEDULE_INDEX_LOCKED_24.csv` و پوشه `plans/`: ۲۴ برنامه Target/Competitor که بین ۸ بازو ثابت‌اند.
- `INTERVENTION_SITES_LOCKED_12.csv`: موقعیت فیزیکی سه گلوگاه و محل خطای غیرصفی در سه Slot؛ Face ID در Runtime تأیید شود.
- `SCIENCE_LOCKS.json`: پنج وضعیت علمی غیرقابل تغییر.
- `generate_prereg.py --verify DIR`: بازتولید و مقایسه بایت‌به‌بایت تمام CSVهای قرارداد.
- `verify_against_parent.py --root DIR --source-zip OLD.zip`: تطبیق نقشه مسیر با فایل واقعی v0.51.5.

محتوای بسته را داخل مخزن overwrite نکنید؛ فقط ZIP داخلی را بدون استخراج آپلود و متن Workflow را در فایل جدید YAML قرار دهید. ابتدا LOCK ONLY؛ Executor آینده بسته جدا خواهد داشت.
