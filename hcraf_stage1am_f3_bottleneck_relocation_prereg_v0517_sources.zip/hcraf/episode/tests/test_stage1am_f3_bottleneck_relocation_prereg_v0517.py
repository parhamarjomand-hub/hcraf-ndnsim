"""v0.51.7 prereg integrity tests, no ndnSIM dependencies or model training."""
import csv,importlib.util,io,json,pathlib,shutil,tempfile,unittest

HERE=pathlib.Path(__file__).resolve()
ROOT=HERE.parents[1]/'docs'/'1AM'/'F3_PATHWIDE_BOTTLENECK_RELOCATION_PREREG_v0.51.7'
spec=importlib.util.spec_from_file_location('hcraf_relocation_generator',ROOT/'generate_prereg.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)

def records(name):return list(csv.DictReader(io.StringIO(mod.build_files()[name].decode())))

class TestScientificContract(unittest.TestCase):
    def test_new_unseen_rng(self):
        self.assertEqual(mod.RNGS,tuple(range(11901,11913)))
        self.assertFalse(set(mod.RNGS)&set(range(11601,11813)))
    def test_science_locks(self):
        self.assertEqual(mod.GATES,{'Congestion':None,'FutureCongestion':None,'F3_ready':False,'GO_FREEZE':False,'training_ready':False})
        actual=json.loads((ROOT/'SCIENCE_LOCKS.json').read_text())
        self.assertEqual({k:actual[k] for k in mod.GATES},mod.GATES)
        self.assertEqual(actual['simulations_executed'],0)
    def test_phases_balanced_across_slots(self):
        phase,_=mod.allocation()
        for slot in range(3):
            self.assertEqual(sorted(phase[r] for r in mod.RNGS if (r-11901)%3==slot),[0,1,2,3])
    def test_seed_schedule_bytes_repeat(self):
        self.assertEqual(mod.build_files(),mod.build_files())
    def test_24_plans(self):
        self.assertEqual(len([k for k in mod.build_files() if k.startswith('plans/')]),24)
    def test_schedule_sizes_and_unique_sequences(self):
        for path,data in mod.build_files().items():
            if not path.startswith('plans/'):continue
            rows=list(csv.DictReader(io.StringIO(data.decode())))
            self.assertEqual(len(rows),108)
            for typ,n in (('TARGET',12),('INDEPENDENT_COMPETITOR',96)):
                rr=[r for r in rows if r['traffic_class']==typ]
                self.assertEqual({int(r['sequence']) for r in rr},set(range(n)))
                self.assertTrue(all(2000000000<=int(r['time_ns'])<20000000000 for r in rr))
    def test_all_216_rows_and_controls(self):
        rows=records('RUN_MATRIX_LOCKED_216.csv')
        self.assertEqual(len(rows),216)
        self.assertEqual(sum(int(r['instrumented']) for r in rows),192)
        self.assertEqual(sum(not int(r['instrumented']) for r in rows),24)
    def test_one_control_each_cell(self):
        rr=records('RUN_MATRIX_LOCKED_216.csv')
        from collections import Counter
        controls=Counter((r['rng_block'],r['family']) for r in rr if r['instrumented']=='0')
        self.assertEqual(len(controls),24);self.assertEqual(set(controls.values()),{1})
    def test_eight_arm_names(self):
        self.assertEqual(len(mod.ARMS),8)
        self.assertEqual({a[0] for a in mod.ARMS},set(r['arm'] for r in records('RUN_MATRIX_LOCKED_216.csv')))
    def test_only_one_link_throttled(self):
        for r in records('RUN_MATRIX_LOCKED_216.csv'):
            self.assertEqual(r['forward_bps'],'50000000')
            self.assertEqual(r['other_path_return_bps'],'50000000')
            if r['arm']=='ALL_RETURN_50M':
                self.assertEqual(r['intervention_location'],'NONE')
                self.assertEqual(r['intervention_return_bps'],'50000000')
            elif r['arm']=='NONQUEUE_RX_LOSS_50M':
                self.assertEqual(r['intervention_location'],'NONE')
                self.assertEqual(r['loss_probability'],'0.15')
                self.assertEqual(r['loss_kind'],'PHY_RX_PACKET_ERROR')
                self.assertEqual(int(r['loss_receiver_device_index']),1+int(r['selected_slot']))
            else:
                self.assertIn(r['intervention_location'],['PRODUCER_RETURN','MID_RETURN','RELAY_RETURN'])
                self.assertIn(r['intervention_return_bps'],['6000000','12000000'])
                self.assertEqual(r['loss_probability'],'0.00')
    def test_exact_schedule_hash_identical_across_arms(self):
        from collections import defaultdict
        g=defaultdict(list)
        for r in records('RUN_MATRIX_LOCKED_216.csv'):g[(r['rng_block'],r['family'])].append(r)
        self.assertEqual(len(g),24)
        for rows in g.values():
            self.assertEqual(len(rows),9)
            for key in ['schedule_sha256','target_schedule_sha256','competitor_schedule_sha256']:
                self.assertEqual(len({r[key] for r in rows}),1)
    def test_three_sites_match_expected_parent_layout(self):
        rs=records('INTERVENTION_SITES_LOCKED_12.csv')
        self.assertEqual(len(rs),12)
        for s in rs:
            sl=int(s['selected_slot']);loc=s['intervention_location']
            if loc=='PRODUCER_RETURN':self.assertEqual((int(s['sender_node_id']),int(s['sender_device_index'])),([8,9,10][sl],0))
            if loc=='MID_RETURN':self.assertEqual((int(s['sender_node_id']),int(s['sender_device_index'])),([7,6,5][sl],0))
            if loc=='RELAY_RETURN':self.assertEqual((int(s['sender_node_id']),int(s['sender_device_index'])),([2,3,4][sl],0))
    def test_verify_current_bytes(self):self.assertEqual(mod.verify(ROOT)['status'],'PASS_LOCKED_DESIGN_VERIFIED_NO_NDNSIM_RUN')
    def test_tampered_schedule_fail_closed(self):
        with tempfile.TemporaryDirectory() as d:
            d=pathlib.Path(d)
            for name,blob in mod.build_files().items():
                p=d/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(blob)
            p=d/'plans'/f'rng-{mod.RNGS[0]}_{mod.FAMILIES[0]}.csv'
            p.write_bytes(p.read_bytes()+b'CORRUPTION\n')
            with self.assertRaises(AssertionError):mod.verify(d)
    def test_no_f3_label_columns(self):
        for n in ('RUN_MATRIX_LOCKED_216.csv','SCHEDULE_INDEX_LOCKED_24.csv'):
            columns=list(csv.DictReader(io.StringIO(mod.build_files()[n].decode())).fieldnames)
            self.assertFalse(any('futurecongestion' in col.lower() or col.lower()=='congestion' for col in columns))
    def test_no_historical_test_or_validation(self):
        self.assertTrue(all('TEST' not in n and 'VALIDATION' not in n for n in mod.build_files()))
    def test_no_executor_cpp_in_new_zip(self):
        self.assertFalse(any(k.suffix=='.cpp' for k in ROOT.rglob('*') if k.is_file()))

if __name__=='__main__':unittest.main()
