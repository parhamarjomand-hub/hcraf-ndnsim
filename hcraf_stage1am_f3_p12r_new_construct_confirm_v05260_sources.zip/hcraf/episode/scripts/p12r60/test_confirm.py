import unittest,tempfile,pathlib,zipfile,math,os
from fractions import Fraction
from pilot_audit import *
from history_guard import matches,scan,IDS
class PilotTest(unittest.TestCase):
 def qa(self):
  a=[dict(event=e,time_ns=str(t),uid=str(u),bytes=str(b),packets=str(n),wait_ns=str(w)) for e,t,u,b,n,w in [('INITIAL',0,0,0,0,0),('ENQUEUE',10,1,1200,1,0),('DEQUEUE',30,1,1200,0,20),('FINAL',END,0,0,0,0)]]
  b=[dict(event=e,time_ns=str(t),old=str(o),new=str(n),uid=str(u)) for e,t,o,n,u in [('INITIAL',0,0,0,0),('CHANGE',10,0,1,0),('CHANGE',30,1,0,0),('FINAL',END,0,0,0)]];return a,b
 def test_actual_parent(self):
  p=pathlib.Path(os.environ['P12R56_PREREG']);c,s,h=read_prereg(p);self.assertEqual(len(c),540);self.assertEqual(len(s),108);self.assertEqual(sum(len(x) for x in s.values())*5,68040);self.assertEqual(set(int(x['seed']) for x in c),set(range(620201,620237)));self.assertEqual(len(h),3)
 def test_wrong_parent(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d)/'x';p.write_bytes(b'fake');self.assertRaises(RuntimeError,read_prereg,p)
 def test_queue_replay(self):
  a,b=self.qa();m=queue_audit(a,b);self.assertEqual(m['wait'],[20]);self.assertEqual(window_area(m['states'],0,40),20)
 def test_wrong_length_witness(self):
  a,b=self.qa();b[1]['new']='2';self.assertRaises(RuntimeError,queue_audit,a,b)
 def test_wrong_wait(self):
  a,b=self.qa();a[2]['wait_ns']='21';self.assertRaises(RuntimeError,queue_audit,a,b)
 def test_drop_without_full(self):
  a,b=self.qa();a.insert(2,dict(event='DROP',time_ns='15',uid='2',bytes='1200',packets='1',wait_ns='0'));self.assertRaises(RuntimeError,queue_audit,a,b)
 def test_coverage(self):
  a,b=self.qa();a[-1]['time_ns']=str(END-1);self.assertRaises(RuntimeError,queue_audit,a,b)
 def test_pulses(self):
  a,b=background_times(3),background_times(18);self.assertEqual((len(a),len(b)),(18*157,18*938));self.assertEqual((a[0],b[0]),(10**9,10**9));self.assertTrue(all((x-10**9)%10**9<500000000 for x in a+b));self.assertEqual(b[1]-b[0],533333)
 def test_reference_boundary(self):
  q=[(0,0,0),(100000000,1,8),(175000000,2,0),(END,3,0)];a,b,y=reference([q,q,q],100000000,0,END);self.assertEqual((a,b,y),(0,Fraction(1,4),1));self.assertEqual(window_area(q,100000000,175000000),8*75000000)
 def test_equal_time(self):
  q=[(0,0,0),(100,1,1),(100,2,2),(200,3,0),(END,4,0)];self.assertEqual(window_area(q,100,200),200)
 def test_history_namespace(self):
  self.assertEqual(matches(b'seed=620001\nfor seed in range(620100,620104):'),[620001,620101,620102,620103,620104]);self.assertEqual(matches(b'foo=16200010\nseed=24901'),[]);self.assertEqual(len(IDS),51)
 def test_block_balance(self):
  cases,s,h=read_prereg(pathlib.Path(os.environ['P12R56_PREREG']));self.assertTrue(all(set(v[i+j][2] for j in range(3))=={0,1,2} for v in s.values() for i in range(0,126,3)))
 def test_drop_witness(self):
  a,b=self.qa();a=a[:1];b=b[:1]
  for i in range(32):
   a.append(dict(event='ENQUEUE',time_ns=str(10+i),uid=str(i+1),bytes='1200',packets=str(i+1),wait_ns='0'));b.append(dict(event='CHANGE',time_ns=str(10+i),old=str(i),new=str(i+1),uid='0'))
  a.append(dict(event='DROP',time_ns='50',uid='100',bytes='1200',packets='32',wait_ns='0'));b.append(dict(event='MAC_DROP',time_ns='50',old='32',new='32',uid='100'))
  for i in range(32):
   a.append(dict(event='DEQUEUE',time_ns=str(100+i),uid=str(i+1),bytes='1200',packets=str(31-i),wait_ns='90'));b.append(dict(event='CHANGE',time_ns=str(100+i),old=str(32-i),new=str(31-i),uid='0'))
  a.append(dict(event='FINAL',time_ns=str(END),uid='0',bytes='0',packets='0',wait_ns='0'));b.append(dict(event='FINAL',time_ns=str(END),old='0',new='0',uid='0'));self.assertEqual(queue_audit(a,b)['drops'],[(50,100)]);b[33]['uid']='101';self.assertRaises(RuntimeError,queue_audit,a,b)
 def test_six_blocks(self):
  c,s,h=read_prereg(pathlib.Path(os.environ['P12R56_PREREG']));groups=[block_cases(c,b) for b in range(1,7)];self.assertEqual(sum(len(g) for g in groups),540);self.assertEqual(len({(x['seed'],x['site'],x['arm']) for g in groups for x in g}),540);self.assertEqual(set.union(*(block_seeds(b) for b in range(1,7))),set(range(620201,620237)))
  for b in (0,7,-1):self.assertRaises(RuntimeError,block_seeds,b)
 def test_amendment(self):
  from confirm_guard import verify_amendment
  self.assertEqual(len(verify_amendment(pathlib.Path(os.environ['P12R60_AMEND']),pathlib.Path(os.environ['P12R56_PREREG']))),3)
 def test_bad_amendment(self):
  from confirm_guard import verify_amendment
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d)/'x';p.write_bytes(b'bad');self.assertRaises(RuntimeError,verify_amendment,p,pathlib.Path(os.environ['P12R56_PREREG']))
if __name__=='__main__':unittest.main()
