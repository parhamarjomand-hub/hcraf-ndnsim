# HCRAF F3 v0.52.2 — Hotfix P1 / خطای پیشوند تله‌متری

## شواهد واقعی GitHub
- Run: `43738030095`، Commit: `ebe6b9ab7cb6a83820dddd9ed0cbf2e938bd008c`
- کامپایل ndnSIM: PASS؛ baseline نخست: PASS؛ نخستین اجرای telemetry20: FAILED.
- خطای runtime: `Stage1M requires three eligible faces`.
- ۹ Smoke آزمایشی کامل نشده‌اند؛ هیچ گزارشی از انتقال موفق NDN قابل ادعا نیست.

## علت ریشه‌ای و اصلاح محدود
- Stage1AH NFD recorder روی `/hcraf` فعال است؛ ابزار انتخاب Stage1M برای همهٔ Interestهای در این دامنه **سه Face واجد شرایط** انتظار دارد.
- تله‌متری قدیم `/hcraf/telemetry/...` به‌اشتباه داخل همین دامنه قرار داشت، با اینکه یک مسیر تک‌شاخه به سمت Source دارد.
- در P1 صرفاً نام ترافیک **کنترلی تله‌متری** از `/hcraf/telemetry` به `/hcraf-queue-telemetry` تغییر کرده است.
- این پیشوند خارج از دامنهٔ `/hcraf` قرار دارد و native BestRoute آن را به شکل واقعی با Interest/Data از لینک‌ها عبور می‌دهد.
- در کد NFD، HCRAF Gate، Labelها، طرح آیندهٔ CALIBRATION/HELDOUT و آرشیوهای سابق هیچ تغییری داده نشده است.

## آزمون‌ها و حد ادعا
- آزمون‌های Python بررسی می‌کنند که Route، Sender، Requester و Receiver در یک Namespace باشند، در `/hcraf/` قرار نگیرند و Sourceهای علمی Target/Competitor دست‌نخورده باقی مانده باشند.
- آزمون‌های آزمایشگاهی **کامپایل یا اجرای واقعی ndnSIM را اثبات نمی‌کنند**. باید Workflow جداگانهٔ P1 در GitHub اجرا و Artifact آن ممیزی شود.
- خود گزارش‌های کنترلی نباید به‌عنوان برچسب FutureCongestion در نظر گرفته شوند. اگر گزارش نرسد، وضعیت UNKNOWN است، نه صفر.
- آزمون‌های تاریخی Stage1S: ۲۰ مورد Deferred. بخش ۴۳۲اجرایی HELDOUT مسدود است.
- Congestion=null, FutureCongestion=null, F3_ready=false, GO_FREEZE=false, training_ready=false.
