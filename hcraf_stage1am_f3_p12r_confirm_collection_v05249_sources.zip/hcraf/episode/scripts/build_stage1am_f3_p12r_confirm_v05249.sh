#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
mkdir -p "$ROOT/episode_output/p12v_native_preflight"
bash "$TASK/scripts/build_stage1am_f3_p12v_native_v05241.sh"
cd "$ROOT/episode_sources/ns-3"
cp "$TASK/src/hcraf-stage1am-f3-p12r-confirm-v05249.cpp" scratch/hcraf-stage1am-f3-p12r-confirm-v05249.cc
cmp -s "$TASK/src/hcraf-stage1am-f3-p12r-confirm-v05249.cpp" scratch/hcraf-stage1am-f3-p12r-confirm-v05249.cc
python3 ./waf -j 2
test -x build/scratch/hcraf-stage1am-f3-p12r-confirm-v05249
