#!/usr/bin/env python3
import json,hashlib,os
from run_stage1am_f3_p12r_confirm_v05249 import matrix,OUT,LOCK,need,sha
from authorize_stage1am_f3_p12r_confirm_v05249 import verify_job,MODEL_SHA

def main():
 seeds=verify_job();cases=[r for r in matrix() if int(r['seed']) in seeds];need(len(cases)==72,'BLOCK_COUNT');hashes={}
 for r in cases:
  d=OUT/r['seed']/(r['site']+'_'+r['load']+'_'+r['telemetry']);p=d/'case_receipt.json';x=json.loads(p.read_text())
  need(x['status']=='PASS_CONFIRM_RAW_COLLECTION_QC_ONLY' and x['case']==r and x['decisions']==128 and x['confirmation_cases']==1 and all(x[k] is v for k,v in LOCK.items()),'CASE_RECEIPT')
  files={str(f.relative_to(d)) for f in d.rglob('*') if f.is_file() and f!=p};need(files==set(x['raw_file_sha256']),'RAW_FILE_SET')
  need(all(sha(d/k)==h for k,h in x['raw_file_sha256'].items()),'RAW_HASH');hashes[str(d.relative_to(OUT))]=sha(p)
 for seed in seeds:
  s=json.loads((OUT/str(seed)/'seed_receipt.json').read_text());need(s['status']=='PASS_12_CONFIRM_RAW_CASES_ONLY' and s['seed']==seed and s['cases']==12 and s['decisions']==1536,'SEED_RECEIPT')
 report=dict(status='PASS_72_CONFIRM_RAW_COLLECTION_ONLY_NO_SCORING',block=int(os.environ['P12R_BLOCK']),seeds=list(seeds),confirmation_cases=72,decisions=9216,primary_arm_decisions=4608,case_receipt_sha256=hashes,model_sha256=MODEL_SHA,model_fits=0,new_AP_computed=False,new_bootstrap_computed=False,diagnostic_rows_used=0,heldout_rows_read=0,**LOCK)
 p=OUT/'P12R_CONFIRM_BLOCK_RECEIPT_v05249.json';need(not p.exists(),'NO_OVERWRITE');p.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(report['status'])
if __name__=='__main__':main()
