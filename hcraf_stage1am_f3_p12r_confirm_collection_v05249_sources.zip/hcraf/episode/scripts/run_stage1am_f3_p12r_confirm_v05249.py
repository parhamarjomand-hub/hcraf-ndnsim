#!/usr/bin/env python3
import argparse,csv,hashlib,json,math,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
DOC=ROOT/'hcraf/episode/docs/1AM/F3_P12R_FAIR_COMPARATOR_PREREG_v0.52.37'
OUT=ROOT/'episode_output/stage1am_f3_p12r_confirm_v05249'
BIN='hcraf-stage1am-f3-p12r-confirm-v05249'
LOCK=dict(F3_ready=False,GO_FREEZE=False,training_ready=False,Congestion=None,FutureCongestion=None,heldout_release_authorized=False,Stage1AO_or_NSGAIII_authorized=False)
def need(c,m):
 if not c:raise RuntimeError('P12R_CONFIRM_'+m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):return [json.loads(l) for l in p.read_text().splitlines() if l.strip()]
def matrix():
 p=DOC/'P12R_LOCKED_MATRIX_504_v05237.csv';need(sha(p)=='ede56f2242648b1ef84b6408b3755f0a61876f98de7213a0d4c3b87088c1fc1f','MATRIX_SHA')
 with p.open() as f: allrows=list(csv.DictReader(f))
 dev=[r for r in allrows if r['partition']=='FAIR_COMPARATOR_CONFIRM'];need(len(allrows)==504 and len(dev)==432,'COUNTS')
 keys={(int(r['seed']),r['site'],r['load'],r['telemetry']) for r in dev}
 need(keys=={(s,i,l,t) for s in range(25001,25037) for i in ('producer_egress','transit_middle','consumer_ingress') for l in ('low_control','high_pressure') for t in ('off','on_20ms')},'CONFIRM_MATRIX')
 for r in dev:
  need(r['execution_authorized_now']==r['validation_or_heldout_released']=='false','FLAGS')
  p=DOC/'plans'/r['schedule_filename'];need(p.name==r['schedule_filename'] and sha(p)==r['schedule_sha256'],'SCHEDULE_SHA')
  with p.open() as f: rr=list(csv.DictReader(f))
  need(len(rr)==128 and sum(x['traffic_class']=='TARGET' for x in rr)==12 and sum(x['traffic_class']=='INDEPENDENT_COMPETITOR' for x in rr)==116,'SCHEDULE_COUNT')
  need(all(x['split']=='FAIR_COMPARATOR_CONFIRM' for x in rr),'SCHEDULE_PARTITION')
 return dev
def command(r,d):
 need(r['partition']=='FAIR_COMPARATOR_CONFIRM' and int(r['seed']) in range(25001,25037),'CONFIRM_ONLY')
 opts=dict(pathArm=r['arm'],interventionLocation=r['location'],interventionReturnBps=12000000,lossProbability=0,lossStream=79,lossReceiverNodeId=-1,lossReceiverDeviceIndex=-1,scheduleFamily='P12R_NEW_FAIR_COMPARATOR_PROSPECTIVE_PREREG_ONLY',scheduleCsv=DOC/'plans'/r['schedule_filename'],prospectiveLoad=r['load'],prospectiveTrafficStreamSeed=r['traffic_stream_seed'],prospectiveRoutingStreamSeed=r['routing_stream_seed'],prospectiveTelemetryStreamSeed=r['telemetry_stream_seed'],selectedSlot=r['selected_slot'],run=r['seed'],output=d,instrument=1,topology='DEV_CHAIN_L',mode='LP_INDEPENDENT_COMPETITOR_NO_DROP',seed=17,lifetimeMs=2600,requestCount=12,intervalNs=330000000,competitorCount=116,competitorIntervalNs=3600000,competitorOffsetNs=0,targetOffsetNs=260000000,forwardBps=50000000,returnBps=50000000,technicalQueueMaxPackets=12,telemetryEnabled=int(r['telemetry']=='on_20ms'),telemetryPeriodMs=20)
 return BIN+' '+' '.join('--%s=%s'%x for x in opts.items())
def replay_local(events,t,o,face):
 prefix=events[:o]
 need(all(e['time_ns']<=t for e in prefix),'FUTURE_NATIVE_EVENT')
 win=[e for e in prefix if t-75000000<e['time_ns']<=t]
 counts=[sum(e['event']==k and (j<3 or e['face_id']==face) for e in win) for j,k in enumerate(('interest_rx','data_rx','nack_rx','interest_tx','interest_drop'))]
 rtt=[e['rtt_ms'] for e in prefix if e['event']=='rtt']
 need(all(0<x<1e9 for x in rtt),'RTT_RANGE')
 ewma=0.
 for i,x in enumerate(rtt):ewma=x if i==0 else .125*x+.875*ewma
 return counts+[ewma,int(not rtt)]
def audit(r,d):
 sc=json.loads((d/'scenario.json').read_text());need(sc['research_partition']=='FAIR_COMPARATOR_CONFIRM' and sc['run']==int(r['seed']) and sc['schedule_csv_filename']==r['schedule_filename'],'SCENARIO')
 for k,v in [('phase_arm',r['arm']),('intervention_location',r['location']),('intervention_return_bps',12000000),('queue_capacity_packets',12),('seed',17),('loss_probability',0),('telemetry_period_ms',20),('selected_face_slot',int(r['selected_slot'])),('p4_prospective_load',r['load']),('telemetry_enabled',r['telemetry']=='on_20ms'),('p4_locked_traffic_stream_seed',int(r['traffic_stream_seed'])),('p4_locked_routing_stream_seed',int(r['routing_stream_seed'])),('p4_locked_telemetry_stream_seed',int(r['telemetry_stream_seed']))]:need(sc[k]==v,'SCENARIO_'+k)
 with (DOC/'plans'/r['schedule_filename']).open() as f:schedule=list(csv.DictReader(f))
 for kind,filename in [('TARGET','consumer_events.jsonl.arrivals.jsonl'),('INDEPENDENT_COMPETITOR','competitor_events.jsonl.arrivals.jsonl')]:
  observed=rows(d/filename);expected={(int(a['sequence']),int(a['time_ns'])) for a in schedule if a['traffic_class']==kind}
  need(len(observed)==len(expected) and {(a['sequence'],a['time_ns']) for a in observed}==expected,'FROZEN_ARRIVAL_REPLAY')
 native=rows(d/'p12v_native_local_12_at_decision.jsonl'); first=rows(d/'p12t_native_local_at_decision.jsonl'); events=rows(d/'p12v_native_local_12_at_decision.jsonl.events.jsonl'); q=rows(d/'nfd_local_queue_at_decision.jsonl');lookup={(a['decision_id'],a['candidate_face_id']):a for a in q}
 need(len(native)==len(first)==128 and len(q)==len(lookup)==384,'DECISION_COUNT')
 need(all(sc[k] is v for k,v in LOCK.items() if k in sc) and sc['official_F3_labels_constructed']==0 and sc['F3_PR_AUC_computed'] is False,'SCENARIO_LOCKS')
 need((d/'link_events.jsonl').stat().st_size>0 and (d/'events.jsonl').stat().st_size>0,'RAW_PHYSICAL_TRACE_REQUIRED')
 need(not rows(d/'fault_events.jsonl'),'UNAUTHORIZED_PHYSICAL_RX_LOSS')
 need(all(e['ordinal']==i and e['node_id']==1 and e['face_id']>0 and (e['name'].startswith('/hcraf/pilot/') or e['name'].startswith('/hcraf/competitor/') or e['name'] in ('/hcraf/pilot','/hcraf/competitor')) for i,e in enumerate(events,1)) and all(a['time_ns']<=b['time_ns'] for a,b in zip(events,events[1:])),'EVENT_ORDER')
 face=sc['selected_face_id']; last=0; times=[]; vectors=[]
 for i,(n,f) in enumerate(zip(native,first),1):
  t=n['time_ns']; o=n['event_ordinal'];v=n['b1_all_twelve_native'];need(n['decision_id']==f['decision_id']==i and t==f['time_ns'] and n['node_id']==1 and n['selected_face_id']==f['selected_face_id']==face,'LOCAL_ALIGNMENT')
  need(len(v)==12 and all(math.isfinite(x) for x in v) and all(abs(v[j]-f['b1_first_five_native'][j])<1e-5 for j in range(5)),'B1')
  a=lookup[(i,face)];need(a['sim_time_ns']==t and a['queue_packets']==v[1] and abs(a['local_queue_occupancy_fraction']-v[2])<1e-5,'QUEUE')
  need(last<=o<=len(events) and (not o or events[o-1]['time_ns']<=t),'ORDINAL');last=o
  replay=replay_local(events,t,o,face)
  need(v[5:10]==replay[:5] and math.isclose(v[10],replay[5],rel_tol=1e-12,abs_tol=1e-12) and v[11]==replay[6],'INDEPENDENT_B1_EVENT_REPLAY')
  need(not n['F3_ready'] and not n['GO_FREEZE'] and not n['model_training_authorized'],'LOCK');times.append(t);vectors.append(v)
 need(times==sorted(times),'DECISION_ORDER')
 if r['telemetry']=='on_20ms':
  ds=rows(d/'queue_telemetry_decisions.jsonl'); rr=rows(d/'queue_telemetry_receipts.jsonl'); ids={a['report_id']:a for a in rr};need(len(ds)==128 and len(ids)==len(rr) and all(a['receipt_ordinal']==i and a['sample_ns']<=a['receipt_ns'] for i,a in enumerate(rr,1)) and all(a['receipt_ns']<=b['receipt_ns'] for a,b in zip(rr,rr[1:])),'REMOTE_COUNT')
  sent=rows(d/'queue_telemetry_sent.jsonl'); sent_map={(a['role']+'-'+str(a['sequence'])):a for a in sent};need(len(sent_map)==len(sent),'SENT_ID_UNIQUE')
  for a in rr:
   b=sent_map[a['report_id']];need(all(a[k]==b[k] for k in ('source_node_id','source_device_index','sample_ns','sequence','data_wire_bytes','payload_bytes')),'REMOTE_SENDER_RECEIPT_MATCH')
  prior=0
  for i,x in enumerate(ds,1):
   t=times[i-1];need(x['decision_id']==i and x['decision_ns']==t,'REMOTE_ALIGNMENT')
   expected={(a['node_id'],a['device_index']) for a in x['selected_sender_sources']};seen=set();need(expected=={(sc['selected_relay_node_id'],0),(sc['selected_mid_node_id'],0),(sc['selected_producer_node_id'],0)},'REMOTE_SOURCES')
   o=x['receipt_ordinal'];need(prior<=o<=len(rr) and (not o or rr[o-1]['receipt_ns']<=t),'REMOTE_ORDINAL');prior=o
   latest={}
   for rec in rr[:o]:latest[(rec['source_node_id'],rec['source_device_index'])]=rec
   fresh={k:a['report_id'] for k,a in latest.items() if t-a['sample_ns']<=100000000}
   need(fresh=={(e['source_node_id'],e['source_device_index']):e['report_id'] for e in x['feature_evidence']},'REMOTE_LATEST_REPLAY')
   for e in x['feature_evidence']:
    a=ids[e['report_id']];k=(e['source_node_id'],e['source_device_index']);need(k==(a['source_node_id'],a['source_device_index']) and k not in seen and a['sample_ns']<=a['receipt_ns']<=t and t-a['sample_ns']<=100000000,'REMOTE_CAUSAL');seen.add(k)
   for e in x['feature_missing_sources']:
    k=(e['source_node_id'],e['source_device_index']);need(k not in seen,'REMOTE_DUP');seen.add(k)
   need(seen==expected,'REMOTE_COVERAGE')
 else:need(not (d/'queue_telemetry_decisions.jsonl').exists(),'OFF_TELEMETRY')
 raw_hashes={str(p.relative_to(d)):sha(p) for p in sorted(d.rglob('*')) if p.is_file()}
 receipt=dict(status='PASS_CONFIRM_RAW_COLLECTION_QC_ONLY',case=r,decisions=128,events=len(events),raw_file_sha256=raw_hashes,new_AP_computed=False,model_fits=0,confirmation_cases=1,**LOCK)
 (d/'case_receipt.json').write_text(json.dumps(receipt,indent=2));return receipt
def main():
 p=argparse.ArgumentParser();p.add_argument('--seed',type=int,required=True,choices=range(25001,25037));p.add_argument('--preflight-only',action='store_true');a=p.parse_args();dev=matrix();selected=[r for r in dev if int(r['seed'])==a.seed];need(len(selected)==12,'SEED_CASES')
 if a.preflight_only:print('PASS_432_MATRIX_216_CONFIRM_SCHEDULES',a.seed);return
 from authorize_stage1am_f3_p12r_confirm_v05249 import verify_model, verify_job
 verify_job(a.seed); verify_model(ROOT/"p12r_model_auth/model.zip")
 base=OUT/str(a.seed);need(not base.exists(),'NO_OVERWRITE');need((ROOT/'episode_sources/ns-3/build/scratch'/BIN).is_file(),'BINARY');base.mkdir(parents=True);receipts=[]
 for r in selected:
  d=base/(r['site']+'_'+r['load']+'_'+r['telemetry']);d.mkdir();cmd=command(r,d);(d/'command.txt').write_text(cmd+'\n')
  with (d/'simulator.log').open('w') as f:subprocess.run(['python3','./waf','--run-no-build',cmd],cwd=ROOT/'episode_sources/ns-3',stdout=f,stderr=subprocess.STDOUT,check=True)
  receipts.append(audit(r,d));print('PASS_CASE',d.name,flush=True)
 for r in selected:
  if r['telemetry']!='on_20ms':continue
  stem=r['site']+'_'+r['load']+'_'; name='p12v_native_local_12_at_decision.jsonl'
  on=rows(base/(stem+'on_20ms')/name);off=rows(base/(stem+'off')/name)
  need([(x['decision_id'],x['time_ns']) for x in on]==[(x['decision_id'],x['time_ns']) for x in off],'PAIR_DECISION_CLOCK')
 (base/'seed_receipt.json').write_text(json.dumps(dict(status='PASS_12_CONFIRM_RAW_CASES_ONLY',seed=a.seed,cases=12,decisions=1536,confirmation_cases=12,new_AP_computed=False,model_fits=0,**LOCK),indent=2))
if __name__=='__main__':main()
