#!/usr/bin/env python3
import hashlib,json,os,math,subprocess,urllib.request,zipfile
from pathlib import Path
MODEL_SHA='6ae14949b3bdc5218d2420b84452b7326142869e843711d2cb0958672363de82'
ART_SHA='c68ed8da0f82229b04d5c20623142c2f46f355cb88e7aa129ba9171f24819f9c'
MODEL_RUN=45991786037
MODEL_ART=15193723927
MODEL_COMMIT='2adb3881a9968fe762233f966560cc80ec606aae'
BLOCKS={str(i+1):tuple(range(25001+6*i,25007+6*i)) for i in range(6)}
LOCKS=('F3_ready','GO_FREEZE','training_ready','heldout_release_authorized','Stage1AO_or_NSGAIII_authorized','new_AP_computed','new_bootstrap_computed')
def need(c,m):
 if not c:raise RuntimeError('P12R_CONFIRM_AUTH_'+m)
def sha(b):return hashlib.sha256(b).hexdigest()
def verify_job(seed=None):
 need(os.environ.get('GITHUB_RUN_ATTEMPT')=='1' and os.environ.get('GITHUB_RUN_NUMBER')=='1','NO_RERUN_OR_SECOND_LOOK')
 block=os.environ.get('P12R_BLOCK');need(block in BLOCKS,'BLOCK')
 if seed is not None:need(seed in BLOCKS[block],'SEED_OUTSIDE_BLOCK')
 return BLOCKS[block]
def verify_model(path):
 raw=Path(path).read_bytes();need(sha(raw)==ART_SHA,'ART_SHA')
 with zipfile.ZipFile(path) as z:
  need(z.testzip() is None and len(z.namelist())==len(set(z.namelist())),'ZIP')
  base='p12r_frozen_models/';name='P12R_FROZEN_FULL_DEV_MODELS_v05248.json'
  b=z.read(base+name);m=json.loads(b);r=json.loads(z.read(base+'P12R_DEV_MODEL_FREEZE_RECEIPT_v05248.json'))
  need(sha(b)==MODEL_SHA==r['model_sha256'],'MODEL_SHA')
  need(r['status']=='PASS_P12R_TWO_DEV_MODELS_FROZEN_ONLY_NO_CONFIRMATION_NO_F3_RELEASE' and r['model_fits']==2 and r['trained_on_rows']==m['trained_on_rows']==4608 and r['trained_on_seeds']==m['trained_on_seeds']==list(range(24901,24907)),'RECEIPT')
  need(all(r[k] is False and m[k] is False for k in LOCKS) and not r['confirmation_execution_authorized'],'LOCKS')
  need(all(r[k] is None and m[k] is None for k in ('Congestion','FutureCongestion')),'NULLS')
  need(all(r[k]==m[k]==0 for k in ('confirmation_rows_read','confirmation_simulations_this_stage','diagnostic_rows_used','legacy_validation_rows_read','heldout_rows_read','official_F3_labels_constructed')),'NO_EXPOSURE')
  for key,label,n in [('local_model','B1',12),('remote_model','R',21)]:
   x=m[key];need(sha((json.dumps(x,sort_keys=True,indent=2,allow_nan=False)+'\n').encode())==r[label+'_model_sha256'],'SUBMODEL_SHA')
   need(len(x['names'])==len(x['means'])==len(x['sds'])==len(x['weights'])==n and all(math.isfinite(v) for k in ('means','sds','weights') for v in x[k]) and all(v>0 for v in x['sds']) and math.isfinite(x['intercept']),'MODEL_DIMENSIONS')
  need(m['remote_model']['names'][:12]==m['local_model']['names'],'FEATURE_ALIGNMENT')
 return m

def get(path):
 repo=os.environ['GITHUB_REPOSITORY'];need(repo=='parhamarjomand-hub/hcraf-ndnsim','REPO')
 req=urllib.request.Request('https://api.github.com/repos/'+repo+path,headers={'Authorization':'Bearer '+os.environ['GH_TOKEN'],'Accept':'application/vnd.github+json','User-Agent':'HCRAF-P12R-v05249'})
 with urllib.request.urlopen(req,timeout=60) as f:return json.load(f)
def main():
 verify_job();run=get('/actions/runs/'+str(MODEL_RUN));a=get('/actions/artifacts/'+str(MODEL_ART));current=get('/actions/runs/'+os.environ['GITHUB_RUN_ID'])
 need(run['status']=='completed' and run['conclusion']=='success' and run['head_sha']==MODEL_COMMIT and run['path'].endswith('/hcraf-stage1am-f3-p12r-dev-model-freeze-v0.52.48.yml') and run['updated_at']<current['created_at'],'MODEL_PRECEDES_CONFIRMATION')
 need(current['run_attempt']==1 and current['run_number']==1 and current['head_sha']==os.environ['GITHUB_SHA'],'RUN_IDENTITY')
 need(a['workflow_run']['id']==MODEL_RUN and a['workflow_run']['head_sha']==MODEL_COMMIT and a['digest']=='sha256:'+ART_SHA and not a['expired'] and a['size_in_bytes']==6083,'MODEL_ARTIFACT')
 subprocess.check_call(['git','merge-base','--is-ancestor',MODEL_COMMIT,'HEAD'])
 verify_model('p12r_model_auth/model.zip')
 # Verify development collection success as a source anchor; do not fetch any DEV rows.
 d=get('/actions/runs/45955373789');need(d['status']=='completed' and d['conclusion']=='success' and d['head_sha']=='749ef4e91f5fe1a47d8c39d816b8d9702d7263ae','DEV_PARENT')
 subprocess.check_call(['git','merge-base','--is-ancestor',d['head_sha'],'HEAD'])
 Path('episode_output/p12r_confirm_preflight/model_auth.json').write_text(json.dumps({'status':'PASS_IMMUTABLE_MODELS_BEFORE_CONFIRMATION','model_run':MODEL_RUN,'model_sha256':MODEL_SHA,'model_artifact':MODEL_ART,'model_artifact_sha256':ART_SHA,'confirmation_run':int(os.environ['GITHUB_RUN_ID']),'block':os.environ['P12R_BLOCK'],'seeds':verify_job()},sort_keys=True,indent=2))
 print('PASS_MODEL_AUTH_NO_FIT_NO_SCORING')
if __name__=='__main__':main()
