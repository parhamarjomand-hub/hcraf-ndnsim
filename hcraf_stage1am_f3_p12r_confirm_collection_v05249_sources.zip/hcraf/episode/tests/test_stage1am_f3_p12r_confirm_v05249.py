import importlib.util,unittest
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'scripts/run_stage1am_f3_p12r_confirm_v05249.py';spec=importlib.util.spec_from_file_location('runner',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Guards(unittest.TestCase):
 def test_matrix_exact(self):
  rs=m.matrix();self.assertEqual(len(rs),432);self.assertEqual(len({r['schedule_filename'] for r in rs}),216)
  for seed in range(25001,25037):self.assertEqual(sum(int(r['seed'])==seed for r in rs),12)
 def test_commands_original_conditions(self):
  for r in m.matrix():
   c=m.command(r,Path('/tmp/test'));self.assertIn('--run='+r['seed'],c);self.assertIn('--telemetryEnabled='+str(int(r['telemetry']=='on_20ms')),c);self.assertIn('--lossProbability=0',c);self.assertNotIn('p12yProbe',c)
 def test_development_rejected(self):
  r=dict(m.matrix()[0]);r['seed']='24901';self.assertRaises(RuntimeError,m.command,r,Path('/tmp/test'))
 def test_window_face_and_same_tick(self):
  def e(t,k,face=258,rtt=0):return dict(time_ns=t,event=k,face_id=face,rtt_ms=rtt)
  es=[e(25000000,'nack_rx'),e(25000001,'nack_rx'),e(30000000,'interest_drop',259),e(40000000,'rtt',rtt=8),e(80000000,'rtt',rtt=16),e(100000000,'interest_drop'),e(100000000,'interest_drop')]
  self.assertEqual(m.replay_local(es,100000000,6,258),[0,0,1,0,1,9.,0]);self.assertEqual(m.replay_local(es,100000000,7,258)[4],2)
 def test_missing_rtt(self):self.assertEqual(m.replay_local([],100000000,0,258),[0,0,0,0,0,0.,1])
 def test_future_rejected(self):self.assertRaises(RuntimeError,m.replay_local,[dict(time_ns=11,event='nack_rx',face_id=258)],10,1,258)
 def test_lock(self):self.assertFalse(m.LOCK['F3_ready']);self.assertFalse(m.LOCK['training_ready']);self.assertFalse(m.LOCK['GO_FREEZE']);self.assertIsNone(m.LOCK['FutureCongestion'])
 def test_model_and_blocks(self):
  import sys,os
  from unittest.mock import patch
  sys.path.insert(0,str(p.parent))
  import authorize_stage1am_f3_p12r_confirm_v05249 as a
  self.assertEqual([x for block in a.BLOCKS.values() for x in block],list(range(25001,25037)))
  with patch.dict(os.environ,{'GITHUB_RUN_ATTEMPT':'1','GITHUB_RUN_NUMBER':'1','P12R_BLOCK':'2'}):
   self.assertEqual(a.verify_job(25007),tuple(range(25007,25013)))
   self.assertRaises(RuntimeError,a.verify_job,25001)
  with patch.dict(os.environ,{'GITHUB_RUN_ATTEMPT':'2','GITHUB_RUN_NUMBER':'1','P12R_BLOCK':'2'}):self.assertRaises(RuntimeError,a.verify_job)
  with patch.dict(os.environ,{'GITHUB_RUN_ATTEMPT':'1','GITHUB_RUN_NUMBER':'2','P12R_BLOCK':'2'}):self.assertRaises(RuntimeError,a.verify_job)
 def test_cpp_streams(self):
  import re
  c=(p.parents[1]/'src/hcraf-stage1am-f3-p12r-confirm-v05249.cpp').read_text()
  found={(int(s),site):tuple(map(int,(a,b,d,e))) for s,site,a,b,d,e in re.findall(r'\{\{(\d+)u,"([a-z_]+)"\},\{(\d+)u,(\d+)u,(\d+)u,(\d+)u\}\}',c)}
  expected={(int(r['seed']),r['site']):tuple(int(r[k]) for k in ('traffic_stream_seed','routing_stream_seed','telemetry_stream_seed','selected_slot')) for r in m.matrix()}
  self.assertEqual(found,expected);self.assertEqual(len(found),108)
  self.assertNotIn('fair_local_dev',c)
if __name__=='__main__':unittest.main()
