# پروتکل ممیزی DEV v0.51.0 و تحویل به ممیزی 1AN

هدف آزمایش، کاهش اختلاط زمان‌بندی با ویژگی آنلاین برای Proxy فشار مسیر برگشت است، نه اثبات سازه F3.

- واحد مستقل RNG بلوکی است؛ نه Window، Face یا LP Fragment. تمام ۱۶۸ اجرا در جدول قفل‌شده v0.50.3 تعیین شده‌اند.
- زمان‌های فرستادن ۱۲ Target و ۹۶ Competitor برای هر Run باید از CSV دقیقاً برابر باشند؛ متغیر مداخله‌ای جفت سه‌ظرفیتی، فقط نرخ برگشت فیزیکی منتخب است.
- افق اصلی ۷۵ms در ظرفیت ۱۲Mbps؛ حساسیت ازپیش‌ثبت‌شده ۵۰ و ۱۰۰ms. رویداد DEQUEUE با صف بیش از ۵ms یا Drop فیزیکی سبب Proxy فشار می‌شود. بدون مشاهده DEQUEUE و بدون فشار، خروجی UNRESOLVED می‌ماند.
- Drop ترافیک رقیب و Target، اگر قابل انتساب باشند، شاخص توصیفی جداگانه‌اند. Probe مستقل لازم است؛ هیچ برچسب علمی منفی از ۵۰Mbps ساخته نمی‌شود.
- برای همه تصمیم‌های Target زمان، event_seq، SRTT، Goodput، SuccessEstimate، RoutingCost، شمارنده‌های valid و local queue جمع‌آوری می‌شود؛ هر ویژگی آینده یا remote queue در ورودی online ممنوع است.
- فقط پس از PASS ساختاری، ارزیابی Group-Aware: Leave-One-RNG-Out و Cross-family با مدل و Hyperparameter ثابت پیش‌ثبت‌شده انجام شود. Fold تک‌کلاسه UNDEFINED؛ ΔAP/Brier، bootstrap جفتی روی RNGها و Missingness گزارش شود. مدل این مرحله تشخیصی است، نه مدل اصلی Gate.
- نظارت/بدون نظارت صرفاً برای سنجش ابزار پایش به‌کار رود، نه برای ایجاد Proxy. Fail-closed در صورت نقص داده.
- خروجی موردنیاز ممیزی: ۱۶۸ فایل config/run، برنامه خام SEND/arrivals، پوشش ۲۰ دستگاه، Receipt، Features پیش از تصمیم، هزینه CPU/RSS و گزارش عدم انطباق با hash manifest.

حکم F3 بدون تغییر NO_GO است؛ `Congestion=null`, `FutureCongestion=null`, `F3_ready=false`, `GO_FREEZE=false`, `training_ready=false`.
