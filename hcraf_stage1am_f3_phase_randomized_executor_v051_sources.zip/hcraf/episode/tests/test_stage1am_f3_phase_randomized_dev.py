"""Offline locked-contract and no-leakage checks; real ndnSIM execution is GitHub-only."""
import csv,hashlib,importlib.util,json,pathlib,sys,unittest,io,contextlib
HERE=pathlib.Path(__file__).resolve().parents[1]
SCRIPTS=HERE/'scripts'
sys.path.insert(0,str(SCRIPTS))
import run_stage1am_f3_phase_randomized_dev as r
import verify_stage1am_f3_phase_randomized_dev as v

class PhaseExecutorContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rows=r.load_matrix()
    def test_run_matrix_168(self):self.assertEqual(len(self.rows),168)
    def test_monitored_144(self):self.assertEqual(sum(int(x['instrumented']) for x in self.rows),144)
    def test_unmonitored_24(self):self.assertEqual(sum(not int(x['instrumented']) for x in self.rows),24)
    def test_rng_24(self):self.assertEqual({int(x['rng_block']) for x in self.rows},set(range(11701,11725)))
    def test_each_rng_only_one_control(self):
        controls=[x['rng_block'] for x in self.rows if x['instrumented']=='0']
        self.assertEqual(len(controls),len(set(controls)))
    def test_four_phase_balance(self):
        rng_phase={(x['rng_block'],x['phase_label']) for x in self.rows}
        self.assertEqual({p:sum(t[1]==p for t in rng_phase) for p in ('P0','P1','P2','P3')},dict.fromkeys(('P0','P1','P2','P3'),6))
    def test_all_three_capacities_per_pair(self):
        d={}
        for x in self.rows:
            if x['instrumented']=='1':d.setdefault((x['rng_block'],x['family']),set()).add(x['arm'])
        self.assertEqual(len(d),48)
        self.assertTrue(all(a==set(r.ARMS) for a in d.values()))
    def test_locked_plan_hashes(self):
        for x in self.rows:
            self.assertEqual(r.digest(r.CONTRACT/x['plan_filename']),x['schedule_sha256'])
    def test_no_scientific_labels_in_matrix(self):
        with (r.CONTRACT/'RUN_MATRIX_LOCKED_168.csv').open() as f:
            s=f.read()
        for key in ('FutureCongestion','Congestion','F3_ready','target_label'):
            self.assertNotIn(key,s)
    def test_exec_cpp_consumes_csv(self):
        source=(HERE/'src/hcraf-stage1am-f3-phase-randomized-dev.cpp').read_text()
        self.assertIn('PREREG_SCHEDULE_FILENAME_MISMATCH',source)
        self.assertIn('Schedule(NanoSeconds(when)',source)
        self.assertIn('CSV_ROW_CONTEXT_CHANGED',source)
        self.assertNotIn('UniformRandomVariable',source)
    def test_immutable_lineage_not_old_scenario(self):
        source=(HERE/'src/hcraf-stage1am-f3-phase-randomized-dev.cpp').read_text()
        self.assertIn('run<11701 || run>11724',source)
        self.assertNotIn('run<11601 || run>11612',source)
    def test_scientific_locks(self):self.assertEqual(v.LOCKS,{'Congestion':None,'FutureCongestion':None,'F3_ready':False,'GO_FREEZE':False,'training_ready':False})
    def test_proxy_status_only(self):
        txt=(SCRIPTS/'verify_stage1am_f3_phase_randomized_dev.py').read_text()
        for s in ('PHYSICAL_PRESSURE_PROXY','LOW_PRESSURE_CANDIDATE','UNRESOLVED'):
            self.assertIn(s,txt)
    def test_not_train_model(self):
        txt=(SCRIPTS/'verify_stage1am_f3_phase_randomized_dev.py').read_text()
        self.assertNotIn('LogisticRegression',txt)
        self.assertNotIn('NSGA_III(',txt)
    def test_no_silent_negative_for_missing_evidence(self):
        txt=(SCRIPTS/'verify_stage1am_f3_phase_randomized_dev.py').read_text()
        self.assertIn("'UNRESOLVED'",txt)
        self.assertIn('if waits else',txt)
    def test_run_manifest_only_planned(self):self.assertEqual({x['status'] for x in self.rows},{'PREREG_PLANNED_NOT_RUN'})
    def test_target_competitor_per_plan(self):
        one=self.rows[0]
        with (r.CONTRACT/one['plan_filename']).open() as f:arr=list(csv.DictReader(f))
        self.assertEqual(sum(x['traffic_class']=='TARGET' for x in arr),12)
        self.assertEqual(sum(x['traffic_class']=='INDEPENDENT_COMPETITOR' for x in arr),96)
    def test_failclosed_on_missing_plan(self):
        with self.assertRaises(Exception):r.digest(pathlib.Path('/no/such/immutable/plan'))
    def test_failclosed_on_invalid_science_config(self):
        row=self.rows[0];c={'Congestion':True}
        with self.assertRaises(RuntimeError):v.config_check(c,row)

if __name__=='__main__':unittest.main()
