#!/usr/bin/env python3
"""v0.51 structural/proxy audit ONLY. No FutureCongestion labels or model fitting."""
import argparse,collections,csv,hashlib,json,pathlib
HERE=pathlib.Path(__file__).resolve().parent
from run_stage1am_f3_phase_randomized_dev import load_matrix,assert_send_plan,check,HASHES,ARMS,CONTRACT
HORIZONS=(50,75,100)
LOCKS={'Congestion':None,'FutureCongestion':None,'F3_ready':False,'GO_FREEZE':False,'training_ready':False}

def jlines(p):
    check(p.exists(),'MISSING_RAW_FILE:'+str(p))
    with p.open() as f:return [json.loads(x) for x in f if x.strip()]

def write_csv(path,rows,fields):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)

def config_check(c,row):
    rng=int(row['rng_block']);slot=int(row['selected_slot'])
    check(c.get('run')==rng and c.get('seed')==17 and c.get('selected_face_slot')==slot,'SCENARIO_RNG_SLOT_MISMATCH')
    check(c.get('topology_id')=='DEV_CHAIN_L' and c.get('holdout_partition')=='DEVELOPMENT','NOT_DEV_CHAIN_L')
    check(c.get('instrument_enabled') is bool(int(row['instrumented'])),'INSTRUMENT_MISMATCH')
    check(c.get('amendment_stage')=='1AM.F3_PHASE_RANDOMIZED_DEV_EXECUTOR.0','NOT_V051_NEW_CPP')
    check(c.get('schedule_contract')=='F3_PHASE_RANDOMIZED_PREREG_V0503_LOCKED_CSV','NOT_LOCKED_SCHEDULE')
    check(c.get('schedule_execution_source')=='IMMUTABLE_V0503_CSV','SCHEDULE_NOT_FROM_CSV')
    check(c.get('schedule_csv_filename')==pathlib.Path(row['plan_filename']).name,'SCENARIO_PLAN_MISMATCH')
    check(c.get('selected_producer_reverse_bps')==int(row['return_link_bps']),'CAPACITY_NOT_MATCHED')
    check(c.get('phase_arm')==row['arm'] and c.get('schedule_family')==row['family'],'PHASE_FAMILY_CHANGED')
    check(c.get('network_node_count')==11 and c.get('network_directed_device_count')==20 and
          c.get('mtu_bytes')==600 and c.get('queue_capacity_packets')==20 and
          c.get('payload_bytes')==4096 and c.get('stop_ns')==20_000_000_000 and
          c.get('interest_lifetime_ms')==2600 and c.get('cache_enabled') is False,'PHYSICAL_CONTRACT_CHANGED')
    check(c.get('selected_forward_bps')==50_000_000 and
          c.get('selected_relay_forward_bps')==50_000_000 and
          c.get('selected_mid_forward_bps')==50_000_000 and
          c.get('selected_return_bps')==50_000_000,'UNCONTROLLED_RATE_CHANGED')
    for k,v in LOCKS.items():check(c.get(k,'MISSING') is v,'SCIENCE_LOCK_BREACH:'+k)
    check(c.get('candidate_negative_control_is_not_scientific_label') is True and
          c.get('future_oracle_is_final_F3') is False and
          c.get('remote_queue_online_feature') is False,'LABEL_SCOPE_BREACH')
    return {k:v for k,v in c.items() if k not in ('phase_arm','selected_producer_reverse_bps','instrument_enabled',
           'local_NFD_queue_observed_before_send','NFD_dispatch_wall_CPU_measured')}

def audit_monitor(path,c,row):
    events=jlines(path/'link_events.jsonl')
    initial=[e for e in events if e.get('event_type')=='INITIAL']
    final=[e for e in events if e.get('event_type')=='FINAL']
    check(len(initial)==len(final)==20,'NOT_20_DEVICES_INITIAL_FINAL')
    devices=lambda xs:{(x['node_id'],x['device_index']) for x in xs}
    check(len(devices(initial))==20 and devices(initial)==devices(final),'DEVICE_SET_DISAGREEMENT')
    check({e['time_ns'] for e in initial}=={0} and {e['time_ns'] for e in final}=={20_000_000_000},'BAD_TRACE_COVERAGE')
    check(all(a['time_ns']<=b['time_ns'] for a,b in zip(events,events[1:])),'TRACE_NOT_CHRONOLOGICAL')
    selected=[e for e in initial if e['node_id']==c['selected_producer_node_id']]
    check(len(selected)==1,'REVERSE_SELECTED_DEVICE_NOT_UNIQUE')
    key=(selected[0]['node_id'],selected[0]['device_index'])
    reverse=[e for e in events if (e['node_id'],e['device_index'])==key]
    check(reverse[0]['event_type']=='INITIAL' and reverse[-1]['event_type']=='FINAL','REVERSE_BOUNDARY')
    queue=0
    for e in reverse:
        typ=e['event_type']
        if typ=='QUEUE_ENQUEUE':queue+=1
        if typ=='QUEUE_DEQUEUE':queue-=1
        check(0<=queue<=20,'IMPOSSIBLE_QUEUE')
        if typ in ('INITIAL','FINAL','QUEUE_ENQUEUE','QUEUE_DEQUEUE','QUEUE_DROP'):
            check(e['queue_packets']==queue,'QUEUE_TRANSITION_MISMATCH')
    decisions=[d for d in jlines(path/'events.jsonl.decisions.jsonl') if d['name'].startswith('/hcraf/pilot/')]
    check(len(decisions)==12,'TARGET_DECISIONS_NOT_12')
    dids={d['decision_id']:d for d in decisions}
    states=[s for s in jlines(path/'events.jsonl.states.jsonl') if
            s['decision_id'] in dids and s.get('face_id')==c['selected_face_id']]
    check(len(states)==12 and len({s['decision_id'] for s in states})==12,'SELECTED_HISTORY_MISSING')
    local=[s for s in jlines(path/'nfd_local_queue_at_decision.jsonl') if
           s.get('decision_id') in dids and s.get('candidate_face_id')==c['selected_face_id']]
    check(len(local)==12 and len({s['decision_id'] for s in local})==12,'SELECTED_LOCAL_QUEUE_MISSING')
    state_by={s['decision_id']:s for s in states};local_by={s['decision_id']:s for s in local}
    windows=[];online=[]
    for d in decisions:
        did=d['decision_id']; st=state_by[did]; lq=local_by[did];t=d['time_ns'];seq=d['after_event_seq']
        check(st['time_ns']<=t and st['after_event_seq']<=seq and
              (st.get('max_terminal_event_seq') or 0)<=seq,'ONLINE_LEAKAGE_FROM_FUTURE')
        check(lq['sim_time_ns']<=t and lq.get('observed_before_forwarding') is True and
              lq.get('remote_node_queue_accessed') is False,'LOCAL_SNAPSHOT_NOT_ONLINE')
        check(st.get('Congestion') is None and lq.get('Congestion') is None,'ONLINE_LABEL_CONTAMINATION')
        online.append({'run_id':row['run_id'],'rng_block':row['rng_block'],'family':row['family'],'arm':row['arm'],
            'phase_label':row['phase_label'],'decision_id':did,'time_ns':t,'name':d['name'],
            'face_id':c['selected_face_id'],'SRTT_ms':st.get('SRTT_ms'),'Goodput_bps':st.get('Goodput_bps'),
            'SuccessEstimate':st.get('SuccessEstimate'),'RoutingCost':st.get('RoutingCost'),
            'valid_outcomes':st.get('valid_outcomes'),'valid_rtt':st.get('valid_rtt'),
            'local_queue_packets':lq.get('queue_packets'),'after_event_seq':seq})
        for h in HORIZONS:
            within=[e for e in reverse if t < e['time_ns'] <=t+h*1_000_000]
            drops=sum(e['event_type']=='QUEUE_DROP' for e in within)
            waits=[e.get('queue_wait_ns') for e in within if e['event_type']=='QUEUE_DEQUEUE' and e.get('queue_wait_ns') is not None]
            check(all(isinstance(q,int) and q>=0 for q in waits),'INVALID_QUEUE_WAIT')
            pressure=bool(drops or any(q>5_000_000 for q in waits))
            label='PHYSICAL_PRESSURE_PROXY' if pressure else ('LOW_PRESSURE_CANDIDATE' if waits else 'UNRESOLVED')
            windows.append({'run_id':row['run_id'],'rng_block':row['rng_block'],'family':row['family'],
               'phase_label':row['phase_label'],'arm':row['arm'],'decision_id':did,'time_ns':t,
               'horizon_ms':h,'diagnostic_proxy_status':label,'queue_drops':drops,'dequeue_count':len(waits),
               'max_wait_ns':max(waits) if waits else None})
    return windows,online

def audit(root,report,contract=CONTRACT):
    matrix=load_matrix();check(root.exists() and not report.exists(),'MISSING_INPUT_OR_REPORT_EXISTS')
    results=[];online=[];windows=[];pairs={};counts=collections.Counter()
    for row in matrix:
        rng=row['rng_block'];family=row['family'];arm=row['arm'];kind='monitored' if int(row['instrumented']) else 'unmonitored'
        path=root/'DEV_CHAIN_L'/('rng-'+rng)/family/kind/arm
        check(path.is_dir(),'MISSING_RUN:'+row['run_id'])
        c=json.loads((path/'scenario.json').read_text());cmp=config_check(c,row)
        pkey=(rng,family)
        if pkey in pairs:check(pairs[pkey]==cmp,'UNCONTROLLED_CONFIG_DIFF_IN_PAIRED_ARMS')
        pairs[pkey]=cmp
        assert_send_plan(path,contract/row['plan_filename'])
        if kind=='monitored':
            w,o=audit_monitor(path,c,row);windows.extend(w);online.extend(o)
        check((path/'resource_usage.txt').is_file(),'MISSING_RESOURCE_USAGE')
        counts[kind]+=1
        results.append({'run_id':row['run_id'],'rng_block':rng,'family':family,'phase_label':row['phase_label'],
                        'arm':arm,'instrumented':int(row['instrumented']),
                        'plan_sha256':row['schedule_sha256'],'result':'PASS_STRUCTURAL'})
    check(counts=={'monitored':144,'unmonitored':24},'RUN_COUNT_WRONG')
    check(len(pairs)==48 and len(online)==1728 and len(windows)==5184,'AUDIT_ROWS_WRONG')
    report.mkdir(parents=True)
    write_csv(report/'run_integrity_168.csv',results,list(results[0]))
    write_csv(report/'online_predecision_1728.csv',online,list(online[0]))
    write_csv(report/'diagnostic_windows_5184.csv',windows,list(windows[0]))
    c=collections.Counter((w['arm'],w['horizon_ms'],w['diagnostic_proxy_status']) for w in windows)
    aggs=[{'arm':arm,'horizon_ms':h,'diagnostic_proxy_status':lab,'count':c[(arm,h,lab)]}
          for arm in ARMS for h in HORIZONS for lab in ('PHYSICAL_PRESSURE_PROXY','LOW_PRESSURE_CANDIDATE','UNRESOLVED')]
    write_csv(report/'proxy_counts.csv',aggs,list(aggs[0]))
    summary={'status':'PASS_STRUCTURAL_PHASE_RANDOMIZED_DEV_ONLY','monitored':144,'unmonitored':24,
             'rng_blocks':24,'plans':48,'primary_capacity_bps':12000000,'primary_horizon_ms':75,
             'no_f3_training':True,'construct_status':'NO_GO_F3_CONSTRUCT_AND_PREDICTABILITY_NOT_VALIDATED',**LOCKS}
    (report/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    return summary

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('root',type=pathlib.Path);ap.add_argument('--output',required=True,type=pathlib.Path)
    args=ap.parse_args();print(json.dumps(audit(args.root,args.output,None),indent=2))
