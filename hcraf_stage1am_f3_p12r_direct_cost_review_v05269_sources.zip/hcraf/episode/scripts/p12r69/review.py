"""Read-only review of sealed v68 evidence. Never runs a simulator or publishes labels."""
import argparse, concurrent.futures, csv, hashlib, json, os, pathlib, shutil, subprocess, sys, tempfile, zipfile
P=pathlib.Path
ROOT=P(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'p12r67'))
import confirm as c, analysis67 as locked
import audit as a
RUN=46133539555; COMMIT='faf334a321f27f5fc65ae9a20ac2a5fef04541c1'
PARENTS={15251340757:(46114789224,'64eb9b88dc84952c3c50a0db6dd4fcfc4f3a2ebb','5199ecc7c84e85deac3530a05c06134384821c85195482cc111f3745f1d17f0b'),15250979168:(46115765415,a.PREREG_COMMIT,a.PREREG_SHA),15255451489:(c.DEV_RUN,c.DEV_COMMIT,c.DEV_SHA),15258955667:(RUN,COMMIT,'d424c6559e43f8ece7860f43cd9b739e88649118afa9f72c15a06eb71673238f'),15259403865:(RUN,COMMIT,'8868d9214390c4a3a9cc248fdb7918bb338cc4b20462150154b2defe37092c1b')}
BLOCKS={1:(15259941424,'8e085cb08af4db9a1f20fba98df322012356e02368af7d9ada5e9df8179fc38d'),2:(15260135437,'9359c3032b7bdcaea1e4ef4c05508a373f03cd18cdc20c84fa467d6d7d7786de'),3:(15259548538,'a8aefd50fe7ab7ffd1b3fc51ac0720c3fa9083ec75b9553379ea9a7ad3915b7f'),4:(15259557212,'b02e476af6e47bd78202fd7508a16143096de01bac4b88e2bb13952237dd5705'),5:(15259289061,'42b0aae4d03974cd75304424f5d773985c97eeefb2993a3382e0ea41d38dc8b1'),6:(15259966764,'ebb3d3092e0b4963d786c93676e3596b0ce0087be4a1aba8095eb21d2d17f992')}
PARENTS.update({i:(RUN,COMMIT,h) for i,h in BLOCKS.values()})
STATUS='PASS_P12R69_SCOPED_EVIDENCE_REVIEW_RELEASE_PENDING'
need=a.need

def check_parents(root):
 for i,(_,_,h) in PARENTS.items():need(a.digest(root/f'github-actions-artifact-{i}.zip')==h,'PARENT_ZIP_'+str(i))
def fetch(root):
 root.mkdir();api=c.prov.api
 for rid,commit in sorted({(r,c) for r,c,h in PARENTS.values()}):
  r=api('/actions/runs/'+str(rid));need(r['status']=='completed' and r['conclusion']=='success' and r['head_sha']==commit and r['run_attempt']==1,'PARENT_RUN');subprocess.check_call(['git','merge-base','--is-ancestor',commit,'HEAD'])
 for i,(rid,commit,h) in PARENTS.items():
  r=api('/actions/artifacts/'+str(i));need(not r['expired'] and r['workflow_run']['id']==rid and r['workflow_run']['head_sha']==commit and r['digest']=='sha256:'+h,'ARTIFACT_ORIGIN');p=root/f'github-actions-artifact-{i}.zip';locked.subprocess_download(i,p);need(p.stat().st_size==r['size_in_bytes'],'ZIP_SIZE')
 check_parents(root)

def replay_case(task):
 r,s,d=task
 # Preserve immutable raw evidence; regenerate ONLY derived reference/receipt in scratch.
 with tempfile.TemporaryDirectory() as td:
  p=P(td);original={k:(d/k).read_bytes() for k in ('candidate_reference.json','case_receipt.json')}
  for x in d.iterdir():
   if x.name not in original:shutil.copyfile(x,p/x.name)
  a.audit_case(r,s,p)
  need(all((p/k).read_bytes()==v for k,v in original.items()),'RAW_REPLAY_MISMATCH:'+str(d))
 return str(d)

def adjudicate(plan,receipt,mapping):
 need(receipt['status']=='PASS_P12R67_DIRECT_COST_GATES_ONLY_NO_F3_RELEASE' and len(receipt['gates'])==26 and all(receipt['gates'].values()),'CONFIRMATION_GATES')
 need(all(receipt[k]==v for k,v in a.LOCKS.items()) and receipt['prior_NO_GO_preserved'] and receipt['model_fits']==receipt['heldout_rows_read']==receipt['official_F3_labels_constructed']==0,'FENCES')
 need(plan['protocol']=='P12R64_DIRECT_COST_PROSPECTIVE_DESIGN' and plan['prior_NO_GO_preserved'] and plan['locks']==a.LOCKS,'PLAN_LOCK')
 need(mapping['status']=='PASS_ARCHITECTURE_MAPPING_AUDIT_F3_RELEASE_BLOCKED' and mapping['prior_scientific_decision']=='NO_GO_P12R62_CONJUNCTIVE_GATES_NOT_MET','MAPPING')
 p=receipt['prediction'];need(p['sites']['producer_return']['mean']==0 and p['sites']['local_forward']['mean']>0,'SCOPE_RESULT')
 return {'scoped_construct_evidence_accepted':True,'direct_cost_evidence_accepted':True,'original_all_environment_estimand_validated':False,'closed_loop_validated':False,'deployment_queue_access_validated':False,'independent_human_review_completed':False,'main_dataset_integration_validated':False,'scope_amendment_approved':False,'candidate_definition':{'online':'binary G: local selected/candidate egress waiting queue time-average >= 1/4 on [t-75ms,t); no future, RTT or remote oracle','future':'binary candidate Y: max of six configured branch-exclusive directed waiting-queue time-average occupancies >= 1/4 on [t,t+75ms); actual first selected TX only; independent of terminal outcome; not whole realized route','missing':'invalid/unavailable, not zero; no counterfactual labels','metric':'grouped noninterpolated AP, equal mean over prospectively designated mixed B/E runs; 216 A/C/D controls retained, not silently omitted from original all-environment estimand','normalization':'DEV P1/P99 SRTT; RC min/max; missing SRTT normalized 1; diagnostic fixed equal weights only'},'release_blockers':['Explicit approval of restricted configured-branch/fixed-window scope and AP estimand amendment (1AA was proposal, not final approval).','Map to actual main-collection topology, candidate availability, causal trace/episode and Run-level split; reject unknowns; establish primary population and policy for single-class Runs prospectively.','Keep consumed v68 evidence out of new independent training/validation/test and preserve earlier NO_GO.','No claim of remote improvement, arbitrary topology, closed-loop, optimized weights or deployment overhead.'],'next':'After explicit scope approval, one gated main-dataset integration/readiness contract on separate unconsumed development/validation seeds, then release review; no heldout access or NSGA-III now.'}

def run(root,out,full):
 check_parents(root);need(sys.version_info[:3]==(3,13,5),'PYTHON_VERSION');out.mkdir();work=out.parent/'review_scratch';work.mkdir();f=lambda i:root/f'github-actions-artifact-{i}.zip'
 for i in (15251340757,15250979168,15258955667,15259403865):c.safe_extract(f(i),work/str(i))
 official=work/'15259403865';auth=work/'15258955667';origin=json.loads((official/'ORIGINS.json').read_text());ar=json.loads((auth/'AUTH.json').read_text());need(origin['run_id']==ar['run_id']==RUN and origin['head_sha']==ar['head_sha']==COMMIT and origin['auth_sha']==a.digest(auth/'AUTH.json') and origin['analysis_receipt_sha']==a.digest(official/'ANALYSIS_RECEIPT.json') and all(ar[k]==origin[k]==v for k,v in a.LOCKS.items()),'ORIGINS')
 norm=c.check_dev(f(15255451489),work/'dev');need(norm==c.norm_read(auth/'NORMALIZATION.json'),'NORM');cases,sch,hashes=c.load_prereg(f(15250979168));data=[];tasks=[];raw_count=0
 for b,(i,h) in BLOCKS.items():
  d=work/f'block{b}';c.safe_extract(f(i),d);o=origin['blocks'][str(b)];need(o['artifact_id']==i and o['sha256']==h and o['block_receipt_sha']==a.digest(d/'BLOCK_RECEIPT.json') and o['binary_sha']==json.loads((d/'BLOCK_RECEIPT.json').read_text())['binary_sha'],'BLOCK_ORIGIN');v=c.verify_block(d,b,cases,sch,hashes,auth);data.extend(v);raw_count+=sum(len(r['files']) for r,_ in v)
  for r in c.block_cases(cases,b):
   if full or int(r['seed'])==640201:tasks.append((r,sch[int(r['seed']),r['site']],d/r['seed']/r['site']/r['arm']))
  print('PASS_BLOCK_SEAL',b,flush=True)
 need(len(data)==360 and raw_count==6840,'RAW_COUNT');replay=work/'analysis_replay';receipt=locked.analyze(data,norm,replay);need(set(p.name for p in replay.iterdir())==set(receipt['files'])|{'ANALYSIS_RECEIPT.json'},'REPLAY_SET');need(all(p.read_bytes()==(official/p.name).read_bytes() for p in replay.iterdir()),'ANALYSIS_REPLAY')
 with concurrent.futures.ProcessPoolExecutor(max_workers=min(4,os.cpu_count() or 1)) as pool:
  count=0
  for _ in pool.map(replay_case,tasks):
   count+=1
   if count%30==0:print('PASS_RAW_REPLAY_CASES',count,flush=True)
 need(count==(360 if full else 10),'RAW_REPLAY_TOTAL');plan=json.loads((work/'15250979168/prereg_result/PLAN.json').read_text());mapping=json.loads((work/'15251340757/mapping_result/MAPPING_RECEIPT.json').read_text());review=adjudicate(plan,receipt,mapping)
 # Summarize state bound observations without claiming measured process memory or deployment latency.
 peaks=[];ops=[];outcomes={};srtt=0;g_local=0;g_remote=0
 for r,vs in data:
  d=next(t for t in (work/f'block{b}'/r['case']['seed']/r['case']['site']/r['case']['arm'] for b in BLOCKS) if t.exists());peaks.extend(int(x['peak']) for x in a.csvrows(d/'overhead.csv'));ops.extend(int(x['ops']) for x in a.csvrows(d/'features.csv'));srtt+=r['srtt_nonmissing']
  for k,v in r['outcomes'].items():outcomes[k]=outcomes.get(k,0)+v
  if r['case']['site']=='local_forward':g_local+=r['g_positive']
  else:g_remote+=r['g_positive']
 report=dict(status=STATUS if full else 'PASS_LOCAL_SEALS_AND_SAMPLE_RAW_REPLAY_ONLY',confirmation_cases=360,raw_files_verified=raw_count,full_raw_cases_replayed=count,analysis_files_byte_identical=6,prior_dev_cases_verified=150,prior_dev_raw_files_verified=2850,source_run=RUN,source_commit=COMMIT,official_analysis_sha=origin['analysis_receipt_sha'],all_gates_passed=26,prediction=receipt['prediction'],primary_cases=144,control_cases=216,selected_rows=45360,candidate_rows=136080,positive_rows=sum(r['all_positive'] for r,v in data),srtt_nonmissing=srtt,g_positive_by_site={'local_forward':g_local,'producer_return':g_remote},outcomes=outcomes,observed_peak_queue_history_events=max(peaks),observed_peak_scan_operations=max(ops),distinct_binary_hashes=len({x['binary_sha'] for x in origin['blocks'].values()}),binary_note='six separately compiled binaries; exact source patch and build receipts sealed, not byte-identical binaries',simulation_runs_new=0,model_fits=0,official_labels=0,heldout_rows_read=0,prior_NO_GO_preserved=True,review=review,**a.LOCKS)
 a.write(out/'REVIEW_RECEIPT.json',report);print(report['status'],flush=True)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--artifacts',type=P,required=True);p.add_argument('--out',type=P,required=True);p.add_argument('--download',action='store_true');p.add_argument('--full',action='store_true');q=p.parse_args()
 if q.download:fetch(q.artifacts)
 run(q.artifacts,q.out,q.full)
