import unittest,json,copy,pathlib,tempfile
import review as r
P=pathlib.Path
class ReviewTests(unittest.TestCase):
 def setUp(self):
  self.plan={'protocol':'P12R64_DIRECT_COST_PROSPECTIVE_DESIGN','prior_NO_GO_preserved':True,'locks':r.a.LOCKS.copy()}
  self.receipt=dict(status='PASS_P12R67_DIRECT_COST_GATES_ONLY_NO_F3_RELEASE',gates={str(i):True for i in range(26)},prior_NO_GO_preserved=True,model_fits=0,heldout_rows_read=0,official_F3_labels_constructed=0,prediction={'sites':{'local_forward':{'mean':.37},'producer_return':{'mean':0}}},**r.a.LOCKS)
  self.mapping={'status':'PASS_ARCHITECTURE_MAPPING_AUDIT_F3_RELEASE_BLOCKED','prior_scientific_decision':'NO_GO_P12R62_CONJUNCTIVE_GATES_NOT_MET'}
 def decide(self):return r.adjudicate(self.plan,self.receipt,self.mapping)
 def test_pass_is_scoped(self):
  v=self.decide();self.assertTrue(v['scoped_construct_evidence_accepted']);self.assertFalse(v['scope_amendment_approved']);self.assertFalse(v['main_dataset_integration_validated']);self.assertFalse(v['original_all_environment_estimand_validated'])
 def test_failed_gate(self):
  self.receipt['gates']['0']=False
  with self.assertRaises(RuntimeError):self.decide()
 def test_missing_gate(self):
  self.receipt['gates'].pop('0')
  with self.assertRaises(RuntimeError):self.decide()
 def test_release_refused(self):
  self.receipt['F3_ready']=True
  with self.assertRaises(RuntimeError):self.decide()
 def test_heldout(self):
  self.receipt['heldout_rows_read']=1
  with self.assertRaises(RuntimeError):self.decide()
 def test_prior_no_go(self):
  self.receipt['prior_NO_GO_preserved']=False
  with self.assertRaises(RuntimeError):self.decide()
 def test_mismatched_plan(self):
  self.plan['locks']['Congestion']=0
  with self.assertRaises(RuntimeError):self.decide()
 def test_remote_scope(self):
  self.receipt['prediction']['sites']['producer_return']['mean']=.01
  with self.assertRaises(RuntimeError):self.decide()
 def test_bad_artifact_hash(self):
  with tempfile.TemporaryDirectory() as t:
   p=P(t);(p/f'github-actions-artifact-{next(iter(r.PARENTS))}.zip').write_bytes(b'bad')
   with self.assertRaises(RuntimeError):r.check_parents(p)
if __name__=='__main__':unittest.main()
