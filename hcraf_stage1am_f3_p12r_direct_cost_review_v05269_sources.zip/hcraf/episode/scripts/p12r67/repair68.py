"""Narrow confirmation entry repair. No scientific changes."""
import hashlib,json,pathlib,zipfile,subprocess,tempfile,os,csv,io,sys
P=pathlib.Path
OLD_RUN=46128240710
OLD_COMMIT='eb3cd47f1379d6131a1c1ef8bb43ebac0aab6a85'
OLD_WORKFLOW='hcraf-stage1am-f3-p12r-direct-cost-confirm-v0.52.67.yml'
OLD_SOURCE='hcraf_stage1am_f3_p12r_direct_cost_confirm_v05267_sources.zip'
OLD_SOURCE_SHA='c8a296dd1259fcffeaa132a0c682c3208e61762e194ad458cf8aa526f186dc57'
OLD_AUTH_ID=15256387201
OLD_AUTH_SHA='7d24b3f9c87fecf41c6bb0a986778799c78e160b863ea595fd4565c2b776bf70'
FAILURES={'1': {'id': 15257843688, 'sha': '1cd397f7ff46d753da204b328664cc913510dd322cec4f169f6bb474fa252ab9', 'size': 49633, 'job': 140927667585, 'seed': 640201}, '2': {'id': 15257472755, 'sha': 'dc617cc9f8a9d6595ddbcb4fabf8b44f4ef057108b085677c42239de75c9aa00', 'size': 49479, 'job': 140927667591, 'seed': 640207}, '3': {'id': 15257194728, 'sha': '1135c18e85b7f23e56d0b3cd65fae9ae818f5abc8e360a422f3860758352c32d', 'size': 48754, 'job': 140927667604, 'seed': 640213}, '4': {'id': 15257089834, 'sha': '17289d7639485de461e825cca5574a3b5fb4263b2cfeebfe43ebd08c303797cd', 'size': 48684, 'job': 140927667581, 'seed': 640219}, '5': {'id': 15257328775, 'sha': 'a0e0af7603159ceea8077c251c2d692598c90c16cbf576c8def4e8fc565e1e76', 'size': 48648, 'job': 140927667583, 'seed': 640225}, '6': {'id': 15257702329, 'sha': '85d48b00c0516c83a8e6c42e261e30c7a9c69c14e67e8f55699f87bfa538a4d5', 'size': 49633, 'job': 140927667677, 'seed': 640231}}
NATIVE=P('hcraf/episode/src/hcraf-stage1am-f3-p12r-direct-cost-v05266.cpp')
OLD_CPP_SHA='ca535cc881b074c5e1f33c153423ff456c14f7c90c37569cab68ed35c7afe91a'
CPP_SHA='26db815e748ea2dbfc8846f2b940c9f2468a2d4acc94266b6f525d5bd8a920a2'
EDITS=[('Pilot run number', 'Confirmation run number'), (' std::string site,arm,output,schedule;U seed=0;', ' bool contractCheck=false;std::string site,arm,output,schedule;U seed=0;'), ('cmd.Parse(argc,argv);', 'cmd.AddValue("contractCheck","Validate locked arguments and schedule without simulation",contractCheck);cmd.Parse(argc,argv);'), ('unsigned start=seed>=640001&&seed<=640003?640001:seed>=640101&&seed<=640112?640101:0;', 'unsigned start=seed>=640201&&seed<=640236?640201:0;'), ('"PILOT_DEV_ONLY"', '"CONFIRMATION_ONLY"'), ('auto plan=readPlan(schedule);RngSeedManager::SetSeed(17);', 'auto plan=readPlan(schedule);if(contractCheck){std::cout<<"PASS_CONFIRMATION_ARGUMENTS_AND_SCHEDULE_NO_SIMULATION"<<std::endl;return 0;}RngSeedManager::SetSeed(17);')]
def need(x,m):
 if not x:raise RuntimeError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def patch_bytes(b):
 need(sha(b)==OLD_CPP_SHA,'ORIGINAL_CPP_SHA');s=b.decode()
 for a,c in EDITS:
  need(s.count(a)==1,'ANCHOR:'+a);s=s.replace(a,c,1)
 need(sha(s.encode())==CPP_SHA,'PATCHED_CPP_SHA');return s.encode()
def patch_file(p=NATIVE):
 p.write_bytes(patch_bytes(p.read_bytes()));print('PASS_EXACT_CONFIRMATION_ENTRY_PATCH',CPP_SHA)
def verify_failures(folder,prereg):
 import confirm as c
 cases,sch,_=c.load_prereg(prereg)
 az=folder/('artifact-%s.zip'%OLD_AUTH_ID);need(sha(az.read_bytes())==OLD_AUTH_SHA,'OLD_AUTH_SHA')
 with zipfile.ZipFile(az) as z:
  need(z.testzip() is None and set(z.namelist())=={'AUTH.json','NORMALIZATION.json'},'OLD_AUTH_MEMBERS');auth=z.read('AUTH.json');ar=json.loads(auth);need(ar['run_id']==OLD_RUN and ar['head_sha']==OLD_COMMIT and ar['status']=='PASS_CONFIRMATION_AUTHORIZED_ENGINEERING_ONLY' and ar['source67_sha']==OLD_SOURCE_SHA and sha(z.read('NORMALIZATION.json'))==c.NORM_SHA and all(ar[k]==v for k,v in c.a.LOCKS.items()),'OLD_AUTH_FIELDS')
 for b,f in FAILURES.items():
  p=folder/('artifact-%s.zip'%f['id']);need(p.stat().st_size==f['size'] and sha(p.read_bytes())==f['sha'],'FAILURE_SHA')
  prefix='p12r67_block/%s/local_forward/A/'%f['seed'];build='p12r67_block/BUILD_RECEIPT.json'
  with zipfile.ZipFile(p) as z:
   names=set(z.namelist());need(z.testzip() is None and len(names)==len(z.namelist()) and names=={prefix+x for x in ('command.txt','schedule.csv','simulator.log')}|{build,'p12r66_preflight/build.log','p12r66_preflight/confirm.log','p12r66_preflight/restore.log','p12v_native_preflight/NFD_PINNED_HOOK_PATCH_RECEIPT.json'},'UNEXPECTED_FAILED_FILES')
   log=z.read(prefix+'simulator.log').decode();need('what():  PILOT_DEV_ONLY' in log and 'terminated with signal SIGIOT' in log,'WRONG_FAILURE')
   cmd=z.read(prefix+'command.txt').decode();r=next(x for x in cases if int(x['seed'])==f['seed'] and x['site']=='local_forward' and x['arm']=='A');need(all('--'+k+'='+str(v) in cmd for k,v in dict(run=r['seed'],site=r['site'],arm=r['arm'],target=r['target_slot'],rate=r['background_mbps'],loss=r['error_ppm'],delay=r['extra_propagation_ms'],trafficStream=r['traffic_stream'],errorStream=r['error_stream'],streamBase=r['stream_base']).items()),'FAILED_COMMAND')
   rows=list(csv.reader(io.StringIO(z.read(prefix+'schedule.csv').decode())));need([tuple(map(int,x)) for x in rows[1:]]==sch[f['seed'],'local_forward'],'FAILED_SCHEDULE')
   r=json.loads(z.read(build));need(r['block']==int(b) and r['simulations']==0 and r['auth_sha']==sha(auth) and r['source66_sha']==c.SOURCE66 and all(r[k]==v for k,v in c.a.LOCKS.items()),'FAILED_BUILD')
 return dict(run_id=OLD_RUN,head_sha=OLD_COMMIT,failed_blocks=6,simulations_started=0,old_auth_sha=OLD_AUTH_SHA,failed_artifacts=FAILURES,scope='exact guard precedes readPlan/RNG/topology; six archives contain only command, schedule, failure and build receipts; no confirmation scores or raw traces',patched_cpp_sha=CPP_SHA)
def official_recovery(prereg):
 import confirm as c
 api=c.prov.api;need(sha(subprocess.check_output(['git','show',OLD_COMMIT+':'+OLD_SOURCE]))==OLD_SOURCE_SHA,'OLD_SOURCE');subprocess.check_call(['git','merge-base','--is-ancestor',OLD_COMMIT,'HEAD'])
 r=api('/actions/runs/'+str(OLD_RUN));need(r['path']=='.github/workflows/'+OLD_WORKFLOW and r['status']=='completed' and r['conclusion']=='failure' and r['head_sha']==OLD_COMMIT and r['run_attempt']==1,'OLD_RUN');l=api('/actions/workflows/'+OLD_WORKFLOW+'/runs?per_page=100');need(l['total_count']==1 and [x['id'] for x in l['workflow_runs']]==[OLD_RUN],'OLD_REPEAT')
 j=api('/actions/runs/'+str(OLD_RUN)+'/jobs?per_page=100');need(j['total_count']==8 and len(j['jobs'])==8,'OLD_JOBS');jobs={x['id']:x for x in j['jobs']};need(jobs[140927539858]['conclusion']=='success' and jobs[140939806254]['conclusion']=='skipped','OLD_ANALYSIS')
 for f in FAILURES.values():
  x=jobs[f['job']];s={y['number']:y['conclusion'] for y in x['steps']};need(x['conclusion']=='failure' and s[14]=='success' and s[15]=='failure' and s[16]=='skipped' and s[17]=='success','OLD_BLOCK_STEPS')
 with tempfile.TemporaryDirectory() as td:
  p=P(td);items=[(OLD_AUTH_ID,OLD_AUTH_SHA)]+[(f['id'],f['sha']) for f in FAILURES.values()];l=api('/actions/runs/'+str(OLD_RUN)+'/artifacts?per_page=100');need(len(l['artifacts'])==7 and {x['id'] for x in l['artifacts']}=={i for i,h in items},'OLD_ARTIFACT_SET')
  for i,h in items:
   x=api('/actions/artifacts/'+str(i));need(not x['expired'] and x['digest']=='sha256:'+h and x['workflow_run']['id']==OLD_RUN and x['workflow_run']['head_sha']==OLD_COMMIT,'OLD_ARTIFACT_ORIGIN');subprocess.check_call(['curl','--fail','--silent','--show-error','--location','--retry','3','--max-time','180','-H','Authorization: Bearer '+os.environ['GH_TOKEN'],'-H','Accept: application/vnd.github+json','https://api.github.com/repos/'+os.environ['GITHUB_REPOSITORY']+'/actions/artifacts/'+str(i)+'/zip','-o',str(p/('artifact-%s.zip'%i))])
  return verify_failures(p,prereg)
if __name__=='__main__':patch_file()
