import json,csv,io,zipfile,sys,pathlib
import audit as a
import provenance as p
P=pathlib.Path

def verify(path):
 a.need(a.digest(path)==p.FAILED_SHA,'FAILED_ZIP_SHA')
 with zipfile.ZipFile(path) as z:
  a.need(z.testzip() is None and len(set(z.namelist()))==len(z.namelist()),'FAILED_ZIP_CRC')
  names=set(z.namelist());prefix='p12r65_pilot/640001/local_forward/A/'
  a.need(not any(n.startswith('p12r65_dev/') or n.endswith('case_receipt.json') or n.endswith('PARTITION_RECEIPT.json') for n in names),'FAILED_UNEXPECTED_ROWS')
  a.need({n.rsplit('/',1)[0]+'/' for n in names if n.startswith('p12r65_pilot/')}=={prefix},'FAILED_CASE_SCOPE')
  r=json.loads(z.read('p12r65_preflight/IMPLEMENTATION_RECEIPT.json'));a.need(r['status']=='PASS_IMPLEMENTATION_BUILD_LOCK_ONLY' and r['run_id']==str(p.FAILED) and r['head_sha']==p.FAILED_COMMIT and r['source_archive_sha256']=='9ed6c15ac73dcb0e3c02a579ac8a90bbbf7d93b3c97057768ff853588803e8d4' and r['prereg_sha256']==a.PREREG_SHA,'FAILED_BUILD_RECEIPT')
  a.need(b'DECISION_COUNT' in z.read(prefix+'simulator.log') and z.read(prefix+'features.csv')==b'','FAILED_SIGNATURE')
  d=[json.loads(x) for x in z.read(prefix+'events.jsonl.decisions.jsonl').splitlines()];t=[e for e in map(json.loads,z.read(prefix+'events.jsonl').splitlines()) if e['event_type']=='TX_INTEREST'];schedule=list(csv.DictReader(io.StringIO(z.read(prefix+'schedule.csv').decode())))
  a.need(len(d)==len(t)==len(schedule)==126,'FAILED_COUNTS');a.need(all(x['decision_id']==y['decision_id']==i+1 and x['name']==y['name'] and x['time_ns']==y['time_ns']==int(s['decision_ns']) and y['face_id']==x['candidates'][0]['face_id'] for i,(x,y,s) in enumerate(zip(d,t,schedule))),'FAILED_LEGACY_SELECTION')
  match=sum(int(s['cost_slot'+s['selected_slot']])==10 for s in schedule);a.need(match==42,'FAILED_MATCH_COUNT')
  return dict(status='PASS_FAILED_ENGINEERING_ATTEMPT_AUTHENTICATED_RETRY_ONLY',failed_run=p.FAILED,failed_artifact=p.FAILED_ART,failed_zip_sha256=p.FAILED_SHA,failed_case=['640001','local_forward','A'],legacy_selected_first_candidate=126,scheduled_matches=match,accepted_cases=0,dev_executed=0,confirmation_executed=0,failed_data_training_authorized=False,**a.LOCKS)
if __name__=='__main__':a.write(P(sys.argv[2]),verify(P(sys.argv[1])))
