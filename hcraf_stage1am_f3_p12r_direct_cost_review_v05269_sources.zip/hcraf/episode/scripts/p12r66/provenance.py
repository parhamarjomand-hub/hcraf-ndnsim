import json,os,pathlib,subprocess,sys,urllib.request,urllib.parse,zipfile,re,io,stat,time
import audit as a
P=pathlib.Path
RID=46115765415; ART=15250979168; COMMIT=a.PREREG_COMMIT
FAILED=46116798501; FAILED_COMMIT="38452059ef62adf76984810b8b41ddc89d73a438"; FAILED_ART=15252554024; FAILED_SHA="8abd79d7123d9789b8d29af5ddecf29dfe3fb0ec54f44d71d94a710c845e3cf0"
PRIOR={46044334756:'cd3c1c87351497e3be1093bf81c156bbc273c08f',46051275419:'75919d2f93f50108816a88bfc441339b09fc111e',46062593390:'518a31059fdf94179c94de10701e22b7bc841a1a',46068343005:'eacca309a4193e53f706b4aea18f6683136d8dbe',46068985498:'737c7395d2aa16ff23ed710e81928cdb6811d9db',46069686033:'ce6fc3e1bb343c114b3483a808cf7312efd0955c',46109235095:'4248de86b4285d5408701e7e327c338f630daff9',46113642336:'5328f2dd34358378068840e53d22812a18fe805d',46114789224:'64eb9b88dc84952c3c50a0db6dd4fcfc4f3a2ebb',RID:COMMIT,FAILED:FAILED_COMMIT}
SEEDS=set(range(640001,640004))|set(range(640101,640113))|set(range(640201,640237))
STREAMS={2000000+(seed-640000)*100+site*10+k for seed in SEEDS for site in range(2) for k in range(10)}
TOKEN=re.compile(rb'(?<![A-Za-z0-9])\d{6,7}(?![A-Za-z0-9])'); RANGE=re.compile(rb'\brange\s*\(\s*(\d{5,9})\s*,\s*(\d{5,9})\s*\)')
TEXT={'.py','.cpp','.cc','.h','.hpp','.sh','.yml','.yaml','.json','.md','.txt','.csv'}
def matches(data):
 ids=SEEDS|STREAMS;hits={int(m.group()) for m in TOKEN.finditer(data)}&ids
 for line in data.splitlines():
  if re.search(rb'\b(seed\w*|rng\w*|run\w*|stream\w*)\b',line,re.I):
   for m in RANGE.finditer(line):
    lo,hi=map(int,m.groups());hits|={x for x in ids if lo<=x<hi}
 return sorted(hits)
def source_archive(n):return n.lower().endswith('.zip') and any(k in n.lower() for k in ('source','workflow')) and not any(k in n.lower() for k in ('artifact','episode_output','/raw/','/results/'))
def eligible(n):
 p=P(n);l=n.lower();return p.suffix.lower() in TEXT and not any(x in l for x in ('/episode_output/','/raw/','/results/','/artifacts/','__pycache__')) and (p.suffix.lower()!='.csv' or any(x in l for x in ('matrix','schedule','plan','seed','prereg','split','lock')))
def scan(raw,n,level=0):
 if source_archive(n.split('!')[-1]):
  a.need(level<4,'HISTORY_NESTING');hits=[];count=0
  with zipfile.ZipFile(io.BytesIO(raw)) as z:
   for m in z.infolist():
    if m.is_dir() or not (eligible(m.filename) or source_archive(m.filename)):continue
    a.need(m.file_size<=64*1024*1024,'HISTORY_MEMBER_TOO_LARGE');h,c=scan(z.read(m),n+'!'+m.filename,level+1);hits+=h;count+=c
  return hits,count
 if not eligible(n.split('!')[-1]):return [],0
 h=matches(raw);return ([dict(path=n,ids=h)] if h else []),1

def api(path):
 a.need(os.environ['GITHUB_REPOSITORY']=='parhamarjomand-hub/hcraf-ndnsim','REPO')
 req=urllib.request.Request('https://api.github.com/repos/'+os.environ['GITHUB_REPOSITORY']+path,headers={'Authorization':'Bearer '+os.environ['GH_TOKEN'],'Accept':'application/vnd.github+json','User-Agent':'HCRAF-P12R66'})
 with urllib.request.urlopen(req,timeout=60) as r:return json.load(r)
def verify(out):
 a.need(os.environ['GITHUB_RUN_ATTEMPT']=='1' and os.environ['GITHUB_RUN_NUMBER']=='1','FIRST_ONLY')
 for rid,commit in PRIOR.items():
  r=api('/actions/runs/'+str(rid));a.need(r['status']=='completed' and r['conclusion']==('failure' if rid in (46069686033,FAILED) else 'success') and r['head_sha']==commit and r['run_attempt']==1,'PRIOR_RUN_'+str(rid));subprocess.check_call(['git','merge-base','--is-ancestor',commit,'HEAD'])
 ar=api('/actions/artifacts/'+str(ART));a.need(not ar['expired'] and ar['digest']=='sha256:'+a.PREREG_SHA and ar['workflow_run']['id']==RID and ar['workflow_run']['head_sha']==COMMIT,'PREREG_ART')
 # Recovery is permitted only after the exact failed engineering-only attempt.
 f=api('/actions/artifacts/'+str(FAILED_ART));a.need(not f['expired'] and f['digest']=='sha256:'+FAILED_SHA and f['workflow_run']['id']==FAILED and f['workflow_run']['head_sha']==FAILED_COMMIT,'FAILED_ARTIFACT_ORIGIN')
 oldwf='hcraf-stage1am-f3-p12r-direct-cost-native-v0.52.65.yml'
 rr=api('/actions/runs/'+str(FAILED));a.need(rr['path']=='.github/workflows/'+oldwf,'FAILED_WORKFLOW')
 lj=api('/actions/runs/'+str(FAILED)+'/jobs?per_page=100');a.need(lj['total_count']==1 and len(lj['jobs'])==1,'FAILED_JOB_COUNT')
 j=lj['jobs'][0];steps={x['number']:x['conclusion'] for x in j['steps']};a.need(j['id']==140892357202 and j['conclusion']=='failure' and steps[13]==steps[14]=='success' and steps[15]=='failure' and steps[16]==steps[17]=='skipped','FAILED_PILOT_ONLY')
 oldlist=api('/actions/workflows/'+oldwf+'/runs?per_page=100');a.need(oldlist['total_count']==1 and len(oldlist['workflow_runs'])==1 and oldlist['workflow_runs'][0]['id']==FAILED,'OLD_WORKFLOW_REPEATED')
 # Direct fetch of relevant workflow runs avoids requiring complete eventually consistent global listing.
 workflow='hcraf-stage1am-f3-p12r-direct-cost-native-v0.52.66.yml';current=int(os.environ['GITHUB_RUN_ID']);r=api('/actions/runs/'+str(current));a.need(r['path']=='.github/workflows/'+workflow and r['head_sha']==os.environ['GITHUB_SHA'] and r['run_attempt']==1,'CURRENT_RUN')
 # No other run of this workflow is allowed. A missing current listing is not used as proof; direct ID above.
 listing=api('/actions/workflows/'+workflow+'/runs?per_page=100');a.need(listing['total_count']<=1 and all(x['id']==current for x in listing['workflow_runs']),'UNEXPECTED_NATIVE_RUN')
 a.need(subprocess.check_output(['git','rev-parse','--is-shallow-repository'],text=True).strip()=='false','SHALLOW')
 # Exclude only exact locked own design/implementation blobs, not earlier names or arbitrary history.
 allowed=set()
 for ref,paths in [(COMMIT,['hcraf_stage1am_f3_p12r_direct_cost_prereg_v05264_sources.zip','.github/workflows/hcraf-stage1am-f3-p12r-direct-cost-prereg-v0.52.64.yml']),(FAILED_COMMIT,['hcraf_stage1am_f3_p12r_direct_cost_native_v05265_sources.zip','.github/workflows/'+oldwf]),('HEAD',['hcraf_stage1am_f3_p12r_direct_cost_native_v05266_sources.zip','.github/workflows/'+workflow])]:
  for p in paths:allowed.add(subprocess.check_output(['git','rev-parse',ref+':'+p],text=True).strip())
 objects=subprocess.check_output(['git','rev-list','--objects','HEAD'],text=True).splitlines();checked=archives=0;hits=[];seen=set()
 for line in objects:
  if ' ' not in line:continue
  oid,n=line.split(' ',1)
  if oid in seen or oid in allowed or not(eligible(n) or source_archive(n)):continue
  seen.add(oid);typ=subprocess.check_output(['git','cat-file','-t',oid],text=True).strip()
  if typ!='blob':continue
  size=int(subprocess.check_output(['git','cat-file','-s',oid],text=True));a.need(size<=128*1024*1024,'HISTORY_BLOB_TOO_LARGE');raw=subprocess.check_output(['git','cat-file','blob',oid]);h,c=scan(raw,n);hits+=h;checked+=c;archives+=source_archive(n)
 a.need(checked>0 and archives>0,'HISTORY_EMPTY');a.write(out,dict(status='PASS_DECLARED_SEED_STREAM_NAMESPACE' if not hits else 'STOP_NAMESPACE_COLLISION',scope='reachable tracked source/plan ancestry and directly known run IDs; no external execution claim',checked_text_members=checked,checked_archives=archives,seeds=sorted(SEEDS),streams=sorted(STREAMS),hits=hits,prior_runs=sorted(PRIOR),failed_engineering_run=FAILED,failed_artifact=FAILED_ART,retry_scope='pilot only, one consumed failed engineering case; DEV never started',**a.LOCKS));a.need(not hits,'HISTORICAL_NAMESPACE_COLLISION_REVIEW_REQUIRED')
if __name__=='__main__':verify(P(sys.argv[1]))
