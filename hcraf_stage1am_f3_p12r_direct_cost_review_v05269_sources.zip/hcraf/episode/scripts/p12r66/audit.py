#!/usr/bin/env python3
"""Direct-Cost engineering only; no scores, AP, fitting, or confirmation reads."""
import argparse,csv,hashlib,io,json,pathlib,subprocess,zipfile,collections,bisect,os
from fractions import Fraction
P=pathlib.Path; H=75_000_000; END=20_000_000_000
PREREG_SHA='c747798391c9324867b94809c9a7e095eda081dc1bee9523be40896b3521a78a'
PREREG_COMMIT='693615edd3ce75d5aacdee6f8570244b3445ca1b'
BIN='hcraf-stage1am-f3-p12r-direct-cost-v05266'
LOCKS=dict(F3_ready=False,GO_FREEZE=False,training_ready=False,construct_validated=False,heldout_release_authorized=False,Stage1AO_or_NSGAIII_authorized=False,Congestion=None,FutureCongestion=None)
KEYS=set(range(9))|set(range(12,21))
SITES=('local_forward','producer_return')
STATUS='PASS_P12R66_DIRECT_COST_PILOT_DEV_NORMALIZATION_ONLY_NO_F3_RELEASE'
def need(ok,msg):
 if not ok:raise RuntimeError('P12R66_'+msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def write(p,obj):p.write_text(json.dumps(obj,sort_keys=True,indent=2,allow_nan=False)+'\n')
def csvrows(p):
 with p.open(newline='') as f:return list(csv.DictReader(f))
def jsrows(p):return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]
def read_prereg(p,partition):
 need(partition in ('pilot','development'),'PARTITION')
 need(digest(p)==PREREG_SHA,'PREREG_ZIP_SHA')
 with zipfile.ZipFile(p) as z:
  need(z.testzip() is None and len(z.namelist())==len(set(z.namelist())),'PREREG_CRC')
  r=json.loads(z.read('prereg_result/PREREG_RECEIPT.json'))
  need(r['status']=='PASS_P12R64_DIRECT_COST_DESIGN_LOCK_ONLY_NO_EXECUTION' and r['prior_NO_GO_preserved'] and r['simulations']==0 and all(r[k]==v for k,v in LOCKS.items()),'PREREG_LOCKS')
  b={k:z.read('prereg_result/'+k) for k in ('PLAN.json','LOCKED_MATRIX.csv','LOCKED_SCHEDULE.csv')}
  need(all(sha(v)==r['files'][k] for k,v in b.items()),'MEMBER_SHA')
 def rows(k):return list(csv.DictReader(io.StringIO(b[k].decode())))
 cases=[x for x in rows('LOCKED_MATRIX.csv') if x['partition']==partition];sch=collections.defaultdict(list)
 for x in rows('LOCKED_SCHEDULE.csv'):
  if x['partition']==partition:sch[int(x['seed']),x['site']].append(tuple(int(x[k]) for k in ('decision_index','decision_ns','selected_slot','cost_slot0','cost_slot1','cost_slot2')))
 n=3 if partition=='pilot' else 12;start=640001 if partition=='pilot' else 640101
 need(len(cases)==n*10 and len(sch)==n*2 and set(sch)=={(i,j) for i in range(start,start+n) for j in SITES},'MATRIX_COUNT')
 need({(int(x['seed']),x['site'],x['arm']) for x in cases}=={(i,j,k) for i in range(start,start+n) for j in SITES for k in 'ABCDE'},'CASE_SET')
 for s in sch.values():
  need(len(s)==126 and [x[0] for x in s]==list(range(126)) and all(set(x[3:])=={10,20,30} and x[2] in (0,1,2) for x in s),'SCHEDULE')
  for j in range(0,126,9):need({(x[2],x[3+x[2]]) for x in s[j:j+9]}=={(k,c) for k in range(3) for c in (10,20,30)},'BLOCK')
 return cases,sch,{k:sha(v) for k,v in b.items()}
def queue_audit(a,b):
 need(a and b and a[0]['event']==b[0]['event']=='INITIAL' and a[-1]['event']==b[-1]['event']=='FINAL','TRACE_BOUNDS')
 need(int(a[0]['time_ns'])==int(b[0]['time_ns'])==0 and int(a[-1]['time_ns'])==int(b[-1]['time_ns'])==END,'TRACE_COVERAGE')
 q=0;pending={};changes=[];drops=[];states=[(0,0,0)];wait=[];enq={};deq={};last=0
 for i,e in enumerate(a[1:-1],1):
  t,u,n,bs,w=map(int,(e['time_ns'],e['uid'],e['packets'],e['bytes'],e['wait_ns']));k=e['event'];need(last<=t<=END and 0<=n<=32 and bs>0,'QUEUE_VALUE');last=t
  if k=='ENQUEUE':
   need(n==q+1 and u not in pending,'ENQUEUE');pending[u]=(t,bs);enq[u]=(t,bs);changes.append((t,q,n))
  elif k=='DEQUEUE':
   need(n==q-1 and u in pending and pending[u]==(t-w,bs) and w>=0,'DEQUEUE');del pending[u];deq[u]=(t,bs);wait.append(w);changes.append((t,q,n))
  elif k=='DROP':need(n==q==32 and u not in pending,'DROP_NOT_FULL');drops.append((t,u))
  else:raise RuntimeError('UNKNOWN_QUEUE_EVENT')
  states.append((t,i,n));q=n
 need(not pending and q==int(a[-1]['packets'])==int(b[-1]['new'])==0,'DRAIN');need(int(a[0]['packets'])==int(b[0]['new'])==0,'INITIAL_EMPTY');need(all(int(x['time_ns'])<=int(y['time_ns']) for x,y in zip(b,b[1:])),'B_ORDER')
 need(changes==[(int(e['time_ns']),int(e['old']),int(e['new'])) for e in b[1:-1] if e['event']=='CHANGE'],'LENGTH_WITNESS');need(drops==[(int(e['time_ns']),int(e['uid'])) for e in b[1:-1] if e['event']=='MAC_DROP'],'DROP_WITNESS');need(len(b)==len(changes)+len(drops)+2,'UNKNOWN_B_EVENT')
 states.append((END,len(a),0));return dict(states=states,drops=drops,enq=enq,deq=deq,wait=wait)

def background_times(rate):return [1_000_000_000+p*1_000_000_000+k*9_600_000_000_000//(rate*1_000_000) for p in range(18) for k in range((500_000_000*rate*1_000_000+9_600_000_000_000-1)//9_600_000_000_000) if k*9_600_000_000_000//(rate*1_000_000)<500_000_000]
def window_area(states,t0,t1):
 # Linear-area prefix with bisect, independent from the prereg reference implementation.
 times=[r[0] for r in states];i=bisect.bisect_right(times,t0)-1;need(i>=0 and t1<=times[-1] and t0<t1,'WINDOW_COVERAGE');last=t0;q=states[i][2];area=0
 for t,_,n in states[i+1:]:
  if t>=t1:break
  area+=(t-last)*q;last=t;q=n
 return area+(t1-last)*q

class IndependentArea:
 def __init__(self,b):
  self.t=[0];self.q=[0];self.a=[0]
  for e in b:
   if e['event']!='CHANGE':continue
   t=int(e['time_ns']);q=int(e['new']);self.a.append(self.a[-1]+(t-self.t[-1])*self.q[-1]);self.t.append(t);self.q.append(q)
 def at(self,t):
  i=bisect.bisect_right(self.t,t)-1;return self.a[i]+(t-self.t[i])*self.q[i]
 def area(self,t0,t1):return self.at(t1)-self.at(t0)

def round5(x):return x//5+int(x%5>=3)
def audit_case(r,s,d):
 seed,slot,rate,loss,delay=[int(r[k]) for k in ('seed','target_slot','background_mbps','error_ppm','extra_propagation_ms')];site=r['site'];j=0 if site=='local_forward' else 2;target=12+3*slot if site=='local_forward' else 3*slot+2
 cfgrows=csvrows(d/'devices.csv');cfg={int(x['queue']):x for x in cfgrows};need(len(cfgrows)==18 and set(cfg)==KEYS,'DEVICE_COUNT');faces=[int(cfg[12+3*s]['face']) for s in range(3)]
 for k in KEYS:
  e=cfg[k];x,h=divmod(k if k<9 else k-12,3);nodes=[1,2+x,7-x,8+x];pair=(nodes[h+1],nodes[h]) if k<9 else (nodes[h],nodes[h+1]);need((int(e['sender']),int(e['receiver']))==pair,'DEVICE_MAP');need(int(e['capacity'])==32 and int(e['rate_bps'])==(12000000 if k==target else 50000000),'RATE_CAP');need(int(e['delay_ns'])==(2+(delay if x==slot and h==j else 0))*1000000,'CHANNEL_DELAY')
  need(int(e['face'])==(faces[x] if k>=12 and h==0 else 0),'FACE_MAP')
 need(len(set(faces))==3 and all(x>0 for x in faces),'FACE_DISTINCT');q_a=collections.defaultdict(list);q_b=collections.defaultdict(list)
 for x in csvrows(d/'queue_a.csv'):q_a[int(x['queue'])].append(x)
 for x in csvrows(d/'queue_b.csv'):q_b[int(x['queue'])].append(x)
 need(set(q_a)==set(q_b)==KEYS,'QUEUE_SET');q={k:queue_audit(q_a[k],q_b[k]) for k in cfg};barea={k:IndependentArea(q_b[k]) for k in cfg};w=collections.defaultdict(dict)
 for x in csvrows(d/'wire.csv'):
  k,t,u,b=map(int,(x['link'],x['time_ns'],x['uid'],x['bytes']));e=x['event'];need(k in KEYS and 0<=t<=END and b>0 and e in ('TX','RX','ERROR'),'WIRE_VALUE');k2=(u,e);need(k2 not in w[k],'WIRE_DUP');w[k][k2]=(t,b)
 errors=eligible=0
 for k in KEYS:
  rs=w[k];tx={u:x for (u,e),x in rs.items() if e=='TX'};rx={u:x for (u,e),x in rs.items() if e=='RX'};er={u:x for (u,e),x in rs.items() if e=='ERROR'};need(not(set(rx)&set(er)) and set(tx)==set(rx)|set(er),'WIRE_ACCOUNTING');need(not er or k==target and loss>0,'UNAUTHORIZED_RX_ERROR');bps=int(cfg[k]['rate_bps']);prop=int(cfg[k]['delay_ns'])
  for u,(t,b) in tx.items():
   t2,b2=(rx if u in rx else er)[u];need(b==b2 and abs(Fraction(t2-t-prop)-Fraction(b*8*10**9,bps))<=2,'ACTUAL_PROPAGATION_OR_SERVICE')
  if k==target:eligible=len(tx);errors=len(er)
  need(tx==q[k]['deq'],'WIRE_DEQUEUE_MATCH')
 need(eligible>0 and (loss>0 or errors==0),'LOSS_FIDELITY')
 bg=csvrows(d/'background.csv');need([int(x['time_ns']) for x in bg]==background_times(rate) and len({int(x['uid']) for x in bg})==len(bg),'OFFERED_TIME');bgok=0;drop_set=set(q[target]['drops'])
 for x in bg:
  t,u=int(x['time_ns']),int(x['uid']);ok=int(x['accepted']);need(ok in (0,1),'SEND_FLAG');need((q[target]['enq'].get(u)==(t,1200) and u in q[target]['deq']) if ok else ((t,u) in drop_set and u not in q[target]['enq']),'BACKGROUND_SHARED_QUEUE_WIRE_SIZE');bgok+=ok
 need(bgok>0 and bool(q[target]['wait']),'TARGET_ENGINEERING')
 dcs=jsrows(d/'events.jsonl.decisions.jsonl');raw=jsrows(d/'events.jsonl');need(len(dcs)==126 and raw[-1]['event_type']=='SIMULATION_END','PIT_RECORDER');need(all(int(a['event_seq'])<int(b['event_seq']) and int(a['time_ns'])<=int(b['time_ns']) for a,b in zip(raw,raw[1:])),'PIT_ORDER');tx=[x for x in raw if x['event_type']=='TX_INTEREST'];need(len(tx)==126,'ACTUAL_TX_COUNT');byname=collections.defaultdict(list)
 for x in raw:byname[x['name']].append(x)
 app=csvrows(d/'probe.csv');need([(x['name'],int(x['time_ns'])) for x in app if x['event']=='SEND']==[(f'/hcraf/pilot/{i}',t) for i,t,k,*c in s],'ACTUAL_PROBE_SCHEDULE');app_by=collections.defaultdict(list)
 for x in app:app_by[x['name']].append(x)
 prod=csvrows(d/'producer.csv');need(len({x['name'] for x in prod})==len(prod) and all(x['name']==f'/hcraf/pilot/{int(x["name"].rsplit("/",1)[-1])}' and 0<=int(x['name'].rsplit('/',1)[-1])<126 and int(x['node'])==8+s[int(x['name'].rsplit('/',1)[-1])][2] for x in prod),'PRODUCER_ROUTE');prod_names={x['name'] for x in prod}
 ev=csvrows(d/'local_events.csv');need(all(int(x['ordinal'])==i+1 and int(x['kind']) in (0,3,5) and int(x['face'])>0 for i,x in enumerate(ev)) and all(int(a['time_ns'])<=int(b['time_ns']) for a,b in zip(ev,ev[1:])),'NATIVE_EVENT_ORDER')
 need([(x['name'],int(x['time_ns']),int(x['face'])) for x in ev if int(x['kind'])==3]==[(x['name'],x['time_ns'],x['face_id']) for x in tx],'NATIVE_TX_MATCH');need(len([x for x in ev if int(x['kind'])==0])==126,'NATIVE_RX_COUNT')
 success={(x['name'],x['face_id'],x['time_ns']) for x in raw if x['event_type']=='PIT_SATISFIED'};samples=set();sent={}
 for e in ev:
  k=int(e['kind']);key=e['name'],int(e['face']);t=int(e['time_ns']);sample=int(e['sample_ns'])
  if k==3:need(key not in sent and sample==0,'DUP_NATIVE_TX');sent[key]=t
  if k==5:need(key in sent and 0<sample<=1000000000 and sample==t-sent[key] and (*key,t) in success,'RTT_SUCCESS_WITNESS');samples.add((*key,t));del sent[key]
 need(samples==success,'ALL_SUCCESS_SAMPLES');fs=csvrows(d/'features.csv');need(len(fs)==378,'FEATURE_ROWS');over=csvrows(d/'overhead.csv');need(len(over)==3 and {int(x['slot']) for x in over}=={0,1,2},'OVERHEAD_SET');ov={int(x['slot']):x for x in over}
 for a in range(3):
  v=ov[a];need(int(v['updates'])==len(q[12+3*a]['enq'])+len(q[12+3*a]['deq']) and 1<=int(v['peak'])<=500000 and int(v['event_payload_bytes'])>0 and int(v['hard_limit'])==500000,'OVERHEAD_BOUND')
 outcomes=collections.Counter();classes=collections.Counter();target_classes=collections.Counter();pits=set();candidate=[]
 for i,t,k,*costs in s:
  dc=dcs[i];x=tx[i];nm=f'/hcraf/pilot/{i}';f=faces[k];pit=int(dc['pit_instance_id']);need(pit>0 and pit not in pits,'PIT_ID');pits.add(pit);need(dc['decision_id']==x['decision_id']==i+1 and dc['time_ns']==x['time_ns']==t and dc['name']==x['name']==nm and x['pit_instance_id']==pit and x['face_id']==f,'ACTUAL_FACE_PIT_TIME');ranks={c['face_id']:c['routing_cost'] for c in dc['candidates']};need(ranks==dict(zip(faces,costs)),'ACTUAL_FIB_COSTS')
  fin=[a for a in byname[nm] if a['event_type']=='PIT_FINALIZE' and a['pit_instance_id']==pit];need(len(fin)==1 and fin[0]['time_ns']>=t,'TERMINAL_PIT');sat=[a for a in byname[nm] if a['event_type']=='PIT_SATISFIED' and a['pit_instance_id']==pit];data=[a for a in app_by[nm] if a['event']=='DATA'];nack=[a for a in app_by[nm] if a['event']=='NACK'];need(len(data)<=1 and len(nack)<=1 and not(data and nack),'TERMINAL_APP')
  if sat:need(len(sat)==1 and sat[0]['face_id']==f and len(data)==1 and not nack and fin[0]['reason']==1 and nm in prod_names,'SUCCESS_WITNESS');outcome='SUCCESS'
  elif nack:need(not data and any(a['event_type']=='RX_NACK' and a['face_id']==f for a in byname[nm]),'NACK_WITNESS');outcome='NACK'
  else:need(not data and fin[0]['time_ns']>=t+1000000000,'TIMEOUT_OR_UNCLASSIFIED');outcome='TIMEOUT'
  outcomes[outcome]+=1
  for a in range(3):
   v=fs[i*3+a];need((int(v['decision_id']),int(v['time_ns']),int(v['slot']),int(v['face']))==(i+1,t,a,faces[a]),'FEATURE_ALIGNMENT');o=int(v['ordinal']);need(0<=o<=len(ev) and all(int(e['time_ns'])<=t for e in ev[:o]) and (o==len(ev) or int(ev[o]['time_ns'])>=t),'CAUSAL_ORDINAL');need(any(int(e['kind'])==0 and e['name']==nm for e in ev[:o]) and not any(int(e['kind'])==3 and e['name']==nm for e in ev[:o]),'BEFORE_ACTUAL_TX');rt=0;missing=1
   for e in ev[:o]:
    if int(e['kind'])==5 and int(e['face'])==faces[a]:sample=int(e['sample_ns']);rt=sample if missing else round5(4*rt+sample);missing=0
   area=window_area(q[12+3*a]['states'],t-H,t);need(area==barea[12+3*a].area(t-H,t)==int(v['area']),'LOCAL_CAUSAL_AREA');need(int(v['g'])==int(4*area>=32*H) and int(v['rank'])==costs[a] and int(v['srtt_ns'])==rt and int(v['missing'])==missing,'LOCAL_FEATURE_REPLAY');need(1<=int(v['retained'])<=int(ov[a]['peak'])<=500000 and 0<=int(v['ops'])<=int(v['retained']),'LOCAL_STATE_BOUND')
  keys=[3*k+h for h in range(3)]+[12+3*k+h for h in range(3)]
  aa=[window_area(q[z]['states'],t-H,t) for z in keys];bb=[window_area(q[z]['states'],t,t+H) for z in keys];need(aa==[barea[z].area(t-H,t) for z in keys] and bb==[barea[z].area(t,t+H) for z in keys],'SIX_QUEUE_AREA_CROSSCHECK');cur,fut=max(aa),max(bb);y=int(4*fut>=32*H);classes[y]+=1
  if k==slot:target_classes[y]+=1
  v=fs[i*3+k];candidate.append(dict(decision_id=i+1,time_ns=t,slot=k,face=f,pit_instance_id=pit,outcome=outcome,rc=costs[k],srtt_ns=None if int(v['missing']) else int(v['srtt_ns']),g=int(v['g']),current_queue_area_packet_ns=cur,future_queue_area_packet_ns=fut,candidate_future_class=y))
 need(len(candidate)==126 and sum(target_classes.values())==42,'CANDIDATE_COUNT');write(d/'candidate_reference.json',candidate)
 ret=dict(case=r,decisions=126,all_candidate_feature_rows=378,reference_rows=126,receiver_errors=errors,eligible_receiver_packets=eligible,mean_target_queue_wait_ns=sum(q[target]['wait'])/len(q[target]['wait']),queue_drops=len(q[target]['drops']),target_positive=target_classes[1],all_positive=classes[1],g_positive=sum(x['g'] for x in candidate),srtt_nonmissing=sum(x['srtt_ns'] is not None for x in candidate),outcomes=dict(outcomes),status='PASS_P12R66_CASE_ENGINEERING_ONLY',**LOCKS)
 ret['files']={p.name:digest(p) for p in sorted(d.iterdir()) if p.is_file()};write(d/'case_receipt.json',ret);return ret,candidate

def quantile7(values,num,den):
 v=sorted(values);need(bool(v) and 0<=num<=den and den>0,'QUANTILE');i,rem=divmod((len(v)-1)*num,den);return Fraction(v[i]*(den-rem)+v[min(i+1,len(v)-1)]*rem,den)
def gate(rc,records,partition):
 n=3 if partition=='pilot' else 12;need(len(rc)==n*10 and len(records)==n*10*126,'PARTITION_TOTALS');seeds=sorted({int(r['case']['seed']) for r in rc});need(len(seeds)==n,'SEEDS');need({x['rc'] for x in records}=={10,20,30},'RC_SUPPORT');
 if partition=='development':need(sum(r['srtt_nonmissing'] for r in rc)*10>=len(records)*9,'SRTT_POOLED')
 for r in rc:
  if r['case']['arm'] in 'BE':
   need(0<r['all_positive']<126,'PRIMARY_MIXED')
   if partition=='development':need(r['srtt_nonmissing']*5>=126*4,'PRIMARY_SRTT')
 for seed in seeds:
  rr=[r for r in rc if int(r['case']['seed'])==seed and r['case']['site']=='local_forward' and r['case']['arm'] in 'BE'];need(len(rr)==2 and 0<sum(r['g_positive'] for r in rr)<252,'LOCAL_G_VARIATION')
 for arm in 'CE':
  rr=[r for r in rc if r['case']['arm']==arm];ratio=Fraction(sum(r['receiver_errors'] for r in rr),sum(r['eligible_receiver_packets'] for r in rr));need(Fraction(5,1000)<=ratio<=Fraction(5,100),'POOLED_LOSS')
 return dict(status='PASS_PARTITION_ENGINEERING_ONLY',partition=partition,cases=len(rc),decisions=len(records),all_candidate_feature_rows=3*len(records),seeds=seeds,srtt_nonmissing=sum(r['srtt_nonmissing'] for r in rc),rc_support=[10,20,30],**LOCKS)

def verify_partition(path,expected):
 r=json.loads((path/'PARTITION_RECEIPT.json').read_text());need(r['partition']==expected and r['status']=='PASS_PARTITION_ENGINEERING_ONLY' and all(r[k]==v for k,v in LOCKS.items()),'PARTITION_LOCK');need(len(r['case_receipt_hashes'])==(30 if expected=='pilot' else 120),'CASE_COUNT');need(set(r['case_receipt_hashes'])=={str(p.relative_to(path)) for p in path.rglob('case_receipt.json')},'CASE_SET')
 for n,h in r['case_receipt_hashes'].items():
  need(not P(n).is_absolute() and '..' not in P(n).parts,'CASE_PATH');p=path/n;need(digest(p)==h,'CASE_SEAL');c=json.loads(p.read_text());need(c['case']['partition']==expected and c['status']=='PASS_P12R66_CASE_ENGINEERING_ONLY' and all(c[k]==v for k,v in LOCKS.items()) and c['decisions']==126 and c['all_candidate_feature_rows']==378,'CASE_GATE');need(all(P(k).name==k for k in c['files']),'RAW_PATH');need(set(c['files'])=={q.name for q in p.parent.iterdir() if q.is_file() and q.name!='case_receipt.json'},'RAW_SET');need(all(digest(p.parent/k)==v for k,v in c['files'].items()),'RAW_SEAL')
 return r

def run(args):
 need(args.partition=='pilot' or args.pilot is not None,'PILOT_REQUIRED')
 if args.partition=='development':verify_partition(args.pilot,'pilot')
 cases,sch,hashes=read_prereg(args.prereg,args.partition);need(not args.out.exists(),'REFUSE_OVERWRITE');args.out.mkdir(parents=True);rc=[];records=[]
 for r in cases:
  s=sch[int(r['seed']),r['site']];d=(args.out/r['seed']/r['site']/r['arm']).resolve();d.mkdir(parents=True);schedule=d/'schedule.csv'
  with schedule.open('w',newline='') as f:w=csv.writer(f,lineterminator='\n');w.writerow(('decision_index','decision_ns','selected_slot','cost_slot0','cost_slot1','cost_slot2'));w.writerows(s)
  opts={'run':r['seed'],'site':r['site'],'arm':r['arm'],'output':d,'schedule':schedule,'target':r['target_slot'],'rate':r['background_mbps'],'loss':r['error_ppm'],'delay':r['extra_propagation_ms'],'trafficStream':r['traffic_stream'],'errorStream':r['error_stream'],'streamBase':r['stream_base']};cmd=BIN+' '+' '.join('--%s=%s'%x for x in opts.items());(d/'command.txt').write_text(cmd+'\n')
  with (d/'simulator.log').open('w') as f:subprocess.run(['python3','./waf','--run-no-build',cmd],cwd=str(args.ns3),stdout=f,stderr=subprocess.STDOUT,check=True)
  receipt,rows=audit_case(r,s,d);rc.append(receipt);records.extend(rows);print('PASS_DIRECT_COST_CASE',r['seed'],r['site'],r['arm'],flush=True)
 result=gate(rc,records,args.partition);result.update(prereg_files=hashes,case_receipt_hashes={str(p.relative_to(args.out)):digest(p) for p in sorted(args.out.rglob('case_receipt.json'))},AP_computed=False,model_fits=0,confirmation_cases=0,official_F3_labels_constructed=0)
 if args.partition=='development':
  values=[x['srtt_ns'] for x in records if x['srtt_ns'] is not None];lo,hi=quantile7(values,1,100),quantile7(values,99,100);need(hi>lo,'SRTT_DEGENERATE');norm=dict(status='FROZEN_DEV_NORMALIZATION_ONLY',rc_min=10,rc_max=30,srtt_p1_ns=[lo.numerator,lo.denominator],srtt_p99_ns=[hi.numerator,hi.denominator],missing_normalized=1,training_rows=len(records),nonmissing=len(values),**LOCKS);write(args.out/'NORMALIZATION.json',norm);result['normalization_sha256']=digest(args.out/'NORMALIZATION.json');result['pilot_receipt_sha256']=digest(args.pilot/'PARTITION_RECEIPT.json')
 write(args.out/'PARTITION_RECEIPT.json',result);verify_partition(args.out,args.partition);print(STATUS if args.partition=='development' else 'PASS_P12R66_PILOT_ENGINEERING_ONLY',flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--prereg',required=True,type=P);p.add_argument('--ns3',required=True,type=P);p.add_argument('--out',required=True,type=P);p.add_argument('--partition',required=True,choices=['pilot','development']);p.add_argument('--pilot',type=P);run(p.parse_args())
