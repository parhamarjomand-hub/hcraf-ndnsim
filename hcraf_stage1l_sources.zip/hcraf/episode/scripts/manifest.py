#!/usr/bin/env python3
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
from datetime import datetime, timezone
root=Path(sys.argv[1]).resolve()
out=root/'episode_output'
out.mkdir(exist_ok=True)
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
try:
    revision=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()
except (OSError,subprocess.CalledProcessError): revision=os.environ.get('GITHUB_SHA')
files={str(p.relative_to(out)):digest(p) for p in sorted(out.rglob('*'))
       if p.is_file() and p.name!='manifest.json'}
code={str(p.relative_to(root)):digest(p) for p in sorted((root/'hcraf/episode').rglob('*'))
      if p.is_file() and '__pycache__' not in p.parts}
workflow=root/'.github/workflows/hcraf-stage1l.yml'
if workflow.exists(): code[str(workflow.relative_to(root))]=digest(workflow)
report=dict(schema_version='0.2',created_at_utc=datetime.now(timezone.utc).isoformat(),
    purpose='CONTROLLED_INSTRUMENTATION_PILOT_NOT_THESIS_DATASET',
    git_commit=revision,github_run_id=os.environ.get('GITHUB_RUN_ID'),
    github_run_attempt=os.environ.get('GITHUB_RUN_ATTEMPT'),
    python=platform.python_version(),artifact_sha256=files,code_sha256=code,
    environment_fully_locked=False,
    limitation='Source revisions are pinned; apt repository state and container digest are not locked.')
(out/'manifest.json').write_text(json.dumps(report,indent=2)+'\n')
