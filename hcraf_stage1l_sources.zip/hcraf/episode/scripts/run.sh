#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK_DIR="$PROJECT_DIR/hcraf/episode"
OUTPUT_DIR="$PROJECT_DIR/episode_output"
cd "$PROJECT_DIR/episode_sources/ns-3"
status=0
for policy in add-on single; do
  probabilities="0 0.05 1"
  verifier=verify_collection.py
  if [[ "$policy" == single ]]; then probabilities="0 0.05 0.5 1"; verifier=verify_selection.py; fi
  for mode in control receive-outage; do
    for probability in $probabilities; do
      for repetition in 1 2; do
        folder="$OUTPUT_DIR/$policy/$mode-p$probability/repeat-$repetition"
        mkdir -p "$folder"
        command="hcraf-episode-pilot --collectionMode=$policy --mode=$mode --probeProbability=$probability --output=$folder --seed=17 --run=1001"
        printf '%s\n' "$command" > "$folder/command.txt"
        if ! python3 ./waf --run-no-build "$command" 2>&1 | tee "$folder/simulator.log"; then status=1; continue; fi
        if ! python3 "$TASK_DIR/scripts/episodes.py" "$folder" --run-id "$mode-p$probability-seed17-run1001"; then status=1; continue; fi
        if ! python3 "$TASK_DIR/scripts/$verifier" "$folder"; then status=1; fi
      done
    done
  done
done
if ! python3 "$TASK_DIR/scripts/compare_selection.py" "$OUTPUT_DIR"; then status=1; fi
exit "$status"
