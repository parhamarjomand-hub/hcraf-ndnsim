"""Frozen before development execution: exact v05254 development-only SGD."""
import pathlib as pl,sys,math,random,json,collections,hashlib,csv
import pilot_audit as a
from reference_contract import BASE,FULL,LOCKS
P=pl.Path; SEEDS=list(range(620101,620113)); BASE_IDX=[FULL.index(k) for k in BASE]; SHUFFLE=620100+521000

def fit(X,y,names):
 n=len(y);d=len(names);a.need(n==len(X) and n>0 and all(len(x)==d for x in X) and 0<sum(y)<n,'FIT_SHAPE_CLASSES')
 means=[sum(row[j] for row in X)/n for j in range(d)]
 sds=[max(1e-10,math.sqrt(sum((row[j]-means[j])**2 for row in X)/n)) for j in range(d)]
 xx=[[max(-5.,min(5.,(v-mu)/sd)) for v,mu,sd in zip(row,means,sds)] for row in X]
 w=[0.]*d;b=math.log((sum(y)+.5)/(n-sum(y)+.5));rng=random.Random(SHUFFLE)
 for epoch in range(24):
  order=list(range(n));rng.shuffle(order);lr=.035/(1+.08*epoch)
  for i in order:
   v=xx[i];z=b+sum(x*c for x,c in zip(w,v));prob=1/(1+math.exp(-z)) if z>=0 else math.exp(z)/(1+math.exp(z));error=prob-y[i];b-=lr*error
   for j,x in enumerate(v):w[j]-=lr*(error*x+.0005*w[j])
 a.need(all(math.isfinite(v) for v in means+sds+w+[b]),'NONFINITE')
 return dict(names=list(names),means=means,sds=sds,weights=w,intercept=b)

def load(prereg,root):
 cases,ss,hashes=a.read_prereg(prereg);r=json.loads((root/'DEV_RECEIPT.json').read_text());a.need(r['status']==a.STATUS and r['prereg_files']==hashes and r['cases']==180 and r['decisions']==22680 and r['all_candidate_feature_rows']==68040 and r['model_fits']==0 and r['confirmation_cases']==0 and not r['new_AP_computed'] and all(r[k]==v for k,v in LOCKS.items()),'DEV_RECEIPT')
 expected={str(P(c['seed'],c['site'],c['arm'],'case_receipt.json')) for c in cases};a.need(set(r['case_receipt_hashes'])==expected=={str(x.relative_to(root)) for x in root.rglob('case_receipt.json')},'DEV_CASE_SET')
 X=[];y=[];stats=[];keys=[];raw_count=0
 for c in sorted(cases,key=lambda c:(int(c['seed']),c['site'],c['arm'])):
  d=root/c['seed']/c['site']/c['arm'];f=d/'case_receipt.json';a.need(a.digest(f)==r['case_receipt_hashes'][str(f.relative_to(root))],'CASE_SHA');rc=json.loads(f.read_text());a.need(rc['case']==c and rc['status']=='PASS_DEV_CASE_ENGINEERING_ONLY' and rc['decisions']==126 and rc['all_candidate_feature_rows']==378 and all(rc[k]==v for k,v in LOCKS.items()),'CASE_RECEIPT')
  a.need(set(rc['files'])=={x.name for x in d.iterdir() if x.is_file() and x.name!='case_receipt.json'},'RAW_SET')
  for n,h in rc['files'].items():a.need(P(n).name==n and a.digest(d/n)==h,'RAW_HASH');raw_count+=1
  fs=a.csvrows(d/'features.csv');ys=json.loads((d/'dev_candidate_reference.json').read_text());s=ss[int(c['seed']),c['site']];a.need(len(fs)==378 and len(ys)==126,'ROW_COUNT');p=tp=0
  for i,t,k in s:
   q=ys[i];v=fs[i*3+k];a.need((q['decision_id'],q['time_ns'],q['slot'])==(i+1,t,k)==(int(v['decision_id']),int(v['time_ns']),int(v['slot'])) and q['face']==int(v['face']),'SELECTED_ALIGNMENT');b=q['future_queue_area_packet_ns'];label=int(4*b>=32*a.H);a.need(type(b) is int and 0<=b<=32*a.H and q['candidate_future_class']==label,'LABEL');x=[float(v[n]) for n in a.FEATURES];a.need(len(x)==12 and all(math.isfinite(z) for z in x),'FEATURES');X.append(x);y.append(label);keys.append((int(c['seed']),c['site'],c['arm'],i+1));p+=label;tp+=label if k==int(c['target_slot']) else 0
  a.need(p==rc['all_positive'] and tp==rc['target_positive'],'CLASS_RECEIPT');stats.append(dict(seed=int(c['seed']),site=c['site'],arm=c['arm'],target_positive=tp,all_positive=p,mean_target_queue_wait_ns=rc['mean_target_queue_wait_ns'],queue_drops=rc['queue_drops'],receiver_errors=rc['receiver_errors'],eligible_receiver_packets=rc['eligible_receiver_packets']))
 a.need(len(X)==22680 and keys==sorted(keys) and len(set(keys))==22680 and set(k[0] for k in keys)==set(SEEDS) and 0<sum(y)<len(y),'DEV_ALL_ROWS');return X,y,stats,raw_count

def freeze(prereg,root,out):
 a.need(sys.version_info[:3]==(3,13,5),'EXACT_PYTHON');a.need(not out.exists(),'NO_OVERWRITE');X,y,stats,count=load(prereg,root)
 # Descriptive dev contrasts; no confirmatory inference, model selection, AP or bootstrap.
 lookup={(x['seed'],x['site'],x['arm']):x for x in stats};contrasts={}
 for high,low in [('B','A'),('E','C'),('C','A'),('D','A')]:
  ds=[];wait=[]
  for seed in SEEDS:
   pairs=[(lookup[seed,s,high],lookup[seed,s,low]) for s in a.SITES];ds.append(sum(x['target_positive']-z['target_positive'] for x,z in pairs)/126);wait.append(sum(x['mean_target_queue_wait_ns']-z['mean_target_queue_wait_ns'] for x,z in pairs)/3)
  contrasts[high+'-'+low]=dict(mean_future_positive_fraction_difference=sum(ds)/12,positive_seed_count=sum(d>0 for d in ds),positive_wait_seed_count=sum(d>0 for d in wait),seed_differences=ds)
 B0=fit([[x[j] for j in BASE_IDX] for x in X],y,BASE);B1=fit(X,y,FULL);a.need(B0['means']==[B1['means'][j] for j in BASE_IDX] and B0['sds']==[B1['sds'][j] for j in BASE_IDX],'COMMON_SCALE');out.mkdir();m=dict(B0=B0,B1=B1,training_seeds=SEEDS,training_rows=len(y),training_positives=sum(y),source_dev_receipt_sha256=a.digest(root/'DEV_RECEIPT.json'),fit_code_sha256=a.digest(P(__file__)),shuffle_seed=SHUFFLE,shuffle_rule='separate identically initialized persistent CPython Random per model; fresh index list each epoch; sorted (seed, site, arm, numeric decision_id)',python_version=sys.version.split()[0],**LOCKS);a.write(out/'FROZEN_MODELS.json',m);a.write(out/'DEV_PHYSICAL_DESCRIPTIVE.json',dict(contrasts=contrasts,cases=stats,interpretation='development descriptive only, not construct validation'));a.write(out/'FREEZE_RECEIPT.json',dict(status='PASS_P12R_NEW_CONSTRUCT_DEV_MODELS_FROZEN_ONLY_NO_F3_RELEASE',model_fits=2,construct_validated=False,confirmation_execution_authorized=False,confirmation_rows_read=0,pilot_rows_used_for_fit=0,heldout_rows_read=0,new_AP_computed=False,new_bootstrap_computed=False,official_F3_labels_constructed=0,raw_files_verified=count,training_rows=len(y),training_positives=sum(y),source_dev_receipt_sha256=m['source_dev_receipt_sha256'],fit_code_sha256=m['fit_code_sha256'],files={n:a.digest(out/n) for n in ('FROZEN_MODELS.json','DEV_PHYSICAL_DESCRIPTIVE.json')},**LOCKS));print('PASS_P12R_NEW_CONSTRUCT_DEV_MODELS_FROZEN_ONLY_NO_F3_RELEASE')
if __name__=='__main__':freeze(*map(P,sys.argv[1:]))
