import sys,pathlib,json,zipfile,tempfile,shutil
P=pathlib.Path; sys.path.insert(0,str(P(__file__).resolve().parent.parent/'p12r56'))
import pilot_audit as a
SHA='0bc9ef3f1c285f9e10880bfb754e6ba836a61c84c81edddc849c7f0117a9911d'
def verify(prereg,pilot,out):
 a.need(a.digest(pilot)==SHA,'PILOT_ZIP_SHA');cases,ss,hashes=a.read_prereg(prereg)
 with tempfile.TemporaryDirectory() as tmp,zipfile.ZipFile(pilot) as z:
  a.need(z.testzip() is None and len(z.namelist())==len(set(z.namelist())),'PILOT_CRC');prefix='p12r56_pilot/';r=json.loads(z.read(prefix+'PILOT_RECEIPT.json'));a.need(r['status']==a.STATUS and r['prereg_files']==hashes and all(r[k]==v for k,v in a.LOCKS.items()) and r['cases']==45 and r['decisions']==5670 and not r['pilot_rows_trainable'] and r['model_fits']==0,'PILOT_RECEIPT')
  expected={str(P(c['seed'],c['site'],c['arm'],'case_receipt.json')) for c in cases};a.need(set(r['case_receipt_hashes'])==expected,'CASE_SET');raw_count=0;pos=0
  for c in cases:
   key=str(P(c['seed'],c['site'],c['arm']));name=key+'/case_receipt.json';b=z.read(prefix+name);a.need(a.sha(b)==r['case_receipt_hashes'][name],'RECEIPT_HASH');rc=json.loads(b);a.need(rc['case']==c and rc['status']=='PASS_PILOT_CASE_ENGINEERING_ONLY','CASE');d=P(tmp)/'case';d.mkdir();files=rc['files'];a.need({n[len(prefix+key+'/'):] for n in z.namelist() if n.startswith(prefix+key+'/')}==set(files)|{'case_receipt.json'},'FILE_SET')
   for n,h in files.items():
    a.need(P(n).name==n,'PATH');raw=z.read(prefix+key+'/'+n);a.need(a.sha(raw)==h,'FILE_SHA');(d/n).write_bytes(raw)
   replay=a.audit_case(c,ss[int(c['seed']),c['site']],d);a.need(replay==rc,'REPLAY_RECEIPT');raw_count+=len(files);pos+=rc['all_positive'];shutil.rmtree(d);print('PASS_PILOT_REPLAY',key,flush=True)
  a.need(0<pos<5670,'VARIATION');a.write(out,dict(status='PASS_INDEPENDENT_PILOT_REPLAY_ONLY',pilot_zip_sha256=SHA,cases=45,decisions=5670,files_verified=raw_count,positive_candidates=pos,pilot_rows_trainable=False,**a.LOCKS))
if __name__=='__main__':verify(*map(P,sys.argv[1:]))
