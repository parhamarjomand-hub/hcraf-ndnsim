import unittest,os,pathlib,math,random
import pilot_audit as a
from freeze_dev import fit,BASE_IDX,SHUFFLE
class TestDev(unittest.TestCase):
 def test_partition(self):
  c,s,h=a.read_prereg(pathlib.Path(os.environ['P12R56_PREREG']));self.assertEqual(len(c),180);self.assertEqual(len(s),36);self.assertEqual(set(int(x['seed']) for x in c),set(range(620101,620113)));self.assertTrue(all(x['partition']=='development' for x in c));self.assertEqual(sum(len(x) for x in s.values())*5,22680)
 def test_baseline(self):self.assertEqual(BASE_IDX,[2,4,5,6,8,10,11]);self.assertEqual(SHUFFLE,1141100)
 def test_fixed_fit(self):
  x=[[0.,1.],[1.,1.],[2.,1.],[3.,1.]];y=[0,0,1,1];m=fit(x,y,['a','b']);self.assertEqual(m,fit(x,y,['a','b']));self.assertEqual(m['weights'][1],0.);self.assertEqual(m['sds'][1],1e-10);self.assertGreater(m['weights'][0],0)
 def test_reject_one_class(self):
  with self.assertRaises(RuntimeError):fit([[0.],[1.]],[0,0],['a'])
 def test_shape(self):
  with self.assertRaises(RuntimeError):fit([[0.]],[0,1],['a'])
if __name__=='__main__':unittest.main()
