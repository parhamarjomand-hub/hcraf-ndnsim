#!/usr/bin/env python3
"""v0.52.56 prospective engineering-only pilot. No AP or fitting."""
import argparse,csv,hashlib,io,json,math,pathlib,subprocess,zipfile,collections,os,bisect
from fractions import Fraction
from reference_contract import reference, matrix, LOCKS, SITES, ARMS
P=pathlib.Path; H=75_000_000; END=20_000_000_000
PREREG_SHA='746889957c3d91523fa937e7a888cef4e50d847c8596760f6b833ccdafe28ab2'
PREREG_COMMIT='cd3c1c87351497e3be1093bf81c156bbc273c08f'
PRIOR='NO_GO_P12R_CONFIRMATORY_STATISTICAL_GATES_NOT_MET'
STATUS='PASS_P12R_NEW_CONSTRUCT_PILOT_ENGINEERING_ONLY_NO_F3_RELEASE'
BIN='hcraf-stage1am-f3-p12r-new-construct-pilot-v05256'
FEATURES='rank packets fraction up pit interest_rx data_rx nack_rx interest_tx interest_drop rtt missing'.split()

def need(ok,msg):
 if not ok:raise RuntimeError('P12R56_'+msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def write(p,obj):p.write_text(json.dumps(obj,sort_keys=True,indent=2,allow_nan=False)+'\n')
def csvrows(p):
 with p.open(newline='') as f:return list(csv.DictReader(f))
def jsrows(p):return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]
def read_prereg(p):
 need(digest(p)==PREREG_SHA,'PREREG_ZIP_SHA')
 with zipfile.ZipFile(p) as z:
  need(z.testzip() is None and len(z.namelist())==len(set(z.namelist())),'PREREG_CRC');r=json.loads(z.read('p12r_prereg/PREREG_RECEIPT.json'))
  need(r['status']=='PASS_P12R_NEW_CONSTRUCT_PREREG_ONLY_NO_EXECUTION_NO_RELEASE' and r['parent_scientific_status']==PRIOR and all(r[k]==v for k,v in LOCKS.items()) and r['simulations']==0 and not r['construct_validated'],'PARENT_LOCKS')
  b={k:z.read('p12r_prereg/'+k) for k in ('LOCKED_MATRIX.csv','LOCKED_PROBE_SCHEDULE.csv','PLAN.json')};need({k:sha(v) for k,v in b.items()}==r['files'],'PREREG_MEMBER_SHA')
 def read(k):return list(csv.DictReader(io.StringIO(b[k].decode())))
 rr,ss=read('LOCKED_MATRIX.csv'),read('LOCKED_PROBE_SCHEDULE.csv');exp,exp_s=matrix()
 need([tuple(str(x) for x in a) for a in exp]==[tuple(a.values()) for a in rr] and [tuple(str(x) for x in a) for a in exp_s]==[tuple(a.values()) for a in ss],'MATRIX_REPRODUCTION')
 cases=[a for a in rr if a['partition']=='pilot'];schedules=collections.defaultdict(list)
 for a in ss:
  if a['partition']=='pilot':schedules[int(a['seed']),a['site']].append((int(a['decision_index']),int(a['decision_ns']),int(a['selected_slot'])))
 need(len(cases)==45 and len(schedules)==9 and all(len(v)==126 for v in schedules.values()),'PILOT_CASES')
 return cases,schedules,r['files']
def queue_audit(a,b):
 need(a and b and a[0]['event']==b[0]['event']=='INITIAL' and a[-1]['event']==b[-1]['event']=='FINAL','TRACE_BOUNDS')
 need(int(a[0]['time_ns'])==int(b[0]['time_ns'])==0 and int(a[-1]['time_ns'])==int(b[-1]['time_ns'])==END,'TRACE_COVERAGE')
 q=0;pending={};changes=[];drops=[];states=[(0,0,0)];wait=[];enq={};deq={};last=0
 for i,e in enumerate(a[1:-1],1):
  t,u,n,bs,w=map(int,(e['time_ns'],e['uid'],e['packets'],e['bytes'],e['wait_ns']));k=e['event'];need(last<=t<=END and 0<=n<=32 and bs>0,'QUEUE_VALUE');last=t
  if k=='ENQUEUE':
   need(n==q+1 and u not in pending,'ENQUEUE');pending[u]=(t,bs);enq[u]=(t,bs);changes.append((t,q,n))
  elif k=='DEQUEUE':
   need(n==q-1 and u in pending and pending[u]==(t-w,bs) and w>=0,'DEQUEUE');del pending[u];deq[u]=(t,bs);wait.append(w);changes.append((t,q,n))
  elif k=='DROP':need(n==q==32 and u not in pending,'DROP_NOT_FULL');drops.append((t,u))
  else:raise RuntimeError('UNKNOWN_QUEUE_EVENT')
  states.append((t,i,n));q=n
 need(not pending and q==int(a[-1]['packets'])==int(b[-1]['new'])==0,'DRAIN');need(int(a[0]['packets'])==int(b[0]['new'])==0,'INITIAL_EMPTY');need(all(int(x['time_ns'])<=int(y['time_ns']) for x,y in zip(b,b[1:])),'B_ORDER')
 need(changes==[(int(e['time_ns']),int(e['old']),int(e['new'])) for e in b[1:-1] if e['event']=='CHANGE'],'LENGTH_WITNESS');need(drops==[(int(e['time_ns']),int(e['uid'])) for e in b[1:-1] if e['event']=='MAC_DROP'],'DROP_WITNESS');need(len(b)==len(changes)+len(drops)+2,'UNKNOWN_B_EVENT')
 states.append((END,len(a),0));return dict(states=states,drops=drops,enq=enq,deq=deq,wait=wait)

def background_times(rate):return [1_000_000_000+p*1_000_000_000+k*9_600_000_000_000//(rate*1_000_000) for p in range(18) for k in range((500_000_000*rate*1_000_000+9_600_000_000_000-1)//9_600_000_000_000) if k*9_600_000_000_000//(rate*1_000_000)<500_000_000]
def window_area(states,t0,t1):
 # Linear-area prefix with bisect, independent from the prereg reference implementation.
 times=[r[0] for r in states];i=bisect.bisect_right(times,t0)-1;need(i>=0 and t1<=times[-1] and t0<t1,'WINDOW_COVERAGE');last=t0;q=states[i][2];area=0
 for t,_,n in states[i+1:]:
  if t>=t1:break
  area+=(t-last)*q;last=t;q=n
 return area+(t1-last)*q

def audit_case(r,s,d):
 seed,slot,rate,loss,delay=[int(r[k]) for k in ('seed','target_slot','background_mbps','loss_ppm','added_propagation_ms')];site=r['site'];j={'relay_return':0,'transit_middle':1,'producer_egress':2}[site];target=3*slot+j
 cfg={int(x['queue']):x for x in csvrows(d/'devices.csv')};need(len(cfg)==12 and set(cfg)==set(range(12)),'DEVICE_COUNT');faces=[]
 for k in range(12):
  e=cfg[k];need(int(e['capacity'])==32 and int(e['rate_bps'])==(12000000 if k==target else 50000000),'RATE_CAP');expected_delay=2+(delay if k==target or (j==0 and k==9+slot) else 0);need(int(e['delay_ns'])==expected_delay*1000000,'CHANNEL_DELAY');
  if k>=9:need(int(e['sender'])==1 and int(e['receiver'])==2+k-9,'LOCAL_DEVICE');faces.append(int(e['face']))
  else:
   x,h=divmod(k,3);nodes=[1,2+x,7-x,8+x];need((int(e['sender']),int(e['receiver']))==(nodes[h+1],nodes[h]),'RETURN_DEVICE')
 need(len(set(faces))==3 and all(x>0 for x in faces),'FACE_MAP');q_a=collections.defaultdict(list);q_b=collections.defaultdict(list)
 for x in csvrows(d/'queue_a.csv'):q_a[int(x['queue'])].append(x)
 for x in csvrows(d/'queue_b.csv'):q_b[int(x['queue'])].append(x)
 need(set(q_a)==set(q_b)==set(cfg),'QUEUE_SET');q={k:queue_audit(q_a[k],q_b[k]) for k in cfg};w=collections.defaultdict(dict)
 for x in csvrows(d/'wire.csv'):
  k,t,u,b=map(int,(x['link'],x['time_ns'],x['uid'],x['bytes']));e=x['event'];need(k in set(range(9))|set(range(12,21)) and 0<=t<=END and b>0 and e in ('TX','RX','ERROR'),'WIRE_VALUE');k2=(u,e);need(k2 not in w[k],'WIRE_DUP');w[k][k2]=(t,b)
 errors=0;eligible=0
 for k in set(range(9))|set(range(12,21)):
  rs=w[k];tx={u:x for (u,e),x in rs.items() if e=='TX'};rx={u:x for (u,e),x in rs.items() if e=='RX'};er={u:x for (u,e),x in rs.items() if e=='ERROR'};need(not(set(rx)&set(er)) and set(tx)==set(rx)|set(er),'WIRE_ACCOUNTING');need(not er or k==target and loss>0,'UNAUTHORIZED_RX_ERROR');base=k if k<9 else k-12;bps=int(cfg[base]['rate_bps']) if k<9 else 50000000;prop=int(cfg[base]['delay_ns'])
  for u,(t,b) in tx.items():
   t2,b2=(rx if u in rx else er)[u];need(b==b2 and abs(Fraction(t2-t-prop)-Fraction(b*8*10**9,bps))<=2,'ACTUAL_PROPAGATION_OR_SERVICE')
  if k==target:eligible=len(tx);errors=len(er)
  if k<9:need(tx==q[k]['deq'],'WIRE_DEQUEUE_MATCH')
 need(eligible>0 and (loss==0 and errors==0 or loss>0 and errors>0 and .005<=errors/eligible<=.05),'LOSS_FIDELITY')
 bg=csvrows(d/'background.csv');need([int(x['time_ns']) for x in bg]==background_times(rate) and len({int(x['uid']) for x in bg})==len(bg),'OFFERED_TIME');bgok=0;drop_set=set(q[target]['drops'])
 for x in bg:
  t,u=int(x['time_ns']),int(x['uid']);ok=int(x['accepted']);need(ok in (0,1),'SEND_FLAG');need((q[target]['enq'].get(u)==(t,1200) and u in q[target]['deq']) if ok else ((t,u) in drop_set and u not in q[target]['enq']),'BACKGROUND_SHARED_QUEUE_WIRE_SIZE');bgok+=ok
 need(bgok>0 and len(bg)>0,'BACKGROUND_EMPTY');need((rate==3 or len(q[target]['drops'])>0) and bool(q[target]['wait']),'PRESSURE_ENGINEERING')
 dcs=jsrows(d/'events.jsonl.decisions.jsonl');raw=jsrows(d/'events.jsonl');need(len(dcs)==126 and raw[-1]['event_type']=='SIMULATION_END','PIT_RECORDER');need(all(int(a['event_seq'])<int(b['event_seq']) and int(a['time_ns'])<=int(b['time_ns']) for a,b in zip(raw,raw[1:])),'PIT_ORDER');tx=[x for x in raw if x['event_type']=='TX_INTEREST'];need(len(tx)==126,'ACTUAL_TX_COUNT');byname=collections.defaultdict(list)
 for x in raw:byname[x['name']].append(x)
 app=csvrows(d/'probe.csv');need([(x['name'],int(x['time_ns'])) for x in app if x['event']=='SEND']==[(f'/hcraf/pilot/{i}',t) for i,t,k in s],'ACTUAL_PROBE_SCHEDULE');app_by=collections.defaultdict(list)
 for x in app:app_by[x['name']].append(x)
 prod=csvrows(d/'producer.csv');need(len(prod)==126 and len({x['name'] for x in prod})==126 and all(int(x['node'])==8+s[int(x['name'].rsplit('/',1)[-1])][2] for x in prod),'PRODUCER_ROUTE')
 ev=csvrows(d/'local_events.csv');need(all(int(x['ordinal'])==i+1 and int(x['kind']) in range(6) and int(x['face'])>0 for i,x in enumerate(ev)) and all(int(a['time_ns'])<=int(b['time_ns']) for a,b in zip(ev,ev[1:])),'NATIVE_EVENT_ORDER')
 # Independently check every RTT event against actual previous send/arrival, per face.
 sent={};expected_rtt={};
 for x in ev:
  k=int(x['kind']);key=x['name'],int(x['face']);t=int(x['time_ns'])
  if k==3:need(key not in sent,'DUP_NATIVE_TX');sent[key]=t
  if k==1 and key in sent:expected_rtt[key]=(t,(t-sent.pop(key))/1e6)
  if k==5:need(key in expected_rtt and expected_rtt[key]==(t,float(x['rtt'])) and float(x['rtt'])>0,'RTT_REPLAY');del expected_rtt[key]
 need(not expected_rtt,'RTT_MISSING');need([(x['name'],int(x['time_ns']),int(x['face'])) for x in ev if int(x['kind'])==3]==[(x['name'],x['time_ns'],x['face_id']) for x in tx],'NATIVE_TX_MATCH');need(len([x for x in ev if int(x['kind'])==0])==126,'NATIVE_RX_COUNT');fs=csvrows(d/'features.csv');need(len(fs)==378,'FEATURE_ROWS');outcomes=collections.Counter();classes=collections.Counter();target_classes=collections.Counter();pits=set();candidate=[]
 for i,t,k in s:
  dc=dcs[i];x=tx[i];nm=f'/hcraf/pilot/{i}';f=faces[k];pit=int(dc['pit_instance_id']);need(pit>0 and pit not in pits,'PIT_ID');pits.add(pit);need(dc['decision_id']==x['decision_id']==i+1 and dc['time_ns']==x['time_ns']==t and dc['name']==x['name']==nm and x['pit_instance_id']==pit and x['face_id']==f,'ACTUAL_FACE_PIT_TIME');ranks={c['face_id']:c['routing_cost'] for c in dc['candidates']};need(ranks=={faces[a]:1 if a==k else a+2 if a<k else a+1 for a in range(3)},'FIB_RANKS')
  fin=[a for a in byname[nm] if a['event_type']=='PIT_FINALIZE' and a['pit_instance_id']==pit];need(len(fin)==1 and fin[0]['time_ns']>=t,'TERMINAL_PIT');sat=[a for a in byname[nm] if a['event_type']=='PIT_SATISFIED' and a['pit_instance_id']==pit];data=[a for a in app_by[nm] if a['event']=='DATA'];nack=[a for a in app_by[nm] if a['event']=='NACK'];need(len(data)<=1 and len(nack)<=1 and not(data and nack),'TERMINAL_APP')
  if sat:need(len(sat)==1 and sat[0]['face_id']==f and len(data)==1 and not nack and fin[0]['reason']==1,'SUCCESS_WITNESS');outcome='SUCCESS'
  elif nack:need(not data,'NACK_WITNESS');outcome='NACK'
  else:need(not data and fin[0]['time_ns']>=t+1000000000,'TIMEOUT_OR_UNCLASSIFIED');outcome='TIMEOUT'
  outcomes[outcome]+=1
  for a in range(3):
   v=fs[i*3+a];need((int(v['decision_id']),int(v['time_ns']),int(v['slot']),int(v['face']))==(i+1,t,a,faces[a]),'FEATURE_ALIGNMENT');o=int(v['ordinal']);need(0<=o<=len(ev) and all(int(e['time_ns'])<=t for e in ev[:o]) and (o==len(ev) or int(ev[o]['time_ns'])>=t),'CAUSAL_ORDINAL');need(any(int(e['kind'])==0 and e['name']==nm for e in ev[:o]) and not any(int(e['kind'])==3 and e['name']==nm for e in ev[:o]),'BEFORE_ACTUAL_TX');counts=[0]*5;rt=0.;missing=1
   for e in ev[:o]:
    ek,ef,et=int(e['kind']),int(e['face']),int(e['time_ns'])
    if ek==5 and ef==faces[a]:rt=float(e['rtt']) if missing else .2*float(e['rtt'])+.8*rt;missing=0
    if ek<5 and t-H<et<=t and (ek<3 or ef==faces[a]):counts[ek]+=1
   need([int(v[k]) for k in FEATURES[5:10]]==counts and math.isclose(float(v['rtt']),rt,rel_tol=1e-12,abs_tol=1e-12) and int(v['missing'])==missing,'FEATURE_REPLAY');p=int(v['packets']);need(0<=p<=32 and float(v['fraction'])==p/32 and int(v['up'])==1 and int(v['rank'])==ranks[faces[a]] and int(v['pit'])>=1,'FEATURE_SNAPSHOT');states=q[9+a]['states'];prior=[z[2] for z in states if z[0]<t];need(p==(prior[-1] if prior else 0) or p in [z[2] for z in states if z[0]==t],'LOCAL_QUEUE_WITNESS')
  paths=[q[3*k+h]['states'] for h in range(3)];a=max(window_area(p,t-H,t) for p in paths);b=max(window_area(p,t,t+H) for p in paths);cur,fut,y=reference(paths,t,0,END);need(cur==Fraction(a,32*H) and fut==Fraction(b,32*H) and y==int(4*b>=32*H),'EXACT_AREA_CROSSCHECK');classes[y]+=1
  if k==slot:target_classes[y]+=1
  candidate.append(dict(decision_id=i+1,time_ns=t,slot=k,face=f,pit_instance_id=pit,outcome=outcome,assignment_probability_numerator=1,assignment_probability_denominator=3-i%3,current_queue_area_packet_ns=a,future_queue_area_packet_ns=b,candidate_future_class=y))
 need(len(candidate)==126 and sum(target_classes.values())==42,'CANDIDATE_COUNT');write(d/'pilot_candidate_reference.json',candidate)
 ret=dict(case=r,decisions=126,all_candidate_feature_rows=378,return_reference_rows=126,conditional_assignment='1/(3-index mod 3), precommitted permutation; old NFD nominal draw is NOT propensity',background_offered=len(bg),background_accepted=bgok,background_offered_wire_bytes=1200*len(bg),receiver_errors=errors,eligible_receiver_packets=eligible,mean_target_queue_wait_ns=sum(q[target]['wait'])/len(q[target]['wait']),queue_drops=len(q[target]['drops']),target_positive=target_classes[1],all_positive=classes[1],outcomes=dict(outcomes),status='PASS_PILOT_CASE_ENGINEERING_ONLY',**LOCKS)
 ret['files']={p.name:digest(p) for p in sorted(d.iterdir()) if p.is_file()};write(d/'case_receipt.json',ret);return ret

def run(args):
 cases,schedules,hashes=read_prereg(args.prereg);need(not args.out.exists(),'REFUSE_OVERWRITE');args.out.mkdir(parents=True);rc=[]
 for r in cases:
  s=schedules[int(r['seed']),r['site']];d=(args.out/r['seed']/r['site']/r['arm']).resolve();d.mkdir(parents=True);schedule=d/'schedule.csv'
  with schedule.open('w',newline='') as f:w=csv.writer(f,lineterminator='\n');w.writerow(('decision_index','decision_ns','selected_slot'));w.writerows(s)
  opts={'run':r['seed'],'site':r['site'],'arm':r['arm'],'output':d,'schedule':schedule,'target':r['target_slot'],'rate':r['background_mbps'],'loss':r['loss_ppm'],'delay':r['added_propagation_ms'],'trafficStream':r['traffic_stream'],'errorStream':r['error_stream'],'streamBase':r['ns3_stream_base']};cmd=BIN+' '+' '.join('--%s=%s'%x for x in opts.items());(d/'command.txt').write_text(cmd+'\n')
  with (d/'simulator.log').open('w') as f:subprocess.run(['python3','./waf','--run-no-build',cmd],cwd=str(args.ns3),stdout=f,stderr=subprocess.STDOUT,check=True)
  receipt=audit_case(r,s,d);rc.append(receipt);print('PASS_PILOT_CASE',r['seed'],r['site'],r['arm'],flush=True)
 need(len(rc)==45 and sum(x['decisions'] for x in rc)==5670 and sum(x['all_candidate_feature_rows'] for x in rc)==17010,'TOTALS');by={(x['case']['seed'],x['case']['site'],x['case']['arm']):x for x in rc};contrasts=[]
 for seed,site in schedules:
  a,b,c,e=(by[str(seed),site,k] for k in ('A','B','C','E'));need(b['mean_target_queue_wait_ns']>a['mean_target_queue_wait_ns'] and e['mean_target_queue_wait_ns']>c['mean_target_queue_wait_ns'],'PRESSURE_WAIT_MANIPULATION');contrasts.append({'seed':seed,'site':site,'B_minus_A_wait_ns':b['mean_target_queue_wait_ns']-a['mean_target_queue_wait_ns'],'E_minus_C_wait_ns':e['mean_target_queue_wait_ns']-c['mean_target_queue_wait_ns']})
 need(0<sum(x['all_positive'] for x in rc)<5670,'PILOT_CLASS_VARIATION');write(args.out/'PILOT_RECEIPT.json',dict(status=STATUS,prior_status=PRIOR,prereg_files=hashes,cases=45,decisions=5670,all_candidate_feature_rows=17010,case_receipt_hashes={str(p.relative_to(args.out)):digest(p) for p in sorted(args.out.rglob('case_receipt.json'))},physical_wait_contrasts=contrasts,construct_validated=False,model_fits=0,new_AP_computed=False,new_bootstrap_computed=False,confirmation_cases=0,development_cases=0,heldout_rows_read=0,official_F3_labels_constructed=0,pilot_rows_trainable=False,**LOCKS));print(STATUS,flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--prereg',required=True,type=P);p.add_argument('--ns3',required=True,type=P);p.add_argument('--out',required=True,type=P);a=p.parse_args();run(a)
