"""Prospective contract/reference only; no simulator, data reader for episodes or fitting."""
import csv, hashlib, io, json, pathlib, zipfile
from fractions import Fraction
VERSION='v0.52.54'
H=75_000_000; CAP=32; N=126
SITES=('producer_egress','transit_middle','relay_return')
ARMS={'A':(3,0,0),'B':(18,0,0),'C':(3,20000,0),'D':(3,0,20),'E':(18,20000,0)}
PARTS={'pilot':(620001,620003),'development':(620101,620112),'confirmation':(620201,620236)}
LOCKS=dict(F3_ready=False,GO_FREEZE=False,training_ready=False,Congestion=None,FutureCongestion=None,heldout_release_authorized=False,Stage1AO_or_NSGAIII_authorized=False)
PARENT_SHA='a992a3cd96f2ad25370771e4ef5a78a5b6061ca979a36523628a4618ed2f444c'
RECEIPT_SHA='98d0eed849c1208e61a97faa313395e3487cae0419745aeb88dd4e0c61b69e19'
BASE=('local_selected_queue_fraction','local_pit_occupancy_at_t','local_interest_rx_count_previous_75ms','local_data_rx_count_previous_75ms','local_selected_face_tx_count_previous_75ms','local_data_rtt_ewma_before_t','local_data_rtt_missing_at_t')
FULL=('fib_route_cost','local_selected_queue_packets','local_selected_queue_fraction','local_selected_link_up','local_pit_occupancy_at_t','local_interest_rx_count_previous_75ms','local_data_rx_count_previous_75ms','local_nack_rx_count_previous_75ms','local_selected_face_tx_count_previous_75ms','local_selected_face_drop_count_previous_75ms','local_data_rtt_ewma_before_t','local_data_rtt_missing_at_t')
def need(ok,msg):
    if not ok:raise ValueError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def draw(n,*key):
    need(n>0,'RANGE');limit=(1<<256)//n*n;i=0
    while True:
        b=json.dumps(['P12R_NEW_CONSTRUCT_05254',*key,i],separators=(',',':')).encode();v=int(sha(b),16)
        if v<limit:return v%n
        i+=1

def schedule(seed,site):
    out=[]
    for block in range(N//3):
        order=[0,1,2]
        for j in (2,1):
            k=draw(j+1,'face',seed,site,block,j);order[j],order[k]=order[k],order[j]
        for slot in order:
            i=len(out);t=2_000_000_000+125_000_000*i+(draw(20_000_001,'time',seed,site,i)-10_000_000)
            out.append((i,t,slot))
    return out

def matrix():
    rows=[];sched=[]
    for part,(start,end) in PARTS.items():
        for seed in range(start,end+1):
            for idx,site in enumerate(SITES):
                target=(seed-start+idx)%3
                # Unique nonzero stream identifiers; same schedule within five paired arms.
                base=100000+((seed-620000)*3+idx)*10
                for i,t,face in schedule(seed,site):sched.append((part,seed,site,i,t,face))
                for arm,(rate,loss,delay) in ARMS.items():
                    rows.append((part,seed,site,arm,target,rate,loss,delay,12,CAP,base,base+1,base+2,N))
    return rows,sched

def csvbytes(header,rows):
    b=io.StringIO(newline='');w=csv.writer(b,lineterminator='\n');w.writerow(header);w.writerows(rows);return b.getvalue().encode()

def queue_area(events,start,end,coverage_start,coverage_end,capacity=CAP):
    """Events: (time_ns, ordinal, post_event_queue_packets), complete ordered trace.
    Initial event establishes state at coverage_start; all events at left boundary
    set the right-continuous state; right boundary has zero measure.
    Trace completeness is an upstream independent QC responsibility.
    """
    need(coverage_start<=start<end<=coverage_end and capacity==CAP,'COVERAGE_OR_CAPACITY')
    need(bool(events) and events[0][0]==coverage_start,'INITIAL_STATE')
    prev=None;q=0;last=start;area=0
    for t,o,n in events:
        need(all(type(v) is int for v in (t,o,n)) and coverage_start<=t<=coverage_end and 0<=n<=capacity,'BAD_EVENT')
        need(prev is None or (t,o)>prev,'ORDER');prev=(t,o)
        if t<=start:q=n;continue
        if t>=end:continue
        area+=(t-last)*q;last=t;q=n
    return area+(end-last)*q

def reference(paths,t,coverage_start,coverage_end):
    need(len(paths)==3,'THREE_RETURN_QUEUES')
    a=max(queue_area(p,t-H,t,coverage_start,coverage_end) for p in paths)
    b=max(queue_area(p,t,t+H,coverage_start,coverage_end) for p in paths)
    return Fraction(a,CAP*H),Fraction(b,CAP*H),int(4*b>=CAP*H)

def validate_parent(path):
    b=pathlib.Path(path).read_bytes();need(sha(b)==PARENT_SHA,'PARENT_ZIP')
    with zipfile.ZipFile(io.BytesIO(b)) as z:
        need(z.testzip() is None and len(z.namelist())==len(set(z.namelist())),'PARENT_ZIP_STRUCTURE')
        raw=z.read('p12r_construct/P12R_CONSTRUCT_FEASIBILITY_RECEIPT_v05253.json');need(sha(raw)==RECEIPT_SHA,'PARENT_RECEIPT')
        r=json.loads(raw);need(r['status']=='PASS_P12R_CONSTRUCT_FEASIBILITY_AUDIT_ONLY_CONSTRUCT_NOT_VALIDATED' and r['parent_scientific_status']=='NO_GO_P12R_CONFIRMATORY_STATISTICAL_GATES_NOT_MET','PARENT_STATUS')
        need(all(r[k]==v for k,v in LOCKS.items()) and r['construct_validated'] is False,'PARENT_LOCKS')
    return r

def make(out,parent):
    validate_parent(parent);out=pathlib.Path(out);out.mkdir(parents=True,exist_ok=True);rows,sched=matrix()
    m=csvbytes('partition seed site arm target_slot background_mbps loss_ppm added_propagation_ms bottleneck_mbps queue_capacity_packets traffic_stream error_stream ns3_stream_base probe_count'.split(),rows)
    s=csvbytes('partition seed site decision_index decision_ns selected_slot'.split(),sched)
    need(len(rows)==765 and len(sched)==19278,'MATRIX_COUNT')
    # The plan and thresholds are source files, not generated from any data.
    plan_path=pathlib.Path(__file__).with_name('PLAN.json');plan=plan_path.read_bytes();p=json.loads(plan)
    need(p['locks']==LOCKS and p['horizon_ns']==H and p['capacity_packets']==CAP and p['feature_order_full']==list(FULL) and p['feature_order_baseline']==list(BASE),'PLAN_CONTRACT')
    for name,b in [('LOCKED_MATRIX.csv',m),('LOCKED_PROBE_SCHEDULE.csv',s),('PLAN.json',plan)]: (out/name).write_bytes(b)
    r=dict(**LOCKS,status='PASS_P12R_NEW_CONSTRUCT_PREREG_ONLY_NO_EXECUTION_NO_RELEASE',parent_zip_sha256=PARENT_SHA,parent_receipt_sha256=RECEIPT_SHA,parent_scientific_status='NO_GO_P12R_CONFIRMATORY_STATISTICAL_GATES_NOT_MET',construct_validated=False,simulations_authorized=False,model_fits_authorized=False,confirmation_authorized=False,official_F3_labels_constructed=0,rows_read=0,model_fits=0,simulations=0,planned_cases={k:(e-s+1)*15 for k,(s,e) in PARTS.items()},planned_decisions=len(rows)*N,files={n:sha(b) for n,b in [('LOCKED_MATRIX.csv',m),('LOCKED_PROBE_SCHEDULE.csv',s),('PLAN.json',plan)]})
    (out/'PREREG_RECEIPT.json').write_text(json.dumps(r,sort_keys=True,indent=2)+'\n');print(r['status'])
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--parent',required=True);p.add_argument('--out',required=True);a=p.parse_args();make(a.out,a.parent)
