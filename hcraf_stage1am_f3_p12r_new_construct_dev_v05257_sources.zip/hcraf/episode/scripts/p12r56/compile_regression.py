#!/usr/bin/env python3
"""Compile the actual schedule-type/parser excerpt; not a full ndnSIM compile."""
import pathlib,subprocess,tempfile,re,os,csv
from pilot_audit import read_prereg
ROOT=pathlib.Path(__file__).resolve().parents[2]
source=ROOT/'src/hcraf-stage1am-f3-p12r-new-construct-pilot-v05256.cpp'
s=source.read_text(); assert not re.search(r'\bProbe\b',s)
start=s.index('struct HcrafP12R56ScheduleEntry'); end=s.index('namespace ns3 {',start)
parser=s[start:end]
head=r'''#include <array>
#include <algorithm>
#include <fstream>
#include <sstream>
#include <vector>
#include <stdexcept>
#include <cstdint>
#include <type_traits>
namespace ns3 { class Probe { Probe(const Probe&)=delete; }; }
using namespace ns3;
using U=uint64_t;
static void need(bool x,const char* m){if(!x)throw std::runtime_error(m);}
'''
tail=r'''namespace ns3 { struct AppCheck { std::vector<HcrafP12R56ScheduleEntry> plan; void set(const std::vector<HcrafP12R56ScheduleEntry>& p){plan=p;} }; }
struct RefCheck { const std::vector<HcrafP12R56ScheduleEntry>& plan; std::ofstream& a; std::ofstream& b; RefCheck(const std::vector<HcrafP12R56ScheduleEntry>& p,std::ofstream& x,std::ofstream& y):plan(p),a(x),b(y){} };
int main(int argc,char** argv){if(argc!=2)return 2;auto p=readPlan(argv[1]); ns3::AppCheck x;x.set(p);std::ofstream a,b;RefCheck ref(p,a,b);return x.plan.size()==126&&ref.plan.size()==126?0:1;}
'''
with tempfile.TemporaryDirectory() as d:
 p=pathlib.Path(d); (p/'check.cc').write_text(head+parser+tail)
 subprocess.check_call(['g++','-std=c++14','-Wall','-Wextra',str(p/'check.cc'),'-o',str(p/'check')])
 _,schedules,_=read_prereg(pathlib.Path(os.environ['P12R56_PREREG']))
 for k,rows in schedules.items():
  with (p/'schedule.csv').open('w') as f:
   wr=csv.writer(f,lineterminator='\n');wr.writerow(('decision_index','decision_ns','selected_slot'));wr.writerows(rows)
  subprocess.check_call([str(p/'check'),str(p/'schedule.csv')])
 print('PASS_EXTRACTED_CPP_SCHEDULE_NAMESPACE_REGRESSION_9_SCHEDULES_NOT_FULL_NDNSIM_BUILD')
