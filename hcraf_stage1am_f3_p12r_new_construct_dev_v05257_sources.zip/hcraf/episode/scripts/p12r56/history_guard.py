#!/usr/bin/env python3
"""Conservative declared namespace collision audit of repository ancestry, not raw heldout outcomes."""
import io,json,pathlib,re,subprocess,zipfile,os,sys,hashlib
from pilot_audit import PREREG_COMMIT,need,write,read_prereg
IDS=set(range(620001,620004))|set(range(620101,620113))|set(range(620201,620237))
TOKEN=re.compile(rb'(?<![A-Za-z0-9])620\d{3}(?![A-Za-z0-9])')
RANGE=re.compile(rb'\brange\s*\(\s*(\d{5,9})\s*,\s*(\d{5,9})\s*\)')
TEXT={'.py','.cpp','.cc','.h','.hpp','.sh','.yml','.yaml','.json','.md','.txt','.csv'}
EXCLUDED=('new_construct_prereg_v05254','new-construct-prereg-v0.52.54','F3_P12R_NEW_CONSTRUCT_v0.52.54')
def matches(data):
 hits={int(m.group()) for m in TOKEN.finditer(data)}&IDS
 for line in data.splitlines():
  if not re.search(rb'\b(seed\w*|rng\w*|run\w*)\b',line,re.I):continue
  for m in RANGE.finditer(line):
   lo,hi=map(int,m.groups());hits|={x for x in IDS if lo<=x<hi}
 return sorted(hits)
def source_archive(n):
 lower=n.lower();return lower.endswith('.zip') and ('source' in lower or 'workflow' in lower) and not any(x in lower for x in ('artifact','episode_output','/raw/','/results/'))
def eligible(n):
 p=pathlib.PurePosixPath(n);lower=n.lower();return p.suffix.lower() in TEXT and not any(x in lower for x in ('/episode_output/','/raw/','/results/','/artifacts/','__pycache__')) and (p.suffix.lower()!='.csv' or any(x in lower for x in ('matrix','schedule','plan','seed','prereg','split','lock')))
def scan(raw,n,level=0):
 if any(x in n for x in EXCLUDED):return [],0
 if source_archive(n.split('!')[-1]):
  need(level<4,'HISTORY_NESTING');hits=[];count=0
  with zipfile.ZipFile(io.BytesIO(raw)) as z:
   for member in z.infolist():
    if member.is_dir():continue
    m=member.filename
    if not(eligible(m) or source_archive(m)) or any(x in m for x in EXCLUDED):continue
    need(member.file_size<=64*1024*1024,'HISTORY_MEMBER_TOO_LARGE:'+m)
    h,c=scan(z.read(member),n+'!'+m,level+1);hits+=h;count+=c
  return hits,count
 if not eligible(n.split('!')[-1]):return [],0
 h=matches(raw);return ([dict(path=n,seeds=h)] if h else []),1

def main(out):
 need(subprocess.check_output(['git','rev-parse','--is-shallow-repository'],text=True).strip()=='false','SHALLOW_HISTORY');subprocess.check_call(['git','merge-base','--is-ancestor',PREREG_COMMIT,'HEAD'])
 # Search all unique blobs reachable in the preregistration ancestry, including old versions.
 objects=subprocess.check_output(['git','rev-list','--objects',PREREG_COMMIT],text=True).splitlines();checked=0;archives=0;hits=[];seen=set()
 for line in objects:
  if ' ' not in line:continue
  oid,n=line.split(' ',1)
  if oid in seen or any(x in n for x in EXCLUDED) or not(eligible(n) or source_archive(n)):continue
  seen.add(oid);typ=subprocess.check_output(['git','cat-file','-t',oid],text=True).strip()
  if typ!='blob':continue
  size=int(subprocess.check_output(['git','cat-file','-s',oid],text=True));need(size<=128*1024*1024,'HISTORY_BLOB_TOO_LARGE:'+n)
  raw=subprocess.check_output(['git','cat-file','blob',oid]);h,c=scan(raw,n);hits+=h;checked+=c;archives+=source_archive(n)
 need(archives>0 and checked>0,'HISTORY_NOT_SCANNED');write(out,dict(status='PASS_NO_DECLARED_NAMESPACE_COLLISION' if not hits else 'STOP_HISTORICAL_NAMESPACE_COLLISION',scope='all reachable historical tracked source/plan/schedule blobs; excludes raw results and own prereg; cannot prove unrecorded external experiments',checked_text_members=checked,checked_archives=archives,namespace=sorted(IDS),hits=hits,prereg_commit=PREREG_COMMIT));need(not hits,'HISTORICAL_NAMESPACE_COLLISION_REVIEW_REQUIRED')
if __name__=='__main__':main(pathlib.Path(sys.argv[1]))
