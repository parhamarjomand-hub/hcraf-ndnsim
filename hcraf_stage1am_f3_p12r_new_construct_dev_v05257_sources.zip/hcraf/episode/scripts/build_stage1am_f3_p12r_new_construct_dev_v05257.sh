#!/usr/bin/env bash
set -euo pipefail
ROOT="$(pwd)"
TASK="$ROOT/hcraf/episode"
# Restore and build verified historical instrumented Forwarder including five live hooks.
bash "$TASK/scripts/build_stage1am_f3_p12v_native_v05241.sh"
cd "$ROOT/episode_sources/ns-3"
cp "$TASK/src/hcraf-stage1am-f3-p12r-new-construct-dev-v05257.cpp" scratch/hcraf-stage1am-f3-p12r-new-construct-dev-v05257.cc
cmp -s "$TASK/src/hcraf-stage1am-f3-p12r-new-construct-dev-v05257.cpp" scratch/hcraf-stage1am-f3-p12r-new-construct-dev-v05257.cc
python3 ./waf -j 2
test -x build/scratch/hcraf-stage1am-f3-p12r-new-construct-dev-v05257
sha256sum build/scratch/hcraf-stage1am-f3-p12r-new-construct-dev-v05257
