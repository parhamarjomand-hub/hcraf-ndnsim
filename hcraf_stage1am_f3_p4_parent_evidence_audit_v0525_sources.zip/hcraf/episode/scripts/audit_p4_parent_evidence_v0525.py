#!/usr/bin/env python3
"""Strictly read-only P3/P4 parent evidence audit. Never produce P4 samples or scores."""
import argparse, collections, hashlib, json, pathlib, re, subprocess, zipfile

P3_ARCHIVE = 'hcraf_stage1am_f3_queue_pressure_feasibility_dev_v0523_sources.zip'
P4_ARCHIVE = 'hcraf_stage1am_f3_p4_prospective_prereg_v0524_sources.zip'
P3_SHA = '2864b8f1917ac38154dde24c42aaf1c03101eaf509c809c95a4113c1ce1ea382'
P4_SHA = '7c8976a9ebee7b21d93979648d8be08e7586b54fc712c334d19d1177c1803577'
P4_LOCK_SHA = '059c6485957450d2ffcf7bb2b2a46656bb6088e2'
P3_LOCK_SHA = '079cb06ae8cdef07abf6df3b2ff34b0607113b2a'
P4_MATRIX_SHA = '7a5bfb44ebd00b68002203fea3a74a3f71a1b6fd2b89450925b7cfab92f21676'
P4_PROTO_SHA = 'fd7bcc7fff7c4c5cb1024b551e11bba6814dad16e02562b4974b7e021e2cadf9'
SCIENCE={'Congestion':None,'FutureCongestion':None,'F3_ready':False,'GO_FREEZE':False,'training_ready':False,'heldout_release_authorized':False}
EVENT_KEYS=('event','event_type','type','reason','drop_reason','trace_event','kind','action')
IDENTITY_KEYS=('sender_node_id','sender_device_index','receiver_node_id','receiver_device_index','node_id','device_index','face_id','selected_face_id','selected_slot','link_id','queue_id','interface','path_id','path','edge','hop','producer_node_id','consumer_node_id')

def digest(raw):return hashlib.sha256(raw).hexdigest()

def committed_zip(path, expected, commit):
    b=pathlib.Path(path).read_bytes()
    assert digest(b)==expected,'SOURCE_ARCHIVE_HASH_MISMATCH_'+path
    historical=subprocess.check_output(['git','show',commit+':'+path])
    assert historical==b,'SOURCE_ARCHIVE_CHANGED_SINCE_LOCK_'+path
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None,'CRC_FAILED_'+path
        names=z.namelist()
        assert len(names)==len(set(names)),'DUPLICATE_MEMBERS_'+path
        for name in names:
            pp=pathlib.PurePosixPath(name)
            assert name and '..' not in pp.parts and not name.startswith('/') and '\\' not in name,'UNSAFE_ARCHIVE_MEMBER'
        return names

def validate_p4_receipt(path):
    r=json.loads(path.read_text('utf-8'))
    assert r['result']=='PASS_P4_V0524_PROSPECTIVE_PREREG_LOCK_ONLY_NO_NDNSIM'
    assert str(r['github_run_id'])=='44378629623'
    assert r['git_commit_sha']==P4_LOCK_SHA
    assert r['source_zip_sha256']==P4_SHA
    assert r['matrix_sha256']==P4_MATRIX_SHA and r['protocol_sha256']==P4_PROTO_SHA
    assert r['planned_runs']==144 and r['development_runs']==48 and r['validation_runs']==48 and r['heldout_runs']==48
    assert r['simulations_executed']==0
    assert all(r[k] is val for k,val in SCIENCE.items()),'SCIENCE_LOCK_CHANGED'
    return r

def relevant_label(row):
    """Count only explicit event-key QUEUE_DROP values, never textual substrings in entire row."""
    seen=[row[k] for k in EVENT_KEYS if k in row and isinstance(row[k],str)]
    if any(v.strip().upper()=='QUEUE_DROP' for v in seen):return 'QUEUE_DROP'
    if any('RECEIVER' in v.upper() and 'DROP' in v.upper() for v in seen):return 'RECEIVER_NONQUEUE_DROP'
    if seen:return 'OTHER_EXPLICIT_EVENT'
    return 'UNCLASSIFIED_NO_EVENT_KEY'

def view(row):
    return {k:row[k] for k in list(EVENT_KEYS)+list(IDENTITY_KEYS)+['time_s','timestamp_s','time_ms','event_time_s','decision_time_s'] if k in row and isinstance(row[k],(str,int,float,bool))}

def scan_witness(file_path, max_lines=250000):
    c=collections.Counter(); identities={k:set() for k in IDENTITY_KEYS}
    keys=collections.Counter(); schemas=collections.Counter(); snippets=collections.defaultdict(list)
    count=0; faulty=0; limit_hit=False
    with file_path.open('r',encoding='utf-8',errors='replace') as fh:
        for line in fh:
            if count>=max_lines:limit_hit=True;break
            if not line.strip():continue
            count+=1
            try: row=json.loads(line)
            except json.JSONDecodeError:faulty+=1;continue
            if not isinstance(row,dict):faulty+=1;continue
            lab=relevant_label(row);c[lab]+=1
            for k,v in row.items():keys[k]+=1
            schemas[','.join(sorted(k for k in row if k in EVENT_KEYS)) or 'NONE']+=1
            for key in IDENTITY_KEYS:
                if key in row and len(identities[key])<80 and isinstance(row[key],(str,int,float,bool)):
                    identities[key].add(str(row[key]))
            if len(snippets[lab])<3:snippets[lab].append(view(row))
    return {'file':str(file_path),'lines_checked':count,'unparsed_or_nonobject':faulty,
         'max_lines_reached':limit_hit,'classified_events':dict(sorted(c.items())),
         'event_key_schemas':dict(sorted(schemas.items())),
         'present_keys':dict(sorted(keys.items())),
         'distinct_identity_values':{k:sorted(s) for k,s in identities.items() if s},
         'sample_event_fields_only':dict(snippets)}

def inspect_source_zip(zippath):
    out={}
    with zipfile.ZipFile(zippath) as z:
        for n in z.namelist():
            if not n.endswith(('.cpp','.py','.hpp','.h','.md','.json')):continue
            if not (n.endswith('.cpp') or 'pressure_feasibility_v0523.py' in n or 'P3_DEV_PROTOCOL_FA' in n):continue
            if z.getinfo(n).file_size>3_000_000:continue
            lines=z.read(n).decode('utf-8','replace').splitlines()
            hits=[]
            rx=re.compile(r'queue|device|node|face|bottleneck|capacity|telemetry|rate|rng|seed|path|drop|selected_slot',re.I)
            for i,line in enumerate(lines):
                if rx.search(line):
                    hits.append({'line':i+1,'content':line[:280]})
                if len(hits)>=350:break
            out[n]={'source_lines_total':len(lines),'matching_lines':hits,'truncated':len(hits)>=350}
    return out

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--evidence',required=True);ap.add_argument('--p4-lock',required=True);ap.add_argument('--output',required=True)
    a=ap.parse_args();ev=pathlib.Path(a.evidence);p4=pathlib.Path(a.p4_lock);output=pathlib.Path(a.output)
    output.mkdir(parents=True,exist_ok=True)
    assert p4.is_dir() and ev.is_dir()
    validate_p4_receipt(p4/'prereg_lock_receipt.json')
    names3=committed_zip(P3_ARCHIVE,P3_SHA,P3_LOCK_SHA)
    names4=committed_zip(P4_ARCHIVE,P4_SHA,P4_LOCK_SHA)
    assert any('queue_pressure' in n for n in names3)
    assert any('RUN_MATRIX_LOCKED_144.csv' in n for n in names4)
    witness=sorted(x for x in ev.rglob('*') if x.is_file() and x.name=='pathwide_witness_b.jsonl')
    files=sorted((x.relative_to(ev).as_posix(),x.stat().st_size) for x in ev.rglob('*') if x.is_file())
    assert files,'P3_EVIDENCE_ARCHIVE_EMPTY'
    report={'status':'PASS_P4_V0525_PARENT_EVIDENCE_INSPECTION_ONLY','parent_p4_run_id':'44378629623',
      'parent_p3_run_id':'44354340404','simulations_executed':0,
      'P3_data_purpose':'HISTORICAL_ENGINEERING_ONLY_NOT_TRAIN_OR_VALIDATE_OR_SELECT_THRESHOLD',
      'scientific_locks':SCIENCE,'p3_source_sha256':P3_SHA,'p4_source_sha256':P4_SHA,
      'p3_source_members':names3,'p4_source_members':names4,'p3_artifact_file_inventory':files,
      'p3_witness_files_found':len(witness),
      'p3_witness_technical_schema_audit':[scan_witness(x) for x in witness],
      'p3_source_structure_excerpts':inspect_source_zip(P3_ARCHIVE),
      'limitation':'Physical mapping is NOT certified by this historical inspection; independent ndnSIM P4 validation is still required.',
      'F3_or_PR_AUC_computed':False}
    (output/'P4_PARENT_EVIDENCE_AUDIT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    summary={'status':report['status'],'witness_files_found':len(witness),
      'witness_queue_drop_count_explicit':sum(z['classified_events'].get('QUEUE_DROP',0) for z in report['p3_witness_technical_schema_audit']),
      'source_code_files_excerpted':len(report['p3_source_structure_excerpts']),
      'artifacts_inspected_only':True,'no_simulation':True,'no_model_training':True,
      'no_heldout':True,'next_gate':'P4_REAL_PHYSICAL_TOPOLOGY_PREFLIGHT_NOT_YET_PASSED', 'science_locks':SCIENCE}
    (output/'AUDIT_SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    (output/'STATUS.txt').write_text('PASS_TECHNICAL_AUDIT_ONLY_NO_NDNSIM_NO_F3\n',encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
