import importlib.util, pathlib, tempfile, unittest, json
SPEC=importlib.util.spec_from_file_location('mod',pathlib.Path(__file__).resolve().parents[1]/'scripts'/'audit_p4_parent_evidence_v0525.py')
mod=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(mod)
class TestReadOnlyAudit(unittest.TestCase):
    def test_01_labels_only_explicit_events(self):
        self.assertEqual(mod.relevant_label({'detail':'future QUEUE_DROP'}),'UNCLASSIFIED_NO_EVENT_KEY')
        self.assertEqual(mod.relevant_label({'event':'QUEUE_DROP'}),'QUEUE_DROP')
        self.assertEqual(mod.relevant_label({'reason':'RECEIVER_DROP'}),'RECEIVER_NONQUEUE_DROP')
        self.assertNotEqual(mod.relevant_label({'event':'SOME_OTHER_DROP'}),'QUEUE_DROP')
    def test_02_scan_independent_and_structural(self):
        with tempfile.TemporaryDirectory() as t:
            p=pathlib.Path(t)/'pathwide_witness_b.jsonl'
            p.write_text('\n'.join(map(json.dumps,[
                {'event':'QUEUE_DROP','node_id':2,'device_index':1},
                {'event':'RECEIVER_DROP','node_id':2},
                {'event':'QUEUE_DROP','node_id':3},
                {'message':'QUEUE_DROP future but not event'},
            ]))+'\n')
            out=mod.scan_witness(p)
            self.assertEqual(out['classified_events']['QUEUE_DROP'],2)
            self.assertEqual(out['classified_events']['RECEIVER_NONQUEUE_DROP'],1)
            self.assertEqual(out['classified_events']['UNCLASSIFIED_NO_EVENT_KEY'],1)
    def test_03_lock_data_type(self):
        self.assertIsNone(mod.SCIENCE['Congestion'])
        self.assertFalse(mod.SCIENCE['heldout_release_authorized'])
        self.assertEqual(mod.P4_LOCK_SHA,'059c6485957450d2ffcf7bb2b2a46656bb6088e2')
    def test_04_bounded_audit(self):
        with tempfile.TemporaryDirectory() as t:
            p=pathlib.Path(t)/'pathwide_witness_b.jsonl'
            p.write_text('{"event":"QUEUE_DROP"}\n'*5)
            out=mod.scan_witness(p,max_lines=2)
            self.assertTrue(out['max_lines_reached'])
            self.assertEqual(out['lines_checked'],2)
if __name__=='__main__':unittest.main()
