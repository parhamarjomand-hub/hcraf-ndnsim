import importlib.util,json,pathlib,unittest
PATH=pathlib.Path(__file__).resolve().parents[1]/'docs'/'1AM'/'F3_P4_PROSPECTIVE_QUEUE_PRESSURE_v0.52.4'
sp=importlib.util.spec_from_file_location('p4_lock_checker',PATH/'generate_prereg_v0524.py')
module=importlib.util.module_from_spec(sp);sp.loader.exec_module(module)
class TestP4Prereg(unittest.TestCase):
 def test_01_all_locks_and_sha(self):self.assertEqual(module.verify()['result'],'PASS_P4_V0524_PROSPECTIVE_PREREG_DESIGN_ONLY')
 def test_02_no_p3_seed_reuse(self):self.assertNotIn(22001,{z for v in module.load()['seed_blocks'].values() for z in v})
 def test_03_disjoint_splits(self):
  x=module.load()['seed_blocks'];self.assertEqual(sum(len(set(v)) for v in x.values()),len(set(sum(x.values(),[]))))
 def test_04_no_future_features(self):
  s=module.load();self.assertTrue(all('future' not in z.lower() for z in s['future_features_allowed']))
 def test_05_quarantine(self):
  s=module.load();self.assertEqual(s['simulations_executed'],0);self.assertFalse(s['science_locks']['heldout_release_authorized'])
 def test_06_all_rows_unexecutable(self):
  rows,_=module.expected(module.load());self.assertTrue(all(r['execution_authorized']=='false' for r in rows))
 def test_07_controls_paired(self):
  rows,_=module.expected(module.load());d={}
  for r in rows:d.setdefault((r['seed'],r['topology_profile']),set()).add((r['load_profile'],r['telemetry_profile']))
  self.assertTrue(all(len(v)==4 for v in d.values()))
 def test_08_independent_group_count(self):
  rows,_=module.expected(module.load());self.assertEqual(len({r['independence_block'] for r in rows}),12)
 def test_09_topology_unverified(self):self.assertTrue(module.load()['topology_mapping_status'].startswith('UNVERIFIED'))
 def test_10_label_contract(self):
  s=module.load();self.assertEqual(s['label_event'],'QUEUE_DROP');self.assertFalse(s['non_queue_receiver_drop_is_queue_drop'])
if __name__=='__main__':unittest.main()
