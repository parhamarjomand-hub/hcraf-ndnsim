#!/usr/bin/env python3
"""Deterministic P4 prereg verifier. Strictly no simulations or training."""
import argparse,csv,hashlib,io,json,pathlib,sys
BASE=pathlib.Path(__file__).resolve().parent

def h(b):return hashlib.sha256(b).hexdigest()
def load():return json.loads((BASE/'DESIGN_SPEC_LOCKED.json').read_text('utf-8'))
def expected(s):
    rows=[];rstreams=[]
    for split in ('development','validation','heldout'):
      for seed in s['seed_blocks'][split]:
        unit=f'{split}-seed-{seed}'
        for stream in ('traffic','routing','telemetry'):
          no=int.from_bytes(hashlib.sha256(f'HCRAF_P4_v0524:{seed}:{stream}'.encode()).digest()[:4],'big')%2147483646+1
          rstreams.append({'split':split,'seed':str(seed),'stream':stream,'stream_seed':str(no)})
        for topo in s['topology_profiles']:
         for load in s['loads']:
          for telemetry in s['telemetries']:
           rows.append({'run_key':f'P4_{split}_{seed}_{topo}_{load}_{telemetry}','split':split,'independence_block':unit,
           'seed':str(seed),'topology_profile':topo,'load_profile':load,'telemetry_profile':telemetry,
           'queue_capacity_packets':'12','horizon_ms':'75','execution_authorized':'false',
           'route_map_provenance':'REQUIRES_REAL_TRACE_AUDIT'})
    return rows,rstreams

def verify():
    s=load();assert s['version']=='0.52.4' and s['simulations_executed']==0
    assert s['queue_capacity_packets']==12 and s['horizon_ms']==75
    assert s['telemetry_period_ms']==20 and s['telemetry_max_age_ms']==100
    assert s['topology_mapping_status'].startswith('UNVERIFIED_')
    assert s['label_event']=='QUEUE_DROP' and s['non_queue_receiver_drop_is_queue_drop'] is False
    assert s['historical_P3_excluded_from_training_and_final_testing'] is True
    assert s['parent']['p3_run_id']=='44354340404'
    assert s['parent']['p3_commit_sha']=='079cb06ae8cdef07abf6df3b2ff34b0607113b2a'
    assert s['parent']['p3_artifact_id']=='14452244240'
    assert s['parent']['p3_artifact_digest']=='sha256:a987ee25118bc3de9c4b341c66e036f2c34783f3390ad7cb97666c8214aca8b2'
    assert s['parent']['v0520_run_id']=='43567814962'
    assert s['parent']['v0520_source_zip_sha256']=='0523ad0ef216426d128596fdf15bc91e1c78523346dab2bbd843c16cf139601e'
    assert s['seed_blocks']=={'development':[23101,23102,23103,23104], 'validation':[24101,24102,24103,24104], 'heldout':[25101,25102,25103,25104]}
    assert s['topology_profiles']==['producer_egress','transit_middle','consumer_ingress']
    assert s['loads']==['low_control','high_pressure'] and s['telemetries']==['off','on_20ms']
    assert s['num_simulations']==144 and s['num_per_split']==48
    assert s['science_locks']=={'Congestion':None,'FutureCongestion':None,'F3_ready':False,'GO_FREEZE':False,'training_ready':False,'heldout_release_authorized':False}
    assert not s['model_training_executed']
    assert not set(s['future_features_allowed']) & set(s['future_features_forbidden'])
    assert 'QUEUE_DROP_future_events' in s['future_features_forbidden']
    rows,streams=expected(s)
    def csvread(p):return list(csv.DictReader(io.StringIO(p.read_text('utf-8'))))
    assert csvread(BASE/'RUN_MATRIX_LOCKED_144.csv')==rows,'DRIFT_MATRIX'
    assert csvread(BASE/'RNG_STREAMS_LOCKED_36.csv')==streams,'DRIFT_SEED_STREAMS'
    assert len(rows)==144 and len(streams)==36 and len({r['run_key'] for r in rows})==144
    assert 22001 not in {z for seeds in s['seed_blocks'].values() for z in seeds}
    assert len({z for seeds in s['seed_blocks'].values() for z in seeds})==12
    assert all(r['execution_authorized']=='false' for r in rows)
    assert set(r['split'] for r in rows)=={'development','validation','heldout'}
    assert len(set((r['independence_block'] for r in rows)))==12
    for split in s['seed_blocks']:
       assert sum(r['split']==split for r in rows)==48
    manifest_path=BASE/'HCRAF_F3_P4_V0524_SOURCE_SHA256.json'
    # manifest only exists when extracted in workflow (it is at ZIP root, not document folder).
    root=BASE.parents[4]  # hcraf/episode/docs/1AM/N => staged repository root
    mf=root/'HCRAF_F3_P4_V0524_SOURCE_SHA256.json'
    if mf.exists():
       m=json.loads(mf.read_text('utf-8'))
       assert m['stage']=='1AM_F3_P4_PROSPECTIVE_PREREG_ONLY_v0.52.4'
       assert m['science_locks']==s['science_locks']
       for name,hashhex in m['source_files'].items():
           p=root/name;assert p.is_file() and h(p.read_bytes())==hashhex,'MISMATCH:'+name
       assert len(m['source_files'])==7
    return {'result':'PASS_P4_V0524_PROSPECTIVE_PREREG_DESIGN_ONLY','num_simulations_planned':len(rows),
       'development_planned':48,'validation_planned':48,'heldout_planned_but_blocked':48,
       'simulations_executed':0,'F3_ready':False,'GO_FREEZE':False,'training_ready':False,
       'heldout_release_authorized':False,'sha_matrix':h((BASE/'RUN_MATRIX_LOCKED_144.csv').read_bytes()),
       'sha_protocol':h((BASE/'SCIENTIFIC_PROTOCOL_FA.md').read_bytes())}

def main():
    p=argparse.ArgumentParser();p.add_argument('--verify',action='store_true');a=p.parse_args()
    if not a.verify:raise SystemExit('FAIL_CLOSED: --verify required; this is not an executor')
    print(json.dumps(verify(),ensure_ascii=False,sort_keys=True,indent=2))
if __name__=='__main__':main()
