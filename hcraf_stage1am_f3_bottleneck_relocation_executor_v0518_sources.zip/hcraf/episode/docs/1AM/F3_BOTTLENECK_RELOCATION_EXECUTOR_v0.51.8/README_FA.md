# HCRAF — Executor مستقل جابه‌جایی گلوگاه، v0.51.8

**نوع:** اجرای Development روی ماتریس *از قبل قفل‌شده* v0.51.7؛ نه قفل جدید، نه Test نهایی، نه Freeze.

- قفل GitHub: Run `43242291541` و SHA `a77704bb631cf2fac74ade2e28bc7c19b9b0fb53`.
- SHA ماتریس ۲۱۶ ردیفی: `6c66dfefce2abcc73e8c07fdb0afa7ef892524e74b8eb2a004a4181942180649`.
- ۸ بازو × (۲۴ پایش‌شده + ۳ بدون پایش) = ۲۱۶ Run؛ **یک Shard در هر اجرای Workflow**.
- Shard 0: Producer 6M؛ 1: Producer 12M؛ 2: Mid 6M؛ 3: Mid 12M؛ 4: Relay 6M؛ 5: Relay 12M؛ 6: 50M بدون فشار دست‌کاری‌شده؛ 7: افت دریافت غیرصفی ۱۵٪.
- برای همه بازوهای جفت‌شده زمان‌های Target/Competitor و Selected Face قفل‌شده‌اند. محل گلوگاه از `INTERVENTION_SITES_LOCKED_12.csv` استخراج و در C++ با شناسه دستگاه و Trace مقایسه می‌شود.
- در بازوی افت غیرصفی، تنها `node1/dev(1+slot)` دارای RateErrorModel است و خطاهای `PHY_RX_DROP` از `QUEUE_DROP` جدا ثبت می‌شوند.
- دو شاهد نرم‌افزاری A/B روی یک شبیه‌ساز، رخدادبه‌رخداد تطبیق داده می‌شوند. این شاهد فیزیکی مستقل خارج از ndnSIM نیست.
- هر خروجی ناقص، ناسازگار یا پیش از قفل‌شدن، FAIL-CLOSED است. هیچ پنجره‌ای خودکار برچسب منفی رسمی ندارد.
- سنجش هزینه ابزار پایش از هزینه خالص سیاست HCRAF تفکیک می‌شود.
- ۲۰ آزمون تاریخی وابسته به Fixture واقعی Stage 1S هنوز Deferred هستند؛ هیچ ادعای PASS کامل رگرسیون نداریم.

## محدودیت علمی قطعی

`Congestion=null`, `FutureCongestion=null`, `F3_ready=false`, `GO_FREEZE=false`, `training_ready=false`.

حکم همچنان `NO_GO_F3_CONSTRUCT_AND_PREDICTABILITY_NOT_VALIDATED` است. ساخت 1AO، Freeze و آموزش NSGA-III ممنوع‌اند.

**وضعیت انتشار:** ۲۴ آزمون Python محلی و بررسی بازتولید رویدادهای A/B بر Trace واقعی قدیمی موفق شدند؛ کامپایل و اجرای جدید C++ در ndnSIM هنوز انجام نشده است.
