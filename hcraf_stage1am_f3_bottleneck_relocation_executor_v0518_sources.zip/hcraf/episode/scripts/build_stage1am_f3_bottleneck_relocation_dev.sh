#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK="$ROOT/hcraf/episode"
# Existing pinned build setup; never launch historical workflows.
bash "$TASK/scripts/build_stage1am_pathwide.sh"
cd "$ROOT/episode_sources/ns-3"
cp "$TASK/src/hcraf-stage1am-pathwide-witness-b.hpp" scratch/hcraf-stage1am-pathwide-witness-b.hpp
cp "$TASK/src/hcraf-stage1am-f3-bottleneck-relocation-dev.cpp" scratch/hcraf-stage1am-f3-bottleneck-relocation-dev.cc
cmp -s "$TASK/src/hcraf-stage1am-f3-bottleneck-relocation-dev.cpp" scratch/hcraf-stage1am-f3-bottleneck-relocation-dev.cc
python3 ./waf -j 2
test -x build/scratch/hcraf-stage1am-f3-bottleneck-relocation-dev
