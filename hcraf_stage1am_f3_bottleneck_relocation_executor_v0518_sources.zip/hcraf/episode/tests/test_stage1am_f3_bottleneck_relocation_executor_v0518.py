"""Contract, no-label, immutable schedule and source-control tests; no ndnSIM claims."""
import csv,hashlib,json,pathlib,sys,unittest
ROOT=pathlib.Path(__file__).resolve().parents[3]
SCRIPT=ROOT/'hcraf/episode/scripts'
sys.path.insert(0,str(SCRIPT))
import run_stage1am_f3_bottleneck_relocation_dev as run
import verify_stage1am_f3_bottleneck_relocation_dev as verify
CPP=(ROOT/'hcraf/episode/src/hcraf-stage1am-f3-bottleneck-relocation-dev.cpp')

class ContractChecks(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.matrix,cls.sites=run.matrix()
 def test_counts(self):
  self.assertEqual(len(self.matrix),216)
  self.assertEqual(sum(int(r['instrumented']) for r in self.matrix),192)
 def test_shard_count(self):
  for s in range(8):
   rr,_=run.shard_rows(s)
   self.assertEqual((len(rr),sum(int(r['instrumented']) for r in rr)),(27,24))
 def test_unique_run_ids(self):self.assertEqual(len({r['run_id'] for r in self.matrix}),216)
 def test_all_12_rng(self):self.assertEqual({int(r['rng_block']) for r in self.matrix},set(range(11901,11913)))
 def test_no_historical_rng(self):self.assertFalse({int(r['rng_block']) for r in self.matrix}&set(range(11801,11813)))
 def test_three_sites(self):
  self.assertEqual({r['intervention_location'] for r in self.matrix if r['intervention_location']!='NONE'},
                   {'PRODUCER_RETURN','MID_RETURN','RELAY_RETURN'})
 def test_loss_control_only(self):
  self.assertEqual(sum(r['loss_kind']=='PHY_RX_PACKET_ERROR' for r in self.matrix),27)
  self.assertTrue(all((r['loss_probability']=='0.15')==(r['loss_kind']=='PHY_RX_PACKET_ERROR') for r in self.matrix))
 def test_no_f3_label_columns(self):
  forbidden={'Congestion','FutureCongestion','F3_ready','future_congestion','training_ready','GO_FREEZE'}
  self.assertFalse(forbidden & set(self.matrix[0]))
 def test_future_science_flags_locked(self):
  self.assertEqual(run.LOCKS,{'Congestion':None,'FutureCongestion':None,'F3_ready':False,'GO_FREEZE':False,'training_ready':False})
 def test_all_plans_have_valid_sha(self):
  for row in self.matrix: self.assertTrue(run.locked_plan(row).is_file())
 def test_plans_same_within_group(self):
  grouped={}
  for r in self.matrix:
   key=(r['rng_block'],r['family']);s=r['schedule_sha256']
   self.assertEqual(grouped.setdefault(key,s),s)
  self.assertEqual(len(grouped),24)
 def test_malicious_shard_rejected(self):
  for s in (-1,8,100):
   with self.assertRaises(RuntimeError):run.shard_rows(s)
 def test_runtime_args_from_row(self):
  spec=run.simulation_args(self.matrix[0],pathlib.Path('/tmp/UNEXECUTED'))
  for fragment in ('--run=11901','--selectedSlot=0','--interventionReturnBps=6000000','--lossProbability=0.00',
          '--mode=LP_INDEPENDENT_COMPETITOR_NO_DROP'):
   self.assertIn(fragment,spec)
 def test_no_test_validation_workflow(self):
  txt=CPP.read_text()
  self.assertIn('holdout_partition\\":\\"DEVELOPMENT',txt)
 def test_cpp_uses_csv_lock(self):
  txt=CPP.read_text()
  self.assertIn('IMMUTABLE_V0517_CSV',txt)
  self.assertIn('OUTSIDE_IMMUTABLE_V0517_RELOCATION_MATRIX',txt)
  self.assertNotIn('run<11801',txt)
 def test_cpp_intervention_three_directions(self):
  txt=CPP.read_text()
  for tok in ('producerDown->SetDataRate(DataRate(producerReturnRate))',
     'midDown->SetDataRate(DataRate(midReturnRate))','relayDown->SetDataRate(DataRate(relayReturnRate))'):
   self.assertIn(tok,txt)
 def test_cpp_loss_at_selected_node1_device(self):
  txt=CPP.read_text()
  self.assertIn('lossReceiver->SetReceiveErrorModel(lossModel)',txt)
  self.assertIn('lossModel->AssignStreams(lossStream)',txt)
  self.assertIn('RecordRxDrop',txt)
 def test_cpp_no_official_labels(self):
  txt=CPP.read_text()
  self.assertIn('future_oracle_is_final_F3\\":false',txt)
  self.assertIn('GO_FREEZE\\":false',txt)
 def test_negative_control_zero_throttle(self):
  for row in self.matrix:
   if row['arm']=='ALL_RETURN_50M':
    self.assertEqual(row['intervention_return_bps'],'50000000')
 def test_sites_identity_has_all_slots(self):
  self.assertEqual({int(r['selected_slot']) for r in self.sites},{0,1,2})
 def test_future_censored_not_zero(self):
  txt=CPP.read_text()
  self.assertIn('path_reverse_fragment_unclassifiable_means_UNKNOWN',txt)
 def test_monitor_event_fields_declared(self):
  self.assertEqual(verify.EVENTS,{'QUEUE_ENQUEUE','QUEUE_DEQUEUE','QUEUE_DROP','PHY_TX_BEGIN','PHY_TX_END'})
 def test_unmonitored_control_count(self):
  self.assertEqual(sum(not int(r['instrumented']) for r in self.matrix),24)
 def test_build_script_path_unique(self):
  txt=(SCRIPT/'build_stage1am_f3_bottleneck_relocation_dev.sh').read_text()
  self.assertIn('hcraf-stage1am-f3-bottleneck-relocation-dev',txt)

if __name__=='__main__':unittest.main()
