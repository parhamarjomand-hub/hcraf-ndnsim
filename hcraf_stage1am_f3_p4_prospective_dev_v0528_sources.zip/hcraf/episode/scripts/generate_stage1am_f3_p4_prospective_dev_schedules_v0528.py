#!/usr/bin/env python3
"""Pure reproducible v0.52.8 DEVELOPMENT schedule generator.

No simulation, no P4 Validation/Test access, no scientific F3 labels.  The
three streams are copied byte-for-byte from the v0.52.4 prereg receipt.
"""
import argparse
import csv
from io import StringIO
import random
from pathlib import Path

STREAMS = {
    23101: (2118176799, 1770039620, 1833149678),
    23102: (205842241, 1463567773, 250903767),
    23103: (803288185, 1733246441, 624851160),
    23104: (196048441, 2049874237, 1215542229),
}
ORDER = sorted(STREAMS, key=lambda n: STREAMS[n][1])
# A split-internal, preregistered stream-based permutation prevents the
# erroneous modular rule from omitting a physical branch altogether.
SLOT = {seed: i % 3 for i, seed in enumerate(ORDER)}
FIELDNAMES = (
    "traffic_class", "sequence", "time_ns", "family", "rng_block", "split",
    "phase_label", "phase_nominal_ns", "phase_jitter_ns", "selected_slot",
    "load_level", "schedule_schema",
)
FAMILY = "P4_PROSPECTIVE"
SCHEMA = "HCRAF_F3_P4_PROSPECTIVE_DEVELOPMENT_V0528"
NS = 1_000_000_000


def filename(seed, load):
    return f"p4-development-seed-{seed}-slot-{SLOT[seed]}-{load}.csv"


def schedule(seed, load):
    if seed not in STREAMS or load not in {"low_control", "high_pressure"}:
        raise ValueError("P4P5_UNREGISTERED_DEVELOPMENT_SEED_OR_LOAD")
    rnd = random.Random(STREAMS[seed][0])
    result = []
    def put(kind, seq, at, phase, nominal, jitter):
        if not 2*NS <= at < 19*NS:
            raise AssertionError("P4P5_SCHEDULE_OUT_OF_BOUND")
        result.append(dict(zip(FIELDNAMES, (
            kind, seq, at, FAMILY, seed, "DEVELOPMENT", phase, nominal,
            jitter, SLOT[seed], load, SCHEMA))))
    # Twelve research interests, paired across load/telemetry/topology.
    # Distinct target jitter is obtained from the same seed on both loads.
    target = [int((2.49 + 4.0*p + 0.012*j)*NS) + rnd.randint(-4_000_000, 4_000_000)
              for p in range(4) for j in range(3)]
    for seq, t in enumerate(target):
        put("TARGET", seq, t, "P"+str(seq//3), 0, 0)
    if load == "high_pressure":
        # Four bursts of 24 competitors at ~1 ms spacing; 12-Mbps return
        # queues can experience real pressure because a 4096-byte Data
        # transmission occupies >2 ms at that rate. Research decisions
        # interleave the burst; timestamps are frozen before simulation.
        competitor = [int((2.46+4.0*p+0.001*j)*NS) + rnd.randint(-100_000,100_000)
                      for p in range(4) for j in range(24)]
    else:
        # Same 96-interest count, spread over 16 seconds: explicit load
        # control, never chosen using physical outcome observations.
        competitor = [int((2.35 + (16.10/95)*j)*NS) + rnd.randint(-10_000_000,10_000_000)
                      for j in range(96)]
    for seq, t in enumerate(competitor):
        put("INDEPENDENT_COMPETITOR",seq,t,"P"+str(seq//24),0,0)
    assert len(result)==108
    assert len({(x["traffic_class"],x["sequence"]) for x in result})==108
    return result


def render(seed, load):
    o=StringIO(newline="")
    writer=csv.DictWriter(o,fieldnames=FIELDNAMES,lineterminator="\n")
    writer.writeheader(); writer.writerows(schedule(seed,load))
    return o.getvalue().encode("ascii")


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--output-dir",required=True)
    args=p.parse_args()
    base=Path(args.output_dir)
    if base.exists() and any(base.iterdir()):
        raise SystemExit("REFUSE_OVERWRITE_LOCKED_PROSPECTIVE_SCHEDULES")
    base.mkdir(parents=True,exist_ok=True)
    for seed in sorted(STREAMS):
        for load in ("low_control","high_pressure"):
            (base/filename(seed,load)).write_bytes(render(seed,load))
    print("PASS_EIGHT_PROSPECTIVE_DEVELOPMENT_SCHEDULES_108_EACH",SLOT)


if __name__ == "__main__":
    main()
