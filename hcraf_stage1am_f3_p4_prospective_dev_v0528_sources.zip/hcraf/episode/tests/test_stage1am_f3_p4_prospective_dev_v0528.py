import pathlib
import sys
import unittest

HERE=pathlib.Path(__file__).resolve()
ROOT=HERE.parents[3]
sys.path.insert(0,str(ROOT/"hcraf/episode/scripts"))

from generate_stage1am_f3_p4_prospective_dev_schedules_v0528 import (
    STREAMS, SLOT, ORDER, render, schedule, filename,
)
from run_stage1am_f3_p4_prospective_dev_seed_v0528 import (
    plan, check_locked_schedules, build_command,
)


class ProspectiveDevelopment(unittest.TestCase):
    def test_only_four_development_seeds_and_three_physical_slots(self):
        self.assertEqual(set(STREAMS),(set(range(23101,23105))))
        self.assertEqual(set(SLOT.values()),{0,1,2})
        self.assertEqual(SLOT[23101],2)
        self.assertEqual(ORDER,[23102,23103,23101,23104])

    def test_prospective_schedules_are_immutable_and_paired(self):
        check_locked_schedules()
        for seed in STREAMS:
            lo=schedule(seed,"low_control")
            hi=schedule(seed,"high_pressure")
            self.assertEqual([r["time_ns"] for r in lo if r["traffic_class"]=="TARGET"],
                             [r["time_ns"] for r in hi if r["traffic_class"]=="TARGET"])
            self.assertNotEqual([r["time_ns"] for r in lo if r["traffic_class"]=="INDEPENDENT_COMPETITOR"],
                                [r["time_ns"] for r in hi if r["traffic_class"]=="INDEPENDENT_COMPETITOR"])
            self.assertEqual(len(lo),108)
            self.assertEqual(len(hi),108)

    def test_no_validation_or_heldout_schedule_generated(self):
        for bad in (22001,24101,25101):
            with self.assertRaises(ValueError):schedule(bad,"high_pressure")
        for bad in ("test","heldout","calibration"):
            with self.assertRaises(ValueError):schedule(23101,bad)

    def test_one_development_seed_only_twelve_factorial_cases(self):
        rows=plan()
        self.assertEqual(len(rows),12)
        self.assertEqual({x["seed"] for x in rows},{23101})
        self.assertEqual({x["selected_slot"] for x in rows},{2})
        self.assertEqual({x["site"] for x in rows},{"producer_egress","transit_middle","consumer_ingress"})
        self.assertEqual({x["load"] for x in rows},{"low_control","high_pressure"})
        self.assertEqual({x["telemetry"] for x in rows},{"off","on_20ms"})
        for r in rows:
            command=build_command(r,pathlib.Path("/tmp/p4-dev-fixture"))
            self.assertIn("--run=23101",command)
            self.assertIn("--technicalQueueMaxPackets=12",command)
            self.assertIn("--scheduleFamily=P4_PROSPECTIVE",command)
            self.assertNotIn("25101",command)
            self.assertNotIn("24101",command)

    def test_cpp_snapshots_exclude_future_and_mark_missing(self):
        cpp=ROOT/"hcraf/episode/src/hcraf-stage1am-f3-p4-prospective-dev-v0528.cpp"
        code=cpp.read_text()
        self.assertIn("feature_missing_sources",code)
        self.assertIn("100000000ULL",code)
        self.assertIn("STALE_GT_100MS",code)
        self.assertIn("UNRECEIVED",code)
        self.assertIn('holdout_partition\\\":\\\"DEVELOPMENT',code)
        self.assertNotIn('holdout_partition\\\":\\\"CALIBRATION',code)


if __name__=="__main__":unittest.main()
