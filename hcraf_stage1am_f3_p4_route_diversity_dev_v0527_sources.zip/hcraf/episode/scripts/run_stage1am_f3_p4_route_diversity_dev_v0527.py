#!/usr/bin/env python3
"""Eight historical-fixture, DEV-only checks for selected path slots 1 and 2.

No P4 prospective seed is executed, and no F3 feature/label is constructed.
"""
import argparse
from collections import Counter
import json
import pathlib
import subprocess
import zipfile

from run_stage1am_f3_future_path_queue_calibration_v0521 import (
    ROOT, LOCKS, matrix, locked_plan, assert_send_plan, check,
)
from run_stage1am_f3_queue_telemetry_smoke_v0522 import (
    BIN, spec, verify_transport,
)

DEST = ROOT / "episode_output/stage1am_f3_p4_route_diversity_dev_v0527"
ARMS = {
    "PRODUCER_RETURN_12M": ("PRODUCER_RETURN", "producer"),
    "MID_RETURN_12M": ("MID_RETURN", "mid"),
    "RELAY_RETURN_12M": ("RELAY_RETURN", "relay"),
}
SLOTS = ((22002, 1), (22003, 2))
CAPACITY = 12
HISTORICAL = "C_STAGGERED_BURSTS"
RESERVED = set(range(23101, 23105)) | set(range(24101, 24105)) | set(range(25101, 25105))
ROLE_KEYS = (("selected_relay_node_id", "relay"),
             ("selected_mid_node_id", "mid"),
             ("selected_producer_node_id", "producer"))


def fixtures():
    rows, _ = matrix()
    selected = [r for r in rows if r["arm"] in ARMS
                and r["family"] == HISTORICAL
                and r["rng_block"] in ("22002", "22003")
                and r["instrumented"] == "1"]
    check(len(selected) == 6, "P4P4_EXPECT_EXACTLY_SIX_HISTORICAL_ROWS")
    seen = set()
    for r in selected:
        intervention, _ = ARMS[r["arm"]]
        key = (int(r["rng_block"]), r["arm"])
        check(key not in seen, "P4P4_DUPLICATED_FIXTURE"); seen.add(key)
        expected = dict(SLOTS)[key[0]]
        check(r["split"] == "CALIBRATION" and r["selected_slot"] == str(expected)
              and r["seed"] == "17" and r["intervention_location"] == intervention
              and r["intervention_return_bps"] == "12000000"
              and key[0] not in RESERVED, "P4P4_HISTORICAL_ROUTE_FIXTURE_MISMATCH")
    return sorted(selected, key=lambda r: (int(r["rng_block"]), tuple(ARMS).index(r["arm"])))


def run_plan(rows):
    plan = []
    for row in rows:
        plan.append((row, "baseline", False))
        if row["arm"] == "MID_RETURN_12M":
            plan.append((row, "telemetry20", True))
    check(len(plan) == 8, "P4P4_EXACTLY_EIGHT_ENGINEERING_RUNS_REQUIRED")
    return plan


def physical_witness(dest, config, expected_role):
    """Independently recount raw queue-drop events, never non-queue losses."""
    senders = {int(config[k]): role for k, role in ROLE_KEYS}
    check(len(senders) == 3, "P4P4_NONUNIQUE_SELECTED_SENDER_IDENTITIES")
    physical = dest / "pathwide_witness_b.jsonl"
    check(physical.is_file(), "P4P4_NO_INDEPENDENT_B_WITNESS")
    by_role = Counter()
    enqueues = Counter()
    maximum = Counter()
    cumulative = {}
    total_physical_drops = 0
    events = 0
    with physical.open() as f:
        for line in f:
            e = json.loads(line); events += 1
            check(e["schema_version"] == "PATHWIDE_WITNESS_B.1" and e["monitor_id"] == "B",
                  "P4P4_UNTRUSTED_WITNESS_SCHEMA")
            node, dev = int(e["node_id"]), int(e["device_index"])
            kind = e["event_type"]
            val = int(e["drop_packets_cumulative"])
            prior = cumulative.get((node, dev), 0)
            check(val >= prior, "P4P4_WITNESS_COUNTER_DECREASED")
            delta = val-prior
            check(delta == (1 if kind == "QUEUE_DROP" else 0),
                  "P4P4_WITNESS_DROP_TYPE_AND_CUMULATIVE_DISAGREE")
            cumulative[(node, dev)] = val
            if kind == "QUEUE_DROP":
                total_physical_drops += 1
            if node in senders and dev == 0:
                role = senders[node]
                maximum[role] = max(maximum[role], int(e["queue_packets"]))
                if kind == "QUEUE_ENQUEUE": enqueues[role] += 1
                if kind == "QUEUE_DROP": by_role[role] += 1
    check(events > 0, "P4P4_WITNESS_EMPTY")
    counts = {r: by_role[r] for r in ("relay", "mid", "producer")}
    for node, role in senders.items():
        check(counts[role] == cumulative.get((node, 0), 0),
              "P4P4_TARGET_ROLE_DROP_CUMULATIVE_MISMATCH")
    target = counts[expected_role]
    other = sum(counts.values()) - target
    return {
        "physical_independent_source": "PATHWIDE_WITNESS_B.1",
        "selected_role_sender_node_ids": {role: node for node, role in senders.items()},
        "selected_device_index": 0,
        "witness_events_read": events,
        "target_role": expected_role,
        "physical_drops_by_role": counts,
        "enqueues_by_role": {r: enqueues[r] for r in counts},
        "max_queue_packets_by_role": {r: maximum[r] for r in counts},
        "all_devices_physical_queue_drops": total_physical_drops,
        "strict_exclusive_real_queue_drop": target > 0 and other == 0 and total_physical_drops == target,
        "nonqueue_receive_failures_excluded": True,
    }


def check_decisions(dest, config):
    p = dest / "events.jsonl.decisions.jsonl"
    check(p.is_file(), "P4P4_NO_RESEARCH_DECISIONS")
    count = 0
    with p.open() as f:
        for line in f:
            d = json.loads(line)
            check(d["node_id"] == 1 and
                  d["name"].startswith(("/hcraf/pilot/", "/hcraf/competitor/")),
                  "P4P4_NDN_TELEMETRY_CONTROL_INTEREST_CONTAMINATION")
            chosen = [c for c in d["candidates"] if c["routing_cost"] == 1]
            check(len(chosen) == 1 and chosen[0]["face_id"] == config["selected_face_id"],
                  "P4P4_SELECTED_FACE_REAL_FIB_MAPPING_MISMATCH")
            count += 1
    check(count == 108, "P4P4_HISTORICAL_DECISION_COUNT_CHANGED")
    return count


def verify_predecision_telemetry(dest, config):
    receipts = {}
    with (dest / "queue_telemetry_receipts.jsonl").open() as f:
        for line in f:
            r = json.loads(line)
            key = (r["source_node_id"], r["report_id"])
            check(key not in receipts and r["sample_ns"] <= r["receipt_ns"],
                  "P4P4_INVALID_TELEMETRY_RECEIPT")
            receipts[key] = r
    checked = 0
    with (dest / "queue_telemetry_decisions.jsonl").open() as f:
        for line in f:
            d = json.loads(line)
            nodes = set()
            for item in d["feature_evidence"]:
                node = item["source_node_id"]
                key = (node, item["report_id"])
                check(key in receipts, "P4P4_EVIDENCE_REFERENCES_UNKNOWN_NDN_REPORT")
                r = receipts[key]
                check(r["receipt_ns"] <= d["decision_ns"] and
                      0 <= d["decision_ns"]-r["sample_ns"] <= 100_000_000,
                      "P4P4_FEATURE_FUTURE_LEAK_OR_STALE_REPORT")
                nodes.add(node); checked += 1
            check(nodes == {int(config[k]) for k, _ in ROLE_KEYS},
                  "P4P4_NOT_THREE_SELECTED_ROLE_REPORTS")
    check(checked == 324 and len(receipts) > 0,
          "P4P4_TELEMETRY_COVERAGE_BELOW_EXPECTED")
    return {"real_ndn_receipts": len(receipts),
            "predecision_role_reports_verified": checked,
            "maximum_feature_age_ms": 100,
            "feature_uses_future_events": False}


def run_one(row, profile, enabled):
    slot = int(row["selected_slot"])
    arm = row["arm"]
    intervention, role = ARMS[arm]
    dest = DEST / ("slot_%d" % slot) / arm / profile
    dest.mkdir(parents=True, exist_ok=False)
    command = spec(row, dest, 20, enabled) + " --technicalQueueMaxPackets=12"
    (dest / "command.txt").write_text(command + "\n")
    (dest / "P4P4_HISTORICAL_FIXTURE.json").write_text(json.dumps({
        "old_traffic_fixture_row": row,
        "technical_global_queue_cap_outside_v0520": CAPACITY,
        "not_an_official_calibration_sample": True,
        "not_P4_development_sample": True,
        "no_P4_reserved_seed_consumed": True,
        **LOCKS, "heldout_release_authorized": False,
    }, indent=2) + "\n")
    with (dest / "simulator.log").open("w") as f:
        subprocess.run(["/usr/bin/time", "-f", "wall_seconds=%e\\nmax_rss_kib=%M",
                        "-o", str(dest / "resource_usage.txt"),
                        "python3", "./waf", "--run-no-build", command],
                       cwd=ROOT / "episode_sources/ns-3", stdout=f,
                       stderr=subprocess.STDOUT, check=True)
    assert_send_plan(dest, locked_plan(row))
    config = json.loads((dest / "scenario.json").read_text())
    check(config["holdout_partition"] == "CALIBRATION" and
          config["selected_face_slot"] == slot and
          config["selected_face_id"] == 258+slot and
          config["phase_arm"] == arm and
          config["intervention_location"] == intervention and
          config["intervention_return_bps"] == 12_000_000 and
          config["queue_capacity_packets"] == CAPACITY and
          config["technical_queue_max_packets"] == CAPACITY and
          config["v0520_locked_reference_queue_capacity_packets"] == 20 and
          config["p3_dev_global_queue_cap_override_not_in_v0520_lock"] is True and
          config["telemetry_enabled"] is enabled,
          "P4P4_WRONG_ACTUAL_SIMULATOR_PHYSICAL_CONFIG")
    for k,v in LOCKS.items():
        check(config[k] is v, "P4P4_SIMULATOR_SCIENCE_LOCK_BROKEN:"+k)
    witness = physical_witness(dest, config, role)
    decisions = check_decisions(dest, config)
    transport = {"telemetry_enabled": enabled,
                 "verified": None if not enabled else False}
    if enabled:
        try:
            transport.update(verify_transport(dest, True))
            transport.update(verify_predecision_telemetry(dest, config))
            transport["verified"] = True
        except (RuntimeError, ValueError, KeyError, AssertionError, OSError) as exc:
            transport["failed_explicitly"] = str(exc)
    else:
        check(not (dest / "queue_telemetry_receipts.jsonl").exists(),
              "P4P4_BASELINE_CONTAMINATED")
    result = {"rng_block": int(row["rng_block"]),
              "selected_face_slot": slot, "arm": arm,
              "profile": profile, "telemetry_enabled": enabled,
              "physical": witness, "research_decisions": decisions,
              "transport": transport,
              "official_F3_labels_constructed": 0,
              "training_executed": False,
              "heldout_runs_executed": 0,
              **LOCKS, "heldout_release_authorized": False}
    (dest / "P4P4_ROUTE_WITNESS_AUDIT.json").write_text(json.dumps(result, indent=2)+"\n")
    return result


def aggregate(results):
    check(len(results) == 8, "P4P4_EXPECT_EXACTLY_EIGHT_ENGINEERING_RESULTS")
    bases = [r for r in results if r["profile"] == "baseline"]
    telemetry = [r for r in results if r["profile"] == "telemetry20"]
    check(len(bases) == 6 and len(telemetry) == 2,
          "P4P4_MISSING_SCHEDULED_CONTROLS")
    check({(r["selected_face_slot"],r["arm"]) for r in bases} ==
          {(slot,arm) for _,slot in SLOTS for arm in ARMS},
          "P4P4_MISSING_LOCATION_BY_SLOT")
    check({r["selected_face_slot"] for r in telemetry} == {1,2} and
          {r["arm"] for r in telemetry} == {"MID_RETURN_12M"},
          "P4P4_WRONG_TELEMETRY_TRANSPORT_CONTROLS")
    physical_pass = all(r["physical"]["strict_exclusive_real_queue_drop"] for r in bases)
    transport_pass = all(r["transport"].get("verified") is True and
                         r["physical"]["strict_exclusive_real_queue_drop"] for r in telemetry)
    return {
        "status": "PASS_DEV_THREE_PHYSICAL_SLOTS_ONLY" if physical_pass and transport_pass
                  else "NO_GO_DEV_PHYSICAL_ROUTE_DIVERSITY_UNVERIFIED",
        "physical_slot_1_2_mapping_pass": physical_pass,
        "telemetry_slot_1_2_delivery_and_causality_pass": transport_pass,
        "prior_slot_0_producer_from_P3_run": "44354340404",
        "prior_slot_0_mid_relay_from_P4P3_run": "44458755203",
        "no_repeat_of_previously_verified_slot_0": True,
        "simulations": len(results),
        "distinct_new_selected_slots": [1,2],
        "P4_v0524_independent_seeds_consumed": 0,
        "P4_144_run_executor_authorized": False,
        "next_gate": "P4_DEVELOPMENT_SCHEDULE_AND_NEW_CXX_SEED_SUPPORT_EXECUTOR_LOCK",
        "original_v0520_protocol_unchanged": True,
        "original_v0524_protocol_unchanged": True,
        "official_F3_labels_constructed": 0,
        "heldout_runs_executed": 0,
        "training_executed": False,
        **LOCKS, "heldout_release_authorized": False,
        "results": results,
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--preflight-only", action="store_true")
    args = p.parse_args()
    plan = run_plan(fixtures())
    if args.preflight_only:
        print(json.dumps({
            "status": "PASS_EIGHT_HISTORICAL_MULTI_ROUTE_FIXTURES_SELECTED_ONLY",
            "plan": [{"rng_block": int(r["rng_block"]), "selected_face_slot": int(r["selected_slot"]),
                      "arm": r["arm"], "profile": name} for r,name,_ in plan],
            "P4_new_reserved_seeds_used": 0,
            "P4_144_run_executor_authorized": False,
            "heldout_runs_executed": 0,
            **LOCKS, "heldout_release_authorized": False,
        },indent=2))
        return
    check((ROOT / "episode_sources/ns-3/build/scratch" / BIN).is_file(),
          "P4P4_ACTUAL_NDNSIM_BINARY_NOT_BUILT")
    check(not DEST.exists(), "P4P4_REFUSE_TO_OVERWRITE_PREVIOUS_RUN")
    results=[]
    for row,name,enabled in plan:
        r=run_one(row,name,enabled)
        results.append(r)
        print("P4P4_COMPLETED",r["rng_block"],r["arm"],name,
              r["physical"]["physical_drops_by_role"], flush=True)
    report=aggregate(results)
    (DEST / "P4P4_ROUTE_DIVERSITY_SUMMARY.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps({k:v for k,v in report.items() if k!="results"},indent=2))


if __name__=="__main__":
    main()
