"""No-simulator checks for P4/P4 eight-run multi-path engineering gate."""
import unittest

from run_stage1am_f3_p4_route_diversity_dev_v0527 import (
    ARMS, RESERVED, SLOTS, aggregate, fixtures, run_plan,
)


def synthetic(pass_physical=True, pass_transport=True):
    data = []
    for rng, slot in SLOTS:
        for arm in ARMS:
            data.append({"rng_block": rng, "selected_face_slot": slot,
                         "arm": arm, "profile": "baseline",
                         "physical": {"strict_exclusive_real_queue_drop": pass_physical},
                         "transport": {"verified": None}})
            if arm == "MID_RETURN_12M":
                data.append({"rng_block": rng, "selected_face_slot": slot,
                             "arm": arm, "profile": "telemetry20",
                             "physical": {"strict_exclusive_real_queue_drop": pass_physical},
                             "transport": {"verified": pass_transport}})
    return data


class RouteDiversitySafetyTests(unittest.TestCase):
    def test_run_plan_only_unseen_old_routes_and_eight_runs(self):
        rows = fixtures()
        plan = run_plan(rows)
        self.assertEqual(len(rows), 6)
        self.assertEqual(len(plan), 8)
        self.assertEqual({int(row["selected_slot"]) for row,_,_ in plan}, {1,2})
        self.assertEqual({int(row["rng_block"]) for row,_,_ in plan}, {22002,22003})
        self.assertTrue(all(int(row["rng_block"]) not in RESERVED for row,_,_ in plan))
        self.assertEqual(sum(enabled for _,_,enabled in plan), 2)

    def test_no_go_if_any_physical_mapping_missing(self):
        summary = aggregate(synthetic(pass_physical=False))
        self.assertTrue(summary["status"].startswith("NO_GO"))

    def test_no_go_if_actual_telemetry_not_causal(self):
        summary = aggregate(synthetic(pass_transport=False))
        self.assertTrue(summary["status"].startswith("NO_GO"))

    def test_good_test_fixture_is_never_scientific_authorization(self):
        s = aggregate(synthetic())
        self.assertTrue(s["physical_slot_1_2_mapping_pass"])
        self.assertTrue(s["telemetry_slot_1_2_delivery_and_causality_pass"])
        self.assertEqual(s["status"], "PASS_DEV_THREE_PHYSICAL_SLOTS_ONLY")
        self.assertFalse(s["P4_144_run_executor_authorized"])
        self.assertEqual(s["P4_v0524_independent_seeds_consumed"], 0)
        self.assertEqual(s["official_F3_labels_constructed"], 0)
        self.assertFalse(s["GO_FREEZE"])
        self.assertFalse(s["heldout_release_authorized"])

    def test_no_shortcut_with_missing_control(self):
        with self.assertRaises(RuntimeError):
            aggregate(synthetic()[:7])


if __name__=="__main__":
    unittest.main()
