#!/usr/bin/env python3
"""Deterministic 288-cell prospective split; no Release, no simulations."""
import csv
from hashlib import sha256
import io
from pathlib import Path

from generate_stage1am_f3_p4_temporal_schedule_v05212 import (
    PARTITIONS, MATRIX, assignments, commitments, locked_filename,
)


COLS=("partition","seed","topology_profile","load_profile","telemetry_profile",
      "selected_slot","randomized_pressure_regime","traffic_stream_seed",
      "routing_stream_seed","telemetry_stream_seed","locked_schedule_filename",
      "locked_schedule_sha256","eligible_after_separate_frozen_executor",
      "execution_authorized_now","official_training_authorized_now",
      "heldout_release_authorized_now")
SITES=("producer_egress","transit_middle","consumer_ingress")
LOADS=("low_control","high_pressure")
TELEMETRIES=("off","on_20ms")


def rows():
    hashes=commitments()["SHA256_by_filename"]
    result=[]
    for partition,seeds in PARTITIONS.items():
        mapping=assignments(partition)
        for seed in seeds:
            a=mapping[seed]
            for site in SITES:
                for load in LOADS:
                    for telemetry in TELEMETRIES:
                        filename=locked_filename(partition,seed,load)
                        result.append(dict(partition=partition,seed=seed,
                            topology_profile=site,load_profile=load,
                            telemetry_profile=telemetry,
                            selected_slot=a["selected_slot"],
                            randomized_pressure_regime=a["temporal_regime"],
                            traffic_stream_seed=a["traffic_stream_seed"],
                            routing_stream_seed=a["routing_stream_seed"],
                            telemetry_stream_seed=a["telemetry_stream_seed"],
                            locked_schedule_filename=filename,
                            locked_schedule_sha256=hashes[filename],
                            eligible_after_separate_frozen_executor=("true" if partition=="DEVELOPMENT" else "false"),
                            execution_authorized_now="false",
                            official_training_authorized_now="false",
                            heldout_release_authorized_now="false"))
    assert len(result)==288
    return result


def render():
    out=io.StringIO(newline="")
    writer=csv.DictWriter(out,fieldnames=COLS,lineterminator="\n")
    writer.writeheader();writer.writerows(rows())
    return out.getvalue().encode()


def main():
    MATRIX.parent.mkdir(parents=True,exist_ok=True)
    if MATRIX.exists():
        assert MATRIX.read_bytes()==render(),"REFUSE_OVERWRITE_LOCKED_MATRIX"
    else:
        MATRIX.write_bytes(render())
    print("PASS_P4P9_288_MATRIX_DEV_96_VALIDATION_96_HELDOUT_96_EXECUTE_ZERO")


if __name__=="__main__":main()
