#!/usr/bin/env python3
"""P4/P9 pre-registered deterministic temporal-regime schedules; NO simulations.

Four independent pressure shapes, two fresh seed blocks per regime in each
partition. Only DEVELOPMENT CSV bytes are emitted at the design-lock step.
"""
import csv
from hashlib import sha256
import io
import json
from pathlib import Path
import random


VERSION = "HCRAF-STAGE1AM-F3-P4-v0.52.12-TEMPORAL"
FAMILY = "P4_TEMPORAL_ORTHOGONAL"
SCHEMA = "HCRAF_F3_P4_TEMPORAL_ORTHOGONAL_V05212"
HEADER = ("traffic_class", "sequence", "time_ns", "family", "rng_block",
          "split", "phase_label", "phase_nominal_ns", "phase_jitter_ns",
          "selected_slot", "load_level", "schedule_schema")
REGIMES = ("EARLY", "LATE", "DOUBLE", "THREE_PULSE")
PARTITIONS = {
    "DEVELOPMENT": tuple(range(23301, 23309)),
    "VALIDATION": tuple(range(24301, 24309)),
    "HELDOUT": tuple(range(25301, 25309)),
}
# The order is a deterministic blocked Latin allocation of phases to distinct
# slots: 0/1 for early, 2/0 for late, 1/2 for double, 0/1 for three pulses.
ROUTE_SLOTS = (0, 1, 2, 0, 1, 2, 0, 1)
PHASE_ASSIGNS = ("EARLY", "EARLY", "LATE", "LATE", "DOUBLE", "DOUBLE",
                 "THREE_PULSE", "THREE_PULSE")
ROOT = Path(__file__).resolve().parents[3]
DOC = ROOT / "hcraf/episode/docs/1AM/F3_P4_TEMPORAL_ORTHOGONAL_v0.52.12"
PLANS = DOC / "plans"
MATRIX = DOC / "RUN_MATRIX_LOCKED_288_v05212.csv"
COMMITMENTS = DOC / "SCHEDULE_COMMITMENTS_48_v05212.json"


def stream_seed(partition, seed, purpose):
    digest = sha256((VERSION+":"+partition+":"+str(seed)+":"+purpose).encode()).digest()
    return (int.from_bytes(digest[:4], "big") & 0x7fffffff) or 1


def assignments(partition):
    assert partition in PARTITIONS
    ordered = sorted(PARTITIONS[partition], key=lambda s: (stream_seed(partition,s,"routing"),s))
    return {seed: {"selected_slot": ROUTE_SLOTS[i],
                   "temporal_regime": PHASE_ASSIGNS[i],
                   "traffic_stream_seed":stream_seed(partition,seed,"traffic"),
                   "routing_stream_seed":stream_seed(partition,seed,"routing"),
                   "telemetry_stream_seed":stream_seed(partition,seed,"telemetry")}
            for i, seed in enumerate(ordered)}


def locked_filename(partition, seed, load):
    info=assignments(partition)[seed]
    return "p4-v05212-"+partition.lower()+"-seed-"+str(seed)+"-slot-"+str(info["selected_slot"])+"-"+load+".csv"


def competitor_nominal(regime, sequence):
    assert 0 <= sequence < 96
    if regime == "EARLY":
        return 2_160_000_000 + sequence*3_600_000
    if regime == "LATE":
        return 2_450_000_000 + sequence*3_600_000
    if regime == "DOUBLE":
        return (2_170_000_000 + sequence*3_600_000 if sequence < 48
                else 2_560_000_000 + (sequence-48)*3_600_000)
    assert regime == "THREE_PULSE"
    anchors = (2_120_000_000,2_410_000_000,2_680_000_000)
    return anchors[sequence//32] + (sequence%32)*3_100_000


def events(partition, seed, load):
    assert partition in PARTITIONS and seed in PARTITIONS[partition]
    assert load in ("low_control", "high_pressure")
    info=assignments(partition)[seed]
    # A separate independent jitter generator by traffic class preserves
    # identical target sends under paired low/high and telemetry off/on.
    target_rng=random.Random(stream_seed(partition,seed,"target_jitter"))
    competitor_rng=random.Random(stream_seed(partition,seed,"competitor_jitter_"+load))
    out=[]
    for seq in range(12):
        nominal=2_320_000_000 + seq*30_000_000
        jitter=target_rng.randint(-280_000,280_000)
        out.append(dict(traffic_class="TARGET",sequence=seq,time_ns=nominal+jitter,
                        family=FAMILY,rng_block=seed,split=partition,
                        phase_label="P"+str(seq//3),phase_nominal_ns=nominal,
                        phase_jitter_ns=jitter,selected_slot=info["selected_slot"],
                        load_level=load,schedule_schema=SCHEMA))
    for seq in range(96):
        nominal=(2_200_000_000 + seq*168_000_000 if load=="low_control"
                 else competitor_nominal(info["temporal_regime"],seq))
        jitter=competitor_rng.randint(-350_000,350_000)
        out.append(dict(traffic_class="INDEPENDENT_COMPETITOR",sequence=seq,
                        time_ns=nominal+jitter,family=FAMILY,rng_block=seed,
                        split=partition,phase_label="P"+str(seq//24),
                        phase_nominal_ns=nominal,phase_jitter_ns=jitter,
                        selected_slot=info["selected_slot"],load_level=load,
                        schedule_schema=SCHEMA))
    out.sort(key=lambda r:(r["time_ns"],r["traffic_class"],r["sequence"]))
    assert len(out)==108 and all(2_000_000_000 <= r["time_ns"] < 20_000_000_000 for r in out)
    assert len({(r["traffic_class"],r["sequence"]) for r in out})==108
    return out


def render(partition, seed, load):
    buff=io.StringIO(newline="")
    writer=csv.DictWriter(buff,fieldnames=HEADER,lineterminator="\n")
    writer.writeheader();writer.writerows(events(partition,seed,load))
    return buff.getvalue().encode()


def commitments():
    # All 48 SHA commitments are generated deterministically. Crucially only
    # DEVELOPMENT schedule CSVs are placed in the source archive; no hidden
    # VALIDATION/HELDOUT output is simulated, analyzed, or opened.
    records={}
    for partition,seeds in PARTITIONS.items():
        for seed in seeds:
            for load in ("low_control","high_pressure"):
                name=locked_filename(partition,seed,load)
                records[name]=sha256(render(partition,seed,load)).hexdigest()
    return dict(stage="v0.52.12_P4_P9_SCHEDULE_PRECOMMITMENT_ONLY",
                schema=SCHEMA, parent_p4p8_run_id=44581661928,
                parent_p4p8_artifact_id=14558599038,
                parent_p4p8_artifact_sha256="b490ce65e2ada71d33b70d5e8708ec4985fd4e72e0ee7b6c936fef23875cee91",
                schedules_committed=48, emitted_development_schedules=16,
                validation_and_heldout_schedules_emitted=0,
                all_288_simulations_executable_now=False,
                independent_new_seed_blocks=24,
                original_v0520_and_v0524_unchanged=True,
                original_v0529_NO_GO_unchanged=True,
                SHA256_by_filename=records,
                Congestion=None,FutureCongestion=None,F3_ready=False,
                GO_FREEZE=False,training_ready=False,
                heldout_release_authorized=False)


def main():
    # Called during package construction, not a simulated run.
    PLANS.mkdir(parents=True,exist_ok=True)
    for seed in PARTITIONS["DEVELOPMENT"]:
        for load in ("low_control","high_pressure"):
            path=PLANS/locked_filename("DEVELOPMENT",seed,load)
            if path.exists():
                assert path.read_bytes()==render("DEVELOPMENT",seed,load),"REFUSE_OVERWRITE_LOCKED_CSV"
            else:
                path.write_bytes(render("DEVELOPMENT",seed,load))
    payload=json.dumps(commitments(),ensure_ascii=False,sort_keys=True,indent=2)+"\n"
    if COMMITMENTS.exists():
        assert COMMITMENTS.read_text()==payload,"REFUSE_OVERWRITE_COMMITMENTS"
    else:
        COMMITMENTS.write_text(payload)
    print("PASS_P4P9_SCHEDULE_LOCK_16_DEV_CSV_32_RESERVED_HASH_ONLY")


if __name__=="__main__":main()
