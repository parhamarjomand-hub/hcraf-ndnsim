#!/usr/bin/env python3
"""P4/P9 guarantees orthogonality design, sealed partitions and immutable CSVs."""
from collections import Counter
from hashlib import sha256
import unittest

from generate_stage1am_f3_p4_temporal_schedule_v05212 import (
    PARTITIONS, REGIMES, PLANS, MATRIX, COMMITMENTS,
    assignments, commitments, events, locked_filename, render,
)
from generate_stage1am_f3_p4_temporal_matrix_v05212 import rows, render as render_matrix


class TestTemporalPrecommit(unittest.TestCase):
    def test_eight_independent_seeds_per_partition(self):
        self.assertEqual(len(PARTITIONS),3)
        self.assertEqual(len(set().union(*map(set,PARTITIONS.values()))),24)
        self.assertTrue(all(len(v)==8 for v in PARTITIONS.values()))
        self.assertTrue(all(not (set(v)&set({23101,23201,23202,23203,23204,
                                           24101,24102,24103,24104,
                                           25101,25102,25103,25104}))
                            for v in PARTITIONS.values()))

    def test_each_partition_balances_four_pressure_regimes_and_route_diversity(self):
        for partition in PARTITIONS:
            values=list(assignments(partition).values())
            self.assertEqual(Counter(v['temporal_regime'] for v in values),
                             {regime:2 for regime in REGIMES})
            self.assertEqual(Counter(v['selected_slot'] for v in values),{0:3,1:3,2:2})
            by_phase={p:{v['selected_slot'] for v in values if v['temporal_regime']==p}
                      for p in REGIMES}
            self.assertTrue(all(len(slots)==2 for slots in by_phase.values()))

    def test_target_send_schedule_is_paired_and_all_names_unique(self):
        for partition,seeds in PARTITIONS.items():
            for seed in seeds:
                low=events(partition,seed,'low_control')
                high=events(partition,seed,'high_pressure')
                for records in (low,high):
                    self.assertEqual(len(records),108)
                    self.assertEqual(sum(r['traffic_class']=='TARGET' for r in records),12)
                    self.assertEqual(sum(r['traffic_class']=='INDEPENDENT_COMPETITOR' for r in records),96)
                    self.assertEqual(len({(r['traffic_class'],r['sequence']) for r in records}),108)
                    self.assertTrue(all(r['split']==partition for r in records))
                self.assertEqual([r['time_ns'] for r in low if r['traffic_class']=='TARGET'],
                                 [r['time_ns'] for r in high if r['traffic_class']=='TARGET'])

    def test_development_only_emitted_and_sha_exact(self):
        manifest=commitments()
        self.assertEqual(len(manifest['SHA256_by_filename']),48)
        self.assertTrue(manifest['original_v0529_NO_GO_unchanged'])
        for partition,seeds in PARTITIONS.items():
            for seed in seeds:
                for load in ('low_control','high_pressure'):
                    name=locked_filename(partition,seed,load)
                    self.assertEqual(manifest['SHA256_by_filename'][name],
                                     sha256(render(partition,seed,load)).hexdigest())
                    self.assertEqual((PLANS/name).exists(),partition=='DEVELOPMENT')
                    if partition=='DEVELOPMENT':
                        self.assertEqual((PLANS/name).read_bytes(),render(partition,seed,load))
        self.assertEqual(COMMITMENTS.read_text(), __import__('json').dumps(manifest,
            ensure_ascii=False,sort_keys=True,indent=2)+'\n')

    def test_matrix_has_zero_execution_authorizations(self):
        self.assertEqual(MATRIX.read_bytes(),render_matrix())
        cells=rows()
        self.assertEqual(len(cells),288)
        self.assertEqual(Counter(row['partition'] for row in cells),
                         {'DEVELOPMENT':96,'VALIDATION':96,'HELDOUT':96})
        self.assertEqual(sum(row['eligible_after_separate_frozen_executor']=='true'
                             for row in cells),96)
        self.assertTrue(all(row['execution_authorized_now']=='false' and
                            row['official_training_authorized_now']=='false' and
                            row['heldout_release_authorized_now']=='false' for row in cells))


if __name__=='__main__':unittest.main()
