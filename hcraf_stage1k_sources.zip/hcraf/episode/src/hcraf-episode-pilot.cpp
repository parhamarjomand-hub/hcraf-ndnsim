// Controlled ndnSIM integration tests, NOT an HCRAF performance experiment.
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/ndnSIM-module.h"
#include "ns3/ndnSIM/apps/ndn-app.hpp"
#include "ns3/ndnSIM/model/ndn-l3-protocol.hpp"
#include "ns3/ndnSIM/NFD/daemon/fw/forwarder.hpp"
#include <fstream>
#include "hcraf-link-monitor.hpp"
#include <set>
#include "ns3/error-model.h"
#include <stdexcept>

namespace ns3 {
class HcrafRequester : public ns3::ndn::App {
public:
  static TypeId GetTypeId() {
    static TypeId tid = TypeId("ns3::HcrafRequester").SetParent<ns3::ndn::App>()
      .AddConstructor<HcrafRequester>();
    return tid;
  }
  void Configure(const std::string& mode, const std::string& output) {
    m_mode = mode;
    m_out.open(output);
    if (!m_out) throw std::runtime_error("Cannot open consumer event file");
  }
  void OnData(std::shared_ptr<const ::ndn::Data> data) override {
    ns3::ndn::App::OnData(data);
    m_out << "{\"event\":\"DATA\",\"time_ns\":" << Simulator::Now().GetNanoSeconds()
          << ",\"name\":" << hcraf::Recorder::quote(data->getName().toUri())
          << ",\"payload_bytes\":" << data->getContent().value_size() << "}\n";
    m_out.flush();
  }
  void OnNack(std::shared_ptr<const ::ndn::lp::Nack> nack) override {
    ns3::ndn::App::OnNack(nack);
    m_out << "{\"event\":\"NACK\",\"time_ns\":" << Simulator::Now().GetNanoSeconds()
          << ",\"name\":" << hcraf::Recorder::quote(nack->getInterest().getName().toUri())
          << ",\"reason\":" << static_cast<int>(nack->getReason()) << "}\n";
    m_out.flush();
  }
protected:
  void StartApplication() override {
    ns3::ndn::App::StartApplication();
    const uint32_t rate = m_mode == "local-pressure" ? 600 : m_mode == "return-pressure" ? 30 : 5;
    for (uint32_t i = 0; i < 8 * rate; ++i)
      Simulator::Schedule(NanoSeconds(1000000000LL + int64_t(i) * 1000000000LL / rate),
                          &HcrafRequester::Send, this, i);
  }
private:
  void Send(uint32_t sequence) {
    if (!m_active) return;
    auto interest = std::make_shared<::ndn::Interest>(::ndn::Name("/hcraf/pilot/" + std::to_string(sequence)));
    interest->setNonce(++m_nonce);
    interest->setInterestLifetime(::ndn::time::milliseconds(1000));
    interest->setCanBePrefix(false);
    interest->setMustBeFresh(true);
    m_out << "{\"event\":\"SEND\",\"time_ns\":" << Simulator::Now().GetNanoSeconds()
          << ",\"name\":" << hcraf::Recorder::quote(interest->getName().toUri())
          << ",\"nonce\":" << m_nonce << "}\n";
    m_out.flush();
    m_transmittedInterests(interest, this, m_face);
    m_appLink->onReceiveInterest(*interest);
  }
  uint32_t m_nonce = 1000;
  std::string m_mode;
  std::ofstream m_out;
};
NS_OBJECT_ENSURE_REGISTERED(HcrafRequester);

class HcrafResponder : public ns3::ndn::App {
public:
  static TypeId GetTypeId() {
    static TypeId tid = TypeId("ns3::HcrafResponder").SetParent<ns3::ndn::App>()
      .AddConstructor<HcrafResponder>();
    return tid;
  }
  void Configure(bool silent, double delay) { m_silent = silent; m_delay = delay; }
  void OnInterest(std::shared_ptr<const ::ndn::Interest> interest) override {
    ns3::ndn::App::OnInterest(interest);
    if (!m_active || m_silent) return;
    Simulator::Schedule(Seconds(m_delay), &HcrafResponder::Reply, this, interest->getName());
  }
protected:
  void StartApplication() override {
    ns3::ndn::App::StartApplication();
    ns3::ndn::FibHelper::AddRoute(GetNode(), "/hcraf", m_face, 0);
  }
private:
  void Reply(::ndn::Name name) {
    if (!m_active) return;
    auto data = std::make_shared<::ndn::Data>(name);
    data->setFreshnessPeriod(::ndn::time::milliseconds(1000));
    data->setContent(std::make_shared<::ndn::Buffer>(1024));
    // Same simulation signature convention as the official ndnSIM Producer.
    ::ndn::SignatureInfo signature(static_cast<::ndn::tlv::SignatureTypeValue>(255));
    data->setSignatureInfo(signature);
    ::ndn::EncodingEstimator estimator;
    ::ndn::EncodingBuffer encoder(estimator.appendVarNumber(0), 0);
    encoder.appendVarNumber(0);
    data->setSignatureValue(encoder.getBuffer());
    data->wireEncode();
    m_transmittedDatas(data, this, m_face);
    m_appLink->onReceiveData(*data);
  }
  bool m_silent = false;
  double m_delay = 0;
};
NS_OBJECT_ENSURE_REGISTERED(HcrafResponder);
}

static void RecordRxDrop(std::ofstream* out, ns3::Ptr<const ns3::Packet> packet) {
  *out << "{\"event\":\"PHY_RX_DROP\",\"node_id\":2,\"time_ns\":"
       << ns3::Simulator::Now().GetNanoSeconds() << ",\"packet_uid\":" << packet->GetUid() << "}\n";
  out->flush();
}

int main(int argc, char* argv[]) {
  using namespace ns3;
  std::string mode = "control", output = ".";
  double probeProbability = 0;
  uint32_t seed = 1;
  uint64_t run = 1;
  CommandLine cmd;
  cmd.AddValue("mode", "control/local-pressure/return-pressure/random-loss/receive-outage/no-route", mode);
  cmd.AddValue("output", "Existing output directory", output);
  cmd.AddValue("seed", "ns-3 random seed", seed);
  cmd.AddValue("run", "ns-3 random run number", run);
  cmd.AddValue("probeProbability", "Extra probe probability [0,1]", probeProbability);
  cmd.Parse(argc, argv);
  if (std::set<std::string>{"control","local-pressure","return-pressure","random-loss","receive-outage","no-route"}.count(mode) == 0)
    throw std::runtime_error("Unknown mode");
  const uint32_t rate = mode == "local-pressure" ? 600 : mode == "return-pressure" ? 30 : 5;
  RngSeedManager::SetSeed(seed); RngSeedManager::SetRun(run);
  NodeContainer nodes; nodes.Create(4);
  PointToPointHelper link;
  link.SetQueue("ns3::DropTailQueue<Packet>", "MaxSize", StringValue("20p"));
  link.SetDeviceAttribute("InterframeGap", TimeValue(NanoSeconds(0)));
  link.SetDeviceAttribute("DataRate", StringValue("10Mbps"));
  link.SetChannelAttribute("Delay", StringValue("10ms"));
  link.Install(nodes.Get(0), nodes.Get(1));
  link.SetDeviceAttribute("DataRate", StringValue("10Mbps"));
  auto primaryDevices = link.Install(nodes.Get(1), nodes.Get(2));
  auto routerDevice = DynamicCast<PointToPointNetDevice>(primaryDevices.Get(0));
  auto producerDevice = DynamicCast<PointToPointNetDevice>(primaryDevices.Get(1));
  const uint64_t forwardRate = mode == "local-pressure" ? 128000 : 10000000;
  const uint64_t returnRate = mode == "return-pressure" ? 128000 : 10000000;
  routerDevice->SetDataRate(DataRate(forwardRate));
  producerDevice->SetDataRate(DataRate(returnRate));
  auto errors = CreateObject<RateErrorModel>();
  errors->SetUnit(RateErrorModel::ERROR_UNIT_PACKET);
  errors->SetRate(mode == "random-loss" ? 0.25 : 0.0);
  errors->AssignStreams(71);
  producerDevice->SetReceiveErrorModel(errors);
  std::ofstream faults(output + "/fault_events.jsonl");
  if (!faults) throw std::runtime_error("Cannot open fault log");
  if (!producerDevice->TraceConnectWithoutContext("PhyRxDrop", MakeBoundCallback(&RecordRxDrop, &faults)))
    throw std::runtime_error("Missing PhyRxDrop trace");
  if (mode == "receive-outage") {
    Simulator::Schedule(Seconds(3), [errors, &faults]() {
      errors->SetRate(1.0); faults << "{\"event\":\"RX_OUTAGE_START\",\"time_ns\":3000000000}\n"; faults.flush();
    });
    Simulator::Schedule(Seconds(6), [errors, &faults]() {
      errors->SetRate(0.0); faults << "{\"event\":\"RX_OUTAGE_END\",\"time_ns\":6000000000}\n"; faults.flush();
    });
  }
  link.SetDeviceAttribute("DataRate", StringValue("512kbps"));
  link.SetChannelAttribute("Delay", StringValue("30ms"));
  auto secondaryDevices = link.Install(nodes.Get(1), nodes.Get(3));
  ns3::ndn::StackHelper stack; stack.setCsSize(0); stack.InstallAll();
  ns3::ndn::StrategyChoiceHelper::InstallAll("/hcraf", "/localhost/nfd/strategy/best-route");
  ns3::ndn::FibHelper::AddRoute(nodes.Get(0), "/hcraf", nodes.Get(1), 1);
  ns3::ndn::FibHelper::AddRoute(nodes.Get(1), "/hcraf", nodes.Get(2), 1);
  ns3::ndn::FibHelper::AddRoute(nodes.Get(1), "/hcraf", nodes.Get(3), 2);
  for (uint32_t n : {2u, 3u}) {
    if (mode == "no-route" && n == 2) continue;
    auto responder = CreateObject<HcrafResponder>(); responder->Configure(false, 0.0);
    nodes.Get(n)->AddApplication(responder); responder->SetStartTime(Seconds(0));
  }
  auto requester = CreateObject<HcrafRequester>();
  requester->Configure(mode, output + "/consumer_events.jsonl");
  nodes.Get(0)->AddApplication(requester); requester->SetStartTime(Seconds(0));
  auto l3 = nodes.Get(1)->GetObject<ns3::ndn::L3Protocol>();
  auto primary = l3->getFaceByNetDevice(primaryDevices.Get(0));
  auto secondary = l3->getFaceByNetDevice(secondaryDevices.Get(0));
  if (!primary || !secondary) throw std::runtime_error("Missing upstream Face mapping");
  auto forwarder = l3->getForwarder();
  forwarder->hcrafEnable(output + "/events.jsonl", nodes.Get(1)->GetId());
  auto probeRng = CreateObject<UniformRandomVariable>();
  probeRng->SetStream(20);
  forwarder->hcrafEnableProbing(probeProbability, [probeRng]() { return probeRng->GetValue(0.0, 1.0); });
  HcrafLinkMonitor linkMonitor(nodes, output + "/link_events.jsonl");
  forwarder->hcrafSetDecisionObserver([&linkMonitor](uint64_t id) { linkMonitor.Snapshot(id); });
  std::ofstream control(output + "/control_events.jsonl");
  if (!control) throw std::runtime_error("Cannot open control log");
  std::ofstream config(output + "/scenario.json");
  config << "{\"mode\":" << hcraf::Recorder::quote(mode)
    << ",\"collector_stage\":\"1K.1\",\"probe_stream\":20,\"probe_probability\":" << probeProbability
    << ",\"seed\":" << seed << ",\"run\":" << run
    << ",\"state_estimator_stage\":\"1I.1\",\"instrumentation_stage\":\"1G.1\",\"stop_ns\":13000000000"
    << ",\"traffic_start_ns\":1000000000,\"traffic_stop_exclusive_ns\":9000000000"
    << ",\"request_rate_per_s\":" << rate << ",\"planned_requests\":" << 8 * rate
    << ",\"primary_face_id\":" << primary->getId() << ",\"secondary_face_id\":" << secondary->getId()
    << ",\"primary_rate_bps\":" << forwardRate << ",\"return_rate_bps\":" << returnRate
    << ",\"secondary_rate_bps\":512000,\"link_rate_bps\":10000000"
    << ",\"primary_delay_ms\":10,\"secondary_delay_ms\":30,\"access_delay_ms\":10"
    << ",\"change_time_ns\":null"
    << ",\"initial_primary_cost\":1,\"secondary_cost\":2,\"changed_primary_cost\":3"
    << ",\"receive_error_probability\":" << (mode == "random-loss" ? 0.25 : 0.0)
    << ",\"receive_error_stream\":71,\"receive_error_unit\":\"PACKET\""
    << ",\"outage_start_ns\":" << (mode == "receive-outage" ? "3000000000" : "null")
    << ",\"outage_end_ns\":" << (mode == "receive-outage" ? "6000000000" : "null")
    << ",\"physical_link_down_tested\":false"
    << ",\"queue_capacity_packets\":20,\"interest_lifetime_ms\":1000,\"payload_bytes\":1024"
    << ",\"observed_node\":1,\"cs_packets\":0,\"consumer_retransmissions\":false"
    << ",\"purpose\":\"TWO_FACE_COLLECTOR_SMOKE_NOT_TRAINING\"}\n";
  config.flush();
  if (!config) throw std::runtime_error("Cannot write configuration");
  config.close();
  Simulator::Stop(Seconds(13)); Simulator::Run();
  forwarder->hcrafFinish(); forwarder->hcrafSetDecisionObserver({}); linkMonitor.Finish();
  Simulator::Destroy();
  return 0;
}
