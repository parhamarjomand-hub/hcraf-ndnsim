#!/usr/bin/env python3
import json,hashlib
from pathlib import Path
from run_stage1am_f3_p12r_dev_v05246 import matrix,OUT,LOCK,need,rows

def main():
 cases=matrix();vectors=set();n=0;primary=0;case_hashes={}
 for r in cases:
  d=OUT/r['seed']/(r['site']+'_'+r['load']+'_'+r['telemetry']);p=d/'case_receipt.json';x=json.loads(p.read_text());need(x['status']=='PASS_DEV_RAW_COLLECTION_QC_ONLY' and x['case']==r and x['decisions']==128 and all(x[k] is v for k,v in LOCK.items()),'AGG_CASE')
  need(all(hashlib.sha256((d/k).read_bytes()).hexdigest()==h for k,h in x['raw_file_sha256'].items()),'AGG_RAW_FILE_HASH')
  n+=128;case_hashes[str(d.relative_to(OUT))]=hashlib.sha256(p.read_bytes()).hexdigest()
  if r['telemetry']=='on_20ms':
   primary+=128;vectors.update(tuple(a['b1_all_twelve_native']) for a in rows(d/'p12v_native_local_12_at_decision.jsonl'))
 need(n==9216 and primary==4608 and len(case_hashes)==72,'AGG_COUNTS')
 status='PASS_72_P12R_DEV_RAW_COLLECTION_ONLY_NO_TRAINING' if len(vectors)>1 else 'INDETERMINATE_P12R_B1_CONSTANT_NO_CONFIRMATION'
 report=dict(status=status,development_cases=72,development_decisions=n,primary_arm_decisions=primary,distinct_primary_B1_vectors=len(vectors),case_receipt_sha256=case_hashes,confirmation_cases=0,model_fits=0,new_AP_computed=False,diagnostic_rows_used=0,**LOCK)
 (OUT/'P12R_DEV_COLLECTION_RECEIPT_v05246.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print(status,flush=True)
 need(len(vectors)>1,'PREDECLARED_CONSTANT_B1_ABORT')
if __name__=='__main__':main()
