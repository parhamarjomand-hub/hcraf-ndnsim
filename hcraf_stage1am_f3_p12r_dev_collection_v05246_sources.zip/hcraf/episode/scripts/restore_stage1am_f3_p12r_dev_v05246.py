#!/usr/bin/env python3
"""Restore exact historical build ancestors, no historical simulation invocation."""
import hashlib,json,os,pathlib,stat,subprocess,zipfile,urllib.request
ROOT=pathlib.Path.cwd()
def sha(b):return hashlib.sha256(b).hexdigest()
def need(c,m):
 if not c:raise RuntimeError(m)
def get(path):
 req=urllib.request.Request('https://api.github.com/repos/'+os.environ['GITHUB_REPOSITORY']+path,headers={'Authorization':'Bearer '+os.environ['GH_TOKEN'],'Accept':'application/vnd.github+json','User-Agent':'HCRAF-P12R-v05246'})
 with urllib.request.urlopen(req,timeout=60) as r:return json.load(r)
def archive(name,h,manifest=None):
 p=ROOT/name;b=p.read_bytes();need(sha(b)==h and subprocess.check_output(['git','show','HEAD:'+name])==b,'SOURCE_HASH_'+name)
 with zipfile.ZipFile(p) as z:
  need(z.testzip() is None,'CRC_'+name)
  if manifest:
   m=json.loads(z.read(manifest));need(set(z.namelist())==set(m['files'])|{manifest} and len(z.namelist())==len(set(z.namelist())),'MANIFEST_'+name)
   for n,h in m['files'].items():
    q=pathlib.PurePosixPath(n);need(q.parts[:2]==('hcraf','episode') and '..' not in q.parts and not q.is_absolute() and '\\' not in n and not stat.S_ISLNK(z.getinfo(n).external_attr>>16),'PATH_'+n)
    content=z.read(n);need(sha(content)==h,'MEMBER_'+n);dest=ROOT/n;need(not dest.exists(),'OVERWRITE_'+n);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(content)
 print('PASS_LOCKED_SOURCE',name,flush=True)
def main():
 need(os.environ['GITHUB_REPOSITORY']=='parhamarjomand-hub/hcraf-ndnsim','WRONG_REPOSITORY')
 for rid,commit,wf in [(45833974569,'17ba4ba7dbb6ebf997954d36a5d6981a4151752d','hcraf-stage1am-f3-p12r-fair-comparator-prospective-prereg-v0.52.37.yml'),(45835224040,'e4f0781bc26909c2311f0b76e3c2094da4f0c633','hcraf-stage1am-f3-p12s-local-causal-meter-compile-audit-v0.52.38.yml'),(45844118722,'6e67ea60c20790cbefdd1a9aec717ff58b65b3e8','hcraf-stage1am-f3-p12t-native-ndnsim-dev-sentinel-v0.52.39.yml'),(45866036207,'50e96029df98f3a24f6487446004bfc90ec6a808','hcraf-stage1am-f3-p12u-native-hook-provenance-gate-v0.52.40.yml'),(45950796539,'435293c775fc1fb1f5d20c3de2a97badffcc2058','hcraf-stage1am-f3-p12z-frozen-negative-path-causal-replay-v0.52.45.yml')]:
  r=get('/actions/runs/'+str(rid));need(r['status']=='completed' and r['conclusion']=='success' and r['head_sha']==commit and r['path'].endswith('/'+wf),'PARENT_RUN_'+str(rid));subprocess.check_call(['git','merge-base','--is-ancestor',commit,'HEAD']);print('PASS_PARENT',rid)
 for aid,rid,digest in [(15124026224,45833974569,'0ec604d9134dd2ba9e7d167690ab7817c6875e2884d32ffe4e77e807cb70dd80'),(15124357642,45835224040,'d5f1ce3e32bda56d3b86d534afb963c84586ac96d45f65873ce388b11ed82481'),(15177035369,45950796539,'788bd94c52cec642256c530101063cd694494b6f53778e0d950dcfa078c1ade0')]:
  a=get('/actions/artifacts/'+str(aid));need(a['digest']=='sha256:'+digest and a['workflow_run']['id']==rid,'PARENT_ARTIFACT_'+str(aid))
 z=ROOT/'p12r_auth_p12z/P12Z_FROZEN_NEGATIVE_NATIVE_CAUSAL_QC_v05245.json';need(sha(z.read_bytes())=='4f03064b0dcf9cced7486d346cf6f855b6d82c0e04e04bfe8ca178d47f2a8505','P12Z_RECEIPT_HASH');q=json.loads(z.read_bytes());need(q['status']=='PASS_P12Z_CAUSAL_NATIVE_NEGATIVE_PATH_WITNESS_ONLY_NO_F3_RELEASE' and q['diagnostic_evidence_not_trainable'] and not q['F3_ready'] and not q['training_ready'] and not q['GO_FREEZE'],'P12Z_LOCKS')
 k=json.loads((ROOT/'p12v_auth_p12k_receipt/stage1am_f3_p12k_prospective_prereg_v05225/P12K_PREREG_RECEIPT.json').read_bytes());need(k['GitHub_Run_ID']=='45195251299' and k['status']=='PASS_P12K_PROSPECTIVE_PREREG_ONLY_ZERO_SIM' and k['P12K_matrix_sha256']=='bebf302b14bd2096e63b8915c640f2db43e069de990f3832a0a98258b6688cbc','P12K_RECEIPT')
 helper='hcraf_stage1am_f3_p12h_validation_v05222_sources.zip';archive(helper,os.environ['V05222_SOURCE_SHA256'])
 with zipfile.ZipFile(helper) as z:
  member='hcraf/episode/scripts/prepare_stage1am_f3_p12h_validation_v05222.py';content=z.read(member)
 exec(compile(content,member,'exec'),{'__name__':'__main__'})
 for name,env,manifest in [('hcraf_stage1am_f3_p12k_prospective_prereg_v05225_sources.zip','V05225_SOURCE_SHA256','HCRAF_F3_P12K_SOURCE_SHA256_v05225.json'),('hcraf_stage1am_f3_p12l6_physical_v05231_cpp_initializer_hotfix_sources.zip','V05231_SOURCE_SHA256','HCRAF_F3_P12L6_SOURCE_SHA256_v05231.json'),('hcraf_stage1am_f3_p12r_fair_comparator_prereg_v05237_sources.zip','P12R_SOURCE_SHA256','HCRAF_F3_P12R_SOURCE_SHA256_v05237.json'),('hcraf_stage1am_f3_p12s_local_instrument_v05238_sources.zip','P12S_SOURCE_SHA256','HCRAF_F3_P12S_SOURCE_SHA256_v05238.json'),('hcraf_stage1am_f3_p12t_native_dev_smoke_v05239_sources.zip','P12T_SOURCE_SHA256','HCRAF_F3_P12T_SOURCE_SHA256_v05239.json'),('hcraf_stage1am_f3_p12v_native_12_hook_dev_v05241_sources.zip','P12V_SOURCE_SHA256','HCRAF_F3_P12V_SOURCE_SHA256_v05241.json')]:archive(name,os.environ[env],manifest)
 # Same P12U adapter member as the verified P12V build, not diagnostic source.
 name='hcraf_stage1am_f3_p12u_native_hook_provenance_v05240_sources.zip';archive(name,os.environ['P12U_SOURCE_SHA256'])
 with zipfile.ZipFile(name) as z:
  member='hcraf/episode/src/hcraf-stage1am-f3-p12u-local-nfd-hook-adapter-v05240.hpp';d=ROOT/member;need(not d.exists(),'ADAPTER_OVERWRITE');d.write_bytes(z.read(member))
 print('PASS_RESTORE_NO_DIAGNOSTIC_DATA_NO_SIMULATION',flush=True)
if __name__=='__main__':main()
