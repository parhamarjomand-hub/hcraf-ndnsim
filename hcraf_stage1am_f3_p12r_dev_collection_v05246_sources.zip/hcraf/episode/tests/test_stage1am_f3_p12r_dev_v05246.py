import importlib.util,unittest
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'scripts/run_stage1am_f3_p12r_dev_v05246.py';spec=importlib.util.spec_from_file_location('runner',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Guards(unittest.TestCase):
 def test_matrix_exact(self):
  rs=m.matrix();self.assertEqual(len(rs),72);self.assertEqual(len({r['schedule_filename'] for r in rs}),36)
  for seed in range(24901,24907):self.assertEqual(sum(int(r['seed'])==seed for r in rs),12)
 def test_commands_original_conditions(self):
  for r in m.matrix():
   c=m.command(r,Path('/tmp/test'));self.assertIn('--run='+r['seed'],c);self.assertIn('--telemetryEnabled='+str(int(r['telemetry']=='on_20ms')),c);self.assertIn('--lossProbability=0',c);self.assertNotIn('p12yProbe',c)
 def test_confirmation_rejected(self):
  r=dict(m.matrix()[0]);r['seed']='25001';self.assertRaises(RuntimeError,m.command,r,Path('/tmp/test'))
 def test_window_face_and_same_tick(self):
  def e(t,k,face=258,rtt=0):return dict(time_ns=t,event=k,face_id=face,rtt_ms=rtt)
  es=[e(25000000,'nack_rx'),e(25000001,'nack_rx'),e(30000000,'interest_drop',259),e(40000000,'rtt',rtt=8),e(80000000,'rtt',rtt=16),e(100000000,'interest_drop'),e(100000000,'interest_drop')]
  self.assertEqual(m.replay_local(es,100000000,6,258),[0,0,1,0,1,9.,0]);self.assertEqual(m.replay_local(es,100000000,7,258)[4],2)
 def test_missing_rtt(self):self.assertEqual(m.replay_local([],100000000,0,258),[0,0,0,0,0,0.,1])
 def test_future_rejected(self):self.assertRaises(RuntimeError,m.replay_local,[dict(time_ns=11,event='nack_rx',face_id=258)],10,1,258)
 def test_lock(self):self.assertFalse(m.LOCK['F3_ready']);self.assertFalse(m.LOCK['training_ready']);self.assertFalse(m.LOCK['GO_FREEZE']);self.assertIsNone(m.LOCK['FutureCongestion'])
if __name__=='__main__':unittest.main()
