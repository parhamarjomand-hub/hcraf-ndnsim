#!/usr/bin/env python3
"""Produce fixed future Development schedules and matched run matrix; NO simulator execution.

All randomness is domain-separated SHA-256 keyed by a locked public seed. It is
not generated from observed labels/metrics or from capacity-dependent streams.
"""
import argparse
import csv
import hashlib
import io
import json
from collections import Counter, defaultdict
from pathlib import Path

SCHEMA = 'HCRAF_F3_PATHWIDE_WITNESS_DEV_PREREG_V0515'
MASTER_SEED = 'HCRAF-PATHWIDE-WITNESS-v0.51.5-20261111-LOCK'
RNGS = tuple(range(11801, 11813))
FAMILIES = ('A_SHIFTED_PULSES', 'B_INTERLEAVED_PULSES')
ARMS = (('RETURN_STRESSED_6M', 6_000_000),
        ('RETURN_INTERMEDIATE_12M', 12_000_000),
        ('RETURN_MATCHED_HIGH_CAPACITY_50M', 50_000_000))
PHASES_MS = (-180, -60, 60, 180)
SCHEDULE_FIELDS = ('traffic_class', 'sequence', 'time_ns', 'family', 'rng_block',
                   'phase_label', 'phase_nominal_ns', 'phase_jitter_ns',
                   'selected_slot', 'schedule_schema')
MATRIX_FIELDS = ('run_id', 'rng_block', 'seed', 'selected_slot', 'family',
                 'phase_label', 'phase_nominal_ns', 'phase_jitter_ns', 'arm',
                 'return_link_bps', 'instrumented', 'plan_filename',
                 'schedule_sha256', 'target_schedule_sha256',
                 'competitor_schedule_sha256', 'status')
INDEX_FIELDS = ('rng_block', 'selected_slot', 'family', 'phase_label',
                'phase_nominal_ns', 'phase_jitter_ns', 'target_start_ns',
                'competitor_start_ns', 'plan_filename', 'schedule_sha256',
                'target_schedule_sha256', 'competitor_schedule_sha256')

def digest(*parts):
    key = '|'.join([MASTER_SEED] + list(map(str, parts))).encode('ascii')
    return hashlib.sha256(key).digest()

def uval(bound, *parts):
    assert bound > 0
    return int.from_bytes(digest(*parts)[:8], 'big') % bound

def signed(bound, *parts):
    return uval(2 * bound + 1, *parts) - bound

def csv_bytes(rows, fields):
    buf = io.StringIO(newline='')
    writer = csv.DictWriter(buf, fieldnames=fields, lineterminator='\n')
    writer.writeheader()
    for row in rows:
        writer.writerow(row)
    return buf.getvalue().encode('utf-8')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def allocation():
    # Each phase has one RNG per physical Slot, for 12 RNG total.
    phase_by_rng = {}
    for slot in range(3):
        candidates=sorted((r for r in RNGS if (r-11801)%3==slot),
                          key=lambda r:digest('phase-permutation',slot,r))
        assert len(candidates)==4
        for i,rng in enumerate(candidates):phase_by_rng[rng]=i
    assert Counter(phase_by_rng.values())=={0:3,1:3,2:3,3:3}
    cells=[(family,arm[0]) for family in FAMILIES for arm in ARMS]
    controls={rng:cells[(rng-11801)%6] for rng in RNGS}
    assert len(controls)==12
    return phase_by_rng, controls

def build_plan(rng, family, phase_index):
    slot = (rng - 11801) % 3
    offset = PHASES_MS[phase_index] * 1_000_000
    phase_jitter_ns = signed(12_000_000, 'phase-jitter', rng, family)
    target_start = 2_450_000_000 + signed(100_000_000, 'target-start', rng, family)
    competitor_start = target_start + offset + phase_jitter_ns
    rows = []
    for cls, count in (('TARGET', 12), ('INDEPENDENT_COMPETITOR', 96)):
        for i in range(count):
            if cls == 'TARGET':
                base = 30_000_000*i
                if family == 'B_INTERLEAVED_PULSES':
                    base += 90_000_000 * (i >= 6) + (6_000_000 if i % 2 == 0 else -6_000_000)
                when = target_start + base + signed(4_000_000, 'target-delta', rng, family, i)
            elif family == 'A_SHIFTED_PULSES':
                base = (i//48)*145_000_000 + (i%48)*2_000_000
                when = competitor_start + base + signed(100_000, 'competitor-delta',rng,family,i)
            else:
                base = (i//24)*110_000_000 + (i%24)*2_000_000
                when = competitor_start + base + signed(100_000, 'competitor-delta',rng,family,i)
            rows.append(dict(traffic_class=cls,sequence=i,time_ns=when,family=family,
                             rng_block=rng,phase_label=f'P{phase_index}',
                             phase_nominal_ns=offset,phase_jitter_ns=phase_jitter_ns,
                             selected_slot=slot,schedule_schema=SCHEMA))
    rows.sort(key=lambda r: (r['time_ns'],r['traffic_class'],r['sequence']))
    assert len(rows)==108 and all(2_000_000_000 <= r['time_ns'] < 20_000_000_000 for r in rows)
    for cls in ('TARGET', 'INDEPENDENT_COMPETITOR'):
        events = sorted(r['time_ns'] for r in rows if r['traffic_class']==cls)
        assert all(b>a for a,b in zip(events,events[1:])), (rng,family,cls)
    return rows, target_start, competitor_start

def build_files():
    phase_by_rng, controls = allocation()
    files = {}
    index, matrix = [], []
    for rng in RNGS:
        phase = phase_by_rng[rng]
        for family in FAMILIES:
            rows, target_start, competitor_start = build_plan(rng,family,phase)
            plan_name = f'plans/rng-{rng}_{family}.csv'
            b = csv_bytes(rows,SCHEDULE_FIELDS)
            files[plan_name] = b
            classhash = {
                cls: sha(csv_bytes([r for r in rows if r['traffic_class']==cls],SCHEDULE_FIELDS))
                for cls in ('TARGET','INDEPENDENT_COMPETITOR')
            }
            common = dict(rng_block=rng,selected_slot=(rng-11801)%3,family=family,
                phase_label=f'P{phase}',phase_nominal_ns=PHASES_MS[phase]*1_000_000,
                phase_jitter_ns=rows[0]['phase_jitter_ns'],plan_filename=plan_name,
                schedule_sha256=sha(b),target_schedule_sha256=classhash['TARGET'],
                competitor_schedule_sha256=classhash['INDEPENDENT_COMPETITOR'])
            index.append(dict(**common,target_start_ns=target_start,competitor_start_ns=competitor_start))
            for arm, bps in ARMS:
                for instrumented in (1,0):
                    if not instrumented and controls[rng] != (family,arm):
                        continue
                    mode='monitored' if instrumented else 'unmonitored'
                    matrix.append(dict(run_id=f'prereg-v0515-rng-{rng}-{family}-{arm}-{mode}',
                        **common,seed=17,arm=arm,return_link_bps=bps,
                        instrumented=instrumented,status='PREREG_PLANNED_NOT_RUN'))
    files['RUN_MATRIX_LOCKED_84.csv'] = csv_bytes(matrix,MATRIX_FIELDS)
    files['SCHEDULE_INDEX_LOCKED_24.csv'] = csv_bytes(index,INDEX_FIELDS)
    return files

def verify_against_disk(root):
    expected=build_files()
    existing={p.relative_to(root).as_posix() for p in root.glob('plans/*.csv')}
    assert existing=={k for k in expected if k.startswith('plans/')}, 'PLAN_SET_CHANGED'
    for name,blob in expected.items():
        actual=(root/name).read_bytes()
        assert actual==blob, 'LOCKED_CONTENT_MISMATCH:'+name
    return dict(schedules=24, monitored_runs=72, unmonitored_runs=12,
                total_runs=84, independent_rng_blocks=12,
                locked_file_count=len(expected), locked_files_sha256={k:sha(v) for k,v in sorted(expected.items())})

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--output',type=Path)
    p.add_argument('--verify',type=Path)
    args=p.parse_args()
    assert (args.output is None)!=(args.verify is None),'Choose --output OR --verify'
    if args.output:
        args.output.mkdir(parents=True,exist_ok=True)
        for name,blob in build_files().items():
            file=args.output/name
            file.parent.mkdir(parents=True,exist_ok=True)
            assert not file.exists(),f'REFUSE_OVERWRITE:{name}'
            file.write_bytes(blob)
        result=verify_against_disk(args.output)
    else:
        result=verify_against_disk(args.verify)
    print(json.dumps({'status':'PREREG_CONTRACT_ONLY_NO_NDNSIM_RUN',**result},ensure_ascii=False,indent=2))

if __name__=='__main__':
    main()
