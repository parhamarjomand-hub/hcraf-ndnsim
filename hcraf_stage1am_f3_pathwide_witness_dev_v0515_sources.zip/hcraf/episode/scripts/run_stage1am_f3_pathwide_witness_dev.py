#!/usr/bin/env python3
"""Execute *after separate Git lock* of v0.51.5 Development matrix, no F3 training."""
import argparse,csv,hashlib,json,os,pathlib,subprocess,sys
ROOT=pathlib.Path(__file__).resolve().parents[3]
CONTRACT=ROOT/'hcraf/episode/docs/1AM/F3_PATHWIDE_WITNESS_DEV_v0.51.5'
OUT=ROOT/'episode_output/stage1am_f3_pathwide_witness_dev'
REPORT=ROOT/'episode_output/stage1am_f3_pathwide_witness_report'
ARMS={'RETURN_STRESSED_6M':6000000,'RETURN_INTERMEDIATE_12M':12000000,'RETURN_MATCHED_HIGH_CAPACITY_50M':50000000}
LOCKS={'Congestion':None,'FutureCongestion':None,'F3_ready':False,'GO_FREEZE':False,'training_ready':False}
HASHES={'RUN_MATRIX_LOCKED_84.csv': 'ebfc115dca3f04b096e184cd429ed92dd5d3adcbc9389e9f11301d712c8695b7', 'SCHEDULE_INDEX_LOCKED_24.csv': '6bcfc321f113f8a2e741d81c87c546447ea1a9b172a70c63e1165ac0bfcf1fea'}

def digest(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()
def check(ok,reason):
    if not ok:raise RuntimeError(reason)
def load_matrix():
    for n,h in HASHES.items():check(digest(CONTRACT/n)==h,'LOCKED_HASH_CHANGED:'+n)
    with (CONTRACT/'RUN_MATRIX_LOCKED_84.csv').open(newline='') as f:matrix=list(csv.DictReader(f))
    with (CONTRACT/'SCHEDULE_INDEX_LOCKED_24.csv').open(newline='') as f:index=list(csv.DictReader(f))
    check(len(matrix)==84 and len(index)==24,'LOCKED_MATRIX_CARDINALITY')
    check(len({r['run_id'] for r in matrix})==84,'DUPLICATE_RUN_ID')
    check({int(r['rng_block']) for r in matrix}==set(range(11801,11813)),'BAD_RNG_SET')
    check({r['status'] for r in matrix}=={'PREREG_PLANNED_NOT_RUN'},'MATRIX_LABELS_ADDED')
    check(sum(int(r['instrumented']) for r in matrix)==72,'MONITORED_COUNT')
    by_pair={}
    for row in matrix:
        rng=int(row['rng_block']); slot=int(row['selected_slot']); fam=row['family'];arm=row['arm']
        check(row['seed']=='17' and slot==(rng-11801)%3 and arm in ARMS,'BAD_SLOT_SEED_OR_ARM')
        check(row['family'] in ('A_SHIFTED_PULSES','B_INTERLEAVED_PULSES'),'BAD_FAMILY')
        check(int(row['return_link_bps'])==ARMS[arm],'RATE_CONFLICT')
        check(int(row['instrumented']) in (0,1),'BAD_INSTRUMENT')
        plan=(CONTRACT/row['plan_filename']).resolve()
        check(os.path.commonpath([str(plan),str(CONTRACT.resolve())])==str(CONTRACT.resolve()) and plan.exists(),'UNSAFE_OR_MISSING_PLAN')
        check(digest(plan)==row['schedule_sha256'],'FROZEN_PLAN_HASH_MISMATCH')
        key=(rng,fam)
        if key in by_pair:check(by_pair[key]==row['schedule_sha256'],'PAIRED_PLAN_HASH_CHANGED')
        by_pair[key]=row['schedule_sha256']
    check(len(by_pair)==24,'BAD_PAIR_SET')
    return matrix

def assert_send_plan(path,plan):
    with plan.open(newline='') as f:rows=list(csv.DictReader(f))
    check(len(rows)==108,'NOT_108_LOCKED_EVENTS')
    for cls,basename,prefix,count in [('TARGET','consumer_events.jsonl','/hcraf/pilot/',12),('INDEPENDENT_COMPETITOR','competitor_events.jsonl','/hcraf/competitor/',96)]:
        expected={int(r['sequence']):int(r['time_ns']) for r in rows if r['traffic_class']==cls}
        check(len(expected)==count,'INVALID_PREREG_CLASS_CARDINALITY')
        arrivals=[json.loads(x) for x in (path/(basename+'.arrivals.jsonl')).read_text().splitlines() if x]
        events=[json.loads(x) for x in (path/basename).read_text().splitlines() if x]
        sends=[e for e in events if e.get('event')=='SEND']
        check(len(arrivals)==len(sends)==count,'MISSING_SEND_OR_ARRIVAL')
        a={int(e['sequence']):int(e['time_ns']) for e in arrivals}
        check(a==expected,'ACTUAL_ARRIVALS_DIFFER_FROM_LOCKED_PLAN')
        actual={int(e['name'].split('/')[-1]):int(e['time_ns']) for e in sends if e['name'].startswith(prefix)}
        check(actual==expected,'ACTUAL_SEND_DIFFERS_FROM_LOCKED_PLAN')
        check({e['schedule'] for e in arrivals}=={'F3_PATHWIDE_WITNESS_DEV_PREREG_V0515_LOCKED_CSV'},'SCHEDULE_SOURCE_NOT_LOCKED')
    return True

def preflight():
    matrix=load_matrix()
    check(not OUT.exists() and not REPORT.exists(),'REFUSE_OVERWRITE_ANY_PRIOR_OUTPUT')
    check((ROOT/'episode_sources/ns-3/build/scratch/hcraf-stage1am-f3-pathwide-witness-dev').is_file(), 'NEW_CPP_NOT_BUILT')
    return matrix

def run():
    matrix=preflight()
    OUT.mkdir(parents=True)
    for i,row in enumerate(matrix,1):
        rng=int(row['rng_block']);slot=int(row['selected_slot']);instrument=int(row['instrumented']);family=row['family'];arm=row['arm']
        kind='monitored' if instrument else 'unmonitored'
        dest=OUT/'DEV_CHAIN_L'/('rng-'+str(rng))/family/kind/arm
        check(not dest.exists(),'RUN_DESTINATION_EXISTS')
        dest.mkdir(parents=True)
        plan=(CONTRACT/row['plan_filename']).resolve()
        args=[f'--pathArm={arm}',f'--scheduleFamily={family}',f'--scheduleCsv={plan}',
            '--topology=DEV_CHAIN_L',f'--selectedSlot={slot}',
            '--mode=LP_INDEPENDENT_COMPETITOR_NO_DROP','--seed=17',f'--run={rng}',
            f'--output={dest}',f'--instrument={instrument}',
            '--lifetimeMs=2600','--requestCount=12','--intervalNs=30000000',
            '--competitorCount=96','--competitorIntervalNs=2000000','--competitorOffsetNs=0',
            '--targetOffsetNs=30000000','--forwardBps=50000000','--returnBps=50000000']
        spec='hcraf-stage1am-f3-pathwide-witness-dev '+' '.join(args)
        (dest/'command.txt').write_text(spec+'\n')
        (dest/'locked_row.json').write_text(json.dumps(row,sort_keys=True,indent=2)+'\n')
        with (dest/'simulator.log').open('w') as log:
            subprocess.run(['/usr/bin/time','-f','wall_seconds=%e\nuser_seconds=%U\nsystem_seconds=%S\nmax_rss_kib=%M',
                 '-o',str(dest/'resource_usage.txt'),'python3','./waf','--run-no-build',spec],
                 cwd=ROOT/'episode_sources/ns-3',stdout=log,stderr=subprocess.STDOUT,check=True)
        assert_send_plan(dest,plan)
        if instrument:
            with (dest/'episodes.log').open('w') as log:
                subprocess.run(['python3',str(ROOT/'hcraf/episode/scripts/episodes_stage1u.py'),str(dest),
                    '--run-id','1am_pathwide_witness_dev-DEV_CHAIN_L-'+str(rng)+'-'+family+'-'+arm],
                    cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
        print('RUN_OK',i,'of',len(matrix),row['run_id'],flush=True)
    import verify_stage1am_f3_pathwide_witness_dev as v
    print(v.audit(OUT,REPORT),flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--preflight-only',action='store_true');args=ap.parse_args()
    if args.preflight_only:
        m=load_matrix();print(json.dumps({'status':'PASS_LOCKED_MATRIX_PREFLIGHT_ONLY_NO_SIMULATION','rows':len(m)},indent=2))
    else:run()
