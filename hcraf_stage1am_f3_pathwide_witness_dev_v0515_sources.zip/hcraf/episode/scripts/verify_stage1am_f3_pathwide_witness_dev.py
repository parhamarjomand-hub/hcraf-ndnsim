#!/usr/bin/env python3
"""Fail-closed independent two-recorder audit; does NOT construct official F3 labels."""
import collections,csv,hashlib,json,pathlib,sys
from run_stage1am_f3_pathwide_witness_dev import load_matrix,assert_send_plan,LOCKS,ARMS,CONTRACT,check

EVENTS={'QUEUE_ENQUEUE','QUEUE_DEQUEUE','QUEUE_DROP','PHY_TX_BEGIN','PHY_TX_END'}


def scan_jsonl(path):
    check(path.exists(),'MISSING_RECORD:'+str(path))
    with path.open(encoding='utf-8') as f:
        for lineno,line in enumerate(f,1):
            if not line.strip():raise RuntimeError(f'BLANK_EVENT:{path}:{lineno}')
            try:yield json.loads(line)
            except json.JSONDecodeError as e:raise RuntimeError(f'INVALID_JSON:{path}:{lineno}') from e


def parse_monitor(path,monitor):
    check(monitor in ('A','B'),'INVALID_MONITOR')
    initials={};finals={};counts=collections.Counter();dropped={};sent={};timestamps={};seen_snapshot=collections.defaultdict(set)
    last_seq=0;last_time=-1;event_total=0;age_bad_snapshot=0
    for e in scan_jsonl(path):
        seq=e['link_event_seq'] if monitor=='A' else e['sequence']
        ts=e['time_ns'] if monitor=='A' else e['timestamp_ns']
        key=(e['node_id'],e['device_index']);kind=e['event_type']
        check(seq==last_seq+1 and ts>=last_time,'WITNESS_SEQUENTIAL_CLOCK_INVALID:'+monitor)
        if monitor=='B':check(e['monitor_id']=='B' and e['schema_version']=='PATHWIDE_WITNESS_B.1','B_SCHEMA_OR_ID_CHANGED')
        last_seq=seq;last_time=ts;event_total+=1
        if kind=='INITIAL':
            check(key not in initials,'DUP_INITIAL');initials[key]=e
            check(ts==0,'INITIAL_TIME_INVALID')
        elif kind=='FINAL':
            check(key not in finals,'DUP_FINAL');finals[key]=e
            check(ts==20_000_000_000,'FINAL_TIME_INVALID')
        if kind in EVENTS:counts[key,kind]+=1
        if kind=='QUEUE_SNAPSHOT':
            tick=e['sample_tick']
            check(ts==tick*1_000_000 and 1<=tick<=19999,'B_SAMPLE_CLOCK_INVALID')
            seen_snapshot[key].add(tick)
            if not e.get('pending_age_verified',False):age_bad_snapshot+=1
        if kind=='FINAL':
            dropped[key]= e['queue_drop_packets_total'] if monitor=='A' else e['drop_packets_cumulative']
            sent[key]= e['phy_tx_started_bytes_total'] if monitor=='A' else e['tx_bytes_cumulative']
    check(len(initials)==len(finals)==20 and set(initials)==set(finals),'20_DEVICE_COVERAGE_MISSING:'+monitor)
    check(event_total>40,'EMPTY_TRACE:'+monitor)
    if monitor=='B':
        required=set(range(10,20000,10))|{1}
        for key in initials:
            check(required.issubset(seen_snapshot[key]),'B_SAMPLE_HEARTBEAT_GAP:'+str(key))
    return {'initials':initials,'finals':finals,'counts':counts,'dropped':dropped,'sent':sent,
            'events':event_total,'age_bad_snapshot':age_bad_snapshot}


def eight_devices(path_nodes, initial):
    check(len(path_nodes)==5 and len(set(path_nodes))==5,'INVALID_SELECTED_PATH')
    # These are the actual per-branch node identities, not guessed Face IDs.
    path=[]
    for a,b in zip(path_nodes,path_nodes[1:]):
        for node in (a,b):
            candidates=[k for k,v in initial.items() if k[0]==node]
            # The expected physical device index comes from frozen path map, not from this helper.
            check(candidates,'EMPTY_SELECTED_PATH_NODE')
        path.extend((a,b))
    return path


def witness_a_b(run_dir, c, row, pathmap):
    A=parse_monitor(run_dir/'link_events.jsonl','A')
    B=parse_monitor(run_dir/'pathwide_witness_b.jsonl','B')
    check(set(A['initials'])==set(B['initials']),'B_DEVICE_SET_DIFFERS')
    for key in A['initials']:
        check(A['initials'][key]['face_id']==B['initials'][key]['face_id'],'A_B_FACE_MISMATCH:'+str(key))
        check(A['dropped'][key]==B['dropped'][key],'A_B_DROP_COUNTER_MISMATCH:'+str(key))
        check(A['sent'][key]==B['sent'][key],'A_B_TX_BYTES_MISMATCH:'+str(key))
        for kind in EVENTS:
            check(A['counts'][key,kind]==B['counts'][key,kind],'A_B_EVENT_COUNT_MISMATCH:'+str(key)+':'+kind)
    slot=int(row['selected_slot'])
    expected={(int(p['sender_node_id']),int(p['device_index'])) for p in pathmap if int(p['slot'])==slot}
    check(len(expected)==8 and expected.issubset(set(A['initials'])),'LOCKED_EIGHT_DEVICE_PATH_INCOMPLETE')
    route=c['path_nodes']
    check(eight_devices(route,A['initials']) and int(route[0])==0 and int(route[1])==1,'INVALID_PATH_NODES')
    return {'a_events':A['events'],'b_events':B['events'],'b_unverifiable_snapshots':B['age_bad_snapshot'],
            'total_queue_drops':sum(A['dropped'].values()),'path_queue_drops':sum(A['dropped'][k] for k in expected),
            'device_count':20,'path_devices':len(expected),'witness_mismatch_count':0}


def audit(output,report):
    check(output.is_dir() and not report.exists(),'REPORT_EXISTS_OR_RUNS_MISSING')
    matrix=load_matrix()
    check(len(matrix)==84,'MATRIX_NOT_LOCKED')
    with (CONTRACT/'PATH_MAP_LOCKED_24.csv').open(newline='') as f:pathmap=list(csv.DictReader(f))
    check(len(pathmap)==24,'PATH_MAP_NOT_24')
    results=[];runset=set()
    for row in matrix:
        kind='monitored' if int(row['instrumented']) else 'unmonitored'
        d=output/'DEV_CHAIN_L'/('rng-'+row['rng_block'])/row['family']/kind/row['arm']
        check(d.is_dir(),'MISSING_RUN:'+row['run_id'])
        check(row['run_id'] not in runset,'DUPLICATE_RUN');runset.add(row['run_id'])
        c=json.loads((d/'scenario.json').read_text())
        check(c['amendment_stage']=='1AM.F3_PATHWIDE_WITNESS_DEV.0','WRONG_DEV_SCENARIO')
        check(c['schedule_contract']=='F3_PATHWIDE_WITNESS_DEV_PREREG_V0515_LOCKED_CSV','SCHEDULE_CONTRACT_CHANGED')
        check(c['independent_rng_block']==int(row['rng_block']) and c['seed']==17,'WRONG_RNG')
        check(c['selected_face_slot']==int(row['selected_slot']),'WRONG_SELECTED_SLOT')
        check(c['selected_producer_reverse_bps']==int(row['return_link_bps']),'WRONG_ARM_RATE')
        check(c['schedule_family']==row['family'] and c['instrument_enabled'] is bool(int(row['instrumented'])),'CONFIG_INCONSISTENT')
        check(c['topology_id']=='DEV_CHAIN_L' and c['holdout_partition']=='DEVELOPMENT','NOT_DEV_ONLY')
        for name,value in LOCKS.items():check(c.get(name,'MISSING') is value,'SCIENCE_LOCK_BREACH:'+name)
        check(c.get('future_oracle_is_final_F3') is False,'OFFICIAL_F3_WRITE_FORBIDDEN')
        assert_send_plan(d,CONTRACT/row['plan_filename'])
        rec={'run_id':row['run_id'],'rng':row['rng_block'],'family':row['family'],
             'arm':row['arm'],'instrumented':int(row['instrumented']),'result':'PASS_STRUCTURAL'}
        if int(row['instrumented']):rec.update(witness_a_b(d,c,row,pathmap))
        else:
            check(not (d/'pathwide_witness_b.jsonl').exists(),'WITNESS_B_ON_UNMONITORED_CONTROL')
        check((d/'resource_usage.txt').is_file(),'RESOURCE_MONITOR_MISSING')
        results.append(rec)
    check(len(results)==84 and sum(x['instrumented'] for x in results)==72,'BAD_RUN_COUNTS')
    report.mkdir(parents=True)
    fields=sorted(set().union(*(r.keys() for r in results)))
    with (report/'device_reconciliation_84.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(results)
    status={'status':'PASS_PATHWIDE_WITNESS_DEV_STRUCTURAL_ONLY',
            'monitored_runs':72,'unmonitored_runs':12,'independent_rng_blocks':12,
            'formal_f3_labels_produced':False,'construct_validated':False,
            'no_nsga_iii':True,'science_status':'NO_GO_F3_CONSTRUCT_AND_PREDICTABILITY_NOT_VALIDATED',**LOCKS}
    (report/'summary.json').write_text(json.dumps(status,indent=2,ensure_ascii=False)+'\n')
    return status

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('output',type=pathlib.Path);ap.add_argument('--report',required=True,type=pathlib.Path)
    args=ap.parse_args();print(json.dumps(audit(args.output,args.report),indent=2))
