#ifndef HCRAF_STAGE1AM_PATHWIDE_WITNESS_B_HPP
#define HCRAF_STAGE1AM_PATHWIDE_WITNESS_B_HPP
// Pathwide witness B: independent writer/counters, shared physical ns-3 queues.
// v0.51.5 diagnostic instrumentation only: NEVER writes F3, Congestion, TargetImpact.
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/ndnSIM/model/ndn-l3-protocol.hpp"
#include "ns3/ndnSIM/NFD/daemon/face/face.hpp"
#include <algorithm>
#include <deque>
#include <fstream>
#include <map>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

class HcrafPathwideWitnessB {
  struct DeviceState {
    ns3::Ptr<ns3::PointToPointNetDevice> device;
    uint32_t node = 0, index = 0;
    uint64_t face = 0, dropCount = 0, txBytes = 0;
    uint64_t enqueueCount = 0, dequeueCount = 0, sampleCount = 0;
    uint64_t lastEmittedTick = 0;
    int64_t lastOldestAge = -1;
    uint32_t lastPackets = 0;
    std::map<uint64_t,std::deque<int64_t>> timestamps;
  };
public:
  HcrafPathwideWitnessB(const ns3::NodeContainer& nodes, const std::string& file,
                        const std::string& runId, uint32_t selectedSlot)
    : m_out(file), m_runId(runId), m_slot(selectedSlot) {
    if(!m_out) throw std::runtime_error("WITNESS_B_CANNOT_OPEN_OUTPUT");
    if(selectedSlot > 2) throw std::runtime_error("WITNESS_B_INVALID_SLOT");
    for(uint32_t n=0;n<nodes.GetN();++n){
      auto node=nodes.Get(n);
      auto l3=node->GetObject<ns3::ndn::L3Protocol>();
      if(!l3) throw std::runtime_error("WITNESS_B_L3_MISSING");
      for(uint32_t d=0;d<node->GetNDevices();++d){
        auto dev=ns3::DynamicCast<ns3::PointToPointNetDevice>(node->GetDevice(d));
        if(!dev)continue;
        auto face=l3->getFaceByNetDevice(dev);
        if(!face || !dev->GetQueue())throw std::runtime_error("WITNESS_B_FACE_OR_QUEUE_MISSING");
        DeviceState info;
        info.device=dev;info.node=node->GetId();info.index=dev->GetIfIndex();info.face=face->getId();
        uint32_t id=static_cast<uint32_t>(m_devices.size());
        m_devices.push_back(std::move(info));
        bool ok=dev->GetQueue()->TraceConnectWithoutContext("Enqueue",ns3::MakeBoundCallback(&HcrafPathwideWitnessB::OnEnqueue,this,id));
        ok=dev->GetQueue()->TraceConnectWithoutContext("Dequeue",ns3::MakeBoundCallback(&HcrafPathwideWitnessB::OnDequeue,this,id))&&ok;
        ok=dev->GetQueue()->TraceConnectWithoutContext("Drop",ns3::MakeBoundCallback(&HcrafPathwideWitnessB::OnDrop,this,id))&&ok;
        ok=dev->TraceConnectWithoutContext("PhyTxBegin",ns3::MakeBoundCallback(&HcrafPathwideWitnessB::OnBegin,this,id))&&ok;
        ok=dev->TraceConnectWithoutContext("PhyTxEnd",ns3::MakeBoundCallback(&HcrafPathwideWitnessB::OnEnd,this,id))&&ok;
        if(!ok)throw std::runtime_error("WITNESS_B_TRACE_CALLBACK_UNAVAILABLE");
      }
    }
    if(m_devices.size()!=20)throw std::runtime_error("WITNESS_B_REQUIRES_20_DIRECTIONAL_DEVICES");
    ValidateSelectedPath();
    for(uint32_t i=0;i<m_devices.size();++i)Emit(i,"INITIAL",nullptr,0);
    ns3::Simulator::Schedule(ns3::NanoSeconds(1000000),&HcrafPathwideWitnessB::Poll,this);
  }
  void Finish(){
    if(m_finished)return;
    // End-state event age can be calculated from event-driven enqueue times.
    for(uint32_t i=0;i<m_devices.size();++i)Emit(i,"FINAL",nullptr,0);
    m_out.flush();if(!m_out)throw std::runtime_error("WITNESS_B_FLUSH_FAILED");
    m_finished=true;
  }
private:
  static std::string Quote(const std::string& raw){
    std::string s="\"";const char *hex="0123456789abcdef";
    for(unsigned char c:raw){if(c=='\"'||c=='\\'){s+='\\';s+=char(c);}
      else if(c<32){s+="\\u00";s+=hex[c>>4];s+=hex[c&15];}else s+=char(c);}
    return s+'\"';
  }
  int64_t OldestAge(DeviceState& d)const{
    int64_t earliest=std::numeric_limits<int64_t>::max();
    size_t num=0;
    for(auto const& kv:d.timestamps)for(int64_t ts:kv.second){earliest=std::min(earliest,ts);++num;}
    if(num!=d.device->GetQueue()->GetNPackets())return -1; // no imputation of missing age
    if(num==0)return 0;
    return ns3::Simulator::Now().GetNanoSeconds()-earliest;
  }
  void Emit(uint32_t i,const char* name,ns3::Ptr<const ns3::Packet> p,int64_t wait){
    auto& d=m_devices.at(i);
    int64_t age=OldestAge(d);
    auto now=ns3::Simulator::Now().GetNanoSeconds();
    m_out<<"{\"schema_version\":\"PATHWIDE_WITNESS_B.1\",\"monitor_id\":\"B\",\"run_id\":"<<Quote(m_runId)
      <<",\"sequence\":"<<++m_sequence<<",\"timestamp_ns\":"<<now
      <<",\"node_id\":"<<d.node<<",\"device_index\":"<<d.index<<",\"face_id\":"<<d.face
      <<",\"event_type\":"<<Quote(name)<<",\"queue_packets\":"<<d.device->GetQueue()->GetNPackets()
      <<",\"queue_bytes\":"<<d.device->GetQueue()->GetNBytes()
      <<",\"drop_packets_cumulative\":"<<d.dropCount<<",\"tx_bytes_cumulative\":"<<d.txBytes
      <<",\"packet_uid\":"<<(p?std::to_string(p->GetUid()):"null")
      <<",\"queue_wait_ns\":"<<(wait>=0?std::to_string(wait):"null")
      <<",\"oldest_packet_age_ns_upper_bound\":"<<(age>=0?std::to_string(age):"null")
      <<",\"pending_age_verified\":"<<(age>=0?"true":"false")
      <<",\"sample_tick\":"<<m_sampleTick
      <<",\"sampling_interval_ns\":1000000,\"selected_slot\":"<<m_slot<<"}\n";
    if(!m_out)throw std::runtime_error("WITNESS_B_WRITE_FAILED");
  }
  static void OnEnqueue(HcrafPathwideWitnessB* self,uint32_t i,ns3::Ptr<const ns3::Packet> p){
    auto& d=self->m_devices.at(i);d.timestamps[p->GetUid()].push_back(ns3::Simulator::Now().GetNanoSeconds());
    ++d.enqueueCount;self->Emit(i,"QUEUE_ENQUEUE",p,-1);
  }
  static void OnDequeue(HcrafPathwideWitnessB* self,uint32_t i,ns3::Ptr<const ns3::Packet> p){
    auto& d=self->m_devices.at(i);int64_t wait=-1;
    auto it=d.timestamps.find(p->GetUid());
    if(it!=d.timestamps.end()&&!it->second.empty()){
      wait=ns3::Simulator::Now().GetNanoSeconds()-it->second.front();it->second.pop_front();
      if(it->second.empty())d.timestamps.erase(it);
    }
    ++d.dequeueCount;self->Emit(i,"QUEUE_DEQUEUE",p,wait);
  }
  static void OnDrop(HcrafPathwideWitnessB* self,uint32_t i,ns3::Ptr<const ns3::Packet> p){
    ++self->m_devices.at(i).dropCount;self->Emit(i,"QUEUE_DROP",p,-1);
  }
  static void OnBegin(HcrafPathwideWitnessB* self,uint32_t i,ns3::Ptr<const ns3::Packet> p){
    self->m_devices.at(i).txBytes+=p->GetSize();self->Emit(i,"PHY_TX_BEGIN",p,-1);
  }
  static void OnEnd(HcrafPathwideWitnessB* self,uint32_t i,ns3::Ptr<const ns3::Packet> p){self->Emit(i,"PHY_TX_END",p,-1);}
  void ValidateSelectedPath(){
    const uint32_t slot=m_slot;
    const uint32_t relay=2+slot;
    const uint32_t mid=(slot==0?7:(slot==1?6:5));
    const uint32_t producer=8+slot;
    const std::vector<uint32_t> nodes={0,1,relay,mid,producer};
    size_t count=0;
    for(size_t hop=0;hop+1<nodes.size();++hop){
      for(int dir=0;dir<2;++dir){
        uint32_t src=dir==0?nodes[hop]:nodes[hop+1],dst=dir==0?nodes[hop+1]:nodes[hop];
        size_t matches=0;
        for(auto const& d:m_devices){
          if(d.node!=src)continue;
          auto channel=ns3::DynamicCast<ns3::PointToPointChannel>(d.device->GetChannel());
          if(!channel || channel->GetNDevices()!=2)continue;
          for(uint32_t j=0;j<2;++j){
            auto endpoint=channel->GetDevice(j);
            if(endpoint!=d.device&&endpoint->GetNode()->GetId()==dst)++matches;
          }
        }
        if(matches!=1)throw std::runtime_error("WITNESS_B_SELECTED_PATH_EDGE_MISSING_OR_AMBIGUOUS");
        ++count;
      }
    }
    if(count!=8)throw std::runtime_error("WITNESS_B_PATH_DEVICE_COUNT");
  }
  void Poll(){
    if(m_finished)return;
    ++m_sampleTick;
    for(uint32_t i=0;i<m_devices.size();++i){
      auto& d=m_devices[i];++d.sampleCount;
      uint32_t packets=d.device->GetQueue()->GetNPackets();int64_t age=OldestAge(d);
      // At most one heartbeat per 10 ticks; changes reported immediately.
      if(m_sampleTick==1||m_sampleTick%10==0||packets!=d.lastPackets||age<0||
         (age>=5000000&&d.lastOldestAge<5000000))Emit(i,"QUEUE_SNAPSHOT",nullptr,0);
      d.lastPackets=packets;d.lastOldestAge=age;
    }
    if(ns3::Simulator::Now().GetNanoSeconds()+1000000<20000000000LL)
      ns3::Simulator::Schedule(ns3::NanoSeconds(1000000),&HcrafPathwideWitnessB::Poll,this);
  }
  std::ofstream m_out;
  std::string m_runId;
  uint32_t m_slot=0;
  uint64_t m_sequence=0,m_sampleTick=0;
  bool m_finished=false;
  std::vector<DeviceState> m_devices;
};
#endif
