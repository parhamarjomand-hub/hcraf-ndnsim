import csv,hashlib,importlib.util,json,pathlib,tempfile,unittest,sys

ROOT=pathlib.Path(__file__).resolve().parents[1]
DOC=ROOT/'docs/1AM/F3_PATHWIDE_WITNESS_DEV_v0.51.5'
sys.path.insert(0,str(ROOT/'scripts'))
SRC=ROOT/'src/hcraf-stage1am-f3-pathwide-witness-dev.cpp'
WITNESS=ROOT/'src/hcraf-stage1am-pathwide-witness-b.hpp'


def load_module(p,name):
    spec=importlib.util.spec_from_file_location(name,p)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module

class PreregTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.g=load_module(DOC/'generate_prereg.py','g0515')
        cls.runner=load_module(ROOT/'scripts/run_stage1am_f3_pathwide_witness_dev.py','runner0515')
        cls.verifier=load_module(ROOT/'scripts/verify_stage1am_f3_pathwide_witness_dev.py','verifier0515')
        cls.matrix=list(csv.DictReader((DOC/'RUN_MATRIX_LOCKED_84.csv').open()))

    def test_matrix_exact(self):
        self.assertEqual(len(self.matrix),84)
        self.assertEqual(len({r['run_id'] for r in self.matrix}),84)
    def test_monitored_72(self):self.assertEqual(sum(int(r['instrumented']) for r in self.matrix),72)
    def test_unmonitored_12(self):self.assertEqual(sum(r['instrumented']=='0' for r in self.matrix),12)
    def test_rng_12(self):self.assertEqual({int(r['rng_block']) for r in self.matrix},set(range(11801,11813)))
    def test_two_families(self):self.assertEqual({r['family'] for r in self.matrix},set(self.g.FAMILIES))
    def test_arms(self):self.assertEqual({r['arm'] for r in self.matrix},{a for a,_ in self.g.ARMS})
    def test_no_splits(self):self.assertEqual({r['status'] for r in self.matrix},{'PREREG_PLANNED_NOT_RUN'})
    def test_four_phases_each_slot(self):
        map=self.g.allocation()[0]
        self.assertEqual(set(map.values()),{0,1,2,3})
        for slot in range(3):self.assertEqual({map[r] for r in map if (r-11801)%3==slot},{0,1,2,3})
    def test_plan_source_identical_across_arms(self):
        groups={}
        for r in self.matrix:
            key=(r['rng_block'],r['family']);groups.setdefault(key,set()).add(r['schedule_sha256'])
        self.assertEqual(len(groups),24)
        self.assertTrue(all(len(v)==1 for v in groups.values()))
    def test_sha_locked_files(self):
        result=self.g.verify_against_disk(DOC)
        self.assertEqual(result['total_runs'],84)
    def test_runner_preflight(self):self.assertEqual(len(self.runner.load_matrix()),84)
    def test_source_never_model(self):
        s=SRC.read_text()
        self.assertIn('HcrafPathwideWitnessB',s)
        self.assertIn('PATHWIDE_WITNESS_DEV_PREREG_V0515',s)
        self.assertIn('"future_oracle_is_final_F3\\":false',s)
    def test_witness_no_forwarding_modification(self):
        s=WITNESS.read_text()
        for word in ('SetDataRate(', 'AddRoute(', 'setCsSize(', 'hcrafSetDecisionObserver('):
            self.assertNotIn(word,s)
    def test_b_has_required_callbacks(self):
        s=WITNESS.read_text()
        for name in ('OnEnqueue','OnDequeue','OnDrop','OnBegin','OnEnd','Poll','ValidateSelectedPath'):
            self.assertIn(name,s)
    def test_b_1ms_poll_heartbeat(self):
        s=WITNESS.read_text()
        self.assertIn('NanoSeconds(1000000)',s)
        self.assertIn('m_sampleTick%10==0',s)
    def test_science_locks(self):
        self.assertEqual(json.loads((DOC/'SCIENCE_LOCKS.json').read_text()),
            {'Congestion':None,'FutureCongestion':None,'F3_ready':False,'GO_FREEZE':False,'training_ready':False})
    def test_wrong_matrix_rejected(self):
        self.assertEqual(self.runner.HASHES['RUN_MATRIX_LOCKED_84.csv'],hashlib.sha256((DOC/'RUN_MATRIX_LOCKED_84.csv').read_bytes()).hexdigest())
    def test_path_eight_devices_three_slots(self):
        rows=list(csv.DictReader((DOC/'PATH_MAP_LOCKED_24.csv').open()))
        self.assertEqual(len(rows),24)
        for slot in range(3):
            self.assertEqual(len([r for r in rows if int(r['slot'])==slot]),8)
    def test_wrong_no_event_negative_forbidden(self):
        s=(DOC/'SCIENTIFIC_PROTOCOL_FA.md').read_text()
        self.assertIn('UNKNOWN',s)
    def test_b_adverse_age_is_null(self):
        self.assertIn('return -1; // no imputation',WITNESS.read_text())
    def test_invalid_monitor_rejected(self):
        with self.assertRaises(RuntimeError):self.verifier.parse_monitor(pathlib.Path('nonexistent'),'C')
    def test_empty_trace_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            p=pathlib.Path(t)/'empty.jsonl';p.write_text('')
            with self.assertRaises(RuntimeError):self.verifier.parse_monitor(p,'B')
    def test_wrong_device_path_rejected(self):
        with self.assertRaises(RuntimeError):self.verifier.eight_devices([0,1,1,7,8],{})
    def test_two_step_gate_explicit(self):
        s=(DOC/'SCIENTIFIC_PROTOCOL_FA.md').read_text()
        self.assertIn('LOCK ONLY',s)
    def test_official_training_not_present(self):
        s=(ROOT/'scripts/run_stage1am_f3_pathwide_witness_dev.py').read_text()
        self.assertNotIn('NSGA',s.upper())

if __name__=='__main__':unittest.main()
